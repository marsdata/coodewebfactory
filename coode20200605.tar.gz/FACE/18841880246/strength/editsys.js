function strengthtb(tbnm,tbtt,tbdt){
 tbct=tbdt.fields.length;
 fmknm="";
 fmktt="";
 fmktp="";
 fmklen="";
 fmkstt="";
 for (i=0;i<tbct;i++){
   knm=tbdt.fields[i].name;
   ktp=tbdt.fields[i].type;
   if (knm!="id" && knm!="ID"){
     fmknm=fmknm+knm+",";
     fmktt=fmktt+",";
     fmkstt=fmkstt+"1,";
     switch (ktp){
     case "int":
     fmktp=fmktp+"int,";
     fmklen=fmklen+"11,";
     break;
     case "Int":
     fmktp=fmktp+"int,";
     fmklen=fmklen+"11,";
     break;
     case "float":
     fmktp=fmktp+"decimal,";
     fmklen=fmklen+",";
     break;
     case "Float":
     fmktp=fmktp+"decimal,";
     fmklen=fmklen+",";
     break;
     case "date":
     kfmt=tbdt.fields[i].dateFormat;
     if (kfmt=="Y-m-d H:i:s.u"){
       fmktp=fmktp+"datetime,";
     }else{
       fmktp=fmktp+"date,";
     }
     fmklen=fmklen+",";
     break;
     case "Date":
     kfmt=tbdt.fields[i].dateFormat;     
     if (kfmt=="Y-m-d H:i:s.u"){
       fmktp=fmktp+"datetime,";
     }else{
       fmktp=fmktp+"date,";
     }
     fmklen=fmklen+",";
     break;
     case "datetime":
     fmktp=fmktp+"datetime,";
     fmklen=fmklen+",";
     break;
     case "Datetime":
     fmktp=fmktp+"datetime,";
     fmklen=fmklen+",";
     break;
     case "string":
     fmktp=fmktp+"varchar,";
     fmklen=fmklen+"100,";
     break;
     case "String":
     fmktp=fmktp+"varchar,";
     fmklen=fmklen+"100,";
     break;
     case "Bool":
     fmktp=fmktp+"varchar,";
     fmklen=fmklen+"6,";
     break;
     case "bool":
     fmktp=fmktp+"varchar,";
     fmklen=fmklen+"6,";
     break;
     default:
     fmktp=fmktp+"varchar,";
     fmklen=fmklen+"100,";         
     }
   }else{
   }
 }
 n=ajaxhtmlpost("/DNA/EXF/anyfuns.php?fid=rcvtborg","tbnm="+tbnm+"&tbtt="+tbtt+"&fmknm="+fmknm+"&fmktp="+fmktp+"&fmklen="+fmklen+"&fmkstt="+fmkstt);
 return n;
}
function strengthdata(stid,tbtt,tbdt){
 tbct=tbdt.metaData.fields.length;
 fmknm="";
 fmktt="";
 fmktp="";
 fmklen="";
 fmkstt="";
 for (i=0;i<tbct;i++){
   knm=tbdt.metaData.fields[i].name;
   ktp=tbdt.metaData.fields[i].type;   
     fmknm=fmknm+knm+",";
     fmktt=fmktt+",";
     fmkstt=fmkstt+"1,";
     switch (ktp){
     case "int":
     fmktp=fmktp+"int,";
     fmklen=fmklen+"11,";
     break;
     case "Int":
     fmktp=fmktp+"int,";
     fmklen=fmklen+"11,";
     break;
     case "float":
     fmktp=fmktp+"decimal,";
     fmklen=fmklen+",";
     break;
     case "Float":
     fmktp=fmktp+"decimal,";
     fmklen=fmklen+",";
     break;
     case "date":
     kfmt=tbdt.metaData.fields[i].dateFormat;
     if (kfmt=="Y-m-d H:i:s.u"){
       fmktp=fmktp+"datetime,";
     }else{
       fmktp=fmktp+"date,";
     }
     fmklen=fmklen+",";
     break;
     case "Date":
     kfmt=tbdt.metaData.fields[i].dateFormat;     
     if (kfmt=="Y-m-d H:i:s.u"){
       fmktp=fmktp+"datetime,";
     }else{
       fmktp=fmktp+"date,";
     }
     fmklen=fmklen+",";
     break;
     case "datetime":
     fmktp=fmktp+"datetime,";
     fmklen=fmklen+",";
     break;
     case "Datetime":
     fmktp=fmktp+"datetime,";
     fmklen=fmklen+",";
     break;
     case "string":
     fmktp=fmktp+"varchar,";
     fmklen=fmklen+"100,";
     break;
     case "String":
     fmktp=fmktp+"varchar,";
     fmklen=fmklen+"100,";
     break;
     case "Bool":
     fmktp=fmktp+"varchar,";
     fmklen=fmklen+"6,";
     break;
     case "bool":
     fmktp=fmktp+"varchar,";
     fmklen=fmklen+"6,";
     break;
     default:
     fmktp=fmktp+"varchar,";
     fmklen=fmklen+"100,";         
     }
 }
 datarow=tbdt.rows;
 totdt=datarow.length;
 fmv="";
 for (j=0;j<totdt;j++){   
   for (i=0;i<tbct-1;i++){
     tmpkv="";
     eval("tmpkv=datarow[j]."+tbdt.metaData.fields[i].name);
     fmv=fmv+tmpkv+"#-#";
   }
     tmpkv="";
     eval("tmpkv=datarow[j]."+tbdt.metaData.fields[tbct-1].name);
     fmv=fmv+tmpkv;
     fmv=fmv+"#/#";
  }
 n=ajaxhtmlpost("/DNA/EXF/anyfuns.php?fid=massrcv","stid="+stid+"&tbtt="+tbtt+"&fmknm="+fmknm+"&fmktp="+fmktp+"&fmklen="+fmklen+"&fmkstt="+fmkstt+"&massval="+mkstr(fmv));
 return n;
}