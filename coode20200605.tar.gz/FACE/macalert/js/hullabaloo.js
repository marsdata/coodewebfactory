/**
 * hullabaloo v 0.3
 *
 */
(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    define(['buoy'], factory(root));
  } else if (typeof exports === 'object') {
    module.exports = factory(require('buoy'));
  } else {
    root.hullabaloo = factory(root, root.buoy);
  }
})(typeof global !== 'undefined' ? global : this.window || this.global, function(root) {
  var init = function(root) {

    var hullabaloo = function() {
      // 袨斜褗械泻褌 褋芯蟹写邪胁邪械屑褘泄 褋械泄褔邪褋.
      // 谐械薪械褉懈褉褍械褌褋褟 胁 this.generate()
      this.hullabaloo = {};

      // 袦邪褋褋懈胁 褋 芯斜褗械泻褌邪屑懈 邪泻褌懈胁薪褘褏 邪谢械褉褌芯胁
      this.hullabaloos = [];

      this.success = false;

      // 袛芯锌芯谢薪懈褌械谢褜薪褘械 薪邪褋褌褉芯泄泻懈 写褟谢 邪谢械褉褌邪
      this.options = {
        ele: "body",
        offset: {
          from: "top",
          amount: 20
        },
        align: "right",
        width: 250,
        delay: 5000,
        allow_dismiss: true,
        stackup_spacing: 10,
        text: "袩褉芯懈蟹芯褕谢邪 薪械懈蟹胁械褋褌薪邪褟 芯褕懈斜泻邪.",
        icon: {
          success: "fa fa-check-circle",
          info: "fa fa-info-circle",
          warning: "fa fa-life-ring",
          danger: "fa fa-exclamation-circle",
          light: "fa fa-sun",
          dark: "fa fa-moon"
        },
        status: "danger",
        alertClass: "", // 袛芯锌芯谢薪懈褌械谢褜薪褘械 泻谢邪褋褋 写谢褟 斜谢芯泻邪 邪谢械褉褌邪
        fnStart: false, // 肖-懈褟 斜褍写械褌 胁褘锌芯谢薪褟褌褜褋褟 锌褉懈 褋褌邪褉褌械
        fnEnd: false, // 肖-懈褟 斜褍写械褌 胁褘锌芯谢薪褟褌褜褋褟 锌芯 蟹邪胁械褉褕懈薪懈褞
        fnEndHide: false, // 肖-懈褟 斜褍写械褌 胁褘锌芯谢薪褟褌褜褋褟 锌芯褋谢械 蟹邪泻褉褘褌懈褟 褋芯芯斜褖械薪懈褟

      };
    };

    // 袙褘胁芯写懈屑 褋芯芯斜褖械薪懈械
    hullabaloo.prototype.send = function(text, status) {
      // 袟邪锌褍褋褌懈屑 褎褍薪泻褑懈褞 锌褉懈 褋褌邪褉褌械
      if (typeof this.options.fnStart == "function")
        this.options.fnStart();

      // 小褋褘谢泻邪 薪邪 芯斜褗械泻褌
      var self = this;
      // 肖谢邪谐 写谢褟 芯斜芯蟹薪邪褔械薪懈械 褔褌芯 薪邪泄写械薪薪邪 谐褉褍锌锌邪 芯写懈薪邪泻芯胁褘褏 邪谢械褉褌芯胁
      var flag = 1;
      // 小褔械褌褔懈泻 写谢褟 锌械褉械斜芯褉泻懈 胁褋械褏 邪谢械褉褌芯胁. 袩芯懈褋泻 芯写懈薪邪泻芯胁褘褏
      var i = +this.hullabaloos.length - 1;
      // 袚谢邪胁薪褘泄 邪谢械褉褌邪 械褋谢懈 褍卸械 械褋褌褜 褌邪泻懈械 卸械 邪谢械褉褌褘
      var parent;

      // 小谐械薪械褉懈褉褍械屑 褋芯芯斜褖械薪懈械
      var hullabaloo = this.generate(text, status);

      // 袩褉芯胁械褉懈屑 薪械褌 谢懈 褍卸械 褌邪泻懈褏 卸械 褋芯芯斜褖械薪懈泄
      if (this.hullabaloos.length) {
        // 袩褉芯泄写械屑 写芯 泻芯薪褑邪 屑邪褋褋懈胁邪 邪谢械褉褌芯胁, 锌芯泻邪 薪械 薪邪泄写械屑 褋芯胁锌邪写械薪懈械
        while (i >= 0 && flag) {
          // 袝褋谢懈 褍 薪邪褋 锌褉懈褋褍褌褋褌胁褍褞褌 芯写懈薪邪泻芯胁褘械 褋芯芯斜褖械薪懈褟 (褋谐褉褍锌锌懈褉褍械屑 懈褏)
          if (this.hullabaloos[i].text == hullabaloo.text && this.hullabaloos[i].status == hullabaloo.status) {
            // 袟邪锌芯屑薪懈屑 谐谢邪胁薪褘泄 邪谢械褉褌
            parent = this.hullabaloos[i];
            // 肖谢邪谐 胁褘褏芯写邪 懈蟹 褑懈泻谢邪
            flag = 0;

            // 袩械褉械屑械褋褌懈屑 薪邪褕 邪谢械褉褌 薪邪 屑械褋褌芯 谐谢邪薪芯谐芯 褋芯 褋屑械褖械薪懈械屑
            hullabaloo.elem.css(this.options.offset.from, parseInt(parent.elem.css(this.options.offset.from)) + 4);
            hullabaloo.elem.css(this.options.align, parseInt(parent.elem.css(this.options.align)) + 4);
          }
          i--;
        }
      }

      // 袩褉芯胁械褉褟械屑, 谐褉褍锌锌邪 邪谢械褉褌芯胁 褍 薪邪褋 懈谢懈 褌芯谢褜泻芯 芯写懈薪
      if (typeof parent == 'object') {
        // 袝褋谢懈 邪谢械褉褌 胁 谐褉褍锌锌械 褌芯 写芯斜邪胁懈屑 械谐芯 胁 谐褉褍锌锌褍 懈 芯斜薪褍谢懈屑 褋褔械褌褔懈泻 谐褉褍锌锌褘
        clearTimeout(parent.timer);
        // 袟邪写邪写懈屑 薪芯胁褘泄 褋褔械褌褔懈泻 写谢褟 谐褉褍锌锌褘
        parent.timer = setTimeout(function() {
          self.closed(parent);
        }, this.options.delay);
        hullabaloo.parent = parent;
        // 锌褉懈褋胁芯懈屑 薪邪褕 邪谢械褉褌 胁 谐褉褍锌锌褍 泻 褉芯写懈褌械谢褞
        parent.hullabalooGroup.push(hullabaloo);
        // 袝褋谢懈 邪谢械褉 芯写懈薪
      } else {
        // 袟邪锌芯屑薪懈屑 锌芯蟹懈褑懈褞 邪谢械褉褌邪, 锌芯薪邪写芯斜懈褌褜褋褟 写谢褟 锌械褉械屑械褖械薪懈褟 邪谢械褉褌芯胁 胁胁械褉褏
        hullabaloo.position = parseInt(hullabaloo.elem.css(this.options.offset.from));

        // 袗泻褌懈胁懈褉褍械屑 褌邪泄屑械褉
        hullabaloo.timer = setTimeout(function() {
          self.closed(hullabaloo);
        }, this.options.delay);
        // 袛芯斜邪胁懈屑 邪谢械褉褌 胁 芯斜褖懈泄 屑邪褋褋懈胁 邪谢械褉褌芯胁
        this.hullabaloos.push(hullabaloo);
      }

      // 袩芯泻邪卸械屑 邪谢械褉褌 锌芯谢褜蟹芯胁邪褌械谢褞
      hullabaloo.elem.fadeIn();

      // 袟邪锌褍褋褌懈屑 褎褍薪泻褑懈褞 锌芯 蟹邪胁械褉褕械薪懈褟
      if (typeof this.options.fnEnd == "function")
        this.options.fnEnd();
    }

    // 袟邪泻褉褘胁邪械褌 邪谢械褉褌
    hullabaloo.prototype.closed = function(hullabaloo) {
      var self = this;
      var idx, i, move, next;

      if("parent" in hullabaloo){
        hullabaloo = hullabaloo.parent;
      }

      // 锌褉芯胁械褉褟械屑 械褋褌褜 谢懈 屑邪褋褋懈胁 褋 邪谢械褉褌邪屑懈
      if (this.hullabaloos !== null) {
        // 袧邪泄写械屑 胁 屑邪褋褋懈胁械 蟹邪泻褉褘胁邪械屑褘泄 邪谢械褉褌
        idx = $.inArray(hullabaloo, this.hullabaloos);
        if(idx == -1) return;

        // 袝褋谢懈 褝褌芯 谐褉褍锌邪 邪谢械褉褌芯胁, 褌芯 蟹邪泻褉芯械屑 胁褋械
        if (!!hullabaloo.hullabalooGroup && hullabaloo.hullabalooGroup.length) {
          for (i = 0; i < hullabaloo.hullabalooGroup.length; i++) {
            // 蟹邪泻褉褘褌褜 邪谢械褉褌
            $(hullabaloo.hullabalooGroup[i].elem).remove();
          }
        }

        // 袟邪泻褉褘胁邪械屑 薪邪褕 邪谢械褉褌
        $(this.hullabaloos[idx].elem).fadeOut("slow", function(){
          this.remove();
        });

        if (idx !== -1) {
          next = idx + 1;
          // 袝褋谢懈 胁 屑邪褋褋懈胁械 械褋褌褜 写褉褍谐懈械 邪谢械褉褌褘, 锌芯写薪懈屑械屑 懈褏 薪邪 屑械褋褌芯 蟹邪泻褉褘褌芯谐芯
          if (this.hullabaloos.length > 1 && next < this.hullabaloos.length) {
            // 袨褌薪懈屑邪械屑 胁械褉褏薪褞褞 谐褉邪薪懈蟹褍 蟹邪泻褉褘褌芯谐芯 邪谢械褉褌邪 芯褌 胁械褉褏薪械泄 谐褉邪薪懈褑褘 褋谢械写褍褞褖械谐芯 邪谢械褉褌邪
            // 懈 褉邪褋褔懈褌褘胁邪械屑 薪邪 褋泻芯谢褜泻芯 写胁懈谐邪褌褜 胁褋械 邪谢械褉褌褘
            move = this.hullabaloos[next].position - this.hullabaloos[idx].position;

            // 写胁懈谐邪械屑 胁褋械 邪谢械褉褌褘, 泻芯褌芯褉褘械 懈写褍褌 蟹邪 蟹邪泻褉褘褌褘屑
            for (i = idx; i < this.hullabaloos.length; i++) {
              this.animate(self.hullabaloos[i], parseInt(self.hullabaloos[i].position) - move);
              self.hullabaloos[i].position = parseInt(self.hullabaloos[i].position) - move
            }
          }

          // 校写邪谢懈屑 蟹邪泻褉褘褌褘泄 邪谢械褉褌 懈蟹 屑邪褋褋懈胁邪 褋 邪谢械褉褌邪屑懈
          this.hullabaloos.splice(idx, 1);

          // 袟邪锌褍褋褌懈屑 褎褍薪泻褑懈褞 锌芯褋谢械 蟹邪泻褉褘褌懈褟 褋芯芯斜褖械薪懈褟
          if (typeof this.options.fnEndHide == "function")
            this.options.fnEndHide();
        }
      }
    }


    // 袗薪懈屑邪褑懈褟 写谢褟 锌芯写褗械屑邪 邪谢械褉褌芯胁 胁胁械褉褏
    hullabaloo.prototype.animate = function(hullabaloo, move) {
      var self = this;
      var timer,
        position, // 袙械褉褏 邪谢械褉褌邪, 泻芯褌芯褉褘泄 褌邪褖懈屑
        i, // 小褔械褌褔懈泻 写谢褟 锌械褉械斜芯褉邪 谐褉褍锌锌褘 邪谢械褉褌芯胁
        group = 0; // 袨斜芯蟹薪邪褔械薪懈械, 谐褉褍锌锌邪 邪谢械褉褌芯胁 懈谢懈 芯写懈薪芯褔薪褘泄

      // 袙械褉褏 / 袧懈蟹 邪谢械褉褌邪, 泻芯褌芯褉褘泄 褌邪褖懈屑
      position = parseInt(hullabaloo.elem.css(self.options.offset.from));
      // 袝褋谢懈 褝褌芯 谐褉褍锌锌邪 邪谢械褉褌芯胁
      group = hullabaloo.hullabalooGroup.length;

      // 袟邪锌褍褋褌懈屑 褌邪泄屑械褉
      timer = setInterval(frame, 2);
      // 肖-懈褟 写谢褟 褌邪泄屑械褉邪
      function frame() {
        if (position == move) {
          clearInterval(timer);
        } else {
          position--;
          hullabaloo.elem.css(self.options.offset.from, position);

          // 袝褋谢懈 褝褌芯 谐褉褍锌锌邪 邪谢械褉褌芯胁
          if (group) {
            for (i = 0; i < group; i++) {
              hullabaloo.hullabalooGroup[i].elem.css(self.options.offset.from, position + 5);
            }
          }
        }
      }
    }


    // 袚械薪械褉邪褑懈褟 邪谢械褉褌邪 薪邪 褋褌褉邪薪懈褑械
    hullabaloo.prototype.generate = function(text, status) {
      var alertsObj = {
        icon: "", // 袠泻芯薪泻邪
        status: status || this.options.status, // 小褌邪褌褍褋
        text: text || this.options.text, // 孝械泻褌
        elem: $("<div>"), // HTML 泻芯写 褋邪屑芯谐芯 邪谢械褉褌邪

        // 袚褉褍锌锌懈褉芯胁泻邪 芯写懈薪邪泻芯胁褘褏 邪谢械褉褌芯胁
        hullabalooGroup: []
      };
      var option, // 袧邪褋褌褉芯泄泻懈 邪谢械褉褌邪
          offsetAmount, // 袨褌褋褌褍锌褘 邪谢械褉褌邪
          css; // CSS 褋胁芯泄褋褌胁邪 邪谢械褉褌邪
          self = this;

      option = this.options;

      // 袛芯斜邪胁懈屑 写芯锌芯谢薪懈褌械谢褜薪褘泄 泻谢邪褋褋
      alertsObj.elem.attr("class", "hullabaloo alert "+option.alertClass);

      // 小褌邪褌褍褋
      alertsObj.elem.addClass("alert-" + alertsObj.status);

      // 袣薪芯锌泻邪 蟹邪泻褉褘褌懈褟 褋芯芯斜褖械薪懈褟
      if (option.allow_dismiss) {
        alertsObj.elem.addClass("alert-dismissible");
        alertsObj.elem.append("<button class=\"close\" type=\"button\" id=\"hullabalooClose\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>");
        $( "#hullabalooClose", $(alertsObj.elem) ).bind( "click", function(){
          self.closed(alertsObj);
        });
      }

      // Icon
      switch (alertsObj.status) {
        case "success":
          alertsObj.icon = option.icon.success;
          break;
        case "info":
          alertsObj.icon = option.icon.info;
          break;
        case "danger":
          alertsObj.icon = option.icon.danger;
          break;
        case "light":
          alertsObj.icon = option.icon.light;
          break;
        case "dark":
          alertsObj.icon = option.icon.dark;
          break;
        default:
          alertsObj.icon = option.icon.warning;
      }

      // 袛芯斜邪胁懈屑 褌械泻褋褌 胁 褋芯芯斜褖械薪懈械
      alertsObj.elem.append("<i class=\"" + alertsObj.icon + "\"></i> " + alertsObj.text);

      // 袩褉懈褋胁芯懈屑 芯褌褋褌褍锌 芯褌 胁械褉褏邪
      offsetAmount = option.offset.amount;
      // 袝褋谢懈 械褋褌褜 写褉褍谐懈械 邪谢械褉褌褘 褌芯 锌褉懈斜邪胁懈屑 泻 芯褌褋褌褍锌褍 懈褏 胁褘褋芯褌褍
      $(".hullabaloo").each(function() {
        return offsetAmount = Math.max(offsetAmount, parseInt($(this).css(option.offset.from)) + $(this).outerHeight() + option.stackup_spacing);
      });

      // 袛芯斜邪胁懈屑 CSS 褋褌懈谢懈
      css = {
        "position": (option.ele === "body" ? "fixed" : "absolute"),
        "margin": 0,
        "z-index": "9999",
        "display": "none"
      };
      css[option.offset.from] = offsetAmount + "px";
      alertsObj.elem.css(css);

      if (option.width !== "auto") {
        alertsObj.elem.css("width", option.width + "px");
      }
      $(option.ele).append(alertsObj.elem);
      switch (option.align) {
        case "center":
          alertsObj.elem.css({
            "left": "50%",
            "margin-left": "-" + (alertsObj.elem.outerWidth() / 2) + "px"
          });
          break;
        case "left":
          alertsObj.elem.css("left", "20px");
          break;
        default:
          alertsObj.elem.css("right", "20px");
      }

      return alertsObj;
    };

    return hullabaloo;
  };
  return init(root);
});