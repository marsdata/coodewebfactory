<?php
class coodetemplate{
 public function showval($strx){
  return $strx;
 }
 public function itemexc($xcode,$stid,$tabnm,$colnm,$snox,$coltt,$dttype,$dxtype,$tval,$cg,$dspl,$cls){
  $xcode=str_replace("[tabnm]",$tabnm,$xcode);
  $xcode=str_replace("[tablenm]",$tabnm,$xcode);
  $xcode=str_replace("[tablename]",$tabnm,$xcode);
  $xcode=str_replace("[stid]",$stid,$xcode);
  $xcode=str_replace("[shortid]",$stid,$xcode);  
  $xcode=str_replace("[key]",$colnm,$xcode);
  $xcode=str_replace("[cid]",$_COOKIE["cid"],$xcode);
  $xcode=str_replace("[uid]",$_COOKIE["uid"],$xcode);
  $xcode=str_replace("[gip]",getip(),$xcode);
  if ($coltt!=""){
   $xcode=str_replace("[title]",$coltt,$xcode);
  }else{
   $xcode=str_replace("[title]",$colnm,$xcode);
  }
  $xcode=str_replace("[SNO]",$snox,$xcode);
  $xcode=str_replace("[thissno]",$snox,$xcode);
  $xcode=str_replace("[datatype]",$dttype,$xcode);
  $xcode=str_replace("[dttp]",$dttype,$xcode);
  $xcode=str_replace("[dxtype]",$dxtype,$xcode);
  $xcode=str_replace("[thisvalue]",$this->showval($tval),$xcode);
  $xcode=str_replace("[class]",$cls,$xcode);
  if (intval($cg)==0){
    $xcode=str_replace("[changeable]","readonly",$xcode);
  }else{
    $xcode=str_replace("[changeable]","",$xcode);
  }
  if (intval($dspl)==0){
    $xcode=str_replace("[displayed]","displayed:none;",$xcode);
  }else{
    $xcode=str_replace("[displayed]","",$xcode);
  }
  return $xcode;
 }
 public function makeformitem($dxtype,$icode,$stid,$sttab,$colnm,$snox,$coltt,$dttype,$clstxt,$tval,$cg,$dspl){
      if (strpos("x".$icode,"function")>0 and strpos("x".$icode,"=(")>0){
          $funstr='$icode=turnlab('.qian(hou('x'.$icode,'function'),'{').');';
          eval($funstr);
      }else{
         $icode=$icode;
      }
      if ($icode!="" or strpos($icode,"thisvalue")>0){
       $icode=$this->itemexc($icode,$stid,$sttab,$colnm,$snox,$coltt,$dttype,$dxtype,$tval,$cg,$dspl,$hcdcls);
      }else{
       $icode=$this->showval($tval);  
      }
      return $icode;
 }
 public function makepagexyz($totye,$pg,$pgn,$allkillbtn,$totallrst,$tbnm,$sid,$pgsrd,$pgin,$pgout,$pgslcls){
   
  $pagesrd=turnlab($pgsrd);
  $pagein=turnlab($pgin);
  $pageout=turnlab($pgout);
  $nextfiv=intval($pg)+3;
  $prefiv=intval($pg)-3;  
  if ($prefiv<0){
    $startp=0;
  }else{
    $startp=$prefiv;
  }
  if ($nextfiv>$totye){
    $deliv=$totye;
  }else{
    $deliv=$nextfiv;
  }  
  $fmy="";
  $fmslct="";
  $fmslctb="";
  $xid="";
  $stid="";
  
  for ($t=0;$t<$totye;$t++){
   $fmslct=$fmslct.($t+1).",";
   $fmslctb=$fmslctb."第".($t+1)."页,";
  };
  if ($totye>0){
   $fmslct=substr($fmslct,0,strlen($fmslct)-1);
   $fmslctb=substr($fmslctb,0,strlen($fmslctb)-1);
  }; 
   $fmselect=formselect($fmslctb,$fmslct,$pg,"topage",$pgslcls,"onchange=\"tospage(document.getElementById('topage').value);\"");
   $fmselectjs=formselect($fmslctb,$fmslct,$pg,"topage",$pgslcls,"onchange=\"tospage(document.getElementById('topage').value);\"");
   $fmspage="显示10条/页,显示20条/页,显示25条/页,显示30条/页,显示50条/页,显示100条/页,显示150条/页,显示200条/页,显示250条/页,显示300条/页,显示500条/页,显示800条/页,显示1000条/页,显示所有";
   $fmbpage="10,20,25,30,50,100,150,200,250,300,500,800,1000,0";
   $fmpagejs=formselect($fmspage,$fmbpage,$pgn,"setpagenum",$pgslcls,"onchange=\"setpage(document.getElementById('setpagenum').value);\"");  
   
  for ($t=$startp;$t<$deliv;$t++){
      $demoin=$pagein;
      $demoout=$pageout;
   if ($pg==($t+1)){
       $demoin=str_replace("[page]",($t+1),$demoin);
       $demoin=str_replace("[pgtt]",($t+1),$demoin);
       $fmy=$fmy.$demoin;
   }else{
       $demoout=str_replace("[page]",($t+1),$demoout);
       $demoout=str_replace("[pgtt]",($t+1),$demoout);
       $fmy=$fmy.$demoout;      
   };
  };  
  if ($pg-1<1){
    $lstpg=1;
  }else{
    $lstpg=$pg-1;
  };
  if ($pg+1>$totye){
    $nxtpg=$totye;
  }else{
    $nxtpg=$pg+1;    
  };
  if (($allkillbtn*1)==0){
    $nodspl="style=\"display:none;\"";
  }
  $srddemo=$pagesrd;
  $srddemo=str_replace("[pagetot]",$totallrst,$srddemo);
  $srddemo=str_replace("[totye]",$totye,$srddemo);
  $srddemo=str_replace("[pgselect]",$fmselect,$srddemo);
  $srddemo=str_replace("[pginner]",$fmy,$srddemo);
  $srddemo=str_replace("[pgnum]",$fmpagejs,$srddemo);
  $srddemo=str_replace("[shownum]",$fmpagejs,$srddemo);
  $srddemo=str_replace("[lstpg]",($pg-1),$srddemo);
  $srddemo=str_replace("[nxtpg]",($pg+1),$srddemo);
  $srddemo=str_replace("[tabnm]",$tbnm,$srddemo);
  $srddemo=str_replace("[stid]",$sid,$srddemo);
  $srddemo=str_replace("[nodspl]",$nodspl,$srddemo);
 return $srddemo; 
 }
 public function maketablelist($stid,$pnum,$page,$cscode=array()){
        $strst=SX("select shorttitle,tablename,showkeys,cdt,ordcdt from coode_shortdata where shortid='".$stid."'");        
        $sttt=anyvalue($strst,"shorttitle",0);
        $sttab=anyvalue($strst,"tablename",0);
        $skeys=anyvalue($strst,"showkeys",0);
        $cdtx=anyvalue($strst,"cdt",0);
        $cdtx=str_replace("[uid]",$_COOKIE["uid"],$cdtx);
        $cdtx=str_replace("[cid]",$_COOKIE["cid"],$cdtx);
        $cdty=anyvalue($strst,"orddt",0);
        eval(RESFUNSET("formbase"));
        eval(RESFUNSET("keyfunbase"));
        $shortbase=array();
        $shortbase=shortinfo($xid,$shortbase);
        $diycode=$shortbase["diycode"];
        $addpage=$shortbase["addpage"];
        $addtitle=$shortbase["addtitle"];
        $sttbnm=$shortbase["tablename"];
        $shorttitle=$shortbase["shorttitle"];
        $updatepage=$shortbase["updatepage"];
        $detailpage=$shortbase["detailpage"];
        $additemx=$shortbase["additemx"];
        $newbutton=$shortbase["newbutton"];
        $obtn=$shortbase["obtn"];
        $vbtn=$shortbase["vbtn"];
        $xbtn=$shortbase["xbtn"];
        $oprtx=$shortbase["oprtx"];
        $headx=$shortbase["headx"];
        $allkillbtn=$shortbase["allkillbtn"];  
        $keyinfo=thekeyfun($keyinfo,glb(),$sttab,$skeys);      
        $pgcdt=" limit ".((intval($page)-1)*intval($pnum)).",".$pnum; 
        $flrst=selecteds($conn,glb(),"select ".$skeys." from ".$sttab." where ".$cdtx.$cdty.$pgcdt,"utf8","");   
        $totrst=countresult($flrst); 
        $sresult=arrdata($sresult,$flrst);
        $kpart=explode(",",$sresult["table"]["keys"]);
        $totk=count($kpart);
        $totrst=countresult($totrst);
        $fmtab="";
        $tabhdtr=$cscode["tabhdtr"];      
         $fmhead="";
         for ($ii=0;$ii<$totk;$ii++){
           $tmphddemo=$this->makeformitem($keyinfo[$kpart[$ii]]["COLUMN_DXTYPE"],$cscode["tabhdtd"],$stid,$sttab,$kpart[$ii],"0",$keyinfo[$kpart[$ii]]["COLUMN_TITLE"],$keyinfo[$kpart[$ii]]["COLUMN_TYPE"],$keyinfo[$kpart[$ii]]["COLUMN_CLSTXT"],"",$keyinfo[$kpart[$ii]]["COLUMN_CANGE"],$keyinfo[$kpart[$ii]]["COLUMN_DSPLD"]);
           $fmhead=$fmhead.$this->itemexc($tmphddemo,$stid,$sttab,$kpart[$ii],"",$keyinfo[$kpart[$ii]]["COLUMN_TITLE"],$keyinfo[$kpart[$ii]]["COLUMN_TYPE"],$keyinfo[$kpart[$ii]]["COLUMN_DXTYPE"],"",$keyinfo[$kpart[$ii]]["COLUMN_CANGE"],$keyinfo[$kpart[$ii]]["COLUMN_DSPLD"],"");
            $dxtpdemo =$cscode[$keyinfo[$kpart[$ii]]["COLUMN_DXTYPE"]];
            if (strpos($dxtpdemo,"unction")>0 and strpos($dxtpdemo,"=(")>0){
              eval($dxtpdemo);
            }//执行模板函数创建
         }  
        $dxtpdemo =$cscode["oprt"];
        if (strpos($dxtpdemo,"unction")>0 and strpos($dxtpdemo,"=(")>0){
           eval($dxtpdemo);
        }//执行模板函数创建
           $tmphddemo=$this->makeformitem("varchar",$cscode["tabhdtd"],$stid,$sttab,"OPRT","0",$keyinfo[$kpart[$ii]]["COLUMN_TITLE"],$keyinfo[$kpart[$ii]]["COLUMN_TYPE"],$keyinfo[$kpart[$ii]]["COLUMN_CLSTXT"],"",$keyinfo[$kpart[$ii]]["COLUMN_CANGE"],$keyinfo[$kpart[$ii]]["COLUMN_DSPLD"]);
           $fmhead=$fmhead.$this->itemexc($tmphddemo,$stid,$sttab,"OPRT",$sresult["SNO"][$jj],"操作","varchar",$oprtx,$obtn,$vbtn,$oxbtn,"");
           $tabhdtr=str_replace("[inner]",$fmhead,$tabhdtr);
         
        for ($jj=1;$jj<$totrst+1;$jj++){
         $trdemo=$cscode["tabtr"];
            for ($ii=0;$ii<$totk;$ii++){
             $_GET["key".hou($kpart[$ii],".")]=$sresult[hou($kpart[$ii],".")][$jj];//所以这个GET 有顺序的，在SHORTCLS引用前 最好让他没顺序
            }
            $fmrow="";
           for ($ii=0;$ii<$totk;$ii++){
             $tddemo=$cscode["tabtd"];
             $tddemo=$this->itemexc($tddemo,$stid,$sttab,$kpart[$ii],$sresult["SNO"][$jj],$keyinfo[$kpart[$ii]]["COLUMN_TITLE"],$keyinfo[$kpart[$ii]]["COLUMN_TYPE"],$keyinfo[$kpart[$ii]]["COLUMN_DXTYPE"],$sresult[$kpart[$ii]][$jj],$keyinfo[$kpart[$ii]]["COLUMN_CANGE"],$keyinfo[$kpart[$ii]]["COLUMN_DSPLD"],"");
             if (qian($keyinfo[$kpart[$ii]]["COLUMN_SSHOW"],"|")!=""){
               $valdemo=qian($keyinfo[$kpart[$ii]]["COLUMN_SSHOW"],"|");               
             }else{
               $valdemo=$cscode[$kpart[$ii]];
             }
             $valdemo=turnlab($valdemo);             
             $valdemo=$this->makeformitem($keyinfo[$kpart[$ii]]["COLUMN_DXTYPE"],$valdemo,$stid,$sttab,$kpart[$ii],$sresult["SNO"][$jj],$keyinfo[$kpart[$ii]]["COLUMN_TITLE"],$keyinfo[$kpart[$ii]]["COLUMN_TYPE"],$keyinfo[$kpart[$ii]]["COLUMN_CLSTXT"],$sresult[$kpart[$ii]][$jj],$keyinfo[$kpart[$ii]]["COLUMN_CANGE"],$keyinfo[$kpart[$ii]]["COLUMN_DSPLD"]);
             $tddemo=str_replace("[inner]",$valdemo,$tddemo);                          
             $fmrow=$fmrow.$tddemo;
           }
             $tddemo=$cscode["tabtd"];
             $tddemo=$this->itemexc($tddemo,$stid,$sttab,"OPRT",$sresult["SNO"][$jj],"操作","varchar","varchar","none","",$oprtx,"");
             $valdemo=$cscode["oprt"];
             $valdemo=turnlab($valdemo);             
             $valdemo=$this->itemexc($valdemo,$stid,$sttab,"OPRT",$sresult["SNO"][$jj],"操作","varchar",$oprtx,$obtn,$vbtn,$oxbtn,"");
             $tddemo=str_replace("[inner]",$valdemo,$tddemo);             
             $fmrow=$fmrow.$tddemo;
             $trdemo=str_replace("[inner]",$fmrow,$trdemo);
             $fmtab=$fmtab.$trdemo;
        }
        $formtable=$fmhead.$fmtab;
        $srd=$cscode["srd"];
        $srd=str_replace("[tabinner]",$formtable,$srd);
        $pagerst=$this->makepagexyz(intval($totrst)/intval($pnum),$page,$pnum,$allkillbtn,$totrst,$sttbnm,$stid,$cscode["pgsrd"],$cscode["pgin"],$cscode["pgout"],$cscode["pgslcls"]);
        $srd=str_replace("[pageinner]",$pagerst,$srd);
        return $srd;
 }
 public function maketempcode($ttype,$dmn,$dkey,$dval,$casecodex){        
 eval(RESFUNSET("democode"));
    switch($ttype){
     case "form":            
       $ccode["srd"]=getcodedemo("srd",$dmn,$dkey);
       return $ccode["srd"];       
     break;
     case "detail":
       $ccode["srd"]=getcodedemo("srd",$dmn,$dkey);
       return $ccode["srd"];       
     break;
     case "menu":
     return $ccode["srd"];       
     break;
     case "list":
        $ccode["content"]=getcodedemo("content",$dmn,$dkey);
        $ccode["searchdemo"]=getcodedemo("searchdemo",$dmn,$dkey);
        $ccode["srd"]=getcodedemo("srd",$dmn,$dkey);
        $allcode=$ccode["content"];
        $srdwithsc=str_replace("[searchdemo]",$ccode["searchdemo"],$ccode["srd"]);
        $allcode=str_replace("[shortdata]",$srdwithsc,$allcode);        
      return $allcode;
     break;
     default:
     $ccode["srd"]=getcodedemo("srd",$dmn,$dkey);
     return $ccode["srd"];       
    }
    
 }
 public function maketmpcdjsf($ttype,$dmx,$mky,$mkv,$casecodex){
        eval($casecodex);
          switch($ttype){
          case "form":
          
            if (strpos($mkv,".")>0){
             $stid=qian($mkv,".");
             $snox=hou($mkv,".");
            }else{
             $snox="0";
             $stid=$mkv;
            }                
            $stcssrst=SX("select jsfiles,cssfiles,scriptx,stylex from coode_shortcss where shortid='".$stid."DETAIL'");
            $totst=countresult($stcssrst);
            if ($totst>0){
            $jsfiles=anyvalue($stcssrst,"jsfiles",0);
            }else{
            $jsfiles="";
            }
            if ($jsfiles!=""){
              return $jsfiles;
            }else{
              return "";
            }
          
          break;
          case "detail":
          if ($mkv!=""){
            if (strpos($mkv,".")>0){
             $stid=qian($mkv,".");
             $snox=hou($mkv,".");
            }else{
             $snox="0";
             $stid=$mkv;
            }                
            $stcssrst=SX("select jsfiles,cssfiles,scriptx,stylex from coode_shortcss where shortid='".$stid."DETAIL'");
            $totst=countresult($stcssrst);
            if ($totst>0){
            $jsfiles=anyvalue($stcssrst,"jsfiles",0);
            }else{
            $jsfiles="";
            }
            if ($jsfiles!=""){
              return $jsfiles;
            }else{
              return "";
            }
          }
          break;
          case "menu":
          break;
          case "list":
          
            if (strpos($mkv,".")>0){
             $stid=qian($mkv,".");
             $snox=hou($mkv,".");
            }else{
             $snox="0";
             $stid=$mkv;
            }                
          
          break;
          default:
        }
        return "";   
 }
 public function maketmpcdcssf($ttype,$dmx,$mky,$mkv,$casecodex){
       eval($casecodex);
          switch($ttype){
          case "form":
          if ($mkv!=""){
            if (strpos($mkv,".")>0){
             $stid=qian($mkv,".");
             $snox=hou($mkv,".");
            }else{
             $snox="0";
             $stid=$mkv;
            }                
            $stcssrst=SX("select jsfiles,cssfiles,scriptx,stylex from coode_shortcss where shortid='".$stid."DETAIL'");
            $totst=countresult($stcssrst);
            if ($totst>0){
            $cssfiles=anyvalue($stcssrst,"cssfiles",0);
            }else{
            $cssfiles="";
            }
            if ($cssfiles!=""){
              return $cssfiles;
            }else{
              return "";
            }
          }
          break;
          case "detail":
          if ($mkv!=""){
            if (strpos($mkv,".")>0){
             $stid=qian($mkv,".");
             $snox=hou($mkv,".");
            }else{
             $snox="0";
             $stid=$mkv;
            }                
            $stcssrst=SX("select jsfiles,cssfiles,scriptx,stylex from coode_shortcss where shortid='".$stid."DETAIL'");
            $totst=countresult($stcssrst);
            if ($totst>0){
            $cssfiles=anyvalue($stcssrst,"cssfiles",0);
            }else{
            $cssfiles="";
            }
            if ($cssfiles!=""){
              return $cssfiles;
            }else{
              return "";
            }
          }
          break;
          case "menu":
          break;
          case "list":
          
            if (strpos($mkv,".")>0){
             $stid=qian($mkv,".");
             $snox=hou($mkv,".");
            }else{
             $snox="0";
             $stid=$mkv;
            }                
          
          break;
          default:
        }
        return "";
 }
 public function maketmpcdstlx($ttype,$dmx,$mky,$mkv,$casecodex){
      eval($casecodex);
       switch($ttype){
          case "form":
          if ($mkv!=""){
            if (strpos($mkv,".")>0){
             $stid=qian($mkv,".");
             $snox=hou($mkv,".");
            }else{
             $snox="0";
             $stid=$mkv;
            }                
            $stcssrst=SX("select jsfiles,cssfiles,scriptx,stylex from coode_shortcss where shortid='".$stid."DETAIL'");
            $totst=countresult($stcssrst);
            if ($totst>0){
            $stylex=anyvalue($stcssrst,"stylex",0);
            }else{
            $stylex="";
            }
            if ($stylex!=""){
              return $stylex;
            }else{
              return "";
            }
          }
          break;
          case "detail":
          if ($mkv!=""){
            if (strpos($mkv,".")>0){
             $stid=qian($mkv,".");
             $snox=hou($mkv,".");
            }else{
             $snox="0";
             $stid=$mkv;
            }                
            $stcssrst=SX("select jsfiles,cssfiles,scriptx,stylex from coode_shortcss where shortid='".$stid."DETAIL'");
            $totst=countresult($stcssrst);
            if ($totst>0){
            $stylex=anyvalue($stcssrst,"stylex",0);
            }else{
            $stylex="";
            }
            if ($stylex!=""){
              return $stylex;
            }else{
              return "";
            }
          }
          break;
          case "menu":
          break;
          case "list":
          
            if (strpos($mkv,".")>0){
             $stid=qian($mkv,".");
             $snox=hou($mkv,".");
            }else{
             $snox="0";
             $stid=$mkv;
            }                
          
          break;
          default:
        }
        return "";
 }
 public function maketmpcdscptx($ttype,$dmx,$mky,$mkv,$casecodex){
     eval($casecodex);
     eval(RESFUNSET("keyfunbase"));
         switch($ttype){
          case "form":          
            if (strpos($mkv,".")>0){
             $stid=qian($mkv,".");
             $snox=hou($mkv,".");
            }else{
             $snox="0";
             $stid=$mkv;
            }                
            $stcssrst=SX("select jsfiles,cssfiles,scriptx,stylex,diytop,diybottom from coode_shortcss where shortid='".$stid."DETAIL'");
            $totst=countresult($stcssrst);
            if ($totst>0){
             $scriptx=anyvalue($stcssrst,"scriptx",0);
            }else{
             $scriptx="";
            }
            
            $scriptz=$scriptz.'ccode=new Array();'.huanhang();
            $scriptz=$scriptz.'ccode["srd"]="'.str_replace("\"","\\\"",killrn($ccode["srd"])).'";'.huanhang();
            if (strpos($ccode["srd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["srd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["diytop"]="'.str_replace("\"","\\\"",killrn(labturn(tostring(anyvalue($stcssrst,"diytop",0))))).'";'.huanhang();
            
            if (strpos(tostring(anyvalue($stcssrst,"diytop",0)),"unction ")>0){
              $scriptz=$scriptz.tostring(anyvalue($stcssrst,"diytop",0)).huanhang();
            }
            $scriptz=$scriptz.'ccode["diybottom"]="'.str_replace("\"","\\\"",killrn(labturn(tostring(anyvalue($stcssrst,"diybottom",0))))).'";'.huanhang();
            if (strpos(tostring(anyvalue($stcssrst,"diybottom",0)),"unction ")>0){
              $scriptz=$scriptz.tostring(anyvalue($stcssrst,"diybottom",0)).huanhang();
            }
            $scriptz=$scriptz.'ccode["chtml"]="'.str_replace("\"","\\\"",killrn($ccode["chtml"])).'";'.huanhang();
            if (strpos($ccode["chtml"],"unction ")>0){
              $scriptz=$scriptz.$ccode["chtml"].huanhang();
            }
            $scriptz=$scriptz.'ccode["itemsrd"]="'.str_replace("\"","\\\"",killrn($ccode["itemsrd"])).'";'.huanhang();
            if (strpos($ccode["itemsrd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["itemsrd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["inline"]="'.str_replace("\"","\\\"",killrn($ccode["inline"])).'";'.huanhang();
            if (strpos($ccode["inline"],"unction ")>0){
              $scriptz=$scriptz.$ccode["inline"].huanhang();
            }
            $scriptz=$scriptz.'ccode["varchar"]="'.str_replace("\"","\\\"",killrn($ccode["varchar"])).'";'.huanhang();
            if (strpos($ccode["varchar"],"unction ")>0){
              $scriptz=$scriptz.$ccode["varchar"].huanhang();
            }
            $scriptz=$scriptz.'ccode["text"]="'.str_replace("\"","\\\"",killrn($ccode["text"])).'";'.huanhang();
            if (strpos($ccode["text"],"unction ")>0){
              $scriptz=$scriptz.$ccode["text"].huanhang();
            }
            $scriptz=$scriptz.'ccode["richtext"]="'.str_replace("\"","\\\"",killrn($ccode["richtext"])).'";'.huanhang();
            if (strpos($ccode["richtext"],"unction ")>0){
              $scriptz=$scriptz.$ccode["richtext"].huanhang();
            }
            $scriptz=$scriptz.'ccode["code"]="'.str_replace("\"","\\\"",killrn($ccode["code"])).'";'.huanhang();
            if (strpos($ccode["code"],"unction ")>0){
              $scriptz=$scriptz.$ccode["code"].huanhang();
            }
            $scriptz=$scriptz.'ccode["select"]="'.str_replace("\"","\\\"",killrn($ccode["select"])).'";'.huanhang();
            if (strpos($ccode["select"],"unction ")>0){
              $scriptz=$scriptz.$ccode["select"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multiselect"]="'.str_replace("\"","\\\"",killrn($ccode["multiselect"])).'";'.huanhang();
            if (strpos($ccode["multiselect"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiselect"].huanhang();
            }
            $scriptz=$scriptz.'ccode["date"]="'.str_replace("\"","\\\"",killrn($ccode["date"])).'";'.huanhang();
            if (strpos($ccode["date"],"unction ")>0){
              $scriptz=$scriptz.$ccode["date"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetime"]="'.str_replace("\"","\\\"",killrn($ccode["datetime"])).'";'.huanhang();
            if (strpos($ccode["datetime"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetime"].huanhang();
            }
            $scriptz=$scriptz.'ccode["int"]="'.str_replace("\"","\\\"",killrn($ccode["int"])).'";'.huanhang();
            if (strpos($ccode["int"],"unction ")>0){
              $scriptz=$scriptz.$ccode["int"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tinyint"]="'.str_replace("\"","\\\"",killrn($ccode["tinyint"])).'";'.huanhang();
            if (strpos($ccode["tinyint"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tinyint"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal1"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1"])).'";'.huanhang();
            if (strpos($ccode["decimal1"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal1"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal2"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2"])).'";'.huanhang();
            if (strpos($ccode["decimal2"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal2"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal3"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3"])).'";'.huanhang();
            if (strpos($ccode["decimal3"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal3"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal4"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4"])).'";'.huanhang();
            if (strpos($ccode["decimal4"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal4"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagex"]="'.str_replace("\"","\\\"",killrn($ccode["imagex"])).'";'.huanhang();
            if (strpos($ccode["imagex"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagex"].huanhang();
            }
            $scriptz=$scriptz.'ccode["images"]="'.str_replace("\"","\\\"",killrn($ccode["images"])).'";'.huanhang();
            if (strpos($ccode["images"],"unction ")>0){
              $scriptz=$scriptz.$ccode["images"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filex"]="'.str_replace("\"","\\\"",killrn($ccode["filex"])).'";'.huanhang();
            if (strpos($ccode["filex"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filex"].huanhang();
            }
            $scriptz=$scriptz.'ccode["files"]="'.str_replace("\"","\\\"",killrn($ccode["files"])).'";'.huanhang();
            if (strpos($ccode["files"],"unction ")>0){
              $scriptz=$scriptz.$ccode["files"].huanhang();
            }
            $scriptz=$scriptz.'ccode["check"]="'.str_replace("\"","\\\"",killrn($ccode["check"])).'";'.huanhang();
            if (strpos($ccode["check"],"unction ")>0){
              $scriptz=$scriptz.$ccode["check"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multicheck"]="'.str_replace("\"","\\\"",killrn($ccode["multicheck"])).'";'.huanhang();
            if (strpos($ccode["multicheck"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multicheck"].huanhang();
            }
            $scriptz=$scriptz.'ccode["varcharSRD"]="'.str_replace("\"","\\\"",killrn($ccode["varcharSRD"])).'";'.huanhang();
            if (strpos($ccode["varcharSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["varcharSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["textSRD"]="'.str_replace("\"","\\\"",killrn($ccode["textSRD"])).'";'.huanhang();
            if (strpos($ccode["textSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["textSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["richtextSRD"]="'.str_replace("\"","\\\"",killrn($ccode["richtextSRD"])).'";'.huanhang();
            if (strpos($ccode["richtextSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["richtextSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["codeSRD"]="'.str_replace("\"","\\\"",killrn($ccode["codeSRD"])).'";'.huanhang();
            if (strpos($ccode["codeSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["codeSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["selectSRD"]="'.str_replace("\"","\\\"",killrn($ccode["selectSRD"])).'";'.huanhang();
            if (strpos($ccode["selectSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["selectSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multiselectSRD"]="'.str_replace("\"","\\\"",killrn($ccode["multiselectSRD"])).'";'.huanhang();
            if (strpos($ccode["multiselectSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiselectSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["dateSRD"]="'.str_replace("\"","\\\"",killrn($ccode["dateSRD"])).'";'.huanhang();
            if (strpos($ccode["dateSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["dateSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetimeSRD"]="'.str_replace("\"","\\\"",killrn($ccode["datetimeSRD"])).'";'.huanhang();
            if (strpos($ccode["datetimeSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetimeSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["intSRD"]="'.str_replace("\"","\\\"",killrn($ccode["intSRD"])).'";'.huanhang();
            if (strpos($ccode["intSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["intSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tinyintSRD"]="'.str_replace("\"","\\\"",killrn($ccode["tinyintSRD"])).'";'.huanhang();
            if (strpos($ccode["tinyintSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tinyintSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal1SRD"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1SRD"])).'";'.huanhang();
            if (strpos($ccode["decimal1SRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal1SRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal2SRD"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2SRD"])).'";'.huanhang();
            if (strpos($ccode["decimal2SRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal2SRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal3SRD"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3SRD"])).'";'.huanhang();
            if (strpos($ccode["decimal3SRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal3SRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal4SRD"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4SRD"])).'";'.huanhang();
            if (strpos($ccode["decimal4SRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal4SRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagexSRD"]="'.str_replace("\"","\\\"",killrn($ccode["imagexSRD"])).'";'.huanhang();
            if (strpos($ccode["imagexSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagexSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagesSRD"]="'.str_replace("\"","\\\"",killrn($ccode["imagesSRD"])).'";'.huanhang();
            if (strpos($ccode["imagesSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagesSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filexSRD"]="'.str_replace("\"","\\\"",killrn($ccode["filexSRD"])).'";'.huanhang();
            if (strpos($ccode["filexSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filexSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filesSRD"]="'.str_replace("\"","\\\"",killrn($ccode["filesSRD"])).'";'.huanhang();
            if (strpos($ccode["filesSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filesSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["checkSRD"]="'.str_replace("\"","\\\"",killrn($ccode["checkSRD"])).'";'.huanhang();
            if (strpos($ccode["checkSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["checkSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multicheckSRD"]="'.str_replace("\"","\\\"",killrn($ccode["multicheckSRD"])).'";'.huanhang();
            if (strpos($ccode["multicheckSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multicheckSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["varcharINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["varcharINLINE"])).'";'.huanhang();
            if (strpos($ccode["varcharINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["varcharINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["textINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["textINLINE"])).'";'.huanhang();
            if (strpos($ccode["textINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["textINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["richtextINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["richtextINLINE"])).'";'.huanhang();
            if (strpos($ccode["richtextINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["richtextINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["codeINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["codeINLINE"])).'";'.huanhang();
            if (strpos($ccode["codeINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["codeINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["selectINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["selectINLINE"])).'";'.huanhang();
            if (strpos($ccode["selectINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["selectINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multiselectINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["multiselectINLINE"])).'";'.huanhang();
            if (strpos($ccode["multiselectINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiselectINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["dateINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["dateINLINE"])).'";'.huanhang();
            if (strpos($ccode["dateINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["dateINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetimeINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["datetimeINLINE"])).'";'.huanhang();
            if (strpos($ccode["datetimeINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetimeINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["intINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["intINLINE"])).'";'.huanhang();
            if (strpos($ccode["intINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["intINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tinyintINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["tinyintINLINE"])).'";'.huanhang();
            if (strpos($ccode["tinyintINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tinyintINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal1INLINE"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1INLINE"])).'";'.huanhang();
            if (strpos($ccode["decimal1INLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal1INLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal2INLINE"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2INLINE"])).'";'.huanhang();
            if (strpos($ccode["decimal2INLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal2INLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal3INLINE"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3INLINE"])).'";'.huanhang();
            if (strpos($ccode["decimal3INLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal3INLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal4INLINE"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4INLINE"])).'";'.huanhang();
            if (strpos($ccode["decimal4INLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal4INLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagexINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["imagexINLINE"])).'";'.huanhang();
            if (strpos($ccode["imagexINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagexINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagesINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["imagesINLINE"])).'";'.huanhang();
            if (strpos($ccode["imagesINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagesINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filexINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["filexINLINE"])).'";'.huanhang();
            if (strpos($ccode["filexINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filexINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filesINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["filesINLINE"])).'";'.huanhang();
            if (strpos($ccode["filesINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filesINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["checkINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["checkINLINE"])).'";'.huanhang();
            if (strpos($ccode["INLINEINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["INLINEINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multicheckINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["multicheckINLINE"])).'";'.huanhang();
            if (strpos($ccode["multiINLINEINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiINLINEINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["onerow"]="'.str_replace("\"","\\\"",killrn($ccode["onerow"])).'";'.huanhang();
            if (strpos($ccode["onerow"],"unction ")>0){
              $scriptz=$scriptz.$ccode["onerow"].huanhang();
            }
            $scriptz=$scriptz.'ccode["duorow"]="'.str_replace("\"","\\\"",killrn($ccode["duorow"])).'";'.huanhang();
            if (strpos($ccode["duorow"],"unction ")>0){
              $scriptz=$scriptz.$ccode["duorow"].huanhang();
            }
            $scriptz=$scriptz.'ccode["varcharFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["varcharFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["textFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["textFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["richtextFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["richtextFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["codeFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["codeFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["selectFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["selectFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["multiselectFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["multiselectFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["dateFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["dateFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["datetimeFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["datetimeFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["intFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["tinyintFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["tinyintFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["intFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal1FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal2FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal3FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal4FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["imagexFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["imagexFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["imagesFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["imagesFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["filexFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["filexFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["filesFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["filesFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["checkFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["checkFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["checkduoFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["checkduoFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["multicheckFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["multicheckFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["duorowFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["duorowFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["srdFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["srdFUNCTION"])).'";'.huanhang();
            
            
            if ($scriptx.$scriptz!=""){
              return $scriptx.$scriptz;
            }else{
              return "";
            }          
          break;
         case "Mform":          
            if (strpos($mkv,".")>0){
             $stid=qian($mkv,".");
             $snox=hou($mkv,".");
            }else{
             $snox="0";
             $stid=$mkv;
            }                
            $stcssrst=SX("select jsfiles,cssfiles,scriptx,stylex,diytop,diybottom from coode_shortcss where shortid='".$stid."DETAIL'");
            $totst=countresult($stcssrst);
            if ($totst>0){
             $scriptx=anyvalue($stcssrst,"scriptx",0);
            }else{
             $scriptx="";
            }
            
            $scriptz=$scriptz.'ccode=new Array();'.huanhang();
            $scriptz=$scriptz.'ccode["srd"]="'.str_replace("\"","\\\"",killrn($ccode["srd"])).'";'.huanhang();
            if (strpos($ccode["srd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["srd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["diytop"]="'.str_replace("\"","\\\"",killrn(labturn(tostring(anyvalue($stcssrst,"diytop",0))))).'";'.huanhang();
            
            if (strpos(tostring(anyvalue($stcssrst,"diytop",0)),"unction ")>0){
              $scriptz=$scriptz.tostring(anyvalue($stcssrst,"diytop",0)).huanhang();
            }
            $scriptz=$scriptz.'ccode["diybottom"]="'.str_replace("\"","\\\"",killrn(labturn(tostring(anyvalue($stcssrst,"diybottom",0))))).'";'.huanhang();
            if (strpos(tostring(anyvalue($stcssrst,"diybottom",0)),"unction ")>0){
              $scriptz=$scriptz.tostring(anyvalue($stcssrst,"diybottom",0)).huanhang();
            }
                  $scriptz=$scriptz.'ccode["varchar"]="'.str_replace("\"","\\\"",killrn($ccode["varchar"])).'";'.huanhang();
            if (strpos($ccode["varchar"],"unction ")>0){
              $scriptz=$scriptz.$ccode["varchar"].huanhang();
            }
            $scriptz=$scriptz.'ccode["text"]="'.str_replace("\"","\\\"",killrn($ccode["text"])).'";'.huanhang();
            if (strpos($ccode["text"],"unction ")>0){
              $scriptz=$scriptz.$ccode["text"].huanhang();
            }
            $scriptz=$scriptz.'ccode["richtext"]="'.str_replace("\"","\\\"",killrn($ccode["richtext"])).'";'.huanhang();
            if (strpos($ccode["richtext"],"unction ")>0){
              $scriptz=$scriptz.$ccode["richtext"].huanhang();
            }
            $scriptz=$scriptz.'ccode["code"]="'.str_replace("\"","\\\"",killrn($ccode["code"])).'";'.huanhang();
            if (strpos($ccode["code"],"unction ")>0){
              $scriptz=$scriptz.$ccode["code"].huanhang();
            }
            $scriptz=$scriptz.'ccode["select"]="'.str_replace("\"","\\\"",killrn($ccode["select"])).'";'.huanhang();
            if (strpos($ccode["select"],"unction ")>0){
              $scriptz=$scriptz.$ccode["select"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multiselect"]="'.str_replace("\"","\\\"",killrn($ccode["multiselect"])).'";'.huanhang();
            if (strpos($ccode["multiselect"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiselect"].huanhang();
            }
            $scriptz=$scriptz.'ccode["date"]="'.str_replace("\"","\\\"",killrn($ccode["date"])).'";'.huanhang();
            if (strpos($ccode["date"],"unction ")>0){
              $scriptz=$scriptz.$ccode["date"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetime"]="'.str_replace("\"","\\\"",killrn($ccode["datetime"])).'";'.huanhang();
            if (strpos($ccode["datetime"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetime"].huanhang();
            }
            $scriptz=$scriptz.'ccode["int"]="'.str_replace("\"","\\\"",killrn($ccode["int"])).'";'.huanhang();
            if (strpos($ccode["int"],"unction ")>0){
              $scriptz=$scriptz.$ccode["int"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tinyint"]="'.str_replace("\"","\\\"",killrn($ccode["tinyint"])).'";'.huanhang();
            if (strpos($ccode["tinyint"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tinyint"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal1"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1"])).'";'.huanhang();
            if (strpos($ccode["decimal1"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal1"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal2"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2"])).'";'.huanhang();
            if (strpos($ccode["decimal2"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal2"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal3"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3"])).'";'.huanhang();
            if (strpos($ccode["decimal3"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal3"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal4"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4"])).'";'.huanhang();
            if (strpos($ccode["decimal4"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal4"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagex"]="'.str_replace("\"","\\\"",killrn($ccode["imagex"])).'";'.huanhang();
            if (strpos($ccode["imagex"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagex"].huanhang();
            }
            $scriptz=$scriptz.'ccode["images"]="'.str_replace("\"","\\\"",killrn($ccode["images"])).'";'.huanhang();
            if (strpos($ccode["images"],"unction ")>0){
              $scriptz=$scriptz.$ccode["images"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filex"]="'.str_replace("\"","\\\"",killrn($ccode["filex"])).'";'.huanhang();
            if (strpos($ccode["filex"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filex"].huanhang();
            }
            $scriptz=$scriptz.'ccode["files"]="'.str_replace("\"","\\\"",killrn($ccode["files"])).'";'.huanhang();
            if (strpos($ccode["files"],"unction ")>0){
              $scriptz=$scriptz.$ccode["files"].huanhang();
            }
            $scriptz=$scriptz.'ccode["check"]="'.str_replace("\"","\\\"",killrn($ccode["check"])).'";'.huanhang();
            if (strpos($ccode["check"],"unction ")>0){
              $scriptz=$scriptz.$ccode["check"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multicheck"]="'.str_replace("\"","\\\"",killrn($ccode["multicheck"])).'";'.huanhang();
            if (strpos($ccode["multicheck"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multicheck"].huanhang();
            }
            $scriptz=$scriptz.'ccode["varcharSRD"]="'.str_replace("\"","\\\"",killrn($ccode["varcharSRD"])).'";'.huanhang();
            if (strpos($ccode["varcharSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["varcharSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["textSRD"]="'.str_replace("\"","\\\"",killrn($ccode["textSRD"])).'";'.huanhang();
            if (strpos($ccode["textSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["textSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["richtextSRD"]="'.str_replace("\"","\\\"",killrn($ccode["richtextSRD"])).'";'.huanhang();
            if (strpos($ccode["richtextSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["richtextSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["codeSRD"]="'.str_replace("\"","\\\"",killrn($ccode["codeSRD"])).'";'.huanhang();
            if (strpos($ccode["codeSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["codeSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["selectSRD"]="'.str_replace("\"","\\\"",killrn($ccode["selectSRD"])).'";'.huanhang();
            if (strpos($ccode["selectSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["selectSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multiselectSRD"]="'.str_replace("\"","\\\"",killrn($ccode["multiselectSRD"])).'";'.huanhang();
            if (strpos($ccode["multiselectSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiselectSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["dateSRD"]="'.str_replace("\"","\\\"",killrn($ccode["dateSRD"])).'";'.huanhang();
            if (strpos($ccode["dateSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["dateSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetimeSRD"]="'.str_replace("\"","\\\"",killrn($ccode["datetimeSRD"])).'";'.huanhang();
            if (strpos($ccode["datetimeSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetimeSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["intSRD"]="'.str_replace("\"","\\\"",killrn($ccode["intSRD"])).'";'.huanhang();
            if (strpos($ccode["intSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["intSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tinyintSRD"]="'.str_replace("\"","\\\"",killrn($ccode["tinyintSRD"])).'";'.huanhang();
            if (strpos($ccode["tinyintSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tinyintSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal1SRD"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1SRD"])).'";'.huanhang();
            if (strpos($ccode["decimal1SRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal1SRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal2SRD"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2SRD"])).'";'.huanhang();
            if (strpos($ccode["decimal2SRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal2SRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal3SRD"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3SRD"])).'";'.huanhang();
            if (strpos($ccode["decimal3SRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal3SRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal4SRD"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4SRD"])).'";'.huanhang();
            if (strpos($ccode["decimal4SRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal4SRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagexSRD"]="'.str_replace("\"","\\\"",killrn($ccode["imagexSRD"])).'";'.huanhang();
            if (strpos($ccode["imagexSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagexSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagesSRD"]="'.str_replace("\"","\\\"",killrn($ccode["imagesSRD"])).'";'.huanhang();
            if (strpos($ccode["imagesSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagesSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filexSRD"]="'.str_replace("\"","\\\"",killrn($ccode["filexSRD"])).'";'.huanhang();
            if (strpos($ccode["filexSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filexSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filesSRD"]="'.str_replace("\"","\\\"",killrn($ccode["filesSRD"])).'";'.huanhang();
            if (strpos($ccode["filesSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filesSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["checkSRD"]="'.str_replace("\"","\\\"",killrn($ccode["checkSRD"])).'";'.huanhang();
            if (strpos($ccode["checkSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["checkSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multicheckSRD"]="'.str_replace("\"","\\\"",killrn($ccode["multicheckSRD"])).'";'.huanhang();
            if (strpos($ccode["multicheckSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multicheckSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["varcharINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["varcharINLINE"])).'";'.huanhang();
            if (strpos($ccode["varcharINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["varcharINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["textINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["textINLINE"])).'";'.huanhang();
            if (strpos($ccode["textINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["textINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["richtextINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["richtextINLINE"])).'";'.huanhang();
            if (strpos($ccode["richtextINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["richtextINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["codeINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["codeINLINE"])).'";'.huanhang();
            if (strpos($ccode["codeINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["codeINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["selectINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["selectINLINE"])).'";'.huanhang();
            if (strpos($ccode["selectINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["selectINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multiselectINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["multiselectINLINE"])).'";'.huanhang();
            if (strpos($ccode["multiselectINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiselectINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["dateINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["dateINLINE"])).'";'.huanhang();
            if (strpos($ccode["dateINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["dateINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetimeINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["datetimeINLINE"])).'";'.huanhang();
            if (strpos($ccode["datetimeINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetimeINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["intINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["intINLINE"])).'";'.huanhang();
            if (strpos($ccode["intINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["intINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tinyintINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["tinyintINLINE"])).'";'.huanhang();
            if (strpos($ccode["tinyintINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tinyintINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal1INLINE"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1INLINE"])).'";'.huanhang();
            if (strpos($ccode["decimal1INLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal1INLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal2INLINE"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2INLINE"])).'";'.huanhang();
            if (strpos($ccode["decimal2INLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal2INLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal3INLINE"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3INLINE"])).'";'.huanhang();
            if (strpos($ccode["decimal3INLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal3INLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal4INLINE"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4INLINE"])).'";'.huanhang();
            if (strpos($ccode["decimal4INLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal4INLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagexINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["imagexINLINE"])).'";'.huanhang();
            if (strpos($ccode["imagexINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagexINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagesINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["imagesINLINE"])).'";'.huanhang();
            if (strpos($ccode["imagesINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagesINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filexINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["filexINLINE"])).'";'.huanhang();
            if (strpos($ccode["filexINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filexINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filesINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["filesINLINE"])).'";'.huanhang();
            if (strpos($ccode["filesINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filesINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["checkINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["checkINLINE"])).'";'.huanhang();
            if (strpos($ccode["INLINEINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["INLINEINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multicheckINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["multicheckINLINE"])).'";'.huanhang();
            if (strpos($ccode["multiINLINEINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiINLINEINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["onerow"]="'.str_replace("\"","\\\"",killrn($ccode["onerow"])).'";'.huanhang();
            if (strpos($ccode["onerow"],"unction ")>0){
              $scriptz=$scriptz.$ccode["onerow"].huanhang();
            }
            $scriptz=$scriptz.'ccode["duorow"]="'.str_replace("\"","\\\"",killrn($ccode["duorow"])).'";'.huanhang();
            if (strpos($ccode["duorow"],"unction ")>0){
              $scriptz=$scriptz.$ccode["duorow"].huanhang();
            }
            $scriptz=$scriptz.'ccode["varcharFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["varcharFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["textFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["textFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["richtextFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["richtextFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["codeFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["codeFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["selectFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["selectFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["multiselectFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["multiselectFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["dateFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["dateFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["datetimeFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["datetimeFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["intFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["tinyintFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["tinyintFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["intFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal1FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal2FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal3FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal4FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["imagexFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["imagexFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["imagesFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["imagesFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["filexFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["filexFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["filesFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["filesFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["checkFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["checkFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["checkduoFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["checkduoFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["multicheckFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["multicheckFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["duorowFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["duorowFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["srdFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["srdFUNCTION"])).'";'.huanhang();
            
            
            if ($scriptx.$scriptz!=""){
              return $scriptx.$scriptz;
            }else{
              return "";
            }          
          break;
          case "detail":         
            if (strpos($mkv,".")>0){
             $stid=qian($mkv,".");
             $snox=hou($mkv,".");
            }else{
             $snox="0";
             $stid=$mkv;
            }                
            $stcssrst=SX("select jsfiles,cssfiles,scriptx,stylex,diytop,diybottom from coode_shortcss where shortid='".$stid."DETAIL'");
            $totst=countresult($stcssrst);
            if ($totst>0){
            $scriptx=anyvalue($stcssrst,"scriptx",0);
            }else{
            $scriptx="";
            }
            
            $scriptz=$scriptz.'ccode=new Array();'.huanhang();
            $scriptz=$scriptz.'ccode["srd"]="'.str_replace("\"","\\\"",killrn($ccode["srd"])).'";'.huanhang();
            if (strpos($ccode["srd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["srd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["diytop"]="'.str_replace("\"","\\\"",killrn(labturn(tostring(anyvalue($stcssrst,"diytop",0))))).'";'.huanhang();
            if (strpos(tostring(anyvalue($stcssrst,"diytop",0)),"unction ")>0){
              $scriptz=$scriptz.tostring(anyvalue($stcssrst,"diytop",0)).huanhang();
            }
            $scriptz=$scriptz.'ccode["diybottom"]="'.str_replace("\"","\\\"",killrn(labturn(tostring(anyvalue($stcssrst,"diybottom",0))))).'";'.huanhang();
            if (strpos(tostring(anyvalue($stcssrst,"diybottom",0)),"unction ")>0){
              $scriptz=$scriptz.tostring(anyvalue($stcssrst,"diybottom",0)).huanhang();
            }
                       $scriptz=$scriptz.'ccode["varchar"]="'.str_replace("\"","\\\"",killrn($ccode["varchar"])).'";'.huanhang();
            if (strpos($ccode["varchar"],"unction ")>0){
              $scriptz=$scriptz.$ccode["varchar"].huanhang();
            }
            $scriptz=$scriptz.'ccode["text"]="'.str_replace("\"","\\\"",killrn($ccode["text"])).'";'.huanhang();
            if (strpos($ccode["text"],"unction ")>0){
              $scriptz=$scriptz.$ccode["text"].huanhang();
            }
            $scriptz=$scriptz.'ccode["richtext"]="'.str_replace("\"","\\\"",killrn($ccode["richtext"])).'";'.huanhang();
            if (strpos($ccode["richtext"],"unction ")>0){
              $scriptz=$scriptz.$ccode["richtext"].huanhang();
            }
            $scriptz=$scriptz.'ccode["code"]="'.str_replace("\"","\\\"",killrn($ccode["code"])).'";'.huanhang();
            if (strpos($ccode["code"],"unction ")>0){
              $scriptz=$scriptz.$ccode["code"].huanhang();
            }
            $scriptz=$scriptz.'ccode["select"]="'.str_replace("\"","\\\"",killrn($ccode["select"])).'";'.huanhang();
            if (strpos($ccode["select"],"unction ")>0){
              $scriptz=$scriptz.$ccode["select"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multiselect"]="'.str_replace("\"","\\\"",killrn($ccode["multiselect"])).'";'.huanhang();
            if (strpos($ccode["multiselect"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiselect"].huanhang();
            }
            $scriptz=$scriptz.'ccode["date"]="'.str_replace("\"","\\\"",killrn($ccode["date"])).'";'.huanhang();
            if (strpos($ccode["date"],"unction ")>0){
              $scriptz=$scriptz.$ccode["date"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetime"]="'.str_replace("\"","\\\"",killrn($ccode["datetime"])).'";'.huanhang();
            if (strpos($ccode["datetime"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetime"].huanhang();
            }
            $scriptz=$scriptz.'ccode["int"]="'.str_replace("\"","\\\"",killrn($ccode["int"])).'";'.huanhang();
            if (strpos($ccode["int"],"unction ")>0){
              $scriptz=$scriptz.$ccode["int"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tinyint"]="'.str_replace("\"","\\\"",killrn($ccode["tinyint"])).'";'.huanhang();
            if (strpos($ccode["tinyint"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tinyint"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal1"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1"])).'";'.huanhang();
            if (strpos($ccode["decimal1"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal1"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal2"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2"])).'";'.huanhang();
            if (strpos($ccode["decimal2"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal2"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal3"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3"])).'";'.huanhang();
            if (strpos($ccode["decimal3"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal3"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal4"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4"])).'";'.huanhang();
            if (strpos($ccode["decimal4"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal4"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagex"]="'.str_replace("\"","\\\"",killrn($ccode["imagex"])).'";'.huanhang();
            if (strpos($ccode["imagex"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagex"].huanhang();
            }
            $scriptz=$scriptz.'ccode["images"]="'.str_replace("\"","\\\"",killrn($ccode["images"])).'";'.huanhang();
            if (strpos($ccode["images"],"unction ")>0){
              $scriptz=$scriptz.$ccode["images"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filex"]="'.str_replace("\"","\\\"",killrn($ccode["filex"])).'";'.huanhang();
            if (strpos($ccode["filex"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filex"].huanhang();
            }
            $scriptz=$scriptz.'ccode["files"]="'.str_replace("\"","\\\"",killrn($ccode["files"])).'";'.huanhang();
            if (strpos($ccode["files"],"unction ")>0){
              $scriptz=$scriptz.$ccode["files"].huanhang();
            }
            $scriptz=$scriptz.'ccode["check"]="'.str_replace("\"","\\\"",killrn($ccode["check"])).'";'.huanhang();
            if (strpos($ccode["check"],"unction ")>0){
              $scriptz=$scriptz.$ccode["check"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multicheck"]="'.str_replace("\"","\\\"",killrn($ccode["multicheck"])).'";'.huanhang();
            if (strpos($ccode["multicheck"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multicheck"].huanhang();
            }
            $scriptz=$scriptz.'ccode["varcharSRD"]="'.str_replace("\"","\\\"",killrn($ccode["varcharSRD"])).'";'.huanhang();
            if (strpos($ccode["varcharSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["varcharSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["textSRD"]="'.str_replace("\"","\\\"",killrn($ccode["textSRD"])).'";'.huanhang();
            if (strpos($ccode["textSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["textSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["richtextSRD"]="'.str_replace("\"","\\\"",killrn($ccode["richtextSRD"])).'";'.huanhang();
            if (strpos($ccode["richtextSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["richtextSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["codeSRD"]="'.str_replace("\"","\\\"",killrn($ccode["codeSRD"])).'";'.huanhang();
            if (strpos($ccode["codeSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["codeSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["selectSRD"]="'.str_replace("\"","\\\"",killrn($ccode["selectSRD"])).'";'.huanhang();
            if (strpos($ccode["selectSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["selectSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multiselectSRD"]="'.str_replace("\"","\\\"",killrn($ccode["multiselectSRD"])).'";'.huanhang();
            if (strpos($ccode["multiselectSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiselectSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["dateSRD"]="'.str_replace("\"","\\\"",killrn($ccode["dateSRD"])).'";'.huanhang();
            if (strpos($ccode["dateSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["dateSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetimeSRD"]="'.str_replace("\"","\\\"",killrn($ccode["datetimeSRD"])).'";'.huanhang();
            if (strpos($ccode["datetimeSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetimeSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["intSRD"]="'.str_replace("\"","\\\"",killrn($ccode["intSRD"])).'";'.huanhang();
            if (strpos($ccode["intSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["intSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tinyintSRD"]="'.str_replace("\"","\\\"",killrn($ccode["tinyintSRD"])).'";'.huanhang();
            if (strpos($ccode["tinyintSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tinyintSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal1SRD"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1SRD"])).'";'.huanhang();
            if (strpos($ccode["decimal1SRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal1SRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal2SRD"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2SRD"])).'";'.huanhang();
            if (strpos($ccode["decimal2SRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal2SRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal3SRD"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3SRD"])).'";'.huanhang();
            if (strpos($ccode["decimal3SRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal3SRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal4SRD"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4SRD"])).'";'.huanhang();
            if (strpos($ccode["decimal4SRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal4SRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagexSRD"]="'.str_replace("\"","\\\"",killrn($ccode["imagexSRD"])).'";'.huanhang();
            if (strpos($ccode["imagexSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagexSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagesSRD"]="'.str_replace("\"","\\\"",killrn($ccode["imagesSRD"])).'";'.huanhang();
            if (strpos($ccode["imagesSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagesSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filexSRD"]="'.str_replace("\"","\\\"",killrn($ccode["filexSRD"])).'";'.huanhang();
            if (strpos($ccode["filexSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filexSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filesSRD"]="'.str_replace("\"","\\\"",killrn($ccode["filesSRD"])).'";'.huanhang();
            if (strpos($ccode["filesSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filesSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["checkSRD"]="'.str_replace("\"","\\\"",killrn($ccode["checkSRD"])).'";'.huanhang();
            if (strpos($ccode["checkSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["checkSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multicheckSRD"]="'.str_replace("\"","\\\"",killrn($ccode["multicheckSRD"])).'";'.huanhang();
            if (strpos($ccode["multicheckSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multicheckSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["varcharINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["varcharINLINE"])).'";'.huanhang();
            if (strpos($ccode["varcharINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["varcharINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["textINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["textINLINE"])).'";'.huanhang();
            if (strpos($ccode["textINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["textINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["richtextINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["richtextINLINE"])).'";'.huanhang();
            if (strpos($ccode["richtextINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["richtextINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["codeINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["codeINLINE"])).'";'.huanhang();
            if (strpos($ccode["codeINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["codeINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["selectINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["selectINLINE"])).'";'.huanhang();
            if (strpos($ccode["selectINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["selectINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multiselectINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["multiselectINLINE"])).'";'.huanhang();
            if (strpos($ccode["multiselectINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiselectINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["dateINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["dateINLINE"])).'";'.huanhang();
            if (strpos($ccode["dateINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["dateINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetimeINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["datetimeINLINE"])).'";'.huanhang();
            if (strpos($ccode["datetimeINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetimeINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["intINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["intINLINE"])).'";'.huanhang();
            if (strpos($ccode["intINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["intINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tinyintINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["tinyintINLINE"])).'";'.huanhang();
            if (strpos($ccode["tinyintINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tinyintINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal1INLINE"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1INLINE"])).'";'.huanhang();
            if (strpos($ccode["decimal1INLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal1INLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal2INLINE"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2INLINE"])).'";'.huanhang();
            if (strpos($ccode["decimal2INLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal2INLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal3INLINE"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3INLINE"])).'";'.huanhang();
            if (strpos($ccode["decimal3INLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal3INLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal4INLINE"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4INLINE"])).'";'.huanhang();
            if (strpos($ccode["decimal4INLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal4INLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagexINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["imagexINLINE"])).'";'.huanhang();
            if (strpos($ccode["imagexINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagexINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagesINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["imagesINLINE"])).'";'.huanhang();
            if (strpos($ccode["imagesINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagesINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filexINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["filexINLINE"])).'";'.huanhang();
            if (strpos($ccode["filexINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filexINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filesINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["filesINLINE"])).'";'.huanhang();
            if (strpos($ccode["filesINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filesINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["checkINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["checkINLINE"])).'";'.huanhang();
            if (strpos($ccode["INLINEINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["INLINEINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multicheckINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["multicheckINLINE"])).'";'.huanhang();
            if (strpos($ccode["multiINLINEINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiINLINEINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["onerow"]="'.str_replace("\"","\\\"",killrn($ccode["onerow"])).'";'.huanhang();
            if (strpos($ccode["onerow"],"unction ")>0){
              $scriptz=$scriptz.$ccode["onerow"].huanhang();
            }
            $scriptz=$scriptz.'ccode["duorow"]="'.str_replace("\"","\\\"",killrn($ccode["duorow"])).'";'.huanhang();
            if (strpos($ccode["duorow"],"unction ")>0){
              $scriptz=$scriptz.$ccode["duorow"].huanhang();
            }
            $scriptz=$scriptz.'ccode["varcharFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["varcharFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["textFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["textFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["richtextFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["richtextFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["codeFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["codeFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["selectFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["selectFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["multiselectFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["multiselectFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["dateFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["dateFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["datetimeFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["datetimeFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["intFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["tinyintFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["tinyintFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["intFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal1FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal2FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal3FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal4FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["imagexFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["imagexFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["imagesFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["imagesFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["filexFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["filexFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["filesFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["filesFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["checkFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["checkFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["checkduoFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["checkduoFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["multicheckFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["multicheckFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["duorowFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["duorowFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["srdFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["srdFUNCTION"])).'";'.huanhang(); 
            if ($scriptx.$scriptz!=""){
              return $scriptx.$scriptz;
            }else{
              return "";
            }          
          break;
         case "Mdetail":         
            if (strpos($mkv,".")>0){
             $stid=qian($mkv,".");
             $snox=hou($mkv,".");
            }else{
             $snox="0";
             $stid=$mkv;
            }                
            $stcssrst=SX("select jsfiles,cssfiles,scriptx,stylex,diytop,diybottom from coode_shortcss where shortid='".$stid."DETAIL'");
            $totst=countresult($stcssrst);
            if ($totst>0){
            $scriptx=anyvalue($stcssrst,"scriptx",0);
            }else{
            $scriptx="";
            }
            
            $scriptz=$scriptz.'ccode=new Array();'.huanhang();
            $scriptz=$scriptz.'ccode["srd"]="'.str_replace("\"","\\\"",killrn($ccode["srd"])).'";'.huanhang();
            if (strpos($ccode["srd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["srd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["diytop"]="'.str_replace("\"","\\\"",killrn(labturn(tostring(anyvalue($stcssrst,"diytop",0))))).'";'.huanhang();
            if (strpos(tostring(anyvalue($stcssrst,"diytop",0)),"unction ")>0){
              $scriptz=$scriptz.tostring(anyvalue($stcssrst,"diytop",0)).huanhang();
            }
            $scriptz=$scriptz.'ccode["diybottom"]="'.str_replace("\"","\\\"",killrn(labturn(tostring(anyvalue($stcssrst,"diybottom",0))))).'";'.huanhang();
            if (strpos(tostring(anyvalue($stcssrst,"diybottom",0)),"unction ")>0){
              $scriptz=$scriptz.tostring(anyvalue($stcssrst,"diybottom",0)).huanhang();
            }
                       $scriptz=$scriptz.'ccode["varchar"]="'.str_replace("\"","\\\"",killrn($ccode["varchar"])).'";'.huanhang();
            if (strpos($ccode["varchar"],"unction ")>0){
              $scriptz=$scriptz.$ccode["varchar"].huanhang();
            }
            $scriptz=$scriptz.'ccode["text"]="'.str_replace("\"","\\\"",killrn($ccode["text"])).'";'.huanhang();
            if (strpos($ccode["text"],"unction ")>0){
              $scriptz=$scriptz.$ccode["text"].huanhang();
            }
            $scriptz=$scriptz.'ccode["richtext"]="'.str_replace("\"","\\\"",killrn($ccode["richtext"])).'";'.huanhang();
            if (strpos($ccode["richtext"],"unction ")>0){
              $scriptz=$scriptz.$ccode["richtext"].huanhang();
            }
            $scriptz=$scriptz.'ccode["code"]="'.str_replace("\"","\\\"",killrn($ccode["code"])).'";'.huanhang();
            if (strpos($ccode["code"],"unction ")>0){
              $scriptz=$scriptz.$ccode["code"].huanhang();
            }
            $scriptz=$scriptz.'ccode["select"]="'.str_replace("\"","\\\"",killrn($ccode["select"])).'";'.huanhang();
            if (strpos($ccode["select"],"unction ")>0){
              $scriptz=$scriptz.$ccode["select"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multiselect"]="'.str_replace("\"","\\\"",killrn($ccode["multiselect"])).'";'.huanhang();
            if (strpos($ccode["multiselect"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiselect"].huanhang();
            }
            $scriptz=$scriptz.'ccode["date"]="'.str_replace("\"","\\\"",killrn($ccode["date"])).'";'.huanhang();
            if (strpos($ccode["date"],"unction ")>0){
              $scriptz=$scriptz.$ccode["date"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetime"]="'.str_replace("\"","\\\"",killrn($ccode["datetime"])).'";'.huanhang();
            if (strpos($ccode["datetime"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetime"].huanhang();
            }
            $scriptz=$scriptz.'ccode["int"]="'.str_replace("\"","\\\"",killrn($ccode["int"])).'";'.huanhang();
            if (strpos($ccode["int"],"unction ")>0){
              $scriptz=$scriptz.$ccode["int"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tinyint"]="'.str_replace("\"","\\\"",killrn($ccode["tinyint"])).'";'.huanhang();
            if (strpos($ccode["tinyint"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tinyint"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal1"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1"])).'";'.huanhang();
            if (strpos($ccode["decimal1"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal1"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal2"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2"])).'";'.huanhang();
            if (strpos($ccode["decimal2"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal2"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal3"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3"])).'";'.huanhang();
            if (strpos($ccode["decimal3"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal3"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal4"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4"])).'";'.huanhang();
            if (strpos($ccode["decimal4"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal4"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagex"]="'.str_replace("\"","\\\"",killrn($ccode["imagex"])).'";'.huanhang();
            if (strpos($ccode["imagex"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagex"].huanhang();
            }
            $scriptz=$scriptz.'ccode["images"]="'.str_replace("\"","\\\"",killrn($ccode["images"])).'";'.huanhang();
            if (strpos($ccode["images"],"unction ")>0){
              $scriptz=$scriptz.$ccode["images"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filex"]="'.str_replace("\"","\\\"",killrn($ccode["filex"])).'";'.huanhang();
            if (strpos($ccode["filex"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filex"].huanhang();
            }
            $scriptz=$scriptz.'ccode["files"]="'.str_replace("\"","\\\"",killrn($ccode["files"])).'";'.huanhang();
            if (strpos($ccode["files"],"unction ")>0){
              $scriptz=$scriptz.$ccode["files"].huanhang();
            }
            $scriptz=$scriptz.'ccode["check"]="'.str_replace("\"","\\\"",killrn($ccode["check"])).'";'.huanhang();
            if (strpos($ccode["check"],"unction ")>0){
              $scriptz=$scriptz.$ccode["check"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multicheck"]="'.str_replace("\"","\\\"",killrn($ccode["multicheck"])).'";'.huanhang();
            if (strpos($ccode["multicheck"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multicheck"].huanhang();
            }
            $scriptz=$scriptz.'ccode["varcharSRD"]="'.str_replace("\"","\\\"",killrn($ccode["varcharSRD"])).'";'.huanhang();
            if (strpos($ccode["varcharSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["varcharSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["textSRD"]="'.str_replace("\"","\\\"",killrn($ccode["textSRD"])).'";'.huanhang();
            if (strpos($ccode["textSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["textSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["richtextSRD"]="'.str_replace("\"","\\\"",killrn($ccode["richtextSRD"])).'";'.huanhang();
            if (strpos($ccode["richtextSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["richtextSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["codeSRD"]="'.str_replace("\"","\\\"",killrn($ccode["codeSRD"])).'";'.huanhang();
            if (strpos($ccode["codeSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["codeSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["selectSRD"]="'.str_replace("\"","\\\"",killrn($ccode["selectSRD"])).'";'.huanhang();
            if (strpos($ccode["selectSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["selectSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multiselectSRD"]="'.str_replace("\"","\\\"",killrn($ccode["multiselectSRD"])).'";'.huanhang();
            if (strpos($ccode["multiselectSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiselectSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["dateSRD"]="'.str_replace("\"","\\\"",killrn($ccode["dateSRD"])).'";'.huanhang();
            if (strpos($ccode["dateSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["dateSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetimeSRD"]="'.str_replace("\"","\\\"",killrn($ccode["datetimeSRD"])).'";'.huanhang();
            if (strpos($ccode["datetimeSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetimeSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["intSRD"]="'.str_replace("\"","\\\"",killrn($ccode["intSRD"])).'";'.huanhang();
            if (strpos($ccode["intSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["intSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tinyintSRD"]="'.str_replace("\"","\\\"",killrn($ccode["tinyintSRD"])).'";'.huanhang();
            if (strpos($ccode["tinyintSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tinyintSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal1SRD"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1SRD"])).'";'.huanhang();
            if (strpos($ccode["decimal1SRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal1SRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal2SRD"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2SRD"])).'";'.huanhang();
            if (strpos($ccode["decimal2SRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal2SRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal3SRD"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3SRD"])).'";'.huanhang();
            if (strpos($ccode["decimal3SRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal3SRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal4SRD"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4SRD"])).'";'.huanhang();
            if (strpos($ccode["decimal4SRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal4SRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagexSRD"]="'.str_replace("\"","\\\"",killrn($ccode["imagexSRD"])).'";'.huanhang();
            if (strpos($ccode["imagexSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagexSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagesSRD"]="'.str_replace("\"","\\\"",killrn($ccode["imagesSRD"])).'";'.huanhang();
            if (strpos($ccode["imagesSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagesSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filexSRD"]="'.str_replace("\"","\\\"",killrn($ccode["filexSRD"])).'";'.huanhang();
            if (strpos($ccode["filexSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filexSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filesSRD"]="'.str_replace("\"","\\\"",killrn($ccode["filesSRD"])).'";'.huanhang();
            if (strpos($ccode["filesSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filesSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["checkSRD"]="'.str_replace("\"","\\\"",killrn($ccode["checkSRD"])).'";'.huanhang();
            if (strpos($ccode["checkSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["checkSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multicheckSRD"]="'.str_replace("\"","\\\"",killrn($ccode["multicheckSRD"])).'";'.huanhang();
            if (strpos($ccode["multicheckSRD"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multicheckSRD"].huanhang();
            }
            $scriptz=$scriptz.'ccode["varcharINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["varcharINLINE"])).'";'.huanhang();
            if (strpos($ccode["varcharINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["varcharINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["textINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["textINLINE"])).'";'.huanhang();
            if (strpos($ccode["textINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["textINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["richtextINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["richtextINLINE"])).'";'.huanhang();
            if (strpos($ccode["richtextINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["richtextINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["codeINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["codeINLINE"])).'";'.huanhang();
            if (strpos($ccode["codeINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["codeINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["selectINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["selectINLINE"])).'";'.huanhang();
            if (strpos($ccode["selectINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["selectINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multiselectINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["multiselectINLINE"])).'";'.huanhang();
            if (strpos($ccode["multiselectINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiselectINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["dateINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["dateINLINE"])).'";'.huanhang();
            if (strpos($ccode["dateINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["dateINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetimeINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["datetimeINLINE"])).'";'.huanhang();
            if (strpos($ccode["datetimeINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetimeINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["intINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["intINLINE"])).'";'.huanhang();
            if (strpos($ccode["intINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["intINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tinyintINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["tinyintINLINE"])).'";'.huanhang();
            if (strpos($ccode["tinyintINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tinyintINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal1INLINE"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1INLINE"])).'";'.huanhang();
            if (strpos($ccode["decimal1INLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal1INLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal2INLINE"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2INLINE"])).'";'.huanhang();
            if (strpos($ccode["decimal2INLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal2INLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal3INLINE"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3INLINE"])).'";'.huanhang();
            if (strpos($ccode["decimal3INLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal3INLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal4INLINE"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4INLINE"])).'";'.huanhang();
            if (strpos($ccode["decimal4INLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal4INLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagexINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["imagexINLINE"])).'";'.huanhang();
            if (strpos($ccode["imagexINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagexINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagesINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["imagesINLINE"])).'";'.huanhang();
            if (strpos($ccode["imagesINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagesINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filexINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["filexINLINE"])).'";'.huanhang();
            if (strpos($ccode["filexINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filexINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filesINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["filesINLINE"])).'";'.huanhang();
            if (strpos($ccode["filesINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filesINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["checkINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["checkINLINE"])).'";'.huanhang();
            if (strpos($ccode["INLINEINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["INLINEINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multicheckINLINE"]="'.str_replace("\"","\\\"",killrn($ccode["multicheckINLINE"])).'";'.huanhang();
            if (strpos($ccode["multiINLINEINLINE"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiINLINEINLINE"].huanhang();
            }
            $scriptz=$scriptz.'ccode["onerow"]="'.str_replace("\"","\\\"",killrn($ccode["onerow"])).'";'.huanhang();
            if (strpos($ccode["onerow"],"unction ")>0){
              $scriptz=$scriptz.$ccode["onerow"].huanhang();
            }
            $scriptz=$scriptz.'ccode["duorow"]="'.str_replace("\"","\\\"",killrn($ccode["duorow"])).'";'.huanhang();
            if (strpos($ccode["duorow"],"unction ")>0){
              $scriptz=$scriptz.$ccode["duorow"].huanhang();
            }
            $scriptz=$scriptz.'ccode["varcharFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["varcharFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["textFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["textFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["richtextFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["richtextFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["codeFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["codeFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["selectFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["selectFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["multiselectFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["multiselectFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["dateFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["dateFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["datetimeFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["datetimeFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["intFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["tinyintFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["tinyintFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["intFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal1FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal2FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal3FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal4FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["imagexFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["imagexFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["imagesFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["imagesFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["filexFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["filexFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["filesFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["filesFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["checkFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["checkFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["checkduoFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["checkduoFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["multicheckFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["multicheckFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["duorowFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["duorowFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["srdFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["srdFUNCTION"])).'";'.huanhang();   
            if ($scriptx.$scriptz!=""){
              return $scriptx.$scriptz;
            }else{
              return "";
            }          
          break;
          case "menu":
           
           $scriptz=$scriptz.'ccodesrd="'.str_replace("\"","\\\"",killrn($ccode["srd"])).'";'.huanhang();
           $scriptz=$scriptz.'ccodelv1="'.str_replace("\"","\\\"",killrn($ccode["lv1"])).'";'.huanhang();
           $scriptz=$scriptz.'ccodelv2="'.str_replace("\"","\\\"",killrn($ccode["lv2"])).'";'.huanhang();
           $scriptz=$scriptz.'ccodelv3="'.str_replace("\"","\\\"",killrn($ccode["lv3"])).'";'.huanhang();
           $scriptz=$scriptz.'ccodelv4="'.str_replace("\"","\\\"",killrn($ccode["lv4"])).'";'.huanhang();
           $scriptz=$scriptz.'ccodelv5="'.str_replace("\"","\\\"",killrn($ccode["lv5"])).'";'.huanhang();
           $scriptz=$scriptz.'initmenu(ccodesrd,ccodelv1,ccodelv2,ccodelv3,ccodelv4,ccodelv5);'.huanhang();
           
           return $scriptz;
          break;
          case "list":
         
            $scriptz=$scriptz.'ccode=new Array();'.huanhang();            
            $scriptz=$scriptz.'ccode["chtml"]="'.str_replace("\"","\\\"",killrn($ccode["chtml"])).'";'.huanhang();
            if (strpos($ccode["chtml"],"unction ")>0){
              $scriptz=$scriptz.$ccode["chtml"].huanhang();
            }
            $scriptz=$scriptz.'ccode["varchar"]="'.str_replace("\"","\\\"",killrn($ccode["varchar"])).'";'.huanhang();
            if (strpos($ccode["varchar"],"unction ")>0){
              $scriptz=$scriptz.$ccode["varchar"].huanhang();
            }
            $scriptz=$scriptz.'ccode["srd"]="'.str_replace("\"","\\\"",killrn($ccode["srd"])).'";'.huanhang();
            if (strpos($ccode["srd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["srd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tabdemo"]="'.str_replace("\"","\\\"",killrn($ccode["tabdemo"])).'";'.huanhang();
            if (strpos($ccode["tabdemo"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tabdemo"].huanhang();
            }
            $scriptz=$scriptz.'ccode["text"]="'.str_replace("\"","\\\"",killrn($ccode["text"])).'";'.huanhang();
            if (strpos($ccode["text"],"unction ")>0){
              $scriptz=$scriptz.$ccode["text"].huanhang();
            }
            $scriptz=$scriptz.'ccode["richtext"]="'.str_replace("\"","\\\"",killrn($ccode["richtext"])).'";'.huanhang();
            if (strpos($ccode["richtext"],"unction ")>0){
              $scriptz=$scriptz.$ccode["richtext"].huanhang();
            }
            $scriptz=$scriptz.'ccode["code"]="'.str_replace("\"","\\\"",killrn($ccode["code"])).'";'.huanhang();
            if (strpos($ccode["code"],"unction ")>0){
              $scriptz=$scriptz.$ccode["code"].huanhang();
            }
            $scriptz=$scriptz.'ccode["select"]="'.str_replace("\"","\\\"",killrn($ccode["select"])).'";'.huanhang();
            if (strpos($ccode["select"],"unction ")>0){
              $scriptz=$scriptz.$ccode["select"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multiselect"]="'.str_replace("\"","\\\"",killrn($ccode["multiselect"])).'";'.huanhang();
            if (strpos($ccode["multiselect"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiselect"].huanhang();
            }
            $scriptz=$scriptz.'ccode["date"]="'.str_replace("\"","\\\"",killrn($ccode["date"])).'";'.huanhang();
            if (strpos($ccode["date"],"unction ")>0){
              $scriptz=$scriptz.$ccode["date"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetime"]="'.str_replace("\"","\\\"",killrn($ccode["datetime"])).'";'.huanhang();
            if (strpos($ccode["datetime"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetime"].huanhang();
            }
            $scriptz=$scriptz.'ccode["int"]="'.str_replace("\"","\\\"",killrn($ccode["int"])).'";'.huanhang();
            if (strpos($ccode["int"],"unction ")>0){
              $scriptz=$scriptz.$ccode["int"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tinyint"]="'.str_replace("\"","\\\"",killrn($ccode["tinyint"])).'";'.huanhang();
            if (strpos($ccode["tinyint"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tinyint"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal1"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1"])).'";'.huanhang();
            if (strpos($ccode["decimal1"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal1"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal2"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2"])).'";'.huanhang();
            if (strpos($ccode["decimal2"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal2"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal3"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3"])).'";'.huanhang();
            if (strpos($ccode["decimal3"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal3"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal4"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4"])).'";'.huanhang();
            if (strpos($ccode["decimal4"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal4"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagex"]="'.str_replace("\"","\\\"",killrn($ccode["imagex"])).'";'.huanhang();
            if (strpos($ccode["imagex"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagex"].huanhang();
            }
            $scriptz=$scriptz.'ccode["images"]="'.str_replace("\"","\\\"",killrn($ccode["images"])).'";'.huanhang();
            if (strpos($ccode["images"],"unction ")>0){
              $scriptz=$scriptz.$ccode["images"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filex"]="'.str_replace("\"","\\\"",killrn($ccode["filex"])).'";'.huanhang();
            if (strpos($ccode["filex"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filex"].huanhang();
            }
            $scriptz=$scriptz.'ccode["files"]="'.str_replace("\"","\\\"",killrn($ccode["files"])).'";'.huanhang();
            if (strpos($ccode["files"],"unction ")>0){
              $scriptz=$scriptz.$ccode["files"].huanhang();
            }
            $scriptz=$scriptz.'ccode["check"]="'.str_replace("\"","\\\"",killrn($ccode["check"])).'";'.huanhang();
            if (strpos($ccode["check"],"unction ")>0){
              $scriptz=$scriptz.$ccode["check"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multicheck"]="'.str_replace("\"","\\\"",killrn($ccode["multicheck"])).'";'.huanhang();
            if (strpos($ccode["multicheck"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multicheck"].huanhang();
            }
$scriptz=$scriptz.'ccode["datasnoth"]="'.str_replace("\"","\\\"",killrn($ccode["datasnoth"])).'";'.huanhang();
            if (strpos($ccode["datasnoth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datasnoth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["oprtbtnth"]="'.str_replace("\"","\\\"",killrn($ccode["oprtbtnth"])).'";'.huanhang();
            if (strpos($ccode["oprtbtnth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["oprtbtnth"].huanhang();
            }
           $scriptz=$scriptz.'ccode["varcharth"]="'.str_replace("\"","\\\"",killrn($ccode["varcharth"])).'";'.huanhang();
            if (strpos($ccode["varcharth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["varcharth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["textth"]="'.str_replace("\"","\\\"",killrn($ccode["textth"])).'";'.huanhang();
            if (strpos($ccode["textth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["textth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["richtextth"]="'.str_replace("\"","\\\"",killrn($ccode["richtextth"])).'";'.huanhang();
            if (strpos($ccode["richtextth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["richtextth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["codeth"]="'.str_replace("\"","\\\"",killrn($ccode["codeth"])).'";'.huanhang();
            if (strpos($ccode["codeth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["codeth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["selectth"]="'.str_replace("\"","\\\"",killrn($ccode["selectth"])).'";'.huanhang();
            if (strpos($ccode["selectth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["selectth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multiselectth"]="'.str_replace("\"","\\\"",killrn($ccode["multiselectth"])).'";'.huanhang();
            if (strpos($ccode["multiselectth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiselectth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["dateth"]="'.str_replace("\"","\\\"",killrn($ccode["dateth"])).'";'.huanhang();
            if (strpos($ccode["dateth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["dateth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetimeth"]="'.str_replace("\"","\\\"",killrn($ccode["datetimeth"])).'";'.huanhang();
            if (strpos($ccode["datetimeth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetimeth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["intth"]="'.str_replace("\"","\\\"",killrn($ccode["intth"])).'";'.huanhang();
            if (strpos($ccode["intth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["intth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tinyintth"]="'.str_replace("\"","\\\"",killrn($ccode["tinyintth"])).'";'.huanhang();
            if (strpos($ccode["tinyintth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tinyintth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal1th"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1th"])).'";'.huanhang();
            if (strpos($ccode["decimal1th"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal1th"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal2th"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2th"])).'";'.huanhang();
            if (strpos($ccode["decimal2th"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal2th"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal3th"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3th"])).'";'.huanhang();
            if (strpos($ccode["decimal3th"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal3th"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal4th"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4th"])).'";'.huanhang();
            if (strpos($ccode["decimal4th"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal4th"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagexth"]="'.str_replace("\"","\\\"",killrn($ccode["imagexth"])).'";'.huanhang();
            if (strpos($ccode["imagexth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagexth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagesth"]="'.str_replace("\"","\\\"",killrn($ccode["imagesth"])).'";'.huanhang();
            if (strpos($ccode["imagesth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagesth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filexth"]="'.str_replace("\"","\\\"",killrn($ccode["filexth"])).'";'.huanhang();
            if (strpos($ccode["filexth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filexth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filesth"]="'.str_replace("\"","\\\"",killrn($ccode["filesth"])).'";'.huanhang();
            if (strpos($ccode["filesth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filesth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["checkth"]="'.str_replace("\"","\\\"",killrn($ccode["checkth"])).'";'.huanhang();
            if (strpos($ccode["checkth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["checkth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multicheckth"]="'.str_replace("\"","\\\"",killrn($ccode["multicheckth"])).'";'.huanhang();
            if (strpos($ccode["multicheckth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multicheckth"].huanhang();
            }
                     $scriptz=$scriptz.'ccode["datasnotd"]="'.str_replace("\"","\\\"",killrn($ccode["datasnotd"])).'";'.huanhang();
            if (strpos($ccode["datasnotd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datasnotd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["oprtbtntd"]="'.str_replace("\"","\\\"",killrn($ccode["oprtbtntd"])).'";'.huanhang();
            if (strpos($ccode["oprtbtntd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["oprtbtntd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["varchartd"]="'.str_replace("\"","\\\"",killrn($ccode["varchartd"])).'";'.huanhang();
            if (strpos($ccode["varchartd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["varchartd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["texttd"]="'.str_replace("\"","\\\"",killrn($ccode["texttd"])).'";'.huanhang();
            if (strpos($ccode["texttd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["texttd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["richtexttd"]="'.str_replace("\"","\\\"",killrn($ccode["richtexttd"])).'";'.huanhang();
            if (strpos($ccode["richtexttd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["richtexttd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["codetd"]="'.str_replace("\"","\\\"",killrn($ccode["codetd"])).'";'.huanhang();
            if (strpos($ccode["codetd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["codetd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["selecttd"]="'.str_replace("\"","\\\"",killrn($ccode["selecttd"])).'";'.huanhang();
            if (strpos($ccode["selecttd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["selecttd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multiselecttd"]="'.str_replace("\"","\\\"",killrn($ccode["multiselecttd"])).'";'.huanhang();
            if (strpos($ccode["multiselecttd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiselecttd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetd"]="'.str_replace("\"","\\\"",killrn($ccode["datetd"])).'";'.huanhang();
            if (strpos($ccode["datetd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetimetd"]="'.str_replace("\"","\\\"",killrn($ccode["datetimetd"])).'";'.huanhang();
            if (strpos($ccode["datetimetd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetimetd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["inttd"]="'.str_replace("\"","\\\"",killrn($ccode["inttd"])).'";'.huanhang();
            if (strpos($ccode["inttd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["inttd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tinyinttd"]="'.str_replace("\"","\\\"",killrn($ccode["tinyinttd"])).'";'.huanhang();
            if (strpos($ccode["tinyinttd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tinyinttd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal1td"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1td"])).'";'.huanhang();
            if (strpos($ccode["decimal1td"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal1td"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal2td"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2td"])).'";'.huanhang();
            if (strpos($ccode["decimal2td"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal2td"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal3td"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3td"])).'";'.huanhang();
            if (strpos($ccode["decimal3td"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal3td"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal4td"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4td"])).'";'.huanhang();
            if (strpos($ccode["decimal4td"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal4td"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagextd"]="'.str_replace("\"","\\\"",killrn($ccode["imagextd"])).'";'.huanhang();
            if (strpos($ccode["imagextd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagextd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagestd"]="'.str_replace("\"","\\\"",killrn($ccode["imagestd"])).'";'.huanhang();
            if (strpos($ccode["imagestd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagestd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filextd"]="'.str_replace("\"","\\\"",killrn($ccode["filextd"])).'";'.huanhang();
            if (strpos($ccode["filextd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filextd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filestd"]="'.str_replace("\"","\\\"",killrn($ccode["filestd"])).'";'.huanhang();
            if (strpos($ccode["filestd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filestd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["checktd"]="'.str_replace("\"","\\\"",killrn($ccode["checktd"])).'";'.huanhang();
            if (strpos($ccode["checktd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["checktd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multichecktd"]="'.str_replace("\"","\\\"",killrn($ccode["multichecktd"])).'";'.huanhang();
            if (strpos($ccode["multichecktd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multichecktd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["oprt"]="'.str_replace("\"","\\\"",killrn($ccode["oprt"])).'";'.huanhang();
            if (strpos($ccode["oprt"],"unction ")>0){
              $scriptz=$scriptz.$ccode["oprt"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tabtr"]="'.str_replace("\"","\\\"",killrn($ccode["tabtr"])).'";'.huanhang();
            if (strpos($ccode["tabstr"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tabstr"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tabtd"]="'.str_replace("\"","\\\"",killrn($ccode["tabtd"])).'";'.huanhang();
            if (strpos($ccode["tabtd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tabtd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tabhdtr"]="'.str_replace("\"","\\\"",killrn($ccode["tabhdtr"])).'";'.huanhang();
            if (strpos($ccode["tabhdtr"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tabhdtr"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tabhdtd"]="'.str_replace("\"","\\\"",killrn($ccode["tabhdtd"])).'";'.huanhang();
            if (strpos($ccode["tabhdtd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tabhdtd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["content"]="'.str_replace("\"","\\\"",killrn($ccode["content"])).'";'.huanhang();
            if (strpos($ccode["content"],"unction ")>0){
              $scriptz=$scriptz.$ccode["content"].huanhang();
            }
            $scriptz=$scriptz.'ccode["pgsrd"]="'.str_replace("\"","\\\"",killrn($ccode["pgsrd"])).'";'.huanhang();
            if (strpos($ccode["pgsrd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["pgsrd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["pgin"]="'.str_replace("\"","\\\"",killrn($ccode["pgin"])).'";'.huanhang();
            if (strpos($ccode["pgin"],"unction ")>0){
              $scriptz=$scriptz.$ccode["pgin"].huanhang();
            }
            $scriptz=$scriptz.'ccode["pgout"]="'.str_replace("\"","\\\"",killrn($ccode["pgout"])).'";'.huanhang();
            if (strpos($ccode["pgout"],"unction ")>0){
              $scriptz=$scriptz.$ccode["pgout"].huanhang();
            }
            $scriptz=$scriptz.'ccode["searchdemo"]="'.str_replace("\"","\\\"",killrn($ccode["searchdemo"])).'";'.huanhang();
            if (strpos($ccode["searchdemo"],"unction ")>0){
              $scriptz=$scriptz.$ccode["searchdemo"].huanhang();
            }
            $scriptz=$scriptz.'ccode["chtmlSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["chtmlSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["varcharSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["varcharSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["contentSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["contentSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["searchdemoSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["searchdemoSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["srdSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["srdSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["textSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["textSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["richtextSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["richtextSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["codeSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["codeSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["selectSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["selectSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["multiselectSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["multiselectSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["dateSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["dateSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["datetimeSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["datetimeSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["intSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["intSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["tinyintSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["tinyintSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal1SCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1SCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal2SCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2SCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal3SCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3SCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal4SCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4SCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["imagexSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["imagexSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["imagesSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["imagesSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["pgsrdSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["pgsrdSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["pginSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["pginSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["pgoutSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["pgoutSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["filexSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["filexSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["filesSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["filesSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["checkSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["checkSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["multicheckSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["multicheckSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["tabtrSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["tabtrSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["tabtdSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["tabtdSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["tabhdtrSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["tabhdtrSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["tabhdtdSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["tabhdtdSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["oprtSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["oprtSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["chtmlFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["chtmlFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["varcharFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["varcharFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["textFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["textFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["richtextFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["richtextFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["codeFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["codeFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["selectFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["selectFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["multiselectFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["multiselectFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["dateFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["dateFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["datetimeFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["datetimeFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["intFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["intFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["tinyintFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["tinyintFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal1FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal2FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal3FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal4FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["imagexFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["imagexFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["imagesFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["imagesFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["pgsrdFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["pgsrdFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["pginFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["pginFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["pgoutFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["pgoutFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["filexFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["filexFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["filesFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["filesFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["checkFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["checkFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["multicheckFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["multicheckFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["oprtFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["oprtFUNCTION"])).'";'.huanhang();            
            $scriptz=$scriptz.'ccode["contentFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["contentFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["searchdemoFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["searchdemoFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["srdFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["srdFUNCTION"])).'";'.huanhang();
            if ($snox!="0"){
              //执行查找数据
             $strst=SX("select shorttitle,tablename,showkeys,cdt,ordcdt from coode_shortdata where shortid='".$stid."'");        
             $sttt=anyvalue($strst,"shorttitle",0);
             $sttab=anyvalue($strst,"tablename",0);
             $skeys=anyvalue($strst,"showkeys",0);
             $cdtx=anyvalue($strst,"cdt",0);
             $cdtx=str_replace("[uid]",$_COOKIE["uid"],$cdtx);
             $cdtx=str_replace("[cid]",$_COOKIE["cid"],$cdtx);
             $cdty=anyvalue($strst,"orddt",0);
             $keyinfo=thekeyfun($keyinfo,glb(),$sttab,$skeys);      
             $pgcdt=" limit ".((intval($page)-1)*intval($pnum)).",".$pnum; 
              $flrst=selecteds($conn,glb(),"select ".$skeys." from ".$sttab." where ".$cdtx.$cdty.$pgcdt,"utf8","");   
              $totrst=countresult($flrst); 
              $sresult=arrdata($sresult,$flrst);
              $kpart=explode(",",$sresult["table"]["keys"]);
              $totk=count($kpart);
              $totrst=countresult($totrst);
              for ($m=1;$m<$totrst+1;$m++){
                for ($ii=0;$ii<$totk;$ii++){
                $tmpfunxyz="";
                  if ($ccode[$keyinfo[$kpart[$ii]]["COLUMN_DXTYPE"]."FUNCTION"]!=""){
                    $tmpfunxyz=$ccode[$keyinfo[$kpart[$ii]]["COLUMN_DXTYPE"]."FUNCTION"];
                    $tmpfunxyz=$this->itemexc($tmpfunxyz,$stid,$sttab,$kpart[$ii],$sresult["SNO"][$jj],$keyinfo[$kpart[$ii]]["COLUMN_TITLE"],$keyinfo[$kpart[$ii]]["COLUMN_DXTYPE"],0,0,0,0,"");
                    $scriptz=$scriptz.$tmpfunxyz.huanhang();
                  }
                }
              }
            }
            if ($scriptx.$scriptz!=""){              
              return $scriptx.$scriptz;
            }else{
              return "";
            }
          
          break;
    case "Mlist":
          
           
            
            
            $scriptz=$scriptz.'ccode=new Array();'.huanhang();
            
            $scriptz=$scriptz.'ccode["chtml"]="'.str_replace("\"","\\\"",killrn($ccode["chtml"])).'";'.huanhang();
            if (strpos($ccode["chtml"],"unction ")>0){
              $scriptz=$scriptz.$ccode["chtml"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datasno"]="'.str_replace("\"","\\\"",killrn($ccode["datasno"])).'";'.huanhang();
            if (strpos($ccode["datasno"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datasno"].huanhang();
            }
            $scriptz=$scriptz.'ccode["oprtbtn"]="'.str_replace("\"","\\\"",killrn($ccode["oprtbtn"])).'";'.huanhang();
            if (strpos($ccode["oprtbtn"],"unction ")>0){
              $scriptz=$scriptz.$ccode["oprtbtn"].huanhang();
            }
            $scriptz=$scriptz.'ccode["varchar"]="'.str_replace("\"","\\\"",killrn($ccode["varchar"])).'";'.huanhang();
            if (strpos($ccode["varchar"],"unction ")>0){
              $scriptz=$scriptz.$ccode["varchar"].huanhang();
            }
            $scriptz=$scriptz.'ccode["srd"]="'.str_replace("\"","\\\"",killrn($ccode["srd"])).'";'.huanhang();
            if (strpos($ccode["srd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["srd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tabdemo"]="'.str_replace("\"","\\\"",killrn($ccode["tabdemo"])).'";'.huanhang();
            if (strpos($ccode["tabdemo"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tabdemo"].huanhang();
            }
            $scriptz=$scriptz.'ccode["text"]="'.str_replace("\"","\\\"",killrn($ccode["text"])).'";'.huanhang();
            if (strpos($ccode["text"],"unction ")>0){
              $scriptz=$scriptz.$ccode["text"].huanhang();
            }
            $scriptz=$scriptz.'ccode["richtext"]="'.str_replace("\"","\\\"",killrn($ccode["richtext"])).'";'.huanhang();
            if (strpos($ccode["richtext"],"unction ")>0){
              $scriptz=$scriptz.$ccode["richtext"].huanhang();
            }
            $scriptz=$scriptz.'ccode["code"]="'.str_replace("\"","\\\"",killrn($ccode["code"])).'";'.huanhang();
            if (strpos($ccode["code"],"unction ")>0){
              $scriptz=$scriptz.$ccode["code"].huanhang();
            }
            $scriptz=$scriptz.'ccode["select"]="'.str_replace("\"","\\\"",killrn($ccode["select"])).'";'.huanhang();
            if (strpos($ccode["select"],"unction ")>0){
              $scriptz=$scriptz.$ccode["select"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multiselect"]="'.str_replace("\"","\\\"",killrn($ccode["multiselect"])).'";'.huanhang();
            if (strpos($ccode["multiselect"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiselect"].huanhang();
            }
            $scriptz=$scriptz.'ccode["date"]="'.str_replace("\"","\\\"",killrn($ccode["date"])).'";'.huanhang();
            if (strpos($ccode["date"],"unction ")>0){
              $scriptz=$scriptz.$ccode["date"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetime"]="'.str_replace("\"","\\\"",killrn($ccode["datetime"])).'";'.huanhang();
            if (strpos($ccode["datetime"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetime"].huanhang();
            }
            $scriptz=$scriptz.'ccode["int"]="'.str_replace("\"","\\\"",killrn($ccode["int"])).'";'.huanhang();
            if (strpos($ccode["int"],"unction ")>0){
              $scriptz=$scriptz.$ccode["int"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tinyint"]="'.str_replace("\"","\\\"",killrn($ccode["tinyint"])).'";'.huanhang();
            if (strpos($ccode["tinyint"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tinyint"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal1"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1"])).'";'.huanhang();
            if (strpos($ccode["decimal1"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal1"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal2"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2"])).'";'.huanhang();
            if (strpos($ccode["decimal2"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal2"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal3"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3"])).'";'.huanhang();
            if (strpos($ccode["decimal3"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal3"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal4"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4"])).'";'.huanhang();
            if (strpos($ccode["decimal4"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal4"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagex"]="'.str_replace("\"","\\\"",killrn($ccode["imagex"])).'";'.huanhang();
            if (strpos($ccode["imagex"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagex"].huanhang();
            }
            $scriptz=$scriptz.'ccode["images"]="'.str_replace("\"","\\\"",killrn($ccode["images"])).'";'.huanhang();
            if (strpos($ccode["images"],"unction ")>0){
              $scriptz=$scriptz.$ccode["images"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filex"]="'.str_replace("\"","\\\"",killrn($ccode["filex"])).'";'.huanhang();
            if (strpos($ccode["filex"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filex"].huanhang();
            }
            $scriptz=$scriptz.'ccode["files"]="'.str_replace("\"","\\\"",killrn($ccode["files"])).'";'.huanhang();
            if (strpos($ccode["files"],"unction ")>0){
              $scriptz=$scriptz.$ccode["files"].huanhang();
            }
            $scriptz=$scriptz.'ccode["check"]="'.str_replace("\"","\\\"",killrn($ccode["check"])).'";'.huanhang();
            if (strpos($ccode["check"],"unction ")>0){
              $scriptz=$scriptz.$ccode["check"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multicheck"]="'.str_replace("\"","\\\"",killrn($ccode["multicheck"])).'";'.huanhang();
            if (strpos($ccode["multicheck"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multicheck"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datasnoth"]="'.str_replace("\"","\\\"",killrn($ccode["datasnoth"])).'";'.huanhang();
            if (strpos($ccode["datasnoth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datasnoth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["oprtbtnth"]="'.str_replace("\"","\\\"",killrn($ccode["oprtbtnth"])).'";'.huanhang();
            if (strpos($ccode["oprtbtnth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["oprtbtnth"].huanhang();
            }
           $scriptz=$scriptz.'ccode["varcharth"]="'.str_replace("\"","\\\"",killrn($ccode["varcharth"])).'";'.huanhang();
            if (strpos($ccode["varcharth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["varcharth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["textth"]="'.str_replace("\"","\\\"",killrn($ccode["textth"])).'";'.huanhang();
            if (strpos($ccode["textth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["textth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["richtextth"]="'.str_replace("\"","\\\"",killrn($ccode["richtextth"])).'";'.huanhang();
            if (strpos($ccode["richtextth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["richtextth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["codeth"]="'.str_replace("\"","\\\"",killrn($ccode["codeth"])).'";'.huanhang();
            if (strpos($ccode["codeth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["codeth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["selectth"]="'.str_replace("\"","\\\"",killrn($ccode["selectth"])).'";'.huanhang();
            if (strpos($ccode["selectth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["selectth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multiselectth"]="'.str_replace("\"","\\\"",killrn($ccode["multiselectth"])).'";'.huanhang();
            if (strpos($ccode["multiselectth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiselectth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["dateth"]="'.str_replace("\"","\\\"",killrn($ccode["dateth"])).'";'.huanhang();
            if (strpos($ccode["dateth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["dateth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetimeth"]="'.str_replace("\"","\\\"",killrn($ccode["datetimeth"])).'";'.huanhang();
            if (strpos($ccode["datetimeth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetimeth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["intth"]="'.str_replace("\"","\\\"",killrn($ccode["intth"])).'";'.huanhang();
            if (strpos($ccode["intth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["intth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tinyintth"]="'.str_replace("\"","\\\"",killrn($ccode["tinyintth"])).'";'.huanhang();
            if (strpos($ccode["tinyintth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tinyintth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal1th"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1th"])).'";'.huanhang();
            if (strpos($ccode["decimal1th"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal1th"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal2th"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2th"])).'";'.huanhang();
            if (strpos($ccode["decimal2th"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal2th"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal3th"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3th"])).'";'.huanhang();
            if (strpos($ccode["decimal3th"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal3th"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal4th"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4th"])).'";'.huanhang();
            if (strpos($ccode["decimal4th"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal4th"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagexth"]="'.str_replace("\"","\\\"",killrn($ccode["imagexth"])).'";'.huanhang();
            if (strpos($ccode["imagexth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagexth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagesth"]="'.str_replace("\"","\\\"",killrn($ccode["imagesth"])).'";'.huanhang();
            if (strpos($ccode["imagesth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagesth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filexth"]="'.str_replace("\"","\\\"",killrn($ccode["filexth"])).'";'.huanhang();
            if (strpos($ccode["filexth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filexth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filesth"]="'.str_replace("\"","\\\"",killrn($ccode["filesth"])).'";'.huanhang();
            if (strpos($ccode["filesth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filesth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["checkth"]="'.str_replace("\"","\\\"",killrn($ccode["checkth"])).'";'.huanhang();
            if (strpos($ccode["checkth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["checkth"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multicheckth"]="'.str_replace("\"","\\\"",killrn($ccode["multicheckth"])).'";'.huanhang();
            if (strpos($ccode["multicheckth"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multicheckth"].huanhang();
            }
                     $scriptz=$scriptz.'ccode["datasnotd"]="'.str_replace("\"","\\\"",killrn($ccode["datasnotd"])).'";'.huanhang();
            if (strpos($ccode["datasnotd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datasnotd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["oprtbtntd"]="'.str_replace("\"","\\\"",killrn($ccode["oprtbtntd"])).'";'.huanhang();
            if (strpos($ccode["oprtbtntd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["oprtbtntd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["varchartd"]="'.str_replace("\"","\\\"",killrn($ccode["varchartd"])).'";'.huanhang();
            if (strpos($ccode["varchartd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["varchartd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["texttd"]="'.str_replace("\"","\\\"",killrn($ccode["texttd"])).'";'.huanhang();
            if (strpos($ccode["texttd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["texttd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["richtexttd"]="'.str_replace("\"","\\\"",killrn($ccode["richtexttd"])).'";'.huanhang();
            if (strpos($ccode["richtexttd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["richtexttd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["codetd"]="'.str_replace("\"","\\\"",killrn($ccode["codetd"])).'";'.huanhang();
            if (strpos($ccode["codetd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["codetd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["selecttd"]="'.str_replace("\"","\\\"",killrn($ccode["selecttd"])).'";'.huanhang();
            if (strpos($ccode["selecttd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["selecttd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multiselecttd"]="'.str_replace("\"","\\\"",killrn($ccode["multiselecttd"])).'";'.huanhang();
            if (strpos($ccode["multiselecttd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multiselecttd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetd"]="'.str_replace("\"","\\\"",killrn($ccode["datetd"])).'";'.huanhang();
            if (strpos($ccode["datetd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["datetimetd"]="'.str_replace("\"","\\\"",killrn($ccode["datetimetd"])).'";'.huanhang();
            if (strpos($ccode["datetimetd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["datetimetd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["inttd"]="'.str_replace("\"","\\\"",killrn($ccode["inttd"])).'";'.huanhang();
            if (strpos($ccode["inttd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["inttd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tinyinttd"]="'.str_replace("\"","\\\"",killrn($ccode["tinyinttd"])).'";'.huanhang();
            if (strpos($ccode["tinyinttd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tinyinttd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal1td"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1td"])).'";'.huanhang();
            if (strpos($ccode["decimal1td"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal1td"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal2td"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2td"])).'";'.huanhang();
            if (strpos($ccode["decimal2td"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal2td"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal3td"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3td"])).'";'.huanhang();
            if (strpos($ccode["decimal3td"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal3td"].huanhang();
            }
            $scriptz=$scriptz.'ccode["decimal4td"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4td"])).'";'.huanhang();
            if (strpos($ccode["decimal4td"],"unction ")>0){
              $scriptz=$scriptz.$ccode["decimal4td"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagextd"]="'.str_replace("\"","\\\"",killrn($ccode["imagextd"])).'";'.huanhang();
            if (strpos($ccode["imagextd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagextd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["imagestd"]="'.str_replace("\"","\\\"",killrn($ccode["imagestd"])).'";'.huanhang();
            if (strpos($ccode["imagestd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["imagestd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filextd"]="'.str_replace("\"","\\\"",killrn($ccode["filextd"])).'";'.huanhang();
            if (strpos($ccode["filextd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filextd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["filestd"]="'.str_replace("\"","\\\"",killrn($ccode["filestd"])).'";'.huanhang();
            if (strpos($ccode["filestd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["filestd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["checktd"]="'.str_replace("\"","\\\"",killrn($ccode["checktd"])).'";'.huanhang();
            if (strpos($ccode["checktd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["checktd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["multichecktd"]="'.str_replace("\"","\\\"",killrn($ccode["multichecktd"])).'";'.huanhang();
            if (strpos($ccode["multichecktd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["multichecktd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["oprt"]="'.str_replace("\"","\\\"",killrn($ccode["oprt"])).'";'.huanhang();
            if (strpos($ccode["oprt"],"unction ")>0){
              $scriptz=$scriptz.$ccode["oprt"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tabtr"]="'.str_replace("\"","\\\"",killrn($ccode["tabtr"])).'";'.huanhang();
            if (strpos($ccode["tabstr"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tabstr"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tabtd"]="'.str_replace("\"","\\\"",killrn($ccode["tabtd"])).'";'.huanhang();
            if (strpos($ccode["tabtd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tabtd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tabhdtr"]="'.str_replace("\"","\\\"",killrn($ccode["tabhdtr"])).'";'.huanhang();
            if (strpos($ccode["tabhdtr"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tabhdtr"].huanhang();
            }
            $scriptz=$scriptz.'ccode["tabhdtd"]="'.str_replace("\"","\\\"",killrn($ccode["tabhdtd"])).'";'.huanhang();
            if (strpos($ccode["tabhdtd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["tabhdtd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["content"]="'.str_replace("\"","\\\"",killrn($ccode["content"])).'";'.huanhang();
            if (strpos($ccode["content"],"unction ")>0){
              $scriptz=$scriptz.$ccode["content"].huanhang();
            }
            $scriptz=$scriptz.'ccode["pgsrd"]="'.str_replace("\"","\\\"",killrn($ccode["pgsrd"])).'";'.huanhang();
            if (strpos($ccode["pgsrd"],"unction ")>0){
              $scriptz=$scriptz.$ccode["pgsrd"].huanhang();
            }
            $scriptz=$scriptz.'ccode["pgin"]="'.str_replace("\"","\\\"",killrn($ccode["pgin"])).'";'.huanhang();
            if (strpos($ccode["pgin"],"unction ")>0){
              $scriptz=$scriptz.$ccode["pgin"].huanhang();
            }
            $scriptz=$scriptz.'ccode["pgout"]="'.str_replace("\"","\\\"",killrn($ccode["pgout"])).'";'.huanhang();
            if (strpos($ccode["pgout"],"unction ")>0){
              $scriptz=$scriptz.$ccode["pgout"].huanhang();
            }
            $scriptz=$scriptz.'ccode["searchdemo"]="'.str_replace("\"","\\\"",killrn($ccode["searchdemo"])).'";'.huanhang();
            if (strpos($ccode["searchdemo"],"unction ")>0){
              $scriptz=$scriptz.$ccode["searchdemo"].huanhang();
            }
            $scriptz=$scriptz.'ccode["chtmlSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["chtmlSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["varcharSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["varcharSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["contentSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["contentSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["searchdemoSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["searchdemoSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["srdSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["srdSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["textSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["textSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["richtextSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["richtextSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["codeSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["codeSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["selectSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["selectSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["multiselectSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["multiselectSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["dateSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["dateSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["datetimeSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["datetimeSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["intSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["intSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["tinyintSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["tinyintSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal1SCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1SCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal2SCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2SCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal3SCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3SCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal4SCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4SCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["imagexSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["imagexSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["imagesSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["imagesSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["pgsrdSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["pgsrdSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["pginSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["pginSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["pgoutSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["pgoutSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["filexSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["filexSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["filesSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["filesSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["checkSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["checkSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["multicheckSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["multicheckSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["tabtrSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["tabtrSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["tabtdSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["tabtdSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["tabhdtrSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["tabhdtrSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["tabhdtdSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["tabhdtdSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["oprtSCRIPT"]="'.str_replace("\"","\\\"",killrn($ccode["oprtSCRIPT"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["chtmlFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["chtmlFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["varcharFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["varcharFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["textFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["textFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["richtextFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["richtextFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["codeFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["codeFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["selectFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["selectFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["multiselectFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["multiselectFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["dateFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["dateFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["datetimeFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["datetimeFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["intFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["intFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["tinyintFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["tinyintFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal1FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal1FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal2FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal2FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal3FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal3FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["decimal4FUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["decimal4FUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["imagexFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["imagexFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["imagesFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["imagesFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["pgsrdFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["pgsrdFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["pginFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["pginFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["pgoutFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["pgoutFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["filexFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["filexFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["filesFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["filesFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["checkFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["checkFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["multicheckFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["multicheckFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["oprtFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["oprtFUNCTION"])).'";'.huanhang();            
            $scriptz=$scriptz.'ccode["contentFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["contentFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["searchdemoFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["searchdemoFUNCTION"])).'";'.huanhang();
            $scriptz=$scriptz.'ccode["srdFUNCTION"]="'.str_replace("\"","\\\"",killrn($ccode["srdFUNCTION"])).'";'.huanhang();
            if ($snox!="0"){
              //执行查找数据
             $strst=SX("select shorttitle,tablename,showkeys,cdt,ordcdt from coode_shortdata where shortid='".$stid."'");        
             $sttt=anyvalue($strst,"shorttitle",0);
             $sttab=anyvalue($strst,"tablename",0);
             $skeys=anyvalue($strst,"showkeys",0);
             $cdtx=anyvalue($strst,"cdt",0);
             $cdtx=str_replace("[uid]",$_COOKIE["uid"],$cdtx);
             $cdtx=str_replace("[cid]",$_COOKIE["cid"],$cdtx);
             $cdty=anyvalue($strst,"orddt",0);
             $keyinfo=thekeyfun($keyinfo,glb(),$sttab,$skeys);      
             $pgcdt=" limit ".((intval($page)-1)*intval($pnum)).",".$pnum; 
              $flrst=selecteds($conn,glb(),"select ".$skeys." from ".$sttab." where ".$cdtx.$cdty.$pgcdt,"utf8","");   
              $totrst=countresult($flrst); 
              $sresult=arrdata($sresult,$flrst);
              $kpart=explode(",",$sresult["table"]["keys"]);
              $totk=count($kpart);
              $totrst=countresult($totrst);
              for ($m=1;$m<$totrst+1;$m++){
                for ($ii=0;$ii<$totk;$ii++){
                $tmpfunxyz="";
                  if ($ccode[$keyinfo[$kpart[$ii]]["COLUMN_DXTYPE"]."FUNCTION"]!=""){
                    $tmpfunxyz=$ccode[$keyinfo[$kpart[$ii]]["COLUMN_DXTYPE"]."FUNCTION"];
                    $tmpfunxyz=$this->itemexc($tmpfunxyz,$stid,$sttab,$kpart[$ii],$sresult["SNO"][$jj],$keyinfo[$kpart[$ii]]["COLUMN_TITLE"],$keyinfo[$kpart[$ii]]["COLUMN_DXTYPE"],0,0,0,0,"");
                    $scriptz=$scriptz.$tmpfunxyz.huanhang();
                  }
                }
              }
            }
            if ($scriptx.$scriptz!=""){              
              return $scriptx.$scriptz;
            }else{
              return "";
            }
          
          break;
          default:
        }
 
        return "";
 }
}
?>