<?php
class dbshortlist{
public function anylist(){
 $stidd=_get('stid');
 $dbmk=_get('dbmk');
 $datatype=$_GET['datatype'];
 if (strpos($stidd,"]")>0){
  $stidd=str_replace("[","",$stidd);
  $stidd=str_replace("]","",$stidd);
 };
 $pagee=$_GET['page'];
 $pagenumm=$_GET['pnum'];
if (strpos($stidd,"-")>0){
  $sid=qian($stidd,"-");
}else{
  $sid=$stidd;
};
if (strpos($stidd,"pnum:")>0){
  $spnum=qian(qian(hou($stidd,"pnum:"),"-"),"&");
}else{
  $spnum="";
}
if ($pagenumm==""){
 $pagenumm=(intval($spnum)*1);
}
if (_get("pnum")=="0"){
  $pagenumm="0"; 
  $pagee="0";
}
 
 eval(RESFUNSET("formbase"));
 $shortbs=dbshortinfo($dbmk,$sid,$shortbs);
 $datatp=$shortbs["dttp"];
 
if ($datatp=="clstxt" or $datatp=="json"){
  header("location:/localxres/funx/anydbshort/?stid=".$sid."&dbmk=".$dbmk);
}
$caseid=$shortbs["caseid"];
$kies=$shortbs["showkeys"];
$tbnmx=$shortbs["tablename"];
 
if (_get("refresh")=="" or _get("refresh")=="-1"){
  $outurl=combineurl(localroot(),"/localxres/formx/".$dbmk."/".$sid."/index.html");
 if (file_exists($outurl)){ 
  $allhtml=file_get_contents($outurl);
  if ($allhtml!="" and strpos("xx".$allhtml,"failure")<=0){  
   $allhtml=str_replace("[date]",date("YmdHis"),$allhtml);
   return $allhtml;
  }
 }else{
   $furl=thisurl();
   $mvurl=makeviewurl($furl);
   header("location:/localxres/tempx/loading/index.html?pagetype=dbformx&dbmk=".$dbmk."&stid=".$sid."&vurl=".$mvurl);
  //跳转到重新渲染
 }
}else{
  if ($datatype==""){
    $furl=thisurl();
    $mvurl=makeviewurl($furl);
    header("location:/localxres/tempx/loading/index.html?pagetype=dbformx&dbmk=".$dbmk."&stid=".$sid."&vurl=".$mvurl);
  }
}
 eval(RESFUNSET("tabbaseinfo"));
 eval(RESFUNSET("democode"));
 eval(RESFUNSET("formvalue"));
 eval(RESFUNSET("quickvalue"));
 eval(RESFUNSET("baseelehtml"));
 eval(RESFUNSET("tabhtmlmake"));
 $z=UX("delete from coode_dbkeydy where COLUMN_NAME=''");
 $z=UX("delete from coode_dbkeydz where COLUMN_NAME=''");
 $stcss=array();
 $stcss=dbshortcss($dbmk,$sid,$stcss);
 $diytop=$stcss["diytop"];
 $diybottom=$stcss["diybottom"]; 
  $y=UX("update  coode_tiny  set PRIME=1,auditmd5='' where longexp like '%stid=".$sid."%'");  
  $qa=file_get_contents("http://".glw()."localxres/funx/tabcol/?tablename=".$tbnmx."&dbmk=".$dbmk."&cid=".$_COOKIE["cid"]."&uid=".$_COOKIE["uid"]);
  $qc=file_get_contents("http://".glw()."localxres/funx/shortcol/?shortid=".$sid."&dbmk=".$dbmk."&cid=".$_COOKIE["cid"]."&uid=".$_COOKIE["uid"]);
  $qb=file_get_contents("http://".glw()."localxres/funx/shortdft/?shortid=".$sid."&dbmk=".$dbmk."&cid=".$_COOKIE["cid"]."&uid=".$_COOKIE["uid"]);
  $exttf=UX("select count(*) as result from coode_tabheadfun where caseid='".$caseid."' and shortid='".$sid."' and catalog='".$dbmk."'");
  if (intval($exttf)==0){
    $sqle="catalog,tfunmark,tftitle,funtype,shortid,caseid,OLMK";
    $sqlf="'".$dbmk."','".getRandChar(8)."','".$sid."@".$caseid."','tab','".$sid."','".$caseid."','".onlymark()."'";
    $gg=UX("insert into coode_tabheadfun(".$sqle.")values(".$sqlf.")");
  }else{
    $tbheadfun=tostring(UX("select tfuneval as result from coode_tabheadfun where  caseid='".$caseid."' and shortid='".$sid."' and catalog='".$dbmk."'"));
  }
$searchhtml="";
$formeval=tostring(UX("select evalcode as result from coode_makeformact where dumark='".$caseid."'"));
if ($formeval!=""){
 eval($formeval);
 
}
$sttitle=$shortbs["shorttitle"];
$dxtp=_get("datatype");
$trst=SX("select sysid,tabtitle from coode_dbtablist where TABLE_NAME='".$tbnmx."' and catalog='".$dbmk."'");
$ttitle=anyvalue($trst,"tabtitle",0);
$sysid=anyvalue($trst,"sysid",0);
if ($sysid==""){
 $sysid="noname";
}
 $tabjspath="/localxres/tabx/".$dbmk."/".$tbnmx."/".$tbnmx.".js";
 $stjspath="/localxres/tabx/".$dbmk."/".$tbnmx."/".$sid.".js";
$jseval=tostring(UX("select evalcode as result from coode_makedujsfile where dumark='".$caseid."'"));
if ($jseval!=""){
 eval($jseval);
}
if ($ttitle==""){
  $ttitle=$tbnmx;
}
$fmdiv="";
$fmdov="";
$show="1";
$tmprst=SX("select styley,scripty,jsfiley,cssfiley,unittitle,pagesurround,outurl,templatecode from coode_domainunit where dumark='".$caseid."'");
 $mnusno=$pagebase["SNO"];
 $mnuid=$caseid;
 $mnumark=$caseid;
 $unittmpcode=turnlab(tostring(anyvalue($tmprst,"templatecode",0)));
 $jsfilez=tostring(anyvalue($tmprst,"jsfiley",0));
 $jsfilez=str_replace("/localxres/csspagex/","/localxres/tempx/".qian($caseid,".")."/",$jsfilez);
 $cssfilez=tostring(anyvalue($tmprst,"cssfiley",0));
 $cssfilez=str_replace("/localxres/csspagex/","/localxres/tempx/".qian($caseid,".")."/",$cssfilez);
 $scpttxtz=tostring(anyvalue($tmprst,"scripty",0));
 $stltxtz=tostring(anyvalue($tmprst,"styley",0));
 if (_get("refresh")=="2"){
  $dd=UX("update coode_dbstcss set scriptext='".anyvalue($tmprst,"scripty",0)."' where shortid='".$sid."' and catalog='".$dbmk."' and (scriptext='' or scriptext='dT"."YPE_HEX:')");
  $ddx=UX("update coode_dbstcss set styleext='".anyvalue($tmprst,"styley",0)."' where shortid='".$sid."' and catalog='".$dbmk."' and (styleext='' or styleext='dT"."YPE_HEX:')");
 }
   
 $mnuoldh="";
 $pagesurrounda=turnlab(tostring(anyvalue($tmprst,"pagesurround",0)));
 $pagesurroundb=turnlab(tostring(anyvalue($tmprst,"pagesurround",0)));
 $pageoutpath=anyvalue($tmprst,"outurl",0);
 
$conn=mysql_connect(gl(),glu(),glp());
$shortrst=selectedx($conn,glb(),"select SNO,describ,jsfiles,cssfiles,scriptx,stylex,scriptext,styleext,CRTM,UPTM from coode_shortcss where shortid='".$sid."'","utf8","");//比较公私分离是否成功,展示比较用hcss2
$totrst=countresult($shortrst);
if ($totrst>0){
  $shortsno=anyvalue($shortrst,"SNO",0);
  $shortjsf=tostring(anyvalue($shortrst,"jsfiles",0));
  $shortcssf=tostring(anyvalue($shortrst,"cssfiles",0));
  $shortscpt=tostring(anyvalue($shortrst,"scriptx",0));
  $shortstl=tostring(anyvalue($shortrst,"stylex",0)); 
  $scriptext=tostring(anyvalue($shortrst,"scriptext",0));
  $styleext=tostring(anyvalue($shortrst,"styleext",0)); 
  if (_get("refresh")=="2"){
    $scpttxtz=$scriptext;
    $stltxtz=$styleext;
  }
};
  $fmhtml="";  
  $dftjs=$tabjspath."?date=[date];".$stjspath."?date=[date]";
  $mnujsfile=$jsfilez.";".$shortjsf.";".$cssmkjsf.";".$dftjs.";";  
  $mnucssfile=$cssfilez.";".$shortcssf.";".$cssmkcssf.";";
  $duscript='<script type="text/javascript" src="'.$dujspath.'?date=[date]"></script>';
  if ($dujspath==""){
    $mnuscpttxt=$scpttxtz."\r\n".$shortscpt."\r\n".$cssmkscpt."\r\n".$sx."\r\n";
  }else{
    $mnuscpttxt=$scpttxtz."\r\n".$shortscpt."\r\n".$cssmkscpt."\r\n".$sx."\r\n".$duscript;
  }
  $mnustltxt=$stltxtz."\r\n".$shortstl."\r\n".$cssmkstl."\r\n";  
  if ($tbheadfun!=""){
    eval($tbheadfun);    
  }
  
   $controlx=anyfunrun("controler",_get("appid"),"","drt=".String2Hex($diyright));
   $demohtml=str_replace("[controler]",$controlx,$unittmpcode);
   $conthtml=str_replace("[controler]",$controlx,$unittmpcode);
   $rightx="";
   $demohtml=str_replace("[diyright]",$rightx,$demohtml);
   $conthtml=str_replace("[diyright]",$rightx,$conthtml);
  
 
  //一句话复制x 到 y 的short信息----------------------
     $sqlxxx="TABLE_CATALOG,TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,ORDINAL_POSITION,COLUMN_DEFAULT,IS_NULLABLE,DATA_TYPE,CHARACTER_MAXIMUM_LENGTH,CHARACTER_OCTET_LENGTH,NUMERIC_PRECISION,NUMERIC_SCALE,DATETIME_PRECISION,CHARACTER_SET_NAME,COLLATION_NAME,COLUMN_TYPE,COLUMN_KEY,EXTRA,PRIVILEGES,COLUMN_COMMENT,CRTM,OLMK,PTOF,classp,keytitle,keyexplain,UPTM,clstxt,dxtype,sysshowfun,valuezero,jspostfun,syspostfun,changeable,acthtml,atnhtml,displayed";              
      $sqlm="insert into coode_dbkeydy(".$sqlxxx.",shortid,CRTOR)select ".$sqlxxx.",'".$sid."','".$_COOKIE["uid"]."' from coode_dbkeydx where TABLE_NAME='".$tbnmx."' and '".$shortbs["showkeys"].",' like concat('%',COLUMN_NAME,',%') and concat('".$sid."',TABLE_NAME,COLUMN_NAME) not in (select concat(shortid,TABLE_NAME,COLUMN_NAME) from coode_dbkeydy)";
      $sqln="insert into coode_dbkeydz(".$sqlxxx.",shortid,CRTOR)select ".$sqlxxx.",'".$sid."','".$_COOKIE["uid"]."' from coode_dbkeydx where TABLE_NAME='".$tbnmx."' and '".$shortbs["showkeys"].",' like concat('%',COLUMN_NAME,',%') and concat('".$sid."',TABLE_NAME,COLUMN_NAME) not in (select concat(shortid,TABLE_NAME,COLUMN_NAME) from coode_dbkeydz)";
     $zz=UX($sqlm);
     $zz=UX($sqln);      
      $nprx=UX("update coode_dbkeydy set displayed=0 where COLUMN_NAME='OPRT' or COLUMN_NAME='itemOprt'");
      $killy=UX("delete from coode_dbkeydy where COLUMN_NAME=''");                        
      $killy=UX("delete from coode_dbkeydz where COLUMN_NAME=''");     
      //-------------------------------
 $dinfo=array();
 $dinfo=takedbinfo($dbmk,$tbnmx,$dinfo);
 //var_dump($dinfo);
  $sceval=tostring(UX("select evalcode as result from coode_casesearch where caseid='".$caseid."' and shortid='".$sid."'"));
  if ($sceval!=""){
    eval($sceval);
  }
   $demohtml=str_replace("[tabnm]",$tbnmx,$demohtml);
   $demohtml=str_replace("[tabkeys]",$shortbs["showkeys"],$demohtml);
   $demohtml=str_replace("[pskey]",$dinfo["pskey"],$demohtml);
   $demohtml=str_replace("[pstitle]",$dinfo["pstitle"],$demohtml);
   $demohtml=str_replace("[pshead]",$dinfo["pshead"],$demohtml);
   $demohtml=str_replace("[pssno]",$dinfo["pssno"],$demohtml);
   
   $conthtml=str_replace("[tabnm]",$tbnmx,$conthtml);
   $conthtml=str_replace("[tabkeys]",$shortbs["showkeys"],$conthtml);
   $conthtml=str_replace("[pskey]",$dinfo["pskey"],$conthtml);
   $conthtml=str_replace("[pstitle]",$dinfo["pstitle"],$conthtml);
   $conthtml=str_replace("[pshead]",$dinfo["pshead"],$conthtml);
   $conthtml=str_replace("[pssno]",$dinfo["pssno"],$conthtml); 
   $demohtml=str_replace("[addform]",$addform,$demohtml);
   $conthtml=str_replace("[addform]",$addform,$conthtml);         
   $conthtml=str_replace("[searchdemo]",$searchhtml,$conthtml); 
   $demohtml=str_replace("[searchdemo]",$searchhtml,$demohtml); 
   $demohtml=str_replace("[diytop]",extdemo($diytop,$sid,$tbnmx),$demohtml);
   $conthtml=str_replace("[diytop]",extdemo($diytop,$sid,$tbnmx),$conthtml);
   $demohtml=str_replace("[diybottom]",extdemo($diybottom,$sid,$tbnmx),$demohtml);
   $conthtml=str_replace("[diybottom]",extdemo($diybottom,$sid,$tbnmx),$conthtml);  
   $tabpage=turnlab(getcodedemo("pgsrd",qian($caseid,"."),hou($caseid,".")));
   $demohtml=str_replace("[tabpage]",$tabpage,$demohtml);
   $conthtml=str_replace("[tabpage]",$tabpage,$conthtml);
   $demohtml=str_replace("[shortid]",$sid,$demohtml);
   $conthtml=str_replace("[shortid]",$sid,$conthtml);
   $demohtml=str_replace("[tbhead]","",$demohtml);
   $conthtml=str_replace("[tbhead]","",$conthtml);
   $demohtml=str_replace("[shorttitle]",$sttitle,$demohtml);
   $conthtml=str_replace("[shorttitle]",$sttitle,$conthtml); 
  $fmhtml=$pagesurrounda;
  $fmdemo=$pagesurroundb;
  $fmhtml=str_replace("<!--thesecomJSFILES-->",formjs($mnujsfile),$fmhtml);   
  $fmdemo=str_replace("<!--thesecomJSFILES-->",formjs($mnujsfile),$fmdemo);    
  $fmhtml=str_replace("<!--thiscomHTML-->", $conthtml,$fmhtml); 
  $fmdemo=str_replace("<!--thiscomHTML-->", $demohtml,$fmdemo);    
  if ($sttitle!=""){
    $fmhtml=str_replace("<!--thistitle-->",$sttitle,$fmhtml);
    $fmdemo=str_replace("<!--thistitle-->",$sttitle,$fmdemo);
  }else{
    $fmhtml=str_replace("<!--thistitle-->",$ttitle."-".$sid."子表",$fmhtml);
    $fmdemo=str_replace("<!--thistitle-->",$ttitle."-".$sid."子表",$fmdemo);
  }
  $fmhtml=str_replace("<!--thesecomCSSFILES-->",formcss($mnucssfile),$fmhtml);
  $fmdemo=str_replace("<!--thesecomCSSFILES-->",formcss($mnucssfile),$fmdemo);
  $fmhtml=str_replace("<!--thiscomSTYLE-->",$mnustltxt.$mnucssext,$fmhtml);
  $fmdemo=str_replace("<!--thiscomSTYLE-->",$mnustltxt.$mnucssext,$fmdemo);
  $fmhtml=str_replace("<!--thiscomSCRIPT-->",$mnuscpttxt.$mnujsext,$fmhtml); 
  $fmdemo=str_replace("<!--thiscomSCRIPT-->",$mnuscpttxt.$mnujsext,$fmdemo);   
  $fmhtml=str_replace("[date]",date("YmdHis"),$fmhtml);
  $fmdemo=str_replace("{date}",date("YmdHis"),$fmdemo); 
  $nkdemo=makeformkdemo("tab",$sid);
      if ($fmhtml==""){
       if ($datatype=="json"){
         return makereturnjson("0","渲染失败，无数据","");
       }else{
         return "no data.";
       }
      }else{
        $outurl=combineurl(localroot(),"/localxres/formx/".$dbmk."/".$sid."/index.html");
        $zz=overfile($outurl,$fmhtml);
        $fmhtml=str_replace("[date]",date("YmdHis"),$fmhtml);
        $fmdemo=str_replace("{date}",date("YmdHis"),$fmdemo);         
        if ($datatype=="json"){
           return makereturnjson("1","渲染完毕","");
        }else{
           return $fmhtml;
        }
      }
 }
}
?>