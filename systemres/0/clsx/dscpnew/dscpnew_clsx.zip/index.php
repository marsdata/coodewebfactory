<?php
class dscpnew{
 public function anydetail($dsid,$csid,$rfrs){ 
   if ($rfrs==""){
   $outurl=combineurl(localroot(),"/localxres/formx/".$csid."/thishostcore/".$dsid."/"._cookie("cid")."-detail.html");
   $allhtml=file_get_contents($outurl);
   if ($allhtml!="" and strpos("xx".$allhtml,"failure")<=0){    
    $allhtml=str_replace("[date]",date("YmdHis"),$allhtml);  
    return $allhtml;
   }
  }  
  $detailid=$csid;
  $dourst=SX("select scripty,styley,jsfiley,cssfiley,pagesurround,casecode,templatecode from coode_domainunit where dumark='".$detailid."'"); 
  $unittmpcode=turnlab(tostring(anyvalue($dourst,"templatecode",0)));
  $scripty=tostring(anyvalue($dourst,"scripty",0));
  $mnustltxt=$stltxtz;
  $styley=tostring(anyvalue($dourst,"styley",0));
  $jsfiley=tostring(anyvalue($dourst,"jsfiley",0));
  $jsfiley=str_replace("/localxres/csspagex/","/localxres/tempx/".qian($detailid,".")."/",$jsfiley);
  $cssfiley=tostring(anyvalue($dourst,"cssfiley",0));
  $cssfiley=str_replace("/localxres/csspagex/","/localxres/tempx/".qian($detailid,".")."/",$cssfiley);
  $pagesurround=turnlab(tostring(anyvalue($dourst,"pagesurround",0)));
  $casecode=tostring(anyvalue($dourst,"casecode",0));
  $stcss=array();
  $scriptx=$stcss["scriptx"];
  $stylex=$stcss["stylex"];
  $jsfilex=$stcss["jsfilex"];
  $cssfilex=$stcss["cssfilex"];
  $scriptext=$stcss["scriptext"];
  $styleext=$stcss["styleext"];
  $arrdx=array(array());
  $diytop=$stcss["diytop"];
  $diytop=extdemo($diytop,$stid,$tabname);
  $diybottom=$stcss["diybottom"];
  $diybottom=extdemo($diybottom,$stid,$tabname);
  $formsrd=$unittmpcode; 
  
   $diytop="";
   $diybottom="";
   $formsrd=str_replace("[diytop]",$diytop,$formsrd);
   $formsrd=str_replace("[diybottom]",$diybottom,$formsrd);
   $formsrd=str_replace("savex","savey",$formsrd);
   $formsrd=str_replace("newx","savey",$formsrd);
   $formsrd=str_replace("newz","savey",$formsrd);
   $fmhtml=$pagesurround;
     $scripty=str_replace("inititem","inititemx",$scripty);
     $scriptx=str_replace("inititem","inititemx",$scriptx);
     $fmhtml=str_replace("<!--thistitle-->",$dstitle,$fmhtml);   
     $fmhtml=str_replace("<!--thesecomJSFILES-->",formjs($jsfiley.";".$dftjs.";".$jsfilex.";"),$fmhtml);
     $fmhtml=str_replace("<!--thesecomCSSFILES-->",formcss($cssfiley.";".$cssfilex),$fmhtml);
     $fmhtml=str_replace("<!--thiscomSTYLE-->",$styley.$stylex,$fmhtml);
     $fmhtml=str_replace("<!--thiscomSCRIPT-->",$scripty.$scriptx,$fmhtml);
     $fmhtml=str_replace("<!--thiscomHTML-->",$formsrd,$fmhtml);
     $fmhtml=str_replace("[date]",date("YmdHis"),$fmhtml);     
     $outurl=combineurl(localroot(),"/localxres/formx/".$csid."/thishostcore/".$dsid."/"._cookie("cid")."-detail.html");
     $zz=overfile($outurl,$fmhtml);
     return $fmhtml;
 }//fun
}//cls
?>