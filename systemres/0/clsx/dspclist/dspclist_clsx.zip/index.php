<?php
class dspclist{
 public function anylist($dsid,$csid,$rfrs){
 $caseid=$csid;
 if ($rfrs==""){
  $outurl=combineurl(localroot(),"/localxres/dataspacex/".$dsid."/"._cookie("cid")."-index.html");
  $allhtml=file_get_contents($outurl);
  if ($allhtml!="" and strpos("xx".$allhtml,"failure")<=0){  
   $allhtml=str_replace("[date]",date("YmdHis"),$allhtml);
   return $allhtml;
  }else{
    return "no-data.";
  }
 }else{
  $searchhtml="";
  $fmdiv="";
  $fmdov="";
  $show="1";
  $tmprst=SX("select styley,scripty,jsfiley,cssfiley,unittitle,pagesurround,outurl,templatecode from coode_domainunit where dumark='".$caseid."'");
  $mnuid=$caseid;
  $mnumark=$caseid;
  $unittmpcode=turnlab(tostring(anyvalue($tmprst,"templatecode",0)));
  $jsfilez=tostring(anyvalue($tmprst,"jsfiley",0));
  $jsfilez=str_replace("/localxres/csspagex/","/localxres/tempx/".qian($caseid,".")."/",$jsfilez);
  $cssfilez=tostring(anyvalue($tmprst,"cssfiley",0));
  $cssfilez=str_replace("/localxres/csspagex/","/localxres/tempx/".qian($caseid,".")."/",$cssfilez);
  $scpttxtz=tostring(anyvalue($tmprst,"scripty",0));
  $stltxtz=tostring(anyvalue($tmprst,"styley",0));
  $mnuoldh="";
  $pagesurrounda=turnlab(tostring(anyvalue($tmprst,"pagesurround",0)));
  $pagesurroundb=turnlab(tostring(anyvalue($tmprst,"pagesurround",0)));
  $pageoutpath=anyvalue($tmprst,"outurl",0);
  $fmhtml="";  
  $mnujsfile=$jsfilez.";".$shortjsf.";".$cssmkjsf.";".$dftjs.";";  
  $mnucssfile=$cssfilez.";".$shortcssf.";".$cssmkcssf.";";  
  if ($dujspath==""){
    $mnuscpttxt=$scpttxtz."\r\n".$shortscpt."\r\n".$cssmkscpt."\r\n".$sx."\r\n";
  }else{
    $mnuscpttxt=$scpttxtz."\r\n".$shortscpt."\r\n".$cssmkscpt."\r\n".$sx."\r\n".$duscript;
  }
  $mnustltxt=$stltxtz."\r\n".$shortstl."\r\n".$cssmkstl."\r\n";  
  $mnuscpttxt=str_replace("initdata","initdatax",$mnuscpttxt);
  $demohtml=$unittmpcode;
  $conthtml=$unittmpcode;   
  $fmhtml=$pagesurrounda;
  $fmdemo=$pagesurroundb;
  $fmhtml=str_replace("<!--thesecomJSFILES-->",formjs($mnujsfile),$fmhtml);   
  $fmdemo=str_replace("<!--thesecomJSFILES-->",formjs($mnujsfile),$fmdemo);    
  $fmhtml=str_replace("<!--thiscomHTML-->", $conthtml,$fmhtml); 
  $fmdemo=str_replace("<!--thiscomHTML-->", $demohtml,$fmdemo);    
  $fmhtml=str_replace("<!--thistitle-->",$dsid,$fmhtml);
  $fmdemo=str_replace("<!--thistitle-->",$dsid,$fmdemo);
  $fmhtml=str_replace("<!--thesecomCSSFILES-->",formcss($mnucssfile),$fmhtml);
  $fmdemo=str_replace("<!--thesecomCSSFILES-->",formcss($mnucssfile),$fmdemo);
  $fmhtml=str_replace("<!--thiscomSTYLE-->",$mnustltxt.$mnucssext,$fmhtml);
  $fmdemo=str_replace("<!--thiscomSTYLE-->",$mnustltxt.$mnucssext,$fmdemo);
  $fmhtml=str_replace("<!--thiscomSCRIPT-->",$mnuscpttxt.$mnujsext,$fmhtml); 
  $fmdemo=str_replace("<!--thiscomSCRIPT-->",$mnuscpttxt.$mnujsext,$fmdemo);   
  $fmhtml=str_replace("[date]",date("YmdHis"),$fmhtml);
  $fmdemo=str_replace("{date}",date("YmdHis"),$fmdemo); 
  if ($fmhtml==""){
       return "no data.";
  }else{
        $outurl=combineurl(localroot(),"/localxres/dataspacex/".$dsid."/"._cookie("cid")."-index.html");
        $zz=overfile($outurl,$fmhtml);        
        return $fmhtml;
  }
 }
}
}
?>