<?php
class excoor{
  function txtobaidu($longitude,$latitude){
    //GPS到百度
   //百度地图坐标转换官网：http://lbsyun.baidu.com/index.php?title=webapi/guide/changeposition
    $q = "http://api.map.baidu.com/geoconv/v1/?coords=".$longitude.",".$latitude."&from=1&to=5&ak=NQFDhNsO7tHVsEGdGQb0TZYfMDTdZ5FH";
    $resultQ = json_decode(file_get_contents($q),true);
    $latitudeNew = $resultQ["result"][0]["y"];
    $longitudeNew = $resultQ["result"][0]["x"];
    //$returnDataArray = array("latitudeNew"=>$latitudeNew,"longitudeNew"=>$longitudeNew);
    return $longitudeNew.",".$latitudeNew;
  }
  function txtogaode($longitude,$latitude){
  //GPS到火星
   //百度地图坐标转换官网：http://lbsyun.baidu.com/index.php?title=webapi/guide/changeposition
    $q = "http://api.map.baidu.com/geoconv/v1/?coords=".$longitude.",".$latitude."&from=1&to=3&ak=NQFDhNsO7tHVsEGdGQb0TZYfMDTdZ5FH";
    $resultQ = json_decode(file_get_contents($q),true);
    
    $latitudeNew = $resultQ["result"][0]["y"];
    $longitudeNew = $resultQ["result"][0]["x"];
    //$returnDataArray = array("latitudeNew"=>$latitudeNew,"longitudeNew"=>$longitudeNew);
    return $longitudeNew.",".$latitudeNew;
 }
}
?>