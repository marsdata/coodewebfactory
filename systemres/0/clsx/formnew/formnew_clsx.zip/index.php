<?php
class formnew{
 public function anydetail($stid,$rfrs){ 
  if ($rfrs==""){
   $allhtml=UX("select storage as result from coode_shortaffect where CRTM=UPTM and shortid='".$stid."_DETAIL' ");
   if ($allhtml!="" and strpos("xx".$allhtml,"failure")<=0){
    $allhtml=tostring($allhtml);
    $allhtml=str_replace("[date]",date("YmdHis"),$allhtml);  
    return $allhtml;
   }
  }
 eval(RESFUNSET("democode"));
 eval(RESFUNSET("formbase"));
 eval(RESFUNSET("keyfunbase"));
  $stbase=array();
  $stbase=shortinfo($stid,$stbase);
  $stcss=array();
  $stcss=shortcss($stid."DETAIL",$stcss);
  $detailid=$stbase["detailid"];
  $shorttitle=$stbase["shorttitle"];
  $tabname=$stbase["tablename"];
  $dourst=SX("select scripty,styley,jsfiley,cssfiley,pagesurround,casecode from coode_domainunit where dumark='".$detailid."'");
  
  $scripty=tostring(anyvalue($dourst,"scripty",0));
  $styley=tostring(anyvalue($dourst,"styley",0));
  $jsfiley=tostring(anyvalue($dourst,"jsfiley",0));
  $cssfiley=tostring(anyvalue($dourst,"cssfiley",0));
  $pagesurround=turnlab(tostring(anyvalue($dourst,"pagesurround",0)));
  $casecode=tostring(anyvalue($dourst,"casecode",0));
  
  $scriptx=$stcss["scriptx"];
  $stylex=$stcss["stylex"];
  $jsfilex=$stcss["jsfilex"];
  $cssfilex=$stcss["cssfilex"];
  $arrdx=array(array());
  $diytop=$stcss["diytop"];
  $diytop=fmvalue($tabname,"自定义顶部",0,"DIYTOP", $diytop,0,$arrdx);
  $diybottom=$stcss["diybottom"];
  $diybottom=fmvalue($tabname,"自定义底部",0,"DIYBOTTOM", $diybottom,0,$arrdx);
  $diybutton=$stcss["diybutton"];
  $diybutton=fmvalue($tabname,"自定义按钮",0,"DIYBTN", $diybutton,0,$arrdx);
  $diyshow=$stcss["diyshow"];
  $diyshow=fmvalue($tabname,"自定义展示",0,"DIYSHOW", $diyshow,0,$arrdx);
  $bottombutton=$stcss["bottombutton"];
  $bottombutton=fmvalue($tabname,"自定义底部按钮",0,"DIYBTMBTN", $bottombutton,0,$arrdx);
  
  
  
  $keybase=array();
  $keybase=thekeyfun($keybase,glb(),"SHORTID",$stid);
  
   if ($casecode!=""){
    eval($casecode);
   };
   
   $formsrd=turnlab($ccode["srd"]);   
   $itemsrd=turnlab($ccode["itemsrd"]);
   $inline=turnlab($ccode["inline"]);
   $onerow=turnlab($ccode["onerow"]);
  
   
   $keyrst=SX("select SNO,COLUMN_NAME,SQX from coode_keydetaily where shortid='".$stid."' group by FLOOR(SQX) order by SQX");
   $totk=countresult($keyrst); 
   for ($j=0;$j<$totk;$j++){
    $ksqx[$j]=anyvalue($keyrst,"SQX",$j);
   }
   $fmrow="";
   $cgcode[0]="readonly";
   $cgcode[1]="";
   $dscode[0]="display:none;";
   $dscode[1]="";
   for ($j=0;$j<$totk;$j++){
     $rowkeys=SX("select SNO,COLUMN_NAME,SQX,keytitle,changeable,displayed,sysshowfun,dxtype from coode_keydetaily where FLOOR(SQX)=".$ksqx[$j]." and shortid='".$stid."'");
     $totr=countresult($rowkeys);
     $srddemo=$itemsrd;
     $fmrx="";
     if ($totr==1){
       $onedemo=$onerow;
       $colname=anyvalue($rowkeys,"COLUMN_NAME",0);
       $sqx=anyvalue($rowkeys,"SQX",0);
       $coltitle=anyvalue($rowkeys,"keytitle",0);
       $cgable=intval(anyvalue($rowkeys,"changeable",$k));
       $dspl=intval(anyvalue($rowkeys,"displayed",$k));
       $dxtp=anyvalue($rowkeys,"dxtype",0); 
       $onedemo=str_replace("[key]",$colname,$onedemo);
       $onedemo=str_replace("[title]",$coltitle,$onedemo);
       $onedemo=str_replace("[dxtp]",$dxtp,$onedemo);
       $onedemo=str_replace("[rdol]",$cgcode[$cgable],$onedemo);
       $onedemo=str_replace("[dspl]",$dscode[$dspl],$onedemo);
       $onedemo=str_replace("{key}",$colname,$onedemo);
       $onedemo=str_replace("{title}",$coltitle,$onedemo);
       $onedemo=str_replace("{dxtp}",$dxtp,$onedemo);
       $onedemo=str_replace("{rdol}",$cgcode[$cgable],$onedemo);
       $onedemo=str_replace("{dspl}",$dscode[$dspl],$onedemo);
       $fmrx=$onedemo;
     }else{      
      for ($k=0;$k<$totr;$k++){
       $onedemo=$inline;
       $colname=anyvalue($rowkeys,"COLUMN_NAME",$k);
       $sqx=anyvalue($rowkeys,"SQX",$k);
       $coltitle=anyvalue($rowkeys,"keytitle",$k);
       $cgable=intval(anyvalue($rowkeys,"changeable",$k));
       $dspl=intval(anyvalue($rowkeys,"displayed",$k));
       $dxtp=anyvalue($rowkeys,"dxtype",$k);
       $onedemo=str_replace("[key]",$colname,$onedemo);
       $onedemo=str_replace("[title]",$coltitle,$onedemo);
       $onedemo=str_replace("[dxtp]",$dxtp,$onedemo);
       $onedemo=str_replace("[rdol]",$cgcode[$cgable],$onedemo);
       $onedemo=str_replace("[dspl]",$dscode[$dspl],$onedemo);
       $onedemo=str_replace("{key}",$colname,$onedemo);
       $onedemo=str_replace("{title}",$coltitle,$onedemo);
       $onedemo=str_replace("{dxtp}",$dxtp,$onedemo);
       $onedemo=str_replace("{rdol}",$cgcode[$cgable],$onedemo);
       $onedemo=str_replace("{dspl}",$dscode[$dspl],$onedemo);
       $fmrx=$fmrx.$onedemo;
      }//totr for
     }//totr=1
     $srddemo=str_replace("[inner]",$fmrx,$srddemo);
     $srddemo=str_replace("{inner}",$fmrx,$srddemo);
     $fmrow=$fmrow.$srddemo;
   }//for j totk
   $formsrd=str_replace("[srdinner]",$fmrow,$formsrd);
   $formsrd=str_replace("[diytop]",$diytop,$formsrd);
   $formsrd=str_replace("[diybutton]",$diybutton,$formsrd);
   $formsrd=str_replace("[diybottom]",$diybottom,$formsrd);
   $formsrd=str_replace("[diyshow]",$diyshow,$formsrd);
   $formsrd=str_replace("[bottombutton]",$bottombutton,$formsrd);
   $formsrd=str_replace("[showkeys]",$stbase["showkeys"],$formsrd);
   $formsrd=str_replace("[tabnm]",$tabname,$formsrd);
   $formsrd=str_replace("[tabname]",$tabname,$formsrd);
   $formsrd=str_replace("[tablename]",$tabname,$formsrd);
   $formsrd=str_replace("[stid]",$stid,$formsrd);
   $formsrd=str_replace("[shortid]",$stid,$formsrd);
   $formsrd=str_replace("{srdinner}",$fmrow,$formsrd);
   $formsrd=str_replace("{diytop}",$diytop,$formsrd);
   $formsrd=str_replace("{diybutton}",$diybutton,$formsrd);
   $formsrd=str_replace("{diybottom}",$diybottom,$formsrd);
   $formsrd=str_replace("{diyshow}",$diyshow,$formsrd);
   $formsrd=str_replace("{bottombutton}",$bottombutton,$formsrd);
   $formsrd=str_replace("{showkeys}",$stbase{"showkeys"},$formsrd);
   $formsrd=str_replace("{tabnm}",$tabname,$formsrd);
   $formsrd=str_replace("{tabname}",$tabname,$formsrd);
   $formsrd=str_replace("{tablename}",$tabname,$formsrd);
   $formsrd=str_replace("{stid}",$stid,$formsrd);
   $formsrd=str_replace("{shortid}",$stid,$formsrd);
   $fmhtml=$pagesurround;
   $dftjs="/DNA/DFT/".$tabname.".js?date=[date];/DNA/DFT/".$stid.".js?date=[date]";
   $fmhtml=str_replace("<!--thistitle-->",$shorttitle,$fmhtml);
   $fmhtml=str_replace("<!--thesecomJSFILES-->",formjs($jsfilex.";".$jsfiley.";".$dftjs),$fmhtml);
   $fmhtml=str_replace("<!--thesecomCSSFILES-->",formcss($cssfilex.";".$cssfiley),$fmhtml);
   $fmhtml=str_replace("<!--thiscomSTYLE-->",$stylex.$styley,$fmhtml);
   $fmhtml=str_replace("<!--thiscomSCRIPT-->",$scriptx.$scripty,$fmhtml);
   $fmhtml=str_replace("<!--thiscomHTML-->",$formsrd,$fmhtml);
   $fmhtml=str_replace("[date]",date("YmdHis"),$fmhtml);
   $tots=UX("select count(*) as result from coode_shortaffect where  shortid='".$stid."_DETAIL' ");
    if ($tots>0){
      $sqlz=UX("update coode_shortaffect set storage='".gohex($fmhtml)."',UPTM=now(),CRTM=now() where shortid='".$stid."_DETAIL' ");
    }else{
      $sqlx="shortid,storage,CRTM,UPTM,STATUS,CRTOR,OLMK";
      $sqly="'".$stid."_DETAIL','".gohex($fmhtml)."',now(),now(),1,'".$_COOKIE["uid"]."','".onlymark()."'";
      $z=UX("insert into coode_shortaffect(".$sqlx.")values(".$sqly.")");
    }
   return  $fmhtml;
 }//fun
}//cls
?>