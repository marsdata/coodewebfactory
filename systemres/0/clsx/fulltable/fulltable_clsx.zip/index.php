<?php
class fulltable{
  public function anyfulltblist($stid,$ffrm,$ffdt,$fps,$fbs,$tbnm,$tbkis,$tbcdtn,$dtp,$surl,$odcdt){ 
 $fmkeyn="";
 
 eval(RESFUNSET("democode"));
 $appid=_get("appid");
  $xid="";
  $xid=$stid;
  $_GET["tmpshortid"]=$xid;
  $appid=$_GET["appid"];  
  if (strpos($dtar,",")>0){
   $ptdta=explode(",",$dtar);
   $totpd=count($ptdta);
   $tmpzs=1;
   $fmzone="";
  }else{
    $totpd=0;
  }   
 if ($fip==""){
  $fip=gl();
 };
 if ($fus==""){
  $fus=glu();
 };
 if ($fbs==""){
  $fbs=glb();
 }else{
   if ($fps==""){
     $cmk=$fbs;
   }
   $fbs=glb();
 };  
  if ($fps==""){
    $fps=glp();
  };  
 if (strpos($tbcdtn,"=")>0 or strpos($tbcdtn,">")>0 or strpos($tbcdtn,"<")>0  or strpos($tbcdtn,"null")>0 or strpos($tbcdtn,"like")>0){
    $tmpcdts=$tbcdtn;
  }else{
    if ($tbcdtn!="" and str_replace(" ","",$tbcdtn)!=""){
     $tmpcdts=Hex2String($tbcdtn);
    }else{
     $tmpcdts="";
    };
  };
  if (dftval($_GET["dbnm"],"")==""){
    $shortbase=shortinfo($xid,$shortbase);
  }else{
    $shortbase=dbshortinfo(dftval($_GET["dbnm"],""),$xid,$shortbase);
  }
  $diycode=$shortbase["diycode"];
  $addpage=$shortbase["addpage"];
  $addtitle=$shortbase["addtitle"];
  $sttbnm=$shortbase["tablename"];
  $caseid=$shortbase["caseid"];
  $shorttitle=$shortbase["shorttitle"];
  $updatepage=$shortbase["updatepage"];
  $detailpage=$shortbase["detailpage"];
  $additemx=$shortbase["additemx"];
  $newbutton=$shortbase["newbutton"];
  $obtn=$shortbase["obtn"];
  $vbtn=$shortbase["vbtn"];
  $xbtn=$shortbase["xbtn"];
  $oprtx=$shortbase["oprtx"];
  $headx=$shortbase["headx"];
  $stcss=array();
  $stcss=shortcss($xid,$stcss);
  $diytop=$stcss["diytop"];
  $sps=$stcss["sps"];
  $diybottom=$stcss["diybottom"];
  $topbtn=$shortbase["topbtn"];
  $bottombtn=$shortbase["bottombtn"];
  $tbhd=$shortbase["tbhd"];
  $dtx=$shortbase["dtx"];
  $ctraw=$shortbase["ctraw"];
  $allkillbtn=$shortbase["allkillbtn"];
  $stcode=$shortbase["STCODE"];  
  $gsqc=$_GET["sqc"];
   $dinfo=array();
   if ($caseid!=""){          
     $tabsrd=turnlab(tostring(getcodedemo("srd",qian($caseid,"."),hou($caseid,"."))));
     $tabtrdemo=turnlab(tostring(getcodedemo("tabtr",qian($caseid,"."),hou($caseid,".")))); 
     $tabtddemo=turnlab(tostring(getcodedemo("tabtd",qian($caseid,"."),hou($caseid,".")))); 
   }
  if ($dtp=="imgx"){    
    $csurd=turnlab(getcodedemo("srd",qian($caseid,"."),hou($caseid,".")));
    $chtml=turnlab(getcodedemo("chtml",qian($caseid,"."),hou($caseid,".")));
  };
  $fmch="";
  $demo=""; 
  
  
  $tabdemo=$shortbase["tabdemo"];  
  $headdemo=$shortbase["headdemo"];  
  $pagedemo=$shortbase["pagedemo"];  
  $fmtbasex=formatbase(qian($dtp,"/"),$fmtbasex);  
  $fmtbasex["dkeyexc"]=$stcode;
  
  if (strpos($tbnm,",")>0 and strpos($tbkis,",")<=0){
    $ncdts=fmcdt($tbnm,$tbkis);
    $gkinfo=allkeyinfo($gkinfo,glb(),$tbnm);
    $tbkis=$gkinfo["COLUMN"]["ALLKEY"];
    $tbtkis=$gkinfo["COLUMN"]["ALLTKEY"];
    $ntbkis=makekey($tbtkis);
    $tbkis=$ntbkis;
    $tbcdts=$ncdts;
    if (strpos($tbnm,",")>0){
      $tbnm=substr($tbnm,0,strlen($tbnm)-1);
    };
}else{
 if ($tbkis=="*" or $tbkis==""){
  $gkinfo=allkeyinfo($gkinfo,glb(),$tbnm);
  $tbkis=$gkinfo["COLUMN"]["ALLKEY"];
 };
};
  if ($tbcdts=="" and $tmpcdts==""){
   $tbcdts=" 1>0 ";
  }else{
   if ($tbcdts!="" and $tmpcdts!=""){
     $tbcdts=$tbcdts." and ".$tmpcdts;
   }else{
     $tbcdts=$tbcdts." ".$tmpcdts;
   };
  };
 if ($tbkis==""){
  $tbkis="SNO";
 };
 
 $stbkis="";
  if ($ffdt!="" and $ffrm==""){
    $wtokis=$ffdt; 
  };
 if (strpos($tbkis,",")>0){
   $kppart=explode(",",$tbkis);
   $totkp=count($kppart);
   for ($k=0;$k<$totkp;$k++){
    if (strpos("_".$wtokis,$kppart[$k].",")>0){
    }else{
       $stbkis=$stbkis.$kppart[$k].",";
    };
   };
  }else{//不大于零 且=* 或空 不正常的情况下找
   if ($tbkis=="*" or $tbkis==""){
    $alif=allkeyinfo($alif,glb(),$tbnm);
    $kppart=explode(",",$alif["COLUMN"]["ALLKEY"]);
    $totkp=count($kppart);
    for ($k=0;$k<$totkp;$k++){
     if (strpos("_".$wtokis,$kppart[$k].",")>0){
     }else{
        $stbkis=$stbkis.$kppart[$k].",";
     };//if
    };//for  
   };//if
  };//if
  $totk=0;
 if ($stbkis!=""){//基本这里结合上面成功的
   $stbkis=substr($stbkis.",",0,strlen($stbkis)-1);
   $kpart=explode(",",$stbkis);
   $totk=count($kpart);
 }else{
  $ncdts=fmcdt($tbnm,$tbkis);
  $gkinfo=allkeyinfo($gkinfo,glb(),$tbnm);
  $tbkis=$gkinfo["COLUMN"]["ALLKEY"];
  $tbtkis=$gkinfo["COLUMN"]["ALLTKEY"];
  $ntbkis=makekey($tbtkis);
  $tbkis=$ntbkis;
  $tbcdts=$ncdts;  
  $kpart=explode(",",$tbkis);
  $totk=count($kpart);
  $stbkis=$tbkis;
  if (strpos($tbnm,",")>0){
   $tbnm=substr($tbnm,0,strlen($tbnm)-1);
  };
 };  
 if ($stbkis==""){
  $stbkis="SNO";
 };  
 
 if (str_replace(" ","",str_replace("1>0","",$tbcdt))!=""){
   $tbcdt=str_replace("1>0","",$tbcdt);
 };  
if (strpos("xx".$odcdt,"order by")>0){
  $ordercdt=$odcdt;
}else{
  if (strlen($odcdt)>10){
    $ordercdt=Hex2String($odcdt);
  }else{
  $ordercdt="";  
  }
};
  
  
if ($exkkk!=""){
  if (substr($exkkk,strlen($exkkk)-1)==","){
    $extkkk=substr($exkkk,0,strlen($exkkk)-2);
  }else{    
  };
  $stbkis=$extkkk;
}else{
};
$fmodx="";
if (_post("sort")!=""){
 $sortx=json_decode(_post("sort"),true); 
 $totsx=count($sortx);
 for ($z=0;$z<$totsx;$z++){  
  if ($sortx[$z]["property"]=="id" or $sortx[$z]["property"]=="ID"){
   $fmodx=$fmodx." SNO ".$sortx[$z]["direction"].",";
  }else{
   $fmodx=$fmodx." ".$sortx[$z]["property"]." ".$sortx[$z]["direction"].",";
  }
 } 
 if ($totsx>0){
  $fmodx=killlaststr($fmodx);
 }
 $ordercdt=" order by ".$fmodx;
}
if (dftval($_GET["dbnm"],"")==""){
 $conn=mysql_connect($fip,$fus,$fps);  
 $flrst=selecteds($conn,glb(),"select ".$stbkis." from ".$tbnm." where ".$tbcdts.$ordercdt,"utf8","");
 //echo "select ".$stbkis." from ".$tbnm." where ".$tbcdts.$ordercdt;
 $dinfo=getdbinfo(glb(),$tbnm,$dinfo);
}else{
 $dinfo=array();
 $dinfo=getdbinfo(dftval($_GET["dbnm"],""),$tbnm,$dinfo);
 $ffip=$dinfo["fip"];
 $fuser=$dinfo["fuser"];
 $fpass=$dinfo["fpass"];
 $conn=mysql_connect($ffip,$fuser,$fpass);  
 $flrst=selecteds($conn,dftval($_GET["dbnm"],""),"select ".$stbkis." from ".$tbnm." where ".$tbcdts.$ordercdt,"utf8","");
}
$fmtbasex["sqlstr"]=gohex("select ".$stbkis." from ".$tbnm." where ".$tbcdts.$ordercdt);
 $totrst=countresult($flrst);
  $kpart=explode(",",$stbkis);
 $totk=count($kpart);
 $sresult=arrdata($sresult,$flrst);
 
 if (_get("y")=="1"){
   $keyinfo=thekeyfun($keyinfo,glb(),"SHORTID",$xid);
   
 }else{
   $keyinfo=thekeyfun($keyinfo,glb(),$tbnm,$stbkis);
 }
 $fmcantc="";
 $fmktps="";  
  $diycode=fmvalue($tbnm,"","","",$diycode,1,$sresult);
  $dbtn=formdiybtn($xid,$diycode);
  $diytop=fmvalue($tbnm,"","","",$diytop,1,$sresult);
  $diybottom=fmvalue($tbnm,"","","",$diybottom,1,$sresult);
  $sresult=makedefault($sresult,$keyinfo);
  
  
 $fmjs="";
 $fmjh="";
 
 $fmdft="{";
 
 $fmtp="";
 $tmpdtx="";
 $dtt = date_create();
 $sttdt=date_timestamp_get($dtt);
 
 
if ($dtp=="html" or $dtp=="table" or $dtp=="excel"){
  if ($keyinfo["COLUMN"]["COUNT"]>10){
     $scolx="overflow-x:scroll;overflow-y:hidden;width:100%;padding-bottom:500px;margin-bottom:50px;";
  }else{
     $scolx="";
  };
  if (($tabdemo=="" or $tabdemo=="@") ){   
    $fmtbdemo=$tabsrd;
  }else{
    $fmtbdemo=$tabdemo;
  }
 
 if ($tabcls==""){
  $tabcls="layui-table";
 }else{  
 }
 if ($formcls==""){
  $formcls="layui-form";
 }
 $demodemo="[tabheadandbody]"; 
 $fmtbdemo=str_replace("[TABLE]",$tbnm,$fmtbdemo);
 $fmtbdemo=str_replace("[SKEYS]",$tbkis,$fmtbdemo);
 $fmtbdemo=str_replace("[CKEYS]",$fmcantc,$fmtbdemo);
 $fmtbdemo=str_replace("TAB_CLS",$tabcls,$fmtbdemo);
 $fmtbdemo=str_replace("FORM_CLS",$formcls,$fmtbdemo);
 $fmtb="";
 $keyinfoa=$keyinfo;
 $keyinfob=$keyinfo;
 $fmtp="<div style=\"width:100%\"><p style=\"text-align:center;font-size:18px;font-weight:bold;width:auto;\">[tabletitle]</p></div><div style=\"width:100%\"><table  name=\"tabdiv\" class=\"TAB_CLS\"  border=\"1px\" cellspacing=\"0px\" cellpadding=\"3px\"  tbname=\"".$tbnm."\" tbkies=\"".$tbkis."\" cantkies=\"".$fmcantc."\" totrcd=\"[totrst]\" >";
 $fmtp=$fmtp."<thead><tr rowidx=\"head\"  style=\"font-weight:bold;\">";
 $fmch="";
 $fmexlx="";
 $headxyz=maketbheadin($totk,$chtml,$dtp,$tbhd,$oprtx,$headx,$keyinfoa,$kpart,$headxyz); 
 $fmexlx=$headxyz["exl"];
 $fmtb="";
 if ($sttbnm==$tbnm){
  if (($headdemo=="" or $headdemo=="@") or $_GET["pageid"]!=""){
  $thead="<thead><tr rowidx=\"head\" class=\"HDTR_CLS\" style=\"HDTR:STL\">".$headxyz["ftb"]."</tr></thead>";      
  $x=UX("update coode_shortdata set headdemo='".gohex($thead)."' where shortid='".$xid."'");
  $fmtb=$fmtb.$thead."<tbody>";  
  }else{
  $fmtb=$fmtb.$headdemo."<tbody>";
  } 
 }else{ 
  $thead="<thead><tr rowidx=\"head\" class=\"HDTR_CLS\" style=\"HDTR:STL\">".$headxyz["ftb"]."</tr></thead>";    
  $fmtb=$fmtb.$thead."<tbody>";   
 }
 $fmtp=$fmtp.$headxyz["ftp"]."</tr></thead><tbody>"; 
}
if (_get("SNO")!="" or $dtp!="html"){
  $tbdatax=maketbdata($totrst,$totk,$tbkis,$chtml,$oprtx,$obtn,$vbtn,$xbtn,$dtp,$headx,$appid,$tbnm,$sresult,$kpart,$keyinfo,$tbdatax,$xid);
  $fmexlx=$fmexlx.$tbdatax["exl"];
}
if ($dtp=="html" or $dtp=="table"){
  if (strpos($tabtrdemo,"v-for")>0){
   $maketvue=maketabvue($totk,$tabtrdemo,$tabtddemo,$dtp,$tbhd,$oprtx,$keyinfoa,$kpart,$headxyz);
   $fmtb=$fmtb.$maketvue;
   $tabbody=$tabbody.$maketvue;
  }else{
   $fmtb=$fmtb.$tbdatax["fmtb"];
   $tabbody=$tabbody.$tbdatax["fmtb"];
  }
  $tmpdtx=$tbdatax["tmpdtx"];
  $fmdft=$fmdft.$tbdatax["dft"];
  $mctraw=makectraw($totk,$tbnm,$dtp,$ctraw,$sresult,$kinfo,$kpart);  
  $fmtb=$fmtb.$mctraw;
  $tabbody=$tabbody.$mctraw;
  $mkaop=makeaddoprt($totk,$appid,$tbnm,$tbkis,$fmdt,$dtp,$headx,$additemx,$oprtx,$keyinfo,$kpart);
  $fmtb=$fmtb.$mkaop;
  $tabbody=$tabbody.$mkaop;
  if (strpos(".".$dtp.$headx,"nooprt")<=0 and ($additemx*1)==1 and ($oprtx*1)==1){    
    $tmptbmid=$tmptbmid.$tmpnewrow;
  };  
}
  
if ($dtp=="imgx"){
  $fmch=$fmch.$tbdatax["fmch"];
}
if (strpos("xx".$dtp,"json")>0){
 $mjs=makejson($fmtbasex,$keyinfo,substr($tbdatax["fmjs"],0,strlen($tbdatax["fmjs"])-1),$tbkis,$totrst);
 $mjs=str_replace("[md5txt]",$tbdatax["fmmd5"],$mjs);
}
if ($dtp=="html" or $dtp=="table"){
 $fmy=pagexyz($totye,$pg,$pgn,$allkillbtn,$totallrst,$tbnm,$xid);  
  $fmtb=$fmtb."</tbody>";
  $tabbody=$tabbody."</tbody>";
  $demodemo=str_replace("[tabheadandbody]",$fmtb,$demodemo); 
  $demodemo=str_replace("[tabpage]",$fmy,$demodemo);
  $demodemo=str_replace("[totrcd]",$totallrst,$demodemo);  
}
$totye=ceil((intval($totallrst)/intval($pgn)));  
if ($dtp=="html" or $dtp=="table"){ 
  $dbtn=exchangestr($dbtn,$xid,$tbnm);     
  $btmsrd=$diybottom;  
  $fmx=exchangestr($fmx,$xid,$tbnm);
  $fmtbdemo=str_replace("[totrcd]",$totrst,$fmtbdemo);
  $fmtbdemo=str_replace("[topbtn]",$dbtn,$fmtbdemo);
  $fmtbdemo=str_replace("[diytop]",$diytop,$fmtbdemo);
  $fmtbdemo=str_replace("[diybottom]",$btmsrd,$fmtbdemo);
  $fmtbdemo=str_replace("[tmpdtx]",$tmpdtx,$fmtbdemo);
  $fmtbdemo=str_replace("[extscript]",$extscript,$fmtbdemo);
  $fmtbdemo=str_replace("[tabpage]",$fmy,$fmtbdemo);
  $fmtbdemo=str_replace("[tabnm]",$sttbnm,$fmtbdemo);  
  $fmtbdemo=str_replace("[tabkeys]",$stbkis,$fmtbdemo);
  $fmtbdemo=str_replace("[scroll]",$scolx,$fmtbdemo);
  $tabledata=str_replace("[tbhead]",$tabhead,$fmtbdemo); 
  $tabledata=str_replace("[tbbody]",$tabbody,$tabledata);
  $tabledata=str_replace("[tbheadbody]",$demodemo,$tabledata);
  $x=UX("update coode_shortdata set tabdemo='".gohex($fmtbdemo)."' where shortid='".$xid."' and tabdemo=''");  
   $oritb="<table ".qian(hou($tabledata,"<table "),"</table>")."</table>";  
 }
 
  switch ($dtp){
   case "jshtm":
   return $fmjh;
   break;
   case "imgx":
   $csurd=str_replace("[totrcd]",$totallrst,$csurd); 
   $csurd=str_replace("[topbtn]",$dbtn,$csurd);
   $csurd=str_replace("[diytop]",$diytop,$csurd);
   $csurd=str_replace("[diybottom]",$btmsrd,$csurd);
   $csurd=str_replace("[tmpdtx]",$tmpdtx,$csurd);
   $csurd=str_replace("[extscript]",$extscript,$csurd);
   $csurd=str_replace("[tabpage]",$fmy,$csurd);
   $csurd=str_replace("[tabnm]",$sttbnm,$csurd);
   $csurd=str_replace("[tabkeys]",$stbkis,$csurd);
   $csurd=str_replace("[tabpage]",$fmy,$csurd);
  
   $csurd=str_replace("[scroll]",$scolx,$csurd);
   $csurd=str_replace("[pnum]","30",$csurd);
   $csurd=str_replace("[inner]",$fmch,$csurd);
   return $csurd;
   break;
   case "excel":
   //var_dump($keyinfo);
   return $fmexlx; 
   break;
   case "html":
    if (_get("SNO")!=""){
      return $tbdatax["fmline"];
    }else{
      return $tabledata;       
    }
   break;
    case "table":
    if (_get("SNO")!=""){
      return $tbdatax["fmline"];
    }else{
      return $oritb;
    }
   break;
   case "diy":
    return $tmptbmid;
   break;
   default:  
    if (strpos(".".$dtp,'json')>0){
       $dttb = date_create();
       $enddt=date_timestamp_get($dttb);
       $haos=$enddt-$sttdt;
       $mjs=str_replace("[ptime]",$haos,$mjs);
       return $mjs;
    };
  }
 }//fun
}//class
?>