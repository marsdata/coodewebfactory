<?php
class itemvalue{
 public function item0($stid){
 $dbmk=dftval($_GET["dbmk"],"");
  if ($dbmk==""){    
     $yrst=SX("select SNO,valuezero,COLUMN_NAME,DATA_TYPE,dxtype,keyexplain,clstxt from coode_keydetaily where shortid='".$stid."' and COLUMN_NAME<>'OPRT'  order by SQX");    
  }else{
     $yrst=SX("select SNO,valuezero,COLUMN_NAME,DATA_TYPE,dxtype,keyexplain,clstxt from coode_dbkeydy where shortid='".$stid."' and COLUMN_NAME<>'OPRT'  order by SQX");
  }
  $toty=countresult($yrst);
  eval(RESFUNSET("formbase"));
  $fmkeys="";
  $fmdtps="";
  $fmdxps="";
  $fmexps="";
  $srddemo='{"status":"1","msg":"success","SNO":"0","shortid":"'.$stid.'","detailkeys":"[fmkeys]","datatypes":"[fmdtps]","kexp":"[kexp]","dxtypes":"[fmdxps]",[datainner]}';
  if ($toty>0){
   $fminner="";
    for ($i=0;$i<$toty;$i++){
      $vz=tostring(anyvalue($yrst,"valuezero",$i));
      $cn=anyvalue($yrst,"COLUMN_NAME",$i);
      $dt=anyvalue($yrst,"DATA_TYPE",$i);
      $dx=anyvalue($yrst,"dxtype",$i);
      $ex=anyvalue($yrst,"keyexplain",$i);
      $ct=anyvalue($yrst,"clstxt",$i);
      $thusvalue="";
      $fmkeys=$fmkeys.$cn.",";
      $fmdtps=$fmdtps.$dt.",";
      $fmdxps=$fmdxps.$dx.",";
      $fmexps=$fmexps.$ex.",";
      if (strpos($vz,"thusvalue=")>0){
        eval($vz);
      }
      if ($cn=="SNO"){
       $fminner=$fminner."\"".$cn."\":\"0\",";
      }else{
       $fminner=$fminner."\"".$cn."\":\"".$thusvalue."\",";
      }
    }//for
    $fminner=killlaststr($fminner);
    $fmkeys=killlaststr($fmkeys);
    $fmdtps=killlaststr($fmdtps);
    $fmdxps=killlaststr($fmdxps);
    $fmexps=killlaststr($fmexps);
  }//if
  $srddemo=str_replace("[fmkeys]",$fmkeys,$srddemo);
  $srddemo=str_replace("[datainner]",$fminner,$srddemo);
  $srddemo=str_replace("[fmdtps]",$fmdtps,$srddemo);
  $srddemo=str_replace("[fmdxps]",$fmdxps,$srddemo);
  $srddemo=str_replace("[kexp]",$fmexps,$srddemo);
  return $srddemo;
 }
 public function itemx($stid,$snox){
 eval(RESFUNSET("formbase"));
  $stbase=array();  
  $fmkeys="";
  $fmtts="";
  $dinfo=array();
  $pssno="SNO";
  $dbmk=dftval($_GET["dbmk"],"");
  if ($dbmk==""){
      $stbase=shortinfo($stid,$stbase);
      $yrst=SX("select SNO,valuezero,TABLE_NAME,COLUMN_NAME,DATA_TYPE,dxtype,keytitle,keyexplain,clstxt from coode_keydetaily where shortid='".$stid."' and  COLUMN_NAME<>'OPRT' order by SQX");
      $tbnm=anyvalue($yrst,"TABLE_NAME",0);    
      $dinfo=takedbinfo("",$tbnm,$dinfo);
      if ($dinfo["pssno"]!=""){
        $pssno=$dinfo["pssno"];
      }
  }else{
      $stbase=dbshortinfo($dbmk,$stid,$stbase);
      $yrst=SX("select SNO,valuezero,TABLE_NAME,COLUMN_NAME,DATA_TYPE,dxtype,keytitle,keyexplain,clstxt from coode_dbkeydy where shortid='".$stid."'  and  COLUMN_NAME<>'OPRT' order by SQX");      
      $tbnm=anyvalue($yrst,"TABLE_NAME",0);
      $dinfo=takedbinfo($dbmk,$tbnm,$dinfo);    
      if ($dinfo["pssno"]!=""){
        $pssno=$dinfo["pssno"];
      }      
  }  
  
  $toty=countresult($yrst);
      for ($i=0;$i<$toty;$i++){
        $cn=anyvalue($yrst,"COLUMN_NAME",$i);
        $tt=anyvalue($yrst,"keytitle",$i);
        $fmtts=$fmtts.$tt.",";
        $fmkeys=$fmkeys.$cn.",";
      }
    $fmkeys=killlaststr($fmkeys);
    $fmtts=killlaststr($fmtts);
    if ($dbmk==""){
        $datarst=SX("select ".$fmkeys." from ".$tbnm." where ".$pssno."='".$snox."'");
    }else{
        $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
        $datarst=selectedx($conn,$dinfo["fbase"],"select ".$fmkeys." from ".$tbnm." where ".$pssno."='".$snox."'","utf8","");
    }
    for ($i=0;$i<$toty;$i++){
          $cn=anyvalue($yrst,"COLUMN_NAME",$i);
          $_GET["key".$cn]=tostring(anyvalue($datarst,cn,0));
    }
  $fmkeys="";
  $fmdtps="";
  $fmdxps="";
  $fmexps="";
  $srddemo='{"status":"1","msg":"success","'.$pssno.'":"'.$snox.'","shortid":"'.$stid.'","detailtitles":"[fmtitles]","detailkeys":"[fmkeys]","kexp":"[kexp]","datatypes":"[fmdtps]","dxtypes":"[fmdxps]",[datainner]}';
  if ($toty>0){
   $fminner="";   
    for ($i=0;$i<$toty;$i++){
      $thusvalue="";
      $vz=tostring(anyvalue($yrst,"valuezero",$i));
      $cn=anyvalue($yrst,"COLUMN_NAME",$i);
      $dt=anyvalue($yrst,"DATA_TYPE",$i);
      $dx=anyvalue($yrst,"dxtype",$i);
      $ex=anyvalue($yrst,"keyexplain",$i);
      $ct=anyvalue($yrst,"clstxt",$i);      
      $thusvalue=anyvalue($datarst,$cn,0);
      if (strpos($thusvalue,"\"")>0 or strpos($thusvalue,">")>0 or strpos($thusvalue,"\r\n")>0  or strpos($thusvalue,"<")>0  or strpos($thusvalue,"'")>0){
        $thusvalue=gohex($thusvalue);
      }
      $fmkeys=$fmkeys.$cn.",";
      $fmdtps=$fmdtps.$dt.",";
      $fmdxps=$fmdxps.$dx.",";      
      $fmexps=$fmexps.$ex.",";
      $fminner=$fminner."\"".$cn."\":\"".$thusvalue."\",";
      if (strpos($ct,"key-")>0){
         $tmpcol=hou($ct,"key-");
         $tmpcol=str_replace("]","",$tmpcol);
         $tmpcol=str_replace("}","",$tmpcol);
         $clsvalue=anyvalue($datarst,$tmpcol,0);
         $fminner=$fminner."\"".$cn."CLSTXT\":\"".$clsvalue."\",";   
      }else if (strpos($ct,"key")>0){
        $tmpct=str_replace("[","",$ct);
        $tmpct=str_replace("]","",$tmpct);
        $tmpct=str_replace("{","",$tmpct);
        $tmpct=str_replace("}","",$tmpct);
        $clsvalue=anyshort($tmpct,"","");
        $fminner=$fminner."\"".$cn."CLSTXT\":\"".$clsvalue."\",";   
      }else{
        $fminner=$fminner."\"".$cn."CLSTXT\":\"".$ct."\",";   
      }
    }//for
    $fminner=killlaststr($fminner);
    $fmkeys=killlaststr($fmkeys);
    $fmdtps=killlaststr($fmdtps);
    $fmdxps=killlaststr($fmdxps);
    $fmexps=killlaststr($fmexps);
  }//if
  $srddemo=str_replace("[fmkeys]",$fmkeys,$srddemo);
  $srddemo=str_replace("[fmtitles]",$fmtts,$srddemo);
  $srddemo=str_replace("[datainner]",$fminner,$srddemo);
  $srddemo=str_replace("[fmdtps]",$fmdtps,$srddemo);
  $srddemo=str_replace("[fmdxps]",$fmdxps,$srddemo);
  $srddemo=str_replace("[kexp]",$fmexps,$srddemo);
  return $srddemo;
 }
 public function itemy($stid,$olmkx){
 $dbmk=dftval($_GET["dbmk"],"");
 eval(RESFUNSET("formbase"));
  $stbase=array();
  if ($dbmk==""){
     
       $stbase=shortinfo($stid,$stbase);  
     
  }else{
    
     $stbase=dbshortinfo($dbmk,$stid,$stbase);  
    
  }
  $fmkeys="";
  if ($dbmk==""){    
      $yrst=SX("select SNO,valuezero,COLUMN_NAME,DATA_TYPE,dxtype,clstxt from coode_keydetaily where shortid='".$stid."' order by SQX");    
  }else{
     $yrst=SX("select SNO,valuezero,COLUMN_NAME,DATA_TYPE,dxtype,clstxt from coode_dbkeydy where shortid='".$stid."' order by SQX");
  }
  $toty=countresult($yrst);
      for ($i=0;$i<$toty;$i++){
        $cn=anyvalue($yrst,"COLUMN_NAME",$i);
        $fmkeys=$fmkeys.$cn.",";
      }
    $fmkeys=killlaststr($fmkeys);
    if ($dbmk==""){
      
        $datarst=SX("select ".$fmkeys." from ".$stbase["tablename"]." where OLMK='".$olmkx."'");  
      
    }else{
       $dinfo=array();
       $dinfo=takedbinfo($dbmk,$stbase["tablename"],$dinfo);
       $ffip=$dinfo["fip"];
       $fuser=$dinfo["fuser"];
       $fpass=$dinfo["fpass"];
       $conn=mysql_connect($ffip,$fuser,$fpass);
       $datarst=selectedx($conn,$dinfo["fbase"],"select ".$fmkeys." from ".$stbase["tablename"]." where OLMK='".$olmkx."'","utf8","");  
    }
  $fmkeys="";
  $fmdtps="";
  $fmdxps="";
  $srddemo='{"status":"1","msg":"success","OLMK":"'.$olmkx.'","shortid":"'.$stid.'","detailkeys":"[fmkeys]","kexp":"[kexp]","datatypes":"[fmdtps]","dxtypes":"[fmdxps]",[datainner]}';
  if ($toty>0){
   $fminner="";
    for ($i=0;$i<$toty;$i++){
      $thusvalue="";
      $vz=tostring(anyvalue($yrst,"valuezero",$i));
      $cn=anyvalue($yrst,"COLUMN_NAME",$i);
      $dt=anyvalue($yrst,"DATA_TYPE",$i);
      $dx=anyvalue($yrst,"dxtype",$i);
      $ct=anyvalue($yrst,"clstxt",$i);
      $ex=anyvalue($yrst,"keyexplain",$i);
      $thusvalue=anyvalue($datarst,$cn,0);
      $fmkeys=$fmkeys.$cn.",";
      $fmdtps=$fmdtps.$dt.",";
      $fmdxps=$fmdxps.$dx.",";
      $fmexps=$fmexps.$ex.",";
      $fminner=$fminner."\"".$cn."\":\"".$thusvalue."\",";
      if (strpos($ct,"key-")>0){
         $tmpcol=hou($ct,"key-");
         $tmpcol=str_replace("]","",$tmpcol);
         $tmpcol=str_replace("}","",$tmpcol);
         $clsvalue=anyvalue($datarst,$tmpcol,0);
         $fminner=$fminner."\"".$cn."CLSTXT\":\"".$clsvalue."\",";   
      }else if (strpos($ct,"key")>0){
        $tmpct=str_replace("[","",$ct);
        $tmpct=str_replace("]","",$tmpct);
        $tmpct=str_replace("{","",$tmpct);
        $tmpct=str_replace("}","",$tmpct);
        $clsvalue=anyshort($tmpct,"","");
        $fminner=$fminner."\"".$cn."CLSTXT\":\"".$clsvalue."\",";   
      }else{
      }
    }//for
    $fminner=killlaststr($fminner);
    $fmkeys=killlaststr($fmkeys);
    $fmdtps=killlaststr($fmdtps);
    $fmdxps=killlaststr($fmdxps);
    $fmexps=killlaststr($fmexps);
  }//if
  $srddemo=str_replace("[fmkeys]",$fmkeys,$srddemo);
  $srddemo=str_replace("[datainner]",$fminner,$srddemo);
  $srddemo=str_replace("[fmdtps]",$fmdtps,$srddemo);
  $srddemo=str_replace("[fmdxps]",$fmdxps,$srddemo);
  $srddemo=str_replace("[kexp]",$fmexps,$srddemo);
  return $srddemo;
 }
}
?>