<?php
class makeqrcode{
public function askcode($mark,$qrtype,$url,$logourl,$bdomain,$bmark){
   $qrurl=UX("select qrimgurl as result from coode_qrcodeurl where qrmark='".$mark."'"); 
   if ($qrurl==""){
     return $this->makecode($mark,$qrtype,$url,$logourl,$bdomain,$bmark);
   }else{
     return $qrurl;
   }
}
public function makecode($mark,$qrtype,$url,$logourl,$bdomain,$bmark){  
 if ($mark!="" and $qrtype!="" and $url!=""){
    switch($qrtype){
        case "ori":
        $ewmurl=$this->scerweima($mark,$url);
        $extx=UX("select count(*) as result from coode_qrcodeurl where qrmark='".$mark."'");
        $b64data=base64EncodeImage(combineurl(localroot(),$ewmurl));
        if (intval($extx)==0){
          $sqlx="qrmark,logourl,qrimgurl,visiturl,qrimgbase64,remark,CRTM,UPTM,OLMK,CRTOR";
          $sqly="'".$mark."','".$logourl."','".$ewmurl."','".$url."','".$b64data."','',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."'";
          $z=UX("insert into coode_qrcodeurl(".$sqlx.")values(".$sqly.")");
        }else{
          $z=UX("update coode_qrcodeurl set logourl='".$logourl."',qrimgbase64='".$b64data."',visiturl='".$url."',qrimgurl='".$ewmurl."' where qrmark='".$mark."'");
        }
        return $ewmurl;
        break;
        case "logo":
         $ewmurl=$this->scerweima1($mark,$url,$logourl);
         $b64data=base64EncodeImage(combineurl(localroot(),$ewmurl));
         $extx=UX("select count(*) as result from coode_qrcodeurl where qrmark='".$mark."'");
         if (intval($extx)==0){
          $sqlx="qrmark,logourl,qrimgurl,visiturl,qrimgbase64,remark,CRTM,UPTM,OLMK,CRTOR";
          $sqly="'".$mark."','".$logourl."','".$ewmurl."','".$url."','".$b64data."','',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."'";
          $z=UX("insert into coode_qrcodeurl(".$sqlx.")values(".$sqly.")");
         }else{
          $z=UX("update coode_qrcodeurl set logourl='".$logourl."',qrimgbase64='".$b64data."',visiturl='".$url."',qrimgurl='".$ewmurl."' where qrmark='".$mark."'");
         }
         return $ewmurl;
        break;
        case "string":
         $ewmurl=$this->scerweima2($mark,$url,$bdomain,$bmark);
         $b64data=base64EncodeImage(combineurl(localroot(),$ewmurl));
         $extx=UX("select count(*) as result from coode_qrcodeurl where qrmark='".$mark."'");
         if (intval($extx)==0){
          $sqlx="qrmark,logourl,qrimgurl,visiturl,qrimgbase64,remark,CRTM,UPTM,OLMK,CRTOR,bdomain,bmark";
          $sqly="'".$mark."','".$logourl."','".$ewmurl."','".$url."','".$b64data."','',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."','".$bdomain."','".$bmark."'";
          $z=UX("insert into coode_qrcodeurl(".$sqlx.")values(".$sqly.")");
         }else{
          $z=UX("update coode_qrcodeurl set bdomain='".$bdomain."',bmark='".$bmark."',logourl='".$logourl."',qrimgbase64='".$b64data."',visiturl='".$url."',qrimgurl='".$ewmurl."' where qrmark='".$mark."'");
         }
         return $ewmurl;
        break;
        default:        
        $ewmurl=$this->scerweima($mark,$url);
        $b64data=base64EncodeImage(combineurl(localroot(),$ewmurl));
        $extx=UX("select count(*) as result from coode_qrcodeurl where qrmark='".$mark."'");
        if (intval($extx)==0){
          $sqlx="qrmark,logourl,qrimgurl,visiturl,qrimgbase64,remark,CRTM,UPTM,OLMK,CRTOR";
          $sqly="'".$mark."','".$logourl."','".$ewmurl."','".$url."','".$b64data."','',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."'";
          $z=UX("insert into coode_qrcodeurl(".$sqlx.")values(".$sqly.")");
        }else{
          $z=UX("update coode_qrcodeurl set logourl='".$logourl."',qrimgbase64='".$b64data."',visiturl='".$url."',qrimgurl='".$ewmurl."' where qrmark='".$mark."'");
        }
        return $ewmurl;
    }
  }else{
    return "";
  }
}
public function scerweima($mark,$url){
    require_once combineurl(localroot(),'/localxres/parax/PHPqrCode/phpqrcode.php');
    $value = $url;                    //二维码内容
    $errorCorrectionLevel = 'L';    //容错级别 
    $matrixPointSize = 5;            //生成图片大小  
    //生成二维码图片
    $lcpath=combineurl(localroot(),'/localxres/iconsetx/qrcode/'.date("Y-m-d"));
    is_dir($lcpath) OR mkdir($lcpath, 0777, true);
    $filename = combineurl(localroot(),'/localxres/iconsetx/qrcode/'.date("Y-m-d").'/'.$mark.'-'.substr(md5($url),0,16).'.png');
    $fileurl='/localxres/iconsetx/qrcode/'.date("Y-m-d").'/'.$mark.'-'.substr(md5($url),0,16).'.png';
    QRcode::png($value,$filename , $errorCorrectionLevel, $matrixPointSize, 2);  
    $QR = $filename;                //已经生成的原始二维码图片文件  
    $QR = imagecreatefromstring(file_get_contents($QR));  
    //输出图片  还可以输出到其他位置
    //imagepng($QR, 'qrcode.png');  
    //imagedestroy($QR);    
    return $fileurl;
}
 
public function scerweima1($mark,$url,$logourl){
    //logo 62px x 62px
    require_once combineurl(localroot(),'/localxres/parax/PHPqrCode/phpqrcode.php');
    $value = $url;                    //二维码内容  
    $errorCorrectionLevel = 'H';    //容错级别  
    $matrixPointSize = 6;            //生成图片大小  
    //生成二维码图片
    $lcpath=combineurl(localroot(),'/localxres/iconsetx/qrcode/'.date("Y-m-d"));
    is_dir($lcpath) OR mkdir($lcpath, 0777, true);
    $filename = combineurl(localroot(),'/localxres/iconsetx/qrcode/'.date("Y-m-d").'/'.$mark.'-'.substr(md5($url),0,16).'.png');
    $fileurl='/localxres/iconsetx/qrcode/'.date("Y-m-d").'/'.$mark.'-'.substr(md5($url),0,16).'.png';
    QRcode::png($value,$filename , $errorCorrectionLevel, $matrixPointSize, 2);  
    $logo = $logourl;     //准备好的logo图片   
    $QR = $filename;            //已经生成的原始二维码图  
    if (file_exists(combineurl(localroot(),$logo))) {   
        $QR = imagecreatefromstring(file_get_contents($QR));           //目标图象连接资源。
        $logo = imagecreatefromstring(file_get_contents(combineurl(localroot(),$logo)));       //源图象连接资源。
        $QR_width = imagesx($QR);            //二维码图片宽度   
        $QR_height = imagesy($QR);            //二维码图片高度   
        $logo_width = imagesx($logo);        //logo图片宽度   
        $logo_height = imagesy($logo);        //logo图片高度   
        $logo_qr_width = $QR_width / 4;       //组合之后logo的宽度(占二维码的1/5)
        $scale = $logo_width/$logo_qr_width;       //logo的宽度缩放比(本身宽度/组合后的宽度)
        $logo_qr_height = $logo_height/$scale;  //组合之后logo的高度
        $from_width = ($QR_width - $logo_qr_width) / 2;   //组合之后logo左上角所在坐标点        
        //重新组合图片并调整大小
        /*
         *    imagecopyresampled() 将一幅图像(源图象)中的一块正方形区域拷贝到另一个图像中
         */                 
        imagecopyresampled($QR, $logo, $from_width, $from_width, 0, 0, $logo_qr_width,$logo_qr_height, $logo_width, $logo_height); 
        //输出图片
        imagepng($QR, $filename);
        imagedestroy($QR);
        imagedestroy($logo);
    }         
    return $fileurl;
 }
 public function scerweima2($mark,$url,$domain,$bmark){
    //logo 62px x 62px
    require_once combineurl(localroot(),'/localxres/parax/PHPqrCode/phpqrcode.php');
    $value = $url;                    //二维码内容  
    $errorCorrectionLevel = 'H';    //容错级别  
    $matrixPointSize = 6;            //生成图片大小  
    //生成二维码图片
    $lcpath=combineurl(localroot(),'/localxres/iconsetx/qrcode/'.date("Y-m-d"));
    is_dir($lcpath) OR mkdir($lcpath, 0777, true);
    $filename = combineurl(localroot(),'/localxres/iconsetx/qrcode/'.date("Y-m-d").'/'.$mark.'-'.substr(md5($url),0,16).'.png');
    $filestring = combineurl(localroot(),'/localxres/iconsetx/qrcode/'.date("Y-m-d").'/'.$domain.$bmark.'-'.substr(md5($url),0,16).'.png');
    if ($domain!="" and $bmark!="") {
       $image = imagecreatetruecolor(62, 62);
       $bgcolor = imagecolorallocate($image, 255, 255, 255);
       imagefill($image, 0, 0, $bgcolor);
        for ($i = 0; $i < strlen($domain); $i++) {    
         $fontcolor = imagecolorallocate($image, 0 , 0 , 0);    
         $fontcontent =substr($domain,$i,1);
         $fontsize=6;
         $x = ($i * 10) + 5;
         $y = 13;
         imagestring($image, $fontsize, $x, $y, $fontcontent, $fontcolor);
        }
        for ($i = 0; $i < strlen($bmark); $i++) {    
         $fontcolor = imagecolorallocate($image, 0 , 0 , 0);    
         $fontcontent =substr($bmark,$i,1);
         $fontsize=6;
         $x = ($i * 10) + 5;
         $y = 33;
         imagestring($image, $fontsize, $x, $y, $fontcontent, $fontcolor);
        }
        //输出图片
        imagepng($image, $filestring);
        imagedestroy($image);        
    }  
    $fileurl='/localxres/iconsetx/qrcode/'.date("Y-m-d").'/'.$mark.'-'.substr(md5($url),0,16).'.png';
    QRcode::png($value,$filename , $errorCorrectionLevel, $matrixPointSize, 2);      
    $QR = $filename;            //已经生成的原始二维码图  
    $logo = $filestring;     //准备好的logo图片   
    $QR = $filename;            //已经生成的原始二维码图  
    if (file_exists($logo)) {   
        $QR = imagecreatefromstring(file_get_contents($QR));           //目标图象连接资源。
        $logo = imagecreatefromstring(file_get_contents($logo));       //源图象连接资源。
        $QR_width = imagesx($QR);            //二维码图片宽度   
        $QR_height = imagesy($QR);            //二维码图片高度   
        $logo_width = imagesx($logo);        //logo图片宽度   
        $logo_height = imagesy($logo);        //logo图片高度   
        $logo_qr_width = $QR_width / 4;       //组合之后logo的宽度(占二维码的1/5)
        $scale = $logo_width/$logo_qr_width;       //logo的宽度缩放比(本身宽度/组合后的宽度)
        $logo_qr_height = $logo_height/$scale;  //组合之后logo的高度
        $from_width = ($QR_width - $logo_qr_width) / 2;   //组合之后logo左上角所在坐标点        
        //重新组合图片并调整大小
        /*
         *    imagecopyresampled() 将一幅图像(源图象)中的一块正方形区域拷贝到另一个图像中
         */                 
        imagecopyresampled($QR, $logo, $from_width, $from_width, 0, 0, $logo_qr_width,$logo_qr_height, $logo_width, $logo_height); 
        //输出图片
        imagepng($QR, $filename);
        imagedestroy($QR);
        imagedestroy($logo);
    }         
    return $fileurl;
 }
}
?>