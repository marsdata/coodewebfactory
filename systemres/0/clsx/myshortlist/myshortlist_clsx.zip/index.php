<?php
class myshortlist{
 public function anylist(){
 $stidd=_get('stid');
 if (strpos($stidd,"]")>0){
  $stidd=str_replace("[","",$stidd);
  $stidd=str_replace("]","",$stidd);
 };
 $pagee=$_GET['page'];
 $pagenumm=$_GET['pnum'];
if (strpos($stidd,"-")>0){
  $sid=qian($stidd,"-");
}else{
  $sid=$stidd;
};
if (strpos($stidd,"pnum:")>0){
  $spnum=qian(qian(hou($stidd,"pnum:"),"-"),"&");
}else{
  $spnum="";
}
if ($pagenumm==""){
 $pagenumm=(intval($spnum)*1);
}
if (_get("pnu")=="0"){
  $pagenumm="0"; 
  $pagee="0";
}
eval(RESFUNSET("tabbaseinfo"));
 eval(RESFUNSET("democode")); 
 $z=UX("delete from coode_mydbkeydy where COLUMN_NAME=''");
$shortbs=myshortinfo(dftval($_GET["dbnm"],""),$sid,$shortbs);
$sps=$shortbs["sps"];
$datatp=$shortbs["dttp"];
$caseid=$shortbs["caseid"];
$kies=$shortbs["showkeys"];
$tbnmx=$shortbs["tablename"];
$dtx=$shortbs["dtx"];
$beforeview=$shortbs["beforeview"];
$diyright=$shortbs["diyright"];
$srst=array(array());
$diyright=fmvalue($tbnmx,"","","",$diyright,1,$srst);
$diyright=exchangestr($diyright,$sid,$tbnmx); 
$tabdemo=$shortbs["tabdemo"];
$headdemo=$shortbs["headdemo"];
$searchdemo=$shortbs["searchdemo"];
$pagedemo=$shortbs["pagedemo"];
$tbdm=$tabdemo;
 eval(CLASSX("tableupdt"));
 $tbup=new tableupdt();
 $tabinfo=$tbup->tabup($tbnmx,"new",$tabinfo);
 if ($tabinfo["status"]["msg"]=="0"){
   $shortinfo=$tbup->shortup($sid,$tbnmx,"new",$shortinfo);
 }
 
 if ($beforeview!=""){
    eval($beforeview);
 }
if (intval($dtx)==1 and _get("refresh")=="" and $datatp!="imgx"){
 $allhtml=UX("select storage as result from coode_myshortaffect where CRTM=UPTM and shortid='".$sid."' and pageid='".$caseid."' and tempid='".$caseid."' ");
 if ($allhtml!="" and strpos("xx".$allhtml,"failure")<=0){
  $allhtml=tostring($allhtml);
  $allhtml=str_replace("[date]",date("YmdHis"),$allhtml);
  return $allhtml;
 }
}else{
  $x=UX("delete from coode_myshortaffect where shortid='".$sid."'");
  $z=UX("update  coode_mydbshort  set tabdemo='',headdemo='',pagedemo='',searchdemo='' where shortid='".$sid."'");
  $y=UX("update  coode_mytiny  set PRIME=1,auditmd5='' where longexp like '%stid=".$sid."%'");  
}
$searchhtml="";
$formeval=tostring(UX("select evalcode as result from coode_makemyformact where dumark='".$caseid."'"));
if ($formeval!=""){
 eval($formeval);
}
$sttitle=$shortbs["shorttitle"];
$dxtp=_get("datatype");
$pgx=_get("page");
$qryx=_get("qry");
$stidx=_get("stid");
$pnumx=_get("pnum");
$_GET["datatype"]="";
$_GET["page"]="";
$_GET["qry"]="";
$_GET["stid"]="";
$_GET["pnum"]="";
$z=anyfunrun("tabcol","","tablename=".$tbnmx,"");
$zx=anyfunrun("shortdft","","shortid=".$sid,"");
$_GET["datatype"]=$dxtp;
$_GET["page"]=$pgx;
$_GET["qry"]=$qryx;
$_GET["stid"]=$stidd;
$_GET["pnum"]=$pnumx;
      
      if (strlen($tbcdtss)>5){
        if(strpos($tbcdtss,"like")<=0 and strpos($tbcdtss,"=")<=0 and strpos($tbcdtss,"by")<=0){
         $tbcdtss=Hex2String($tbcdtss); //未发现说面加密了,需要解密,否则不用解密       
        };
        $tbcdtss=str_replace("[gid]",$_COOKIE["gid"],$tbcdtss);
        $tbcdtss=str_replace("[uid]",$_COOKIE["uid"],$tbcdtss);
        $tbcdtss=str_replace("[cid]",$_COOKIE["cid"],$tbcdtss);
        $tbcdtss=str_replace("[date]",date("Y-m-d"),$tbcdtss);
        $tbcdtss=str_replace("[now]",date("Y-m-d H:i:s"),$tbcdtss);
       $ptnhtxt=explode("[get-",$tbcdtss);
       $totpt=count($ptnhtxt);
       for ($f=0;$f<$totpt;$f++){
          $tmpok=qian($ptnhtxt[$f],"]");
         $tbcdtss=str_replace("[get-".$tmpok."]",$_GET[$tmpok],$tbcdtss);     
       };         
       $ptnhtxt=explode("[post-",$tbcdtss);
       $totpt=count($ptnhtxt);
       for ($f=0;$f<$totpt;$f++){
         $tmpok=qian($ptnhtxt[$f],"]");
         $tbcdtss=str_replace("[post-".$tmpok."]",$_POST[$tmpok],$tbcdtss);     
       };
       $ptnhtxt=explode("[cookie-",$tbcdtss);
       $totpt=count($ptnhtxt);
       for ($f=0;$f<$totpt;$f++){
         $tmpok=qian($ptnhtxt[$f],"]");
         $tbcdtss=str_replace("[cookie-".$tmpok."]",$_COOKIE[$tmpok],$tbcdtss);     
       };
        $tbcdtss=str_replace("[anymark]",date("YmdHis").getRandChar(6),$tbcdtss);
      }        
        $stcode=str_replace(" ","",$tbcdtss);
        $stcode=str_replace("'","",$stcode);
        $stcode=str_replace("=","eq",$stcode);
        $stcode=str_replace("<>","en",$stcode);
        $stcode=str_replace(">","gr",$stcode);
        $stcode=str_replace("<","le",$stcode);
        $stcode=str_replace('%',"_",$stcode);
        $conn=mysql_connect(gl(),glu(),glp());
 
 if ($dxtp!=""){
   $datatp=$dxtp;
 }
 if ($datatp=="imgx"){
   $tbdt=anyshortx($stidd,$pagee,$pagenumm,$caseid);  
 }else{
   if ($tbheadbody==""){
     $tbdt=anyshort($stidd,$pagee,$pagenumm);
   }
 }
$trst=SX("select sysid,tabtitle from coode_mydbtablist where TABLE_NAME='".$tbnmx."' and schm='".dftval($_GET["dbnm"],"")."'");
$ttitle=anyvalue($trst,"tabtitle",0);
$sysid=anyvalue($trst,"sysid",0);
if ($sysid==""){
 $sysid="noname";
}
$tabjspath="/ORG/system/".$sysid."/mytabs/".$tbnmx."/".$tbnmx.".js";
$stjspath="/ORG/system/".$sysid."/mytabs/".$tbnmx."/".qian($stidd,"-").".js";
$jseval=tostring(UX("select evalcode as result from coode_makemydujsfile where dumark='".$caseid."'"));
if ($jseval!=""){ 
 eval($jseval);
}
if ($ttitle==""){
  $ttitle=$tbnmx;
}
 $tbcdt=$_GET["tbcdtn"];
if (strpos("X".$tbcdt,"SNO")>0){
 $sno=hou("x".$tbcdt,"SNO=");
};
$fmdiv="";
$fmdov="";
$show="1";
$tmprst=SX("select styley,scripty,jsfiley,cssfiley,unittitle,pagesurround,outurl from coode_mydonunit where dumark='".$caseid."'");
 $mnusno=$pagebase["SNO"];
 $mnuid=$caseid;
 $mnumark=$caseid;
 $jsfilez=tostring(anyvalue($tmprst,"jsfiley",0));
 $jsfilez=str_replace("/FACE/","/units/".qian($caseid,".")."/",$jsfilez);
 $cssfilez=tostring(anyvalue($tmprst,"cssfiley",0));
 $cssfilez=str_replace("/FACE/","/units/".qian($caseid,".")."/",$cssfilez);
 $scpttxtz=tostring(anyvalue($tmprst,"scripty",0));
 $stltxtz=tostring(anyvalue($tmprst,"styley",0));
 $mnuoldh="";
 $mnupagefrm=turnlab(tostring(anyvalue($tmprst,"pagesurround",0)));
 $mnupagehtml=turnlab(tostring(anyvalue($tmprst,"pagesurround",0)));
 $mnupagedata=turnlab(getcodedemo("content",qian($caseid,"."),hou($caseid,".")));
 $mnusrdfrm=turnlab(getcodedemo("content",qian($caseid,"."),hou($caseid,".")));
 $tabsrdfrm=turnlab(getcodedemo("srd",qian($caseid,"."),hou($caseid,".")));
 $mnuoutpath=anyvalue($tmprst,"outurl",0);
if (dftval($_GET["dbnm"],"")==""){
  $dinfo=array();
  $dinfo=getdbinfo(glb(),$tbnmx,$dinfo);
}else{
  $dinfo=array();
  $dinfo=getdbinfo(dftval($_GET["dbnm"],""),$tbnmx,$dinfo);
}
$conn=mysql_connect(gl(),glu(),glp());
$shortrst=selectedx($conn,glb(),"select SNO,describ,jsfiles,cssfiles,scriptx,stylex,CRTM,UPTM from coode_mydbstcss where shortid='".$sid."'","utf8","");//比较公私分离是否成功,展示比较用hcss2
$totrst=countresult($shortrst);
if ($totrst>0){
  $shortsno=anyvalue($shortrst,"SNO",0);
  $shortjsf=tostring(anyvalue($shortrst,"jsfiles",0));
  $shortcssf=tostring(anyvalue($shortrst,"cssfiles",0));
  $shortscpt=tostring(anyvalue($shortrst,"scriptx",0));
  $shortstl=tostring(anyvalue($shortrst,"stylex",0)); 
};
  $fmhtml="";  
  $dftjs=$tabjspath."?date=[date];".$stjspath."?date=[date]";
  $mnujsfile=$jsfilez.";".$shortjsf.";".$cssmkjsf.";".$dftjs.";";  
  $mnucssfile=$cssfilez.";".$shortcssf.";".$cssmkcssf.";";
  $duscript='<script type="text/javascript" src="'.$dujspath.'?date=[date]"></script>';
  if ($dujspath==""){
    $mnuscpttxt=$scpttxtz."\r\n".$shortscpt."\r\n".$cssmkscpt."\r\n".$sx."\r\n";
  }else{
    $mnuscpttxt=$scpttxtz."\r\n".$shortscpt."\r\n".$cssmkscpt."\r\n".$sx."\r\n".$duscript;
  }
  $mnustltxt=$stltxtz."\r\n".$shortstl."\r\n".$cssmkstl."\r\n";  
  if ($tbheadbody==""){
    $demohtml=str_replace("[shortdata]",$tbdm,$mnusrdfrm);
    $conthtml=str_replace("[shortdata]",$tbdt,$mnusrdfrm);
  }else{
    $tbinner=str_replace("[tbheadbody]",$tbheadbody,$tabsrdfrm);
    $demohtml=str_replace("[shortdata]",$tbinner,$mnusrdfrm);
    $conthtml=str_replace("[shortdata]",$tbinner,$mnusrdfrm);
  }
  if ($datatp=="imgx"){   
   $demohtml=str_replace("[controler]","",$demohtml);
   $conthtml=str_replace("[controler]","",$conthtml);
   $demohtml=str_replace("[diyright]","",$demohtml);
   $conthtml=str_replace("[diyright]","",$conthtml);
  }else{
   $controlx=anyfunrun("controler",_get("appid"),"","drt=".String2Hex($diyright));
   $demohtml=str_replace("[controler]",$controlx,$demohtml);
   $conthtml=str_replace("[controler]",$controlx,$conthtml);
   $rightx=anyfunrun("easyright",_get("appid"),"","drt=".String2Hex($diyright));
   $demohtml=str_replace("[diyright]",$rightx,$demohtml);
   $conthtml=str_replace("[diyright]",$rightx,$conthtml);
  }
  if ($tbheadbody!=""){
   $demohtml=str_replace("[pnum]","",$demohtml);
   $demohtml=str_replace("[tabnm]",$tbnmx,$demohtml);
   $demohtml=str_replace("[tabkeys]",$shortbs["showkeys"],$demohtml);
   $demohtml=str_replace("[pskey]",$dinfo["pskey"],$demohtml);
   $demohtml=str_replace("[pstitle]",$dinfo["pstitle"],$demohtml);
   $demohtml=str_replace("[pshead]",$dinfo["pshead"],$demohtml);
   $demohtml=str_replace("[pssno]",$dinfo["pssno"],$demohtml);
   $conthtml=str_replace("[pnum]","",$conthtml);
   $conthtml=str_replace("[tabnm]",$tbnmx,$conthtml);
   $conthtml=str_replace("[tabkeys]",$shortbs["showkeys"],$conthtml);
   $conthtml=str_replace("[pskey]",$dinfo["pskey"],$conthtml);
   $conthtml=str_replace("[pstitle]",$dinfo["pstitle"],$conthtml);
   $conthtml=str_replace("[pshead]",$dinfo["pshead"],$conthtml);
   $conthtml=str_replace("[pssno]",$dinfo["pssno"],$conthtml);   
  }
  $demohtml=str_replace("[searchdemo]",$searchhtml,$demohtml);
  $conthtml=str_replace("[searchdemo]",$searchhtml,$conthtml);
  $demohtml=str_replace("[addform]",$addform,$demohtml);
  $conthtml=str_replace("[addform]",$addform,$conthtml);
  $fmhtml=$mnupagefrm;
  $fmdemo=$mnupagefrm;
   $fmhtml=str_replace("[pskey]",$dinfo["pskey"],$fmhtml);
   $fmhtml=str_replace("[pstitle]",$dinfo["pstitle"],$fmhtml);
   $fmhtml=str_replace("[pshead]",$dinfo["pshead"],$fmhtml);
   $fmhtml=str_replace("[pssno]",$dinfo["pssno"],$fmhtml);
   $fmhtml=$fmhtml."pssnostrpos-".strpos($fmhtml,"{pssno}");
  $fmhtml=str_replace("<!--thesecomJSFILES-->",formjs($mnujsfile),$fmhtml);   
  $fmdemo=str_replace("<!--thesecomJSFILES-->",formjs($mnujsfile),$fmdemo);    
  $fmhtml=str_replace("<!--thiscomHTML-->", $conthtml,$fmhtml); 
  $fmdemo=str_replace("<!--thiscomHTML-->", $demohtml,$fmdemo);    
  if ($sttitle!=""){
    $fmhtml=str_replace("<!--thistitle-->",$sttitle,$fmhtml);
    $fmdemo=str_replace("<!--thistitle-->",$sttitle,$fmdemo);
  }else{
    $fmhtml=str_replace("<!--thistitle-->",$ttitle."-".$sid."数据子表",$fmhtml);
    $fmdemo=str_replace("<!--thistitle-->",$ttitle."-".$sid."数据子表",$fmdemo);
  }
  $fmhtml=str_replace("<!--thesecomCSSFILES-->",formcss($mnucssfile),$fmhtml);
  $fmdemo=str_replace("<!--thesecomCSSFILES-->",formcss($mnucssfile),$fmdemo);
  $fmhtml=str_replace("<!--thiscomSTYLE-->",$mnustltxt.$mnucssext,$fmhtml);
  $fmdemo=str_replace("<!--thiscomSTYLE-->",$mnustltxt.$mnucssext,$fmdemo);
  $fmhtml=str_replace("<!--thiscomSCRIPT-->",$mnuscpttxt.$mnujsext,$fmhtml); 
  $fmdemo=str_replace("<!--thiscomSCRIPT-->",$mnuscpttxt.$mnujsext,$fmdemo);   
  $fmhtml=str_replace("[date]",date("YmdHis"),$fmhtml);
  $fmhtml=str_replace("{date}",date("YmdHis"),$fmhtml); 
  
    if ($allhtml!="" and strpos("xx".$allhtml,"failure")<=0){
      return $allhtml;
    }else{  
      if ($fmhtml==""){
       return "no data.";
      }else{
        if (intval($dtx)==1){
          $extx=UX("select count(*) as result from coode_myshortaffect where shortid='".$sid."' and pageid='".$caseid."' and tempid='".$caseid."' ");
         if (intval($extx)>0){
           $x=UX("update coode_myshortaffect set storage='".gohex($fmdemo)."',CRTM=UPTM where shortid='".$sid."' and pageid='".$caseid."' and tempid='".$caseid."' ");
         }else{
           $x=UX("insert into coode_myshortaffect(tablename,storage,shortid,pageid,tempid,CRTM,UPTM,CRTOR,OLMK)values('".$tbnmx."','".gohex($fmdemo)."','".$sid."','".$caseid."','".$caseid."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."')");
         }
        }        
       return $fmhtml;
      }
    }
 }
}
?>