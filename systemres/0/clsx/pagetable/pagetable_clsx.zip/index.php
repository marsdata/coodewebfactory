<?php
class pagetable{
public function anypagetblist($stid,$ffrm,$ffdt,$fps,$fbs,$tbnm,$tbkis,$wtokis,$tbcdtn,$dtp,$surl,$pg,$pgn,$odcdt){
 $appid=$_GET["appid"];
 
 eval(RESFUNSET("democode"));
 $fmkeyn="";  
  if (strpos($tbcdtn,"=")>0 or strpos($tbcdtn,">")>0 or strpos($tbcdtn,"<")>0  or strpos($tbcdtn,"null")>0 or strpos($tbcdtn,"like")>0){
    $tmpcdts=$tbcdtn;
    $tmcdthex=String2Hex($tbcdtn);
  }else{
    if ($tbcdtn!="" and str_replace(" ","",$tbcdtn)!=""){
     $tmpcdts=Hex2String($tbcdtn);
     $tmcdthex=$tbcdtn;     
    }else{
     $tmpcdts="";
     $tmcdthex="";
    };
  };
 if ($ffdt!=""){
  $tdtq=qian($ffdt,"|");
  $tdth=hou($ffdt,"|");
  $tdptq=explode(",",$tdtq);
  $tott=count($tdptq);
  $tdpth=explode(",",$tdth);
  $tmptbmid="";
  for ($m=0;$m<$tott;$m++){
   $zhuanhuan[$tdptq[$m]]=$tdptq[$m];
  };
 }; 
  if (strpos("x".$odcdt," order by ")>0){
    $ordercdt=$odcdt;
    $odhex=String2Hex($odcdt);
  }else{
   if (strlen("x".$odcdt)>0){
    $ordercdt=Hex2String($odcdt);
    if (strpos("x".$ordercdt," order by ")>0){
      $odhex=$odcdt;
    }else{
     $ordercdt="";
      $odhex="";
    };
   };
  };  
 if ($fip==""){
  $fip=gl();
 };
 if ($fus==""){
  $fus=glu();
 };
 
 if ($fbs==""){
  $fbs=glb();
 }else{
   if ($fps==""){
     $cmk=$fbs;
   };
   $fbs=glb();
 };  
 if ($fps==""){
  $fps=glp();
 };
 if ($pg=="" or $pg<1){
   $pg=1;
  };
 if($pgn!="" ){
  $pgcdt=" limit ".(($pg-1)*$pgn).",".$pgn;
 };  
  $xid=$stid;
  $_GET["tmpshortid"]=$xid;
  $appid=$_GET["appid"];
  
  
  
  if ($tbcdts=="" and $tmpcdts==""){
   $tbcdts=" 1>0 ";
  }else{
   if ($tbcdts!="" and $tmpcdts!=""){
     $tbcdts=$tbcdts." and ".$tmpcdts;
   }else{
     $tbcdts=$tbcdts." ".$tmpcdts;
   };
  };
  $shortbase=array();
  $dinfo=array();
  if (dftval($_GET["dbnm"],"")==""){
    $shortbase=shortinfo($xid,$shortbase);
    $dinfo=getdbinfo(glb(),$tbnmx,$dinfo);
  }else{
    $shortbase=dbshortinfo(dftval($_GET["dbnm"],""),$xid,$shortbase);
    $dinfo=getdbinfo(dftval($_GET["dbnm"],""),$tbnmx,$dinfo);
  }
  $diycode=$shortbase["diycode"];
  $addpage=$shortbase["addpage"];
  $addtitle=$shortbase["addtitle"];
  $sttbnm=$shortbase["tablename"];
  $caseid=$shortbase["caseid"];
  $shorttitle=$shortbase["shorttitle"];
  $updatepage=$shortbase["updatepage"];
  $detailpage=$shortbase["detailpage"];
  $additemx=$shortbase["additemx"];
  $newbutton=$shortbase["newbutton"];
  $obtn=$shortbase["obtn"];
  $vbtn=$shortbase["vbtn"];
  $xbtn=$shortbase["xbtn"];
  $oprtx=$shortbase["oprtx"];
  $headx=$shortbase["headx"];
  $sps=$shortbase["sps"];
  $stcss=array();
  $stcss=shortcss($xid,$stcss);
  $diytop=$stcss["diytop"];
  $diybottom=$stcss["diybottom"];
  $topbtn=$shortbase["topbtn"];
  $bottombtn=$shortbase["bottombtn"];
  $tbhd=$shortbase["tbhd"];
  $dtx=$shortbase["dtx"];
  $ctraw=$shortbase["ctraw"];
  $allkillbtn=$shortbase["allkillbtn"];
  $stcode=$shortbase["STCODE"];
  $gsqc=$_GET["sqc"];
  if ($dtp=="imgx"){
    $csurd=turnlab(getcodedemo("srd",qian($caseid,"."),hou($caseid,".")));
    $chtml=turnlab(getcodedemo("chtml",qian($caseid,"."),hou($caseid,".")));
  };
  $fmch="";
  $demo="";
  if ($caseid!=""){          
     $tabsrd=turnlab(tostring(getcodedemo("srd",qian($caseid,"."),hou($caseid,"."))));
     $tabtrdemo=turnlab(tostring(getcodedemo("tabtr",qian($caseid,"."),hou($caseid,"."))));
     $tabtddemo=turnlab(tostring(getcodedemo("tabtd",qian($caseid,"."),hou($caseid,"."))));
  }   
  
  $tabdemo=$shortbase["tabdemo"];  
  
  $fmtbasex=formatbase(qian($dtp,"/"),$fmtbasex);  
  $fmtbasex["dkeyexc"]=$stcode;
if ($odcdt!=""){
 $ordercdt=$odcdt;
};
  $totk=0;
 if ($tbkis=="*" or $tbkis==""){
  $gkinfo=allkeyinfo($gkinfo,glb(),$tbnm);
  $tbkis=$gkinfo["COLUMN"]["ALLKEY"];
 };
 if ($tbkis==""){
  $tbkis="SNO";
 }; 
 $stbkis="";
  if ($ffdt!="" and $ffrm==""){
    $wtokis=$ffdt;
  };
 if (strpos($tbkis,",")>0){
   $kppart=explode(",",$tbkis);
   $totkp=count($kppart);
   for ($k=0;$k<$totkp;$k++){
    if (strpos("_".$wtokis,$kppart[$k].",")>0){
    }else{
       $stbkis=$stbkis.$kppart[$k].",";
    };
   };
  }else{//不大于零 且=* 或空 不正常的情况下找
   if ($tbkis=="*" or $tbkis==""){
    $alif=allkeyinfo($alif,glb(),$tbnm);
    $kppart=explode(",",$alif["COLUMN"]["ALLKEY"]);
    $totkp=count($kppart);
    for ($k=0;$k<$totkp;$k++){
     if (strpos("_".$wtokis,$kppart[$k].",")>0){
     }else{
        $stbkis=$stbkis.$kppart[$k].",";
     };//if
    };//for  
   };//if
  };//if
  $totk=0;
//echo "stbkis---------".$stbkis;
 if ($stbkis!=""){//基本这里结合上面成功的
   $stbkis=substr($stbkis.",",0,strlen($stbkis)-1);
   $kpart=explode(",",$stbkis);
   $totk=count($kpart);
 };  
 if ($stbkis==""){
  $stbkis="SNO";
 };  
 $conn=mysql_connect($fip,$fus,$fps);  
 if (str_replace(" ","",str_replace("1>0","",$tbcdt))!=""){
   $tbcdt=str_replace("1>0","",$tbcdt);
 };
  
if (strpos("xx".$odcdt,"order by")>0){
  $ordercdt=$odcdt;
}else{
  if (strlen($odcdt)>10){
    $ordercdt=Hex2String($odcdt);
  }else{
  $ordercdt="";  
  }
};   
if ($exkkk!=""){
  if (substr($exkkk,strlen($exkkk)-1)==","){
    $extkkk=substr($exkkk,0,strlen($exkkk)-2);
  }else{    
  };
  $stbkis=$extkkk;
}else{
};
$fmodx="";
if (_post("sort")!=""){
 $sortx=json_decode(_post("sort"),true); 
 $totsx=count($sortx);
 for ($z=0;$z<$totsx;$z++){  
  if ($sortx[$z]["property"]=="id" or $sortx[$z]["property"]=="ID"){
   $fmodx=$fmodx." SNO ".$sortx[$z]["direction"].",";
  }else{
   $fmodx=$fmodx." ".$sortx[$z]["property"]." ".$sortx[$z]["direction"].",";
  }
 } 
 if ($totsx>0){
  $fmodx=killlaststr($fmodx);
 }
 $ordercdt=" order by ".$fmodx;
}
if (dftval($_GET["dbnm"],"")==""){
    $dinfo=array();
   $dinfo=getdbinfo(glb(),$tbnm,$dinfo);
  if (strpos($tbnm,",")>0){
    $conn=mysql_connect(gl(),glu(),glp());
    $totallrst=updatingx($conn,glb(),"select count(".qian($tbnm,",").".SNO) as result from ".$tbnm." where ".$tbcdts,"utf8"); 
  }else{
    $conn=mysql_connect(gl(),glu(),glp());
    $totallrst=updatingx($conn,glb(),"select count(*) as result from ".$tbnm." where ".$tbcdts,"utf8");  
  };
 }else{ 
    $dinfo=array();
    $dinfo=getdbinfo(dftval($_GET["dbnm"],""),$tbnm,$dinfo);
    $ffip=$dinfo["fip"];
    $fuser=$dinfo["fuser"];
    $fpass=$dinfo["fpass"];
    $conn=mysql_connect($ffip,$fuser,$fpass);
    if (strpos($tbnm,",")>0){
      $conn=mysql_connect($ffip,$fuser,$fpass);
      $totallrst=updatingx($conn,dftval($_GET["dbnm"],""),"select count(".qian($tbnm,",").".SNO) as result from ".$tbnm." where ".$tbcdts,"utf8"); 
    }else{
      $conn=mysql_connect($ffip,$fuser,$fpass);
      $totallrst=updatingx($conn,dftval($_GET["dbnm"],""),"select count(*) as result from ".$tbnm." where ".$tbcdts,"utf8");  
    };
}
   
 if (dftval($_GET["dbnm"],"")==""){
    $dinfo=array();
   $dinfo=getdbinfo(glb(),$tbnm,$dinfo);
   $conn=mysql_connect(gl(),glu(),glp());  
   if (_get("SNO")!=""){
    $flrst=selecteds($conn,glb(),"select ".$stbkis." from ".$tbnm." where ".$tbcdts,"utf8","");   
   }else{
    $flrst=selecteds($conn,glb(),"select ".$stbkis." from ".$tbnm." where ".$tbcdts.$ordercdt.$pgcdt,"utf8","");       
   }
  }else{
   $dinfo=array();
   $dinfo=getdbinfo(dftval($_GET["dbnm"],""),$tbnm,$dinfo);
   $ffip=$dinfo["fip"];
   $fuser=$dinfo["fuser"];
   $fpass=$dinfo["fpass"];
   $conn=mysql_connect($ffip,$fuser,$fpass);  
   if (_get("SNO")!=""){
    $flrst=selecteds($conn,dftval($_GET["dbnm"],""),"select ".$stbkis." from ".$tbnm." where ".$tbcdts,"utf8","");   
   }else{
    $flrst=selecteds($conn,dftval($_GET["dbnm"],""),"select ".$stbkis." from ".$tbnm." where ".$tbcdts.$ordercdt.$pgcdt,"utf8","");   
    
   }
  }
  $fmtbasex["sqlstr"]=gohex($ffip.$fuser.$fpass.dftval($_GET["dbnm"],"")."@select ".$stbkis." from ".$tbnm." where ".$tbcdts.$ordercdt.$pgcdt);
  $totrst=countresult($flrst); 
  $sresult=arrdata($sresult,$flrst);
  if (_get("y")=="1"){
   $keyinfo=thekeyfun($keyinfo,glb(),"SHORTID",$xid);
  }else{
   $keyinfo=thekeyfun($keyinfo,glb(),$tbnm,$stbkis);
  } 
  $dcd=fmvalue($tbnm,$_SERVER['REQUEST_URI'],"demo","",$diycode,1,$sresult);      
  $dbtn=formdiybtn($xid,$dcd);  
  $diytop=fmvalue($tbnm,$_SERVER['REQUEST_URI'],"demo","",$diytop,1,$sresult);
  $diybottom=fmvalue($tbnm,$_SERVER['REQUEST_URI'],"demo","",$diybottom,1,$sresult);
  $sresult=makedefault($sresult,$keyinfo);
  $fmcantc="";
  $fmktps="";
  $jjshow="";
  $jjpost="";
  $demo="";
  $fmch="";
  
 $fmdft="{";
 $fmjs="";
 $fmjh="";
 $fmtb="";
 $tmpdtx="";
 $fmexl="";
 $stid=$_GET["stid"];
 $xid=qian($stid,"-");
 
 $dtt = date_create();
 $sttdt=date_timestamp_get($dtt);
  if (intval($keyinfo["COLUMN"]["COUNT"])>10){
     $scolx="overflow-x:scroll;overflow-y:hidden;width:100%;padding-bottom:500px;margin-bottom:50px;";
  }else{
  };
  
if ($dtp=="html" or $dtp=="table"){     
   $diybottom=exchangestr($diybottom,$xid,$tbnm);   
  if (($tabdemo=="" or $tabdemo=="@") ){    
      $fmtbdemo=$tabsrd;
  }else{    
      $fmtbdemo=$tabdemo;    
  }
 $demodemo="[tabheadandbody]\r\n"; 
 
  if ($tabcls==""){
   $tabcls="layui-table";
  }
  if ($formcls==""){
   $formcls="layui-form";
  }
  $fmtbdemo=str_replace("[TABLE]",$tbnm,$fmtbdemo);
  $fmtbdemo=str_replace("[SKEYS]",$tbkis,$fmtbdemo);
  $fmtbdemo=str_replace("[CKEYS]",$fmcantc,$fmtbdemo);
  $fmtbdemo=str_replace("TAB_CLS",$tabcls,$fmtbdemo);
  $fmtbdemo=str_replace("FORM_CLS",$formcls,$fmtbdemo);
  
 
 $fmexlx="";
 $tmpnewrow=$ffrm;  
  $keyinfoa=$keyinfo;
  $keyinfob=$keyinfo;
  $headxyz=maketbheadin($totk,$chtml,$dtp,$tbhd,$oprtx,$headx,$keyinfoa,$kpart,$headxyz); 
  $fmexlx=$fmexlx.$headxyz["exl"].huanhang(); 
  $fmtb=""; 
  
 if ($sttbnm==$tbnm){
  if (($headdemo=="" or $headdemo=="@") or $_GET["pageid"]!=""){  
   $thead="<thead><tr rowidx=\"head\" class=\"HDTR_CLS\" style=\"HDTR:STL\">".$headxyz["ftb"]."</tr></thead>";   
   $x=UX("update coode_shortdata set headdemo='".gohex($thead)."' where shortid='".$xid."' and headdemo=''");
   $fmtb=$fmtb.$thead."<tbody>";  
  }else{
    $fmtb=$fmtb.$headdemo."<tbody>";
  }
 }else{
  $thead="<thead><tr rowidx=\"head\" class=\"HDTR_CLS\" style=\"HDTR:STL\">".$headxyz["ftb"]."</tr></thead>";    
  $fmtb=$fmtb.$thead."<tbody>";  
 } 
 $tabhead=$thead;
 $tabbody="<tbody>";
}
if (_get("SNO")!="" or $dtp!="html"){
  $tbdatax=maketbdata($totrst,$totk,$tbkis,$chtml,$oprtx,$obtn,$vbtn,$xbtn,$dtp,$headx,$appid,$tbnm,$sresult,$kpart,$keyinfo,$tbdatax,$xid);
}
if ($dtp=="html" or $dtp=="table"){    
  if (strpos($tabtrdemo,"v-for")>0){
   $maketvue=maketabvue($totk,$tabtrdemo,$tabtddemo,$dtp,$tbhd,$oprtx,$keyinfoa,$kpart,$headxyz);
   $fmtb=$fmtb.$maketvue;
   $tabbody=$tabbody.$maketvue;
  }else{
   $fmtb=$fmtb.$tbdatax["fmtb"];
   $tabbody=$tabbody.$tbdatax["fmtb"];
  }
  $tmpdtx=$tbdatax["tmpdtx"];
  $fmdft=$fmdft.$tbdatax["dft"];  
  $mctraw=makectraw($totk,$tbnm,$dtp,$ctraw,$sresult,$kinfo,$kpart);  
  $fmtb=$fmtb.$mctraw;
  $tabbody=$tabbody.$mctraw;
  $mkaop=makeaddoprt($totk,$appid,$tbnm,$tbkis,$fmdt,$dtp,$headx,$additemx,$oprtx,$keyinfo,$kpart);
  $fmtb=$fmtb.$mkaop;
  $tabbody=$tabbody.$mkaop;
  if ($additemx*1==1){
     $tmptbmid=$tmptbmid.$tmpnewrow;
  }
}
if (strpos("xx".$dtp,"json")>0){
  $mjs=makejson($fmtbasex,$keyinfo,substr($tbdatax["fmjs"],0,strlen($tbdatax["fmjs"])-1),$tbkis,$totallrst);
  $mjs=str_replace("[md5txt]",$tbdatax["fmmd5"],$mjs);
}
if ($dtp=="imgx"){      
 $fmch=$fmch.$tbdatax["fmch"];
}
if ($dtp=="excel"){      
 $fmexlx=$fmexlx.$tbdatax["exl"];
}
if ($dtp=="html" or $dtp=="table"){  
  $fmy=pagexyz($totye,$pg,$pgn,$allkillbtn,$totallrst,$tbnm,$xid);  
  $fmtb=$fmtb."</tbody>";
  $tabbody=$tabbody."</tbody>";
  $demodemo=str_replace("[tabheadandbody]",$fmtb,$demodemo);  
}
$totye=ceil((intval($totallrst)/intval($pgn)));  
if ($dtp=="html" or $dtp=="table"){ 
  $fmx=exchangestr($fmx,$xid,$tbnm);   
  $dbtn=exchangestr($dbtn,$xid,$tbnm);
  $btmsrd=$diybottom;
  $fmtbdemo=str_replace("[totrcd]",$totallrst,$fmtbdemo); 
  $fmtbdemo= str_replace("[topbtn]",$dbtn,$fmtbdemo);
  $fmtbdemo= str_replace("[diytop]",$diytop,$fmtbdemo);
  $fmtbdemo= str_replace("[diybottom]",$btmsrd,$fmtbdemo);
  $fmtbdemo= str_replace("[tmpdtx]",$tmpdtx,$fmtbdemo);
  $fmtbdemo= str_replace("[extscript]",$extscript,$fmtbdemo);
  $fmtbdemo=str_replace("[tabpage]",$fmy,$fmtbdemo);
  $fmtbdemo=str_replace("[tabnm]",$sttbnm,$fmtbdemo);
  $fmtbdemo=str_replace("[tabkeys]",$stbkis,$fmtbdemo);
  $fmtbdemo=str_replace("[tabpage]",$fmy,$fmtbdemo);  
  $fmtbdemo=str_replace("[scroll]",$scolx,$fmtbdemo);
  $tabledata=str_replace("[tbhead]",$tabhead,$fmtbdemo);  
  $tabledata=str_replace("[tbbody]",$tabbody,$tabledata);  
  $tabledata=str_replace("[tbheadbody]",$demodemo,$tabledata); 
  
  if (dftval($_GET["dbnm"],"")==""){
    $x=UX("update coode_shortdata set tabdemo='".gohex($fmtbdemo)."' where shortid='".$xid."' and tabdemo=''");  
  }else{
    $x=UX("update coode_dbshort set tabdemo='".gohex($fmtbdemo)."' where shortid='".$xid."' and tabdemo=''");  
  }
  $oritb="<table ".qian(hou($tabledata,"<table "),"</table>")."</table>";      
}//dtp-html
if ($dtp=="imgx"){
  $csurd=str_replace("[totrcd]",$totallrst,$csurd); 
  $csurd=str_replace("[topbtn]",$dbtn,$csurd);
  $csurd=str_replace("[diytop]",$diytop,$csurd);
  $csurd=str_replace("[diybottom]",$btmsrd,$csurd);
  $csurd=str_replace("[tmpdtx]",$tmpdtx,$csurd);
  $csurd=str_replace("[extscript]",$extscript,$csurd);
  $csurd=str_replace("[tabpage]",$fmy,$csurd);
  $csurd=str_replace("[tabnm]",$sttbnm,$csurd);
  $csurd=str_replace("[tabkeys]",$stbkis,$csurd);
  $csurd=str_replace("[tabpage]",$fmy,$csurd);  
  $csurd=str_replace("[scroll]",$scolx,$csurd);
  $csurd=str_replace("[pnum]","30",$csurd);
  $fmscript="";    
  $csurd=str_replace("[inner]",$fmch,$csurd);
}
 switch ($dtp){
   case "jshtm":
   return $fmjh;
   break;
   case "imgx":
   $fmpg=pagexyz($totye,$pg,$pgn,$allkillbtn,$totallrst,$tbnm,$xid); 
   $csurd=str_replace("[tabpage]",$fmpg,$csurd);
   return $csurd;
   break;
   case "excel":
   return $fmexlx; 
   break;
   case "html":
   if (_get("SNO")!=""){
      return $tbdatax["fmline"];
   }else{
      return $tabledata;     
   }
   break;
   case "table":
   if (_get("SNO")!=""){
      return $tbdatax["fmline"];
   }else{
      return $oritb;
   }
   break;
   case "diy":
    return $tmptbmid;
   break;
   default:  
    if (strpos(".".$dtp,'json')>0){
       $dttb = date_create();
       $enddt=date_timestamp_get($dttb);
       $haos=$enddt-$sttdt;
       $mjs=str_replace("[ptime]",$haos,$mjs);
       return $mjs;
    };
  }
 }
}
?>