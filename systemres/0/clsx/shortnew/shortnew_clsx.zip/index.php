<?php
class shortnew{
 public function anydetail($stid,$rfrs){ 
 $dbmk=dftval($_GET["dbmk"],"");
 $datatype=dftval($_GET["datatype"],"");
 //echo "rdrs--".$rfrs."--".$datatype;
  if ($rfrs==""){
   eval(RESFUNSET("formbase"));
   $stbase=array();
    if ($dbmk==""){
      $outurl=combineurl(localroot(),"/localxres/formx/".$stid."/detail.html");
    }else{
      $outurl=combineurl(localroot(),"/localxres/formx/".$dbmk."/".$stid."/detail.html");
    }  
    if (file_exists($outurl)){
      $allhtml=file_get_contents($outurl);
      if ($allhtml!="" and strpos("xx".$allhtml,"failure")<=0){    
       $allhtml=str_replace("[date]",date("YmdHis"),$allhtml);  
       return $allhtml;
      }
    }else{
      $frul=thisurl();
      $mvurl=makeviewurl($furl);
      header("location:/localxres/tempx/loading/index.html?pagetype=detailx&stid=".$sid."&vurl=".$mvurl);
    }
   
  }else{
    if ($datatype==""){
      $frul=thisurl();
      $mvurl=makeviewurl($furl);
      header("location:/localxres/tempx/loading/index.html?pagetype=detailx&stid=".$sid."&vurl=".$mvurl);
      echo "dtempty";
    }
  }
  //onerow 配 itemsrd    duorow 配 inline
 $zxz=eval(RESFUNSET("tabbaseinfo")); 
 eval(RESFUNSET("democode"));
 eval(RESFUNSET("formbase"));
 eval(RESFUNSET("keyfunbase"));
 eval(RESFUNSET("tabhtmlmake"));
 
  $stbase=array();
  $dinfo=array();
  
  if ($dbmk==""){
    $stbase=shortinfo($stid,$stbase);
    $dinfo=takedbinfo("",$tbnmx,$dinfo);
  }else{
    $stbase=dbshortinfo($dbmk,$stid,$stbase);
    $dinfo=takedbinfo($dbmk,$tbnmx,$dinfo);
  }
  
  $detailid=$stbase["detailid"];
  $shorttitle=$stbase["shorttitle"];
  $tabname=$stbase["tablename"];
  $dourst=SX("select scripty,styley,jsfiley,cssfiley,pagesurround,casecode,templatecode from coode_domainunit where dumark='".$detailid."'"); 
  $unittmpcode=turnlab(tostring(anyvalue($dourst,"templatecode",0)));
  $scripty=tostring(anyvalue($dourst,"scripty",0));
  $mnustltxt=$stltxtz;
  $styley=tostring(anyvalue($dourst,"styley",0));
  $jsfiley=tostring(anyvalue($dourst,"jsfiley",0));
  $jsfiley=str_replace("/localxres/csspagex/","/localxres/tempx/".qian($detailid,".")."/",$jsfiley);
  $cssfiley=tostring(anyvalue($dourst,"cssfiley",0));
  $cssfiley=str_replace("/localxres/csspagex/","/localxres/tempx/".qian($detailid,".")."/",$cssfiley);
  $pagesurround=turnlab(tostring(anyvalue($dourst,"pagesurround",0)));
  $casecode=tostring(anyvalue($dourst,"casecode",0));
  $stcss=array();
  if ($dbmk==""){
   $stcss=shortcss($stid."DETAIL",$stcss);
  }else{
    $stcss=dbshortcss($dbmk,$stid."DETAIL",$stcss);
  }
  $scriptx=$stcss["scriptx"];
  $stylex=$stcss["stylex"];
  $jsfilex=$stcss["jsfilex"];
  $cssfilex=$stcss["cssfilex"];
  $scriptext=$stcss["scriptext"];
  $styleext=$stcss["styleext"];
  $arrdx=array(array());
  $diytop=$stcss["diytop"];
  $diytop=extdemo($diytop,$stid,$tabname);
  $diybottom=$stcss["diybottom"];
  $diybottom=extdemo($diybottom,$stid,$tabname);
  
  $formsrd=$unittmpcode; 
  
   $fmrow="";
   $cgcode[0]="readonly";
   $cgcode[1]="";
   $dscode[0]="display:none;";
   $dscode[1]="";
   $extolmk=0;
   $tabkeys="";
   $tabrst=SX("select sysid,tabtitle,srckey,olmkkey,mainsqx,subsqx from coode_tablist where TABLE_NAME='".$tabname."'");
   $sysid=anyvalue($tabrst,"sysid",0);
   $tabtitle=anyvalue($tabrst,"tabtitle",0);
   $srckey=anyvalue($tabrst,"srckey",0);
   $olmkkey=anyvalue($tabrst,"olmkkey",0);
   $mainsqx=anyvalue($tabrst,"mainsqx",0);
   $subsqx=anyvalue($tabrst,"subsqx",0);
  if ($formeval==""){
   $keybase=array();
   $keybase=thekeyfun($keybase,glb(),"SHORTID",$stid);
     if ($casecode!=""){
      eval($casecode);
     };         
     if ($dbmk==""){
        $rowkeys=SX("select SNO,COLUMN_NAME,SQX,keytitle,changeable,displayed,sysshowfun,dxtype,keyexplain from coode_keydetaily where  shortid='".$stid."' order by SQX");
     }else{
        $rowkeys=SX("select SNO,COLUMN_NAME,SQX,keytitle,changeable,displayed,sysshowfun,dxtype,keyexplain from coode_dbkeydy where  shortid='".$stid."' and TABLE_CATALOG='".$dbmk."' order by SQX");
     }
   $totk=countresult($rowkeys);       
   for ($j=0;$j<$totk;$j++){              
      $onedemo=turnlab($ccode["onerow"]);
      $colname=anyvalue($rowkeys,"COLUMN_NAME",$j);
      $dxtp=anyvalue($rowkeys,"dxtype",$j); 
       if ($ccode[$dxtp."SRD"]==""){
         $itemsrd=turnlab($ccode["itemsrd"]);
         $srddemo=$itemsrd;
       }else{
         $srddemo=turnlab($ccode[$dxtp."SRD"]);
       }       
       if ($colname==$olmkkey){
         $extolmk=$extolmk+1;
       }
       $tabkeys=$tabkeys.$colname.",";
       $sqx=anyvalue($rowkeys,"SQX",$j);
       $coltitle=anyvalue($rowkeys,"keytitle",$j);
       $cgable=intval(anyvalue($rowkeys,"changeable",$j));
       $dspl=intval(anyvalue($rowkeys,"displayed",$j));
       $keyexp=anyvalue($rowkeys,"keyexplain",$j);
       $srddemo=str_replace("[key]",$colname,$srddemo);
       $srddemo=str_replace("[title]",$coltitle,$srddemo);
       $srddemo=str_replace("[dxtp]",$dxtp,$srddemo);
       $srddemo=str_replace("[rdol]",$cgcode[$cgable],$srddemo);
       $srddemo=str_replace("[dspl]",$dscode[$dspl],$srddemo);
       $srddemo=str_replace("[exp]",$keyexp,$srddemo);
       $srddemo=str_replace("{key}",$colname,$srddemo);
       if ($coltitle==""){
         $srddemo=str_replace("{title}",$colname,$srddemo);
       }else{
         $srddemo=str_replace("{title}",$coltitle,$srddemo);
       }
       $srddemo=str_replace("{dxtp}",$dxtp,$srddemo);
       $srddemo=str_replace("{rdol}",$cgcode[$cgable],$srddemo);
       $srddemo=str_replace("{dspl}",$dscode[$dspl],$srddemo);
       $srddemo=str_replace("{exp}",$keyexp,$srddemo);
       $onedemo=str_replace("[key]",$colname,$onedemo);
       $onedemo=str_replace("[title]",$coltitle,$onedemo);
       $onedemo=str_replace("[dxtp]",$dxtp,$onedemo);
       $onedemo=str_replace("[rdol]",$cgcode[$cgable],$onedemo);
       $onedemo=str_replace("[dspl]",$dscode[$dspl],$onedemo);
       $onedemo=str_replace("[exp]",$keyexp,$onedemo);
       $onedemo=str_replace("{key}",$colname,$onedemo);
       if ($coltitle==""){
        $onedemo=str_replace("{title}",$colname,$onedemo);
       }else{
        $onedemo=str_replace("{title}",$coltitle,$onedemo);
       }
       $onedemo=str_replace("{dxtp}",$dxtp,$onedemo);
       $onedemo=str_replace("{rdol}",$cgcode[$cgable],$onedemo);
       $onedemo=str_replace("{dspl}",$dscode[$dspl],$onedemo);
       $onedemo=str_replace("{exp}",$keyexp,$onedemo);
       $onedemo=str_replace("[rowx]",$srddemo,$onedemo);      
     $fmrow=$fmrow.$onedemo;
   }//for j totk
   $tabkeys=killlaststr($tabkeys);
   if ($extolmk==0){
       $onedemo=turnlab($ccode["onerow"]);
       $itemsrd=turnlab($ccode["itemsrd"]);
       $srddemo=$itemsrd;
       $colname=$olmkkey;
       $coltitle="唯一标记";
       $cgable=0;
       $dspl=0;       
       $srddemo=str_replace("[key]",$colname,$srddemo);
       $srddemo=str_replace("[title]",$coltitle,$srddemo);
       $srddemo=str_replace("[dxtp]",$dxtp,$srddemo);
       $srddemo=str_replace("[rdol]",$cgcode[$cgable],$srddemo);
       $srddemo=str_replace("[dspl]",$dscode[$dspl],$srddemo);
       $srddemo=str_replace("{key}",$colname,$srddemo);
       $srddemo=str_replace("{title}",$coltitle,$srddemo);
       $srddemo=str_replace("{dxtp}",$dxtp,$srddemo);
       $srddemo=str_replace("{rdol}",$cgcode[$cgable],$srddemo);
       $srddemo=str_replace("{dspl}",$dscode[$dspl],$srddemo);
       $onedemo=str_replace("[key]",$olmkkey,$onedemo);
       $onedemo=str_replace("[title]","唯一标记",$onedemo);
       $onedemo=str_replace("[dxtp]","varchar",$onedemo);
       $onedemo=str_replace("[rdol]",$cgcode[0],$onedemo);
       $onedemo=str_replace("[dspl]",$dscode[0],$onedemo);
       $onedemo=str_replace("{key}",$colname,$onedemo);
       $onedemo=str_replace("{title}",$coltitle,$onedemo);
       $onedemo=str_replace("{dxtp}",$dxtp,$onedemo);
       $onedemo=str_replace("{rdol}",$cgcode[$cgable],$onedemo);
       $onedemo=str_replace("{dspl}",$dscode[$dspl],$onedemo);       
       $onedemo=str_replace("{rowx}",$srddemo,$onedemo);
       $onedemo=str_replace("[rowx]",$srddemo,$onedemo);
       $fmrow=$fmrow.$onedemo;
   }
   $formsrd=str_replace("[srdinner]",$fmrow,$formsrd);
  }else{
   eval($formeval);
   //echo "wocao-".$formeval;
  }
    $diytop=$stcss["diytop"];
   $diybottom=$stcss["diybottom"];
   
   $formsrd=str_replace("[diytop]",$diytop,$formsrd);   
   $formsrd=str_replace("[diybottom]",$diybottom,$formsrd);
   $formsrd=str_replace("[showkeys]",$stbase["showkeys"],$formsrd);
   $formsrd=str_replace("[tabkeys]",$tabkeys,$formsrd);
   $formsrd=str_replace("[pskey]",$dinfo["pskey"],$formsrd);
   $formsrd=str_replace("[pstitle]",$dinfo["pstitle"],$formsrd);
   $formsrd=str_replace("[pshead]",$dinfo["pshead"],$formsrd);
   $formsrd=str_replace("[pssno]",$dinfo["pssno"],$formsrd);
   $formsrd=str_replace("[mainsqx]",$mainsqx,$formsrd);
   $formsrd=str_replace("[subsqx]",$subsqx,$formsrd);
   $formsrd=str_replace("[olmkkey]",$olmkkey,$formsrd);
   $formsrd=str_replace("[srckey]",$srckey,$formsrd);
   $formsrd=str_replace("[tabnm]",$tabname,$formsrd);
   $formsrd=str_replace("[tabname]",$tabname,$formsrd);
   $formsrd=str_replace("[tablename]",$tabname,$formsrd);
   $formsrd=str_replace("[stid]",$stid,$formsrd);
   $formsrd=str_replace("[shortid]",$stid,$formsrd);
   $formsrd=str_replace("[shorttitle]",$shorttitle."详情",$formsrd);   
   $formsrd=str_replace("[inner]","",$formsrd);
   $formsrd=str_replace("[prisno]",$mainsqx,$formsrd);
   $formsrd=str_replace("{srdinner}",$fmrow,$formsrd);
   $formsrd=str_replace("{diytop}",$diytop,$formsrd);
   $formsrd=str_replace("{diybutton}",$diybutton,$formsrd);
   $formsrd=str_replace("{diybottom}",$diybottom,$formsrd);
   $formsrd=str_replace("{diyshow}",$diyshow,$formsrd);
   $formsrd=str_replace("{bottombutton}",$bottombutton,$formsrd);
   $formsrd=str_replace("{showkeys}",$stbase["showkeys"],$formsrd);
   $formsrd=str_replace("{tabkeys}",$tabkeys,$formsrd);
   $formsrd=str_replace("{tabnm}",$tabname,$formsrd);
   $formsrd=str_replace("{tabname}",$tabname,$formsrd);
   $formsrd=str_replace("{tablename}",$tabname,$formsrd);
   $formsrd=str_replace("{stid}",$stid,$formsrd);
   $formsrd=str_replace("{shortid}",$stid,$formsrd);      
   $formsrd=str_replace("{mainsqx}",$mainsqx,$formsrd);
   $formsrd=str_replace("{prisno}",$mainsqx,$formsrd);
   $formsrd=str_replace("{subsqx}",$subsqx,$formsrd);
   $formsrd=str_replace("{olmkkey}",$olmkkey,$formsrd);
   $formsrd=str_replace("{srckey}",$srckey,$formsrd);
   $formsrd=str_replace("{inner}","",$formsrd);
   $fmhtml=$pagesurround;
   if ($sysid==""){
     $sysid="noname";
   }
    //if (dftval($_GET["dbnm"],"")==""){
      $feval=tostring(UX("select evalcode as result from coode_makedujsfile where dumark='".$detailid."'"));
    //}else{
     // $feval=tostring(UX("select evalcode as result from coode_dbmakedujsfile where dumark='".$detailid."'"));
    //}
   if ($feval!=""){
     eval($feval);
   }
   $duscript='<script type="text/javascript" src="'.$dujspath.'?date=[date]"></script>';
    if ($dujspath==""){
    }else{
      $scriptx=$scriptx."\r\n".$duscript;
    };
   if ($dbmk==""){
     $sttabjspath="/localxres/tabx/".$tabname."/".$stid."_table.js";
     $stdtljspath="/localxres/tabx/".$tabname."/".$stid."_detail.js";
     $stjspath="/localxres/tabx/".$tabname."/".$stid.".js";
   }else{
     $sttabjspath="/localxres/tabx/".$dbmk."/".$tabname."/".$stid."_table.js";
     $stdtljspath="/localxres/tabx/".$dbmk."/".$tabname."/".$stid."_detail.js";
     $stjspath="/localxres/tabx/".$dbmk."/".$tabname."/".$stid.".js";
   }
     $dftjs=$sttabjspath."?date=[date];".$stdtljspath."?date=[date];".$stjspath."?date=[date]";
     $fmhtml=str_replace("<!--thistitle-->",$shorttitle,$fmhtml);   
     $fmhtml=str_replace("<!--thesecomJSFILES-->",formjs($jsfiley.";".$dftjs.";".$jsfilex.";"),$fmhtml);
     $fmhtml=str_replace("<!--thesecomCSSFILES-->",formcss($cssfiley.";".$cssfilex),$fmhtml);
     $fmhtml=str_replace("<!--thiscomSTYLE-->",$styley.$stylex,$fmhtml);
     $fmhtml=str_replace("<!--thiscomSCRIPT-->",$scripty.$scriptx,$fmhtml);
     $fmhtml=str_replace("<!--thiscomHTML-->",$formsrd,$fmhtml);
     
     $nkdemo=makeformkdemo("form",$stid); 
     if ($dbmk==""){
       $outurl=combineurl(localroot(),"/localxres/formx/".$stid."/detail.html");
     }else{
      $outurl=combineurl(localroot(),"/localxres/formx/".$dbmk."/".$stid."/detail.html");
     }  
     $zz=overfile($outurl,$fmhtml);
     $fmhtml=str_replace("[date]",date("YmdHis"),$fmhtml);
     if ($datatype=="json"){
       return makereturnjson("1","渲染成功","");
     }else{
       return $fmhtml;
     }
 }//fun
}//cls
?>