<?php
class tabletemp{
  function maketabtemp($stid,$dbnm){
   $shortbase=array();
   $dinfo=array();
   if ($dbnm==glb()){
    $shortbase=shortinfo($stid,$shortbase);
    $dinfo=getdbinfo(glb(),$shortbase["tablename"],$dinfo);
   }else{
    $shortbase=dbshortinfo($dbnm,$xid,$shortbase);
    $dinfo=getdbinfo($dbnm,$shortbase["tablename"],$dinfo);
   }
   $diycode=$shortbase["diycode"];
   $addpage=$shortbase["addpage"];
   $addtitle=$shortbase["addtitle"];
   $tbnm=$shortbase["tablename"];
   $sttbnm=$shortbase["tablename"];
   $caseid=$shortbase["caseid"];
   $shorttitle=$shortbase["shorttitle"];
   $updatepage=$shortbase["updatepage"];
   $detailpage=$shortbase["detailpage"];
   $additemx=$shortbase["additemx"];
   $newbutton=$shortbase["newbutton"];
   $obtn=$shortbase["obtn"];
   $vbtn=$shortbase["vbtn"];
   $xbtn=$shortbase["xbtn"];
   $oprtx=$shortbase["oprtx"];
   $headx=$shortbase["headx"];
   $sps=$shortbase["sps"];
   $stcss=array();
   $stcss=shortcss($xid,$stcss);
   $diytop=$stcss["diytop"];
   $diybottom=$stcss["diybottom"];
   $topbtn=$shortbase["topbtn"];
   $bottombtn=$shortbase["bottombtn"];
   $tbhd=$shortbase["tbhd"];
   $dtx=$shortbase["dtx"];
   $ctraw=$shortbase["ctraw"];
   $allkillbtn=$shortbase["allkillbtn"];
   $stcode=$shortbase["STCODE"];
   eval(RESFUNSET("democode"));
   $csurd=turnlab(getcodedemo("srd",qian($caseid,"."),hou($caseid,".")));
   $chtml=turnlab(getcodedemo("chtml",qian($caseid,"."),hou($caseid,".")));
   if ($caseid!=""){          
     $tabsrd=turnlab(tostring(getcodedemo("srd",qian($caseid,"."),hou($caseid,"."))));
     $tabtrdemo=turnlab(tostring(getcodedemo("tabtr",qian($caseid,"."),hou($caseid,"."))));
     $tabtddemo=turnlab(tostring(getcodedemo("tabtd",qian($caseid,"."),hou($caseid,"."))));
   }     
   $tabdemo=$shortbase["tabdemo"];    
   $fmtbasex=formatbase(qian($dtp,"/"),$fmtbasex);  
   $fmtbasex["dkeyexc"]=$stcode;
   $gkinfo=allkeyinfo($gkinfo,glb(),$tbnm);
   $tbkis=$gkinfo["COLUMN"]["ALLKEY"];
   if (($tabdemo=="" or $tabdemo=="@") ){    
      $fmtbdemo=$tabsrd;
   }else{    
      $fmtbdemo=$tabdemo;    
   }
   $demodemo="[tabheadandbody]\r\n"; 
   $keyinfoa=$keyinfo;
   $keyinfob=$keyinfo;
   $headxyz=array();
   $fmtb="";
   $headxyz=maketbheadin($totk,$chtml,$dtp,$tbhd,$oprtx,$headx,$keyinfoa,$kpart,$headxyz); 
   if (($headdemo=="" or $headdemo=="@") or $_GET["pageid"]!=""){  
    $thead="<thead><tr rowidx=\"head\" class=\"HDTR_CLS\" style=\"HDTR:STL\">".$headxyz["ftb"]."</tr></thead>";    
    $fmtb=$fmtb.$thead."<tbody>";  
   }else{
    $fmtb=$fmtb.$headdemo."<tbody>";
   }
   $fmy=pagexyz($totye,$pg,$pgn,$allkillbtn,$totallrst,$tbnm,$xid);  
   $fmtb=$fmtb."</tbody>";   
   $demodemo=str_replace("[tabheadandbody]",$fmtb,$demodemo);  
   $fmtbdemo=str_replace("[totrcd]",$totallrst,$fmtbdemo); 
    $fmtbdemo= str_replace("[topbtn]",$dbtn,$fmtbdemo);
    $fmtbdemo= str_replace("[diytop]",$diytop,$fmtbdemo);
    $fmtbdemo= str_replace("[diybottom]",$btmsrd,$fmtbdemo);
    $fmtbdemo= str_replace("[tmpdtx]",$tmpdtx,$fmtbdemo);
    $fmtbdemo= str_replace("[extscript]",$extscript,$fmtbdemo);
    $fmtbdemo=str_replace("[tabpage]",$fmy,$fmtbdemo);
    $fmtbdemo=str_replace("[tabnm]",$sttbnm,$fmtbdemo);
    $fmtbdemo=str_replace("[tabkeys]",$stbkis,$fmtbdemo);
    $fmtbdemo=str_replace("[pskey]",$dinfo["pskey"],$fmtbdemo);
    $fmtbdemo=str_replace("[pstitle]",$dinfo["pstitle"],$fmtbdemo);
    $fmtbdemo=str_replace("[pshead]",$dinfo["pshead"],$fmtbdemo);
    $fmtbdemo=str_replace("[pssno]",$dinfo["pssno"],$fmtbdemo);
    $fmtbdemo=str_replace("[tabpage]",$fmy,$fmtbdemo);  
    $fmtbdemo=str_replace("[scroll]",$scolx,$fmtbdemo);
    $tabledata=str_replace("[tbhead]",$tabhead,$fmtbdemo);  
    $tabledata=str_replace("[tbbody]",$tabbody,$tabledata);  
    $tabledata=str_replace("[tbheadbody]",$demodemo,$tabledata); 
    return $tabledata;
  }
  function maketabimgx($stid,$dbnm){
   $shortbase=array();
   $dinfo=array();
   if ($dbnm==glb()){
    $shortbase=shortinfo($stid,$shortbase);
    $dinfo=getdbinfo(glb(),$shortbase["tablename"],$dinfo);
   }else{
    $shortbase=dbshortinfo($dbnm,$xid,$shortbase);
    $dinfo=getdbinfo($dbnm,$shortbase["tablename"],$dinfo);
   }
     $diycode=$shortbase["diycode"];
     $addpage=$shortbase["addpage"];
     $addtitle=$shortbase["addtitle"];
     $sttbnm=$shortbase["tablename"];
     $caseid=$shortbase["caseid"];
     $shorttitle=$shortbase["shorttitle"];
     $updatepage=$shortbase["updatepage"];
     $detailpage=$shortbase["detailpage"];
     $additemx=$shortbase["additemx"];
     $newbutton=$shortbase["newbutton"];
     $obtn=$shortbase["obtn"];
     $vbtn=$shortbase["vbtn"];
     $xbtn=$shortbase["xbtn"];
     $oprtx=$shortbase["oprtx"];
     $headx=$shortbase["headx"];
     $sps=$shortbase["sps"];
     $stcss=array();
     $stcss=shortcss($xid,$stcss);
     $diytop=$stcss["diytop"];
     $diybottom=$stcss["diybottom"];
     $topbtn=$shortbase["topbtn"];
     $bottombtn=$shortbase["bottombtn"];
     $tbhd=$shortbase["tbhd"];
     $dtx=$shortbase["dtx"];
     $ctraw=$shortbase["ctraw"];
     $allkillbtn=$shortbase["allkillbtn"]; 
     $stcode=$shortbase["STCODE"];
    $csurd=turnlab(getcodedemo("srd",qian($caseid,"."),hou($caseid,".")));
    $chtml=turnlab(getcodedemo("chtml",qian($caseid,"."),hou($caseid,".")));
    $csurd=str_replace("[totrcd]",$totallrst,$csurd); 
    $csurd=str_replace("[topbtn]",$dbtn,$csurd);
    $csurd=str_replace("[diytop]",$diytop,$csurd);
    $csurd=str_replace("[diybottom]",$btmsrd,$csurd);
    $csurd=str_replace("[tmpdtx]",$tmpdtx,$csurd);
    $csurd=str_replace("[extscript]",$extscript,$csurd);
    $csurd=str_replace("[tabpage]",$fmy,$csurd);
    $csurd=str_replace("[tabnm]",$sttbnm,$csurd);
    $csurd=str_replace("[tabkeys]",$stbkis,$csurd);
    $csurd=str_replace("[pskey]",$dinfo["pskey"],$csurd);
    $csurd=str_replace("[pstitle]",$dinfo["pstitle"],$csurd);
    $csurd=str_replace("[pshead]",$dinfo["pshead"],$csurd);
    $csurd=str_replace("[pssno]",$dinfo["pssno"],$csurd);
    $csurd=str_replace("[tabpage]",$fmy,$csurd);  
    $csurd=str_replace("[scroll]",$scolx,$csurd);
    $csurd=str_replace("[pnum]","30",$csurd);    
    $csurd=str_replace("[inner]",$fmch,$csurd);
    return $csurd;
  }//fun
}//cls
?>