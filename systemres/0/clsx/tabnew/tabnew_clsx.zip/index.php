<?php
class tabnew{
 public function anyform($stid,$rfrs){  
  if ($rfrs==""){
  eval(RESFUNSET("formbase"));
    $stbase=array();
    if ($dbmk==""){
      $stbase=shortinfo($stid,$stbase);
      $detailid=$stbase["detailid"];
      $outurl=combineurl(localroot(),"/localxres/formx/".$detailid."/thishostcore/".$stid."/"._cookie("cid")."-detail.html");
    }else{
      $stbase=dbshortinfo($dbmk,$stid,$stbase);
      $detailid=$stbase["detailid"];
      $outurl=combineurl(localroot(),"/localxres/formx/".$detailid."/".$dbmk."/".$stid."/"._cookie("cid")."-detail.html");
    }  
    $allhtml=file_get_contents($outurl);
    if ($allhtml!="" and strpos("xx".$allhtml,"failure")<=0){    
     $allhtml=str_replace("[date]",date("YmdHis"),$allhtml);  
     return $allhtml;
    }
  }
  //onerow 配 itemsrd    duorow 配 inline
 $zxz=eval(RESFUNSET("tabbaseinfo")); 
 eval(RESFUNSET("democode"));
  eval(RESFUNSET("formbase"));
  $stbase=array();
  $dinfo=array();
  if (dftval($_GET["dbnm"],"")==""){
    $stbase=shortinfo($stid,$stbase);
    $dinfo=getdbinfo(glb(),$tbnmx,$dinfo);
  }else{
    $stbase=dbshortinfo(dftval($_GET["dbnm"],""),$stid,$stbase);
    $dinfo=getdbinfo(dftval($_GET["dbnm"],""),$tbnmx,$dinfo);
  }
  
  $detailid=$stbase["detailid"];
  $shorttitle=$stbase["shorttitle"];
  $tabname=$stbase["tablename"];
  $dourst=SX("select scripty,styley,jsfiley,cssfiley,pagesurround,casecode,templatecode from coode_domainunit where dumark='".$detailid."'"); 
  $unittmpcode=turnlab(tostring(anyvalue($dourst,"templatecode",0)));
  $scripty=tostring(anyvalue($dourst,"scripty",0));
  $mnustltxt=$stltxtz;
  $styley=tostring(anyvalue($dourst,"styley",0));
  $jsfiley=tostring(anyvalue($dourst,"jsfiley",0));
  $jsfiley=str_replace("/localxres/csspagex/","/localxres/tempx/".qian($detailid,".")."/",$jsfiley);
  $cssfiley=tostring(anyvalue($dourst,"cssfiley",0));
  $cssfiley=str_replace("/localxres/csspagex/","/localxres/tempx/".qian($detailid,".")."/",$cssfiley);
  $pagesurround=turnlab(tostring(anyvalue($dourst,"pagesurround",0)));
  $casecode=tostring(anyvalue($dourst,"casecode",0));
  $stcss=array();
  $stcss=shortcss($stid."DETAIL",$stcss);
  $scriptx=$stcss["scriptx"];
  $stylex=$stcss["stylex"];
  $jsfilex=$stcss["jsfilex"];
  $cssfilex=$stcss["cssfilex"];
  $scriptext=$stcss["scriptext"];
  $styleext=$stcss["styleext"];
  $arrdx=array(array());
  $diytop=$stcss["diytop"];
  $diybottom=$stcss["diybottom"];
  $diytop=extdemo($diytop,$stid,$tabname);
  $diybottom=extdemo($diybottom,$stid,$tabname);
  //if (dftval($_GET["dbnm"],"")==""){
     $formeval=tostring(UX("select evalcode as result from coode_makeformact where dumark='".$detailid."'")); 
  //}else{
    // $formeval=tostring(UX("select evalcode as result from coode_dbmakeformact where dumark='".$detailid."'")); 
  //}  
  $qa=file_get_contents("http://".glw()."localxres/funx/tabcol?tablename=".$tabname."&dbnm=".dftval($_GET["dbnm"],"")."&cid=".$_COOKIE["cid"]."&uid=".$_COOKIE["uid"]);
  $qb=file_get_contents("http://".glw()."localxres/funx/shortdft?shortid=".$stid."&dbnm=".dftval($_GET["dbnm"],"")."&cid=".$_COOKIE["cid"]."&uid=".$_COOKIE["uid"]);
   $fmrow="";
   $fmtab="";
   $cgcode[0]="readonly";
   $cgcode[1]="";
   $dscode[0]="display:none;";
   $dscode[1]="";
   $extolmk=0;
   $tabkeys="";
   $tabrst=SX("select sysid,tabtitle,srckey,olmkkey,mainsqx,subsqx from coode_tablist where TABLE_NAME='".$tabname."'");
   $sysid=anyvalue($tabrst,"sysid",0);
   $tabtitle=anyvalue($tabrst,"tabtitle",0);
   $srckey=anyvalue($tabrst,"srckey",0);
   $olmkkey=anyvalue($tabrst,"olmkkey",0);
   $mainsqx=anyvalue($tabrst,"mainsqx",0);
   $subsqx=anyvalue($tabrst,"subsqx",0);
  if ($formeval==""){
   $keybase=array();
   $keybase=thekeyfun($keybase,glb(),"SHORTID",$stid);
   if ($casecode!=""){
    eval($casecode);
   };   
   $formsrd=$unittmpcode; 
   if (dftval($_GET["dbnm"],"")==""){
     $keyrst=SX("select SNO,COLUMN_NAME,SQX from coode_keydetaily where shortid='".$stid."' group by FLOOR(SQX) order by SQX");
   }else{
     $keyrst=SX("select SNO,COLUMN_NAME,SQX from coode_dbkeydy where shortid='".$stid."' group by FLOOR(SQX) order by SQX");
   }
   $totk=countresult($keyrst); 
   for ($j=0;$j<$totk;$j++){
    $ksqx[$j]=floor(anyvalue($keyrst,"SQX",$j)*1);
   }
   $cmax=0;
   for ($j=0;$j<$totk;$j++){
     if (dftval($_GET["dbnm"],"")==""){
        $crow=UX("select count(*) as result from coode_keydetaily where FLOOR(SQX)=".$ksqx[$j]." and shortid='".$stid."'");
        if (intval($crow)>=$cmax){
          $cmax=intval($crow);
        }
     }else{
        $crow=UX("select count(*) as result from coode_dbkeydy where FLOOR(SQX)=".$ksqx[$j]." and shortid='".$stid."'");
        if (intval($crow)>=$cmax){
          $cmax=intval($crow);
        }
     }
   }
   $fmtd="";
   for ($k=0;$k<$cmax;$k++){
     $fmtd=$fmtd."<td>[tdinnera".$k."]</td><td>[tdinnerb".$k."]</td>";
   }
   $fmtrx="<tr>".$fmtd."</tr>";
   if ($cmax>1){
     $onetrx='<tr><td >[tdinnera0]</td><td colspan="'.($cmax*2-1).'">[tdinnerb0]</td></tr>';
   }else{
     $onetrx='<tr><td >[tdinnera0]</td><td >[tdinnerb0]</td></tr>';
   }
   for ($j=0;$j<$totk;$j++){
     if (dftval($_GET["dbnm"],"")==""){
        $rowkeys=SX("select SNO,COLUMN_NAME,SQX,keytitle,changeable,displayed,sysshowfun,dxtype,keyexplain from coode_keydetaily where FLOOR(SQX)=".$ksqx[$j]." and shortid='".$stid."' order by SQX");
     }else{
        $rowkeys=SX("select SNO,COLUMN_NAME,SQX,keytitle,changeable,displayed,sysshowfun,dxtype,keyexplain from coode_dbkeydy where FLOOR(SQX)=".$ksqx[$j]." and shortid='".$stid."' order by SQX");
     }
     $totr=countresult($rowkeys);
     
     if ($totr==1){
      $fmtry=$onetrx;
      $onedemo=turnlab($ccode["onerow"]);
      $colname=anyvalue($rowkeys,"COLUMN_NAME",0);
      $dxtp=anyvalue($rowkeys,"dxtype",0); 
       if ($ccode[$dxtp."SRD"]==""){
         $itemsrd=turnlab($ccode["itemsrd"]);
         $srddemo=$itemsrd;
       }else{
         $srddemo=turnlab($ccode[$dxtp."SRD"]);
       }       
       if ($colname==$olmkkey){
         $extolmk=$extolmk+1;
       }
       $tabkeys=$tabkeys.$colname.",";
       $sqx=anyvalue($rowkeys,"SQX",0);
       $coltitle=anyvalue($rowkeys,"keytitle",0);
       $cgable=intval(anyvalue($rowkeys,"changeable",0));
       $dspl=intval(anyvalue($rowkeys,"displayed",0));
       $keyexp=anyvalue($rowkeys,"keyexplain",0);
       $srddemo=str_replace("[key]",$colname,$srddemo);
       $srddemo=str_replace("[title]",$coltitle,$srddemo);
       $srddemo=str_replace("[dxtp]",$dxtp,$srddemo);
       $srddemo=str_replace("[rdol]",$cgcode[$cgable],$srddemo);
       $srddemo=str_replace("[dspl]",$dscode[$dspl],$srddemo);
       $srddemo=str_replace("[exp]",$keyexp,$srddemo);
       $srddemo=str_replace("{key}",$colname,$srddemo);
       if ($coltitle==""){
         $srddemo=str_replace("{title}",$colname,$srddemo);
       }else{
         $srddemo=str_replace("{title}",$coltitle,$srddemo);
       }
       $srddemo=str_replace("{dxtp}",$dxtp,$srddemo);
       $srddemo=str_replace("{rdol}",$cgcode[$cgable],$srddemo);
       $srddemo=str_replace("{dspl}",$dscode[$dspl],$srddemo);
       $srddemo=str_replace("{exp}",$keyexp,$srddemo);
       $onedemo=str_replace("[key]",$colname,$onedemo);
       $onedemo=str_replace("[title]",$coltitle,$onedemo);
       $onedemo=str_replace("[dxtp]",$dxtp,$onedemo);
       $onedemo=str_replace("[rdol]",$cgcode[$cgable],$onedemo);
       $onedemo=str_replace("[dspl]",$dscode[$dspl],$onedemo);
       $onedemo=str_replace("[exp]",$keyexp,$onedemo);
       $onedemo=str_replace("{key}",$colname,$onedemo);
       if ($coltitle==""){
        $onedemo=str_replace("{title}",$colname,$onedemo);
       }else{
        $onedemo=str_replace("{title}",$coltitle,$onedemo);
       }
       $onedemo=str_replace("{dxtp}",$dxtp,$onedemo);
       $onedemo=str_replace("{rdol}",$cgcode[$cgable],$onedemo);
       $onedemo=str_replace("{dspl}",$dscode[$dspl],$onedemo);
       $onedemo=str_replace("{exp}",$keyexp,$onedemo);
       $onedemo=str_replace("[rowx]","",$onedemo);
       $fmtry=str_replace("[tdinnera0]",$onedemo,$fmtry);
       $fmtry=str_replace("[tdinnerb0]",$srddemo,$fmtry);
     }else{
       $fmtry=$fmtrx;       
      for ($k=0;$k<$totr;$k++){       
       $onedemo=turnlab($ccode["duorow"]);
       $colname=anyvalue($rowkeys,"COLUMN_NAME",$k);
       $tabkeys=$tabkeys.$colname.",";
       if ($colname=="OLMK"){
         $extolmk=$extolmk+1;
       }
       $dxtp=anyvalue($rowkeys,"dxtype",$k);
       if ($ccode[$dxtp."SRD"]==""){   
         $itemsrd=turnlab($ccode["inline"]);
         $srddemo=$itemsrd;
       }else{
         $srddemo=turnlab($ccode[$dxtp."SRD"]);         
        }
       $sqx=anyvalue($rowkeys,"SQX",$k);
       $coltitle=anyvalue($rowkeys,"keytitle",$k);
       $cgable=intval(anyvalue($rowkeys,"changeable",$k));
       $dspl=intval(anyvalue($rowkeys,"displayed",$k));
       $srddemo=str_replace("[key]",$colname,$srddemo);
       $srddemo=str_replace("[title]",$coltitle,$srddemo);
       $srddemo=str_replace("[dxtp]",$dxtp,$srddemo);
       $srddemo=str_replace("[rdol]",$cgcode[$cgable],$srddemo);
       $srddemo=str_replace("[dspl]",$dscode[$dspl],$srddemo);
       $srddemo=str_replace("{key}",$colname,$srddemo);
       $srddemo=str_replace("{title}",$coltitle,$srddemo);
       $srddemo=str_replace("{dxtp}",$dxtp,$srddemo);
       $srddemo=str_replace("{rdol}",$cgcode[$cgable],$srddemo);
       $srddemo=str_replace("{dspl}",$dscode[$dspl],$srddemo);
       $onedemo=str_replace("[key]",$colname,$onedemo);
       $onedemo=str_replace("[title]",$coltitle,$onedemo);
       $onedemo=str_replace("[dxtp]",$dxtp,$onedemo);
       $onedemo=str_replace("[rdol]",$cgcode[$cgable],$onedemo);
       $onedemo=str_replace("[dspl]",$dscode[$dspl],$onedemo);
       $onedemo=str_replace("[exp]",$keyexp,$onedemo);
       $onedemo=str_replace("{key}",$colname,$onedemo);
       if ($coltitle==""){
        $onedemo=str_replace("{title}",$colname,$onedemo);
       }else{
        $onedemo=str_replace("{title}",$coltitle,$onedemo);
       }
       $onedemo=str_replace("{dxtp}",$dxtp,$onedemo);
       $onedemo=str_replace("{rdol}",$cgcode[$cgable],$onedemo);
       $onedemo=str_replace("{dspl}",$dscode[$dspl],$onedemo);
       $onedemo=str_replace("{exp}",$keyexp,$onedemo);
       $onedemo=str_replace("[rowx]","",$onedemo);
       $fmtry=str_replace("[tdinnera".$k."]",$onedemo,$fmtry);       
       $fmtry=str_replace("[tdinnerb".$k."]",$srddemo,$fmtry);   
      }//totr for     
     }//totr=1     
     $fmtab=$fmtab.$fmtry;
   }//for j totk
   
   $tabkeys=killlaststr($tabkeys);
   if ($extolmk==0){
       $fmtry=$onetrx;
       $onedemo=turnlab($ccode["onerow"]);
       $itemsrd=turnlab($ccode["itemsrd"]);
       $srddemo=$itemsrd;
       $colname=$olmkkey;
       $coltitle="唯一标记";
       $cgable=0;
       $dspl=0;       
       $srddemo=str_replace("[key]",$colname,$srddemo);
       $srddemo=str_replace("[title]",$coltitle,$srddemo);
       $srddemo=str_replace("[dxtp]",$dxtp,$srddemo);
       $srddemo=str_replace("[rdol]",$cgcode[$cgable],$srddemo);
       $srddemo=str_replace("[dspl]",$dscode[$dspl],$srddemo);
       $srddemo=str_replace("{key}",$colname,$srddemo);
       $srddemo=str_replace("{title}",$coltitle,$srddemo);
       $srddemo=str_replace("{dxtp}",$dxtp,$srddemo);
       $srddemo=str_replace("{rdol}",$cgcode[$cgable],$srddemo);
       $srddemo=str_replace("{dspl}",$dscode[$dspl],$srddemo);
       $onedemo=str_replace("[key]",$olmkkey,$onedemo);
       $onedemo=str_replace("[title]","唯一标记",$onedemo);
       $onedemo=str_replace("[dxtp]","varchar",$onedemo);
       $onedemo=str_replace("[rdol]",$cgcode[0],$onedemo);
       $onedemo=str_replace("[dspl]",$dscode[0],$onedemo);
       $onedemo=str_replace("{key}",$colname,$onedemo);
       $onedemo=str_replace("{title}",$coltitle,$onedemo);
       $onedemo=str_replace("{dxtp}",$dxtp,$onedemo);
       $onedemo=str_replace("{rdol}",$cgcode[$cgable],$onedemo);
       $onedemo=str_replace("{dspl}",$dscode[$dspl],$onedemo);       
       $onedemo=str_replace("{rowx}","",$onedemo);
       $onedemo=str_replace("[rowx]","",$onedemo);
       $fmtry=str_replace("[tdinnera0]",$onedemo,$fmtry);
       $fmtry=str_replace("[tdinnerb0]",$srddemo,$fmtry);
       $fmtab=$fmtab.$fmtry;
   }   
   $fmtab="<table>".$fmtab."</table>";
   $diytop=$stcss["diytop"];
   $diybottom=$stcss["diybottom"];
   $formsrd=str_replace("[srdinner]",$fmtab,$formsrd);
   $formsrd=str_replace("[diytop]",$diytop,$formsrd);
   $formsrd=str_replace("[diybottom]",$diybottom,$formsrd);     
   $formsrd=str_replace("[showkeys]",$stbase["showkeys"],$formsrd);
   $formsrd=str_replace("[tabkeys]",$tabkeys,$formsrd);
   $formsrd=str_replace("[pskey]",$dinfo["pskey"],$formsrd);
   $formsrd=str_replace("[pstitle]",$dinfo["pstitle"],$formsrd);
   $formsrd=str_replace("[pshead]",$dinfo["pshead"],$formsrd);
   $formsrd=str_replace("[pssno]",$dinfo["pssno"],$formsrd);
   $formsrd=str_replace("[mainsqx]",$mainsqx,$formsrd);
   $formsrd=str_replace("[subsqx]",$subsqx,$formsrd);
   $formsrd=str_replace("[olmkkey]",$olmkkey,$formsrd);
   $formsrd=str_replace("[srckey]",$srckey,$formsrd);
   $formsrd=str_replace("[tabnm]",$tabname,$formsrd);
   $formsrd=str_replace("[tabname]",$tabname,$formsrd);
   $formsrd=str_replace("[tablename]",$tabname,$formsrd);
   $formsrd=str_replace("[stid]",$stid,$formsrd);
   $formsrd=str_replace("[shortid]",$stid,$formsrd);
   $formsrd=str_replace("[shorttitle]",$tabtitle."详情",$formsrd);   
   $formsrd=str_replace("[inner]","",$formsrd);
   $formsrd=str_replace("[prisno]",$mainsqx,$formsrd);
   $formsrd=str_replace("{srdinner}",$fmtab,$formsrd);
   $formsrd=str_replace("{diytop}",$diytop,$formsrd);
   $formsrd=str_replace("{diybottom}",$diybottom,$formsrd);
   $formsrd=str_replace("{showkeys}",$stbase["showkeys"],$formsrd);
   $formsrd=str_replace("{tabkeys}",$tabkeys,$formsrd);
   $formsrd=str_replace("{tabnm}",$tabname,$formsrd);
   $formsrd=str_replace("{tabname}",$tabname,$formsrd);
   $formsrd=str_replace("{tablename}",$tabname,$formsrd);
   $formsrd=str_replace("{stid}",$stid,$formsrd);
   $formsrd=str_replace("{shortid}",$stid,$formsrd);      
   $formsrd=str_replace("{mainsqx}",$mainsqx,$formsrd);
   $formsrd=str_replace("{prisno}",$mainsqx,$formsrd);
   $formsrd=str_replace("{subsqx}",$subsqx,$formsrd);
   $formsrd=str_replace("{olmkkey}",$olmkkey,$formsrd);
   $formsrd=str_replace("{srckey}",$srckey,$formsrd);
   $formsrd=str_replace("{inner}","",$formsrd);
  }else{
   eval($formeval);
  }
  
   $fmhtml=$pagesurround;
   if ($sysid==""){
     $sysid="noname";
   }
    //if (dftval($_GET["dbnm"],"")==""){
      $feval=tostring(UX("select evalcode as result from coode_makedujsfile where dumark='".$detailid."'"));
    //}else{
     // $feval=tostring(UX("select evalcode as result from coode_dbmakedujsfile where dumark='".$detailid."'"));
    //}
   if ($feval!=""){
     eval($feval);
   }
   $duscript='<script type="text/javascript" src="'.$dujspath.'?date=[date]"></script>';
    if ($dujspath==""){
    }else{
      $scriptx=$scriptx."\r\n".$duscript;
    };
   if (dftval($_GET["dbnm"],"")==""){
     $sttabjspath="/localxres/tabx/".$tabname."/".$stid."_table.js";
     $stdtljspath="/localxres/tabx/".$tabname."/".$stid."_detail.js";
     $stjspath="/localxres/tabx/".$tabname."/".$stid.".js";
   }else{
     $sttabjspath="/localxres/dbtabx/".$tabname."/".$stid."_table.js";
     $stdtljspath="/localxres/dbtabx/".$tabname."/".$stid."_detail.js";
     $stjspath="/localxres/dbtabx/".$tabname."/".$stid.".js";
   }
   switch($rfrs){
     case "2":
     $extb=UX("select count(*) as result from coode_shortcss where shortid='".$stid."DETAIL'");
     if (intval($extb)==0){
      $zz=UX("insert into coode_shortcss(shortid,describ,tablename,scriptext,styleext,CRTM,UPTM)select concat(shortid,'DETAIL'),shorttitle,tablename,'".gohex($scripty)."','".gohex($styley)."',CRTM,UPTM from coode_shortdata where shortid='".$stid."'");
      $scriptext=$scripty;
      $styleext=$styley;
     }else{
      $zz1=UX("update coode_shortcss set scriptext='".gohex($scripty)."' where shortid='".$stid."DETAIL' and (scriptext='' or scriptext='dTY"."PE_HEX:')");
      $zz2=UX("update coode_shortcss set styleext='".gohex($styley)."' where shortid='".$stid."DETAIL' and (styleext='' or styleext='dTY"."PE_HEX:')");
      if ($scriptext==""){
        $scriptext=$scripty;        
      }
      if ($styleext==""){
        $styleext=$styley;        
      }
     }
     $dftjs=$sttabjspath."?date=[date];".$stdtljspath."?date=[date];".$stjspath."?date=[date]";
     $fmhtml=str_replace("<!--thistitle-->",$shorttitle,$fmhtml);   
     $fmhtml=str_replace("<!--thesecomJSFILES-->",formjs($jsfiley.";".$dftjs.";".$jsfilex.";"),$fmhtml);
     $fmhtml=str_replace("<!--thesecomCSSFILES-->",formcss($cssfiley.";".$cssfilex),$fmhtml);
     $fmhtml=str_replace("<!--thiscomSTYLE-->",$stylex.$styleext,$fmhtml);
     $fmhtml=str_replace("<!--thiscomSCRIPT-->",$scriptx.$scriptext,$fmhtml);
     $fmhtml=str_replace("<!--thiscomHTML-->",$formsrd,$fmhtml);
     $fmhtml=str_replace("[date]",date("YmdHis"),$fmhtml);
     break;
     default:
     $dftjs=$sttabjspath."?date=[date];".$stdtljspath."?date=[date];".$stjspath."?date=[date]";
     $fmhtml=str_replace("<!--thistitle-->",$shorttitle,$fmhtml);   
     $fmhtml=str_replace("<!--thesecomJSFILES-->",formjs($jsfiley.";".$dftjs.";".$jsfilex.";"),$fmhtml);
     $fmhtml=str_replace("<!--thesecomCSSFILES-->",formcss($cssfiley.";".$cssfilex),$fmhtml);
     $fmhtml=str_replace("<!--thiscomSTYLE-->",$styley.$stylex,$fmhtml);
     $fmhtml=str_replace("<!--thiscomSCRIPT-->",$scripty.$scriptx,$fmhtml);
     $fmhtml=str_replace("<!--thiscomHTML-->",$formsrd,$fmhtml);
     $fmhtml=str_replace("[date]",date("YmdHis"),$fmhtml);
   }
   $nkdemo=makeformkdemo("form",$stid);
    if ($dbmk==""){
      $outurl=combineurl(localroot(),"/localxres/formx/".$detailid."/thishostcore/".$stid."/"._cookie("cid")."-detail.html");
    }else{
      $outurl=combineurl(localroot(),"/localxres/formx/".$detailid."/".$dbmk."/".$stid."/"._cookie("cid")."-detail.html");
    }  
   $zz=overfile($outurl,$fmhtml);
   return $fmhtml;
 }//fun
}//cls
?>