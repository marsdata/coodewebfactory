<?php
class workerchat{
  public function chatroomdft($crmark,$cr=array()){
     $crrst=SX("select circletotab,friendstab,groupstab,grplisttab,grprcdtab,chatpostab,chatrcdtab,chatusertab,linkbank,collecttab,svsdefinedtab,afsvstab,svshistorytab from worchat_chatroomlist where croommark='".$crmark."'");
     if (countresult($crrst)>0){
       $circletotab=anyvalue($crrst,"circletotab",0);
       $friendstab=anyvalue($crrst,"friendstab",0);
       $groupstab=anyvalue($crrst,"groupstab",0);
       $grplisttab=anyvalue($crrst,"grplisttab",0);
       $grprcdtab=anyvalue($crrst,"grprcdtab",0);
       $chatpostab=anyvalue($crrst,"chatpostab",0);
       $chatrcdtab=anyvalue($crrst,"chatrcdtab",0);
       $chatusertab=anyvalue($crrst,"chatusertab",0);
       $linkbanktab=anyvalue($crrst,"linkbank",0);
       $collecttab=anyvalue($crrst,"collecttab",0);
       $svsdefinedtab=anyvalue($crrst,"svsdefinedtab",0);
       $afsvstab=anyvalue($crrst,"afsvstab",0);
       $svshistorytab=anyvalue($crrst,"svshistorytab",0);       
       $cr["c2tab"]=$circletotab;
       $cr["fstab"]=$friendstab;
       $cr["gstab"]=$groupstab;
       $cr["gltab"]=$grplisttab;
       $cr["grtab"]=$grprcdtab;
       $cr["cptab"]=$chatpostab;
       $cr["crtab"]=$chatrcdtab;
       $cr["cutab"]=$chatusertab;
       $cr["lbtab"]=$linkbanktab;
       $cr["cltab"]=$collecttab;
       $cr["sdtab"]=$svsdefinedtab;
       $cr["astab"]=$afsvstab;
       $cr["shtab"]=$svshistorytab;
     }else{
       $cr["c2tab"]="";
       $cr["fstab"]="";
       $cr["gstab"]="";
       $cr["gltab"]="";
       $cr["grtab"]="";
       $cr["cptab"]="";
       $cr["crtab"]="";
       $cr["cutab"]="";
       $cr["lbtab"]="";
       $cr["cltab"]="";
       $cr["sdtab"]="";
       $cr["astab"]="";
       $cr["shtab"]="";
     }
     return $cr;
  }
  public function abmakefriend($auid,$buid,$crmx){
   $crmy=array();
   $crmy=$this->chatroomdft($crmx,$crmy);
    $c2tab=$crmy["c2tab"];
    $fstab=$crmy["fstab"];
    $gstab=$crmy["gstab"];
    $gltab=$crmy["gltab"];
    $grtab=$crmy["grtab"];
    $cptab=$crmy["cptab"];
    $crtab=$crmy["crtab"];
    $cutab=$crmy["cutab"];
    $lbtab=$crmy["lbtab"];
    $cltab=$crmy["cltab"];
    $sdtab=$crmy["sdtab"];
    $astab=$crmy["astab"];
    $shtab=$crmy["shtab"];
   if ($cutab!=""){     
     $comid=UZ("select comid as result from ".$cutab." where uid='".$auid."'");
     $sqlx="uid,frienduid,STATUS,CRTM,UPTM,OLMK,CRTOR,comid";
     $sqly="'".$auid."','".$buid."',1,now(),now(),'".onlymark()."','".$auid."','".$comid."'";
     $extab=UX("select count(*) from worchat_worchatfriends  where uid='".$auid."' and frienduid='".$buid."' and comid='".$comid."'");
     if ($extab*1==0){
      $z=UX("insert into worchat_worchatfriends(".$sqlx.")values(".$sqly.")");      
     }
     $extba=UX("select count(*) from worchat_worchatfriends  where uid='".$buid."' and frienduid='".$auid."' and comid='".$comid."'");
     $sqlz="'".$buid."','".$auid."',1,now(),now(),'".onlymark()."','".$buid."','".$comid."'";
     if ($extba*1==0){
      $z=UX("insert into worchat_worchatfriends(".$sqlx.")values(".$sqlz.")");
     }
     $fstab="worchat_worchatfriends";
     $cutab="coode_svsuser";
     $z1=UX("update worchat_worchatfriends,coode_svsuser set ".$fstab.".uname=".$cutab.".realname,".$fstab.".vxuid=".$cutab.".vxuid,".$fstab.".uheadx=".$cutab.".headpic,".$fstab.".unick=".$cutab.".nickname where ".$fstab.".uid=".$cutab.".userid");
     $z2=UX("update worchat_worchatfriends,coode_svsuser set ".$fstab.".frienduname=".$cutab.".realname,".$fstab.".friendvxuid=".$cutab.".vxuid,".$fstab.".frienduheadx=".$cutab.".headpic,".$fstab.".friendunick=".$cutab.".nickname,".$fstab.".remarkpy=".$cutab.".pynick,".$fstab.".remarkfirst=mid(".$cutab.".pynick,1,1) where ".$fstab.".frienduid=".$cutab.".userid");
     $z=UX("update worchat_worchatfriends set STATUS=1 where uid='".$auid."' and frienduid='".$buid."' and comid='".$comid."'");
     //$z=UX("update worchat_worchatfriends set STATUS=0 where uid='".$buid."' and frienduid='".$auid."' and comid='".$comid."'");
     return true;
   }else{
     return false;
   }
  }
  public function quickanygrp($crtuid,$grpid,$grptitle,$membs,$crmx){
    $crmy=array();
    $crmy=$this->chatroomdft($crmx,$crmy);
    $c2tab=$crmy["c2tab"];
    $fstab=$crmy["fstab"];
    $gstab=$crmy["gstab"];
    $gltab=$crmy["gltab"];
    $grtab=$crmy["grtab"];
    $cptab=$crmy["cptab"];
    $crtab=$crmy["crtab"];
    $cutab=$crmy["cutab"];
    $lbtab=$crmy["lbtab"];
    $cltab=$crmy["cltab"];
    $sdtab=$crmy["sdtab"];
    $astab=$crmy["astab"];
    $shtab=$crmy["shtab"];
   if (  $fstab!="" and $gltab!=""){   
    $fuids=$membs;
    $gname=$grptitle;
    if ($fuids!="" and $crtuid!=""){
     $ptuid=explode(",",$fuids);
     $totpt=count($ptuid);
     $fmcdt="";
     $fmcdt=$fmcdt."  frienduid='".$crtuid."' ";
     for ($j=0;$j<$totpt;$j++){
      $fmcdt=$fmcdt." or frienduid='".$ptuid[$j]."' ";
     }    
     $fmcdty="(".$fmcdt.") and uid='".$crtuid."'";
     if ($grpid==""){
       $newgroupid=make_numbers(10);
     }else{
       $newgroupid=$grpid;
     }
     $uirst=SZ("select comid,grpcid from ".$cutab." where uid='".$crtuid."'");
     $crtgrpcid=anyvalue($uirst,"grpcid",0);
     $crtcid=anyvalue($uirst,"comid",0);
     
     $ext0=UZ("select count(*) as result from ".$gltab." where groupid='".$newgroupid."'");
     if (intval($ext0)==0 and $gname!=""){
      $sqla="manageruid,uheadx,grouptype,grouptitle,groupid,comid,grpcid,CRTM,UPTM,OLMK,CRTOR";
      $sqlb="'".$crtuid."','/ORG/BRAIN/images/icon/system/ss16.svg','comgroup','".$gname."','".$newgroupid."','".$crtcomid."','".$crtgrpcid."',now(),now(),'".onlymark()."','".$crtuid."'";
      $sqlc=UZ("insert into ".$gltab."(".$sqla.")values(".$sqlb.")");
      $sqlx="uheadx,utype,uid,vxuid,uname,usex,utel,unick,groupid,manageruid,comid,grpcid,CRTM,UPTM,OLMK";
      $sqly="frienduheadx,friendutype,frienduid,friendvxuid,frienduname,friendusex,friendutel,friendunick,'".$newgroupid."','".$crtuid."',comid,grpcid,now(),now(),RAND()*1000000";
      $z=UZ("insert into ".$gstab."(".$sqlx.")select ".$sqly." from ".$fstab." where ".$fmcdty." and concat('".$newgroupid."',frienduid) not in (select concat(groupid,uid) from ".$gstab.")");
      $sqld="uheadx,utype,uid,vxuid,uname,usex,utel,unick,frienduheadx,friendutype,frienduid,friendvxuid,frienduname,friendusex,friendutel,friendunick,remarkpy,remarkfirst,comid,grpcid,CRTM,UPTM,OLMK";
      $sqle="frienduheadx,friendutype,frienduid,friendvxuid,frienduname,friendusex,friendutel,friendunick,'/ORG/BRAIN/images/icon/system/ss16.svg','grp','".$newgroupid."','','".$gname."','','".$crtuid."','".$newgroupid."','abc','a',comid,grpcid,now(),now(),RAND()*10000000";
      $fmcdty=$fmcdty." and comid='".$crtcid."'";
      $sqlf=UX("insert into worchat_worchatfriends(".$sqld.")select ".$sqle." from worchat_worchatfriends where ".$fmcdty." ");
      return '{"status":"1","msg":"建立成功:'.$newgroupid.'","redirect":"/localxres/pagex/workerchat/5g8EzE/chatwithmore.html?layid=XmAKrG&tinyid=5g8EzE&groupid='.$newgroupid.'"}';
     }else{
      return '{"status":"0","msg":"建立失败:'.$newgroupid.'","redirect":""}';
     }
    }else{
     return '{"status":"0","msg":"建立失败:'.$newgroupid.'","redirect":""}';
    }
   }else{
    return '{"status":"0","msg":"建立失败:'.$newgroupid.'","redirect":""}';
   }
  }
  public function groupadd($fuids,$groupid,$crmx){   
    $crmy=array();
    $crmy=$this->chatroomdft($crmx,$crmy);
    $c2tab=$crmy["c2tab"];
    $fstab=$crmy["fstab"];
    $gstab=$crmy["gstab"];
    $gltab=$crmy["gltab"];
    $grtab=$crmy["grtab"];
    $cptab=$crmy["cptab"];
    $crtab=$crmy["crtab"];
    $cutab=$crmy["cutab"];
    $lbtab=$crmy["lbtab"];
    $cltab=$crmy["cltab"];
    $sdtab=$crmy["sdtab"];
    $astab=$crmy["astab"];
    $shtab=$crmy["shtab"];
  $demo='{"status":"0",msg:"发送失败"}';
if ( $fstab!="" and $gstab!="" and $gltab!=""){   
   if ($groupid!="" and $fuids!=""){
    $ptuid=explode(",",$fuids);
    $totpt=count($ptuid);
    $fmcdt="";  
     $uirst=SZ("select comid,grpcid from ".$cutab." where uid='".$_COOKIE["uid"]."'");
     $crtgrpcid=anyvalue($uirst,"grpcid",0);
     $crtcid=anyvalue($uirst,"comid",0);
    for ($j=0;$j<$totpt;$j++){
      $fmcdt=$fmcdt." or frienduid='".$ptuid[$j]."' ";
    }  
    $fmcdt=substr($fmcdt,3,strlen($fmcdt)-3);
    $fmcdty="(".$fmcdt.") and uid='".$_COOKIE["uid"]."'";
    $ext0=UZ("select count(*) as result from ".$gltab." where groupid='".$groupid."'");
    if (intval($ext0)>0){   
      $grst=SZ("select grouptitle,manageruid from ".$gltab." where groupid='".$groupid."'");
      $muid=anyvalue($grst,"manageruid",0);
      $gname=anyvalue($grst,"grouptitle",0);
      $sqlx="uheadx,utype,uid,vxuid,uname,usex,utel,unick,groupid,manageruid,comid,grpcid,CRTM,UPTM,OLMK";
      $sqly="frienduheadx,friendutype,frienduid,friendvxuid,frienduname,friendusex,friendutel,friendunick,'".$groupid."','".$muid."',comid,grpcid,now(),now(),RAND()*1000000";
      $z=UZ("insert into ".$gstab."(".$sqlx.")select ".$sqly." from ".$fstab." where ".$fmcdty." and concat('".$groupid."',frienduid) not in (select concat(groupid,uid) from ".$gstab.")");
      $sqld="uheadx,utype,uid,vxuid,uname,usex,utel,unick,frienduheadx,friendutype,frienduid,friendvxuid,frienduname,friendusex,friendutel,friendunick,remarkpy,remarkfirst,comid,grpcid,CRTM,UPTM,OLMK";
      $sqle="frienduheadx,friendutype,frienduid,friendvxuid,frienduname,friendusex,friendutel,friendunick,'/ORG/BRAIN/images/icon/system/ss16.svg','grp','".$groupid."','','".$gname."','','".$muid."','".$groupid."','abc','a',comid,grpcid,now(),now(),RAND()*10000000";
      $fmcdty=$fmcdty." and comid='".$crtcid."'";
      $sqlf=UX("insert into worchat_worchatfriends(".$sqld.")select ".$sqle." from worchat_worchatfriends where ".$fmcdty." ");     
      return '{"status":"1","msg":"添加成功:'.$groupid.'","redirect":"/localxres/pagex/workerchat/5g8EzE/chatwithmore.html?layid=XmAKrG&tinyid=5g8EzE&groupid='.$groupid.'"}';
    }else{
      return '{"status":"0","msg":"添加失败:不存在该群'.$groupid.'","redirect":""}';
    }  
   }else{
     return '{"status":"0","msg":"添加失败:参数不全'.$groupid.'","redirect":""}';
   }
  }else{
    return '{"status":"0","msg":"添加失败:参数不全'.$groupid.'","redirect":""}';
  }
 }
  public function newuser($uid,$crmx){
   $crmy=array();
   $crmy=$this->chatroomdft($crmx,$crmy);
    $c2tab=$crmy["c2tab"];
    $fstab=$crmy["fstab"];
    $gstab=$crmy["gstab"];
    $gltab=$crmy["gltab"];
    $grtab=$crmy["grtab"];
    $cptab=$crmy["cptab"];
    $crtab=$crmy["crtab"];
    $cutab=$crmy["cutab"];
    $lbtab=$crmy["lbtab"];
    $cltab=$crmy["cltab"];
    $sdtab=$crmy["sdtab"];
    $astab=$crmy["astab"];
    $shtab=$crmy["shtab"];
   if ( $uid!="" and $cutab!=""){   
    $extx=UX("select count(*) as result from ".$cutab." where uid='".$uid."'");    
    if (intval($extx)==0){
      $usql="uid,uheadx,vxuid,uname,unick,utype,usex,comid,CRTM,UPTM,CRTOR,OLMK";
      $xx="userid,headpic,vxuid,realname,nickname,'','',wrdid,now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";
      $z=UX("insert into ".$cutab."(".$usql.")select ".$xx." from coode_userlist where userid='".$uid."'");
      $upp=UX("update ".$cutab." set uheadx='/localxres/iconsetx/18841880246/todayfiles/2023-05-16/QrVG5U/rlzy.png' where uheadx=''");
      return true;
    }else{
      return false;
    }
  }
 }
   public function adduser($uid,$vxuid,$unm,$unc,$uhx,$coid,$crmx){
   $crmy=array();
   $crmy=$this->chatroomdft($crmx,$crmy);
    $c2tab=$crmy["c2tab"];
    $fstab=$crmy["fstab"];
    $gstab=$crmy["gstab"];
    $gltab=$crmy["gltab"];
    $grtab=$crmy["grtab"];
    $cptab=$crmy["cptab"];
    $crtab=$crmy["crtab"];
    $cutab=$crmy["cutab"];
    $lbtab=$crmy["lbtab"];
    $cltab=$crmy["cltab"];
    $sdtab=$crmy["sdtab"];
    $astab=$crmy["astab"];
    $shtab=$crmy["shtab"];
   if ( $uid!="" and $cutab!="" and $unm!="" and $uhx!="" and $coid!=""){   
    $extx=UX("select count(*) as result from ".$cutab." where uid='".$uid."'");    
    if (intval($extx)==0){
      $usql="uid,uheadx,vxuid,uname,unick,utype,usex,comid,CRTM,UPTM,CRTOR,OLMK";
      $vsql="'$uid','$uhx','".$vxuid."','$unm','".$unc."','','','$coid',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";
      $z=UX("insert into ".$cutab."(".$usql.")values(".$vsql.")");
      $upp=UX("update ".$cutab." set uheadx='/localxres/iconsetx/18841880246/todayfiles/2023-05-16/QrVG5U/rlzy.png' where uheadx=''");
      return true;
    }else{
      return false;
    }
  }
 }
  public function asendtob($fuid,$touid,$msgcont,$crmx){
   $crmy=array();
   $crmy=$this->chatroomdft($crmx,$crmy);
    $c2tab=$crmy["c2tab"];
    $fstab=$crmy["fstab"];
    $gstab=$crmy["gstab"];
    $gltab=$crmy["gltab"];
    $grtab=$crmy["grtab"];
    $cptab=$crmy["cptab"];
    $crtab=$crmy["crtab"];
    $cutab=$crmy["cutab"];
    $lbtab=$crmy["lbtab"];
    $cltab=$crmy["cltab"];
    $sdtab=$crmy["sdtab"];
    $astab=$crmy["astab"];
    $shtab=$crmy["shtab"];
   $demo='{"status":"0",msg:"发送失败","redirect":""}';
if (  $fstab!="" and $crtab!=""){   
  $omk=onlymark();  
  $msgcontent=$msgcont;
  $comid=UZ("select comid as result from ".$cutab." where uid='".$fuid."'");
  $demo_2='{"status":"-2","msg":"提交参数不全","redirect":""}';
  $demo_1='{"status":"-1","msg":"对方不是你的好友","redirect":""}';
  $demo0='{"status":"0","msg":"发送失败","redirect":""}';
  $demo1='{"status":"1","msg":"发送成功","totm":"[totm]","redirect":""}';
   if ($fuid!="" and $fuid!="un"."defined" and $touid!=""){
    $extrlt0=UX("select count(*) as result from worchat_worchatfriends where uid='".$touid."' and frienduid='".$fuid."' and comid='".$comid."' and STATUS=1");
    $extrlt1=UX("select count(*) as result from worchat_worchatfriends where uid='".$fuid."' and frienduid='".$touid."' and comid='".$comid."' and STATUS=1");  
    if ((intval($extrlt0)>0 and intval($extrlt1)>0) or $fuid=="18841888888" or $touid=="18841888888"){
     $sqlx="fromuid,touid,msgtime,msgcontent,CRTM,UPTM,OLMK";
     $sqly="'".$fuid."','".$touid."',now(),'".gohex($msgcontent)."',now(),now(),'".$omk."'";
     $z=UZ("insert into ".$crtab."(".$sqlx.")values(".$sqly.")");
     //$extz=UZ("select count(*) as result from ".$crtab." where OLMK='".$omk."'");
     if ($omk!=""){      
       $notr=UZ("select count(*) as result from ".$crtab." where touid='".$touid."' and fromuid='".$fuid."' and isread=0");
       $c=UX("update worchat_worchatfriends set STATUS=1,PRIME='".$notr."' where uid='".$touid."' and frienduid='".$fuid."' and comid='".$comid."'");
       $demo=$demo1;
       $demo=str_replace("[totm]",$notr,$demo);
       $b=UZ("update ".$crtab.",".$fstab." set ".$crtab.".fromuheadx=".$fstab.".uheadx, ".$crtab.".fromuname=".$fstab.".uname,".$crtab.".touheadx=".$fstab.".frienduheadx, ".$crtab.".touname=".$fstab.".frienduname where ".$crtab.".fromuid=".$fstab.".uid and  ".$crtab.".touid=".$fstab.".frienduid ");
     }else{
       $demo=$demo0;
     }   
    }else{
     $demo=$demo_1;
    }
   }else{
    $demo=$demo_2;
   }
   return $demo;
  }
 }
public function asendtobfile($fuid,$touid,$url,$crmx){
   $crmy=array();
   $crmy=$this->chatroomdft($crmx,$crmy);
    $c2tab=$crmy["c2tab"];
    $fstab=$crmy["fstab"];
    $gstab=$crmy["gstab"];
    $gltab=$crmy["gltab"];
    $grtab=$crmy["grtab"];
    $cptab=$crmy["cptab"];
    $crtab=$crmy["crtab"];
    $cutab=$crmy["cutab"];
    $lbtab=$crmy["lbtab"];
    $cltab=$crmy["cltab"];
    $sdtab=$crmy["sdtab"];
    $astab=$crmy["astab"];
    $shtab=$crmy["shtab"];
 $demo='{"status":"0",msg:"发送失败","redirect":""}';
 if ( $fstab!="" and $crtab!=""){   
  $omk=onlymark();  
  $msgcontent=$msgcont;
  $comid=UZ("select comid as result from ".$cutab." where uid='".$fuid."'");
  $demo_2='{"status":"-2","msg":"提交参数不全","redirect":""}';
  $demo_1='{"status":"-1","msg":"对方不是你的好友","redirect":""}';
  $demo0='{"status":"0","msg":"发送失败","redirect":""}';
  $demo1='{"status":"1","msg":"发送成功","totm":"[totm]","redirect":""}';
   if ($fuid!="" and $fuid!="un"."defined" and $touid!=""){
    $extrlt0=UX("select count(*) as result from worchat_worchatfriends where uid='".$touid."' and frienduid='".$fuid."' and comid='".$comid."'");
    $extrlt1=UX("select count(*) as result from worchat_worchatfriends where uid='".$fuid."' and frienduid='".$touid."' and comid='".$comid."'");  
    if (intval($extrlt0)>0 and intval($extrlt1)>0){
     $sqlx="fromuid,touid,msgtime,msgcontent,CRTM,UPTM,OLMK,isfile";
     $sqly="'".$fuid."','".$touid."',now(),'".$url."',now(),now(),'".$omk."',1";
     $z=UZ("insert into ".$crtab."(".$sqlx.")values(".$sqly.")");
     //$extz=UZ("select count(*) as result from ".$crtab." where OLMK='".$omk."'");
     if ($omk!=""){      
       $notr=UZ("select count(*) as result from ".$crtab." where touid='".$touid."' and fromuid='".$fuid."' and isread=0");
       $c=UX("update worchat_worchatfriends set STATUS=1,PRIME='".$notr."' where uid='".$touid."' and frienduid='".$fuid."' and comid='".$comid."'");
       $demo=$demo1;
       $demo=str_replace("[totm]",$notr,$demo);
       $b=UZ("update ".$crtab.",".$fstab." set ".$crtab.".fromuheadx=".$fstab.".uheadx, ".$crtab.".fromuname=".$fstab.".uname,".$crtab.".touheadx=".$fstab.".frienduheadx, ".$crtab.".touname=".$fstab.".frienduname where ".$crtab.".fromuid=".$fstab.".uid and  ".$crtab.".touid=".$fstab.".frienduid ");
     }else{
       $demo=$demo0;
     }   
    }else{
     $demo=$demo_1;
    }
   }else{
    $demo=$demo_2;
   }
   return $demo;
  }
}
 public function asendtogrp($aid,$groupid,$msgcont,$crmx){
   $crmy=array();
   $crmy=$this->chatroomdft($crmx,$crmy);
    $c2tab=$crmy["c2tab"];
    $fstab=$crmy["fstab"];
    $gstab=$crmy["gstab"];
    $gltab=$crmy["gltab"];
    $grtab=$crmy["grtab"];
    $cptab=$crmy["cptab"];
    $crtab=$crmy["crtab"];
    $cutab=$crmy["cutab"];
    $lbtab=$crmy["lbtab"];
    $cltab=$crmy["cltab"];
    $sdtab=$crmy["sdtab"];
    $astab=$crmy["astab"];
    $shtab=$crmy["shtab"];
 
   $demo='{"status":"0",msg:"发送失败"}';
   if ( $aid!="" and $fstab!="" and $grtab!=""){   
    $omk=onlymark();   
    $msgcontent=$msgcont;
    $comid=UZ("select comid as result from ".$cutab." where uid='".$aid."'");
    $demo_2='{"status":"-2",msg:"提交参数不全"}';
    $demo_1='{"status":"-1",msg:"您不在该群聊中"}';
    $demo0='{"status":"0",msg:"发送失败"}';
    $demo1='{"status":"1",msg:"发送成功"}';
   if ($groupid!="" and $groupid!="un"."defined" and $aid!=""){
      $extme=UZ("select count(*) as result from ".$gstab." where groupid='".$groupid."' and uid='".$aid."' ");  
     if (intval($extme)>0 ){
       $grst=SZ("select uid,uheadx,utype,vxuid,uname,usex,unick,comid,grpcid from ".$gstab." where groupid='".$groupid."' and uid<>'".$aid."'");
       $totg=countresult($grst);
       $sqlx="fromuid,touid,msgtime,msgcontent,CRTM,UPTM,OLMK,STCODE,groupid";    
       for ($i=0;$i<$totg;$i++){
         $fuid=anyvalue($grst,"uid",$i);
         $sqly="'".$aid."','".$fuid."',now(),'".gohex($msgcontent)."',now(),now(),'".onlymark()."','".$omk."','".$groupid."'"; 
         $b=UX("update  worchat_worchatfriends set PRIME=PRIME+1,STATUS=1 where uid='".$fuid."' and frienduid='".$groupid."'");
         $z=UZ("insert into ".$grtab."(".$sqlx.")values(".$sqly.")");
       }
       $extz=UZ("select count(*) as result from ".$grtab." where STCODE='".$omk."'");
       if (intval($extz)==intval($totg)){
         $b1=UZ("update ".$grtab.",".$cutab." set ".$grtab.".fromuheadx=".$cutab.".uheadx, ".$grtab.".fromuname=".$cutab.".uname where ".$grtab.".fromuid=".$cutab.".uid ");
         $b2=UZ("update ".$grtab.",".$cutab." set ".$grtab.".touheadx=".$cutab.".uheadx, ".$grtab.".touname=".$cutab.".uname where  ".$grtab.".touid=".$cutab.".uid ");
         $demo=$demo1;
       }else{
         $demo=$demo0;
       }   
     }else{
       $demo=$demo_1;
     }
   }else{
    $demo=$demo_2;
   }
   return $demo;
  }//
 } 
}
?>