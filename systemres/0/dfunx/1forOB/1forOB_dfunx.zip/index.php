<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    $fid=dftval($_GET["fid"],"");
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snox=dftval($_GET["SNO"],"");
$ptrst=SX("select srcArea,sysID,pTempID,frmType from iO_psysTemp where sNo='".$snox."'");
$srcarea=anyvalue($ptrst,"srcArea",0);
$ptempid=anyvalue($ptrst,"pTempID",0);
$sysid=anyvalue($ptrst,"sysID",0);
$frmtype=anyvalue($ptrst,"frmType",0);
if ($frmtype=="Mlist" or $frmtype=="list" ){
  $kdrst=SX("select keyMark,keyTitle from iO_dKeyDefine where tabName='tempkey' or tabName='table'");
}else if ($frmtype=="Mform" or $frmtype=="form" ){
  $kdrst=SX("select keyMark,keyTitle from iO_dKeyDefine where tabName='tempkey' or tabName='formdetail'");
}
$totkd=countresult($kdrst);
for ($j=0;$j<$totkd;$j++){
  $kmark=anyvalue($kdrst,"keyMark",$j);
  $ktitle=anyvalue($kdrst,"keyTitle",$j);
  $extx=UX("select count(*) as result from iO_TsysKeys where pTempID='".$ptempid."' and tKeyMark='".$kmark."Srd' and sysID='".$sysid."'");
  if (intval($extx)==0){
   $sqlx="srcArea,sysID,pTempID,tKeyMark,tKeyTitle,tKeyType,itemCTime,itemUTime,itemOnlyMark,itemCrtID";
   $sqly="'".$srcarea."','".$sysid."','".$ptempid."','".$kmark."Srd','".$ktitle."模板外围脚本','".$kmark."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."'";
   $zz=UX("insert into iO_TsysKeys(".$sqlx.")values(".$sqly.")");
  }
  $extx=UX("select count(*) as result from iO_TsysKeys where pTempID='".$ptempid."' and tKeyMark='".$kmark."Demo' and sysID='".$sysid."'");
  if (intval($extx)==0){
   $sqlx="srcArea,sysID,pTempID,tKeyMark,tKeyTitle,tKeyType,itemCTime,itemUTime,itemOnlyMark,itemCrtID";
   $sqly="'".$srcarea."','".$sysid."','".$ptempid."','".$kmark."Demo','".$ktitle."模板生成脚本','".$kmark."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."'";
   $zz=UX("insert into iO_TsysKeys(".$sqlx.")values(".$sqly.")");
  }
  $extx=UX("select count(*) as result from iO_TempKeys where pTempID='".$ptempid."' and tKeyMark='".$kmark."JsRun' and sysID='".$sysid."'");
  if (intval($extx)==0){
   $sqlx="srcArea,sysID,pTempID,tKeyMark,tKeyTitle,tKeyType,itemCTime,itemUTime,itemOnlyMark,itemCrtID";
   $sqly="'".$srcarea."','".$sysid."','".$ptempid."','".$kmark."JsRun','".$ktitle."模板初始执行脚本','".$kmark."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."'";
   $zz=UX("insert into iO_TsysKeys(".$sqlx.")values(".$sqly.")");
  }
  $extx=UX("select count(*) as result from iO_TempKeys where pTempID='".$ptempid."' and tKeyMark='".$kmark."Script' and sysID='".$sysid."'");
  if (intval($extx)==0){
     $sqlx="srcArea,sysID,pTempID,tKeyMark,tKeyTitle,tKeyType,itemCTime,itemUTime,itemOnlyMark,itemCrtID";
     $sqly="'".$srcarea."','".$sysid."','".$ptempid."','".$kmark."Script','".$ktitle."模板附带函数','".$kmark."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."'";
     $zz=UX("insert into iO_TsysKeys(".$sqlx.")values(".$sqly.")");
  }
}
if ($totkd>0){
  $outtxt=makereturnjson("1","生成成功","");  
}else{
  $outtxt=makereturnjson("0","不存在表格表单","");  
}
    $zz=UX("update coode_datafun set UPTM=now(),CRTM=now(), resulttxt='".str_replace("\'","\\\'",$outtxt)."' where dfunmark='".$fid."'");
    $outdatapath=combineurl(localroot(),"/localxres/dfunx/".$fid."/data.json");
    $ofx=overfile($outdatapath,$outtxt);
    echo $outtxt;
    session_write_close();
?>