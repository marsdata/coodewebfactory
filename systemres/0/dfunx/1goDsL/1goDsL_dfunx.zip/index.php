<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    $fid=dftval($_GET["fid"],"");
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snox=dftval($_GET["SNO"],"");
$fmrst=SX("select tabArea,tabName,sysID,showKeys,formID,formType,tempMark from iO_formList where sNo=".$snox);
$tempmark=anyvalue($fmrst,"tempMark",0);
$tabarea=anyvalue($fmrst,"tabArea",0);
$tabname=anyvalue($fmrst,"tabName",0);
$sysid=anyvalue($fmrst,"sysID",0);
$showkeys=anyvalue($fmrst,"showKeys",0);
$formid=anyvalue($fmrst,"formID",0);
$formtype=anyvalue($fmrst,"formType",0);
$ptkey=explode(",",$showkeys);
$totpt=count($ptkey);
$fmcdt="";
for ($i=0;$i<$totpt;$i++){
  $fmcdt=$fmcdt." or keyMark='".$ptkey[$i]."'";
}
$fmcdt=substr($fmcdt,3,strlen($fmcdt)-3);
if ($formtype=="list"){
  $dxrst=SX("select sNo,dxType from iO_dtabKeyz where (".$fmcdt.") and formID='".$formid."'");
}else{
  $dxrst=SX("select sNo,dxType from iO_dtabKeyy where (".$fmcdt.") and formID='".$formid."'");
}
$totdx=countresult($dxrst);
for ($j=0;$j<$totdx;$j++){
  $sno=anyvalue($dxrst,"sNo",$j);
  $dxtype=anyvalue($dxrst,"dxType",$j);
  if ($formtype=="list"){  
     $dd=UX("update iO_dtabKeyz set srdCode='".systkcode($sysid,$tempmark,$dxtype."Srd")."' where srdCode='' and sNo=".$sno);
     $dd=UX("update iO_dtabKeyz set htmlCode='".systkcode($sysid,$tempmark,$dxtype."Demo")."' where htmlCode='' and sNo=".$sno);
     $dd=UX("update iO_dtabKeyz set jsRunCode='".systkcode($sysid,$tempmark,$dxtype."jsRun")."' where jsRunCode='' and sNo=".$sno);
     $dd=UX("update iO_dtabKeyz set scriptCode='".systkcode($sysid,$tempmark,$dxtype."Script")."' where scriptCode='' and sNo=".$sno);
  }else{
      $dd=UX("update iO_dtabKeyy set srdCode='".systkcode($sysid,$tempmark,$dxtype."Srd")."' where srdCode='' and sNo=".$sno);
      $dd=UX("update iO_dtabKeyy set htmlCode='".systkcode($sysid,$tempmark,$dxtype."Demo")."' where htmlCode='' and sNo=".$sno);
      $dd=UX("update iO_dtabKeyy set jsRunCode='".systkcode($sysid,$tempmark,$dxtype."jsRun")."' where jsRunCode='' and sNo=".$sno);
      $dd=UX("update iO_dtabKeyy set scriptCode='".systkcode($sysid,$tempmark,$dxtype."Script")."' where scriptCode='' and sNo=".$sno);
  }
}
$outtxt=makereturnjson("1","生成成功","");
    $zz=UX("update coode_datafun set UPTM=now(),CRTM=now(), resulttxt='".str_replace("\'","\\\'",$outtxt)."' where dfunmark='".$fid."'");
    $outdatapath=combineurl(localroot(),"/localxres/dfunx/".$fid."/data.json");
    $ofx=overfile($outdatapath,$outtxt);
    echo $outtxt;
    session_write_close();
?>