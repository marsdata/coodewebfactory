<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    $fid=dftval($_GET["fid"],"");
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $areamark=dftval($_GET["areamark"],"");
$formid=dftval($_GET["formid"],"");
$frst=SX("select formTitle,dsTitle,sysID,formType,tabName from iO_formList where formID='".$formid."' and tabArea='".$areamark."'");
$totf=countresult($frst);
if (intval($totf)>0){
  $formtitle=anyvalue($frst,"formTitle",0);
  $dstitle=anyvalue($frst,"dsTitle",0);
  $sysid=anyvalue($frst,"sysID",0);
  $tabname=anyvalue($frst,"tabName",0);
  $formtype=anyvalue($frst,"formType",0);
  if ($formtype=="list"){
    $dzrst=SX("select keyMark,keyTitle,dxType,srdCode,htmlCode,scriptCode,jsRunCode from iO_dtabKeyz where formID='".$formid."' and tabArea='".$areamark."' order by sQx");
  }else{
    $dzrst=SX("select keyMark,keyTitle,dxType,srdCode,htmlCode,scriptCode,jsRunCode from iO_dtabKeyy where formID='".$formid."' and tabArea='".$areamark."' order by sQx");
  }
  $totdz=countresult($dzrst);
  $outstr='var funnames=new Array();';
  for ($b=0;$b<$totdz;$b++){
     $kmark=anyvalue($dzrst,"keyMark",$b);
     $ktitle=anyvalue($dzrst,"keyTitle",$b);
     $srdcode=tostring(anyvalue($dzrst,"srdCode",$b));
     $htmlcode=tostring(anyvalue($dzrst,"htmlCode",$b));
     $scriptcode=tostring(anyvalue($dzrst,"scriptCode",$b));
     $jsruncode=tostring(anyvalue($dzrst,"jsRunCode",$b));
     $outstr=$outstr.'funnames["'.$kmark.'Srd"]="'.qian(hou($srdcode,'unction'),'{').'";'.huanhang();
     $outstr=$outstr.'funnames["'.$kmark.'Demo"]="'.qian(hou($srdcode,'unction'),'{').'";'.huanhang();     
     $outstr=$outstr.'funnames["'.$kmark.'jsRun"]="'.qian(hou($srdcode,'unction'),'{').'";'.huanhang();
  }
  for ($b=0;$b<$totdz;$b++){
     $kmark=anyvalue($dzrst,"keyMark",$b);
     $ktitle=anyvalue($dzrst,"keyTitle",$b);
     $srdcode=tostring(anyvalue($dzrst,"srdCode",$b));
     $htmlcode=tostring(anyvalue($dzrst,"htmlCode",$b));
     $scriptcode=tostring(anyvalue($dzrst,"scriptCode",$b));
     $jsruncode=tostring(anyvalue($dzrst,"jsRunCode",$b));
     $outstr=$outstr.$scriptcode.huanhang();
  }
  for ($b=0;$b<$totdz;$b++){
     $kmark=anyvalue($dzrst,"keyMark",$b);
     $ktitle=anyvalue($dzrst,"keyTitle",$b);
     $srdcode=tostring(anyvalue($dzrst,"srdCode",$b));
     $htmlcode=tostring(anyvalue($dzrst,"htmlCode",$b));
     $scriptcode=tostring(anyvalue($dzrst,"scriptCode",$b));
     $jsruncode=tostring(anyvalue($dzrst,"jsRunCode",$b));
     $outstr=$outstr.$srdcode.huanhang();
     $outstr=$outstr.$htmlcode.huanhang();
     $outstr=$outstr.$jsruncodecode.huanhang();
  }
  $outpath=combineurl(localroot(),"/tables/".$areamark."/".$sysid."/".$tabname."/".$formid."demo.js");
  $zz=overfile($outpath,$outstr);
  $outtxt=makereturnjson("1","操作成功","");
}else{
  $outtxt=makereturnjson("1","操作失败","");
}
    $zz=UX("update coode_datafun set UPTM=now(),CRTM=now(), resulttxt='".str_replace("\'","\\\'",$outtxt)."' where dfunmark='".$fid."'");
    $outdatapath=combineurl(localroot(),"/localxres/dfunx/".$fid."/data.json");
    $ofx=overfile($outdatapath,$outtxt);
    echo $outtxt;
    session_write_close();
?>