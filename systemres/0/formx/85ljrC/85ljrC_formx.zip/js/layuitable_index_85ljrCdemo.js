kcode=new Array();
kcode["varchar50DEMO"]="[thisvalue]";
kcode["varchar50SRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["varchar50ROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function varchar50mkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["varchar50HEADSTART"]="";
kcode["varchar50START"]="";
kcode["textDEMO"]="[thisvalue]";
kcode["textSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["textROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function textmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["textHEADSTART"]="";
kcode["textSTART"]="";
kcode["inputDEMO"]="[thisvalue]";
kcode["inputSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["inputROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function inputmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["inputHEADSTART"]="";
kcode["inputSTART"]="";
kcode["richtextDEMO"]="{a href=\"javascript:void(0)\" onclick=\"newwin('编辑内容','/localxres/pagex/1/funabout/uhcN3urt/aPFAUo/index.html?tbnm=[table]&tbkey=[key]&tbsno=[thissno]')\"} 编辑{/a}";
kcode["richtextSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["richtextROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function richtextmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["richtextHEADSTART"]="";
kcode["richtextSTART"]="";
kcode["codeDEMO"]="{a href=\"javascript:void(0)\" onclick=\"newwin('编辑代码','/localxres/tempx/markdowneditor/index.html?funid=[tabname]@SNO:[thissno].[key]')\"}窗口内编辑{/a}";
kcode["codeSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["codeROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function codemkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "数据编号";
  break;
  case "OPRT":
  return "操作";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return ktitle;
  }
}
kcode["codeHEADSTART"]="";
kcode["codeSTART"]="";
kcode["tinyintDEMO"]="[thisvalue]";
kcode["tinyintSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["tinyintROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function tinyintmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["tinyintHEADSTART"]="";
kcode["tinyintSTART"]="";
kcode["intDEMO"]="[thisvalue]";
kcode["intSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["intROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function intmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["intHEADSTART"]="";
kcode["intSTART"]="";
kcode["decimal1DEMO"]="{input id=\"p_[key][thissno]\" data_step=\"0.1\" style=\"width:100px;\" data_min=\"0\" data_max=\"9999\" data_edit=\"true\"  data_digit=\"1\" value=\"[thisvalue]\"}";
kcode["decimal1SRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["decimal1ROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function decimal1mkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["decimal1HEADSTART"]="";
kcode["decimal1START"]="";
kcode["decimal2DEMO"]="{input id=\"p_[key][thissno]\" data_step=\"0.01\" style=\"width:100px;\" data_min=\"0\" data_max=\"9999\" data_edit=\"true\"  data_digit=\"2\" value=\"[thisvalue]\"}";
kcode["decimal2SRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["decimal2ROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function decimal2mkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["decimal2HEADSTART"]="";
kcode["decimal2START"]="";
kcode["decimal3DEMO"]="{input id=\"p_[key][thissno]\" data_step=\"0.001\" style=\"width:100px;\" data_min=\"0\" data_max=\"9999\" data_edit=\"true\"  data_digit=\"3\" value=\"[thisvalue]\"}";
kcode["decimal3SRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["decimal3ROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function decimal3mkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["decimal3HEADSTART"]="";
kcode["decimal3START"]="";
kcode["decimal4DEMO"]="{input id=\"p_[key][thissno]\" data_step=\"0.1\" style=\"width:100px;\" data_min=\"0\" data_max=\"9999\" data_edit=\"true\"  data_digit=\"1\" value=\"[thisvalue]\"}";
kcode["decimal4SRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["decimal4ROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function decimal4mkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["decimal4HEADSTART"]="";
kcode["decimal4START"]="";
kcode["dateDEMO"]="{input id=\"p_[key][thissno]\" class=\"demo-input\"  value=\"[thisvalue]\"}";
kcode["dateSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["dateROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function datemkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["dateHEADSTART"]="";
kcode["dateSTART"]="tm=laydatex('p_[key][thissno]');";
kcode["datetimeDEMO"]="{input id=\"p_[key][thissno]\" class=\"demo-input\"  value=\"[thisvalue]\"}";
kcode["datetimeSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["datetimeROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function datetimemkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["datetimeHEADSTART"]="";
kcode["datetimeSTART"]="dttmx=laydttmx('p_[key][thissno]');";
kcode["selectDEMO"]="functionx(selectmklistcode)";
kcode["selectSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["selectROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function selectmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["selectHEADSTART"]="";
kcode["selectSTART"]="";
function selectmklistcode(dax,vr,dkeyx,dtypex,ctxtx,dvalx,snox,dn,jsondatax){
//valuerange="[valuerange]";
$colname=dkeyx;
$snox=snox;
$clstxt=ctxtx;
$acthtm="";
$thusvalue=dvalx;
$arraydata=arrdata(jsontosx(jsondatax));
jsondata=jsondatax;
$ti=dn;
  switch(dvalx){
  case "3.14":
  return dvalx;
  break;
  default:
$clstxt=tostring($clstxt);  
  if ($clstxt!=""){
      if (strpos($clstxt,"key-")==1){
          $hk=qian(hou($clstxt,"key-"),"]");
          $clstxt=tostring($arraydata[$hk][$ti]);
      }else{
          if (strpos($clstxt,"key")==1 ){ 
             kclstxtx="";            
             $clstxt=makeclstxtbykst($clstxt,$arraydata,$ti);    
          }else{            
            $clstxt=$clstxt;
         };
      };
    $acthtm=$acthtm+' lay-filter="brickType" lay-search=""';
    $fmselect=formselect(qian($clstxt,"|"),hou($clstxt,"|"),$thusvalue,"p_"+$colname+$snox,"layui-select",$acthtm);
    return $fmselect;
   }else{
    return "";
   }
  }
}

kcode["multiselectDEMO"]="functionx(multiselectmklistcode)";
kcode["multiselectSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["multiselectROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function multiselectmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["multiselectHEADSTART"]="";
kcode["multiselectSTART"]="ms=$(\".p_[key][thissno]\").fSelect();";
function multiselectmklistcode(dax,vr,dkeyx,dtypex,ctxtx,dvalx,snox,dn,jsondatax){
//valuerange="[valuerange]";
//$colname,$snox,$clstxt,$thusvalue,$arraydata,jsondata,$ti
$colname=dkeyx;
$snox=snox;
$clstxt=ctxtx;
$acthtm="";
$thusvalue=dvalx;
$arraydata=arrdata(jsontosx(jsondatax));
jsondata=jsondatax;
$ti=dn;
  switch(dvalx){
  case "3.14":
  return dvalx;
  break;
  default:
  $clstxt=tostring($clstxt);
  if ($clstxt!=""){
      $newonex=tostring($clstxt);
      if (strpos($newonex,"key-")==1){
          $hk=qian(hou($newonex,"key-"),"]");
          $newonex=tostring($arraydata[$hk][$ti]);
      }else{
          if (strpos($newonex,"key")==1 ){ 
             kclstxtx="";
             $newonex=makeclstxtbykst($clstxt,$arraydata,$ti);
          };
      };
    $inputdemo="<input type='hidden' id='p_[key0]' value='"+$thusvalue+"'>";
    $fmselect=formselectx(qian($newonex,"|"),hou($newonex,"|"),$thusvalue,"p_"+$colname+$snox,"p_"+$colname+$snox,"");
    return $inputdemo+$fmselect;
   }else{
    return "";
   }
  }
}
kcode["checkDEMO"]="[thisvalue]";
kcode["checkSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["checkROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function checkmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["checkHEADSTART"]="";
kcode["checkSTART"]="";
kcode["multicheckDEMO"]="[thisvalue]";
kcode["multicheckSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["multicheckROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function multicheckmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["multicheckHEADSTART"]="";
kcode["multicheckSTART"]="";
kcode["imagexDEMO"]="";
kcode["imagexSRD"]="";
kcode["imagexROWSRD"]="";
function imagexmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//窗口编辑的单图管理器可以在线编辑加工图片的那种，可以替换
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["imagexHEADSTART"]="";
kcode["imagexSTART"]="";
kcode["imagesDEMO"]="";
kcode["imagesSRD"]="";
kcode["imagesROWSRD"]="";
function imagesmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["imagesHEADSTART"]="";
kcode["imagesSTART"]="";
kcode["filexDEMO"]="{a href=\"[thisvalue]\" target=\"about_blank\"}下载文件{/a}";
kcode["filexSRD"]="";
kcode["filexROWSRD"]="";
function filexmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["filexHEADSTART"]="";
kcode["filexSTART"]="";
kcode["filesDEMO"]="";
kcode["filesSRD"]="";
kcode["filesROWSRD"]="";
function filesmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["filesHEADSTART"]="";
kcode["filesSTART"]="";
kcode["varcharDEMO"]="[thisvalue]";
kcode["varcharSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["varcharROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function varcharmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["varcharHEADSTART"]="";
kcode["varcharSTART"]="";
kcode["varchar100DEMO"]="[thisvalue]";
kcode["varchar100SRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["varchar100ROWSRD"]="{span id=\"pagein\" class=\"layui-laypage-curr\"}{em class=\"layui-laypage-em\"}{/em}{em}[pgtt]{/em}{/span}";
function varchar100mkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "数据编号";
  break;
  case "OPRT":
  return "操作";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return ktitle;
  }
}
kcode["varchar100HEADSTART"]="";
kcode["varchar100START"]="";
kcode["varchar255DEMO"]="[thisvalue]";
kcode["varchar255SRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["varchar255ROWSRD"]="{a id=\"pageout\" href=\"javascript:void(0);\" onclick=\"tospage([page])\"}[pgtt]{/a}";
function varchar255mkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["varchar255HEADSTART"]="";
kcode["varchar255START"]="";
kcode["varchar1024DEMO"]="[thisvalue]";
kcode["varchar1024SRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["varchar1024ROWSRD"]="functionx(getpagesrd)";
function getpagesrd(){
//valuerange="[valuerange]";
  switch(dvalx){
  case "3.14":
  return dvalx;
  break;
  default:
  dvaly="{div id=\"customPages\" class=\"customPages\"}{a href=\"javascript:void(0)\"  onclick=\"window.open(location.href.replace('&refresh=',''))\"}{img id=\"tcg\" src=\"/localxres/iconsetx/pagecontrol/移动.svg\" style=\"width:20px;height:20px;\"}{/a}{a href=\"javascript:void(0)\" onclick=\"window.open(location.href.replace('&refresh=','')+'&refresh=1')\"}{img src=\"/localxres/iconsetx/pagecontrol/qj37.svg\" style=\"width:20px;height:20px;\"}{/a}{span class=\"layui-laypage-count\"}共[totrst]条{/span}{span class=\"layui-laypage-count\"}共[totpage]页{/span}{span class=\"layui-laypage-limits\"}[pgselect]{/span}{span class=\"layui-laypage-limits\"}[pgnum]{/span}{div class=\"layui-box layui-laypage layui-laypage-default\" id=\"layui-laypage-1\"}{a href=\"javascript:void(0);\" class=\"layui-laypage-prev\"  onclick=\"tospage([prepg])\"}《{/a}{a href=\"javascript:void(0);\" class=\"layui-laypage-first\" onclick=\"tospage(1)\"}首页{/a}  [pageinner]{a href=\"javascript:void(0);\"  class=\"layui-laypage-last\" onclick=\"tospage([totye])\"}尾页{/a}{a href=\"javascript:void(0);\" class=\"layui-laypage-next\" onclick=\"tospage([nxtpg])\"}》{/a}{/div}{/div}";
  return turnlab(dvaly);
  }
}
function varchar1024mkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["varchar1024HEADSTART"]="";
kcode["varchar1024START"]="";
kcode["chtmlDEMO"]="{a href=\"javascript:void(0)\" onclick=\"viewitem([thissno])\" style=\"[obtndspl];\" snox=\"[thissno]\"}{img src=\"/localxres/iconsetx/pagecontrol/detail5.svg\" style=\"width:20px;height:20px;\"}{/a}{a href=\"javascript:void(0)\" onclick=\"updateitem([thissno])\" style=\"[vbtndspl];\"  snox=\"[thissno]\"}{img  id=\"upd[thissno]\" src=\"/localxres/iconsetx/pagecontrol/tongguoqr.svg\" style=\"width:20px;height:20px\"}{/a}{a href=\"javascript:void(0)\" onclick=\"delitem([thissno])\"  style=\"[xbtndspl];\"  snox=\"[thissno]\"}{img  src=\"/localxres/iconsetx/pagecontrol/shanchu13.svg\" style=\"width:20px;height:20px\"}{/a}";
kcode["chtmlSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["chtmlROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function chtmlmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["chtmlHEADSTART"]="";
kcode["chtmlSTART"]="";
kcode["TABSRD"]="[diytop]{div class=\"oldTable\" style=\"overflow: auto; height: auto; magin-top: -8px;\" id=\"htmllist\"}{div class=\"loadingBox\" data-show=\"1\"}{div class=\"loadingMain\"}{div class=\"loadingCenter\"}{div class=\"loadingIcon\"}{span}{/span}{/div}{p}信息加载中,请等待{/p}{/div}{/div}{/div}  {div class=\"pagestorage\" style=\"display:none;\"}{div id=\"[shortid]storage\"}{/div}{/div}  {div class=\"console\"}    {div class=\"layui-form-item\"  style=\"margin-left:5px;margin-top:15px\"}        {div class=\"layui-input-block\" }         {span style=\"left:5px;\"}{button  class=\"button white\" lay-submit lay-filter=\"submitBut\" onclick=\"allsearch('[shortid]');\"}检索{/button}{a href=\"javascript:void(0)\" class=\"button white\" onclick=\"deliv('[shortid]',0)\"}下载与打印{/a}{span id=\"xzdz\"}{/span}         {span style=\"margin-left:0px\"} {div class=\"layui-input-inline\" style=\"margin-left:50px\" }         {input type=\"text\" id=\"searchkey\" name=\"searchkey\" required lay-verify=\"required\" placeholder=\"输入关键词\" style=\"\" autocomplete=\"off\" class=\"layui-input\"}        {/div}{a href=\"javascript:void(0);\" class=\"button black\" onclick=\"update('[shortid]',0)\"}新建{/a}&nbsp;{a href=\"javascript:void(0);\"  class=\"button black\" onclick=\"window.location.reload()\"}刷新{/a}&nbsp;{a href=\"javascript:void(0);\"  class=\"button black\" onclick=\"window.history.go(-1);\"}返回{/a}{/span}    {/div}     {/div}{div name=\"tabdiv\" style=\"[scroll];margin-left:5%;width:90%;OVERFLOW: auto;height:800px;padding:0px\"}   {form id=\"tabform\" name=\"tabform\"  class=\"layui-form\" onsubmit=\"return changesmt();\"  action=\"javascript:void(0)\"}   {/form}{/div}  {div id=\"pageskin\" }[tabpage]{/div}{/div}[diyright][controler][diybottom]";
kcode["TABWHOLE"]="{table  name=\"tabunit\" class=\"layui-table\"  style=\"TAB_STL\"  tbname=\"[tabnm]\" pskey=\"[pskey]\" pstitle=\"[pstitle]\" pshead=\"[pshead]\" pssno=\"[pssno]\" tbkies=\"[tabkeys]\"   totrcd=\"[totrcd]\"  pnum=\"[pnum]\" } [tbheadbody]{/table}";
function oprteval(){
     $("form[name='tabform']").html(bktable);
     $('.loadingBox').attr('data-show', 0);
    newtdlisten();
    listenclsduo();
     layrender();
     layui.use(['form'], function(){
     form =layui.form;
     form.on('select(brickType)', function(data){ 
     ocg=$(this).parent().parent().prev().attr("onchange");
     nv=$(this).attr("lay-value");
     if (ocg!=undefined  &&  nv!=undefined){
      if (ocg!=""){
        ocg=ocg.replace(/\<thisnewvalue\>/g,nv);
        eval(ocg);
        form.render(); 
      };
     };
   });
  }); 
    a=$("th");
    b=$("td");
    for (z=0;z<a.length;z++){
     $(a[z]).width($(b[z]).width());
    }
  }
kcode["SNODEMO"]="{input type=\"checkbox\" id=\"chk[thissno]\" name=\"chksno\"  lay-skin=\"primary\"  value=\"[thissno]\"}[thisvalue]";
kcode["SNOSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["SNOROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function intmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["SNOHEADSTART"]="";
kcode["SNOSTART"]="";
kcode["unittitleDEMO"]="[thisvalue]{a href=\"javascript:void(0)\" onclick=\"cloneunit('[SNO]')\"}{img src=\"/localxres/tabx/coode_domainunit/images/复制_copy.svg\" style=\"width:20px;height:20px\"}{/a}";
kcode["unittitleSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["unittitleROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function varcharmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["unittitleHEADSTART"]="";
kcode["unittitleSTART"]="";
kcode["unitclassDEMO"]="functionx(selectmklistcode)";
kcode["unitclassSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["unitclassROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function selectmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["unitclassHEADSTART"]="";
kcode["unitclassSTART"]="";
function selectmklistcode(dax,vr,dkeyx,dtypex,ctxtx,dvalx,snox,dn,jsondatax){
//valuerange="[valuerange]";
$colname=dkeyx;
$snox=snox;
$clstxt=ctxtx;
$acthtm="";
$thusvalue=dvalx;
$arraydata=arrdata(jsontosx(jsondatax));
jsondata=jsondatax;
$ti=dn;
  switch(dvalx){
  case "3.14":
  return dvalx;
  break;
  default:
$clstxt=tostring($clstxt);  
  if ($clstxt!=""){
      if (strpos($clstxt,"key-")==1){
          $hk=qian(hou($clstxt,"key-"),"]");
          $clstxt=tostring($arraydata[$hk][$ti]);
      }else{
          if (strpos($clstxt,"key")==1 ){ 
             kclstxtx="";            
             $clstxt=makeclstxtbykst($clstxt,$arraydata,$ti);    
          }else{            
            $clstxt=$clstxt;
         };
      };
    $acthtm=$acthtm+' lay-filter="brickType" lay-search=""';
    $fmselect=formselect(qian($clstxt,"|"),hou($clstxt,"|"),$thusvalue,"p_"+$colname+$snox,"layui-select",$acthtm);
    return $fmselect;
   }else{
    return "";
   }
  }
}

kcode["appidDEMO"]="functionx(selectmklistcode)";
kcode["appidSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["appidROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function selectmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["appidHEADSTART"]="";
kcode["appidSTART"]="";
function selectmklistcode(dax,vr,dkeyx,dtypex,ctxtx,dvalx,snox,dn,jsondatax){
//valuerange="[valuerange]";
$colname=dkeyx;
$snox=snox;
$clstxt=ctxtx;
$acthtm="";
$thusvalue=dvalx;
$arraydata=arrdata(jsontosx(jsondatax));
jsondata=jsondatax;
$ti=dn;
  switch(dvalx){
  case "3.14":
  return dvalx;
  break;
  default:
$clstxt=tostring($clstxt);  
  if ($clstxt!=""){
      if (strpos($clstxt,"key-")==1){
          $hk=qian(hou($clstxt,"key-"),"]");
          $clstxt=tostring($arraydata[$hk][$ti]);
      }else{
          if (strpos($clstxt,"key")==1 ){ 
             kclstxtx="";            
             $clstxt=makeclstxtbykst($clstxt,$arraydata,$ti);    
          }else{            
            $clstxt=$clstxt;
         };
      };
    $acthtm=$acthtm+' lay-filter="brickType" lay-search=""';
    $fmselect=formselect(qian($clstxt,"|"),hou($clstxt,"|"),$thusvalue,"p_"+$colname+$snox,"layui-select",$acthtm);
    return $fmselect;
   }else{
    return "";
   }
  }
}

kcode["unitmarkDEMO"]="function mkouttxt($snox,$thusvalue,$arraydata,$ti){ $domainmark=$arraydata[\"domainmark\"][$ti]; $unitmark=$arraydata[\"unitmark\"][$ti]; $ucls=$arraydata[\"unitclass\"][$ti]; $shuchu=$thusvalue+\"{br}\"; $shuchu=$shuchu+\"{a href=\"+syh()+\"javascript:void(0);\"+syh()+\" onclick=\"+syh()+\"window.open('/localxres/tempx/tempeditor/index.html?unitid=\"+$domainmark+\".\"+$unitmark+\"&rnd=\"+onlymark()+\"')\"+syh()+\"}编辑{/a}&nbsp;&nbsp;\"; $shuchu=$shuchu+\"{a href=\"+syh()+\"javascript:void(0);\"+syh()+\" onclick=\"+syh()+\"window.open('/localxres/funx/anyjsshort/?stid=x3deHs-pnum:100-&domain=\"+$domainmark+\"&mark=\"+$unitmark+\"')\"+syh()+\"}设置{/a}&nbsp;&nbsp;\"; $shuchu=$shuchu+\"{a href=\"+syh()+\"javascript:void(0);\"+syh()+\" onclick=\"+syh()+\"window.open('/localxres/tempx/anydir/?rdr=1&ddd=/units/\"+$domainmark+\"/&rnd=\"+onlymark()+\"')\"+syh()+\"}文件{/a}&nbsp;&nbsp;\"; $shuchu=$shuchu+\"{a href=\"+syh()+\"javascript:void(0);\"+syh()+\" onclick=\"+syh()+\"window.open('/localxres/funx/anyjsshort/?stid=bpPOVC-pnum:30-&folder=/units/\"+$domainmark+\"/&rnd=\"+onlymark()+\"')\"+syh()+\"}管理{/a}&nbsp;&nbsp;\";  if ($ucls==\"form\" || $ucls==\"Mform\" || $ucls==\"list\" || $ucls==\"Mlist\"){  $shuchu=$shuchu+\"{a href=\"+syh()+\"javascript:void(0);\"+syh()+\" onclick=\"+syh()+\"window.open('/localxres/funx/gotoeditformact/?dumark=\"+$domainmark+\".\"+$unitmark+\"')\"+syh()+\"}执行{/a}&nbsp;&nbsp;\";   $shuchu=$shuchu+\"{a href=\"+syh()+\"javascript:void(0);\"+syh()+\" onclick=\"+syh()+\"window.open('/localxres/funx/gotoeditformjs/?dumark=\"+$domainmark+\".\"+$unitmark+\"')\"+syh()+\"}js制作{/a}&nbsp;&nbsp;\";    } return turnlab($shuchu);}";
kcode["unitmarkSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["unitmarkROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function varcharmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["unitmarkHEADSTART"]="";
kcode["unitmarkSTART"]="";
kcode["domainmarkDEMO"]="[thisvalue]{br}{a href=\"javascript:void(0)\" onclick=\"window.open('/localxres/funx/anyjsshort/?stid=Wn8wkX-pnum:30-&tempid=[thisvalue].[key-unitmark]')\"}编辑菜单{/a}&nbsp;&nbsp;{a href=\"javascript:void(0)\" onclick=\"restojar('temp','[thisvalue].[key-unitmark]')\"}资源包生成{/a}";
kcode["domainmarkSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["domainmarkROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function varcharmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["domainmarkHEADSTART"]="";
kcode["domainmarkSTART"]="";
kcode["outurlDEMO"]="{a href=\"javascript:void(0);\" onclick=\"window.open('[thisvalue]')\"}访问{/a}";
kcode["outurlSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["outurlROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function varcharmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["outurlHEADSTART"]="";
kcode["outurlSTART"]="";
kcode["dumarkDEMO"]="[thisvalue]";
kcode["dumarkSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["dumarkROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function varcharmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["dumarkHEADSTART"]="";
kcode["dumarkSTART"]="";
kcode["OLMKDEMO"]="{a href=\"javascript:void(0);\" onclick=\"newwin('操作流程[thistable]','/SPEC/EDITOR/anyjsshort.php?stid=2wxVUN&accid=[key-VRT]&tablenm=[thistable]&tablesno=[thissno]&ustr=[thisshort]@SNO=[thissno]/newdftstyleXoA')\"}{img src=\"/ORG/BRAIN/images/icon/system/jurassic_process.svg\" style=\"width:20px;height:20px;\"}操作流程{/a}";
kcode["OLMKSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["OLMKROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function varcharmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["OLMKHEADSTART"]="";
kcode["OLMKSTART"]="";
kcode["STCODEDEMO"]="{a href=\"javascript:void(0)\" onclick=\"window.open('/localxres/pagex/1/tempmng/OuaxhgFc/7bLVeL/index.html?srctype=temp&srcid=[key-domainmark]')\"}获取资源{/a}{br}{a href=\"javascript:void(0)\" onclick=\"window.open('/localxres/funx/anyjsshort/?stid=kjRgcW-pnum:30-&srctype=temp&srcid=[key-domainmark]')\"}查看资源{/a}";
kcode["STCODESRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["STCODEROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function varcharmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["STCODEHEADSTART"]="";
kcode["STCODESTART"]="";
kcode["OPRTDEMO"]="{a href=\"javascript:void(0)\" onclick=\"viewitem([thissno])\" style=\"[obtndspl];\" snox=\"[thissno]\"}{img src=\"/localxres/iconsetx/pagecontrol/detail5.svg\" style=\"width:20px;height:20px;\"}{/a}{a href=\"javascript:void(0)\" onclick=\"updateitem([thissno])\" style=\"[vbtndspl];\"  snox=\"[thissno]\"}{img  id=\"upd[thissno]\" src=\"/localxres/iconsetx/pagecontrol/tongguoqr.svg\" style=\"width:20px;height:20px\"}{/a}{a href=\"javascript:void(0)\" onclick=\"delitem([thissno])\"  style=\"[xbtndspl];\"  snox=\"[thissno]\"}{img  src=\"/localxres/iconsetx/pagecontrol/shanchu13.svg\" style=\"width:20px;height:20px\"}{/a}";
kcode["OPRTSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["OPRTROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function varcharmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["OPRTHEADSTART"]="";
kcode["OPRTSTART"]="";
kcode["sysidDEMO"]="functionx(selectmklistcode)";
kcode["sysidSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["sysidROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function selectmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["sysidHEADSTART"]="";
kcode["sysidSTART"]="";
function selectmklistcode(dax,vr,dkeyx,dtypex,ctxtx,dvalx,snox,dn,jsondatax){
//valuerange="[valuerange]";
$colname=dkeyx;
$snox=snox;
$clstxt=ctxtx;
$acthtm="";
$thusvalue=dvalx;
$arraydata=arrdata(jsontosx(jsondatax));
jsondata=jsondatax;
$ti=dn;
  switch(dvalx){
  case "3.14":
  return dvalx;
  break;
  default:
$clstxt=tostring($clstxt);  
  if ($clstxt!=""){
      if (strpos($clstxt,"key-")==1){
          $hk=qian(hou($clstxt,"key-"),"]");
          $clstxt=tostring($arraydata[$hk][$ti]);
      }else{
          if (strpos($clstxt,"key")==1 ){ 
             kclstxtx="";            
             $clstxt=makeclstxtbykst($clstxt,$arraydata,$ti);    
          }else{            
            $clstxt=$clstxt;
         };
      };
    $acthtm=$acthtm+' lay-filter="brickType" lay-search=""';
    $fmselect=formselect(qian($clstxt,"|"),hou($clstxt,"|"),$thusvalue,"p_"+$colname+$snox,"layui-select",$acthtm);
    return $fmselect;
   }else{
    return "";
   }
  }
}

kcode["funclsDEMO"]="functionx(selectmklistcode)";
kcode["funclsSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["funclsROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function selectmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["funclsHEADSTART"]="";
kcode["funclsSTART"]="";
function selectmklistcode(dax,vr,dkeyx,dtypex,ctxtx,dvalx,snox,dn,jsondatax){
//valuerange="[valuerange]";
$colname=dkeyx;
$snox=snox;
$clstxt=ctxtx;
$acthtm="";
$thusvalue=dvalx;
$arraydata=arrdata(jsontosx(jsondatax));
jsondata=jsondatax;
$ti=dn;
  switch(dvalx){
  case "3.14":
  return dvalx;
  break;
  default:
$clstxt=tostring($clstxt);  
  if ($clstxt!=""){
      if (strpos($clstxt,"key-")==1){
          $hk=qian(hou($clstxt,"key-"),"]");
          $clstxt=tostring($arraydata[$hk][$ti]);
      }else{
          if (strpos($clstxt,"key")==1 ){ 
             kclstxtx="";            
             $clstxt=makeclstxtbykst($clstxt,$arraydata,$ti);    
          }else{            
            $clstxt=$clstxt;
         };
      };
    $acthtm=$acthtm+' lay-filter="brickType" lay-search=""';
    $fmselect=formselect(qian($clstxt,"|"),hou($clstxt,"|"),$thusvalue,"p_"+$colname+$snox,"layui-select",$acthtm);
    return $fmselect;
   }else{
    return "";
   }
  }
}

kcode["frmexpDEMO"]="[thisvalue]";
kcode["frmexpSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["frmexpROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function varcharmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["frmexpHEADSTART"]="";
kcode["frmexpSTART"]="";
kcode["PRIMEDEMO"]="CASE=0::{a}{/a} E@CS CASE=1:: {a href=\"javascript:void(0)\" onclick=\"F('updateres','restype=tempx&SNO=[SNO]','','PRIME[SNO]','process')\"}升级{/a} E@CS";
kcode["PRIMESRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["PRIMEROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function intmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["PRIMEHEADSTART"]="";
kcode["PRIMESTART"]="";
kcode["coloraDEMO"]="functionx(selectmklistcode)";
kcode["coloraSRD"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
kcode["coloraROWSRD"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
function selectmkheadlcode(dax,vr,dkeyx,dtypex,ctxtx,jsondatax){
//valuerange="[valuerange]";
  switch(dkeyx){
  case "SNO":
  return "<th id='tabhdSNO'>数据编号</th>";
  break;
  case "OPRT":
  return "<th id='tabhdOPRT'>操作</th>";
  break;
  default:
  ktitle="";
   for (kk=0;kk<jsondatax.ktps.length;kk++){
    if (jsondatax.ktps[kk].keyname==dkeyx){
     ktitle=jsondatax.ktps[kk].keytitle;
    }
   }
  return "<th id='tabhd"+dkeyx+"'>"+ktitle+"</th>";
  }
}
kcode["coloraHEADSTART"]="";
kcode["coloraSTART"]="";
function selectmklistcode(dax,vr,dkeyx,dtypex,ctxtx,dvalx,snox,dn,jsondatax){
//valuerange="[valuerange]";
$colname=dkeyx;
$snox=snox;
$clstxt=ctxtx;
$acthtm="";
$thusvalue=dvalx;
$arraydata=arrdata(jsontosx(jsondatax));
jsondata=jsondatax;
$ti=dn;
  switch(dvalx){
  case "3.14":
  return dvalx;
  break;
  default:
$clstxt=tostring($clstxt);  
  if ($clstxt!=""){
      if (strpos($clstxt,"key-")==1){
          $hk=qian(hou($clstxt,"key-"),"]");
          $clstxt=tostring($arraydata[$hk][$ti]);
      }else{
          if (strpos($clstxt,"key")==1 ){ 
             kclstxtx="";            
             $clstxt=makeclstxtbykst($clstxt,$arraydata,$ti);    
          }else{            
            $clstxt=$clstxt;
         };
      };
    $acthtm=$acthtm+' lay-filter="brickType" lay-search=""';
    $fmselect=formselect(qian($clstxt,"|"),hou($clstxt,"|"),$thusvalue,"p_"+$colname+$snox,"layui-select",$acthtm);
    return $fmselect;
   }else{
    return "";
   }
  }
}

