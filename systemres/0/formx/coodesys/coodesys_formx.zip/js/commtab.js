function makecomtab(jsondata,tabcode){
  if (jsondata.status>0){
	 keytitlex=new Array();
	 keynamex=new Array();
	 keydxtype=new Array();
	 keyclstxt=new Array();
	 titlex="";
	 namex="";
	 keynmx="";
	 dxtypex="";
	 clstxtx="";
	 tabdemo='<table id="'+tabcode+'">\
	         <thead>{headinner}</thead>\
	         <tbody>\
			 {bodyinner}\
			 </tbody>\
	         </table>';
	  //dataarea=jsondata.dataarea;
	  dataarea="";
	  tabkeys=jsondata.keys;
	  tabkeyx="xxx/"+tabkeys;
	  ptkey=tabkeys.split(",");
	  totkey=ptkey.length;
	  for (kk=0;kk<totkey;kk++){
		  namex=ptkey[kk];
		  keynamex[kk]=namex;
		  for (jj=0;jj<jsondata.ktps.length;jj++){		  
		   eval('keynmx=jsondata.ktps[jj].keyname;');
		   if (keynmx==namex){
			eval('titlex=jsondata.ktps[jj].keytitle;');   
			keytitlex[kk]=titlex;
			eval('dxtypex=jsondata.ktps[jj].dxtype;');   
			keydxtype[kk]=dxtypex;
			eval('clstxtx=jsondata.ktps[jj].clstxt;');   
			keyclstxt[kk]=clstxtx;
		   }
		  }
	  }
	  fmhead="";
	  for (kk=0;kk<totkey;kk++){
		  fmhead=fmhead+'<th id="th'+keynamex[kk]+'">'+keytitlex[kk]+'</th>';
	  }
	  headdemo='<tr>'+fmhead+'</tr>\r\n';
	  fmdata="";
	  //console.log("头部已完毕，身部");
	  for (ii=0;ii<jsondata.vls.length;ii++){
		itemx="";
		for (kk=0;kk<totkey;kk++){
			dval="";
			dkey=keynamex[kk];
			dtype=keydxtype[kk];
			clsx=keyclstxt[kk];
			if (tabkeyx.indexOf("SNO")>0){
			  dsno=jsondata.vls[ii].SNO;
			}else{
			  dsno=ii;
			}	
			eval('dval=jsondata.vls[ii].'+keynamex[kk]+';');
			itemx=itemx+'<td id="dt'+dkey+dsno+'">'+extabkey(dataarea,dkey,dtype,clsx,dval,ii,kk,dsno,jsondata)+'</td>';
		}			
		fmdata=fmdata+'<tr>'+itemx+'</tr>\r\n';
		//console.log('<tr>'+itemx+'</tr>\r\n');
	  }
	  tabdemo=tabdemo.replace("{headinner}",headdemo);
	  tabdemo=tabdemo.replace("{bodyinner}",fmdata);
	  return tabdemo;
  }else{
	  return "";
  }
}
function makedstab(dsdata,tabcode,oprt){
  if (dsdata.status>0){
	 keytitlex=new Array();
	 keynamex=new Array();
	 keydxtype=new Array();
	 keyclstxt=new Array();
      datatypes=dsdata.keytps;
      formtitles="";
	  formkeys="";	  
	  dxtypes="";
	  fmcls="";
	  for (j=0;j<dsdata.keytps.length;j++){
		  formtitles=formtitles+dsdata.keytps[j].keytitle+",";
		  formkeys=formkeys+dsdata.keytps[j].keyid+",";
		  dxtypes=dxtypes+dsdata.keytps[j].dxtype+",";
		  fmcls=fmcls+dsdata.keytps[j].clstxt+"/";
	  }
     formtitles=killlasttring(formtitles);
	 formkeys=killlasttring(formkeys);
	 dxtypes=killlasttring(dxtypes);
	 fmcls=killlasttring(fmcls);
	 titlex="";
	 namex="";
	 keynmx="";
	 dxtypex="";
	 clstxtx="";
	 //dataarea=jsondata.dataarea;
	 tabdemo='<table id="'+tabcode+'">\
	         <thead>{headinner}</thead>\
	         <tbody>\
			 {bodyinner}\
			 </tbody>\
	         </table>';
	 dataarea="";
      
	  ptkey=formkeys.split(",");
	  pttitle=formtitles.split(",");
	  
	  ptdxtp=dxtypes.split(",");
	  ptcls=fmcls.split("/");
	  totkey=ptkey.length;
	  for (kk=0;kk<totkey;kk++){
		  namex=ptkey[kk];
		  keynamex[kk]=namex;
		  keydxtype[kk]=ptdxtp[kk];
		  keytitlex[kk]=pttitle[kk];
          keyclstxt[kk]=ptcls[kk];
	  }
	  fmhead="";
	  for (kk=0;kk<totkey;kk++){
		  fmhead=fmhead+'<th id="th'+keynamex[kk]+'">'+keytitlex[kk]+'</th>';
	  }
	  if (oprt==1){
	      fmhead=fmhead+'<th id="thoprt">操作</th>';
	  }
	  headdemo='<tr>'+fmhead+'</tr>\r\n';
	  fmdata="";
	  //console.log("头部已完毕，身部");
	  for (ii=0;ii<dsdata.vls.length;ii++){
		itemx="";
		dsno=dsdata.vls[ii].datasno;
		for (kk=0;kk<totkey;kk++){
			dval="";
			dkey=keynamex[kk];
			dtype=keydxtype[kk];
			clsx=keyclstxt[kk];
			eval('dval=dsdata.vls[ii].'+keynamex[kk]+';');
			itemx=itemx+'<td id="dt'+dkey+dsno+'">'+extabkey(dataarea,dkey,dtype,clsx,dval,ii,kk,dsno,dsdata)+'</td>';
		}	
		if (oprt==1){
		  itemx=itemx+'<td id="dtoprt'+dsno+'">'+extabkey(dataarea,"oprt","varchar",clsx,dval,ii,totkey,dsno,dsdata)+'</td>';
		}
		fmdata=fmdata+'<tr>'+itemx+'</tr>\r\n';
		//console.log('<tr>'+itemx+'</tr>\r\n');
	  }
	  tabdemo=tabdemo.replace("{headinner}",headdemo);
	  tabdemo=tabdemo.replace("{bodyinner}",fmdata);
	  return tabdemo;
  }else{
	  return "";
  }
}
function makecomlist(jsondata,listcode,listsrd,listhead,listtr){
  if (jsondata.status>0){
	 keytitlex=new Array();
	 keynamex=new Array();
	 keydxtype=new Array();
	 keyclstxt=new Array();
	 titlex="";
	 namex="";
	 keynmx="";
	 dxtypex="";
	 clstxtx="";
	 listsrdx="";
	 listheadx="";
	 liststrx=liststr;
	 listsrdx=listsrd.replace('{listcode}',listcode);
	 //dataarea=jsondata.dataarea;
	 dataarea="";
	  tabkeys=jsondata.keys;
	  tabkeyx="xxx/"+tabkeys;
	  ptkey=tabkeys.split(",");
	  totkey=ptkey.length;
	  for (kk=0;kk<totkey;kk++){
		  namex=ptkey[kk];
		  keynamex[kk]=namex;
		  for (jj=0;jj<jsondata.ktps.length;jj++){		  
		   eval('keynmx=jsondata.ktps[jj].keyname;');
		   if (keynmx==namex){
			eval('titlex=jsondata.ktps[jj].keytitle;');   
			keytitlex[kk]=titlex;
			eval('dxtypex=jsondata.ktps[jj].dxtype;');   
			keydxtype[kk]=dxtypex;
			eval('clstxtx=jsondata.ktps[jj].clstxt;');   
			keyclstxt[kk]=clstxtx;
		   }
		  }
	  }
	  listheadx=listhead;
	  for (kk=0;kk<totkey;kk++){
		  listheadx=listheadx.replace('{th'+keynamex[kk]+'}',keytitlex[kk]);		  
	  }
	  listsrdx=listsrdx.replace('{listhead}',listheadx);
	  fmdata="";
	  for (ii=0;ii<jsondata.vls.length;ii++){
		itemx=listtrx;
		for (kk=0;kk<totkey;kk++){
			dval="";
			dkey=keynamex[kk];
			dtype=keydxtype[kk];
			clsx=keyclstxt[kk];
			if (tabkeyx.indexOf("SNO")>0){
			  dsno=jsondata.vls[ii].SNO;
			}else{
			  dsno=ii;
			}	
			eval('dval=jsondata.vls[ii].'+keynamex[kk]+';');			
			itemx=itemx.replace('{td'+dkey+'}',extabkey(dataarea,dkey,dtype,clsx,dval,ii,kk,dsno,jsondata));
		}			
		fmdata=fmdata+itemx+'\r\n';
	  }
	  listsrdx=listsrdx.replace('{innerdata}',fmdata);
	  return turnlab(listsrdx);
  }else{
	  return "";
  }
}
function makedslist(dsdata,listcode,listsrd,listhead,listtr){
  if (dsdata.status>0){
	 keytitlex=new Array();
	 keynamex=new Array();
	 keydxtype=new Array();
	 keyclstxt=new Array();
	  datatypes=dsdata.keytps;
      formtitles="";
	  formkeys="";	  
	  dxtypes="";
	  fmcls="";
	  for (j=0;j<dsdata.keytps.length;j++){
		  formtitles=formtitles+dsdata.keytps[j].keytitle+",";
		  formkeys=formkeys+dsdata.keytps[j].keyid+",";
		  dxtypes=dxtypes+dsdata.keytps[j].dxtype+",";
		  fmcls=fmcls+dsdata.keytps[j].clstxt+"/";
	  }
     formtitles=killlasttring(formtitles);
	 formkeys=killlasttring(formkeys);
	 dxtypes=killlasttring(dxtypes);
	 fmcls=killlasttring(fmcls);
	 titlex="";
	 namex="";
	 keynmx="";
	 dxtypex="";
	 clstxtx="";
	 //dataarea=jsondata.dataarea;
	 dataarea="";
      formsrdx=formsrd;
	  ptkey=formkeys.split(",");
	  pttitle=formtitles.split(",");
	  
	  ptdxtp=dxtypes.split(",");
	  ptcls=fmcls.split("/");
	  totkey=ptkey.length;
	  for (kk=0;kk<totkey;kk++){
		  namex=ptkey[kk];
		  keynamex[kk]=namex;
		  keydxtype[kk]=ptdxtp[kk];
		  keytitlex[kk]=pttitle[kk];
          keyclstxt[kk]=ptcls[kk];
	  }
	  listheadx=listhead;
	  for (kk=0;kk<totkey;kk++){
		  listheadx=listheadx.replace('{th'+keynamex[kk]+'}',keytitlex[kk]);		  
	  }
	  listsrdx=listsrdx.replace('{listhead}',listheadx);
	  fmdata="";
	  for (ii=0;ii<jsondata.vls.length;ii++){
		itemx=listtrx;
		for (kk=0;kk<totkey;kk++){
			dval="";
			dkey=keynamex[kk];
			dtype=keydxtype[kk];
			clsx=keyclstxt[kk];
  		    dsno=jsondata.vls[ii].datasno;
			eval('dval=jsondata.vls[ii].'+keynamex[kk]+';');			
			itemx=itemx.replace('{td'+dkey+'}',extabkey(dataarea,dkey,dtype,clsx,dval,ii,kk,dsno,dsdata));
		}			
		fmdata=fmdata+itemx+'\r\n';
	  }
	  listsrdx=listsrdx.replace('{innerdata}',fmdata);
	  return turnlab(listsrdx);
  }else{
	  return "";
  }
}
function makedsform(dsdata,formcode,formsrd){
  if (dsdata.status>0){
      keytitlex=new Array();
	  keynamex=new Array();
	  keydxtype=new Array();
	  keyclstxt=new Array();
      datatypes=dsdata.keytps;
      formtitles="";
	  formkeys="";	  
	  dxtypes="";
	  fmcls="";
	  for (j=0;j<dsdata.keytps.length;j++){
		  formtitles=formtitles+dsdata.keytps[j].keytitle+",";
		  formkeys=formkeys+dsdata.keytps[j].keyid+",";
		  dxtypes=dxtypes+dsdata.keytps[j].dxtype+",";
		  fmcls=fmcls+dsdata.keytps[j].clstxt+"/";
	  }
     formtitles=killlasttring(formtitles);
	 formkeys=killlasttring(formkeys);
	 dxtypes=killlasttring(dxtypes);
	 fmcls=killlasttring(fmcls);
	 titlex="";
	 namex="";
	 keynmx="";
	 dxtypex="";
	 clstxtx="";
	 //dataarea=jsondata.dataarea;
	 dataarea="";
      formsrdx=formsrd;
	  ptkey=formkeys.split(",");
	  pttitle=formtitles.split(",");
	  
	  ptdxtp=dxtypes.split(",");
	  ptcls=fmcls.split("/");
	  totkey=ptkey.length;
	  for (kk=0;kk<totkey;kk++){
		  namex=ptkey[kk];
		  keynamex[kk]=namex;
		  keydxtype[kk]=ptdxtp[kk];
		  keytitlex[kk]=pttitle[kk];
          keyclstxt[kk]=ptcls[kk];
	  }
      formsrdx=formsrdx.replace('{formcode}',formcode);
	  for (kk=0;kk<totkey;kk++){
		  formsrdx=formsrdx.replace('{label'+keynamex[kk]+'}',keytitlex[kk]);
		  	  formsrdx=formsrdx.replace('{label'+keynamex[kk]+'}',keytitlex[kk]);		  
		  	  	  formsrdx=formsrdx.replace('{label'+keynamex[kk]+'}',keytitlex[kk]);		  
	  }
	  for (kk=0;kk<totkey;kk++){
			dval="";
			dkey=keynamex[kk];
			dtype=keydxtype[kk];
			clsx=keyclstxt[kk];
			
			dsno=_get("SNO")*1;
			if (dsdata.vls.length>0){
			 eval('dval=dsdata.vls[0].'+keynamex[kk]+';');			
			 formsrdx=formsrdx.replace('{data'+dkey+'}',exformkey(dataarea,dkey,dtype,clsx,dftval(dval,''),dsno,dsdata));
			}else{
			  formsrdx=formsrdx.replace('{data'+dkey+'}',exformkey(dataarea,dkey,dtype,clsx,"",dsno,dsdata));
			}
	  }			
	  return turnlab(formsrdx);
  }else{
	  return "";
  }
}

function makecomform(jsondata,formcode,formsrd){
  if (jsondata.status>0){
      datatypes=jsondata.datatypes;
      formtitles=jsondata.detailtitles;
	  formkeys=jsondata.detailkeys;
	  formkeyx="xxx/"+formkeys; 
	  dxtypes=jsondata.dxtypes;
	 keytitlex=new Array();
	 keynamex=new Array();
	 keydxtype=new Array();
	 keyclstxt=new Array();
	 titlex="";
	 namex="";
	 keynmx="";
	 dxtypex="";
	 clstxtx="";
	 //dataarea=jsondata.dataarea;
	 dataarea="";
      formsrdx=formsrd;
	  ptkey=formkeys.split(",");
	  pttitle=formtitles.split(",");
	  
	  ptdxtp=dxtypes.split(",");
	  totkey=ptkey.length;
	  for (kk=0;kk<totkey;kk++){
		  namex=ptkey[kk];
		  keynamex[kk]=namex;
		  keydxtype[kk]=ptdxtp[kk];
		  keytitlex[kk]=pttitle[kk];
		  if (keydxtype[kk]=="select" || keydxtype[kk]=="multiselect" ){
		    keyclstxt[kk]="";
		    eval('keyclstxt[kk]=jsondata.'+namex+'CLSTXT;');
		  }
	  }
      formsrdx=formsrdx.replace('{formcode}',formcode);
	  for (kk=0;kk<totkey;kk++){
		  formsrdx=formsrdx.replace('{label'+keynamex[kk]+'}',keytitlex[kk]);		  
	  }
	  for (kk=0;kk<totkey;kk++){
			dval="";
			dkey=keynamex[kk];
			dtype=keydxtype[kk];
			clsx=keyclstxt[kk];
			if (formkeyx.indexOf("SNO")>0){
			  dsno=jsondata.SNO;
			}else{
			  dsno=-1;
			}	
			eval('dval=jsondata.'+keynamex[kk]+';');			
			formsrdx=formsrdx.replace('{data'+dkey+'}',exformkey(dataarea,dkey,dtype,clsx,dftval(dval,''),dsno,jsondata));
	  }			
	  return turnlab(formsrdx);
  }else{
	  return "";
  }
}
function formformhtml(jsondata,formsrd,formitem){
    if (jsondata.status>0){
      formsrdx=formsrd;
      formitemx=formitem;
      datatypes=jsondata.datatypes;
      formtitles=jsondata.detailtitles;
	  formkeys=jsondata.detailkeys;
	  formkeyx="xxx/"+formkeys;     
	  dxtypes=jsondata.dxtypes;
 	  keytitlex=new Array();
	  keynamex=new Array();
	  keydxtype=new Array();
	  keyclstxt=new Array();
	  titlex="";
	  namex="";
	  keynmx="";
	  dxtypex="";
	  clstxtx="";
	 //dataarea=jsondata.dataarea;
	  dataarea="";
      formsrdx=formsrd;
	  ptkey=formkeys.split(",");
	  pttitle=formtitles.split(",");
	  pttp=datatypes.split(",");
	  ptdxtp=dxtypes.split(",");
	  totkey=ptkey.length;
	  fmtr="";
	  for (kk=0;kk<totkey;kk++){
		  namex=ptkey[kk];
		  keynamex[kk]=namex;
		  keydxtype[kk]=ptdxtp[kk];
		  keytitlex[kk]=pttitle[kk];
		  if (keydxtype[kk]=="select" || keydxtype[kk]=="multiselect" ){
		    keyclstxt[kk]="";
		    eval('keyclstxt[kk]=jsondata.'+namex+'CLSTXT;');
		  }
		  itemy=formitemx;
		  itemy=itemy.replace('{labeltitle}',keytitlex[kk]);
		  itemy=itemy.replace('{dataitem}','{data'+namex+'}');
		  itemy=itemy.replace('{datakey}','p_'+namex);
		  fmtr=fmtr+""+itemy+"\r\n";
	  }
	  demo=formsrdx.replace("{forminner}",fmtr);
	  return demo;
     }else{
         return "";
     }
    
}
function dsformhtml(dsdata,formsrd,formitem){
    if (dsdata.status>0){
	 keytitlex=new Array();
	 keynamex=new Array();
	 keydxtype=new Array();
	 keyclstxt=new Array();
       datatypes=dsdata.keytps;
      formtitles="";
	  formkeys="";	  
	  dxtypes="";
	  fmcls="";
	  for (j=0;j<dsdata.keytps.length;j++){
		  formtitles=formtitles+dsdata.keytps[j].keytitle+",";
		  formkeys=formkeys+dsdata.keytps[j].keyid+",";
		  dxtypes=dxtypes+dsdata.keytps[j].dxtype+",";
		  fmcls=fmcls+dsdata.keytps[j].clstxt+"/";
	  }
     formtitles=killlasttring(formtitles);
	 formkeys=killlasttring(formkeys);
	 dxtypes=killlasttring(dxtypes);
	 fmcls=killlasttring(fmcls);
	 titlex="";
	 namex="";
	 keynmx="";
	 dxtypex="";
	 clstxtx="";
	 //dataarea=jsondata.dataarea;
	 dataarea="";
      formsrdx=formsrd;
	  ptkey=formkeys.split(",");
	  pttitle=formtitles.split(",");
	  ptdxtp=dxtypes.split(",");
	  ptcls=fmcls.split("/");
	  totkey=ptkey.length;
	  fmtr="";
	  formitemx=formitem;
	  for (kk=0;kk<totkey;kk++){
		  namex=ptkey[kk];
		  keynamex[kk]=namex;
		  keydxtype[kk]=ptdxtp[kk];
		  keytitlex[kk]=pttitle[kk];
          keyclstxt[kk]=ptcls[kk];	  
		  itemy=formitemx;
		  itemy=itemy.replace('{labeltitle}',keytitlex[kk]);
		  itemy=itemy.replace('{labeltitle}',keytitlex[kk]);
		  itemy=itemy.replace('{labeltitle}',keytitlex[kk]);
		  itemy=itemy.replace('{dataitem}','{data'+namex+'}');
		  itemy=itemy.replace('{dataitem}','{data'+namex+'}');
		  itemy=itemy.replace('{dataitem}','{data'+namex+'}');
		  itemy=itemy.replace('{datakey}','p_'+namex);
		  itemy=itemy.replace('{datakey}','p_'+namex);
		  itemy=itemy.replace('{datakey}','p_'+namex);
		  fmtr=fmtr+""+itemy+"\r\n";
	  }
	  demo=formsrdx.replace("{forminner}",fmtr);
	  return demo;
     }else{
         return "";
     }
    
}
function extabkeyx(dax,dkeyx,dtypex,ctxtx,dvalx,iii,kkk,snox,jsondatax){
	 switch(dkeyx){
		 case "SNO":
		  return dvalx;
		 break;
		 case "OPRT":
		 break;
		 default:
		 switch(dtypex){
			 case "varchar1024":
			 return dvalx;
			 break;
			 case "datetime":
			 return dvalx;
			 break;
			 default:
			 return dvalx;
		 }
	 }
}
function exformkeyx(dax,dkeyx,dtypex,ctxtx,dvalx,snox,jsondatax){
	 switch(dkeyx){
		 case "SNO":
		  return dvalx;
		 break;
		 case "OPRT":
		 break;
		 default:
		 switch(dtypex){
			 case "varchar1024":
			 return dvalx;
			 break;
			 case "datetime":
			 return dvalx;
			 break;
			 default:
		      return dvalx;	 
		 }
	 }
}