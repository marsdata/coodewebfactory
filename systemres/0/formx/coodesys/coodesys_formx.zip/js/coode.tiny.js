$_GET=new Array();
$_COOKIE=new Array();
$_POST=new Array();
$_COOKIE["gid"]="";
$_COOKIE["uid"]="";
$_COOKIE["cid"]="";
sessionStorage.locallist=0;
sessionStorage.allct=0;
sessionStorage.renderstart=0;
function base64Encode(input){
    var rv;
    rv = encodeURIComponent(input);
    rv = unescape(rv);
    rv = window.btoa(rv);
    return rv;
}
function base64Decode(input){
    rv = window.atob(input);
    rv = escape(rv);
    rv = decodeURIComponent(rv);
    return rv;
}
function GetRequest(){
  var url = location.search; //获取url中"?"符后的字串
  var theRequest = new Object();
  if (url.indexOf("?") != -1) {
 var str = url.substr(1);
 strs = str.split("&");
 for(var i = 0; i < strs.length; i ++) {
   theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
 }
  }
  return theRequest;
}

function GetUrlParam(paraName) {
  var url = document.location.toString();
  var arrObj = url.split("?");
  if (arrObj.length > 1) {
  var arrPara = arrObj[1].split("&");
  var arr;
  for (var i = 0; i < arrPara.length; i++) {
  arr = arrPara[i].split("=");

  if (arr != null && arr[0] == paraName) {
    return arr[1];
  }
  }
  return "";
  }
  else {
  return "";
  }
  }
function randomWord(randomFlag, min, max){
 var str = "",
  range = min,
  arr = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
 
 // 随机产生
 if(randomFlag){
  range = Math.round(Math.random() * (max-min)) + min;
 }
 for(var i=0; i<range; i++){
  pos = Math.round(Math.random() * (arr.length-1));
  str += arr[pos];
 }
 return str;
}
function rnd01(){
    tmpxn=Math.random();
    if (tmpxn<0.5){
        return 0;
    }else{
        return 1;
    }
}
/**
 * base64编码
 * @param {Object} str
 */

function gl(){
 return "localhost";   //本系统mysql 数据库IP 
}
function glu(){
 return "";   //本系统mysql 数据库IP 
}
function glc(){
 return "";   //本系统mysql 数据库IP 
}
function getuid(){
 if (localStorage.uid!=undefined && localStorage.uid!=""){
  return localStorage.uid;   //本系统mysql 数据库用户名  
 }else{
  domn=GetRequest().domn;
  stk=GetRequest().stk;
  if (domn==undefined || stk==undefined){
   return ajaxhtmlpost("/localxres/funx/getuid","");
  }else{
    domn=base64Decode(domn);
    bkdt=fundatap(domn,stk,"getuid","","",mtd);
    return bkdt.uid;
  }
 }
}
function glp(){
 return localStorage.pwd;  //本系统mysql 数据库密码  
}
function getcid(){
 if (localStorage.cid!=undefined && localStorage.cid!=""){
  return localStorage.cid;   //本系统mysql 数据库用户名  
 }else{
  domn=GetRequest().domn;
  stk=GetRequest().stk;
  if (domn==undefined || stk==undefined){
   return ajaxhtmlpost("/localxres/funx/getcid","");
  }else{
    domn=base64Decode(domn);
    bkdt=fundatap(domn,stk,"getcid","","",mtd);
    return bkdt.cid;
  }
 }
}

function glw(){
 return document.domain+"/";   //本服务器域名  结尾要加/ 如果没有域名请用本机分配的固定IP,结尾也要加/
}

function glw(){
 return document.domain;   //本服务器域名 
}
function glb(){
 return "blueprints";   //本系统mysql 数据库  
}
function  dfp(){
 return "/localxres/iconsetx/pagecontrol/coode.jpg";
}
function  gln(){
 return localStorage.gln;
}
function makeguid(){
     return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
     var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
     return v.toString(16);
  });
}
function hmcode(){
 $ax="abcdefghjkmnpqrstuvwxy";
 $bx="236789";
 $rtnxx=substr($ax,(Math.random()*(strlen($ax)-1)),1);
 $rtnxx=$rtnxx+substr($ax,(Math.random()*(strlen($ax)-1)),1);
 $rtnxx=$rtnxx+substr($bx,(Math.random()*(strlen($bx)-1)),1);
 $rtnxx=$rtnxx+substr($bx,(Math.random()*(strlen($bx)-1)),1);
 $rtnxx=$rtnxx+substr($bx,(Math.random()*(strlen($bx)-1)),1);
 return $rtnxx;
}
function savedata(kx,vx){
  if (typeof(Storage) !== "undefined") {  
 localStorage.setItem(kx,vx);
 return true; 
   } else {
 return false;
  }
}
function usedata(kx){
  if (typeof(Storage) !== "undefined") {  
  return  localStorage.getItem(kx); 
   } else {
 return "";
  }
}
function isMobile (mobile) {  
  return /^1[3-9]\d{9}$/.test(mobile)
}
function multirun(mtd,qrystr,tmx){
    window.open("/localxres/pagex/0/funcore/4dq5sLWX/hxSKGu/index.html?method="+mtd+"&"+qrystr+"&scd="+tmx+"&rnd="+onlymark());
}
function vxlogin(utel,tinyid){
    if (isMobile(utel) && tinyid!=""){
      location.href="/localxres/funx/worchatlogin/?mobile="+utel+"&loginarea="+tinyid;
    }else{
      alert("参数不正确，无法用微信登录");
    }
}
function getmyip(){
$.ajax({
        type:"GET",
        url:"http://kitty.halo123.cn/localxres/funx/getthisip/",
        dataType:"jsonp",
        jsonp:"cb",
        jsonpCallback:"cbx",
        success:function(data){
            sessionStorage.thisip=data.ip;
            console.log(data.ip);
        }
    });
}
function makepagesession(){
    guidx=makeguid();
    sessionStorage.pagess=guidx;
    return guidx;
}
function getpagesession(){
    return sessionStorage.pagess;
}
function lcexecsql(dbnm,sqlstr){
//dbnm="Test DB";
var db = openDatabase('mydb', '1.0', dbnm, 2 * 1024 * 1024);
   db.transaction(function (tx) {
   tx.executeSql(sqlstr);
   return true;
 });
}
function lcsx(dbnm,sqlstr,fx){
//dbnm="Test DB";
var db = openDatabase('mydb', '1.0', dbnm, 2 * 1024 * 1024);
  db.transaction(function (tx) {
   skeys=qian(hou(sqlstr,"elect"),"from");
   skeys=qian(hou(skeys,"ELECT"),"FROM");
   skeys=skeys.replace(/ /g,"");
   ptkey=skeys.split(",");
   totkey=ptkey.length;
   fmkeyx="";
   for (j=0;j<totkey;j++){
       fmkeyx=fmkeyx+ptkey[j]+"#-#"
   }
   fmkeyx=killlasttring(fmkeyx);
   fmkeyx=killlasttring(fmkeyx);
   fmkeyx=killlasttring(fmkeyx);
   fmkeyx=fmkeyx+"#/#"
  tx.executeSql(sqlstr, [], function (tx, results) {
      var len = results.rows.length, i;
      for (i = 0; i < len; i++){
          for (j=0;j<totkey;j++){
              if (ptkey[j]!=""){
               tmpval="";
               eval("tmpval=results.rows.item(i)."+ptkey[j]+";");
               fmkeyx=fmkeyx+tmpval+"#-#";
              }
          };
        fmkeyx=killlasttring(fmkeyx);
        fmkeyx=killlasttring(fmkeyx);
        fmkeyx=killlasttring(fmkeyx);
        fmkeyx=fmkeyx+"#/#"
      };
      return fx(fmkeyx);
   }, null);
 });
}
function lcux(dbnm,sqlstr,fx){
//dbnm="Test DB";
var db = openDatabase('mydb', '1.0', dbnm, 2 * 1024 * 1024);
   db.transaction(function (tx) {
    tx.executeSql(sqlstr, [], function (tx, results) {
      return fx(results.rows.item(0).result);
   }, null);
 });
}
function  adminindex(){
 return localStorage.adminindex;
}
function  visitorindex(){
 return localStorage.visitorindex;
}
function  indexpage(){
 return localStorage.indexpage;
}
function  visitorlogin(){
 return localStorage.visitorlogin;
}
function  relogin(){
 return localStorage.relogin;
}
function  adminlogin(){
 return localStorage.adminlogin;
}
function ceil(numx){
  return Math.ceil(numx);
}
function myfirstpos(){
  return qian(_cookie("posids"),",");
}
function getip(){
  if (sessionStorage.thisip!=undefined){
     return sessionStorage.thisip;
  }else{
      return "127.0.0.1";
  }
}
function _cookie(name){
  var strcookie = document.cookie;//获取cookie字符串
  var arrcookie = strcookie.split("; ");//分割
  //遍历匹配
  for ( var i = 0; i < arrcookie.length; i++) {
  var arr = arrcookie[i].split("=");
  if (arr[0] == name){
    return arr[1];
  }
  }
}
function dttmtounix(dttm){
   a = (dttm).replace(/-/g,"/");
   dt = new Date(a);
   n = dt.valueOf() / 1000;
   return n;
}
function newgrpcid(){
  return _cookie("grpcid")+randomWord(false,2);
}
function _post(gcx){
  return "";
}
function strlen(strx){
 try{
  return strx.length;
 }
 catch(err){
  return 9999;
 }
}
function tohex(strx){
  return a2hex(strx);
}
function getRandChar(n){
  return randomWord(false,n);
}
function valtostr(valxx){
 ptvalx=valxx.split("#-#");
 totpx=ptvalx.length;
 fmxxx="";
 for (m=0;m<totpx;m++){
     fmxxx=fmxxx+"\'"+ptvalx[m]+"\',";
 }
 fmxxx=killlasttring(fmxxx);
 return fmxxx;
}
function makeupdtstr(keyxx,valxx,expk){
 if (expk==""){
     expk="hellowocao";
 };
 empty=0;
 ptkeyx=keyxx.split("#-#");
 ptvalx=valxx.split("#-#");
 totpx=ptvalx.length;
 totpk=ptkeyx.length;
 if (totpx==totpk){
   fmxxx="";
   for (m=0;m<totpx;m++){
     if (expk!=ptkeyx[m]){
       fmxxx=fmxxx+ptkeyx[m]+"=\'"+ptvalx[m]+"\',";
     };
     if (ptkeyx[m]==""){
         empty=empty+1;
     };
   };
   if (empty==0){
     fmxxx=killlasttring(fmxxx);
   }else{
    fmxxx="";    
   };
   return fmxxx;
 }else{
     return "";
 }
}
Date.prototype.format =function(format)
{
  var o = {
"y+" : this.getYear(),
"M+" : this.getMonth()+1, //month
"d+" : this.getDate(), //day
"h+" : this.getHours(), //hour
"m+" : this.getMinutes(), //minute
"s+" : this.getSeconds(), //second
"q+" : Math.floor((this.getMonth()+3)/3), //quarter
"S" : this.getMilliseconds() //millisecond
}
if(/(y+)/.test(format)) format=format.replace(RegExp.$1,(this.getFullYear()+"").substr(4- RegExp.$1.length));
  for(var k in o)if(new RegExp("("+ k +")").test(format))
  format = format.replace(RegExp.$1,RegExp.$1.length==1? o[k] :("00"+ o[k]).substr((""+ o[k]).length));
   return format;
}
function makevmark(cnum){
    
    ty="";
    for (i=0;i<cnum;i++){
        tx=Math.ceil(Math.random()*10)-1;
        ty=ty+substr("AEHKNRSXY3",tx,1);
    }
    return ty;
}
function makeviewurl(urlx){
    ///localxres/funx/anytiny/@@@tiny$owaXMv&rnd=adsf
    newurlx=urlx.replace(/\?/g,"@@@");
    newurlx=newurlx.replace(/\&/g,"*");
    newurlx=newurlx.replace(/\=/g,"$");
    return newurlx;
}
function unviewurl(urly){
    ///localxres/funx/anytiny/@@@tiny$owaXMv&rnd=adsf
    newurly=urly.replace(/@@@/g,"\?");
    newurly=newurly.replace(/\*/g,"\&");
    newurly=newurly.replace(/\$/g,"\=");
    return newurly;
}
function date(fmt){
  timex="";  
  dt=new Date();
 switch (fmt){  
  case "Y-m-d":
  timex = dt.format("yyyy-MM-dd");  
 break;
  case "Y":
  timex = dt.format("yyyy");  
 break;
  case "m":
  timex = dt.format("MM");  
 break;
   case "d":
  timex = dt.format("dd");  
 break;
 case "Y-m-d H:i:s":
 timex = dt.format("yyyy-MM-dd hh:mm:ss");  
 break;
 case "H":
  timex = dt.format("hh");  
 break;
 case "i":
  timex = dt.format("mm");  
 break;
 case "s":
  timex = dt.format("ss");  
 break;
 default:
   timex = dt.format("yyyy-MM-dd");   
   }
  return timex;
}
function dateval(timeDate){
  a=new Date(timeDate).getTime();
  return a;
}
function strtodate(timeDate){
var datex = new Date(dateval(timeDate));
return datex;
}
function datefmtval(timeDate,fmt){
  timex="";  
  dt=strtodate(timeDate);
 switch (fmt){  
  case "Y-m-d":
  timex = dt.format("yyyy-MM-dd");  
 break;
  case "Y":
  timex = dt.format("yyyy");  
 break;
  case "m":
  
  timex = dt.format("MM");  
 break;
   case "d":
  timex = dt.format("dd");  
 break;
 case "Y-m-d H:i:s":
 timex = dt.format("yyyy-MM-dd hh:mm:ss");  
 break;
 case "H":
  timex = dt.format("hh");  
 break;
 case "i":
  timex = dt.format("mm");  
 break;
 case "s":
  timex = dt.format("ss");  
 break;
 default:
   timex = dt.format("yyyy-MM-dd");   
   }
  return timex;
}
function absorbface(scode){
    fmface="";
    if (scode!=""){
        ptcode=scode.split("/FACE/");
        tots=ptcode.length;
        for (i=1;i<tots;i++){
            if (ptcode[i]!=""){
              tempface=qian(ptcode[i],"/");
             if (tempface!="" && tempface.length<15 && tempface.indexOf(" ")<=-1){
                fmface=fmface+tempface+",";
             }
            }
        }
    }
    return fmface;
}
function absorbmyface(scode){
    fmface="";
    if (scode!=""){
        ptcode=scode.split("/MYFACE/");
        tots=ptcode.length;
        for (i=1;i<tots;i++){
            if (ptcode[i]!=""){
              tempface=qian(ptcode[i],"/");
             if (tempface!="" && tempface.length<15 && tempface.indexOf(" ")<=-1){
                fmface=fmface+tempface+",";
             }
            }
        }
    }
    return fmface;
}
function flashback(strx){
    stry="";
    for (i=0;i<strx.length;i++){
        stry=stry+substr(strx,strx.length-i-1,1);
    }
    return stry;
} 
function makepass(uid,pass){
 return mdf32(uid+pass+flashback(pass)+flashback(uid));
}
function atv(strx){
  //return ajaxhtmlpost("/localxres/funx/atv","strx="+mkstr(strx));
  return  "";
}
function utv(ustr){
  //return ajaxhtmlpost("/localxres/funx/utv","strx="+mkstr(strx));
  return "";
}
function onlymark(){
  return makeguid();
}
function syh(){
 return "\"";
}
function dyh(){
 return "\'";
}
function mysql_connect(glx,glux,glpx){
  return "gl="+glx+"&uid="+glux+"&pwd="+glpx;
}
function updatings(cnx,dbs,sqlstr,lanx){
  return ajaxhtmlpost("/localxres/funx/updatings&"+cnx+"&lan="+lanx,"sql="+mkstr(sqlstr));
}
function updatingx(cnx,dbs,sqlstr,lanx){
   return ajaxhtmlpost("/localxres/funx/updatingx&"+cnx+"&lan="+lanx,"sql="+mkstr(sqlstr));
}
function selectedx(cnx,dbs,sqlstr,lanx,tpx){
   return ajaxhtmlpost("/localxres/funx/selectedx&"+cnx+"&lan="+lanx+"&type="+tpx,"sql="+mkstr(sqlstr));
}
function selecteds(cnx,dbs,sqlstr,lanx,tpx){
   return ajaxhtmlpost("/localxres/funx/selecteds&"+cnx+"&lan="+lanx+"&type="+tpx,"sql="+mkstr(sqlstr));
}
function IIF(pdcdt,tval,fval){
    if (pdcdt){
        return tval;
    }else{
        return fval;
    }
    
}
function mdf32(str){
 return str.MD5(32);
}
function mdf16(str){
 return str.MD5();
}
function enpass(pass,mtd){
 try{
  rtn="";
  eval("rtn="+mtd+"(pass);")
 if (rtn!=undefined){
  return rtn;
 }else{
  return pass;   
 }
 }
 catch(err){
  return pass;
 }
}
function explode(bstr,longstr){
  return longstr.split(bstr);
}

function countx(ptx){
  return ptx.length;
}
function qudouhao(strx){
 if (strx!=undefined){
  return strx.toString().replace(/,/g,"");
 }else{
  return  "";
 }
}
function qufenhao(strx){
 if (strx!=undefined){
  return strx.toString().replace(/;/g,"");
 }else{
  return "";
 }
}
function qukongge(strx){
 if (strx!=undefined){
  return strx.toString().replace(/ /g,"");
 }else{
  return "";
 }
}
function fenzhuandou(strx){
 if (strx!=undefined){
  return strx.toString().replace(/;/g,",");
 }else{
  return "";
 }
}
function quxiegang(strx){
 if (strx!=undefined){
  return strx.toString().replace(/\\\'/g,"\'")
 }else{
  return "";
 }
}
function notempty(strx){
    if (strx!=undefined && strx!="." && strx!=""){
        return true;
    }else{
        return false;
    }
}
function dftval(valx,valy){
    if (notempty(valx)){
        return valx;
    }else{
        return valy;
    }
}
function kuozhanming($fileurl){
    if (strpos($fileurl,".")>0){
     $ptpt=explode(".",$fileurl);
     $totptpt=countx($ptpt);
     $kzm=$ptpt[$totptpt-1];
      return qian($kzm,"?");
    }else{
        return "";
    }
}
function makecdturl(cdtx){
cdtx=cdtx.replace(/ /g,"[spc]")
cdtx=cdtx.replace(/=/g,"[eq]")
cdtx=cdtx.replace(/\>/g,"[gt]")
cdtx=cdtx.replace(/\</g,"[lt]")
cdtx=cdtx.replace(/\'/g,"[dyh]")
return cdtx;
}
function thisrowkey(kmark){
    preval="";
    eval("preval=sessionStorage.p"+kmark+";");
    return dftval($("#p_"+kmark).val(),preval);
}
function makeurlqry(){
    qrykey="";
    preurl=decodeURIComponent(location.href);
    houhref=qian(hou(prehref,"?"),"#");
    fmxyz="";
    if (houhref.indexOf("&")>0){
     pthref=houhref.split("&");
     totp=pthref.length;
     for (i=0;i<totp;i++){
         qqq=qian(pthref[i],"=");
         hhh=hou(pthref[i],"=");
         switch(qqq){
             case "stid":
             break;
             case "layid":
             break;
             case "tinyid":
             break;
             case "laydb":
             break;
             case "accid":
             break;
             case "refresh":
             break;
             case "rndom":
             break;
             case "dbnm":
             break;
             default:
             fmxyz=fmxyz+qqq+"="+hhh+"&";
             qrykey=qrykey+qqq+",";
         }
     }
    }else{
         qqq=qian(houhref,"=");
         hhh=hou(houhref,"=");
         switch(qqq){
             case "stid":
             break;
             case "layid":
             break;
             case "tinyid":
             break;
             case "laydb":
             break;
             case "accid":
             break;
             case "refresh":
             break;
             case "rndom":
             break;
             default:
             fmxyz=fmxyz+qqq+"="+hhh;
             qrykey=qrykey+qqq+",";
         }
    }
    if (fmxyz!=""){
        return "&"+fmxyz+"&qrykey="+qrykey;
    }else{
        return "";
    }
}

function vfmblfrmlogin(sysid){
 a=myuinfo();
 if (a.userid==""){
  localStorage.fromurl=location.href;
  location.href="/localxres/pagex/goodmachinecode/gmcleader/c7whNGTa/f35hXF/index.html?sysid="+sysid;
 }
 return true;
}
function vfpcfrmlogin(sysid){
 a=myuinfo();
 if (a.userid==""){
  localStorage.fromurl=location.href;
  location.href="/localxres/pagex/goodmachinecode/gmcleader/c7whNGTa/oj3Po4/index.html?sysid="+sysid;
 }
 return true;
}
function viewitem(sno){
 stid=GetRequest().stid;
 sid=qian(stid,"-");
   if (typeof(stid)=="un"+"defined" || stid==""){
    if (strpos(prehref,"/shortid")>0){
     sid=hou(qian(prehref,"/shortid/"),"/");
    }
   }
   x=update(sid,sno);
}
function seticonpage(tbnm,tbkey,tbsno){
    window.open("/localxres/pagex/0/tabcore/safruuc2/C4CSF1/index.html?tbnm="+tbnm+"&tbkey="+tbkey+"&tbsno="+tbsno+"&rnd="+onlymark());
}
function setimgpage(tbnm,tbkey,tbsno){
    window.open("/localxres/pagex/0/tabcore/safruuc2/C4CSF1/index.html?tbnm="+tbnm+"&tbkey="+tbkey+"&tbsno="+tbsno+"&rnd="+onlymark());
}
function setfilepage(tbnm,tbkey,tbsno){
    window.open("/localxres/pagex/0/tabcore/safruuc2/C4CSF1/index.html?tbnm="+tbnm+"&tbkey="+tbkey+"&tbsno="+tbsno+"&rnd="+onlymark());
}
function openlist(){
 stid=GetRequest().stid;
 sid=qian(stid,"-");
   if (typeof(stid)=="un"+"defined" || stid==""){
    if (strpos(prehref,"/shortid")>0){
     sid=hou(qian(prehref,"/shortid/"),"/");
    }
   }
   window.open("/localxres/funx/anyjsshort/?stid="+sid+"-pnum:30-&refresh=2&rnd="+getRandChar(8));
}
function gotiny(tinyid,V){
  domn=GetRequest().domn;
  stk=GetRequest().stk;
  if (domn==undefined || stk==undefined){
    location.href='/localxres/funx/anytiny/?tiny='+tinyid+"&refresh="+v;
  }else{
    domn=base64Decode(domn);
    location.href=domn+'/localxres/funx/anytiny/?tiny='+tinyid+"&refresh="+v+"&stk="+stk;
  }
}
function golay(layid){
  domn=GetRequest().domn;
  stk=GetRequest().stk;
  if (domn==undefined || stk==undefined){
    location.href='/localxres/funx/anylay/?layid='+layid+"&refresh="+v;  
  }else{
    domn=base64Decode(domn);
    location.href=domn+'/localxres/funx/anylay/?layid='+layid+"&refresh="+v+"&stk="+stk;  
  }
}
function opentiny(tinyid,v){
  domn=GetRequest().domn;
  stk=GetRequest().stk;
  if (domn==undefined || stk==undefined){
    window.open('/localxres/funx/anytiny/?tiny='+tinyid+"&refresh="+v);
  }else{
    domn=base64Decode(domn);
    window.open(domn+'/localxres/funx/anytiny/?tiny='+tinyid+"&refresh="+v+"&stk="+stk);
  }
}
function openlay(layid,v){
  domn=GetRequest().domn;
  stk=GetRequest().stk;
  if (domn==undefined || stk==undefined){
    window.open('/localxres/funx/anylay/?layid='+layid+"&refresh="+v);
  }else{
    domn=base64Decode(domn);
    window.open(domn+'/localxres/funx/anylay/?layid='+layid+"&refresh="+v+"&stk="+stk);
  }
}
function tinyurl(tinyid,v){
  domn=GetRequest().domn;
  stk=GetRequest().stk;
  if (domn==undefined || stk==undefined){
    return '/localxres/funx/anytiny/?tiny='+tinyid+"&refresh="+v;  
  }else{
    domn=base64Decode(domn);
    return domn+'/localxres/funx/anytiny/?tiny='+tinyid+"&refresh="+v+"&stk="+stk;
  }
}
function makeqrcode(eid,url,w,h){
    var qrcode = new QRCode(document.getElementById(eid), {
          width : w,//设置宽高
          height : h
          });
     qrcode.makeCode(url);
}
function makeclstxtbykst(kstid,arrdata,presno){
    kstidx=kstid.replace("[","");
    kstidx=kstidx.replace("]","");
    stidx=qian(kstidx,"@");
    qrykey=hou(kstidx,"@");
    qrykey=qrykey.replace(".",",");
    eval('stdtjson='+stidx+'Data;')
    fmtxta="";
    fmtxtb="";
    amd5="";
    if (qrykey.indexOf(",")>0){
    //    console.log("qrykey-"+qrykey);
      ptkey=qrykey.split(",");
      totpt=ptkey.length;
      //console.log(ptkey);
      switch(totpt){
          case 2:
          q1=ptkey[0];
          q1a=qian(q1,"=");
          q1b=hou(q1,"=");
          v1=arrdata[q1a][presno];
          q2=ptkey[1];
          q2a=qian(q2,"=");
          q2b=hou(q2,"=");
          v2=arrdata[q2a][presno];

          amd5="a"+mdf16(stidx+"@"+v1+","+v2);
          tmpstock="";
          eval('tmpstock=dftval(sessionStorage.'+amd5+',"");');
          if (tmpstock==""){
           for (p=0;p<stdtjson.vls.length;p++){
             vv1="";
             vv2="";
             tt="";
             kk="";
             eval('vv1=stdtjson.vls[p].'+q1b+';');
             eval('vv2=stdtjson.vls[p].'+q2b+';');
             if (v1==vv1 && v2==vv2){
                tt=stdtjson.vls[p].ktitle;
                kk=stdtjson.vls[p].kval;
                fmtxta=fmtxta+tt+",";
                fmtxtb=fmtxtb+kk+",";
             }
           }
           fmtxta=killlasttring(fmtxta);
           fmtxtb=killlasttring(fmtxtb);
           eval('sessionStorage.'+amd5+'="'+fmtxta+"|"+fmtxtb+'";');
           return fmtxta+"|"+fmtxtb;
          }else{
            return tmpstock;
          }
          break;
          case 3:
          q1=ptkey[0];
          q1a=qian(q1,"=");
          q1b=hou(q1,"=");
          v1=arrdata[q1a][presno];
          q2=ptkey[1];
          q2a=qian(q2,"=");
          q2b=hou(q2,"=");
          v2=arrdata[q2a][presno];
          q3=ptkey[2];
          q3a=qian(q3,"=");
          q3b=hou(q3,"=");
          v3=arrdata[q3a][presno];
          amd5="a"+mdf16(stidx+"@"+v1+","+v2+","+v3);
          tmpstock="";
          eval('tmpstock=dftval(sessionStorage.'+amd5+',"");');
          if (tmpstock==""){
           for (p=0;p<stdtjson.vls.length;p++){
            vv1="";
            vv2="";
            vv3="";
            tt="";
            kk="";
            eval('vv1=stdtjson.vls[p].'+q1b+';');
            eval('vv2=stdtjson.vls[p].'+q2b+';');
            eval('vv3=stdtjson.vls[p].'+q3b+';');
            if (v1==vv1 && v2==vv2 && v3==vv3){
                tt=stdtjson.vls[p].ktitle;
                kk=stdtjson.vls[p].kval;
                fmtxta=fmtxta+tt+",";
                fmtxtb=fmtxtb+kk+",";
            }
           }
           fmtxta=killlasttring(fmtxta);
           fmtxtb=killlasttring(fmtxtb);
           eval('sessionStorage.'+amd5+'="'+fmtxta+"|"+fmtxtb+'";');
           return fmtxta+"|"+fmtxtb;
          }else{
           return tmpstock;
          }
          break;
          case 4:
          q1=ptkey[0];
          q1a=qian(q1,"=");
          q1b=hou(q1,"=");
          v1=arrdata[q1a][presno];
          q2=ptkey[1];
          q2a=qian(q2,"=");
          q2b=hou(q2,"=");
          v2=arrdata[q2a][presno];
          q3=ptkey[2];
          q3a=qian(q3,"=");
          q3b=hou(q3,"=");
          v3=arrdata[q3a][presno];
          q4=ptkey[3];
          q4a=qian(q4,"=");
          q4b=hou(q4,"=");
          v4=arrdata[q4a][presno];
          amd5="a"+mdf16(stidx+"@"+v1+","+v2+","+v3+","+v4);
          tmpstock="";
          eval('tmpstock=dftval(sessionStorage.'+amd5+',"");');
          if (tmpstock==""){
           for (p=0;p<stdtjson.vls.length;p++){
            vv1="";
            vv2="";
            vv3="";
            vv4="";
            tt="";
            kk="";
            eval('vv1=stdtjson.vls[p].'+q1b+';');
            eval('vv2=stdtjson.vls[p].'+q2b+';');
            eval('vv3=stdtjson.vls[p].'+q3b+';');
            eval('vv4=stdtjson.vls[p].'+q4b+';');
            if (v1==vv1 && v2==vv2 && v3==vv3 && v4==vv4){
                tt=stdtjson.vls[p].ktitle;
                kk=stdtjson.vls[p].kval;
                fmtxta=fmtxta+tt+",";
                fmtxtb=fmtxtb+kk+",";
            }
           }
           fmtxta=killlasttring(fmtxta);
           fmtxtb=killlasttring(fmtxtb);
           eval('sessionStorage.'+amd5+'="'+fmtxta+"|"+fmtxtb+'";');
           return fmtxta+"|"+fmtxtb;
          }else{
             return tmpstock;
          }
          break;
          default:
      }
    }else{
         q1=qrykey;
         qa=qian(q1,"=");
         qb=hou(q1,"=");
         v1=arrdata[qa][presno];
         amd5="a"+mdf16(stidx+"@"+v1);
         tmpstock="";
         eval('tmpstock=dftval(sessionStorage.'+amd5+',"");');
         if (tmpstock==""){
           for (p=0;p<stdtjson.vls.length;p++){
            vv="";
            tt="";
            kk="";
            eval('vv=stdtjson.vls[p].'+qb+';');
            if (vv==v1){
                tt=stdtjson.vls[p].ktitle;
                kk=stdtjson.vls[p].kval;
                fmtxta=fmtxta+tt+",";
                fmtxtb=fmtxtb+kk+",";
            }
          }
          fmtxta=killlasttring(fmtxta);
          fmtxtb=killlasttring(fmtxtb);
          eval('sessionStorage.'+amd5+'="'+fmtxta+"|"+fmtxtb+'";');
          return fmtxta+"|"+fmtxtb;
         }else{
          return tmpstock;
         }
    }
    
}
function tinydata(pdt){
  layid=GetRequest().layid;
  tempid=GetRequest().tinyid;
  if (layid!=undefined && tempid!=undefined){
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
      fback=fundata("asktinydata","layid="+layid+"&tempid="+tempid,pdt);
      return fback;
    }else{
      domn=base64Decode(domn);
      return fundatap(domn,stk,"asktinydata","layid="+layid+"&tempid="+tempid,pdt,"");
    }
  }else{
    return [];
  }
}
function pageinit(){
  layid=GetRequest().layid;
  tempid=GetRequest().tinyid;
  if (layid!=undefined && tempid!=undefined){
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
      fback=fundata("gettempinit","layid="+layid+"&tempid="+tempid,"");
      return fback;
    }else{
      domn=base64Decode(domn);
      return fundatap(domn,stk,"gettempinit","layid="+layid+"&tempid="+tempid,"","");
    }
  }else{
    return [];
  }
}
function pushtiny(pcn,pkey,pval,ptitle){
    pitem='{"pkey":"'+pkey+'","pval":"'+pval+'","ptitle":"'+ptitle+'"}';
    pxitem=eval('('+pitem+')');
    pcn.push(pxitem);
    return pcn;
}
function pushsdata(stval,kx,vx){
  tot=stval.length;
  vx=[];
   for (i=0;i<tot;i++){
     tmpv="";
     eval("tmpv=stval["+i+"]."+kx+";");
     vx.push(tmpv);
   }
  return vx;
}

function newac(atitle,atab,acdt,acomm){
    return fundata("newacom","","atitle="+atitle+"&atab="+atab+"&acdt="+mkstr(acdt)+"&acomm="+acomm);
}
function maketiny(pcn,ttt){
    fmk="";
    fmt="";
    fmkv="";
    //keys,ktitles,rcvtt
    for (i=0;i<pcn.length;i++){
        kx=pcn[i].pkey;
        tx=pcn[i].ptitle;
        vx=pcn[i].pval;
        fmk=fmk+kx+",";
        fmt=fmt+tx+",";
        fmkv=fmkv+kx+"="+vx+"&";
    }
    fmk=killlasttring(fmk);
    fmt=killlasttring(fmt);
    fmkv=killlasttring(fmkv);
    pdtx=fmkv+"&keys="+fmk+"&ktitles="+fmt+"&rcvtt="+ttt;
    if (fmk!=""){
      return tinypost(pdtx);
    }else{
        return {"status":"0","msg":"参数不能为空","redirect":""};
    }
}
function tinypost(pdt){
  layid=GetRequest().layid;
  tempid=GetRequest().tinyid;
  if (layid!=undefined && tempid!=undefined){
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
      fbacktxt=ajaxhtmlpost("/localxres/funx/tinypost/?layid="+layid+"&tinyid="+tempid,pdt);
      fbackdata=eval('('+fbacktxt+')');
      if (intval(fbackdata.status)==1){
        return pagenotify("1","执行成功:"+fbackdata.msg,fbackdata.redirect);
      }else{
        return pagenotify("0","执行失败:"+fbackdata.msg,"");    
      }
    }else{
      domn=base64Decode(domn);
      return fundatap(domn,stk,"tinypost","layid="+layid+"&tinyid="+tempid,pdt,"");
    }
  }else{
   return [];
  }
}
function runfun(fid,qry,pdt){
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
      fback=fundata(fid,qry,pdt);
      if (intval(fback.status)==1){
        return "1"; 
      }else{
        return fback.msg;
      };
    }else{
        domn=base64Decode(domn);
        return fundatap(domn,stk,fid,qry,pdt,"run");
    }
}
function runalert(fid,qry,pdt){
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
      fback=fundata(fid,qry,pdt);
      if (intval(fback.status)==1){
       return pagenotify("1",fback.msg,fback.redirect);
      }else{
       return pagenotify("0",fback.msg,fback.redirect);
      };
    }else{
        domn=base64Decode(domn);
        return fundatap(domn,stk,fid,qry,pdt,"alert");
    }
}
function clstxttojson(txtstr,knm,vnm){
  kstr=qian(txtstr,"|");
  vstr=hou(txtstr,"|");
  ptk=kstr.split(",");
  ptv=vstr.split(",");
  totpt=count(ptk);
  fmall="";
  item='{"[vnm]":"[vvv]","[knm]":"[kkk]"},';
  for (k=0;k<totpt;k++){
      itemx=item;
      itemx=itemx.replace("\[vnm\]",vnm);
      itemx=itemx.replace("\[knm\]",knm);
      itemx=itemx.replace("\[vvv\]",ptv[k]);
      itemx=itemx.replace("\[kkk\]",ptk[k]);
      fmall=fmall+itemx;
  }
  fmall=killlasttring(fmall);
  return eval('(['+fmall+'])');
}
function pagenotifyx(sttx,msgx,rdrx){
    if (intval(sttx)>0){
        alert("成功-"+msgx);
    }else{
        alert("失败-"+msgx);
    }
}
function runout(fid,qry,pdtx){
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
      fback=fundata(fid,qry,pdtx);
      if (intval(fback.status)==1){
         if (fback.redirect!=""){
          //setTimeout("location.href=fback.redirect;", 1000 );
          location.href=fback.redirect;
         }else{
          window.location.reload();
          //setTimeout("window.location.reload();", 1000 );
         }
      }else{
        return pagenotify("0","执行失败",fback.msg);
      };
    }else{
        domn=base64Decode(domn);
        return fundatap(domn,stk,fid,qry,pdt,"out");
    }
}
function rungoout(fid,qry,pdtx){
    return ajaxpostgo("/localxres/funx/"+fid+"/?"+qry,pdtx,"");
}
function askimgurl(t,m,w,h){
  layid=dftval(GetRequest().layid,"");
  tempid=dftval(GetRequest().tinyid,"");
    domn=GetRequest().domn;
    stk=dftval(GetRequest().stk,"");
    if (domn==undefined || stk==undefined){
     if (layid!=undefined && tempid!=undefined){
       return "/localxres/funx/askforimg&w="+w+"&h="+h+"&tempid="+layid+"."+tempid+"&askmark="+m+"&asktitle="+t;
     }else{
       return "/localxres/funx/askforimg&w="+w+"&h="+h+"&tempid="+fullurlmd5()+"&askmark="+m+"&asktitle="+t;   
     }
    }else{
      domn=base64Decode(domn);
     if (layid!=undefined && tempid!=undefined){
       return domn+"/localxres/funx/askforimg&w="+w+"&h="+h+"&tempid="+layid+"."+tempid+"&askmark="+m+"&asktitle="+t+"&stk="+stk;
     }else{
       return domn+"/localxres/funx/askforimg&w="+w+"&h="+h+"&tempid="+fullurlmd5()+"&askmark="+m+"&asktitle="+t+"&stk="+stk;
     }
    }
}
function quickimgurl(tt){
    return askimgurl(tt,getRandChar(8),33,33);
}
function askvisiturl(tt){
    return "/localxres/funx/asktinyurl&askmark="+getRandChar(8)+"&asktitle="+tt;
}
function layurl(layid,v){
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
      return '/localxres/funx/anylay/?layid='+layid+"&refresh="+v;
    }else{
      domn=base64Decode(domn);
      return domn+'/localxres/funx/anylay/?layid='+layid+"&refresh="+v+"&stk="+stk;
    }
}
function funurl(fid,qry){
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
     return '/localxres/funx/'+fid+"/?"+qry;
    }else{
    domn=base64Decode(domn);
     return domn+'/localxres/funx/'+fid+"/?"+qry+"&stk="+stk;   
    }
}
function openitem(sno){
 stid=GetRequest().stid;
 sid=qian(stid,"-");
  if (sessionStorage.latesturl==undefined){
   sessionStorage.latesturl=decodeURIComponent(location.href);
  }
  if (stid==undefined || stid==""){
    if (strpos(prehref,"/shortid")>0){
     sid=hou(qian(prehref,"/shortid/"),"/");
    }
   }
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
      window.open('/localxres/funx/anyshortnew/?stid='+sid+"&SNO="+sno+"&rnd="+randomWord(false,6)+"&dbnm="+dftval(GetRequest().dbnm,"")+"&laydb="+dftval(GetRequest().laydb,""));
    }else{
      domn=base64Decode(domn);
      window.open(domn+'/localxres/funx/anyshortnew/?stid='+sid+"&SNO="+sno+"&rnd="+randomWord(false,6)+"&stk="+stk+"&dbnm="+dftval(GetRequest().dbnm,"")+"&laydb="+dftval(GetRequest().laydb,""));
    }
}
function goitem(sno){
 stid=GetRequest().stid;
 sid=qian(stid,"-");
  if (sessionStorage.latesturl==undefined){
   sessionStorage.latesturl=decodeURIComponent(location.href);
  }
  if (stid==undefined || stid==""){
    if (strpos(prehref,"/shortid")>0){
     sid=hou(qian(prehref,"/shortid/"),"/");
    }
   }
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
      location.href='/localxres/funx/anyshortnew/?stid='+sid+"&SNO="+sno+"&rnd="+randomWord(false,6)+"&dbnm="+dftval(GetRequest().dbnm,"")+"&laydb="+dftval(GetRequest().laydb,"");
    }else{
      domn=base64Decode(domn);
      location.href=domn+'/localxres/funx/anyshortnew/?stid='+sid+"&SNO="+sno+"&rnd="+randomWord(false,6)+"&stk="+stk+"&dbnm="+dftval(GetRequest().dbnm,"")+"&laydb="+dftval(GetRequest().laydb,"");
    }
}
function es(strx){
    if (strx==undefined || strx==""){
        return 0;
    }else{
        return 1;
    }
    
}
function typeimg($fileu,$tp){
   $tmpkzm="js,css,htm,doc,xls,ppt,pdf,txt,rar,zip,mp3,mp4,psd,jpeg,jpg,png,gif,svg,html,xlsx,docx,pptx,";
   $kzhm=hou(hou($fileu,document.domain),".");
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
      if (strpos($tmpkzm,$kzhm+",")>0){
        return "/ORG/BRAIN/images/icon/Uv9L9e06/"+$kzhm+"-"+$tp+".svg";
      }else{
        return "/ORG/BRAIN/images/icon/Uv9L9e06//svg-b.svg";
      };
    }else{
      domn=base64Decode(domn);
      if (strpos($tmpkzm,$kzhm+",")>0){
        return domn+"/ORG/BRAIN/images/icon/Uv9L9e06/"+$kzhm+"-"+$tp+".svg";
      }else{
        return domn+"/ORG/BRAIN/images/icon/Uv9L9e06/svg-b.svg";
      };
    }
}
function toitem(sno){
 stid=GetRequest().stid;
 sid=qian(stid,"-");
   if (typeof(stid)=="un"+"defined" || stid==""){
     if (strpos(prehref,"/shortid")>0){
       sid=hou(qian(prehref,"/shortid/"),"/");
     }
   }
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
       window.open('/localxres/funx/anyshortnew/?stid='+sid+"&SNO="+sno+"&rnd="+randomWord(false,6));
    }else{
       domn=base64Decode(domn);
       window.open(domn+'/localxres/funx/anyshortnew/?stid='+sid+"&SNO="+sno+"&rnd="+randomWord(false,6)+"&stk="+stk);
    }
}
function golatest(){
 if (sessionStorage.latesturl!=undefined){
   location.href=sessionStorage.latesturl;
 }
}
function vurldata(url,pdt){
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
      vtxt=ajaxhtmlpost(url,pdt);
      datax=eval('('+vtxt+')');
      return datax;  
    }else{
      domn=base64Decode(domn);
      return vurldatap(domn,stk,url,pdt);
    }
}
function seteleval(eid,valx,title){
    if (eid!="" && valx!=""){
         $("#"+eid).val(valx+':['+title+']');
         z=setselectval(eid,valx);
         return true;
     }else{
         return false; 
     }
}
function setanyval(dbnm,tbnm,tbkey,tbsno,nval){
    if (es(tbnm)*es(tbkey)*es(tbsno)==1){
        fd=fundata("setanyval","dbnm="+dbnm+"&tbnm="+tbnm+"&tbkey="+tbkey+"&tbsno="+tbsno+"&newval="+nval);
        if (intval(fd.status)==1){
            allsearch("");
        }else{
            allsearch("");
        }
    }else{
        return false;
    }
}
function pagesetval(nval){
    dbnm=dftval(GetRequest().dnm,"");
    tbnm=dftval(GetRequest().tbnm,"");
    tbkey=dftval(GetRequest().tbkey,"");
    tbsno=dftval(GetRequest().tbsno,"");
    if (es(tbnm)*es(tbkey)*es(tbsno)==1){
        fd=fundata("setanyval","dbnm="+dbnm+"&tbnm="+tbnm+"&tbkey="+tbkey+"&tbsno="+tbsno+"&newval="+nval);
        if (intval(fd.status)==1){
         parent.allsearch("");
         layurl=hou(location.href,document.domain);
         laymd5='l'+layurl.MD5();
         layidx=0;
         eval("layidx=sessionStorage."+laymd5+";");
         if (layidx==undefined){
           layidx=1;
         }else{
           layidx=intval(layidx);
         }
         setTimeout(parent.layer.close(layidx), 1000);
         setTimeout(parent.layer.closeAll(), 1000);
        }else{
            allsearch("");
        }
    }else{
        return false;
    }
}
function geteleval(srcid,srctitle){
    layurl=hou(location.href,document.domain);
    laymd5='l'+layurl.MD5();
    layidx=0;
    eval("layidx=sessionStorage."+laymd5+";");
    eid=dftval(GetRequest().eid,"");
    dbnm=dftval(GetRequest().dbnm,"");
    tbnm=dftval(GetRequest().tbnm,"");
    tbkey=dftval(GetRequest().tbkey,"");
    tbsno=dftval(GetRequest().tbsno,"");
    parent.setanyval(dbnm,tbnm,tbkey,tbsno,srcid);
    //console.log(layurl);
    //console.log(layidx);
    //console.log(dftval(GetRequest().eid,"")+"/"+srcid+"/"+srctitle);
    if (layidx==undefined){
        layidx=1;
    }else{
        layidx=intval(layidx);
    }
    setTimeout(parent.layer.close(layidx), 1000);
    setTimeout(parent.layer.closeAll(), 1000);
    
}
function fundata(fid,qry,pdt){

  url="/localxres/funx/"+fid+"/?"+qry;
  funtxt=ajaxhtmlpost(url,pdt);
  datax=eval('('+funtxt+')');
  return datax;
}

function basefun(fid,keys,pdt){
  url="/localxres/funx/basefun/?fid="+fid+"&keys="+keys;
  funtxt=ajaxhtmlpost(url,pdt);
  return funtxt;
}
function showdata(fid,data){
    switch(fid){
     case "wocao":
     break;
     default:
     //console.log(data);
    }
    return true;
}
function showrun(data){
    if (intval(data.status)==1){
        return "1";
    }else{
        return data.msg;
    }
}
function showout(data){
    if (intval(data.status)==1){
        if (data.redirect!=""){
            location.href=data.redirect;
        }else{
            window.location.reload();
        }
    }else{
        return pagenotify("0","执行失败",data.msg);
    }
}
function showalert(data){
    if (intval(data.status)==1){
        return pagenotify("1","执行成功",data.msg);
    }else{
        return pagenotify("0","执行失败",data.msg);
    }
}
function fundatap(domn,stk,fid,qry,pdt,mtd){
 sessionStorage.wocao="1";
 urlx=domn+"/localxres/funx/"+fid+"/?stk="+stk+"&fromip="+getip()+"&rnd="+onlymark();//jsonp 只有GET和异步
 if (qry!=""){
   urlx=urlx+"&"+qry;
 }
 if (pdt!=""){
   urlx=urlx+"&"+pdt;      
 }
 $.ajax({
      url:urlx,
      type:'get',
      dataType:'jsonp',
      jsonpCallback:"soda",//自定义传递给服务器的函数名，而不是使用jquery自动生成的
      jsonp:'callback',//把传递函数名的那个形参callBack变为cb
      success:function(data){
          sessionStorage.wocao="2";
        switch(mtd){
          case "run":
          return showrun(data);
          break;
          case "out":
          return showout(data);
          break;
          case "alert":
          return showalert(data);
          break;
          default:
          if (mtd==""){
              return showdata(fid,data);
          }else{
             eval(mtd);
          }
        }
      },
    })
}
function vurldatap(domn,stk,url,pdt){
 urlx=domn+url+"&stk="+stk+"&r="+onlymark();//jsonp 只有GET和异步
 if (pdt!=""){
   urlx=urlx+"&"+pdt;      
 }
 $.ajax({
      url:urlx,
      type:'get',
      dataType:'jsonp',
      jsonpCallback:"soda",//自定义传递给服务器的函数名，而不是使用jquery自动生成的
      jsonp:'callback',//把传递函数名的那个形参callBack变为cb
      success:function(data){
          return showdata(url,data);
      },
    })
}

function shortdata(stid,pnum,page,qry){
    domn=GetRequest().domn;
    stk=GetRequest().stk;
      if (qry!=""){
          if (qry.indexOf("=")>0){
            url="/localxres/funx/anyshort/?stid="+stid+"-pnum:"+pnum+"-&page="+page+"&datatype=json&"+qry+"&rnd="+onlymark();
          }else{
            url="/localxres/funx/anyshort/?stid="+stid+"-pnum:"+pnum+"-&page="+page+"&datatype=json&qry="+qry+"&rnd="+onlymark();  
          }
      }else{
        url="/localxres/funx/anyshort/?stid="+stid+"-pnum:"+pnum+"-&page="+page+"&datatype=json&rnd="+onlymark();
      }
    if (domn==undefined || stk==undefined){
      shorttxt=ajaxhtmlpost(url,"");
      shortx=eval('('+shorttxt+')');
      return shortx;
    }else{
       domn=base64Decode(domn);
       return vurldatap(domn,stk,url,"");
    }
}
function shortjson(stid,page,pnum,qry){
      if (qry!=""){
          if (qry.indexOf("=")>0){
            url="/localxres/funx/anyjson/?shortid="+stid+"&itemnum="+pnum+"&page="+page+"&"+qry+"&rnd="+onlymark();
          }else{
            url="/localxres/funx/anyjson/?shortid="+stid+"&itemnum="+pnum+"&page="+page+"&qry="+qry+"&rnd="+onlymark();  
          }
      }else{
        url="/localxres/funx/anyjson/?shortid="+stid+"&itemnum="+pnum+"&page="+page+"&rnd="+onlymark();  
      }
      shorttxt=ajaxhtmlpost(url,"");
      shortx=eval('('+shorttxt+')');
      return shortx;
}
function makeoprtbtn(tabnm,btntp,codedemo){
    bkdata=new Array();
    sd=shortdata("nSAezV","99","1","dbtabnm="+tabnm);
    fma="";
    if (intval(sd.totrcd>0) && btntp!="" && codedemo!=""){
     for (j=0;j<sd.totrcd;j++){
        btntypex=sd.vls[j].btntype;
        btntitlex=sd.vls[j].btntitle;
        btnmarkx=sd.vls[j].btnmark;
        btnclickf=sd.vls[j].onclickfun;
        if (btntp==btntypex){
           itemcode=codedemo;
           itemcode=itemcode.replace("[onclick]",tostring(btnclickf));
           itemcode=itemcode.replace("[btnmark]",btnmarkx);
           itemcode=itemcode.replace("[btntitle]",btntitlex);
           bkdata.push(itemcode);
        }
     }
       return bkdata;
    }else{
       return bkdata;
    }
}
function makeallbtn(tabnm,btntp,codedemo){
    
    sd=shortdata("nSAezV","99","1","dbtabnm="+tabnm);
    fma="";
    if (intval(sd.totrcd>0) && btntp!="" && codedemo!=""){
     for (j=0;j<sd.totrcd;j++){
        btntypex=sd.vls[j].btntype;
        btntitlex=sd.vls[j].btntitle;
        btnmarkx=sd.vls[j].btnmark;
        btnclickf=sd.vls[j].onclickfun;
        if (btntp==btntypex){
           itemcode=codedemo;
           itemcode=itemcode.replace("[onclick]",tostring(btnclickf));
           itemcode=itemcode.replace("[btnmark]",btnmarkx);
           itemcode=itemcode.replace("[btntitle]",btntitlex);
           fma=fma+itemcode;
        }
     }
       return fma;
    }else{
       return fma;
    }
}
function spacex(num){
    tmpx="";
    for (i=0;i<num;i++){
        tmpx=tmpx+" ";
    }
    return tmpx;
}

function shortkeys(stid){
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
      url="/localxres/funx/anyshort/?stid="+stid+"-pnum:30-&page=1&datatype=json&rnd="+onlymark();
      shorttxt=ajaxhtmlpost(url,"");
      shortx=eval('('+shorttxt+')');
      return shortx.keys;
    }else{
      url="/localxres/funx/anyshort/?stid="+stid+"-pnum:30-&page=1&datatype=json&rnd="+onlymark();
      domn=base64Decode(domn);
      return vurldatap(domn,stk,url,"");
    }
}
function shortktps(stid){
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
      url="/localxres/funx/anyshort/?stid="+stid+"-pnum:30-&page=1&datatype=json&rnd="+onlymark();
      shorttxt=ajaxhtmlpost(url,"");
      shortx=eval('('+shorttxt+')');
      return shortx.ktps;
    }else{
      url="/localxres/funx/anyshort/?stid="+stid+"-pnum:30-&page=1&datatype=json&rnd="+onlymark();
      domn=base64Decode(domn);
      return vurldatap(domn,stk,url,"");
    }
}
function sysuinfo(sysid){
      if (dftval(_cookie("uid"))==""){
       bkinfo=ajaxhtmlpost("/localxres/funx/sysgetuser/?sysid="+sysid+"&ptel="+_cookie("userid"),"");
      }else{
       bkinfo=ajaxhtmlpost("/localxres/funx/sysgetuser/?sysid="+sysid+"&ptel="+_cookie("uid"),"");   
      }
      bkdata=eval('('+bkinfo+')');
      return bkdata;
}
function myuinfo(){
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (_cookie("sysid")=="rberpbox"){
     if (domn==undefined || stk==undefined){
      bkinfo=ajaxhtmlpost("/localxres/funx/rbboxgetuser/?ptel="+_cookie("uid"),"");
      bkdata=eval('('+bkinfo+')');
      return bkdata;
     }else{
      domn=base64Decode(domn);
      url="/localxres/funx/rbboxgetuser/?ptel="+_cookie("uid");
      return vurldatap(domn,stk,url,"");
     }
    }else{
      return sysuinfo(_cookie("sysid"));
    }
}

function gomobilelist(){
  stid=GetRequest().stid;
  sid=qian(stid,"-");
  if (stid==undefined || stid==""){
    if (strpos(prehref,"/shortid")>0){
      sid=hou(qian(prehref,"/shortid/"),"/");
     }
   }
   localStorage.prepage="1";
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
      location.href='/localxres/funx/anyjsshort/?stid='+sid+"-pnum:10-&refresh=2&pnum=10&rnd="+randomWord(false,6);
    }else{
      domn=base64Decode(domn);
      location.href=domn+'/localxres/funx/anyjsshort/?stid='+sid+"-pnum:10-&refresh=2&pnum=10&rnd="+randomWord(false,6)+"&stk="+stk;
    }
}


function updateitem(sno){
    //vurldata  此为同步 提交
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
      sessionStorage.renderstart=intval(sessionStorage.renderstart)+1;
      stid=GetRequest().stid;
      xid=qian(stid,"-");
      tbnm=$('table[name="tabunit"]').attr("tbname");
      if (tbnm!="" && tbnm!=undefined){
       $("#upd"+sno).attr("src","/localxres/iconsetx/pagecontrol/wGsdqO.gif");
      }else{
       $("#upd"+sno).attr("src","/localxres/iconsetx/pagecontrol/wGsdqO.gif");
       tbnm="";
      }
      tbkies=$('table[name="tabunit"]').attr("tbkies");
      pttbk=tbkies.split(",");
      totp=pttbk.length;
      fmudt="";
      fmupk="";
      for (i=0;i<totp;i++){
       if ($("#p_"+pttbk[i]+sno).val()!=undefined && pttbk[i]!="SNO" && pttbk[i]!="OLMK" && pttbk[i]!="OPRT"){
        fmudt=fmudt+"&p_"+pttbk[i]+sno+"="+mkstr($("#p_"+pttbk[i]+sno).val());
        fmupk=fmupk+pttbk[i]+",";
       }
      }
      fmupk=killlasttring(fmupk);
      aurl='/localxres/funx/dataprocess/?stid='+dftval(qian(GetRequest().stid,"-"),"")+'&ptype=update&SNO='+sno+'&dbnm='+dftval(GetRequest().dbnm,"")+'&rnd='+randomWord(false,6);
      adata='SNO='+sno+fmudt;
      $.ajax({
			url:encodeURI(aurl),
			data:adata,
			type:'POST',
			dataType:"json",
			async : true, //true 异步 
			success: function(data){
			  sessionStorage.renderstart=intval(sessionStorage.renderstart)-1;
			  if (intval(data.status)==1){
                  z=pagenotify("1","修改信息成功",data.msg);
                  $("#upd"+sno).attr("src","/localxres/iconsetx/pagecontrol/sureatoc.svg");
                   if (aurl.indexOf("dataprocess")>0){
                         stid=GetRequest().stid;
                         if (stid!=undefined){
                            sid=qian(stid,"-");
                            if (intval(sessionStorage.renderstart)<=0){
                              thisurl=location.href;
                              myurl=thisurl.replace("&refresh=1","");
                              myurl=myurl.replace("&refresh=1","");
                              myurl=myurl.replace("&refresh=","");
                              //location.href=myurl;
                            }
                          }
                    }
               }else{
                  $("#upd"+sno).attr("src","/localxres/iconsetx/pagecontrol/shanchu0.svg");
                  return pagenotify("0","修改信息失败",data.msg);
               };
			}
		});
     }else{
         return updateitemp(sno);
     }
}

function delitem(sno){
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
      tbnm=$('table[name="tabunit"]').attr("tbname");
      if (tbnm!="" && tbnm!="un"+"defined"){
      }else{
       tbnm="";
      }
      return pagekill(tbnm,sno);
    }else{
      return pagekill(tbnm,sno);
    }
}
function killitem(sno){
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
      tbnm=$('table[name="tabunit"]').attr("tbname");
      z=ajaxhtmlpost("/localxres/funx/dataprocess/?stid="+dftval(qian(GetRequest().stid,"-"),"")+"&ptype=del","SNO="+sno);
      zd=eval('('+z+')');
      if (intval(zd.status)==1){
        window.location.reload();
      }else{
        return pagenotify("0","删除信息失败",zd.msg);
      }
    }else{
        domn=base64Decode(domn);
        tbnm=$('table[name="tabunit"]').attr("tbname");
        url=domn+"/localxres/funx/dataprocess/?stid="+dftval(qian(GetRequest().stid,"-"),"")+"&ptype=del&stk="+stk+"&SNO="+sno;
        zd=vurldatap(down,stk,url,"");
        if (intval(zd.status)==1){
          window.location.reload();    
        }else{
          return pagenotify("0","删除信息失败",zd.msg);    
        }
    }
}
function itemtosx(dtxt){
 return "";
}
function plotnextid($plmk,$pltab){
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
      url="/localxres/funx/plotnextid?plmk="+$plmk+"&pltab="+$pltab;
      zd=vurldata(url,"");
      return zd.myid;
    }else{
      domn=base64Decode(domn);
      url=domn+"/localxres/funx/plotnextid?plmk="+$plmk+"&pltab="+$pltab+"&stk="+stk;
      zd=vurldatap(domn,stk,url,"");
      return zd.myid;
    }
}
function mklv2menu(mnsrd,lv1srd,lv1item,lv2srd,lv2item,mndata){
    totx=mndata.length;
    fmlv1="";
    srd1=lv1srd;
    for (i=0;i<totx;i++){
        myid=mndata[i].myid;
        parid=mndata[i].parid;
      if (intval(parid)==-1 || intval(parid)==0){
        mytitle=mndata[i].mytitle;
        mymark=mndata[i].mymark;
        myurl=mndata[i].myurl;
        myclick=mndata[i].myclick;
        mydescrib=mndata[i].mydescrib;
        item1=lv1item;
        srd2=lv2srd;
        fmlv2="";
        for (j=0;j<totx;j++){
            item2=lv2item;
            thisid=mndata[j].myid;
            thispar=mndata[j].parid;
            thistitle=mndata[j].mytitle;
            thismark=mndata[j].mymark;
            thisurl=mndata[j].myurl;
            thisclick=mndata[j].myclick;
            thisdescrib=mndata[j].mydescrib;
            if (intval(thispar)==intval(myid)){
                item2=item2.replace(/\[myid\]/g,thisid);
                item2=item2.replace(/\[mytitle\]/g,thistitle);
                item2=item2.replace(/\[mymark\]/g,thismark);
                item2=item2.replace(/\[myurl\]/g,thisurl);
                item2=item2.replace(/\[myclick\]/g,thisclick);
                item2=item2.replace(/\[mydescrib\]/g,thisdescrib);
                item2=item2.replace(/\[mypar\]/g,thispar);
                fmlv2=fmlv2+item2;
            }//if
        }//forj
        srd2=srd2.replace("\[inner\]",fmlv2);
        item1=item1.replace(/\[myid\]/g,myid);
        item1=item1.replace(/\[mytitle\]/g,mytitle);
        item1=item1.replace(/\[mymark\]/g,mymark);
        item1=item1.replace(/\[myurl\]/g,myurl);
        item1=item1.replace(/\[myclick\]/g,myclick);
        item1=item1.replace(/\[mydescrib\]/g,mydescrib);
        item1=item1.replace("\[inner\]",srd2);
        fmlv1=fmlv1+item1;
      }//ifparid
    }//fori
    srd1=srd1.replace("\[inner\]",fmlv1);
    mnsrd=mnsrd.replace("\[inner\]",srd1);
    return mnsrd;
}

function makenextselect(tbnm,nkey,sno,prekey,qry){
  bkd=ajaxhtmlpost("/localxres/funx/makeselect&"+qry+"&prekey="+prekey+"&tabname="+tbnm+"&tabkey="+nkey+"&tabsno="+sno,"");
  $("#"+nkey+sno).html(bkd);
}
function plsc(surl,tbnm){
  tbnm=$('table[name="tabunit"]').attr("tbname");
  return pagemasskill(surl,tbnm);
}
function ssclear(){
 return ajaxhtmlpost("/localxres/funx/sessionclear","");
}


function left(mainStr,lngLen) { 
 if (lngLen>0) {return mainStr.substring(0,lngLen)} 
 else{return null} 
 }  

function right(mainStr,lngLen) { 
// alert(mainStr.length) 
 if (mainStr.length-lngLen>=0 && mainStr.length>=0 && mainStr.length-lngLen<=mainStr.length) { 
 return mainStr.substring(mainStr.length-lngLen,mainStr.length)} 
 else{return null} 
 } 
function mid(mainStr,starnum,endnum){ 
 if (mainStr.length>=0){ 
 return mainStr.substr(starnum,endnum) 
 }else{return null} 
 //mainStr.length 
 }
function resetkey($xid,$keyx,$sno){
 prehref=decodeURIComponent(location.href);
  houhref=hou(prehref,"?");
  pthref=houhref.split("&");
  totp=pthref.length;
  if (prehref.indexOf("pnum:")>0){
   pn=qian(hou(prehref,"pnum:"),"-");
  }else{
   pn="";
  }
  fmxxx="";
  pppp="";
  tmpss="";
  for (i=0;i<totp;i++){
 if (qian(pthref[i],"=")!="page" && qian(pthref[i],"=")!="pnum"){
   if (qian(pthref[i],"=")!=""){
  eval("tmpss=sessionStorage."+qian(pthref[i],"=")+";");   
  
   }else{
  tmpss="";
   }
   if (tmpss!=undefined && tmpss!=""){
  fmxxx=fmxxx+"&"+qian(pthref[i],"=")+"="+tmpss;
  }else{
  fmxxx=fmxxx+"&"+pthref[i];
  }
 }
  }
 if (sessionStorage.pgnum=="" || sessionStorage.pgnum==undefined){
   if (pn==""){
  pgnum=GetRequest().pnum;
   }else{
  pgnum=pn;
   }
 }else{   
  pgnum=sessionStorage.pnum;
 }
 if (sessionStorage.page==""){
  pgpage=GetRequest().page;
 }else{
  pgpage=sessionStorage.page;
 }
 if  (typeof(pgnum)=="un"+"defined" || pgnum==""){
   pgnum="30";
 }
if  (typeof(pgpage)!="un"+"defined"){  
  if (pgpage.indexOf(":")>0){
 pppp="page="+pgpage+"&pnum="+pgnum;
  if (strpos(prehref,"stid=")>0){
  }else{  
  if (strpos(prehref,"/shortid")>0){
   sid=hou(qian(prehref,"/shortid/"),"/");
   pppp=pppp+"&stid="+sid;
  };  
  };
 sessionStorage.page=pgpage;
 sessionStorage.pnum=pgnum;
  }else{
 pppp="page="+pgpage+"&pnum="+pgnum;
  if (strpos(prehref,"stid=")>0){
  }else{  
  if (strpos(prehref,"/shortid")>0){
   sid=hou(qian(prehref,"/shortid/"),"/");
   pppp=pppp+"&stid="+sid;
  };  
  };
 sessionStorage.page=pgpage;
 sessionStorage.pnum=pgnum;
  }
}else{
  pppp="pnum="+pgnum+"&page=1";
  if (strpos(prehref,"stid=")>0){
  }else{  
  if (strpos(prehref,"/shortid")>0){
   sid=hou(qian(prehref,"/shortid/"),"/");
   pppp=pppp+"&stid="+sid;
  };  
  };
  sessionStorage.page="1";
  sessionStorage.pnum=pgnum;
}
  if (fmxxx.indexOf("qry=")==-1){
   if (sessionStorage.qry!=undefined && sessionStorage.qry!=""){
  fmxxx=fmxxx+"&qry="+sessionStorage.qry;
   }else{
  if (sessionStorage.xkey!=undefined && sessionStorage.xkey!="" && sessionStorage.xval!=undefined && sessionStorage.xval!=""){
  fmxxx=fmxxx+"&xkey="+sessionStorage.xkey+"&xval="+sessionStorage.xval;
  }
   }
  }else{
 //如果存在qry 则不继续探索
  } 
  purl="/localxres/funx/anyshort/?"+pppp+fmxxx;   
  tbnm=$('table[name="tabunit"]').attr("tbname");
   if (tbnm!="" && tbnm!="un"+"defined"){
   }else{
  tbnm="";
   }
   stid=GetRequest().stid;
   sid=qian(stid,"-");   
   if ($xid=="" || $xid==undefined){
  $xid=sid;
   }
   if(pgnum.indexOf(":")>0){
   pnum=qian(pgnum,":");
   }else{
   pnum=pgnum;
   }
   if(pgpage.indexOf(":")>0){
  page=qian(pgpage,":");
   }else{
  page=pgpage;
   }
  bkxyz=ajaxhtmlpost(purl+"&datatype=table&tabkey="+$keyx+"&SNO="+$sno,"");  
  if (bkxyz!=""){
 $("#"+$keyx+$sno).html(bkxyz);  
 //layrender();
 //newtdlisten();   
 //listenclsduo();
 //newjsfile("/FACE/imginout/js/boxImg.js");
 //newjsfile("/FACE/inputpm/js/num-alignment.js");
  }
 layui.use(['form'], function(){
 form=layui.form;
 form.on('select(brickType)', function(data){ 
 ocg=$(this).parent().parent().prev().attr("onchange");
  nv=$(this).attr("lay-value");
  if (typeof(ocg)!="un"+"defined" && typeof(nv)!="un"+"defined"){
   if (ocg!=""){
  ocg=ocg.replace(/<thisnewvalue>/g,nv);
  eval(ocg);
  form.render(); 
 };
   };
  });
 });   
}
function fullurlmd5(){
 preurl=decodeURIComponent(location.href);
 return preurl.MD5();
}
function shorturlmd5(){
 var domain = document.domain;
 preurl=decodeURIComponent(location.href);
 shorturl=hou(preurl,domain);
 return shorturl.MD5();
}
function urltopath($url){$ptxyz=explode("/",$url);$totp=countx($ptxyz);$lslen=strlen($ptxyz[$totp-1]);return substr($url,0,strlen($url)-$lslen);}//DESCRIB ():  END@()
function urlfname($urlx){$ptxyz=explode("/",$urlx);$totp=countx($ptxyz);return $ptxyz[$totp-1];}//DESCRIB ():  END@()
function savehtmltolc(stid,htmlx){
 if (htmlx!="" && htmlx!=undefined && stid!=""){
  htmlx=htmlx.replace(/\r\n/g,"-r-n");
  htmlx=htmlx.replace(/</g,"〖");
  htmlx=htmlx.replace(/>/g,"〗");
  //eval("sessionStorage."+varmark+"='"+htmlx.replace(/\'/g,"@-v-@")+"';");
  $("#"+stid+"storage").html(htmlx.replace(/\'/g,"@-v-@"));//用页面存储节约空间，浏览器存储太费了。
  return true;
 }else{
  return false;
 }
}
function gethtmlfromlc(stid){
 tmpvar="";
 tmpval="";
 //eval("tmpvar=typeof(sessionStorage."+varmark+");");
 if (stid!=""){
  //eval("tmpval=sessionStorage."+varmark+";");
  tmpval=$("#"+stid+"storage").html();
  tmpval=tmpval.replace(/-r-n/g,"\r\n");
  tmpval=tmpval.replace(/〖/g,"<");
  tmpval=tmpval.replace(/〗/g,">");
  tmpval=tmpval.replace(/@-v-@/g,"\'");
  return tmpval;
 }else{
  return "";
 }
}
function rehtml(oldhtml,stid,sno,newpart){
 if (oldhtml!="" && stid!="" && sno!="" && newpart!=""){
 startx=qian(oldhtml,"<tr id=\""+stid+sno+"\"");
 endx=hou(hou(oldhtml,"<tr id=\""+stid+sno+"\""),"</tr>");
 roidx=qian(hou(oldhtml,"<tr id=\""+stid+sno+"\""),">");
  return startx+"<tr id=\""+stid+sno+"\" "+roidx+" >"+newpart+"</tr>"+endx;
 }else{
  return oldhtml;
 }
}
function resetline($xid,$sno){
 prehref=decodeURIComponent(location.href);
  houhref=hou(prehref,"?");
  pthref=houhref.split("&");
  totp=pthref.length;
  if (prehref.indexOf("pnum:")>0){
   pn=qian(hou(prehref,"pnum:"),"-");
  }else{
   pn="";
  }
  fmxxx="";
  pppp="";
  tmpss="";
  for (i=0;i<totp;i++){
 if (qian(pthref[i],"=")!="page" && qian(pthref[i],"=")!="pnum"){
   if (qian(pthref[i],"=")!=""){
  eval("tmpss=sessionStorage."+qian(pthref[i],"=")+";");   
   }else{
  tmpss="";
   }
   if (tmpss!=undefined && tmpss!=""){
  fmxxx=fmxxx+"&"+qian(pthref[i],"=")+"="+tmpss;
  }else{
  fmxxx=fmxxx+"&"+pthref[i];
  }
 }
  }
 if (sessionStorage.pgnum=="" || sessionStorage.pgnum==undefined){
   if (pn==""){
  pgnum=GetRequest().pnum;
   }else{
  pgnum=pn;
   }
 }else{   
  pgnum=sessionStorage.pnum;
 }
 if (sessionStorage.page==""){
  pgpage=GetRequest().page;
 }else{
  pgpage=sessionStorage.page;
 }
 if  (typeof(pgnum)=="un"+"defined" || pgnum==""){
   pgnum="30";
 }
if  (typeof(pgpage)!="un"+"defined"){  
  if (pgpage.indexOf(":")>0){
 pppp="page="+pgpage+"&pnum="+pgnum;
  if (strpos(prehref,"stid=")>0){
  }else{  
  if (strpos(prehref,"/shortid")>0){
   sid=hou(qian(prehref,"/shortid/"),"/");
   pppp=pppp+"&stid="+sid;
  };  
  };
 sessionStorage.page=pgpage;
 sessionStorage.pnum=pgnum;
  }else{
 pppp="page="+pgpage+"&pnum="+pgnum;
  if (strpos(prehref,"stid=")>0){
  }else{  
  if (strpos(prehref,"/shortid")>0){
   sid=hou(qian(prehref,"/shortid/"),"/");
   pppp=pppp+"&stid="+sid;
  };  
  };
 sessionStorage.page=pgpage;
 sessionStorage.pnum=pgnum;
  }
}else{
  pppp="pnum="+pgnum+"&page=1";
  if (strpos(prehref,"stid=")>0){
  }else{  
  if (strpos(prehref,"/shortid")>0){
   sid=hou(qian(prehref,"/shortid/"),"/");
   pppp=pppp+"&stid="+sid;
  };  
  };
  sessionStorage.page="1";
  sessionStorage.pnum=pgnum;
}
  if (fmxxx.indexOf("qry=")==-1){
   if (sessionStorage.qry!=undefined && sessionStorage.qry!=""){
  fmxxx=fmxxx+"&qry="+sessionStorage.qry;
   }else{
  if (sessionStorage.xkey!=undefined && sessionStorage.xkey!="" && sessionStorage.xval!=undefined && sessionStorage.xval!=""){
  fmxxx=fmxxx+"&xkey="+sessionStorage.xkey+"&xval="+sessionStorage.xval;
  }
   }
  }else{
 //如果存在qry 则不继续探索
  } 
  purl="/localxres/funx/anyshort/?"+pppp+fmxxx;   
  tbnm=$('table[name="tabunit"]').attr("tbname");
   if (tbnm!="" && tbnm!="un"+"defined"){
   }else{
  tbnm="";
   }
   stid=GetRequest().stid;
   sid=qian(stid,"-");   
   if ($xid=="" || $xid==undefined){
  $xid=sid;
   }
   if(pgnum.indexOf(":")>0){
   pnum=qian(pgnum,":");
   }else{
   pnum=pgnum;
   }
   if(pgpage.indexOf(":")>0){
  page=qian(pgpage,":");
   }else{
  page=pgpage;
   }
  bkxyz=ajaxhtmlpost(purl+"&datatype=table&SNO="+$sno,""); 
  if (bkxyz!=""){
 newhtml=rehtml(gethtmlfromlc(sid),sid,$sno,bkxyz);
 n=savehtmltolc("h"+shorturlmd5(),newhtml);
 ohtm=$("form[name='tabform']").html(newhtml);
 hlen=ohtm.length;
 hnlen=newhtml.length;
 diflen=Math.abs(hnlen-hlen);  
 if (intval(sessionStorage.renderstart)==0){
  sessionStorage.renderstart=-1;
  layrender();
  newtdlisten();   
  listenclsduo();
  //newjsfile("/FACE/imginout/js/boxImg.js");
  //newjsfile("/FACE/inputpm/js/num-alignment.js");
  sessionStorage.renderstart=0;
 }else{
  //console.log("diflen-"+diflen);
 }
  }
 layui.use(['form'], function(){
 form=layui.form;
 form.on('select(brickType)', function(data){ 
 ocg=$(this).parent().parent().prev().attr("onchange");
  nv=$(this).attr("lay-value");
  if (typeof(ocg)!="un"+"defined" && typeof(nv)!="un"+"defined"){
   if (ocg!=""){
  ocg=ocg.replace(/<thisnewvalue>/g,nv);
  eval(ocg);
  form.render(); 
 };
   };
  });
 });   
}
function setpage(pgn){
  prehref=decodeURIComponent(location.href);
  houhref=hou(prehref,"?");
  pthref=houhref.split("&");
  ccd=ccode;
  kcd=kcode;
  if (strpos(prehref,"stid=")>0){
   sid=qian(hou(prehref,"stid="),"-");
  }else if (strpos(prehref,"/shortid")>0){
    sid=hou(qian(prehref,"/shortid/"),"/");
    pppp=pppp+"&stid="+sid;
  }else{
    sid=xid;
  }
  if (prehref.indexOf("pnum:")>0){
    pn=qian(hou(prehref,"pnum:"),"-");
  }else{
    pn="";
  }
  totp=pthref.length;
  fmxxx="";
  pppp="";
  for (i=0;i<totp;i++){
     if (qian(pthref[i],"=")!="page" && qian(pthref[i],"=")!="pnum" && qian(pthref[i],"=")!="xkey"  && qian(pthref[i],"=")!="xval"  && qian(pthref[i],"=")!="qry"  && qian(pthref[i],"=")!="stid"  && qian(pthref[i],"=")!="datatype"){
       fmxxx=fmxxx+"&"+pthref[i];
      }
  }
 pgnum=dftval(sessionStorage.pnum,GetRequest().pnum);
 pgnum=dftval(pgnum,pn);
 pgnum=dftval(pgnum,pgn);
 pgpage=dftval(sessionStorage.page,GetRequest().page);
 pgpage=dftval(pgpage,"1");
 if (pgnum.indexOf(":")>0){
     pgnum=pgn+":"+hou(pgnum,":");
 }
 if (pgpage.indexOf(":")>0){
     pppp="&page=1:"+hou(pgpage,":")+"&pnum="+pgnum+"&qry="+mkstr($("#searchkey").val());
     sessionStorage.page="1:"+hou(pgpage,":");
     sessionStorage.pnum=pgnum;
     sessionStorage.xkey="";
     sessionStorage.xval="";
     sessionStorage.qry=mkstr($("#searchkey").val());
 }else{
     pppp="&page=1&pnum="+pgnum+"&qry="+mkstr($("#searchkey").val());
     sessionStorage.page=1;
     sessionStorage.pnum=pgnum;
     sessionStorage.xkey="";
     sessionStorage.xval="";
     sessionStorage.qry=mkstr($("#searchkey").val());
 }
   purl="/localxres/funx/anyshort/?stid="+sid+pppp+fmxxx;
   tbnm=dftval($('table[name="tabunit"]').attr("tbname"),"");
   sessionStorage.ccdhtml=ccd["chtml"];
   sessionStorage.sid=sid;
   sessionStorage.tbnm=tbnm;
   sessionStorage.spage="1";
   sessionStorage.spnum=pgn;
   sessionStorage.allsc="";
   sessionStorage.xk="";
   sessionStorage.xv="";
   z=jsontab(purl,tbnm,"1",sid,intval(pgn));
}
function tospage(pgx){
  prehref=decodeURIComponent(location.href);
  houhref=hou(prehref,"?");
  pthref=houhref.split("&");
  ccd=ccode;
  kcd=kcode;
  if (strpos(prehref,"stid=")>0){
   sid=qian(hou(prehref,"stid="),"-");
  }else if (strpos(prehref,"/shortid")>0){
    sid=hou(qian(prehref,"/shortid/"),"/");
    pppp=pppp+"&stid="+sid;
  }else{
    sid=xid;
  }
  if (prehref.indexOf("pnum:")>0){
    pn=qian(hou(prehref,"pnum:"),"-");
  }else{
    pn="";
  }
  totp=pthref.length;
  fmxxx="";
  pppp="";
  for (i=0;i<totp;i++){
     if (qian(pthref[i],"=")!="page" && qian(pthref[i],"=")!="pnum" && qian(pthref[i],"=")!="xkey"  && qian(pthref[i],"=")!="xval"  && qian(pthref[i],"=")!="qry"  && qian(pthref[i],"=")!="stid"  && qian(pthref[i],"=")!="datatype"){
       fmxxx=fmxxx+"&"+pthref[i];
      }
  }
 pgnum=dftval(sessionStorage.pnum,GetRequest().pnum);
 pgnum=dftval(pgnum,pn);
 pgnum=dftval(pgnum,"30");
 pgpage=dftval(sessionStorage.page,GetRequest().page);
 pgpage=dftval(pgpage,pgx);

 if (pgpage.indexOf(":")>0){
     pppp="&page="+pgx+":"+hou(pgpage,":")+"&pnum="+pgnum+"&qry="+mkstr($("#searchkey").val());
     sessionStorage.page=pgx+hou(pgpage,":");
     sessionStorage.pnum=pgnum;
     sessionStorage.xkey="";
     sessionStorage.xval="";
     sessionStorage.qry=mkstr($("#searchkey").val());
 }else{
     pppp="&page="+pgx+"&pnum="+pgnum+"&qry="+mkstr($("#searchkey").val());
     sessionStorage.page=pgx;
     sessionStorage.pnum=pgnum;
     sessionStorage.xkey="";
     sessionStorage.xval="";
     sessionStorage.qry=mkstr($("#searchkey").val());
 }

   purl="/localxres/funx/anyshort/?stid="+sid+pppp+fmxxx;
   tbnm=dftval($('table[name="tabunit"]').attr("tbname"),"");
   console.log("-bfjsontab-"+tbnm);
   sessionStorage.ccdhtml=ccd["chtml"];
   sessionStorage.sid=sid;
   sessionStorage.tbnm=tbnm;
   sessionStorage.spage=pgx;
   sessionStorage.spnum=qian(pgnum,":");
   sessionStorage.allsc="";
   sessionStorage.xk="";
   sessionStorage.xv="";
   z=jsontab(purl,tbnm,pgx,sid,intval(pgnum));
}
function allsearch(xid){
  prehref=decodeURIComponent(location.href);
  houhref=hou(prehref,"?");
  pthref=houhref.split("&");
  ccd=ccode;
  kcd=kcode;
  if (strpos(prehref,"stid=")>0){
   sid=qian(hou(prehref,"stid="),"-");
  }else if (strpos(prehref,"/shortid")>0){
    sid=hou(qian(prehref,"/shortid/"),"/");
    pppp=pppp+"&stid="+sid;
  }else{
    sid=xid;
  }
  if (prehref.indexOf("pnum:")>0){
    pn=qian(hou(prehref,"pnum:"),"-");
  }else{
    pn="";
  }
  totp=pthref.length;
  fmxxx="";
  pppp="";
  for (i=0;i<totp;i++){
     if (qian(pthref[i],"=")!="page" && qian(pthref[i],"=")!="pnum" && qian(pthref[i],"=")!="xkey"  && qian(pthref[i],"=")!="xval"  && qian(pthref[i],"=")!="qry"  && qian(pthref[i],"=")!="stid"  && qian(pthref[i],"=")!="datatype"){
       fmxxx=fmxxx+"&"+pthref[i];
      }
  }
 pgnum=dftval(sessionStorage.pnum,GetRequest().pnum);
 pgnum=dftval(pgnum,pn);
 pgnum=dftval(pgnum,"30");
 pgpage=dftval(sessionStorage.page,GetRequest().page);
 pgpage=dftval(pgpage,"1");

 if (pgpage.indexOf(":")>0){
     pppp="&page=1:"+hou(pgpage,":")+"&pnum="+pgnum+"&qry="+mkstr($("#searchkey").val());
     sessionStorage.page="1:"+hou(pgpage,":");
     sessionStorage.pnum=pgnum;
     sessionStorage.xkey="";
     sessionStorage.xval="";
     sessionStorage.qry=mkstr($("#searchkey").val());
 }else{
     pppp="&page=1&pnum="+pgnum+"&qry="+mkstr($("#searchkey").val());
     sessionStorage.page=1;
     sessionStorage.pnum=pgnum;
     sessionStorage.xkey="";
     sessionStorage.xval="";
     sessionStorage.qry=mkstr($("#searchkey").val());
 }

   purl="/localxres/funx/anyshort/?stid="+sid+pppp+fmxxx;
   tbnm=dftval($('table[name="tabunit"]').attr("tbname"),"");
   sessionStorage.ccdhtml=ccd["chtml"];
   sessionStorage.sid=sid;
   sessionStorage.tbnm=tbnm;
   sessionStorage.spage="1";
   sessionStorage.spnum=qian(pgnum,":");
   sessionStorage.allsc="";
   sessionStorage.xk="";
   sessionStorage.xv="";
   z=jsontab(purl,tbnm,"1",sid,intval(pgnum));
}
function gosearch(xid){
  prehref=decodeURIComponent(location.href);
  houhref=hou(prehref,"?");
  pthref=houhref.split("&");
  ccd=ccode;
  kcd=kcode;
  if (strpos(prehref,"stid=")>0){
   sid=qian(hou(prehref,"stid="),"-");
  }else if (strpos(prehref,"/shortid")>0){
    sid=hou(qian(prehref,"/shortid/"),"/");
    pppp=pppp+"&stid="+sid;
  }else{
    sid=xid;
  }
  if (prehref.indexOf("pnum:")>0){
    pn=qian(hou(prehref,"pnum:"),"-");
  }else{
    pn="";
  }
  totp=pthref.length;
  fmxxx="";
  pppp="";
  for (i=0;i<totp;i++){
     if (qian(pthref[i],"=")!="page" && qian(pthref[i],"=")!="pnum" && qian(pthref[i],"=")!="xkey"  && qian(pthref[i],"=")!="xval"  && qian(pthref[i],"=")!="qry"  && qian(pthref[i],"=")!="stid"  && qian(pthref[i],"=")!="datatype"){
       fmxxx=fmxxx+"&"+pthref[i];
      }
  }
 pgnum=dftval(sessionStorage.pnum,GetRequest().pnum);
 pgnum=dftval(pgnum,pn);
 pgnum=dftval(pgnum,"30");
 pgpage=dftval(sessionStorage.page,GetRequest().page);
 pgpage=dftval(pgpage,"1");

 if (pgpage.indexOf(":")>0){
     pppp="&page=1:"+hou(pgpage,":")+"&pnum="+pgnum+"&qry="+mkstr($("#searchkey").val());
     sessionStorage.page="1:"+hou(pgpage,":");
     sessionStorage.pnum=pgnum;
     sessionStorage.xkey="";
     sessionStorage.xval="";
     sessionStorage.qry=mkstr($("#searchkey").val());
 }else{
     pppp="&page=1&pnum="+pgnum+"&qry="+mkstr($("#searchkey").val());
     sessionStorage.page=1;
     sessionStorage.pnum=pgnum;
     sessionStorage.xkey="";
     sessionStorage.xval="";
     sessionStorage.qry=mkstr($("#searchkey").val());
 }

   purl="/localxres/funx/anyjsshort/?stid="+sid+pppp+fmxxx;
   location.href=purl;
}
function newtdlisten(){
  $('td').click(function (){
 var isup=$('#isupdate').prop('checked');
 var isuv=$('#isupdate').val();
 var tdcls=$(this).attr("class");
 var rdol=$(this).attr("rdol");
 var knm=$(this).attr("knm");
  if (isup==true || (isuv*1)==1 && rdol!="readonly"  && knm!="OPRT" && knm!="SNO" && knm!="OLMK"){
 var snoid=$(this).attr('snoid');
 var knmid=$(this).attr('knm');
 var tiptid=knmid+snoid;
 var tiptidx="p_"+knmid+snoid;
 var oldvl=$('#'+tiptid).html();
 var tydata=typeof($(this).attr('tdata'));
 if (tydata!="un"+"defined"){
  var olddtvl=unquote($(this).attr('tdata'));
   olddtvl=hhth(olddtvl);
 }else{
  var olddtvl="";   
 }
 var tptid=typeof($('#'+tiptid));
 if (tptid!="un"+"defined"){
  var tiphtm=$('#'+tiptid).html();
  var iptsize=tiphtm.length;
  var kntp=$(this).attr('tpnm');
 }else{
  var iptsize=0;
  var kntp="";
 }
  atb=document.getElementsByName("anytable");
  tota=atb.length;
 allck="";
  for (m=0;m<tota;m++){
  allck=allck+$(atb[m]).attr("cantkies")+",";
  }
  var cks="xy-"+allck;
  var knmx=$(this).attr("knm");
  if (iptsize==0 || iptsize>10){iptsize=15};
   if (oldvl.indexOf('<input')<=-1 && oldvl.indexOf('<textarea')<=-1 && oldvl.indexOf('<select')<=-1 && cks.indexOf(knmx)<=-1){
  if (kntp=='text' || kntp=='longtext'){
  inhtml='<text'+'area id="'+tiptidx+'" rows=3 cols=50 >'+olddtvl.replace(/\\\'/g,"\'")+'</text'+'area>';
  $('#'+tiptid).html(inhtml);
  }else{
  inhtml= '<text'+'area id="'+tiptidx+'" rows=2 cols=33 >'+olddtvl.replace(/\\\'/g,"\'")+'</text'+'area>';
  $('#'+tiptid).html(inhtml);
  };
   };
   
  }else{
  };
 }
);
  return true;
}
function uniturl(ourl){
  prehref=decodeURIComponent(location.href);
  houhref=hou(prehref,"?");
  pthref=houhref.split("&");
  totp=pthref.length;
  fmxxx="";
  pppp="";
  for (i=0;i<totp;i++){
 pkey=""; 
 pkey=qian(pthref[i],"=")+"=";
 if (ourl.indexOf(pkey)>0){   
 }else{
   fmxxx=fmxxx+"&"+pthref[i];
 }
  }
 location.href=ourl+fmxxx;
}
function upfl(sno,tb,key){
  var srcd=$("#imghead"+key+sno).attr("src");
  var x=ajaxhtmlpost('/localxres/funx/anyrcvimg&tbnm='+tb+'&SNO='+sno+'&key='+key,'src='+srcd);  
   if(x=="1"){
  alert("成功");
   };
  }

 function update(xyz,sno) {
  bktxt=F('gaddpage','stid='+xyz);
  bkdata=eval('('+bktxt+')');
  bku=bkdata.redirect;
  prehref=decodeURIComponent(location.href);
  houhref=hou(prehref,"?");
  pthref=houhref.split("&");
  totp=pthref.length;
  fmxxx="";
  for (i=0;i<totp;i++){
     if (qian(pthref[i],"=")!="page" && qian(pthref[i],"=")!="pnum" && qian(pthref[i],"=")!="xkey"  && qian(pthref[i],"=")!="xval"  && qian(pthref[i],"=")!="qry"  && qian(pthref[i],"=")!="stid" && qian(pthref[i],"=")!="datatype"){
        fmxxx=fmxxx+"&"+pthref[i];
     }
   }
   if (bku.length>10){
       ptnhtxt=bku.split("[get-");
       totpt=ptnhtxt.length;
       for (f=1;f<totpt;f++){
         tmpok=qian(ptnhtxt[f],"]");
         eval("gvl=GetRequest()."+tmpok+";");
         bku=bku.replace("[get-"+tmpok+"]",gvl); 
       };
       bku=bku.replace("[stid]",xyz); 
       bku=bku.replace("[sno]",sno); 
       if (bku.indexOf("?")==-1){
          bku=bku+"?rdr=1&rnd="+randomWord(false,10);
       }else{
          bku=bku+"&rdr=1&rnd="+randomWord(false,10);
       }
         bkurl=ajaxhtmlpost(bku,"");
       if (bkurl.indexOf("location:")==0){
         surl=bkurl.replace("location:","");
       }else{
         surl=bku;
       }
   }else{
    if (xyz.length>10){
      bku=xyz;
      ptnhtxt=bku.split("[get-");
      totpt=ptnhtxt.length;
      for (f=1;f<totpt;f++){
       tmpok=qian(ptnhtxt[f],"]");
       eval("gvl=GetRequest()."+tmpok+";");
       bku=bku.replace("[get-"+tmpok+"]",gvl); 
      };
      bku=bku.replace("[stid]",xyz); 
      bku=bku.replace("[sno]",sno); 
      bku=bku.replace("[appid]",GetRequest().appid); 
      if (bku.indexOf("?")==-1){
         bku=bku+"?rdr=1&rnd="+randomWord(false,10);
      }else{
         bku=bku+"&rdr=1&rnd="+randomWord(false,10);
      }
      bkurl=ajaxhtmlpost(bku,"");
      if (bkurl.indexOf("location:")==0){
         surl=bkurl.replace("location:","");
      }else{
         surl=bku;
      }
    }else{
       surl='/localxres/funx/anyshortnew/?stid='+xyz+'&SNO='+sno+'&rnd='+randomWord(false,10);
    }
  };
   surl=surl+fmxxx;
   whf=bkdata;
   if (whf.status==1){
    hx=whf.h+"px";
    wx=whf.w+"px";
   }else{
    hx='600px';
    wx='1000px';
    mx=true;
   }
    tt=whf.t;
  if (surl.indexOf("SNO")>0){
     if (surl.indexOf("SNO=0")>0){
       ttt="为"+tt+"新增记录";
     }else{
       ttt="编辑"+tt+"的详情";
     }
   }else{
     ttt=""+tt+"的列表";
   }
  if (whf.f==1){
   mx=false;
  }else{
   mx=true;
  }
  layidx=layer.open({
   type: 2,
   title: ttt,
   shadeClose: true,
   shade: false,
   maxmin: mx, //开启最大化最小化按钮
   area: [wx, hx],
   content: surl //这里content是一个URL,如果你不想让iframe出现滚动条,你还可以content: ['http://sentsin.com', 'no']
  });
  umd5=surl.MD5();
  eval("sessionStorage.l"+umd5+"="+layidx+";");
 }
function newwin(title,url) {  
   bku=url;
   ptnhtxt=bku.split("[get-");
   totpt=ptnhtxt.length;
  for (f=1;f<totpt;f++){
   tmpok=qian(ptnhtxt[f],"]");
   eval("gvl=GetRequest()."+tmpok+";");
   bku=bku.replace("[get-"+tmpok+"]",gvl); 
  };
  bku=bku.replace("[stid]",qian(GetRequest().stid,"-")); 
  bku=bku.replace("[appid]",GetRequest().appid); 
   if (bku.indexOf("?")==-1){
     bku=bku+"?rdr=1&rnd="+randomWord(false,10);
   }else{
     bku=bku+"&rdr=1&rnd="+randomWord(false,10);
   }
   bkurl=ajaxhtmlpost(bku,"");
   if (bkurl.indexOf("location:")==0){
     surl=bkurl.replace("location:","");
   }else{
     surl=bku;
   }
  if (surl.indexOf("stid=")>0){
    ustid=qian(qian(hou(surl,"stid="),"&"),"-");
    bkwhf= F('getstwh','stid='+ustid,''); 
    whf=eval('('+bkwhf+')');
    if (whf.status==1){
     hx=whf.h+"px";
     wx=whf.w+"px";
    }else{
     hx='800px';
     wx='1000px';
     mx=true;
    }
    tt=whf.t;
   if (surl.indexOf("SNO")>0){
     if (surl.indexOf("SNO=0")>0){
       ttt="为"+tt+"新增记录";
     }else{
       ttt="编辑"+tt+"的详情";
     }
   }else{
     ttt=""+tt+"的列表";
   }
  
   if (whf.f==1){
     mx=false;
   }else{
     mx=true;
   }
 
  }else{
    xyz=surl;
    ttt=title;
    mx=true;
    hx='800px';
    wx='1000px';
  }


  layidx=layer.open({
   type: 2,
   title: ttt,
   shadeClose: true,
   shade: false,
   maxmin: mx, //开启最大化最小化按钮
   area: [wx, hx],
   content: surl //这里content是一个URL,如果你不想让iframe出现滚动条,你还可以content: ['http://sentsin.com', 'no']
  });
  umd5=surl.MD5();
  
  //console.log(surl);
  //console.log("l"+umd5);
  //console.log(layidx);
  eval("sessionStorage.l"+umd5+"="+layidx+";");
 }
function openwin(title,url,w,h) {  
   bku=url;
   ptnhtxt=bku.split("[get-");
   totpt=ptnhtxt.length;
  for (f=1;f<totpt;f++){
   tmpok=qian(ptnhtxt[f],"]");
   eval("gvl=GetRequest()."+tmpok+";");
   bku=bku.replace("[get-"+tmpok+"]",gvl); 
  };
  bku=bku.replace("[stid]",qian(GetRequest().stid,"-")); 
  bku=bku.replace("[appid]",GetRequest().appid); 
   if (bku.indexOf("?")==-1){
   bku=bku+"?rdr=1&rnd="+randomWord(false,10);
   }else{
   bku=bku+"&rdr=1&rnd="+randomWord(false,10);
   }
   bkurl=ajaxhtmlpost(bku,"");
   if (bkurl.indexOf("location:")==0){
  surl=bkurl.replace("location:","");
   }else{
  surl=bku;
   }
   if (surl.indexOf("stid=")>0){
  xyz=qian(qian(hou(surl,"stid="),"&"),"-");
   }else{
  xyz=surl;
   }   
   if (h>0){
  hx=h+"px";
  wx=w+"px";
   }else{
  hx='600px';
  wx='893px';
   }
 mx=true;   
  layidx=layer.open({
   type: 2,
   title: title,
   shadeClose: true,
   shade: false,
   maxmin: mx, //开启最大化最小化按钮
   area: [wx, hx],
   content: surl //这里content是一个URL,如果你不想让iframe出现滚动条,你还可以content: ['http://sentsin.com', 'no']
  });
  umd5=surl.MD5();
  eval("sessionStorage.l"+umd5+"="+layidx+";");
  }
function intourl(turl){
 var furl=window.decodeURIComponent(location.href);
 var dmn=window.location.host;
 localStorage.setItem("preurl",furl) ;
 localStorage.setItem("pretitle",document.title) ;
 ptit=turl.split("{");
 totp=ptit.length;
 for (i=1;i<totp;i++){
   inx=qian(ptit[i],"}");
   xxx=qian(inx,"-");
   yyy=hou(inx,"-");
   zzz="";
   if (xxx="get"){
  eval("zzz=GetRequest()."+yyy);
   }
  if (zzz!=undefined){
   turl=turl.replace("{"+inx+"}",zzz);
  }else{
   turl=turl.replace("{"+inx+"}","");
  }
 }
 ptit=turl.split("\[");
 totp=ptit.length;
 for (i=1;i<totp;i++){
   inx=qian(ptit[i],"\]");
   xxx=qian(inx,"-");
   yyy=hou(inx,"-");
   zzz="";
   if (xxx="get"){
  eval("zzz=GetRequest()."+yyy);
   }
  if (zzz!=undefined){
   turl=turl.replace("\["+inx+"\]",zzz);
  }else{
   turl=turl.replace("\["+inx+"\]","");
  }
 }
 stid=GetRequest().stid;
 if (stid!=undefined){
   stid=qian(stid,"-");
 }else{
   stid="";
 }
 turl=turl.replace(/\[shortid\]/g,stid);
 location.href=turl;
}


function totb(){
 tbnm=$('table[name="tabunit"]').attr("tbname");
 if (dftval(GetRequest().dbnm,"")==""){
   openwin("编辑"+tbnm+"表格","/localxres/funx/anyjsshort/?stid=2qPIqS-sfile:anyjsshort.php-&pnum=150:"+tbnm+"&page=1:TABLE_NAME",1746,806);
 }else{
   openwin("编辑数据库"+tbnm+"表格","/localxres/funx/anyjsshort/?stid=2qP7P4-&tabnm="+tbnm+"&page=1&schm="+dftval(GetRequest().dbnm,""),1746,806);  
 }
}
function uptb(){
 stid=GetRequest().stid;
 if (stid.indexOf("-")>0){
  stid=qian(stid,"-");
 }
 if (dftval(GetRequest().dbnm,"")==""){
    openwin("编辑短数据表格"+stid,"/localxres/funx/anyjsshort/?datatype=html&stid=keydz-sfile:anyjsshort.php-&pnum=150:"+stid+"&page=1:shortid",1846,806);
 }else{
    openwin("编辑数据库短数据表格"+stid,"/localxres/funx/anyjsshort/?datatype=html&stid=keydLk5-sfile:anyjsshort.php-&pnum=150:"+stid+"&page=1:shortid&schm="+dftval(GetRequest().dbnm,""),1846,806);
 }
}
function toxy(){
 tbnm=$('table[name="tabunit"]').attr("tbname");
 if (dftval(GetRequest().dbnm,"")==""){
   openwin("编辑表格响应方法","/localxres/funx/anyjsshort/?stid=EtRhCo-sfile:anyjsshort.php-&lang=&pnum=150:"+tbnm+"&page=1:TABLE_NAME&sqc=3",1846,806);
 }else{
   openwin("编辑表格响应方法","/localxres/funx/anyjsshort/?stid=EtRsE7-sfile:anyjsshort.php-&lang=&pnum=150:"+tbnm+"&page=1:TABLE_NAME&sqc=3&schm="+dftval(GetRequest().dbnm,""),1846,806);  
 }
}
function tozs(){
 tbnm=$('table[name="tabunit"]').attr("tbname");
 if (dftval(GetRequest().dbnm,"")==""){
   openwin("编辑此表格列表展示方法","/localxres/funx/anyjsshort/?&stid=pMoPka-sfile:anyjsshort.php-&pnum=150:"+tbnm+"&lang=&page=1:TABLE_NAME&sqc=0",1846,806);
 }else{
   openwin("编辑此表格列表展示方法","/localxres/funx/anyjsshort/?&stid=pMoJlF-sfile:anyjsshort.php-&pnum=150:"+tbnm+"&lang=&page=1:TABLE_NAME&sqc=0&schm="+dftval(GetRequest().dbnm,""),1846,806);
 }
}
function topmt(){
 appid=GetRequest().appid;
 openwin("编辑此应用相关用户权限"+appid,"/localxres/funx/anyjsshort/?stid=pmissps-sfile:anyjsshort.php-pnum:150-&page=1:appid&pnum=30:"+appid+"",1846,806);
}
function tofun(){
 appid=GetRequest().appid;
 bkfun=F('getfunbyappid','appid='+appid,'');
 openwin("编辑此应用涉及方法-"+appid,"/localxres/funx/anyjsshort/?stid=appfuns-sfile:anyjsshort.php-pnum:150-&funs="+bkfun+"",1846,806);
}
function killsave(tbnmx,snox){
  if (tbnmx!="" && snox!="" ){
    if (sessionStorage.locallist==1){
      xz=UY("delete from "+tbnmx+" where SNO='"+snox+"'"); 
      x=localitem();
   }else{
      z=ajaxhtmlpost("/localxres/funx/dataprocess/?stid="+dftval(qian(GetRequest().stid,"-"),"")+"&ptype=del","SNO="+snox);
      y=eval('('+z+')');
    if (intval(y.status)=="1"){
       $("tr[snox='"+snox+"']").hide();
    }else{
       return pagenotify("0","删除记录失败",y.msg);
    }
   }
 return "1";
  }else{
 return "0";
  }
}


function localitem(){  
  sessionStorage.locallist=1;
  stid=GetRequest().stid;
  xtid=qian(stid,"-");
  lhtm=localshort(xtid,"","");
 $("form").html(lhtm);
}
function isnx(strx){
  if (strx*1>-1){
  return true;
   }else{
  return false;
   }
}

function qajaxp(ttt,aurl,adata){
  sessionStorage.renderstart=intval(sessionStorage.renderstart)+1;
     if (aurl.indexOf("anyrcv.php")>0 && aurl.indexOf("SNO=")>0){
         snox=qian(hou(aurl,"SNO="),"\&");
         $("#upd"+snox).attr("src","/sysdisk/pubimgs/controller/wGsdqO.gif");
      }
	  $.ajax({
			url:encodeURI(aurl),
			data:adata,
			type:'POST',
			dataType:"json",
			async : true, //true 异步 
			success: function(data){
			  sessionStorage.renderstart=intval(sessionStorage.renderstart)-1;
			  if (intval(data.status)==1){
                  z=pagenotify("1",ttt,data.msg);
                   if (aurl.indexOf("anyrcv.php")>0 && aurl.indexOf("SNO=")>0){
                         $("#upd"+snox).attr("src","/localxres/iconsetx/pagecontrol/sureatoc.svg");
                         //stid=GetRequest().stid;
                         //if (stid!=undefined){
                           // sid=qian(stid,"-");
                            //if (intval(sessionStorage.renderstart)<=0){
                            //  window.location.reload();
                            //}
                         // }
                    }
               }else{
                  $("#upd"+snox).attr("src","/localxres/iconsetx/pagecontrol/shanchu0.svg");
                  z=pagenotify("0",ttt,data.msg);
               };
			}
		});	
}		
function qajaxps(ttt,aurl,adata){
  sessionStorage.renderstart=intval(sessionStorage.renderstart)+1;
     if (aurl.indexOf("anyrcv.php")>0 && aurl.indexOf("SNO=")>0){
         snox=qian(hou(aurl,"SNO="),"\&");
         $("#upd"+snox).attr("src","/sysdisk/pubimgs/controller/wGsdqO.gif");
      }
	  $.ajax({
			url:encodeURI(aurl),
			data:adata,
			type:'POST',
			dataType:"json",
			async : true, //true 异步 
			success: function(data){
			  sessionStorage.renderstart=intval(sessionStorage.renderstart)-1;
			  if (intval(data.status)==1){
                  z=pagenotify("1",ttt,data.msg);
                   if (aurl.indexOf("anyrcv.php")>0 && aurl.indexOf("SNO=")>0){
                         $("#upd"+snox).attr("src","/localxres/iconsetx/pagecontrol/sureatoc.svg");
                         //stid=GetRequest().stid;
                        // if (stid!=undefined){
                         //   sid=qian(stid,"-");
                          //  if (intval(sessionStorage.renderstart)<=0){
                              window.location.reload();
                        //    }
                         // }
                    }
               }else{
                  $("#upd"+snox).attr("src","/localxres/iconsetx/pagecontrol/shanchu0.svg");
                  z=pagenotify("0",ttt,data.msg);
               };
			}
		});	
}	

function ajaxposthtml(urlx,evalfun){
$.ajax({
  type: "POST",
  async : true, //默认为true 异步 
  url: encodeURI(urlx),
  dataType:"html",
  success: function(data){  
   eval(evalfun); 
   console.log(urlx+"..is..ifnished!");
  } 
  });  
  }
  function ajaxpostgo(urlx,adata,evalfun){
 $.ajax({
   type: "POST",
   async : true, //默认为true 异步 
   url: encodeURI(urlx),
   data: adata,   
   dataType:"html",
   success: function(data){  
    if (evalfun!=""){
       eval(evalfun); 
    }
    datax=eval('('+data+')');
    if (intval(datax.status)==1){
        if (datax.redirect!=""){
            location.href=datax.redirect;
        }else{
            window.location.reload();
        }
    }else{
        console.log("urlx-"+urlx+"-执行失败");
    }
   return true;
   } 
   });  
  }
function ajaxhtmlpost(aurl,adata){
  returnValue='';
      $.ajax({
			url:encodeURI(aurl),
			data:adata,
   async:false,
			type:'POST',
			dataType:"html",
			success:function(data){
            returnValue=data;
			}
   });
  return returnValue;
 }
 function ajaxheadpost(aurl,adata,hk,hv){
  returnValue='';
		$.ajax({
			url:encodeURI(aurl),
			data:adata,
   async:false,
			type:'POST',
			dataType:"html",
			beforeSend: function(request) {
   request.setRequestHeader(hk, hv);
   },
			success:function(data){
  returnValue=data;
			}
   });
  return returnValue;
 }
 function textform(){
  tot=0;   
   for (i=1;i<10;i++){
  if($("#LAY_layedit_"+i).attr("textarea")!=undefined){ 
   teid=$("#LAY_layedit_"+i).attr("textarea");
  //ifr_window=window.parent.frames["LAY_layedit_"+i];
  //console.log($(document.getElementById('LAY_layedit_1').contentWindow.document.body).html())
  //ifr_window.document.body.innerHTML  oldstringcode
   bodhtml=$(document.getElementById('LAY_layedit_'+i).contentWindow.document.body).html();
   $("#"+teid).html(bodhtml);   
  tot=tot+1;
  };
   }
   return tot;
 }
 function _get(gkx){
   grst="";
   if (gkx=="" || gkx==undefined || strlen(gkx)>=15 || strpos(gkx,">")>0 ||  strpos(gkx,"=")>0 || strpos(gkx,"<")>0){
  return "";
   }else{
   eval("grst=GetRequest()."+gkx+";");
 if (grst!="" && grst!=undefined){
  return grst+"";
 }else{
   return "";  
 }
   }
 }

 function getknm(kvs,kxx){
 var xkeys=kvs.keys;
 var ptkx=xkeys.split(",");
 var totptk=ptkx.length;
 var ktpx=kvs.ktps;
 var totkt=ktpx.length;
 var ktt="";
 if (totkt>0){
   for (p=0;p<totkt;p++){
   if (ktpx[p].keyname==kxx){
  var ktt=ktpx[p].typetitle;
   }  
   }
  return ktt;
 }else{
   return "";
 }   
 }
function getkcnm(kvs,kxx,kvv){
 var xkeys=kvs.keys;
 var ptkx=xkeys.split(",");
 var totptk=ptkx.length;
 var ktpx=kvs.ktps;
 var totkt=ktpx.length;
 var ktxt="";
 var knm="";
 if (totkt>0){
  for (p=0;p<totkt;p++){
  if (ktpx[p].keyname==kxx){
  var ktxt=ktpx[p].clstxt;
  }  
  }
  if (ktxt==""){
  knm="";
  }else{
   var qqq=qian(ktxt,"|");
   var hhh=hou(ktxt,"|");
   var ptq=qqq.split(",");
   var pth=hhh.split(",");
   var totptq=ptq.length;
   for (q=0;q<totptq;q++){
   if (pth[q]==kvv){
   knm=ptq[q];
   }//if
   }//for  
  }
   return knm;
 }else{
   return "";
 }   
}
function tabledft(tbnm){
   eval("frmtp=typeof(TBFRM"+tbnm+");");
   if (frmtp=="undefined"){
  x=newjsfile("/localxres/funx/tabcol&tablename="+tbnm+"&rnd="+Math.random());
  return true;
   }else{
  return false;
   }  
}
function shortdft(stid){
   stid=qian(stid,"-");
   eval("frmtp=typeof(STDFT"+stid+");");
   if (frmtp=="undefined"){
  x=newjsfile("/localxres/funx/shortdft&shortid="+stid+"&rnd="+Math.random());
  return true;
   }else{
  return false;
   }  
}

function strpos(strx,strsub){
  if (strx!="" && strx!=undefined && strsub!="" && strsub!=undefined){
 return strx.indexOf(strsub);
  }else{
 return -1;
  }
}
function countresult(fullresult)
 {  
  partkn=explode("#/#",fullresult);
  countkn=countx(partkn);
  return countkn-2;
 }
function isx1(brst,frst){
  if (strpos("xx-"+brst,frst)>0){
 return true;
  }else{
 return false;
  }
}
function iso1(brst,frst,isxy){
  if (isxy==true){
 if (strpos("xx-"+brst,frst)>0){
   return true;
 }else{
   return false;
   }
  }else{
 return false;
  }
}
function isx2($brst,$frst,$trst){
  if (strpos("xx-"+$brst,$frst)>0 && strpos("xx-"+$brst,$trst)>0){
 return true;
  }else{
 return false;
  }
}
function iso2($brst,$frst,$trst){
  if (strpos("xx-"+$brst,$frst)>0 || strpos("xx-"+$brst,$trst)>0){
 return true;
  }else{
 return false;
  }
}
function isx3($brst,$frst,$trst,$thrst){
  if (strpos("xx-"+$brst,$frst)>0 && strpos("xx-"+$brst,$trst)>0 && strpos("xx-"+$brst,$thrst)>0){
 return true;
  }else{
 return false;
  }
}
function iso3($brst,$frst,$trst,$thrst){
  if (strpos("xx-"+$brst,$frst)>0 || strpos("xx-"+$brst,$trst)>0 || strpos("xx-"+$brst,$thrst)>0){
 return true;
  }else{
 return false;
  }
}
function substr(strstrstr,sts,lens){
  if (strstrstr!=undefined){
  return strstrstr.substr(sts,lens);
  }else{
  return "";
  }
}
function str_replace(oldstr,newstr,rplst){
  if (rplst==undefined){
   return "";
  }else{
   rtnstr="";
   if (oldstr!="" && oldstr!=undefined && newstr!=undefined && rplst!="" && rplst!=undefined){
   oldstr=turncon(oldstr);
   oldstr=oldstr.replace(/\r\n/g,'-r-n');
   oldstr=oldstr.replace(/\'/g,'@---@');
   newstr=newstr.toString().replace(/\r\n/g,'-r-n');
   newstr=newstr.replace(/\'/g,'@---@');
 if ((oldstr.indexOf(" ")>0 && oldstr.indexOf("\"")>0) || oldstr.indexOf("/")>0 || oldstr.indexOf("[")>0){
  eval("rtnstr=rplst.replace('"+oldstr+"','"+newstr+"');")
  rtnstr=rtnstr.replace(/@---@/g,"\'");
  rtnstr=rtnstr.replace(/-r-n/g,"\r\n");
  return rtnstr;
 }else{
  eval("rtnstr=rplst.replace(/"+oldstr+"/g,'"+newstr+"');")
  rtnstr=rtnstr.replace(/@---@/g,"\'");
  rtnstr=rtnstr.replace(/-r-n/g,"\r\n");
  return rtnstr;
 }
   }else{
  return rplst;
   }
  }
}
function one_replace(oldstr,newstr,rplst,tms){
 if (rplst!=undefined){
  rtnstr=rplst.replace(oldstr,newstr);
  if (tms>1){
   for (z=1;z<tms;z++){
  rtnstr=rtnstr.replace(oldstr,newstr);
   }
  }
  return rtnstr;
 }else{
  return "";
 }
}
function all_replace(oldstr,newstr,rplst){
 if (rplst!=undefined){
   eval('rtnstr=rplst.replace(/'+oldstr+'/g,newstr);');
   return rtnstr;
 }else{
   return "";
 }
}
function tostring($vlsx){
try{
 if ($vlsx!="" && $vlsx!=undefined && $vlsx!=null){
  if (strpos("x"+$vlsx,"TYPE_HEX:")>0){
      $houvlx=hex2a(hou(hou($vlsx,"TYPE_HEX:"),"TYPE_HEX:"));
   if (strpos("x"+$houvlx,"TYPE_HEX:")>0){
     $houvlx=hex2a(hou(hou($houvlx,"TYPE_HEX:"),"TYPE_HEX:"));
   }
     $houvlx=hhth($houvlx);
  }else{   
    $houvlx=hhth($vlsx);
  };
  return $houvlx;
  }else{
   return "";
  }
 }
 catch(err){
  console.log("err-"+err+"vlsx-"+$vlsx);
  return "";
 }
}
 function instance($mstr){
   $mstr=str_replace("{","<",$mstr);
   $mstr=str_replace("}",">",$mstr);
   $mstr=$mstr.replace(/\[/g,"{");
   $mstr=$mstr.replace(/\]/g,"}");
   return $mstr;
 }
function shortinfo(stid){
 $stbase=new Array();
 stid=qian(stid,"-");
 eval("frmtp=typeof(STDFT"+stid+");");
if (frmtp=="undefined"){
  return $stbase;
}else{
 stid=qian(stid,"-");   
  eval("tmpst=STDFT"+stid+";");
  $stbase["shortid"]=stid;
  $stbase["tablename"]=tmpst.vls[0].tablename;
  $stbase["showkeys"]=tostring(tmpst.vls[0].showkeys);
  if (strpos("XX"+$stbase["showkeys"],"SNO,")>0){
   if (substr($stbase["showkeys"],0,3)!="SNO"){
    $stbase["showkeys"]="SNO,"+one_replace("SNO,","",$stbase["showkeys"],3);
   };
  }else{
    $stbase["showkeys"]="SNO,"+$stbase["showkeys"];
  }
  
  $stbase["cdt"]=tostring(tmpst.vls[0].cdt);
  $stbase["orddt"]=tostring(tmpst.vls[0].orddt);
  $stbase["caseid"]=tostring(tmpst.vls[0].caseid);
  $stbase["pageid"]=tostring(tmpst.vls[0].lang);
  $stbase["dttp"]=tostring(tmpst.vls[0].dttp);  
  $stbase["addpage"]=tostring(tmpst.vls[0].addpage);
  $stbase["addtitle"]=tostring(tmpst.vls[0].addtitle);
  $stbase["shorttitle"]=tostring(tmpst.vls[0].shorttitle);
  $stbase["updatepage"]=tostring(tmpst.vls[0].updatepage);
  $stbase["detailpage"]=tostring(tmpst.vls[0].detailpage);
  $stbase["additemx"]=tmpst.vls[0].additemx*1;
  $stbase["newbutton"]=tmpst.vls[0].newbutton*1;
  $stbase["obtn"]=tmpst.vls[0].obtn*1;
  $stbase["vbtn"]=tmpst.vls[0].vbtn*1;
  $stbase["xbtn"]=tmpst.vls[0].xbtn*1;
  $stbase["oprtx"]=tmpst.vls[0].oprtx*1;
  $stbase["diycode"]=instance(tostring(tmpst.vls[0].diycode));
  $stbase["headx"]=instance(tostring(tmpst.vls[0].headx));
  $stbase["diytop"]=instance(tostring(tmpst.vls[0].diytop));
  $stbase["diybottom"]=instance(tostring(tmpst.vls[0].diybottom));  
  $stbase["topbtn"]=tostring(tmpst.vls[0].topbtn)*1;
  $stbase["bottombtn"]=tostring(tmpst.vls[0].bottombtn)*1;
  $stbase["tbhd"]=tostring(tmpst.vls[0].tbhd)*1;
  $stbase["sps"]=tostring(tmpst.vls[0].sps)*1;
  $stbase["dtx"]=tostring(tmpst.vls[0].dtx)*1;
  $stbase["ctraw"]=tostring(tmpst.vls[0].ctraw)*1;
  $stbase["allkillbtn"]=tostring(tmpst.vls[0].allkillbtn)*1;  
  return $stbase;
 }
  
}
function jsontosx(jsonx){
  if (jsonx.keys!=undefined){
  akeys=jsonx.keys;
  totrcd=jsonx.totrcd;
  ptak=explode(",",akeys);
  totp=countx(ptak);
  fmx="";
   if (jsonx.vls.length>0 && totrcd!="" && intval(totrcd)!=0){
  fmx=fmx+akeys.replace(/,/g,"#-#")+"#/#";
 for (j=0;j<jsonx.vls.length;j++){   
  for (i=0;i<totp;i++){
  tmpv="";
  if (strpos(ptak[i],"clstxt")>0){
   tmpmd5="";
   eval("tmpmd5=jsonx.vls["+j+"]."+ptak[i]+";");
   if (tmpmd5!=""){
     eval("tmpv=tostring("+"jsonx.md5txt."+tmpmd5+");");
   if (tmpv!=undefined && tmpv!=""){
   }else{
     eval("tmpv=tostring("+"jsonx.vls["+j+"]."+ptak[i]+");");
   }
   }else{
     eval("tmpv=tostring("+"jsonx.vls["+j+"]."+ptak[i]+");");
   }
  }else{
     eval("tmpv=tostring("+"jsonx.vls["+j+"]."+ptak[i]+");");
  }
    fmx=fmx+tmpv.replace(/\\"/g,'"')+"#-#";
  }
   fmx=killlast3(fmx)+"#/#";
 }
    return fmx;//有记录的
   }else{
    return akeys.replace(/,/g,"#-#")+"#/#";//无记录
   }
  }else{
  return "";
  }
}
function arrdata(selerst){
tbrst=new Array();
tmpkies=qian(selerst,"#/#");
tmpkiep=tmpkies.split("#-#");
totpx=tmpkiep.length;
tmpvalrp=selerst.split("#/#")
tottbrst=tmpvalrp.length-1;
 for (ix=0;ix<totpx;ix++){
   tbrst[tmpkiep[ix]]=new Array();
   tbrst[tmpkiep[ix]][tottbrst]=0;  
   tbrst[tmpkiep[ix]][0]=tmpkies;  
 }  
 for (jx=1;jx<tottbrst;jx++){ //因为第一行是KEYS所以数量不变如果不存在他就是0-N   
   for (ix=0;ix<totpx;ix++){
     tmpvalrx=tmpvalrp[jx].split("#-#");  
     if (tmpvalrx[ix].indexOf("TYPE_HEX")>0){
       tbrst[tmpkiep[ix]][jx]=tostring(tmpvalrx[ix]);   
     }else{
       tbrst[tmpkiep[ix]][jx]=tmpvalrx[ix];   
     }
     if (tmpvalrx[ix]*1>0 || tmpvalrx[ix]*1<0){
      tbrst[tmpkiep[ix]][tottbrst]=tbrst[tmpkiep[ix]][tottbrst]+(tmpvalrx[ix]*1);
     }else{
       tbrst[tmpkiep[ix]][tottbrst]=tbrst[tmpkiep[ix]][tottbrst]+0;
     }
   };   
  };
   return tbrst;
}

function TX(sqlstr){  
  if (sqlstr.indexOf("elect ")>0 && sqlstr.indexOf(" from ")>0){
  skeys=qian(hou(sqlstr,"elect ")," from "); 
  tbnm=qian(hou(sqlstr," from ")," where ");
  cdts=hou(sqlstr," where ");
  stype="select";
 skeys=skeys.replace(/ /g,"");
 tmptx={"skeys":skeys,"tbnm":tbnm,"cdts":cdts,"stype":"select"};
   }
   if (sqlstr.indexOf("elete ")>0 && sqlstr.indexOf(" from ")>0){  
  tbnm=qian(hou(sqlstr," from ")," where ");
  cdts=hou(sqlstr," where ");
  stype="delete";  
  tmptx={"skeys":"","tbnm":tbnm,"cdts":cdts,"stype":"select"};
   }
   if (sqlstr.indexOf("nsert ")>0 && sqlstr.indexOf(" into ")>0){  
  tbnm=qian(hou(sqlstr," into "),"(");
  skeys=qian(hou(sqlstr,"("),")");
  vals=hou(sqlstr,"values");
  vals=killfirsttring(vals);
  vals=killlasttring(vals);
  vals=vals.replace(/'/g,"");
  stype="insert";
  skeys=skeys.replace(/ /g,"");
  tmptx={"skeys":skeys,"tbnm":tbnm,"cdts":vals,"stype":"insert"};
   }
   if (sqlstr.indexOf("pdate ")>0 && sqlstr.indexOf(" set ")>0){
  skvs=qian(hou(sqlstr," set ")," where ");
  skvs=skvs.replace(/'/g,"");
  tbnm=qian(hou(sqlstr,"update ")," set ");
  cdts=hou(sqlstr," where ");
  stype="update";
  tmptx={"skeys":"","tbnm":tbnm,"cdts":cdts,"stype":"update","sets":skvs};
   }
  return tmptx;
}
function UY(sqlstr){  
 if (sqlstr!=""){
   skeys="";
   if (sqlstr.indexOf("elect ")>0 && sqlstr.indexOf(" from ")>0){
  if (strpos(sqlstr," where ")==-1){
  sqlstr=sqlstr+" where ";
  }
  skeys=qian(hou(sqlstr,"elect ")," from ");
  tbnm=qian(hou(sqlstr," from ")," where ");
  cdts=hou(sqlstr," where ");
  stype="select";
   }
   if (sqlstr.indexOf("elete ")>0 && sqlstr.indexOf(" from ")>0){  
  if (strpos(sqlstr," where ")==-1){
  sqlstr=sqlstr+" where ";
  }
  tbnm=qian(hou(sqlstr," from ")," where ");
  cdts=hou(sqlstr," where ");
  stype="delete";
   }
   if (sqlstr.indexOf("nsert ")>0 && sqlstr.indexOf(" into ")>0){  
  //console.log("s-"+sqlstr);
  tbnm=qian(hou(sqlstr," into "),"(");
  skeys=qian(hou(sqlstr,"("),")");
  vals=hou(sqlstr,"values");
  vals=killfirsttring(vals);
  vals=killlasttring(vals);  
  stype="insert";
   }
   if (sqlstr.indexOf("pdate ")>0 && sqlstr.indexOf(" set ")>0){
  if (strpos(sqlstr," where ")==-1){
  sqlstr=sqlstr+" where ";
  }
  skvs=qian(hou(sqlstr," set ")," where ");
  tbnm=qian(hou(sqlstr,"pdate")," set ");
  if (sqlstr.indexOf(" where ")>0){
  cdts=hou(sqlstr," where ");
  }else{
  cdts="";
  }
  stype="update";
   }
   skeys=skeys.replace(/ /g,"");
   tbnm=tbnm.replace(/ /g,"");
   eval("frmtp=typeof(TBFRM"+tbnm+");");
   if (frmtp=="undefined"){
  x=newjsfile("/localxres/funx/tabcol&tablename="+tbnm);
   }
   switch(stype){
  case "select":
  eval (tbnm+"txt=localStorage."+tbnm);
  eval (tbnm+"=eval('('+"+tbnm+"txt+')')");  
  eval("tbtp=typeof("+tbnm+");");
  if (tbtp=="undefined" || extkeys(skeys,tbnm)==false){
  return [];
  }else{
   eval ("tmptable="+tbnm+";");  
   sltable=[];
   sltable=selectx(cdts,tmptable,tbnm);
   tmpvl="";   
   switch(skeys){
   case "count(*)":
   return sltable.length;
   break;
   default:
   if (sltable.length>0){
  eval("tmpvl=sltable[0]."+skeys+";");
  return tmpvl;  
   }
   }
  }  
  break;
  case "delete":
  eval (tbnm+"txt=localStorage."+tbnm);
  eval (tbnm+"=eval('('+"+tbnm+"txt+')')");
  eval("tbtp=typeof("+tbnm+");");
  if (tbtp=="undefined" || extkeys(skeys,tbnm)==false){  
   sltable=[];
   eval ("localStorage."+tbnm+"=JSON.stringify(sltable, null, 2)");
  }else{
   eval ("tmptable="+tbnm+";");  
   sltable=[];
   sltable=deletex(cdts,tmptable,tbnm);  
   eval ("localStorage."+tbnm+"=JSON.stringify(sltable, null, 2)");
  }
  return sltable;
  break;
  case "insert":
  tbtp="";
  eval (tbnm+"txt=localStorage."+tbnm);
  eval (tbnm+"=eval('('+"+tbnm+"txt+')')");
  eval("tbtp=typeof("+tbnm+");");
  if (tbtp=="undefined"){
   eval(tbnm+"=[]");   
  }else{
  }
   if (extkeys(skeys,tbnm)==false){
  eval("tmptb="+tbnm+";");
  return tmptb;
   }else{
  ptskey=skeys.split(",");
  ptsval=vals.split(",");
  totpt=ptskey.length;
  eval("extpush=extdftval(skeys,TBFRM"+tbnm+")");
  fmpush="";
  for (i=0;i<totpt;i++){
   fmpush=fmpush+"\""+ptskey[i]+"\":\""+killquote(ptsval[i])+"\",";
  }
   if (extpush!=""){
   extpush=killlasttring(extpush);
   }
  fmpush=fmpush+extpush;
  fmpush="{"+fmpush+"}";
  eval (tbnm+".push("+fmpush+")");
  eval("tmptb="+tbnm+";");
  eval ("localStorage."+tbnm+"=JSON.stringify("+tbnm+", null, 2)");
  return tmptb;
  }
  break;
  case "update":
  tbtp="";  
  //console.log("tbnm-"+tbnm+"-skvs-"+skvs+"cdts-"+cdts);
  eval ("xtxt=localStorage."+tbnm+";");
  //console.log("xtxt=localStorage."+tbnm+";");
  //console.log("xtxt-"+xtxt);
  eval ("tmptable=eval('('+xtxt+')');");
  tbtp=typeof(tmptable);  
  //console.log("tbtp-"+tbtp);
  if (tbtp=="undefined"){
  return [];
  }else{
   sltable=updatex(cdts,tmptable,tbnm,skvs);
   eval ("localStorage."+tbnm+"=JSON.stringify(sltable, null, 2)");
   return sltable;
  }
  break;
   }
  }
}
function killquote(xstr){
  if (substr(xstr,0,1)=="'"){
 tmpx=substr(xstr,1,strlen(xstr)-2);
 tmpx=str_replace("undefined","",tmpx);
 return tmpx;
  }else{
 tmpx=str_replace("undefined","",xstr);
 return tmpx;
  }
}
function extkeys(skx,tbnm){
  eval ("tmpfrm=TBFRM"+tbnm+";");
  if (typeof(tmpfrm)!="undefined"){
 k=1;
 for (i=0;i<tmpfrm.length;i++){
   kkk="x,"+skx+",";
   if (kkk.indexOf(","+tmpfrm.vls[i].COLUMN_NAME+",")>0){
   }else{
  k=k*0;
   }
 }
  }else{
 k=0;
  }
  if (k==1){
 return true;
  }else{
 return false;
  }  
}
function deletex(cdty,tbdata,tbnmy){
 z=0;
 etxt="if ([tbcdts]){z〓1;}else{z〓0;};";
 if (cdty==""){
   cdty=" 1>0 ";
 }
 etxt=etxt.replace("[tbcdts]",cdty);
 xtxt=cdty;
 etxt=etxt.replace(/=/g,"==");
 xtxt=xtxt.replace(/=/g,"==");
 etxt=etxt.replace(/〓/g,"=");
 xtxt=xtxt.replace(/〓/g,"=");
 etxt=etxt.replace(" and "," && ");
 xtxt=xtxt.replace(" and "," && ");
 etxt=etxt.replace(" or "," || "); 
 xtxt=xtxt.replace(" or "," || "); 
 eval("tmpfrm=TBFRM"+tbnmy+";");
   tmps=[];
   if (cdty.replace(/ /,"")==""){
  return [];
   }else{
 for (i=0;i<tbdata.length;i++){
   z=0;
   detxt=etxt;
   for (j=0;j<tmpfrm.totrcd;j++){
  detxt=detxt.replace(tmpfrm.vls[j].COLUMN_NAME,"tbdata[i]."+tmpfrm.vls[j].COLUMN_NAME);
   }
  if (detxt.indexOf("order")>0){
  eval(qian(detxt,"order")+")"+hou(detxt,")"));
  }else{
  eval(detxt);
  }
  if (z==1){  
  }else{
  tmps.push(tbdata[i]);
  }
  }
  return tmps;
   }
  
}
function updatex(cdty,tbdata,tbnmy,sets){
 z=0;
 etxt="if ([tbcdts]){z〓1;}else{z〓0;};";
 if (cdty==""){
   cdty=" 1>0 ";
 }
 etxt=etxt.replace("[tbcdts]",cdty);
 xtxt=cdty;
 etxt=etxt.replace(/=/g,"==");
 xtxt=xtxt.replace(/=/g,"==");
 etxt=etxt.replace(/〓/g,"=");
 xtxt=xtxt.replace(/〓/g,"=");
 etxt=etxt.replace(" and "," && ");
 xtxt=xtxt.replace(" and "," && ");
 etxt=etxt.replace(" or "," || "); 
 xtxt=xtxt.replace(" or "," || ");   
 eval("tmpfrm=TBFRM"+tbnmy+";");  
 for (j=0;j<tmpfrm.totrcd;j++){
   sets=sets.replace(tmpfrm.vls[j].COLUMN_NAME,"tbdata[i]."+tmpfrm.vls[j].COLUMN_NAME);
 }  
 sets=sets+";";
   tmps=[];
 if (cdty.replace(/ /,"")==""){
 for (i=0;i<tbdata.length;i++){   
   eval(sets);   
 }
   return tbdata;
 }else{
   for (i=0;i<tbdata.length;i++){
   z=0;
   detxt=etxt;
   for (j=0;j<tmpfrm.totrcd;j++){
  detxt=detxt.replace(tmpfrm.vls[j].COLUMN_NAME,"tbdata[i]."+tmpfrm.vls[j].COLUMN_NAME);
   }
  if (detxt.indexOf("order")>0){
  eval(qian(detxt,"order")+")"+hou(detxt,")"));
  }else{
  eval(detxt);
  }
  if (z==1){
  eval(sets);
  }else{
  }
 }
   return tbdata;
 }
  
 }
function selectx(cdty,tbdata,tbnmy){
 z=0;
 etxt="if ([tbcdts]){z〓1;}else{z〓0;};";
 if (cdty==""){
   cdty=" 1>0 ";
 }
 etxt=etxt.replace("[tbcdts]",cdty);
 xtxt=cdty;
 etxt=etxt.replace(/=/g,"==");
 xtxt=xtxt.replace(/=/g,"==");
 etxt=etxt.replace(/〓/g,"=");
 xtxt=xtxt.replace(/〓/g,"=");
 etxt=etxt.replace(" and "," && ");
 xtxt=xtxt.replace(" and "," && ");
 etxt=etxt.replace(" or "," || "); 
 xtxt=xtxt.replace(" or "," || "); 
 eval("tmpfrm=TBFRM"+tbnmy+";");
   tmps=[];
  if (cdty.replace(/ /,"")==""){
 return tbdata;
  }else{
   for (i=0;i<tbdata.length;i++){
   z=0;
   detxt=etxt;
   for (j=0;j<tmpfrm.totrcd;j++){
  detxt=detxt.replace(tmpfrm.vls[j].COLUMN_NAME,"tbdata[i]."+tmpfrm.vls[j].COLUMN_NAME);
  xtxt=xtxt.replace(tmpfrm.vls[j].COLUMN_NAME,"tbdata[i]."+tmpfrm.vls[j].COLUMN_NAME);
   }
  
  if (detxt.indexOf("order")>0){
  eval(qian(detxt,"order")+")"+hou(detxt,")"));
  dxtxt=qian(xtxt,"order")+hou(xtxt,")");;
  }else{
  eval(detxt);
  }
  if (z==1){
  tmps.push(tbdata[i]);
  }else{
  }
 }
 return tmps;
  }
 }
function extdftval(sks,frmtb){
  fmek="";
  skkx=",,"+sks;
  for (j=0;j<frmtb.totrcd;j++){
 if (skkx.indexOf(frmtb.vls[j].COLUMN_NAME)>0){
 }else{
   tmpk=frmtb.vls[j].COLUMN_NAME;
 //  console.log("sf-"+frmtb.vls[j].sysshowfun);
   tmdft=tostring(frmtb.vls[j].sysshowfun);
   tmdft=tostring(tmdft);
   if (tmdft==""){
  if (frmtb.vls[j].COLUMN_NAME=="SNO"){
   fmek=fmek+"\""+frmtb.vls[j].COLUMN_NAME+"\":\""+randomWord(false,5)+"\",";
   }else{
   fmek=fmek+"\""+frmtb.vls[j].COLUMN_NAME+"\":\"\",";
   }
   }else{
   dftv=hou("x"+tmdft,"|");  
   //  console.log("dftv="+dftv);   
   $thusvalue="";
   eval(dftv);
   if ($thusvalue==undefined){
   $thusvalue="";
  }
  //switch  
   fmek=fmek+"\""+frmtb.vls[j].COLUMN_NAME+"\":\""+$thusvalue+"\",";
   }
 }
  }
  return fmek;
}
function UX($asqlstr){
  $conn=mysql_connect(gl(),glu(),glp());
  return updatings($conn,glb(),$asqlstr,"utf8");
}
function SX($asqlstr){
  $conn=mysql_connect(gl(),glu(),glp());
  return selecteds($conn,glb(),$asqlstr,"utf8","");
}
function SY(sqlstr){
 if (sqlstr.indexOf(" where")>0){
 }else{
   sqlstr=sqlstr+" where 1>0 ";
 }
  //console.log("sqlstr-"+sqlstr);
 if (sqlstr!=""){
   if (sqlstr.indexOf("elect ")>0 && sqlstr.indexOf(" from ")>0){
  skeys=qian(hou(sqlstr,"elect ")," from ");
  tbnm=qian(hou(sqlstr," from ")," where ");
  if (sqlstr.indexOf(" where ")>0){
  cdts=hou(sqlstr," where ");
  }else{
  cdts="";
  }
  tbnm=tbnm.replace(/ /g,"");
  skeys=skeys.replace(/ /g,"");
   }
 eval("frmtp=typeof(TBFRM"+tbnm+");");
 if (frmtp=="undefined"){
   x=newjsfile("/localxres/funx/tabcol&tablename="+tbnm);
 }   
  eval (tbnm+"txt=localStorage."+tbnm);
  eval (tbnm+"=eval('('+"+tbnm+"txt+')')");  
  eval("tbtp=typeof("+tbnm+");");
  if (tbtp=="undefined"){
  return [];
  }else{
   eval ("tmptable="+tbnm+";");  
   sltable=[];
   //console.log("cdts-"+cdts);
   sltable=selectx(cdts,tmptable,tbnm);
  }
  return sltable;
  }
}
function fmsx(tbnm,tkeys,stable){
  fmx="";
  if (tkeys=="*"){
 eval("tkeys="+tbnm+"akb[\"COLUMN\"][\"ALLKEY\"];"); 
  }else{   
  }
  ptk=tkeys.split(",");
  for (j=0;j<stable.length;j++){
 fmy="";
 for (i=0;i<ptk.length;i++){
  eval("fmy=fmy+stable[j]."+ptk[i]+"+',';");
 }
 fmy=killlasttring(fmy);
 fmy=fmy.replace(/,/g,"#-#");
 fmx=fmx+fmy+";";
  } 
  fmx=fmx.replace(/;/g,"#/#");
  tkeys=tkeys.replace(/,/g,"#-#");
  return tkeys+"#/#"+fmx;
}
function anyvalue(fullresult,keynm,sqc)
{
  keyname=qian(fullresult,"#/#");
  partkn=keyname.split("#-#");
  partresult=fullresult.split("#/#");
  countprs=partresult.length;
  countkn=partkn.length;
  tempkey=0;
  for (x=0;x<=countkn-1;x++)
   {
 if (partkn[x]==keynm)
 {
  tempkey=x;
  };
   };
  sqcresult=partresult[sqc+1];
  partpart=sqcresult.split("#-#");
  return partpart[tempkey];
}

function qian(str,qq){
  tpit=typeof(str);
 if (tpit === 'string'){
  var fpos=str.indexOf(qq);
  if (fpos>0){
 return str.substring(0,fpos);
  }else{
 if (fpos==0){
   return "";
 }else{
   return str;
 }
  };
 }else{
   return "";
 }
}
function hou(str,hh){
  tpit=typeof(str);
   if (tpit === 'string'){
 var fpos=str.indexOf(hh);
 var flen=hh.length;
 var slen=str.length;
 if (fpos>0){
   return str.substring(fpos+flen,slen);
 }else{
   if (fpos==0){
  return "";
   }else{
  return str;
   }
 };
   }else{
   return "";
   }
}
function bMapToQQMap(lng, lat,typex) {
  if (lng == null || lng == '' || lat == null || lat == '')
  return [lng, lat];
  var x_pi = 3.14159265358979324;
  var x = parseFloat(lng) - 0.0065;
  var y = parseFloat(lat) - 0.006;
  var z = Math.sqrt(x * x + y * y) - 0.00002 * Math.sin(y * x_pi);
  var theta = Math.atan2(y, x) - 0.000003 * Math.cos(x * x_pi);
  var lng = (z * Math.cos(theta)).toFixed(7);
  var lat = (z * Math.sin(theta)).toFixed(7);
  if (typex=="lon"){
  return lng;
  }else{
  return lat;
  }
}

function qqMapToBMap(lng, lat,typex) {
  if (lng == null || lng == '' || lat == null || lat == '')
  return [lng, lat];
  var x_pi = 3.14159265358979324;
  var x = parseFloat(lng);
  var y = parseFloat(lat);
  var z = Math.sqrt(x * x + y * y) + 0.00002 * Math.sin(y * x_pi);
  var theta = Math.atan2(y, x) + 0.000003 * Math.cos(x * x_pi);
  var lng = (z * Math.cos(theta) + 0.0065).toFixed(5);
  var lat = (z * Math.sin(theta) + 0.006).toFixed(5);
  if (typex=="lon"){
  return lng;
  }else{
  return lat;
  }
}
function killlastsplit(strx,sx){
  tpit=typeof(strx);
if (tpit === 'string'){
 if (("x"+strx).indexOf(sx)>0){
  ptstrx=strx.split(sx);
  totpart=ptstrx.length;
  fmstrx="";
  for (var kx=0;kx<totpart-1;kx++){
   fmstrx=fmstrx+ptstrx[kx]+sx; 
  };
  return fmstrx;
 }else{
  return "";
 }
}else{
  return "";
}
}
function getlastsplit(strx,sx){
tpit=typeof(strx);
if (tpit === 'string'){
 if (("x"+strx).indexOf(sx)>0){
  ptstrx=strx.split(sx);
  totpart=ptstrx.length;
  return ptstrx[totpart-1];
 }else{
  return "";
 };
}else{
  return "";
}
}
function killlasttring(strx){
  tpit=typeof(strx);
 if (tpit === 'string'){
  if (strx.length>0){
   strx=strx.substring(0,strx.length-1);
  };
  return strx;
 }else{
  return "";
 }
}
function killlast3(strx){
  tpit=typeof(strx);
 if (tpit === 'string'){
  if (strx.length>0){
   strx=strx.substring(0,strx.length-3);
  };
  return strx;
 }else{
  return "";
 }
}
function killfirsttring(strx){
   tpit=typeof(strx);
 if (tpit === 'string'){
   if (strx.length>0){
   strx=strx.substring(1,strx.length-1);
   };
   return strx;
 }else{
   return "";
 }
}
dec2utf8 = function (arr) {
 if (typeof arr === 'string') {
  return arr;
 }

 var unicodeString = '', _arr = arr;
 for (var i = 0; i < _arr.length; i++) {
  var one = _arr[i].toString(2);
  var v = one.match(/^1+?(?=0)/);

  if (v && one.length === 8) {
   var bytesLength = v[0].length;
   var store = _arr[i].toString(2).slice(7 - bytesLength);

   for (var st = 1; st < bytesLength; st++) {
  store += _arr[st + i].toString(2).slice(2)
   }

   unicodeString += String.fromCharCode(parseInt(store, 2));
   i += bytesLength - 1;
  } else {
   unicodeString += String.fromCharCode(_arr[i]);
  }
 }
 return unicodeString
};
function hhth(strx){
  strx=strx.replace(/-r-n/g,'\r\n');
  strx=strx.replace(/-\/-\//g,'\\');
  return strx;
}
function hex2a(hexx) {
 var hex = hexx.toString();//force conversion 
 var str_list = [];
 for (var i = 0; (i < hex.length && hex.substr(i, 2) !== '00'); i += 2)
  str_list.push(parseInt(hex.substr(i, 2), 16)); 
 return dec2utf8(str_list);
}
function a2hex(str){
 if(str === "")
  return "";
  var hexCharCode = [];
  //hexCharCode.push("0x"); 
  for(var i = 0; i < str.length; i++) {
  hexCharCode.push((str.charCodeAt(i)).toString(16));
  }
  return hexCharCode.join("");
  }


function layrender(){
 layui.use('form', function(){
   var form = layui.form;//高版本建议把括号去掉，有的低版本，需要加()
   form.render();
  });
}
 
function mkstr(hstr){
  if (hstr==null || hstr==undefined || hstr=="" || typeof(hstr)=="object"){
     return "";
   }else{
     //console.log(hstr);
    fmtxt=hstr;
    fmtxt=fmtxt.replace(/'/g,"^");
    fmtxt=fmtxt.replace(/&amp;/g,"δ");
    fmtxt=fmtxt.replace(/&/g,"δ");
    fmtxt=fmtxt.replace(/\+/g,"＋");
    fmtxt=fmtxt.replace(/=/g,"＝");
    fmtxt=fmtxt.replace(/\?/g,"？");
    fmtxt=fmtxt.replace(/\\/g,"↘");
   //fmtxt=fmtxt.replace(/\r\n/g,"卍");
    fmtxt=fmtxt.replace(/[\r\n][\r\n]/g,"卍");
    fmtxt=fmtxt.replace(/[\r\n]/g,"卍");   
    fmtxt=fmtxt.replace(/[\n]/g,"卍");   
    return fmtxt;
   };
}

function unstr(strx){
  strx=strx.replace(/-r-n/g,"\r\n");
  strx=strx.replace(/-\/-\//g,"");
  strx=strx.replace(/\\'/g,"'");
  return strx;
}
 
   function topage(url){
 var pghtml=ajaxhtmlpost(url,'');
 $('#content').html(pghtml);
   }
   function page(url){
 location.href=url;
   }
function fmslcthtm(clstext,prev,keynm,clss){
 if (clstext.indexOf('|')>0){
  var nowcls="";
  var nowcls=hou(clss,keynm+":");
  var nowcls=qian(nowcls,";");
  var nowhtml="";
  var nowhtml=hou(clss,keynm+"html:");
  var nowhtml=hex2a(qian(nowhtml,";"));
  return fmselect(qian(clstext,"|"),hou(clstext,"|"),prev,keynm,nowcls,nowhtml);
 };
 if (clstext.indexOf('/')>0){
  var nowcls="";
  var nowcls=hou(clss,keynm+":");
  var nowcls=qian(nowcls,";");
  var nowhtml="";
  var nowhtml=hou(clss,keynm+"html:");
  var nowhtml=hex2a(qian(nowhtml,";"));
  return fmduoselect(qian(clstext,"/"),hou(clstext,"/"),prev,keynm,nowcls,"");
 };
 if (clstext.indexOf('|')<=0 && clstext.indexOf(']')>0){
  var domain = document.domain;
  var nclstxt=ajaxhtmlpost("/localxres/funx/anyshort/?stid="+clstext+"&dttp=clstxt",nowhtml);
  var nowcls="";
  var nowcls=hou(clss,keynm+":");
  var nowcls=qian(nowcls,";");
  var nowhtml="";
  var nowhtml=hou(clss,keynm+"html:");
  var nowhtml=hex2a(qian(nowhtml,";"));
  return fmselect(qian(nclstxt,"|"),hou(nclstxt,"|"),prev,keynm,nowcls,nowhtml);
 };
} 
function getchkvalue(tagnm){
   //获取所有的input标签

   var input = document.getElementsByName(tagnm);
   var str="";

   for (var i = 0; i < input.length; i++){
  var obj = input[i];
  //判断是否是checkbox并且已经选中
  if (obj.type == "checkbox" && obj.checked) 
  {
  var code = obj.value;//获取checkbox的值
  str=str+code+",";
  }
   }
  return str;
  }
  function setchkvalue(tagnm,prev){
   //获取所有的input标签
   var input = $("input[name='"+tagnm+"']");
   var str="";
   for (var i = 0; i < input.length; i++){
  
  //判断是否是checkbox并且已经选中
  if ($(input[i]).val()==prev) 
    {
     $(input[i]).attr("checked","checked");
    }
   }
  return true;
  }
  function setselectval(eid,valx){
   var selectid = document.getElementById(eid);
   for(i=0;i<selectid.length;i++){
    if(selectid[i].value==valx){
      selectid[i].selected = true;
    }
   }
}
function getduovalue(tagnm){
   //获取所有的input标签
   var input = document.getElementsByName(tagnm);
   var str="";
   for (var i = 0; i < input.length; i++){
  var obj = input[i];
  //判断是否是checkbox并且已经选中
  if (obj.checked) 
  {   
  var code = obj.value;
  str=str+code+",";
  }
   }
  return killlasttring(str);
  }
function getduocolumn(colm){
   //获取所有的input标签
   var input = document.getElementsByName("chksno");
   var str="";
   for (var i = 0; i < input.length; i++){
  var obj = input[i];
  //判断是否是checkbox并且已经选中
  if (obj.checked) 
  {   
  var code = obj.value;
  str=str+$("#"+colm+code).html()+",";
  }
   }
  return killlasttring(str);
  }
function putvalue(url,ocls){
var pgdata=ajaxhtmlpost(url,"");
pgo=eval('('+pgdata+')');
var pgk=pgo.ktps;
//alert(pgk);
var pgv=pgo.vls;
var totk=pgk.length;
eval("var sno=pgv[0].SNO");
 for (i=0;i<totk;i++){
   var knm=pgk[i].keyname;
   var newhtml="";
   var tvl="";
   if (knm!=="SNO"){
  if (pgk[i].jshow!==""){
  var newhtml=pgk[i].jshow;
   if (newhtml.indexOf("TYPE_HEX")>0){
  newhtml=hou(newhtml,"TYPE_HEX-");
  newhtml=hou(newhtml,"TYPE_HEX:");
  newhtml=hex2a(newhtml);
   }else{
   };

   eval("var tvl=pgv[0]."+knm+"");
   newhtml=newhtml.replace('[thisvalue]',tvl);
   newhtml=newhtml.replace('[thisvalue]',tvl);
   newhtml=newhtml.replace('[thissno]',pgv[0].SNO);
   newhtml=newhtml.replace('[thissno]',pgv[0].SNO);
   newhtml=newhtml.replace('[thiskey]',knm);
   newhtml=newhtml.replace('[thiskey]',knm);
   newhtml=newhtml.replace('[thisktp]',pgk[i].datatype);
   newhtml=newhtml.replace('[thisktp]',pgk[i].datatype);
   newhtml=newhtml.replace(/{/g,'<');
   newhtml=newhtml.replace(/}/g,'>');

   var pgktxt=pgk[i].clstxt;

   if (pgktxt!==""){

  if (pgktxt.indexOf("TYPE_HEX")>0){
  pgktxt=hou(pgktxt,"TYPE_HEX:");
  pgktxt=hou(pgktxt,"TYPE_HEX-");
  pgktxt=hex2a(pgktxt);

  newhtml=newhtml.replace('[selecthtm]',fmslcthtm(pgktxt,tvl,knm,ocls));
   }else{
  newhtml=newhtml.replace('[selecthtm]',fmslcthtm(pgktxt,tvl,knm,ocls));
   };
   };
  $('#'+knm+sno+'div').html(newhtml);
   var pgktxt="";
   }else{//jshow
  eval("var tvl=pgv[0]."+knm+"");
   var pgktxt=pgk[i].clstxt;
   if (pgktxt!==""){
  if (pgktxt.indexOf("TYPE_HEX")>0){
  pgktxt=hou(pgktxt,"TYPE_HEX:");
  pgktxt=hou(pgktxt,"TYPE_HEX-");
  pgktxt=hex2a(pgktxt);
  newhtml=fmslcthtm(pgktxt,tvl,knm,ocls);
  // alert(pgktxt);
   }else{
  newhtml=fmslcthtm(pgktxt,tvl,knm,ocls);
   //alert(pgktxt);
   };


   $('#'+knm+sno+'div').html(newhtml);
  $("#p_"+knm+sno).attr("selected",true);
  //alert(newhtml);
   }else{
   $('#p_'+knm+sno).val(tvl);
   };
   };//jshow
   };//sno
 };//for

}


function choosebyid(eid,evl){
	$("#"+eid).find("option[value='"+evl+"']").attr("selected",true);
}

function imgsize(image){
  str=image.substring(22); // 1.需要计算文件流大小，首先把头部的data:image/png;base64,（注意有逗号）去掉。
  equalIndex= str.indexOf("=");//2.找到等号，把等号也去掉
  if(str.indexOf("=")>0) {
   str=str.substring(0, equalIndex);
  }
  strLength=str.length;//3.原来的字符流大小，单位为字节
  size=strLength-(strLength/8)*2;//4.计算后得到的文件流大小，单位为字节
  return size;
 }

function _cttmx(eid){
  return function(){
  tmpbyd=0;
  tmpct=0;
  tmpfun="";   
  eval("sessionStorage.ct"+eid+"=intval(sessionStorage.ct"+eid+")+1;"); 
  eval("tmpct=sessionStorage.ct"+eid+";"); 
  eval("tmpbyd=sessionStorage.byd"+eid+";"); 
  eval("tmpval=sessionStorage.val"+eid+";");  
  if (intval(tmpct)>intval(tmpbyd) || tmpval==1){
  eval("tmpfun=sessionStorage.bydevfun"+eid+";");  
  if (tmpval==1){
   $("#"+eid).html("<a><img src=\"/localxres/iconsetx/pagecontrol/stt1.svg\" style=\"width:20px;height:20px;\">已操作完成</a>");
  }else{
   eval(tmpfun.replace(/@@@@/g,'\\"'));  
  }
  eval("clearInterval(count"+eid+");");
  } 
   return true;
  }
}
function setcounttime(ctid,bydtime,bydevfun){
  allct=sessionStorage.allct;
  if (allct==undefined || allct=="" || allct=="0" || allct==0){
 sessionStorage.allct="1";
 tmpallct="1";
  }else{
 tmpallct=intval(allct)+1;
 sessionStorage.allct=tmpallct;
  };
  eval("sessionStorage.ct"+tmpallct+"='"+ctid+"';");
  eval("sessionStorage.ct"+ctid+"=0;");
  eval("sessionStorage.val"+ctid+"=-1;");
  eval("sessionStorage.byd"+ctid+"="+bydtime+";");  
  eval("sessionStorage.bydevfun"+ctid+"='"+bydevfun.replace(/\'/g,"\\\'")+"';");  
  eval("count"+ctid+"=setInterval(_cttmx('"+ctid+"'),1000);");
}
 function setuniturlhtml(unitid,aurl,adata){
	  $.ajax({
			url:encodeURI(aurl),
			data:adata,
			type:'POST',
			dataType:"html",
			async : true, //true 异步 
			success: function(data){
			  $("#"+unitid).html(data);
			}
		});
		return true;
 }
 function F(fid,fstr,fpst,myunid,mway){ 
  domn=GetRequest().domn;
  stk=GetRequest().stk;
  var byd=0;
  if (domn==undefined || stk==undefined){
    byd=0;
  }else{
    byd=1;
    domn=base64Decode(domn);
  }
  switch(mway){
  case "refresh":
     if (byd==0){
       baxr=ajaxhtmlpost("/localxres/funx/"+fid+"/?"+fstr,fpst);
     }else{
       baxr=urldatap(domn,stk,"/localxres/funx/"+fid+"/?"+fstr,fpst);
     }
     $("#"+myunid).html(baxr);  
   return true;
  break;
  case "process":
   oldhtml=$("#"+myunid).html();
      $("#"+myunid).html("<a><img src=\"/sysdisk/pubimgs/controller/hh2B4y.gif\"></a>"); 
     if (byd==0){
      baxr=ajaxposthtml("/localxres/funx/"+fid+"/?"+fstr,"sessionStorage.val"+myunid+"=1;clearInterval(count"+myunid+");sessionStorage.allct=intval(sessionStorage.allct)-1;$('#"+myunid+"').html('<a><img src=\"/localxres/iconsetx/pagecontrol/stt1.svg\" style=\"width:20px;height:20px;\">已操作完成</a>');");z=setcounttime(myunid,30,"$(\"#"+myunid+"\").html(\"<a>超时-</a>"+oldhtml.replace(/"/g,'@@@@')+"\");");
     }else{
         return fundatap(domn,stk,"/localxres/funx/"+fid+"/?"+fstr,fpst,"sessionStorage.val"+myunid+"=1;clearInterval(count"+myunid+");sessionStorage.allct=intval(sessionStorage.allct)-1;$('#"+myunid+"').html('<a><img src=\"/localxres/iconsetx/pagecontrol/stt1.svg\" style=\"width:20px;height:20px;\">已操作完成</a>');");z=setcounttime(myunid,30,"$(\"#"+myunid+"\").html(\"<a>超时-</a>"+oldhtml.replace(/"/g,'@@@@')+"\");")
     }
   return true;
  break;
  case "alert":
  if (byd==0){
     baxr=ajaxhtmlpost("/localxres/funx/"+fid+"/?"+fstr,fpst);
     bayr=eval('('+baxr+')');
     if (intval(bayr.status)==1){
      z=pagenotify("1","操作成功",bayr.msg);
      if (bayr.redirect!=""){
       location.href=bayr.redirect;
      }
     }else{
       z=pagenotify("0","操作失败",bayr.msg);
     };
  }else{
      return fundatap(domn,stk,"/localxres/funx/"+fid+"/?"+fstr,fpst,"alert");
  }
  return true;
  break;
  default:
     if (byd==0){
       baxr=ajaxhtmlpost("/localxres/funx/"+fid+"/?"+fstr,fpst);
     }else{
       baxr=fundatap(domn,stk,"/localxres/funx/"+fid+"/?"+fstr,fpst,"");
     }
   return baxr;
  }
 }
 function V(id,vlx){
	if (vlx=="()"){
  var ysx=$("input[name='"+id+"']");
  if (ysx.length>=1){  
		 ckdel=$("input[name='"+id+"']:checked");
		 var totck=ckdel.length;
		 var fmckv='';
		 if (totck>1){
		   for (j=0;j<totck;j++){
			   fmckv=fmckv+$(ckdel[j]).val()+'/';
		   }
		   fmckv=killlasttring(fmckv);
		 }else{
			fmckv=$(ckdel).val();
		 }
			 
		return fmckv;
		
  }else{
		 return $("#"+id).val();
  }
	}else{
		$("#"+id).val(vlx);
	}//根据不同情况加上自动跳转选择的功能
 }
 function getcheckval(nmx){
  var els =document.getElementsByName(nmx);
  vlx="";
   for (var i = 0, j = els.length; i < j; i++){
    if (els[i].checked==true){
        vlx=els[i].value;
    }
   }
   return vlx;
 }
 function P(pids,vids,tps){
	 if (tps>0){
	  ptpidx=pids.split(',');
	  totpid=ptpidx.length;
	 }else{
	   totpid=0;
	 };
	 ptvidx=vids.split(',');
	 totvid=ptvidx.length;
	 if (totpid==totvid || tps==0){
		 var fmkvx='';
		if (tps==0){
		 for (i=0;i<totvid;i++){
			fmkvx=fmkvx+V(ptvidx[i],'()')+",";
		 };
		 if (totvid>0){
			fmkvx=killlasttring(fmkvx);
		 };
		}else{
		 for (i=0;i<totvid;i++){
			 if (tps==1){
			  fmkvx=fmkvx+'&'+ptpidx[i]+'='+V(ptvidx[i],'()');
			 }else if(tps==2){
				 fmkvx=fmkvx+'&'+ptpidx[i]+'='+mkstr(V(ptvidx[i],'()'));
			 }
		 };
		};
		return fmkvx;
	 }else{
  return 0;
	 };
 }
function onlyone(strx,fh){
  ptstr=strx.split(fh);
  totpt=ptstr.length;
  tmpx="";
  for (i=0;i<totpt;i++){
 if (("mm-"+tmpx).indexOf(ptstr[i])>0 && ptstr[i]!=""){
 }else{
   if ( ptstr[i]!=""){
  tmpx=tmpx+ptstr[i]+fh;
   };
 }
  }//fori
  return tmpx;
}//func
function huanhang(){
  return "\r\n";
}
function GetDistance( lat1,  lng1,  lat2,  lng2){
 var radLat1 = lat1*Math.PI / 180.0;
 var radLat2 = lat2*Math.PI / 180.0;
 var a = radLat1 - radLat2;
 var  b = lng1*Math.PI / 180.0 - lng2*Math.PI / 180.0;
 var s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a/2),2) +
 Math.cos(radLat1)*Math.cos(radLat2)*Math.pow(Math.sin(b/2),2)));
 s = s *6378.137 ;// EARTH_RADIUS;
 s = Math.round(s * 10000) / 10000;
 return s;
}
function newjsfile(jfname){
 var script = document.createElement("script");
 script.type = "text/javascript";
 script.src = jfname;
 document.getElementsByTagName("head")[0].appendChild(script);
}
function makekey($mkei){
 $partmk=explode(",",$mkei);
 $tot=countx($partmk);
 $fmmk="";
 for ($i=0;$i<$tot;$i++){
   if (hou($partmk[$i],".")!="SNO" && strpos("--"+$fmmk,hou($partmk[$i],"."))<=0){
 $fmmk=$fmmk+$partmk[$i]+",";
   };
 };
 if ($tot>0){
  $fmmk=substr($fmmk,0,strlen($fmmk)-1);
 };
 return $fmmk;
}
function turncon($mstr){
  //把[]标签替换成{} 防止静态模板自己被解析，使用的时候实例化与静态有区别，不然编辑静态的时候容易出错  
  $mstr=$mstr.replace(/\[/g,"{");
  $mstr=$mstr.replace(/\]/g,"}");  
  return $mstr;
}
function conturn($mstr){
  $mstr=$mstr.replace(/{/g,"\[");
  $mstr=$mstr.replace(/}/g,"\]");
  return $mstr;
}
function labturn($mstr){
  //把真实代码模板化存储  
  $mstr=$mstr.replace(/{/g,"｛");
  $mstr=$mstr.replace(/}/g,"｝");
  $mstr=$mstr.replace(/\</g,"{");
  $mstr=$mstr.replace(/\>/g,"}");
  return $mstr;
}
function labturns($mstr){ 
  $mstr=str_replace("{","｛",$mstr);
  $mstr=str_replace("}","｝",$mstr);
  $mstr=str_replace("<","{",$mstr);
  $mstr=str_replace(">","}",$mstr);
  $mstr=str_replace("\"","@",$mstr);
  $mstr=str_replace("'","#",$mstr);
  $mstr=str_replace("OC","onclick",$mstr);
  $mstr=str_replace("OC","ONCLICK",$mstr);
  return $mstr;
}
function turnlab($mstr){
  //把模板实例化使用
  if (strpos("xx"+$mstr,"{")>0 && strpos("xx"+$mstr,"}")>0  && strpos("xx"+$mstr,"\<")<=0  && strpos("xx"+$mstr,"\>")<=0){
   $mstr=str_replace("{","<",$mstr);
   $mstr=str_replace("}",">",$mstr);
   $mstr=str_replace("｛","{",$mstr);
   $mstr=str_replace("｝","}",$mstr);
  }else{
  //console.log($mstr+"---");  
  }
  
  return $mstr;
}
function fmcdt($tbns,$kie){
 $parttb=explode(",",substr($tbns,0,strlen($tbns)-1));
 $tot=countx($parttb);
 $fmtj="";
 switch ($tot){
   case 2:
  $fmtj=$parttb[0]+"."+$kie+"="+$parttb[1]+"."+$kie+"  ";
  break;
   case 3:
  $fmtj=$parttb[0]+"."+$kie+"="+$parttb[1]+"."+$kie+" and "+$parttb[1]+"."+$kie+"="+$parttb[2]+"."+$kie+" ";
  break;
 }
 return $fmtj;
}
function keytostr(strx){
    stry="x"+strx;
    if (stry.indexOf("\'")<=0){
        return "\'"+strx+"\'";
    }
}
function keystostrs(strxs){
    fmnew="";
    if (strxs.indexOf(",")>0){
      ptstr=strxs.split(",");
      for (zi=0;zi<ptstr.length;zi++){
          fmnew=fmnew+keytostr(ptstr[zi])+",";
      }
      fmnew=killlasttring(fmnew);
      return fmnew;
    }else{
        return strxs;
    }
}

function keyexc($kxyz,$allkx,$kifx,$funxx){   
  if (strpos("xx"+$allkx,$kxyz)>0 && strpos("xx"+$funxx,"[col-")>0){
   $funxx=str_replace("[col-"+$kxyz+":clstxt]",$kifx[$dkey]["COLUMN_CLSTXT"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":classp]",$kifx[$dkey]["COLUMN_CLASSP"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":title]",$kifx[$dkey]["COLUMN_TITLE"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":sshow]",$kifx[$dkey]["COLUMN_SSHOW"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":spost]",$kifx[$dkey]["COLUMN_SPOST"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":jshow]",$kifx[$dkey]["COLUMN_JSHOW"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":jpost]",$kifx[$dkey]["COLUMN_JPOST"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":cange]",$kifx[$dkey]["COLUMN_CANGE"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":dspld]",$kifx[$dkey]["COLUMN_DSPLD"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":dxtype]",$kifx[$dkey]["COLUMN_DXTYPE"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":default]",$kifx[$dkey]["COLUMN_DEFAULT"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":explain]",$kifx[$dkey]["COLUMN_EXPLAIN"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":sqx]",$kifx[$dkey]["COLUMN_SQX"],$funxx); 
   $funxx=str_replace("[col-"+$kxyz+":type]",$kifx[$dkey]["COLUMN_TYPE"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":tpnm]",$kifx[$dkey]["COLUMN_TPNM"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":tplen]",$kifx[$dkey]["COLUMN_TPLEN"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":acthtm]",$kifx[$dkey]["COLUMN_ACTHTM"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":atnhtm]",$kifx[$dkey]["COLUMN_ATNHTM"],$funxx);
   $kxyz="key";
   $funxx=str_replace("[col-"+$kxyz+":clstxt]",$kifx[$dkey]["COLUMN_CLSTXT"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":classp]",$kifx[$dkey]["COLUMN_CLASSP"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":title]",$kifx[$dkey]["COLUMN_TITLE"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":sshow]",$kifx[$dkey]["COLUMN_SSHOW"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":spost]",$kifx[$dkey]["COLUMN_SPOST"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":jshow]",$kifx[$dkey]["COLUMN_JSHOW"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":jpost]",$kifx[$dkey]["COLUMN_JPOST"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":cange]",$kifx[$dkey]["COLUMN_CANGE"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":dspld]",$kifx[$dkey]["COLUMN_DSPLD"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":dxtype]",$kifx[$dkey]["COLUMN_DXTYPE"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":default]",$kifx[$dkey]["COLUMN_DEFAULT"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":explain]",$kifx[$dkey]["COLUMN_EXPLAIN"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":sqx]",$kifx[$dkey]["COLUMN_SQX"],$funxx); 
   $funxx=str_replace("[col-"+$kxyz+":type]",$kifx[$dkey]["COLUMN_TYPE"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":tpnm]",$kifx[$dkey]["COLUMN_TPNM"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":tplen]",$kifx[$dkey]["COLUMN_TPLEN"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":acthtm]",$kifx[$dkey]["COLUMN_ACTHTM"],$funxx);
   $funxx=str_replace("[col-"+$kxyz+":atnhtm]",$kifx[$dkey]["COLUMN_ATNHTM"],$funxx);
  }
   return $funxx;
}
function duofilex($cdtx,$dval){
  //使用方法 [duofile-b(20x20)]
  //echo "xxxxxxxxxxxx-".$cdtx."------------".$dval;
  $tmpkzm="js,css,htm,doc,xls,ppt,pdf,txt,rar,zip,mp3,mp4,psd,jpg,png,gif,svg,html,xlsx,docx,pptx,";
  if (strpos($dval,",")>0){
  $ptdv=explode(",",$dval);
  };
  if (strpos($dval,";")>0){
  $ptdv=explode(";",$dval);
  };  
  $totp=countx($ptdv);
  $kcss=qian($cdtx,"(");
  $kxyz=qian(hou($cdtx,"("),")");//w x h  1024 768 800 600
  $kxyz=str_replace("x",":",$kxyz);
  
  $kw=qian($kxyz,":");
  $kh=hou($kxyz,":");
  $fmxhtm="";
  
  for ($d=0;$d<$totp;$d++){
  $kzm="";
 if ($ptdv[$d]!=""){   
  $kzm=hou(hou($ptdv[$d],glw()),".");   
   if (strlen($kzm)<=4 && strlen($kzm)>0){
  if (strpos($tmpkzm,$kzm+",")>0){
  //发现定义域中的扩展名了
  if (strpos("xjpg,jpeg,png,bmp,gif",$kzm)>0){
  	$fmxhtm=$fmxhtm+"<a href=\""+$ptdv[$d]+"\" target=\"about_blank\"><img src=\""+$ptdv[$d]+"\"  width=\""+$kw+"px\" height=\""+$kh+"px\"></a>";
  }else{
   $fmxhtm=$fmxhtm+"<a href=\""+$ptdv[$d]+"\" target=\"about_blank\"><img src=\"/ORG/BRAIN/images/icon/filetypes/"+$kzm+"-"+$kcss+".svg"+"\" width=\""+$kw+"px\" height=\""+$kh+"px\"></a>";
  }   
  }else{
  //没发现定义域中的扩展名
  $fmxhtm=$fmxhtm+"<a href=\""+$ptdv[$d]+"\" target=\"about_blank\"><img src=\"/ORG/BRAIN/images/icon/filetypes/svg-c.svg"+"\" width=\""+$kw+"px\" height=\""+$kh+"px\"></a>";
  };
   }else{
  //否则位数不够
  // $fmxhtm=$fmxhtm."位数不够！/";
   }
 }else{
   //如果 分割部分没有值
   //$fmxhtm=$fmxhtm."分割部分没有值！/";
 };
  };//for
 return $fmxhtm;  
 // return "duofile-".$cdtx."---".$dval;
}
function turnquote(tutxt){
  if (tutxt!=undefined && tutxt!=""){
  tutxt=tutxt.toString().replace(/\\\'/g,'\'');
  return tutxt;
  }else{
   return "";
  }
}

function shortcls(stid){
  tmpval="";
  eval("tmpval=localStorage.shortcls"+stid+";");
  if (tmpval=="" || tmpval==undefined){
 bktxt=ajaxhtmlpost("/localxres/funx/anyshort/?stid="+stid,"");
 eval("localStorage.shortcls"+stid+"=bktxt;");
 return bktxt;
  }else{
 return tmpval;
  }
}
function toquote(txtx){
  if (txtx!=undefined){
   txtx=txtx.toString().replace(/\"/g,'@!!!@');  
   txtx=txtx.replace(/\'/g,'@---@');  
   txtx=txtx.replace(/\>/g,'@=--@');  
   txtx=txtx.replace(/\</g,'@--=@');  
   txtx=txtx.replace(/inner/g,'@INR@');  
   return txtx;
  }else{
   return "";
  }
}
function unquote(txtx){
 if (txtx!=undefined){
   txtx= txtx.toString().replace(/@!!!@/g,"\"");  
   txtx= txtx.replace(/@---@/g,"\'");  
   txtx=txtx.replace(/@=--@/g,'\>');  
   txtx=txtx.replace(/@--=@/g,'\<');  
   txtx=txtx.replace(/@INR@/g,'inner');  
   return txtx;
 }else{
   return ""; 
 }
}


function intval(sint){
   return Number(sint);
}


function combinestr2(a,b){
 return a+b;
}
function combinestr3(a,b,c){
 return a+b+c;
}
function combinestr4(a,b,c,d){
 return a+b+c+d;
}
function combinestr5(a,b,c,d,e){
 return a+b+c+d+e;
}
function combinestr6(a,b,c,d,e,f){
 return a+b+c+d+e+f;
}
function combinestr7(a,b,c,d,e,f,g){
 return a+b+c+d+e+f+g;
}

String.prototype.MD5 = function (bit)
{
 var sMessage = this;
 function RotateLeft(lValue, iShiftBits) { return (lValue<<iShiftBits) | (lValue>>>(32-iShiftBits)); } 
 function AddUnsigned(lX,lY)
 {
  var lX4,lY4,lX8,lY8,lResult;
  lX8 = (lX & 0x80000000);
  lY8 = (lY & 0x80000000);
  lX4 = (lX & 0x40000000);
  lY4 = (lY & 0x40000000);
  lResult = (lX & 0x3FFFFFFF)+(lY & 0x3FFFFFFF); 
  if (lX4 & lY4) return (lResult ^ 0x80000000 ^ lX8 ^ lY8); 
  if (lX4 | lY4)
  { 
   if (lResult & 0x40000000) return (lResult ^ 0xC0000000 ^ lX8 ^ lY8); 
   else return (lResult ^ 0x40000000 ^ lX8 ^ lY8); 
  } else return (lResult ^ lX8 ^ lY8); 
 } 
 function F(x,y,z) { return (x & y) | ((~x) & z); } 
 function G(x,y,z) { return (x & z) | (y & (~z)); } 
 function H(x,y,z) { return (x ^ y ^ z); } 
 function I(x,y,z) { return (y ^ (x | (~z))); } 
 function FF(a,b,c,d,x,s,ac)
 { 
  a = AddUnsigned(a, AddUnsigned(AddUnsigned(F(b, c, d), x), ac)); 
  return AddUnsigned(RotateLeft(a, s), b); 
 } 
 function GG(a,b,c,d,x,s,ac)
 { 
  a = AddUnsigned(a, AddUnsigned(AddUnsigned(G(b, c, d), x), ac)); 
  return AddUnsigned(RotateLeft(a, s), b); 
 } 
 function HH(a,b,c,d,x,s,ac)
 { 
  a = AddUnsigned(a, AddUnsigned(AddUnsigned(H(b, c, d), x), ac)); 
  return AddUnsigned(RotateLeft(a, s), b); 
 } 
 function II(a,b,c,d,x,s,ac)
 { 
  a = AddUnsigned(a, AddUnsigned(AddUnsigned(I(b, c, d), x), ac)); 
  return AddUnsigned(RotateLeft(a, s), b); 
 } 
 function ConvertToWordArray(sMessage)
 { 
  var lWordCount; 
  var lMessageLength = sMessage.length; 
  var lNumberOfWords_temp1=lMessageLength + 8; 
  var lNumberOfWords_temp2=(lNumberOfWords_temp1-(lNumberOfWords_temp1 % 64))/64; 
  var lNumberOfWords = (lNumberOfWords_temp2+1)*16; 
  var lWordArray=Array(lNumberOfWords-1); 
  var lBytePosition = 0; 
  var lByteCount = 0; 
  while ( lByteCount < lMessageLength )
  { 
   lWordCount = (lByteCount-(lByteCount % 4))/4; 
   lBytePosition = (lByteCount % 4)*8; 
   lWordArray[lWordCount] = (lWordArray[lWordCount] | (sMessage.charCodeAt(lByteCount)<<lBytePosition)); 
   lByteCount++; 
  } 
  lWordCount = (lByteCount-(lByteCount % 4))/4; 
  lBytePosition = (lByteCount % 4)*8; 
  lWordArray[lWordCount] = lWordArray[lWordCount] | (0x80<<lBytePosition); 
  lWordArray[lNumberOfWords-2] = lMessageLength<<3; 
  lWordArray[lNumberOfWords-1] = lMessageLength>>>29; 
  return lWordArray; 
 } 
 function WordToHex(lValue)
 { 
  var WordToHexValue="",WordToHexValue_temp="",lByte,lCount; 
  for (lCount = 0;lCount<=3;lCount++)
  { 
   lByte = (lValue>>>(lCount*8)) & 255; 
   WordToHexValue_temp = "0" + lByte.toString(16); 
   WordToHexValue = WordToHexValue + WordToHexValue_temp.substr(WordToHexValue_temp.length-2,2); 
  } 
  return WordToHexValue; 
 } 
 var x=Array(); 
 var k,AA,BB,CC,DD,a,b,c,d 
 var S11=7, S12=12, S13=17, S14=22; 
 var S21=5, S22=9 , S23=14, S24=20; 
 var S31=4, S32=11, S33=16, S34=23; 
 var S41=6, S42=10, S43=15, S44=21; 
 // Steps 1 and 2. Append padding bits and length and convert to words 
 x = ConvertToWordArray(sMessage); 
 // Step 3. Initialise 
 a = 0x67452301; b = 0xEFCDAB89; c = 0x98BADCFE; d = 0x10325476; 
 // Step 4. Process the message in 16-word blocks 
 for (k=0;k<x.length;k+=16)
 { 
  AA=a; BB=b; CC=c; DD=d; 
  a=FF(a,b,c,d,x[k+0], S11,0xD76AA478); 
  d=FF(d,a,b,c,x[k+1], S12,0xE8C7B756); 
  c=FF(c,d,a,b,x[k+2], S13,0x242070DB); 
  b=FF(b,c,d,a,x[k+3], S14,0xC1BDCEEE); 
  a=FF(a,b,c,d,x[k+4], S11,0xF57C0FAF); 
  d=FF(d,a,b,c,x[k+5], S12,0x4787C62A); 
  c=FF(c,d,a,b,x[k+6], S13,0xA8304613); 
  b=FF(b,c,d,a,x[k+7], S14,0xFD469501); 
  a=FF(a,b,c,d,x[k+8], S11,0x698098D8); 
  d=FF(d,a,b,c,x[k+9], S12,0x8B44F7AF); 
  c=FF(c,d,a,b,x[k+10],S13,0xFFFF5BB1); 
  b=FF(b,c,d,a,x[k+11],S14,0x895CD7BE); 
  a=FF(a,b,c,d,x[k+12],S11,0x6B901122); 
  d=FF(d,a,b,c,x[k+13],S12,0xFD987193); 
  c=FF(c,d,a,b,x[k+14],S13,0xA679438E); 
  b=FF(b,c,d,a,x[k+15],S14,0x49B40821); 
  a=GG(a,b,c,d,x[k+1], S21,0xF61E2562); 
  d=GG(d,a,b,c,x[k+6], S22,0xC040B340); 
  c=GG(c,d,a,b,x[k+11],S23,0x265E5A51); 
  b=GG(b,c,d,a,x[k+0], S24,0xE9B6C7AA); 
  a=GG(a,b,c,d,x[k+5], S21,0xD62F105D); 
  d=GG(d,a,b,c,x[k+10],S22,0x2441453); 
  c=GG(c,d,a,b,x[k+15],S23,0xD8A1E681); 
  b=GG(b,c,d,a,x[k+4], S24,0xE7D3FBC8); 
  a=GG(a,b,c,d,x[k+9], S21,0x21E1CDE6); 
  d=GG(d,a,b,c,x[k+14],S22,0xC33707D6); 
  c=GG(c,d,a,b,x[k+3], S23,0xF4D50D87); 
  b=GG(b,c,d,a,x[k+8], S24,0x455A14ED); 
  a=GG(a,b,c,d,x[k+13],S21,0xA9E3E905); 
  d=GG(d,a,b,c,x[k+2], S22,0xFCEFA3F8); 
  c=GG(c,d,a,b,x[k+7], S23,0x676F02D9); 
  b=GG(b,c,d,a,x[k+12],S24,0x8D2A4C8A); 
  a=HH(a,b,c,d,x[k+5], S31,0xFFFA3942); 
  d=HH(d,a,b,c,x[k+8], S32,0x8771F681); 
  c=HH(c,d,a,b,x[k+11],S33,0x6D9D6122); 
  b=HH(b,c,d,a,x[k+14],S34,0xFDE5380C); 
  a=HH(a,b,c,d,x[k+1], S31,0xA4BEEA44); 
  d=HH(d,a,b,c,x[k+4], S32,0x4BDECFA9); 
  c=HH(c,d,a,b,x[k+7], S33,0xF6BB4B60); 
  b=HH(b,c,d,a,x[k+10],S34,0xBEBFBC70); 
  a=HH(a,b,c,d,x[k+13],S31,0x289B7EC6); 
  d=HH(d,a,b,c,x[k+0], S32,0xEAA127FA); 
  c=HH(c,d,a,b,x[k+3], S33,0xD4EF3085); 
  b=HH(b,c,d,a,x[k+6], S34,0x4881D05); 
  a=HH(a,b,c,d,x[k+9], S31,0xD9D4D039); 
  d=HH(d,a,b,c,x[k+12],S32,0xE6DB99E5); 
  c=HH(c,d,a,b,x[k+15],S33,0x1FA27CF8); 
  b=HH(b,c,d,a,x[k+2], S34,0xC4AC5665); 
  a=II(a,b,c,d,x[k+0], S41,0xF4292244); 
  d=II(d,a,b,c,x[k+7], S42,0x432AFF97); 
  c=II(c,d,a,b,x[k+14],S43,0xAB9423A7); 
  b=II(b,c,d,a,x[k+5], S44,0xFC93A039); 
  a=II(a,b,c,d,x[k+12],S41,0x655B59C3); 
  d=II(d,a,b,c,x[k+3], S42,0x8F0CCC92); 
  c=II(c,d,a,b,x[k+10],S43,0xFFEFF47D); 
  b=II(b,c,d,a,x[k+1], S44,0x85845DD1); 
  a=II(a,b,c,d,x[k+8], S41,0x6FA87E4F); 
  d=II(d,a,b,c,x[k+15],S42,0xFE2CE6E0); 
  c=II(c,d,a,b,x[k+6], S43,0xA3014314); 
  b=II(b,c,d,a,x[k+13],S44,0x4E0811A1); 
  a=II(a,b,c,d,x[k+4], S41,0xF7537E82); 
  d=II(d,a,b,c,x[k+11],S42,0xBD3AF235); 
  c=II(c,d,a,b,x[k+2], S43,0x2AD7D2BB); 
  b=II(b,c,d,a,x[k+9], S44,0xEB86D391); 
  a=AddUnsigned(a,AA); b=AddUnsigned(b,BB); c=AddUnsigned(c,CC); d=AddUnsigned(d,DD); 
 }
 if(bit==32)
 {
  return WordToHex(a)+WordToHex(b)+WordToHex(c)+WordToHex(d);
 }
 else
 {
  return WordToHex(b)+WordToHex(c);
 }
}
function timestampFormat( timestamp ) {
function zeroize( num ) {
return (String(num).length == 1 ? '0' : '') + num;
}

var curTimestamp = parseInt(new Date().getTime() / 1000); //当前时间戳
var timestampDiff = curTimestamp - timestamp; // 参数时间戳与当前时间戳相差秒数

var curDate = new Date( curTimestamp * 1000 ); // 当前时间日期对象
var tmDate = new Date( timestamp * 1000 ); // 参数时间戳转换成的日期对象

var Y = tmDate.getFullYear(), m = tmDate.getMonth() + 1, d = tmDate.getDate();
var H = tmDate.getHours(), i = tmDate.getMinutes(), s = tmDate.getSeconds();

if ( timestampDiff < 60 ) { // 一分钟以内
return "刚刚";
} else if( timestampDiff < 3600 ) { // 一小时前之内
return Math.floor( timestampDiff / 60 ) + "分钟前";
} else if ( curDate.getFullYear() == Y && curDate.getMonth()+1 == m && curDate.getDate() == d ) {
return '今天' + zeroize(H) + ':' + zeroize(i);
} else {
var newDate = new Date( (curTimestamp - 86400) * 1000 ); // 参数中的时间戳加一天转换成的日期对象
if ( newDate.getFullYear() == Y && newDate.getMonth()+1 == m && newDate.getDate() == d ) {
return '昨天' + zeroize(H) + ':' + zeroize(i);
} else if ( curDate.getFullYear() == Y ) {
return zeroize(m) + '月' + zeroize(d) + '日 ' + zeroize(H) + ':' + zeroize(i);
} else {
return Y + '年' + zeroize(m) + '月' + zeroize(d) + '日 ' + zeroize(H) + ':' + zeroize(i);
}
}
}
function makedttm(date){
var strDate = date.getFullYear()+"-";
strDate += date.getMonth()+1+"-";
strDate += date.getDate()+"-";
strDate += date.getHours()+":";
strDate += date.getMinutes()+":";
strDate += date.getSeconds();
return strDate ;
}
function tabstr(){
  return "\t";
}
function makedkoid(dtm,rc){
    return ajaxhtmlpost("/localxres/funx/makedkoid&datex"+dtm+"&rc="+rc,"");
}
