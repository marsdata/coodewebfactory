function visitit(ustr){
	if (qian(ustr,".")=="Err"){
		 alert(ustr);
	}else{
		 location.href=ustr;
	}
}
function vfcookie(sysid){
	if (_cookie("uid")==""){
		location.href="/";
	}else{
		location.href="/localxres/funx/anysys/?sysid="+sysid+".1";
	}
}
function loginsys(uid,pass,sysid){
	fd=fundata("commonlogin","uid="+uid+"&pass="+makepass(uid,pass)+"&sysid="+sysid,"");
	console.log(fd);
	if (fd.status>0){
		return fd.redirect;
	}else{
		return "Err.loginFailed";
	}
}
function quitsys(){
	fd=fundata("quit","","");
	console.log(fd);
	if (fd.status>0){
		return "/";
	}else{
		return "Err.loginFailed";
	}
}

function sqlexec(sqlstring){
	fd=fundata("sqlexec","stype=","sqlx="+sqlstring);
	console.log(fd);
	if (fd.status>0){
		return fd.redirect;
	}else{
		return "Err.sqlFailed";
	}
}