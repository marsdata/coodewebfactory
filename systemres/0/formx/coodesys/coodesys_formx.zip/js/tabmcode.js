function fmvalue($tbnmx,$dvalue,$dsno,$dkey,$sfun,$dn,$arrdt){  
$nhtxt="";
$sfunx="";
$funvalue="";
$newfunx=""; 
tmpvx="";
$colname=$dkey;
$snox=$dsno;
//$ktitle
$sfun=$sfun.toString();
$sttab=$tbnmx;
$thusvalue=$dvalue;
smd5=$tbnmx+$dvalue+$dsno+$dkey+$sfun+$dn;
smd5="a"+smd5.MD5();
eval('tmpvx=sessionStorage.'+smd5+';');
if (tmpvx!="" && tmpvx!=undefined && $dvalue!="" && $dsno!="" && $dkey!=""){
  
  return tostring(tmpvx);
}else{
  if ($dkey=="apps"){   
  }
  $sfun=qian(" "+$sfun,"|");
 if ($sfun=="" || $dn==-1 || $sfun==undefined ){
   if(strlen($dvalue)>20){
   return substr($dvalue,0,20);
   }else{
   return $dvalue;
   };
 }  
fd=0;
$tmpvlx="";
  if (strpos("x"+$sfun,"CASE")>0 && strpos("x"+$sfun,"E@CS")>0){
 $ptfunx=explode("CASE",$sfun);
 $totpf=countx($ptfunx);
 $fd=0;
 for ($pf=1;$pf<$totpf;$pf++){   
  $tmpfn=qian(hou($ptfunx[$pf],"::"),"E@CS");
  $tmpct=qian($ptfunx[$pf],"::");
  $tmptj=substr($ptfunx[$pf],0,1);
  $tmpvlx=qian($ptfunx[$pf],"::");   
  $tmpvlx=$tmpvlx.replace($tmptj,"");  
  switch($tmptj){
   case "@":
   if (((strpos("xxx"+$dvalue,$tmpvlx)>0 && $tmpvlx!="") || $tmpvlx=="") && $fd==0){
   $newfunx=$tmpfn;
   $fd=$fd+1;
   }
   break;
   case "=":
  if ($dvalue==$tmpvlx || intval($dvalue)*1==intval($tmpvlx)*1 && $tmpvlx!="" && $fd==0){
  $newfunx=$tmpfn;   
  $fd=$fd+1;
   };
   break;
   case ">":
   if ((($tmpvlx*1)>($dvalue*1)) && $tmpvlx!="" && $fd==0){
  $newfunx=$tmpfn;
  $fd=$fd+1;
   };
  break;
   case "<":
   if ((($tmpvlx*1)<($dvalue*1)) && $tmpvlx!="" && $fd==0){
  $newfunx=$tmpfn;
  $fd=$fd+1;
   };
   break;
   default:   
   $sfun="";
  }
   };//for
   $sfun="";
   if ($fd==0){   
   }
  }else{
  };  
 if ($newfunx!=""){
   $sfun=turncon($newfunx);   
 }else{
   
   if (strpos("x"+$sfun,"unction ")>0 ){
   }else{
   $sfun=turncon($sfun);  
   }
 }
  if (strpos("x"+$sfun,"{")>0 || strpos("x"+$sfun,"unction ")>0 || strpos($sfun,"}")>0 ){
   if (strpos($sfun,"unction ")>0 && strpos($sfun,"function(")<=0){
  funstr='$nhtxt='+qian(hou($sfun,"unction "),"{")+";";
  xfunstr=substr(funstr,2,strlen(funstr)-2);
  if (xfunstr.indexOf("$")<=0){
   funstr=one_replace("key0",syh()+"p_"+$dkey+$dsno+syh(),funstr,6); 
   funstr=one_replace("key",syh()+$dkey+syh(),funstr,6);
   funstr=one_replace("SNO",syh()+$dsno+syh(),funstr,6);
   funstr=one_replace("table",syh()+$tbnmx+syh(),funstr,6);
   funstr=one_replace("date",syh()+date("Y-m-d")+syh(),funstr,6);
   funstr=one_replace("now",syh()+date("Y-m-d H:i:s")+syh(),funstr,6);
   funstr=one_replace("anymark",syh()+date("YmdHis")+randomWord(false,6)+syh(),funstr,6);
   funstr=one_replace("OLMK",syh()+onlymark()+syh(),funstr,6);
   funstr=one_replace("thiskey",syh()+$dkey+syh(),funstr,6);
   funstr=one_replace("thistable",syh()+$tbnmx+syh(),funstr,6);
   funstr=one_replace("thissno",syh()+$dsno+syh(),funstr,6);
   funstr=one_replace("thisvalue",syh()+tostring($dvalue)+syh(),funstr,3);  
   if (funstr.indexOf("key-")>0){
   $ptnhtxt=explode("key-",funstr);
   $totpt=countx($ptnhtxt); 
   for ($f=1;$f<$totpt;$f++){
   $tmpok=qian($ptnhtxt[syh()+$f],",");  
   if ($trow["showkeys"].indexOf($tmpok)>0){
     funstr=one_replace("key-"+$tmpok,$arrdt[$tmpok][$dn*1],funstr,6);
   }else{
     funstr=one_replace("key-"+$tmpok,"",funstr,6);
   }
   };//for
  }//if key-
  }//if $
  eval(funstr);
   }else{//$unction
  $nhtxt=$sfun;   
   }
   $nhtxt=str_replace("{thisid}","ipt"+$dkey+$dsno,$nhtxt);   
   $nhtxt=str_replace("{thiskey}",$dkey,$nhtxt);
   if (strpos("xxx"+$nhtxt,"{col-key")>0){
  $kfun=array(array());
  $kfun=thekeyfun($kfun,glb(),$tbnmx,$arrdt["table"]["keys"]);  
  $nhtxt=keyexc($dkey,$arrdt["table"]["keys"],$kfun,$nhtxt);
   }
   $nhtxt=str_replace("{thistable}",$tbnmx,$nhtxt);
   $grp=atv("(coode_sysdefault@companyid='"+glc()+"').groupid");
   $nhtxt=str_replace("{grp}",$grp,$nhtxt);
   $nhtxt=str_replace("{thissno}",$dsno,$nhtxt);
   $nhtxt=str_replace("{SNO}",$dsno,$nhtxt);
   $nhtxt=str_replace("{key}",$dkey,$nhtxt);
   $nhtxt=str_replace("{key0}","p_"+$dkey+$dsno,$nhtxt);
   $nhtxt=str_replace("{table}",$tbnmx,$nhtxt);
   $nhtxt=str_replace("{OLMK}",onlymark(),$nhtxt);
   $nhtxt=str_replace("{date}",date("Y-m-d"),$nhtxt);
  $nhtxt=str_replace("{now}",date("Y-m-d H:i:s"),$nhtxt);
   $nhtxt=str_replace("{uid}",glu(),$nhtxt);
   $nhtxt=str_replace("{gid}","",$nhtxt);
   $nhtxt=str_replace("{cid}",glc(),$nhtxt);
   $nhtxt=str_replace("{appid}",_get("appid"),$nhtxt);
   $nhtxt=str_replace("{thisshort}",_get("tmpshortid"),$nhtxt);
   $nhtxt=str_replace("{thisshort}",_get("tmpstid"),$nhtxt);
   $nhtxt=str_replace("{shortid}",_get("shortid"),$nhtxt);
   $nhtxt=str_replace("{shortid}",_get("stid"),$nhtxt);
   $nhtxt=str_replace("{thisvalue}",tostring($dvalue),$nhtxt);
   if ($dvalue=="1" || $dvalue=="checked"){
  $nhtxt=str_replace("{checked}","checked",$nhtxt);
   }else{
  $nhtxt=str_replace("{checked}","",$nhtxt);
   };//
   if ($dvalue==""){
  $nhtxt=str_replace("{imgvalue}",dfp(),$nhtxt);
   }else{
  $nhtxt=str_replace("{imgvalue}",str_replace(";","",$dvalue),$nhtxt);
   };//
   $nhtxt=str_replace("{siteurl}",glw(),$nhtxt);
   $nhtxt=str_replace("{rip}",getip(),$nhtxt);
   $nhtxt=str_replace("{defaultbase}",glb(),$nhtxt);
   $nhtxt=str_replace("{defaultip}",gl(),$nhtxt);
   $nhtxt=str_replace("{today}",date("Y-m-d"),$nhtxt);
   $nhtxt=str_replace("{now}",date("Y-m-d H:i:s"),$nhtxt);
   if (strpos("xxx".$nhtxt,"{duofile-")>0){  
  $ftj=qian(hou($nhtxt,"{duofile-"),"}");
  $nhtxt=str_replace("{duofile-"+$ftj+"}",duofilex($ftj,tostring($dvalue)),$nhtxt); 
   };//

  if ($nhtxt.indexOf("{key-")>0){
   $ptnhtxt=explode("{key-",$nhtxt);
   $totpt=countx($ptnhtxt); 
   for ($f=1;$f<$totpt;$f++){
   $tmpok=qian($ptnhtxt[$f],"}");  
   if (strpos($arrdt[$dkey][0],$tmpok)>0){
  $nhtxt=str_replace("{key-"+$tmpok+"}",$arrdt[$tmpok][$dn*1],$nhtxt);
   }
   };//
  }
  if (strpos("xxx"+$nhtxt,"{col-")>0){
  //$kfun=array(array());
  $kfun=thekeyfun($kfun,glb(),$tbnmx,$arrdt[$dkey][0]);  
  $ptnhtxt=explode("{col-",$nhtxt);
  $totpt=countx($ptnhtxt);
  for ($f=1;$f<$totpt;$f++){
   $tmpok=qian($ptnhtxt[$f],"}");
   $tmpokx=qian($tmpok,":");
   $nhtxt=keyexc($tmpokx,$arrdt[$dkey][0],$kfun,$nhtxt);
  };//
 }
  if ($nhtxt.indexOf("{get-")>0){
   $ptnhtxt=explode("{get-",$nhtxt);
   $totpt=countx($ptnhtxt);
 for ($f=1;$f<$totpt;$f++){
   $tmpok=qian($ptnhtxt[$f],"}");
   $nhtxt=str_replace("{get-"+$tmpok+"}",_get($tmpok),$nhtxt);
 };//
  }
  if ($nhtxt.indexOf("{post-")>0){
 $ptnhtxt=explode("{post-",$nhtxt);
 $totpt=countx($ptnhtxt);
 for ($f=1;$f<$totpt;$f++){
   $tmpok=qian($ptnhtxt[$f],"}");
   $nhtxt=str_replace("{post-"+$tmpok+"}",_post($tmpok),$nhtxt);
 };//
  }
  if ($nhtxt.indexOf("{cookie-")>0){
   $ptnhtxt=explode("{cookie-",$nhtxt);
   $totpt=countx($ptnhtxt);
   for ($f=1;$f<$totpt;$f++){
   $tmpok=qian($ptnhtxt[$f],"}");
   $nhtxt=str_replace("{cookie-"+$tmpok+"}",_cookie($tmpok),$nhtxt);
   };//
  }
 if ($nhtxt.indexOf("{atv-")>0){
  if (strpos($nhtxt,"{atv-")>0){
   $ptatv=explode("{atv-",$nhtxt);
   $totatv=countx($ptatv);
   for ($g=1;$g<$totatv;$g++){
   $tmpatv=qian($ptatv[$g],"}");
   $nhtxt=str_replace("{atv-"+$tmpatv+"}",atv($tmpatv),$nhtxt);
   };//
  };//
 };
 if ($nhtxt.indexOf("{utv-")>0){
  if (strpos($nhtxt,"{utv-")>0){
   $ptutv=explode("{utv-",$nhtxt);
   $totutv=countx($ptutv);
   for ($h=1;$h<$totutv;$h++){
   $tmputv=qian($ptutv[$h],"}");
   $nhtxt=str_replace("{utv-"+$tmputv+"}",utv($tmputv),$nhtxt);
 };//
   };//   
  };
 }else{
  $nhtxt=$dvalue;
 };//

   $nhtxt=turnlab($nhtxt);
   $nhtxt=turnquote($nhtxt);
   eval('sessionStorage.'+smd5+'=$nhtxt;');
   return $nhtxt;
 };
}

function formdiybtn($stid,$diycode){
  $fmx="";
  $fmxy="";
 if ($diycode!=""){
  if (strpos($diycode,",")>0){
  $ptdiy=explode(",",$diycode);
  $totptd=countx($ptdiy);
  $fmx="";
  $fmxy="";
  for ($p=0;$p<$totptd;$p++){
   $ttx=qian($ptdiy[$p],":");
   $uux=hou($ptdiy[$p],":");
   if (strpos($uux,")")>0){
   $fmx=$fmx+"<a class=\"layui-btn\" onclick=\""+$uux+"\">"+$ttx+"</a>";
   if (($gsqc*1)==$p){
  $fmxy=$fmxy+"<li><a href=\"javascript:void(0);\" onclick=\""+$uux+"\" class=\"current\">"+$ttx+"</a></li>";
   }else{
   $fmxy=$fmxy+"<li><a href=\"javascript:void(0);\" onclick=\""+$uux+"\">"+$ttx+"</a></li>";
   };
   }else{
   $fmx=$fmx+"<a class=\"layui-btn\" onclick=\"intourl('"+$uux+"')\">"+$ttx+"</a>";
   if (($gsqc*1)==1){
  $fmxy=$fmxy+"<li><a href=\"javascript:void(0);\" onclick=\"intourl('"+$uux+"')\" class=\"current\">"+$ttx+"</a></li>";
   }else{
   $fmxy=$fmxy+"<li><a href=\"javascript:void(0);\" onclick=\"intourl('"+$uux+"')\">"+$ttx+"</a></li>";
   };
   };
  };//for
   }else{
   $ttx=qian($diycode,":");
   $uux=hou($diycode,":");
   if (strpos($uux,")")>0){
   $fmx=$fmx+"<a class=\"layui-btn\" href=\"javascript:void(0);\" onclick=\""+$uux+"\">"+$ttx+"</a>";
   if (($gsqc*1)==1){
   $fmxy=$fmxy+"<li><a href=\"javascript:void(0);\" onclick=\""+$uux+"\">"+$ttx+"</a></li>";
   }
   }else{
   $fmx=$fmx+"<a class=\"layui-btn\" href=\"javascript:void(0);\" onclick=\"intourl('"+$uux+"')\">"+$ttx+"</a>";
   if (($gsqc*1)==1){
   $fmxy=$fmxy+"<li><a href=\"javascript:void(0);\" onclick=\"intourl('"+$uux+"')\">"+$ttx+"</a></li>";
   };
   };   
  };
 $dbtn="<div id=\"wrap\"><div id=\"content\" ><ul >"+$fmxy+"</ul></div></div>";
 return $dbtn;
  }else{
   return "";
  };
}

 function maketbhead($skeyx,$kxif,$cscs,$stxy){
  $shokx=$skeyx;
  $srst=new Array();
  $tdxx=new Array();
  $partkx=explode(",",$shokx);
  $totptkx=countx($partkx);
  
  $trtr=turnlab($cscs["tabhdtr"]);
  $fmtd="";
  $ttt="";
  allkeys=",";
  
  for ($mx=0;$mx<$totptkx;$mx++){
   if ($partkx[$mx]!=""){
     if (typeof($kxif[$partkx[$mx]])!="undefined"){
      $ttt=$kxif[$partkx[$mx]]["COLUMN_TITLE"];
     }else{
      $ttt="";
     }
     dxtypex=$kxif[$partkx[$mx]]["COLUMN_DXTYPE"];
     dxclass=$kxif[$partkx[$mx]]["COLUMN_CLASSP"];
     $tdvl=$ttt;
     $datax=new Array();
     
     if (intval(dxclass)==8){
         $("#areacode").val($partkx[$mx]);
         $("#areacls").val($kxif[$partkx[$mx]]["COLUMN_CLSTXT"]);
     }
     if (intval(dxclass)==11){
         $("#wrdcode").val($partkx[$mx]);
         $("#wrdcls").val($kxif[$partkx[$mx]]["COLUMN_CLSTXT"]);
     }
     $tdxx=formtrow($tdxx,$partkx[$mx],$tdvl,"-1","-1",$kxif,$stxy,-1,$srst);
    if ($kxif[$partkx[$mx]]["COLUMN_THCODE"]!=""){
      cthcode=tostring($kxif[$partkx[$mx]]["COLUMN_THCODE"]);
      cthcode=cthcode.replace(/\\\'/g,'\'');
      $maketdv=exchangeunit($tdxx,turnlab(cthcode),$datax,0);  
    }else{
      if (dftval($cscs[dxtypex+"th"],"")!=""){
        $maketdv=exchangeunit($tdxx,turnlab($cscs[dxtypex+"th"]),$datax,0);
      }else{
        $maketdv=exchangeunit($tdxx,turnlab($cscs["tabhdtd"]),$datax,0);  
      }
    }
     $maketdv=one_replace("[inner]",$tdvl,$maketdv);
     $fmtd=$fmtd+$maketdv;
   }
  }  

 $trtr="<thead>"+one_replace("[inner]",$fmtd,$trtr)+"</thead>";
   return $trtr;
 }

 function getkeyc(ktpx,kid,mtd){
     rtnval="";
     fmval="";
     for (kk=0;kk<ktpx.length;kk++){
      fmval=fmval+ktpx[kk].keyid+",";
      if (ktpx[kk].keyid==kid){
       switch(mtd){
         case "title":
             rtnval= ktpx[kk].keytitle;
         break;
         case "dxtype":
             rtnval= ktpx[kk].dxtype;
         break;
         default:
       }//swc
      }//if
     }//for
     if (mtd=="showkeys"){
       return killlasttring(fmval);
     }else{
       return rtnval;
     }
 }
 function maketbheadx($skeyx,$kxtp,$cscs){
  $shokx=$skeyx;
  $srst=new Array();
  $tdxx=new Array();
  $partkx=explode(",",$shokx);
  $totptkx=countx($partkx);
  $trtr=turnlab($cscs["tabhdtr"]);
  $fmtd="";
  $ttt="";
  allkeys=",";
  for ($mx=0;$mx<$totptkx;$mx++){
   if ($partkx[$mx]!=""){
      $ttt=getkeyc($kxtp,$partkx[$mx],"title");
      dxtypex=getkeyc($kxtp,$partkx[$mx],"dxtype");
      $tdvl=$ttt;
      $datax=new Array();
      $tdxx=formtrowx($tdxx,$partkx[$mx],$tdvl,"-1","-1",-1,$srst);
      if (dftval($cscs[dxtypex+"th"],"")!=""){
        $maketdv=exchangeunit($tdxx,turnlab($cscs[dxtypex+"th"]),$datax,0);
      }else{
        $maketdv=exchangeunit($tdxx,turnlab($cscs["tabhdtd"]),$datax,0);  
      }
     $maketdv=one_replace("[inner]",$tdvl,$maketdv);
     $fmtd=$fmtd+$maketdv;
   }
  }  
  $trtr="<thead>"+one_replace("[inner]",$fmtd,$trtr)+"</thead>";
   return $trtr;
 }
 function inititemx(ccd){
 dsid=_get("dsid");
 snox=_get("SNO");
 lurl=decodeURIComponent(location.href);
 lurl=lurl.replace("dsid","odsid");
  if (snox==undefined || snox==""){
        snox="0";
        backtxt=ajaxhtmlpost("/localxres/funx/getdspcitem/?"+hou(lurl,"?")+"&dsid="+dsid+"&SNO=0","");  
  }else{
        backtxt=ajaxhtmlpost("/localxres/funx/getdspcitem/?"+hou(lurl,"?")+"&dsid="+dsid,"");  
  }
  backdata=eval('('+backtxt+')');
  keytpx=backdata.keytps;
  showkeys="/,";
  sks="";
  for (k=0;k<keytpx.length;k++){
      showkeys=showkeys+keytpx[k].keyid+",";
      sks=sks+keytpx[k].keyid+",";
  }
  sks=killlasttring(sks);
  $("#addform").attr("showkeys",sks);
  formtype=ccd["chtml"];
    $("#formtitle").html(backdata.datatitle);
  switch(formtype){
      case "multiline":
  
          tabcls=backdata.tabcls;
  
          tabt=qian(tabcls,"|");
          tabc=hou(tabcls,"|");
          pttt=tabt.split(",");
          pttc=tabc.split(",");
          tott=pttt.length;
          fmtabtop="";
          fmtabbody="";
          for (tt=0;tt<tott;tt++){
              actx=qian(ccd["inline"],"::");
              topx=hou(ccd["inline"],"::");
              //tabActive::{span class="tabBtn [labcode]"}[labtitle]{/span}
              if (tt==0){
                topx=topx.replace("[labcode]",actx);
                topx=topx.replace("[labtitle]",pttt[tt]);
              }else{
                topx=topx.replace("[labcode]","");  
                topx=topx.replace("[labtitle]",pttt[tt]);
              }
              fmtabtop=fmtabtop+topx;
              duoact=qian(ccd["duorow"],"::");
              duorow=hou(ccd["duorow"],"::");
              fmrow="";
              for (k=0;k<keytpx.length;k++){
                   dztp=keytpx[k].dxtype;
                   if (dztp.indexOf("archar")>0){
                       dxtp="varchar";
                   }else{f
                       dxtp=dztp;
                   }
                   colnm=keytpx[k].keyid;
                   coltitle=keytpx[k].keytitle;
                   keyexp=keytpx[k].keyexp;
                   if (keytpx[k].classp==pttc[tt]){
                       onerow=ccode["onerow"];
                       
                      if (dftval(ccode[dxtp+"SRD"],"")==""){
                         itemsrd=ccode["itemsrd"];
                         srddemo=itemsrd;
                       }else{
                         srddemo=ccode[dxtp+"SRD"];
                       }       
                       
                       srddemo=srddemo.replace(/\[key\]/g,colnm);
                       srddemo=srddemo.replace(/\[title\]/g,coltitle);
                       srddemo=srddemo.replace(/\[dxtp\]/g,dxtp);
                       srddemo=srddemo.replace(/\[rdol\]/g,"");
                       srddemo=srddemo.replace(/\[dspl\]/g,"");
                       srddemo=srddemo.replace(/\[exp\]/g,keyexp);
                       onerow=onerow.replace("[rowx]",srddemo);
                       onerow=onerow.replace(/\[key\]/g,colnm);
                       onerow=onerow.replace(/\[title\]/g,coltitle);
                       onerow=onerow.replace(/\[dxtp\]/g,dxtp);
                       onerow=onerow.replace(/\[rdol\]/g,"");
                       onerow=onerow.replace(/\[dspl\]/g,"");
                       onerow=onerow.replace(/\[exp\]/g,keyexp);
                       if (dxtp!="chtml"){
                         fmrow=fmrow+onerow;
                       }
                   }//ifclassp==pttc
              }//for k==0
              duorow=duorow.replace("[tabx]",fmrow);
              if (tt==0){
                 duorow=duorow.replace("[clscode]",duoact);    
              }else{
                 duorow=duorow.replace("[clscode]","");     
              }
              fmtabbody=fmtabbody+duorow;
          }//for tt
          //console.log(fmtabtop);
          $("#tabtop").html(turnlab(fmtabtop));
          $("#tabbody").html(turnlab(fmtabbody));
      break;
      case "plane":
          tabcls=backdata.tabcls;
          tabt=qian(tabcls,"|");
          tabc=hou(tabcls,"|");
          pttt=tabt.split(",");
          pttc=tabc.split(",");
          tott=pttt.length;
          fmdbody="";
          for (tt=0;tt<tott;tt++){

              duorow=ccd["duorow"];
              fmrow="";
              for (k=0;k<keytpx.length;k++){
                   dztp=keytpx[k].dxtype;
                   if (dztp.indexOf("archar")>0){
                       dxtp="varchar";
                   }else{
                       dxtp=dztp;
                   }
                   colnm=keytpx[k].keyid;
                   coltitle=keytpx[k].keytitle;
                   keyexp=keytpx[k].keyexp;
                   if (qian(keytpx[k].sqx,".")==pttc[tt]){
                      if (dftval(ccode[dxtp+"INLINE"],"")==""){
                         itemsrd=ccode["inline"];
                         srddemo=itemsrd;
                       }else{
                         srddemo=ccode[dxtp+"INLINE"];
                       }       
                       srddemo=srddemo.replace(/\[key\]/g,colnm);
                       srddemo=srddemo.replace(/\[title\]/g,coltitle);
                       srddemo=srddemo.replace(/\[dxtp\]/g,dxtp);
                       srddemo=srddemo.replace(/\[rdol\]/g,"");
                       srddemo=srddemo.replace(/\[dspl\]/g,"");
                       srddemo=srddemo.replace(/\[exp\]/g,keyexp);
                       if (dxtp!="chtml"){
                        fmrow=fmrow+srddemo;
                       }
                   }//ifclassp==pttc
              }//for k==0
              duorow=duorow.replace("[rowx]",fmrow);
              fmdbody=fmdbody+duorow;
          }
          $("#dbody").html(turnlab(fmdbody));
      break;
      default:
          fmrow="";
              for (k=0;k<keytpx.length;k++){
                      dztp=keytpx[k].dxtype;
                      if (dztp.indexOf("archar")>0){
                       dxtp="varchar";
                      }else{
                       dxtp=dztp;
                      }
                      colnm=keytpx[k].keyid;
                      coltitle=keytpx[k].keytitle;
                      keyexp=keytpx[k].keyexp;
                      onerow=ccode["onerow"];
                     if (dftval(ccode[dxtp+"SRD"],"")==""){
                         itemsrd=ccode["itemsrd"];
                         srddemo=itemsrd;
                      }else{
                         srddemo=ccode[dxtp+"SRD"];
                      }       
                      srddemo=srddemo.replace(/\[key\]/g,colnm);
                      srddemo=srddemo.replace(/\[title\]/g,coltitle);
                      srddemo=srddemo.replace(/\[dxtp\]/g,dxtp);
                      srddemo=srddemo.replace(/\[rdol\]/g,"");
                      srddemo=srddemo.replace(/\[dspl\]/g,"");
                      srddemo=srddemo.replace(/\[exp\]/g,keyexp);
                      onerow=onerow.replace("[rowx]",srddemo);
                      onerow=onerow.replace(/\[key\]/g,colnm);
                      onerow=onerow.replace(/\[title\]/g,coltitle);
                      onerow=onerow.replace(/\[dxtp\]/g,dxtp);
                      onerow=onerow.replace(/\[rdol\]/g,"");
                      onerow=onerow.replace(/\[dspl\]/g,"");
                      onerow=onerow.replace(/\[exp\]/g,keyexp);
                      if (dxtp!="chtml"){
                        fmrow=fmrow+onerow;
                      }
              }//for k==0
             $("#dbody").html(turnlab(fmrow));
      
  }
 srst=jsontosx(backdata);
 arrdt=arrdata(srst);
  for (k=0;k<keytpx.length;k++){
   dztp=keytpx[k].dxtype;
     if (dztp.indexOf("archar")>0){
        dxtype="varchar";
     }else{
        dxtype=dztp;
     }
   colname=keytpx[k].keyid;
   coltitle=keytpx[k].keytitle;
   if (showkeys.indexOf(colname)>0 || dftval(GetRequest().dbmk,"")==""){
    valdemo=ccd[dxtype];
    $binfo=new Array();
    thisval="";
    hexval="";
    eval('hexval=backdata.vls[0].'+colname+';');  
    eval('thisval=tostring(backdata.vls[0].'+colname+');');  
    $binfo=formtrowx($binfo,colname,hexval,snox,"",1,arrdt);
    $binfo["showkeys"]=showkeys;
    $binfo["tablename"]=backdata.datamark;
    $binfo["shortid"]=backdata.datamark;
    $binfo["dxtype"]=dxtype;
    $binfo["ktitle"]=coltitle;
    $binfo["clstxt"]=keytpx[k].clstxt;
    $binfo["kexplain"]=keytpx[k].keyexp;
    if (valdemo!=undefined){
      valdemo=exchangeunit($binfo,valdemo,arrdt,1);
      $("#eleof"+colname).html(valdemo);
    }else{
      $("#eleof"+colname).html("");
    }//if valdemo
    
  }else{
    
  }//iftabkeys
 }//for
 
for (k=0;k<keytpx.length;k++){
   dztp=keytpx[k].dxtype;
     if (dztp.indexOf("archar")>0){
        dxtype="varchar";
     }else{
        dxtype=dztp;
     }
   colname=keytpx[k].keyid;
   coltitle=keytpx[k].keytitle;
     $binfo=new Array();
     if (showkeys.indexOf(colname)>0 || dftval(GetRequest().dbmk,"")==""){
       thisval="";
       hexval="";
        eval('hexval=backdata.vls[0].'+colname+';'); 
        eval('thisval=tostring(backdata.vls[0].'+colname+');'); 
       $binfo=formtrowx($binfo,colname,hexval,snox,"",1,arrdt);
       $binfo["showkeys"]=showkeys;
       $binfo["tablename"]=backdata.datamark;
       $binfo["shortid"]=backdata.datamark;
       $binfo["dxtype"]=dxtype;
       $binfo["ktitle"]=coltitle;   
       $binfo["clstxt"]=keytpx[k].clstxt;
       fundemo=ccd[dxtype+"FUNCTION"];
       if (fundemo!=undefined && fundemo!=""){
         fundemo=exchangeunit($binfo,fundemo,arrdt,1);
         eval(fundemo);
       };
     }//col dbnm
   }//for
     srdeval=ccd["srdFUNCTION"];
     if (srdeval!=undefined && srdeval!=""){
          eval(srdeval);
     }
   return true;
}
function jsontab(purl,tbnm,atpage,sidx,pnum){
       purl=purl+"&datatype=json";
       bkdata=ajaxhtmlpost(purl,"");
       datax=eval('('+bkdata+')');
       sxy=jsontosx(datax);
       //console.log(sxy);
             $jsonx=new Array();
             $jsonx["totrcd"]=datax.totrcd;
             $jsonx["json"]=datax;
             //console.log($tabinfo["tmpdtx"]+"---");
             $jsonx["keys"]=datax.keys;
             $jsonx["sxy"]=sxy;
             $jsonx["url"]=purl;
           //console.log("beforecodetab");
        ccdhtml=sessionStorage.ccdhtml;
        jsondata=datax;
        sid=sidx;
        spage=atpage;
        spnum=pnum;
        allsc=sessionStorage.allsc;
        xk=sessionStorage.xk;
        xv=sessionStorage.xv;
         

         bkdata=anytab(sxy,jsondata,sid,tbnm,spage,intval(spnum));

          bktable=bkdata["tabdata"];
          pagecode=bkdata["pagehtml"];  
          tabeval=bkdata["exteval"];

         if (bktable!=""){
           //$("form[name='tabform']").html(bktable);
           //$('.loadingBox').attr('data-show', 0);
           n=savehtmltolc(sid,bktable);
           $("#pageskin").html(pagecode);
           oprteval();
           if (tabeval!=""){
           //console.log(tabeval);
            eval(tabeval); //这个也是传过来的执行
           }; 
           listenclsduo();
         }else{
            if (tabeval!=""){
              cssd=_get("cssd");   
              if (cssd=="1"){
                oprtevalx();
              }else{
                oprteval();  
              }
            }
            listenclsduo();
         }
         sessionStorage.init="0";
}
function inititem(ccd){
 stid=dftval($("#addform").attr("shortid"),qian(_get("stid"),"-"));
 snox=dftval(GetRequest().SNO,"");
 lurl=decodeURIComponent(location.href);
 lurl=lurl.replace("stid","ostid");


  if (snox==undefined || snox==""){
        snox="0";
        backtxt=ajaxhtmlpost("/localxres/funx/anyitem/?"+hou(lurl,"?")+"&stid="+stid+"&SNO=0&dbmk="+dftval(_get("dbmk"),""),"");  
  }else{
        backtxt=ajaxhtmlpost("/localxres/funx/anyitem/?"+hou(lurl,"?")+"&stid="+stid+"&dbmk="+dftval(_get("dbmk"),""),"");  
  }
  backdata=eval('('+backtxt+')');

 srst=jsontosx(backdata);
 arrdt=arrdata(srst);
 showkeys=backdata.detailkeys;
 tabkeys=","+showkeys;
 dxtypes=backdata.dxtypes;
 ptkeys=showkeys.split(",");
 ptdtps=dxtypes.split(",");
 ptdxs="";
 totp=ptkeys.length;
  $sbase=shortinfo(stid);
  eval("$gkinfo="+$sbase["tablename"]+"kbase;");
 for (i=0;i<totp;i++){
   dxtype=ptdtps[i];
   colname=ptkeys[i];
   if (tabkeys.indexOf(colname)>0 || dftval(GetRequest().dbmk,"")==""){
    if ($gkinfo[colname]["COLUMN_SSHOW"]=="" ){
     valdemo=ccd[dxtype];
     //console.log("ccd-"+valdemo);
    }else{
     valdemo=tostring($gkinfo[colname]["COLUMN_SSHOW"]);  
     //console.log("ssh-"+valdemo)
    }//if gkinfo
    $binfo=new Array();
    thisval="";
    hexval="";
    v0=$gkinfo[colname]["COLUMN_VALUEZERO"];
    cange=$gkinfo[colname]["COLUMN_CANGE"];
    dspl=$gkinfo[colname]["COLUMN_DSPLD"];
    if (snox=="0"){
      if (v0.indexOf("thusvalue")>0){
        $thusvalue="";
        eval(v0);
        thisval=$thusvalue;
        hexval=$thusvalue;
      }else{
        eval('hexval=backdata.'+colname+';'); 
        eval('thisval=tostring(backdata.'+colname+');'); 
      }
     }else{
      eval('hexval=backdata.'+colname+';');  
      eval('thisval=tostring(backdata.'+colname+');');  
     }//if snox
     
    $binfo=formtrow($binfo,colname,hexval,snox,"",$gkinfo,$sbase,1,arrdt);
    if (valdemo!=undefined){
      $clstxtx=$gkinfo[colname]["COLUMN_CLSTXT"];
      valdemo=exchangeunit($binfo,valdemo,arrdt,1);
      $("#eleof"+colname).html(valdemo);
    }else{
      $("#eleof"+colname).html("");
    }//if valdemo
    
  }else{
    
  }//iftabkeys
 }//for
 
   if (snox=="0"){
     olmkdemo="<input id=\"p_"+$("#addform").attr("olmkkey")+"\" value=\""+randomWord(false,10)+"\" readonly>";
     $("#eleof"+$("#addform").attr("olmkkey")).html(olmkdemo);
   }
   for (i=0;i<totp;i++){
     dxtype=ptdtps[i];
     colname=ptkeys[i];
     valdemo=ccd[dxtype];
     $binfo=new Array();
     if (tabkeys.indexOf(colname)>0 || dftval(GetRequest().dbmk,"")==""){
       thisval="";
        eval('hexval=backdata.'+colname+';'); 
        eval('thisval=tostring(backdata.'+colname+');'); 
       $binfo=formtrow($binfo,colname,hexval,snox,"",$gkinfo,$sbase,1,arrdt);
       if ($gkinfo[colname]["COLUMN_SSHOW"]=="" ){
         fundemo=ccd[dxtype+"FUNCTION"];
       }else{
         fundemo=tostring($gkinfo[colname]["COLUMN_JSHOW"]);  
       }
       if (fundemo!=undefined && fundemo!=""){
         fundemo=exchangeunit($binfo,fundemo,arrdt,1);
         eval(fundemo);
       };
     }//col dbnm
   }//for
     srdeval=ccd["srdFUNCTION"];
     if (srdeval!=undefined && srdeval!=""){
          eval(srdeval);
     }
   return true;
}
function initdata(){
 ccd=ccode;    
 
 sessionStorage.latesturl=decodeURIComponent(location.href);
 sessionStorage.latesttitle=document.title;
 sessionStorage.init="1";
 zzz=setTimeout("getmyip()", 3000);
 prehref=decodeURIComponent(location.href);
 stidx=dftval(GetRequest().stid,qian(_get("stid"),"-"));
 stid=qian(stidx,"-");
 if (stidx.indexOf("pnum:")>0){
   pn=qian(hou(stidx,"pnum:"),"-");
 }else{
   pn="30";     
 }
 urlpgn=dftval(GetRequest().pnum,pn);
 pnkey="";
 if (urlpgn.indexOf(":")>0){
     pnkey=hou(urlpgn,":");
     upn=qian(urlpgn,":");
 }else{
     upn=urlpgn;
 }
 mainpn=dftval(upn,pn);
 tabe=$('table[name="tabunit"]');
 for (t=0;t<tabe.length;t++){
     tupnum=dftval($(tabe[t]).attr("pnum"),"");
     sid=dftval($(tabe[t]).attr("shortid"),stid);
     tbnm=dftval($(tabe[t]).attr("tbname"),"");
     if (tupnum=="[pnum]" || tupnum==""){
         tabnum=dftval(mainpn,"30")
     }else{
         tabnum=tupnum;
     }
    sessionStorage.dpage=0;   
    tmpdft="";
    eval("tmpdft=typeof(STDFT"+sid+");");
    houhref=hou(prehref,"?");
    pthref=houhref.split("&");
    totp=pthref.length;
    fmxxx="";
    pppp="";
    for (i=0;i<totp;i++){
      if (qian(pthref[i],"=")!="page" && qian(pthref[i],"=")!="pnum" && qian(pthref[i],"=")!="xkey"  && qian(pthref[i],"=")!="xval"  && qian(pthref[i],"=")!="qry"  && qian(pthref[i],"=")!="stid" && qian(pthref[i],"=")!="datatype"){
         fmxxx=fmxxx+"&"+pthref[i];
      }
    }

    qry=dftval(GetRequest().qry,"");
    if (qry!=""){
        qry=base64Decode(qry);
        sessionStorage.qry=mkstr(qry);
    }
     urlpage=dftval(GetRequest().page,"1");
     prepage=qian(urlpage,":");
     pagekey=hou(urlpage,":");

    if (pnkey!=""){
        urlpn=dftval(tabnum,mainpn)+":"+pnkey;
    }else{
        urlpn=dftval(tabnum,mainpn);
    }
     pppp="&page="+urlpage+"&pnum="+urlpn+"&qry="+mkstr(qry);
     purl="/localxres/funx/anyshort/?stid="+sid+"-pnum:"+tabnum+"-"+pppp+fmxxx;
     sessionStorage.pnum=urlpn;
     sessionStorage.page=urlpage;
     //console.log("urlpn-"+urlpn);
     sessionStorage.ppnum=intval(mainpn);
     sessionStorage.sid=sid;
     sessionStorage.tbnm=tbnm;
     sessionStorage.spage=prepage;
     sessionStorage.spnum=mainpn;
     sessionStorage.allsc="";
     sessionStorage.xk="";
     sessionStorage.xv="";
     if (sid!=""){
       console.log("正在寻找表"+t+"，发现参数:"+purl);
       atpage=prepage;
       sidx=sid;
       pnum=intval(mainpn);
       purl=purl.replace("anyjsshort","anyshort");
       purl=purl+"&datatype=json";
       bkdata=ajaxhtmlpost(purl,"");
       datax=eval('('+bkdata+')');
       sxy=jsontosx(datax);
       sessionStorage.allkeys=datax.keys;
       //console.log(sxy);
        $jsonx=new Array();
        $jsonx["totrcd"]=datax.totrcd;
        $jsonx["json"]=datax;
        //console.log($tabinfo["tmpdtx"]+"---");
        $jsonx["keys"]=datax.keys;
        $jsonx["sxy"]=sxy;
        $jsonx["url"]=purl;
         //console.log("beforecodetab");
        ccdhtml=sessionStorage.ccdhtml;
        jsondata=datax;
        sid=sidx;
        spage=atpage;
        spnum=pnum;
        allsc=sessionStorage.allsc;
        xk=sessionStorage.xk;
        xv=sessionStorage.xv;

        bkdata=anytab(sxy,jsondata,sid,tbnm,spage,intval(spnum));

       bktable=bkdata["tabdata"];
       pagecode=bkdata["pagehtml"];  
       tabeval=bkdata["exteval"];
        
         if (bktable!=""){
           //$("form[name='tabform']").html(bktable);
           //$('.loadingBox').attr('data-show', 0);
           //n=savehtmltolc(sid,bktable);
           $("#pageskin").html(pagecode);
           oprteval();
           if (tabeval!=""){
           //console.log(tabeval);
            eval(tabeval); //这个也是传过来的执行
           }; 
           listenclsduo();
         }else{
            if (tabeval!=""){
                oprteval();
            }
            listenclsduo();
         }
         sessionStorage.init="0";
     }else{
         console.log("正在寻找表"+t+"未发现参数");
     }
 }
}
function initdatax(){
 ccd=ccode;
 sessionStorage.latesturl=decodeURIComponent(location.href);
 sessionStorage.latesttitle=document.title;
 sessionStorage.init="1";
 zzz=setTimeout("getmyip()", 3000);
 prehref=decodeURIComponent(location.href);
 dsid=_get("dsid");
 dsst=_get("dsst");
  tabe=$('table[name="tabunit"]');
 for (t=0;t<tabe.length;t++){
    tmpdft="";
    houhref=hou(prehref,"?");
    pthref=houhref.split("&");
    totp=pthref.length;
    fmxxx="";
    pppp="";
    for (i=0;i<totp;i++){
      if (qian(pthref[i],"=")!="page" && qian(pthref[i],"=")!="pnum" && qian(pthref[i],"=")!="xkey"  && qian(pthref[i],"=")!="xval"  && qian(pthref[i],"=")!="qry"  && qian(pthref[i],"=")!="stid" && qian(pthref[i],"=")!="datatype"){
         fmxxx=fmxxx+"&"+pthref[i];
      }
    }

    qry=dftval(GetRequest().qry,"");
    if (qry!=""){
        qry=base64Decode(qry);
        sessionStorage.qry=mkstr(qry);
    }

     pppp="&qry="+mkstr(qry);
     purl="/localxres/funx/getdspcdata/?datamark="+dsid+"&datatype=jsshort"+pppp+fmxxx;

     sessionStorage.sid=dsst;
     sessionStorage.tbnm=dsid;
     sessionStorage.allsc="";
     sessionStorage.xk="";
     sessionStorage.xv="";
     if (dsid!=""){
         console.log("正在寻找数据空间"+dsid+"，发现参数:"+purl);
        z=codedspc(purl,dsid,dsst);
     }else{
         console.log("正在寻找数据空间"+dsid+"未发现参数");
     }
 }
}

function initall(ccd,kcd){
 sessionStorage.latesturl=decodeURIComponent(location.href);
 sessionStorage.latesttitle=document.title;
 sessionStorage.init="1";
 prehref=decodeURIComponent(location.href);
 tabe=$('table[name="tabunit"]');
 for (t=0;t<tabe.length;t++){
     sid=dftval($(tabe[t]).attr("shortid"),"");
     tbnm=dftval($(tabe[t]).attr("tbname"),"");
     tmpdft="";
     eval("tmpdft=typeof(STDFT"+sid+");");
     purl="/localxres/funx/anyshort/?stid="+sid+"&ssmark="+makepagesession()+"&rnd="+getRandChar(6);
     z=jsontab(purl,tbnm,1,sid,10000);
 }
}

function codedspc(purl,dscd,stcd){
       bkdata=ajaxhtmlpost(purl,"");
       datax=eval('('+bkdata+')');
       sxy=jsontosx(datax);
       dspc=new Array();
       dspc=anydspc(sxy,datax,stcd,dscd);
       dspcdata=dspc["dsdata"];
       tabeval=bkdata["exteval"];
       document.title=datax.datatitle;
       if (dspcdata!=""){
        $("form[name='tabform']").html(dspcdata);
         $('.loadingBox').attr('data-show', 0);
         n=savehtmltolc(stcd,dspcdata);
         oprteval();
         if (tabeval!=""){
           eval(tabeval); //这个也是传过来的执行
         };
         
         listenclsduo();
       }
}

function getdxtype(jd,$kx){
var tpvv="";
if (jd.ktps!=undefined){
 for (g=0;g<jd.ktps.length;g++){
     kkx=jd.ktps[g].keyname;
     if (kkx==$kx){
         tpvv=jd.ktps[g].dxtype;
     }
 }
}else{
 for (g=0;g<jd.keytps.length;g++){
     kkx=jd.keytps[g].keyid;
     if (kkx==$kx){
         tpvv=jd.keytps[g].dxtype;
     }
 }  
}
 if (tpvv==""){
     return "varchar";
 }else{
     return tpvv;
 }
}
//以下是表格拼接合成
function anytab($frsts,$jsondata,$shortid,$tabnm,$page,$pnum){
    //数据与字段模板合成表格模型算法
    console.log($jsondata);
    console.log("进入表格合成-tabnm:"+$tabnm+"--shortid:"+$shortid+"--页page:"+$page+"数量pnum:"+$pnum);
 $fmch="";
 $pgnum=$pnum;
 $pgnum=dftval($pgnum,"30");
 $page=dftval($page,"1");
 $binfo=new Array();
 $allsc="";
 $xk="";
 $xv="";
 $cshtml="";
 $totallrst=$jsondata.totrcd;
 $totrcd=$jsondata.vls.length;
 $arraydata=arrdata($frsts); 
 console.log("arrdata==="+$arraydata);
 $result=$frsts;
 $sresult=$arraydata;
 jsondata=$jsondata;
  eval("$gkinfo="+$tabnm+"kbase;");
  eval("$ccs=ccode;");
  
  //console.log($gkinfo);
  //console.log($ccs);
  //console.log($kcs);
  sessionStorage.prepage=$page;
  sessionStorage.totrcd=$totallrst;
  sessionStorage.totpage=ceil($totallrst/$pgnum);
  
  
  
  $sbase=shortinfo($shortid);
  $shoks=$jsondata.keys;
  $tabnm=$sbase["tablename"];
  $kpart=explode(",",$shoks);
  $totk=countx($kpart);  
  $partk=explode(",",$shoks);
  
  $totptk=countx($partk); 
  $kdemo="";
  console.log("tbshok-"+$shoks);
  $tablehd=maketbhead($shoks,$gkinfo,$ccs,$sbase);   
  
  $pghtml=makepagerow($pgnum,$page,$totallrst,$shortid,$ccs,$allsc,$xk,$xv);

  pskey=dftval($('table[name="tabunit"]').attr("pskey"),"");
  pstitle=dftval($('table[name="tabunit"]').attr("pstitle"),"");
  pshead=dftval($('table[name="tabunit"]').attr("pshead"),"");
  pssno=dftval($('table[name="tabunit"]').attr("pssno"),"SNO");
  console.log("pskey:"+pskey+",pstitle:"+pstitle+",pshead:"+pshead+",pssno:"+pssno);
  //之后加上denykey
  $fmhtmlx="";
  $sbase["pnum"]=$pgnum;
  $sbase["page"]=$page;  
  $fmextscript="";
  $csurd=turnlab($ccs["tabdemo"]);
  
  for ($ti=1;$ti<($totrcd+1);$ti++){   
    $fmtrinner="";
    $fmtrouter=turnlab($ccs["tabtr"]);
     if (pssno!=""){
       $fmtrouter=one_replace("[thissno]",$arraydata[pssno][$ti],$fmtrouter,6);
       $fmtrouter=one_replace("[SNO]",$arraydata[pssno][$ti],$fmtrouter,6);
       $fmtrouter=one_replace("[sqx]",$ti,$fmtrouter,6);
     }else{
       tmpsnornd=getRandChar(6);
       $fmtrouter=one_replace("[thissno]",tmpsnornd,$fmtrouter,6);
       $fmtrouter=one_replace("[SNO]",tmpsnornd,$fmtrouter,6);
       $fmtrouter=one_replace("[sqx]",$ti,$fmtrouter,6);
     }
  
    for ($j=0;$j<$totptk;$j++){ 
      //console.log("j="+$j);
      //console.log("partk:"+$partk[$j]);
         $tdxtp=getdxtype($jsondata,$partk[$j]);
        //console.log("发现存在于"+$partk[$j]+"中类型为:"+$tdxtp);
         $olmkx="";
         if (pssno!=""){
          $binfo=formtrow($binfo,$partk[$j],$arraydata[$partk[$j]][$ti],$arraydata[pssno][$ti],$olmkx,$gkinfo,$sbase,$ti,$arraydata);
          //console.log($binfo);
         }else{
           $binfo=formtrow($binfo,$partk[$j],$arraydata[$partk[$j]][$ti],getRandChar(),$olmkx,$gkinfo,$sbase,$ti,$arraydata);  
         }
         $tdcode0="";
         $tdcode1=dftval($tdcode0,$ccs[$tdxtp+"td"]);
         $tdcode=dftval($tdcode1,$ccs["tabtd"]);
         $colname=$partk[$j];
         if (pssno!=""){
           $snox=$arraydata[pssno][$ti];
         }
         $ktitle=$binfo["ktitle"];
         $dtype=$tdxtp;
         $clstxt=$binfo["clstxt"];
         $thusvalue=$arraydata[$partk[$j]][$ti];
         $thisvalue=$arraydata[$partk[$j]][$ti];
         thisval=$thusvalue;
         thissqn=$ti;
         ssshow=dftval("",$gkinfo[$partk[$j]]["COLUMN_SSHOW"]);
         
         if (ssshow!=""){
             $valdemo=tostring(ssshow);
             $valdemo=$valdemo.replace(/\\\'/g,'\'');
             if ($valdemo.indexOf("unctionx(")>0){
                 daxx="";//数据区域
                 vrr="";//取值范围
                 dkeyxx=$colname;//字段名
                 dtypexx=$dtype;//显示类型
                 ctxtxx=$clstxt;//分类选项
                 dvalxx=thisval;//当前值
                 snoxx=$snox;//序号
                 dnn=thissqn;//第几行
                 jsondataxx=$jsondata;
                 funnm=qian(hou($valdemo,"("),")");
                 eval('$valdemo='+funnm+'(daxx,vrr,dkeyxx,dtypexx,ctxtxx,dvalxx,snoxx,dnn,jsondataxx);');
             }
             
             jsshowx=dftval("",$gkinfo[$partk[$j]]["COLUMN_JSHOW"]);
             if (jsshowx!=""){
               $tmpscript=exchangeunit($binfo,tostring(jsshowx),$arraydata,$ti);
               $fmextscript=combinestr3($fmextscript,$tmpscript,huanhang());
             }else{
               $tmpscript="";  
             } 
            
         }else{
              $valdemo=dftval("",tostring($ccs[$tdxtp]));
              $valdemo=$valdemo.replace(/\\\'/g,'\'');
              if ($valdemo.indexOf("unctionx(")>0){
                 daxx="";//数据区域
                 vrr="";//取值范围
                 dkeyxx=$colname;//字段名
                 dtypexx=$dtype;//显示类型
                 ctxtxx=$clstxt;//分类选项
                 dvalxx=thisval;//当前值
                 snoxx=$snox;//序号
                 dnn=thissqn;//第几行
                 jsondataxx=$jsondata;
                 funnm=qian(hou($valdemo,"("),")");
                 eval('$valdemo='+funnm+'(daxx,vrr,dkeyxx,dtypexx,ctxtxx,dvalxx,snoxx,dnn,jsondataxx);');
              }
              $sfunx=dftval("",$ccs[combinestr2($tdxtp,"FUNCTION")]);
            if ($sfunx!=""){
              $tmpscript=exchangeunit($binfo,$sfunx,$arraydata,$ti);
              $fmextscript=combinestr3($fmextscript,$tmpscript,huanhang());
            }else{
              $tmpscript="";
            }
         }
         
         if ($valdemo.indexOf("unctionx(")>0){
         }else{
           $acthtm="";
           $tdinner=exchangeunit($binfo,$valdemo,$arraydata,$ti);
         }
         
        //console.log($tdxtp);
        //console.log($tdinner);
         $tdcode=exchangeunit($binfo,$tdcode,$arraydata,$ti);
         $tdcode=$tdcode.replace(/@IN@/g,"inner");
         $comux=one_replace("{inner}",$tdinner,$tdcode,1);
         $comux=one_replace("[inner]",$tdinner,$comux,1);
         $comux=$comux.replace(/@IN@/g,"inner");
         $fmtrinner=$fmtrinner+$comux;
     };//有空加OPRT for j
     if ($totptk>0){
       if (strpos($fmtrouter,"{inner}")>0){
         $fmhtmlx=combinestr2($fmhtmlx,one_replace("{inner}",$fmtrinner,$fmtrouter,1));
       }else{
         $fmhtmlx=combinestr2($fmhtmlx,one_replace("[inner]",$fmtrinner,$fmtrouter,1));
       }
     }
   }//有必要的时候加上统计行  for i
   $onlyrow=$fmhtmlx;
   $stb=$sbase;
   $btnhtm=new Array();
   $dsplnone="display:none;";

   $fmtable=$tablehd+"<tbody>"+$fmhtmlx+"</tbody>";

   //console.log("tabhead-"+$tablehd);
   $fmtable=one_replace("{tablename}",$stb["tablename"],$fmtable,6);
   $fmtable=one_replace("{tablenm}",$stb["tablename"],$fmtable,6);
   $fmtable=one_replace("{tabnm}",$stb["tablename"],$fmtable,6);
   $fmtable=one_replace("{tabkeys}",$stb["showkeys"],$fmtable,6);
   $fmtable=one_replace("{pskey}",pskey,$fmtable,6);
   $fmtable=one_replace("{pstitle}",pstitle,$fmtable,6);
   $fmtable=one_replace("{pshead}",pshead,$fmtable,6);
   $fmtable=one_replace("{pssno}",pssno,$fmtable,6);
   $fmtable=one_replace("{sttab}",$stb["tablename"],$fmtable,6);
   $fmtable=one_replace("{stid}",$stb["tablename"],$fmtable,6);
   $fmtable=one_replace("{shortid}",$stb["shortid"],$fmtable,6);
   $fmtable=one_replace("{makecdt}",$stb["makecdt"],$fmtable,6);
   $fmtable=one_replace("{allcdt}",$stb["allcdt"],$fmtable,6);
   $fmtable=one_replace("{pnum}",$stb["pnum"],$fmtable,6);
   $fmtable=one_replace("{page}",$stb["page"],$fmtable,6);   
   $fmtable=one_replace("{shorttitle}",$stb["shorttitle"],$fmtable,6);  
   $fmtable=one_replace("{asc}",$stb["asc"],$fmtable,6);  
   $fmtable=one_replace("{xkey}",$stb["xkey"],$fmtable,6);  
   $fmtable=one_replace("{xval}",$stb["xval"],$fmtable,6);  
   $fmtable=all_replace("{dsplnone}","display:none;",$fmtable); 
   $fmtable=all_replace("{readonly}","readonly",$fmtable);  
   $fmtable=all_replace("\\[tablename\\]",$stb["tablename"],$fmtable);
   $fmtable=all_replace("\\[tablenm\\]",$stb["tablename"],$fmtable);
   $fmtable=all_replace("\\[tabnm\\]",$stb["tablename"],$fmtable);
   $fmtable=all_replace("\\[sttab\\]",$stb["tablename"],$fmtable);
   $fmtable=all_replace("\\[tabkeys\\]",$stb["showkeys"],$fmtable);
   $fmtable=all_replace("\\[pskey\\]",pskey,$fmtable);
   $fmtable=all_replace("\\[pstitle\\]",pstitle,$fmtable);
   $fmtable=all_replace("\\[pshead\\]",pshead,$fmtable);
   $fmtable=all_replace("\\[pssno\\]",pssno,$fmtable);
   $fmtable=all_replace("\\[stid\\]",$stb["tablename"],$fmtable);
   $fmtable=all_replace("\\[shortid\\]",$stb["shortid"],$fmtable);
   $fmtable=all_replace("\\[makecdt\\]",$stb["makecdt"],$fmtable);
   $fmtable=all_replace("\\[allcdt\\]",$stb["allcdt"],$fmtable);
   $fmtable=all_replace("\\[pnum\\]",$stb["pnum"],$fmtable);
   $fmtable=all_replace("\\[page\\]",$stb["page"],$fmtable);   
   $fmtable=all_replace("\\[headx\\]",$stb["headx"],$fmtable);
   $fmtable=all_replace("\\[shorttitle\\]",$stb["shorttitle"],$fmtable);  
   $fmtable=all_replace("\\[asc\\]",$stb["asc"],$fmtable);  
   $fmtable=all_replace("\\[xkey\\]",$stb["xkey"],$fmtable);  
   $fmtable=all_replace("\\[xval\\]",$stb["xval"],$fmtable);  
   $fmtable=all_replace("\\[dsplnone\\]","display:none;",$fmtable);  
   $fmtable=all_replace("\\[readonly\\]","readonly",$fmtable);  
   $fmtable=all_replace("\\<tablename\\>",$stb["tablename"],$fmtable);
   $fmtable=all_replace("\\<tablenm\\>",$stb["tablename"],$fmtable);
   $fmtable=all_replace("\\<tabnm\\>",$stb["tablename"],$fmtable);
   $fmtable=all_replace("\\<sttab\\>",$stb["tablename"],$fmtable);
   $fmtable=all_replace("\\<tabkeys\\>",$stb["showkeys"],$fmtable);
   $fmtable=all_replace("\\<pskey\\>",pskey,$fmtable);
   $fmtable=all_replace("\\<pstitle\\>",pstitle,$fmtable);
   $fmtable=all_replace("\\<pshead\\>",pshead,$fmtable);
   $fmtable=all_replace("\\<pssno\\>",pssno,$fmtable);
   $fmtable=all_replace("\\<stid\\>",$stb["tablename"],$fmtable);
   $fmtable=all_replace("\\<shortid\\>",$stb["shortid"],$fmtable);
   $fmtable=all_replace("\\<makecdt\\>",$stb["makecdt"],$fmtable);
   $fmtable=all_replace("\\<allcdt\\>",$stb["allcdt"],$fmtable);
   $fmtable=all_replace("\\<pnum\\>",$stb["pnum"],$fmtable);
   $fmtable=all_replace("\\<page\\>",$stb["page"],$fmtable);   
   $fmtable=all_replace("\\<headx\\>",$stb["headx"],$fmtable);
   $fmtable=all_replace("\\<shorttitle\\>",$stb["shorttitle"],$fmtable);  
   $fmtable=all_replace("\\<asc\\>",$stb["asc"],$fmtable);  
   $fmtable=all_replace("\\<xkey\\>",$stb["xkey"],$fmtable);  
   $fmtable=all_replace("\\<xval\\>",$stb["xval"],$fmtable);  
   if ($totrcd>0 ){
    $cshtml=all_replace("{inner}",$fmch,$csurd);
    $csinner=$fmch;
    $cshtml=all_replace("\\[inner\\]",$fmch,$cshtml);
   }else{
    $cshtml="";
    $csinner="";
   };
   //maketable前把SBASE里的各种DIY 解析了
  
  $tab=new Array();
  $tab["cshtml"]=$cshtml;
  $tab["csinner"]=$csinner;
   tabhtml=all_replace("\\[tbheadbody\]",$fmtable,$csurd);
   tabhtml=all_replace("\\[tablename\]",$stb["tablename"],tabhtml);
   tabhtml=all_replace("\\[tablenm\]",$stb["tablename"],tabhtml);
   tabhtml=all_replace("\\[tabnm\]",$stb["tablename"],tabhtml);
   tabhtml=all_replace("\\[sttab\]",$stb["tablename"],tabhtml);
   tabhtml=all_replace("\\[tabkeys\]",$stb["showkeys"],tabhtml);
   tabhtml=all_replace("\\[pskey\]",pskey,tabhtml);
   tabhtml=all_replace("\\[pstitle\]",pstitle,tabhtml);
   tabhtml=all_replace("\\[pshead\]",pshead,tabhtml);
   tabhtml=all_replace("\\[pssno\]",pssno,tabhtml);
   tabhtml=all_replace("\\[stid\]",$stb["tablename"],tabhtml);
   tabhtml=all_replace("\\[shortid\]",$stb["shortid"],tabhtml);
   tabhtml=all_replace("\\[makecdt\]",$stb["makecdt"],tabhtml);
   tabhtml=all_replace("\\[allcdt\]",$stb["allcdt"],tabhtml);
   tabhtml=all_replace("\\[pnum\]",$stb["pnum"],tabhtml);
   tabhtml=all_replace("\\[page\]",$stb["page"],tabhtml);   
   
   $tab["tabdata"]=tabhtml;
   $tab["pagehtml"]=$pghtml;
   $tab["exteval"]=$fmextscript;
  return $tab;
}

function anydspc($frsts,$jsondata,$dsst,$dsid){
    //数据与字段模板合成表格模型算法
    console.log($jsondata);
    console.log("进入数据空间合成-dsst:"+$dsst+"--dsid:"+$dsid);
 $fmch="";
 
 $binfo=new Array();
 $allsc="";
 $xk="";
 $xv="";
 $cshtml="";
 $totallrst=$jsondata.totrcd;
 $totrcd=$jsondata.vls.length;
 $arraydata=arrdata($frsts); 
 console.log($arraydata);
 $result=$frsts;
 $sresult=$arraydata;
 jsondata=$jsondata;
  eval("$ccs=ccode;");
  
  $pghtml="";
  $shoks=getkeyc($jsondata.keytps,"","showkeys");
  $tabnm=dsid;
  $kpart=explode(",",$shoks);
  $totk=countx($kpart);  
  $partk=explode(",",$shoks);
  $totptk=countx($partk); 
  
  console.log("tbshok-"+$shoks);
  $tablehd=maketbheadx($shoks,$jsondata.keytps,$ccs);   
  
  //之后加上denykey
  $fmhtmlx="";
  $fmextscript="";
  $csurd=turnlab($ccs["tabdemo"]);
  console.log($totrcd);
  for ($ti=1;$ti<($totrcd+1);$ti++){   
    $fmtrinner="";
    $fmtrouter=turnlab($ccs["tabtr"]);
    pssno="datasno";
     if (pssno!=""){
       $fmtrouter=one_replace("[thissno]",$arraydata[pssno][$ti],$fmtrouter,6);
       $fmtrouter=one_replace("[SNO]",$arraydata[pssno][$ti],$fmtrouter,6);
       $fmtrouter=one_replace("[sqx]",$ti,$fmtrouter,6);
     }else{
       tmpsnornd=getRandChar(6);
       $fmtrouter=one_replace("[thissno]",tmpsnornd,$fmtrouter,6);
       $fmtrouter=one_replace("[SNO]",tmpsnornd,$fmtrouter,6);
       $fmtrouter=one_replace("[sqx]",$ti,$fmtrouter,6);
     }
  
    for ($j=0;$j<$totptk;$j++){ 
      //console.log("j="+$j);
      //console.log("partk:"+$partk[$j]);
         $tdxtp=getdxtype($jsondata,$partk[$j]);
        //console.log("发现存在于"+$partk[$j]+"中类型为:"+$tdxtp);
        if ($tdxtp.indexOf("archar")>0){
            $tdxtp="varchar";
        }
         $olmkx="";
         if (pssno!=""){
          $binfo=formtrowx($binfo,$partk[$j],$arraydata[$partk[$j]][$ti],$arraydata[pssno][$ti],$olmkx,$ti,$arraydata);
          //console.log($binfo);
           $binfo["clstxt"]="";
           $binfo["dxtype"]=$tdxtp;
         }else{
           $binfo=formtrowx($binfo,$partk[$j],$arraydata[$partk[$j]][$ti],getRandChar(),$olmkx,$ti,$arraydata);  
           $binfo["clstxt"]=getkeyc($jsondata.keytps,$partk[$j],"clstxt");
           $binfo["dxtype"]=$tdxtp;
         }
          if (dftval($ccs[$tdxtp+"td"],"")!=""){
             $tdcode=turnlab($ccs[$tdxtp+"td"]);
          }else{
             $tdcode=turnlab($ccs["tabtd"]);   
          }
         
         $colname=$partk[$j];
         if (pssno!=""){
           $snox=$arraydata[pssno][$ti];
         }
         $ktitle=getkeyc($jsondata.keytps,$partk[$j],"title");
         $dtype=$tdxtp;
         $clstxt=getkeyc($jsondata.keytps,$partk[$j],"clstxt");
         $thusvalue=$arraydata[$partk[$j]][$ti];
         $thisvalue=$arraydata[$partk[$j]][$ti];
         thisval=$thusvalue;
         thissqn=$ti;

            $valdemo=tostring($ccs[$tdxtp]);
            if ($valdemo!=undefined){
              $valdemo=$valdemo.replace(/\\\'/g,'\'');
            }else{
              $valdemo="";
            }

            if ($ccs[combinestr2($tdxtp,"FUNCTION")]!=""){
              $tmpscript=exchangeunit($binfo,$ccs[$tdxtp+"FUNCTION"],$arraydata,$ti);
              $fmextscript=combinestr3($fmextscript,$tmpscript,huanhang());
            }else{
              $tmpscript="";
            }

         $tdinner=exchangeunit($binfo,$valdemo,$arraydata,$ti);
        //console.log($tdxtp);
        //console.log($tdinner);
         $tdcode=exchangeunit($binfo,$tdcode,$arraydata,$ti);
         $tdcode=$tdcode.replace(/@IN@/g,"inner");
         $comux=one_replace("{inner}",$tdinner,$tdcode,1);
         $comux=one_replace("[inner]",$tdinner,$comux,1);
         $comux=$comux.replace(/@IN@/g,"inner");
         $fmtrinner=$fmtrinner+$comux;
     };//有空加OPRT for j
     if ($totptk>0){
       if (strpos($fmtrouter,"{inner}")>0){
         $fmhtmlx=combinestr2($fmhtmlx,one_replace("{inner}",$fmtrinner,$fmtrouter,1));
       }else{
         $fmhtmlx=combinestr2($fmhtmlx,one_replace("[inner]",$fmtrinner,$fmtrouter,1));
       }
     }
   }//有必要的时候加上统计行  for i
   $onlyrow=$fmhtmlx;
   $btnhtm=new Array();
   $dsplnone="display:none;";

   $fmtable=$tablehd+"<tbody>"+$fmhtmlx+"</tbody>";
  pskey="";
  pstitle="";
  pshead="";
  $sttt="";
   //console.log("tabhead-"+$tablehd);
   $fmtable=one_replace("{tablename}",$dsid,$fmtable,6);
   $fmtable=one_replace("{tablenm}",$dsid,$fmtable,6);
   $fmtable=one_replace("{tabnm}",$dsid,$fmtable,6);
   $fmtable=one_replace("{tabkeys}",$shoks,$fmtable,6);
   $fmtable=one_replace("{pskey}",pskey,$fmtable,6);
   $fmtable=one_replace("{pstitle}",pstitle,$fmtable,6);
   $fmtable=one_replace("{pshead}",pshead,$fmtable,6);
   $fmtable=one_replace("{pssno}","datasno",$fmtable,6);
   $fmtable=one_replace("{sttab}",$dsid,$fmtable,6);
   $fmtable=one_replace("{stid}",$dsst,$fmtable,6);
   $fmtable=one_replace("{shortid}",$dsst,$fmtable,6);
   $fmtable=one_replace("{makecdt}","",$fmtable,6);
   $fmtable=one_replace("{allcdt}","",$fmtable,6);
   $fmtable=one_replace("{pnum}","",$fmtable,6);
   $fmtable=one_replace("{page}","",$fmtable,6);   
   $fmtable=one_replace("{shorttitle}",$sttt,$fmtable,6);  
   $fmtable=one_replace("{asc}","",$fmtable,6);  
   $fmtable=one_replace("{xkey}","",$fmtable,6);  
   $fmtable=one_replace("{xval}","",$fmtable,6);  
   $fmtable=all_replace("{dsplnone}","display:none;",$fmtable); 
   $fmtable=all_replace("{readonly}","readonly",$fmtable);  
   $fmtable=one_replace("\\[tablename\\]",$dsid,$fmtable,6);
   $fmtable=one_replace("\\[tablenm\\]",$dsid,$fmtable,6);
   $fmtable=one_replace("\\[tabnm\\]",$dsid,$fmtable,6);
   $fmtable=one_replace("\\[tabkeys\\]",$shoks,$fmtable,6);
   $fmtable=one_replace("\\[pskey\\]",pskey,$fmtable,6);
   $fmtable=one_replace("\\[pstitle\\]",pstitle,$fmtable,6);
   $fmtable=one_replace("\\[pshead\\]",pshead,$fmtable,6);
   $fmtable=one_replace("\\[pssno\\]","datasno",$fmtable,6);
   $fmtable=one_replace("\\[sttab\\]",$dsid,$fmtable,6);
   $fmtable=one_replace("\\[stid\\]",$dsst,$fmtable,6);
   $fmtable=one_replace("\\[shortid\\]",$dsst,$fmtable,6);
   $fmtable=one_replace("\\[makecdt\\]","",$fmtable,6);
   $fmtable=one_replace("\\[allcdt\\]","",$fmtable,6);
   $fmtable=one_replace("\\[pnum\\]","",$fmtable,6);
   $fmtable=one_replace("\\[page\\]","",$fmtable,6);   
   $fmtable=one_replace("\\[shorttitle\\]",$sttt,$fmtable,6);  
   $fmtable=one_replace("\\[asc\\]","",$fmtable,6);  
   $fmtable=one_replace("\\[xkey\\]","",$fmtable,6);  
   $fmtable=one_replace("\\[xval\\]","",$fmtable,6);  
   $fmtable=all_replace("\\[dsplnone\\]","display:none;",$fmtable); 
   $fmtable=all_replace("\\[readonly\\]","readonly",$fmtable);  
   $fmtable=one_replace("\\<tablename\\>",$dsid,$fmtable,6);
   $fmtable=one_replace("\\<tablenm\\>",$dsid,$fmtable,6);
   $fmtable=one_replace("\\<tabnm\\>",$dsid,$fmtable,6);
   $fmtable=one_replace("\\<tabkeys\\>",$shoks,$fmtable,6);
   $fmtable=one_replace("\\<pskey\\>",pskey,$fmtable,6);
   $fmtable=one_replace("\\<pstitle\\>",pstitle,$fmtable,6);
   $fmtable=one_replace("\\<pshead\\>",pshead,$fmtable,6);
   $fmtable=one_replace("\\<pssno\\>","datasno",$fmtable,6);
   $fmtable=one_replace("\\<sttab\\>",$dsid,$fmtable,6);
   $fmtable=one_replace("\\<stid\\>",$dsst,$fmtable,6);
   $fmtable=one_replace("\\<shortid\\>",$dsst,$fmtable,6);
   $fmtable=one_replace("\\<makecdt\\>","",$fmtable,6);
   $fmtable=one_replace("\\<allcdt\\>","",$fmtable,6);
   $fmtable=one_replace("\\<pnum\\>","",$fmtable,6);
   $fmtable=one_replace("\\<page\\>","",$fmtable,6);   
   $fmtable=one_replace("\\<shorttitle\\>",$sttt,$fmtable,6);  
   $fmtable=one_replace("\\<asc\\>","",$fmtable,6);  
   $fmtable=one_replace("\\<xkey\\>","",$fmtable,6);  
   $fmtable=one_replace("\\<xval\\>","",$fmtable,6);  
   $fmtable=all_replace("\\<dsplnone\\>","display:none;",$fmtable); 
   $fmtable=all_replace("\\<readonly\\>","readonly",$fmtable);  
   if ($totrcd>0 ){
    $cshtml=all_replace("{inner}",$fmch,$csurd);
    $csinner=$fmch;
    $cshtml=all_replace("\\[inner\\]",$fmch,$cshtml);
   }else{
    $cshtml="";
    $csinner="";
   };
   //maketable前把SBASE里的各种DIY 解析了
  $dspc=new Array();
  $dspc["cshtml"]=$cshtml;
  $dspc["csinner"]=$csinner;
   tabhtml=all_replace("\\[tbheadbody\]",$fmtable,$csurd);
   tabhtml=all_replace("\\[tablename\]",$dsid,tabhtml);
   tabhtml=all_replace("\\[tablenm\]",$dsid,tabhtml);
   tabhtml=all_replace("\\[tabnm\]",$dsid,tabhtml);
   tabhtml=all_replace("\\[sttab\]",$dsid,tabhtml);
   tabhtml=all_replace("\\[tabkeys\]",$shoks,tabhtml);
   tabhtml=all_replace("\\[pskey\]",pskey,tabhtml);
   tabhtml=all_replace("\\[pstitle\]",pstitle,tabhtml);
   tabhtml=all_replace("\\[pshead\]",pshead,tabhtml);
   tabhtml=all_replace("\\[pssno\]",pssno,tabhtml);
   tabhtml=all_replace("\\[stid\]",$dsst,tabhtml);
   tabhtml=all_replace("\\[shortid\]",$dsst,tabhtml);
   tabhtml=all_replace("\\[makecdt\]","",tabhtml);
   tabhtml=all_replace("\\[allcdt\]","",tabhtml);
   tabhtml=all_replace("\\[pnum\]","",tabhtml);
   tabhtml=all_replace("\\[page\]","",tabhtml);   
   $dspc["dsdata"]=tabhtml;
   $dspc["exteval"]=$fmextscript;
  return $dspc;
}
function judgefunx(strx){
 strx=strx.replace(/ /g,"");
 if (right(strx,1)==";" || strx.indexOf("unction ")>0){
  return true;
 }else{
  return false;
 };
}
function exchangedemo($stdata,$demox,$dkeys,$valks){
  fmdemo="";

  if ( $dkeys!="" && $valks!="" ){
   ptkx=$dkeys.split(",");
   totpt=ptkx.length;
   ptvx=$valks.split(",");
   totvx=ptvx.length;
   $vals=$dkeys;
   $keys=$valks;
  }else{
   if ($demox.indexOf("{k-")>0){
     $keys="";
     $vals="";
     ptdmk=$demox.split("{k-");
     totpt=ptdmk.length;
     for (p=1;p<totpt;p++){
        $vals=$vals +qian(ptdmk[p],"}")+",";
        $keys=$keys +"{k-"+qian(ptdmk[p],"}")+"},";
     }
      $vals=killlasttring($vals);
      $keys=killlasttring($keys);
      demoy=$demox;
      ptkx=$keys.split(",");
      totpt=ptkx.length;
      ptvx=$vals.split(",");
      totvx=ptvx.length;
   }else{
      totpt=0;
      totvx=0;
      $keys="";
      $vals="";
   }
  }
  for (k=0;k<$stdata.vls.length;k++){
    demoy=$demox;
    if ( $keys!="" && $vals!=""){
     for (z=0;z<totpt;z++){
      if (ptvx[z]!="" && ptvx[z]!=undefined){
       kkk=ptkx[z];
       vvv="";
       eval("vvv=$stdata.vls[k]."+ptvx[z]+";");
       demoy=all_replace('{'+kkk+'}',exkey($stdata,k,kkk,vvv),demoy);
       demoy=all_replace('{k-'+kkk+'}',exkey($stdata,k,kkk,vvv),demoy);
       demoy=all_replace(kkk,exkey($stdata,k,kkk,vvv),demoy);
      }
     }//for z
   }else{
     demoy="";
   }
   demoy=all_replace("{k-sqx}",k+1,demoy);
   fmdemo=fmdemo+demoy;
  }//for k
  return fmdemo;
}
function exkeyx(stda,ki,kk,vv){
 if (kk!=""){
  switch(kk){
     case "SNO":
      return vv;
     break;
     default:
      return vv;
  }
 }else{
   return "";   
 }
}
function makeclstxt(clsstr){
    if (clsstr.indexOf("}")>0){
      smark="a"+mdf16(clsstr+_cookie("cid")+_cookie("uid"));
      ssstk="";
      eval("ssstk=sessionStorage."+smark+";");
      if (ssstk!=undefined && ssstk!=""){
          return ssstk;
      }else{
          clsstrx=clsstr.replace("{","");
          clsstrx=clsstrx.replace("}","");
          bktxt=anyshort(clsstrx,"","");
          eval("sessionStorage."+smark+"='"+bktxt+"';");    
          return bktxt;
      }
    }else{
        return clsstr;
    }
}
function exchangeunit($trow,$casehtml,$adt,$ix){   
if ($casehtml!=undefined){
  if ($casehtml.indexOf("unction")>0 && $casehtml.indexOf("unction(")<=0){
     $fvalue="";
   if (qian(hou($casehtml,"unction"),"{")!=""){
      funstr=combinestr3('$fvalue=',qian(hou($casehtml,"unction"),"{"),';');
      xfunstr=substr(funstr,2,strlen(funstr)-2);
   //---------------------------------------------------------------------------------------------------------------
      if (xfunstr.indexOf("$")<=0){
        if ($trow["ktitle"]==""){
          funstr=one_replace("label",syh()+$trow["key"]+syh(),funstr,6);
          funstr=one_replace("coltitle",syh()+$trow["key"]+syh(),funstr,6);
          funstr=one_replace("coltitle",syh()+$trow["key"]+syh(),funstr,6);
        }else{
          funstr=one_replace("label",syh()+$trow["ktitle"]+syh(),funstr,6);
          funstr=one_replace("coltitle",syh()+$trow["ktitle"]+syh(),funstr,6);
          funstr=one_replace("coltitle",syh()+$trow["ktitle"]+syh(),funstr,6);
        }
         funstr=one_replace("key0",syh()+$trow["key0"]+syh(),funstr,6);
         funstr=one_replace("key",syh()+$trow["key"]+syh(),funstr,6);
         funstr=one_replace("SNO",syh()+$trow["thissno"]+syh(),funstr,6);
         funstr=one_replace("keys",syh()+$trow["showkeys"]+syh(),funstr,6);
         funstr=one_replace("exp",syh()+$trow["kexplain"]+syh(),funstr,6);
         funstr=one_replace("table",syh()+$trow["tablename"]+syh(),funstr,6);
         funstr=one_replace("table",syh()+$trow["tablename"]+syh(),funstr,6);
         funstr=one_replace("table",syh()+$trow["tablename"]+syh(),funstr,6);
         funstr=one_replace("tabname",syh()+$trow["tablename"]+syh(),funstr,6);
         funstr=one_replace("tabname",syh()+$trow["tablename"]+syh(),funstr,6);
         funstr=one_replace("tabname",syh()+$trow["tablename"]+syh(),funstr,6);
         funstr=one_replace("stid",syh()+$trow["shortid"]+syh(),funstr,6);
         funstr=one_replace("dxtype",syh()+$trow["dxtype"]+syh(),funstr,6);
         funstr=one_replace("date",syh()+date("Y-m-d")+syh(),funstr,6);
         funstr=one_replace("now",syh()+date("Y-m-d H:i:s")+syh(),funstr,6);
         funstr=one_replace("anymark",syh()+date("YmdHis")+randomWord(false,6)+syh(),funstr,6);
         funstr=one_replace("dspl",syh()+$trow["dsplhtml"]+syh(),funstr,6);
         funstr=one_replace("rdol",syh()+$trow["rdolhtml"]+syh(),funstr,6);
         funstr=one_replace("OLMK",syh()+$trow["thisolmk"]+syh(),funstr,6);
         funstr=one_replace("thiskey",syh()+$trow["key"]+syh(),funstr,6);
         funstr=one_replace("thistable",syh()+$trow["tablename"]+syh(),funstr,6);
         funstr=one_replace("thissno",syh()+$trow["thissno"]+syh(),funstr,6);
         funstr=one_replace("tmpks",syh()+$trow["key"]+syh()+$trow["thissno"]+syh(),funstr,6);
         funstr=one_replace("thisshort",syh()+$trow["shortid"]+syh(),funstr,6);
         funstr=one_replace("uid",syh()+$_COOKIE["uid"]+syh(),funstr,6);
         funstr=one_replace("gid",syh()+$_COOKIE["gid"]+syh(),funstr,6);
         funstr=one_replace("cid",syh()+$_COOKIE["cid"]+syh(),funstr,6);
         funstr=one_replace("posids",syh()+$_COOKIE["posids"]+syh(),funstr,6);
         funstr=one_replace("depart",syh()+$_COOKIE["depart"]+syh(),funstr,6);
         funstr=one_replace("dpts",syh()+$_COOKIE["dpts"]+syh(),funstr,6);
         funstr=one_replace("appid",syh()+$trow["appid"]+syh(),funstr,6);
         funstr=one_replace("sysid",syh()+$trow["sysid"]+syh(),funstr,6);
         funstr=one_replace("clstxt",syh()+$trow["clstxt"]+syh(),funstr,6);
         funstr=one_replace("thisvalue",syh()+tostring($trow["value"])+syh(),funstr,3);  
         funstr=one_replace("ti",syh()+$trow["ti"]+syh(),funstr,6); 
         funstr=one_replace("tj",syh()+$trow["tj"]+syh(),funstr,6); 
         funstr=one_replace("acthtm",syh()+$trow["acthtm"]+syh(),funstr,6);
         funstr=one_replace("atnhtm",syh()+$trow["atnhtm"]+syh(),funstr,6);
         if (funstr.indexOf("key-")>0){
           $ptnhtxt=explode("key-",funstr);
           $totpt=countx($ptnhtxt); 
          for ($f=1;$f<$totpt;$f++){
            $tmpok=qian($ptnhtxt[syh()+$f],",");  
            if ($trow["showkeys"].indexOf($tmpok)>0){
               funstr=one_replace("key-"+$tmpok,$adt[$tmpok][$ix*1],funstr,6);
           }else{
               funstr=one_replace("key-"+$tmpok,"",funstr,6);
           }
          };
         }
      }
     eval(funstr);
   //---------------------------------------------------------------------------------------------------------------
     if ($fvalue==""){
      $casehtml=tostring($trow["value"]);
     }else{
      $casehtml=$fvalue; 
     }
   }
  }
 if (strpos(combinestr2("XY",$casehtml),"FUN:")>0){
  $casehtml="[thisvalule]";
 };
  $sfun=$casehtml;
  $newfunx="";
  $dvalue=$trow["value"];
 if (strpos("x"+$sfun,"CASE")>0 && strpos("x"+$sfun,"E@CS")>0){
   $ptfunx=explode("CASE",$sfun);
   $totpf=countx($ptfunx);
   $fd=0;
   for ($pf=1;$pf<$totpf;$pf++){   
    $tmpfn=qian(hou($ptfunx[$pf],"::"),"E@CS");
    $tmpct=qian($ptfunx[$pf],"::");
    $tmptj=substr($ptfunx[$pf],0,1);
    $tmpvlx=qian($ptfunx[$pf],"::");   
    $tmpvlx=$tmpvlx.replace($tmptj,"");
    $zuo=qian($tmpvlx,",");
    $you=hou($tmpvlx,",");
   switch($tmptj){
    case "@":
     if (((strpos("xxx"+$dvalue,$tmpvlx)>0 && $tmpvlx!="") || $tmpvlx=="") && $fd==0){
      $newfunx=$tmpfn;
      $fd=$fd+1;
      }
   break;
   case "=":
     if ($dvalue==$tmpvlx || intval($dvalue)*1==intval($tmpvlx)*1 && $tmpvlx!="" && $fd==0){
      $newfunx=$tmpfn;   
      $fd=$fd+1;
     };
   break;
   case ":":
   if ((($you*1)>=($dvalue*1) && ($zuo*1)<=($dvalue*1)) && $tmpvlx!="" && $fd==0){
     $newfunx=$tmpfn;
     $fd=$fd+1;
   };
   break;
   case "*":
   if ($fd==0){
     $newfunx=$tmpfn;
     $fd=$fd+1;
   };
   break;
   default:   
   $sfun="";
  }
  };//for
  $sfun="";
 };  
  if ($newfunx!=""){
   $casehtml=$newfunx;
  }
  
  if (judgefunx($casehtml)){
   //console.log($casehtml);
  }else{
   $casehtml=turnlab($casehtml);
  }
  if ($trow["ktitle"]==""){
   $casehtml=one_replace("{label}",$trow["key"],$casehtml,6);
   $casehtml=one_replace("{coltitle}",$trow["key"],$casehtml,6);
   $casehtml=one_replace("[coltitle]",$trow["key"],$casehtml,6);
   $casehtml=one_replace("[title]",$trow["key"],$casehtml,6);
  }else{
   $casehtml=one_replace("{label}",$trow["ktitle"],$casehtml,6);
   $casehtml=one_replace("{coltitle}",$trow["ktitle"],$casehtml,6);
   $casehtml=one_replace("[coltitle]",$trow["ktitle"],$casehtml,6);
   $casehtml=one_replace("[title]",$trow["ktitle"],$casehtml,6);
  }
  if ($trow["value"]!="" && $trow["value"]!=undefined){
   tosval=tostring($trow["value"]);
   tosval=tosval.toString();
   tosval=tosval.replace(/thisvalue/g,"@TV@");
   tosval=tosval.replace(/\[value\]/g,"@VV@");
   tosval=tosval.replace(/{value}/g,"@VV@");
   tosval=tosval.replace(/hvalue/g,"@HV@");
   tosval=tosval.replace(/inner/g,"@IN@");
   tosval=tosval.replace(/row/g,"@ROW@");
  }else{
    tosval="";
  }

  $casehtml=one_replace("\[vtitle\]",vtitle(tosval,$trow["clstxt"]),$casehtml,6);
  $casehtml=one_replace("{vtitle}",vtitle(tosval,$trow["clstxt"]),$casehtml,6);
  $casehtml=one_replace("{key0}",$trow["key0"],$casehtml,6);
  $casehtml=one_replace("{key}",$trow["key"],$casehtml,6);
  $casehtml=one_replace("{key}",$trow["key"],$casehtml,6);
  $casehtml=one_replace("{key}",$trow["key"],$casehtml,6);
  $casehtml=one_replace("{key}",$trow["key"],$casehtml,6);
  $casehtml=one_replace("{key}",$trow["key"],$casehtml,6);
  $casehtml=one_replace("{key}",$trow["key"],$casehtml,6);
  $casehtml=one_replace("{key}",$trow["key"],$casehtml,6);
  $casehtml=one_replace("{SNO}",$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("{SNO}",$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("{SNO}",$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("{SNO}",$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("{SNO}",$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("{SNO}",$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("{SNO}",$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("{keys}",$trow["showkeys"],$casehtml,6);
  $casehtml=one_replace("{table}",$trow["tablename"],$casehtml,6);
  $casehtml=one_replace("{table}",$trow["tablename"],$casehtml,6);
  $casehtml=one_replace("{table}",$trow["tablename"],$casehtml,6);
  $casehtml=one_replace("{tabname}",$trow["tablename"],$casehtml,6);
  $casehtml=one_replace("{tabname}",$trow["tablename"],$casehtml,6);
  $casehtml=one_replace("{tabname}",$trow["tablename"],$casehtml,6);
  $casehtml=one_replace("{stid}",$trow["shortid"],$casehtml,6);
  $casehtml=one_replace("{stid}",$trow["shortid"],$casehtml,6);
  $casehtml=one_replace("{stid}",$trow["shortid"],$casehtml,6);
  $casehtml=one_replace("{stid}",$trow["shortid"],$casehtml,6);
  $casehtml=one_replace("{dxtype}",$trow["dxtype"],$casehtml,6);
  $casehtml=one_replace("{tpnm}",$trow["tpnm"],$casehtml,6);
  $casehtml=one_replace("{clstxt}",$trow["clstxt"],$casehtml,6);
  $casehtml=one_replace("{date}",date("Y-m-d"),$casehtml,6);
  $casehtml=one_replace("{now}",date("Y-m-d H:i:s"),$casehtml,6);
  $casehtml=one_replace("{anymark}",date("YmdHis")+randomWord(false,6),$casehtml,6);
  $casehtml=one_replace("{dspl}",$trow["dsplhtml"],$casehtml,6);
  $casehtml=one_replace("{rdol}",$trow["rdolhtml"],$casehtml,6);
  $casehtml=one_replace("{exp}",$trow["kexplain"],$casehtml,6);
  $casehtml=one_replace("{OLMK}",$trow["thisolmk"],$casehtml,6);
  $casehtml=one_replace("{thisid}","ipt"+$trow["key"]+$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("{thiskey}",$trow["key"],$casehtml,6);
  $casehtml=one_replace("{thistable}",$trow["tablename"],$casehtml,6);
  $casehtml=one_replace("{thissno}",$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("{tmpks}",$trow["key"]+$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("{thisshort}",$trow["shortid"],$casehtml,6);   
  $casehtml=one_replace("{vwx}",qian($trow["vqx"],"."),$casehtml,6);   
  $casehtml=one_replace("{vhx}",hou($trow["vqx"],"."),$casehtml,6);   
  $casehtml=one_replace("{siteurl}",glw(),$casehtml,6);  
  $casehtml=one_replace("{rip}",getip(),$casehtml,6);
  $casehtml=one_replace("{uid}",$_COOKIE["uid"],$casehtml,6);
  $casehtml=one_replace("{gid}",$_COOKIE["gid"],$casehtml,6);
  $casehtml=one_replace("{cid}",$_COOKIE["cid"],$casehtml,6);
  $casehtml=one_replace("{posids}",$_COOKIE["posids"],$casehtml,6);
  $casehtml=one_replace("{depart}",$_COOKIE["depart"],$casehtml,6);
  $casehtml=one_replace("{dpts}",$_COOKIE["dpts"],$casehtml,6);
  $casehtml=one_replace("{appid}",$trow["appid"],$casehtml,6);
  $casehtml=one_replace("{sysid}",$trow["sysid"],$casehtml,6);
  $casehtml=one_replace("{defaultbase}",glb(),$casehtml,6);
  $casehtml=one_replace("{defaultip}",gl(),$casehtml,6);
  if (strlen($trow["value"])>100 && $casehtml.indexOf("input")<=0 &&  $casehtml.indexOf("textarea")<=0  &&  $casehtml.indexOf("tarea")<=0 && $trow["dxtype"]!="richtext" && $trow["dxtype"]!="text"){
    $casehtml=one_replace("{value}",substr(tosval.replace(/\\\'/g,"\'"),0,20)+"...",$casehtml,30); 
    $casehtml=one_replace("{thisvalue}",substr(tosval.replace(/\\\'/g,"\'"),0,20)+"...",$casehtml,30);
  }else{
    $casehtml=one_replace("{value}",tosval.replace(/\\\'/g,"\'"),$casehtml,30);
    $casehtml=one_replace("{thisvalue}",tosval.replace(/\\\'/g,"\'"),$casehtml,30); 
  }
  $casehtml=one_replace("{hvalue}",$trow["hvalue"],$casehtml,1); 
  $casehtml=one_replace("{hexvalue}",$trow["hexvalue"],$casehtml,1); 
  $casehtml=one_replace("{ti}",$trow["ti"],$casehtml,6); 
  $casehtml=one_replace("{tj}",$trow["tj"],$casehtml,6); 
  $casehtml=one_replace("{acthtm}",$trow["acthtm"],$casehtml,6);
  $casehtml=one_replace("{atnhtm}",$trow["atnhtm"],$casehtml,6);
  $casehtml=one_replace("{dsplnone}","display:none;",$casehtml,6);
  $casehtml=one_replace("\[key0\]",$trow["key0"],$casehtml,6);
  $casehtml=one_replace("\[key0\]",$trow["key0"],$casehtml,6);
  $casehtml=one_replace("\[key0\]",$trow["key0"],$casehtml,6);
  $casehtml=one_replace("\[key0\]",$trow["key0"],$casehtml,6);
  $casehtml=one_replace("\[key0\]",$trow["key0"],$casehtml,6);
  $casehtml=one_replace("\[key0\]",$trow["key0"],$casehtml,6);
  $casehtml=one_replace("\[key0\]",$trow["key0"],$casehtml,6);
  $casehtml=one_replace("\[key\]",$trow["key"],$casehtml,6);
  $casehtml=one_replace("\[key\]",$trow["key"],$casehtml,6);
  $casehtml=one_replace("\[key\]",$trow["key"],$casehtml,6);
  $casehtml=one_replace("\[key\]",$trow["key"],$casehtml,6);
  $casehtml=one_replace("\[key\]",$trow["key"],$casehtml,6);
  $casehtml=one_replace("\[key\]",$trow["key"],$casehtml,6);
  $casehtml=one_replace("\[key\]",$trow["key"],$casehtml,6);
  $casehtml=one_replace("\[SNO\]",$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("\[SNO\]",$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("\[SNO\]",$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("\[SNO\]",$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("\[SNO\]",$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("\[SNO\]",$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("\[SNO\]",$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("\[SNO\]",$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("\[keys\]",$trow["showkeys"],$casehtml,6);
  $casehtml=one_replace("\[table\]",$trow["tablename"],$casehtml,6);
  $casehtml=one_replace("\[table\]",$trow["tablename"],$casehtml,6);
  $casehtml=one_replace("\[table\]",$trow["tablename"],$casehtml,6);
  $casehtml=one_replace("\[tabname\]",$trow["tablename"],$casehtml,6);
  $casehtml=one_replace("\[tabname\]",$trow["tablename"],$casehtml,6);
  $casehtml=one_replace("\[tabname\]",$trow["tablename"],$casehtml,6);
  $casehtml=one_replace("\[stid\]",$trow["shortid"],$casehtml,6);
  $casehtml=one_replace("\[exp\]",$trow["kexplain"],$casehtml,6);
  $casehtml=one_replace("\[dxtype\]",$trow["dxtype"],$casehtml,6);
  $casehtml=one_replace("\[tpnm\]",$trow["tpnm"],$casehtml,6);
  $casehtml=one_replace("\[date\]",date("Y-m-d"),$casehtml,6);
  $casehtml=one_replace("\[now\]",date("Y-m-d H:i:s"),$casehtml,6);
  $casehtml=one_replace("\[anymark\]",date("YmdHis")+randomWord(false,6),$casehtml,6);
  $casehtml=one_replace("\[dspl\]",$trow["dsplhtml"],$casehtml,6);
  $casehtml=one_replace("\[rdol\]",$trow["rdolhtml"],$casehtml,6);
  $casehtml=one_replace("\[OLMK\]",$trow["thisolmk"],$casehtml,6);
  $casehtml=one_replace("\[thisid\]","ipt"+$trow["key"]+$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("\[thiskey\]",$trow["key"],$casehtml,6);
  $casehtml=one_replace("\[thistable\]",$trow["tablename"],$casehtml,6);
  $casehtml=one_replace("\[thissno\]",$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("\[tmpks\]",$trow["key"]+$trow["thissno"],$casehtml,6);
  $casehtml=one_replace("\[thisshort\]",$trow["shortid"],$casehtml,6);   
  $casehtml=one_replace("\[vwx\]",qian($trow["vqx"],"."),$casehtml,6);   
  $casehtml=one_replace("\[vhx\]",hou($trow["vqx"],"."),$casehtml,6);   
  $casehtml=one_replace("\[siteurl\]",glw(),$casehtml,6);  
  $casehtml=one_replace("\[rip\]",getip(),$casehtml,6);
  $casehtml=one_replace("\[uid\]",$_COOKIE["uid"],$casehtml,6);
  $casehtml=one_replace("\[gid\]",$_COOKIE["gid"],$casehtml,6);
  $casehtml=one_replace("\[cid\]",$_COOKIE["cid"],$casehtml,6);
  $casehtml=one_replace("\[posids\]",$_COOKIE["posids"],$casehtml,6);
  $casehtml=one_replace("\[depart\]",$_COOKIE["depart"],$casehtml,6);
  $casehtml=one_replace("\[dpts\]",$_COOKIE["dpts"],$casehtml,6);
  $casehtml=one_replace("\[appid\]",$trow["appid"],$casehtml,6);
  $casehtml=one_replace("\[sysid\]",$trow["sysid"],$casehtml,6);
  $casehtml=one_replace("\[clstxt\]",$trow["clstxt"],$casehtml,6);
  $casehtml=one_replace("\[defaultbase\]",glb(),$casehtml,6);
  $casehtml=one_replace("\[defaultip\]",gl(),$casehtml,6);
  if (strlen($trow["value"])>100 && $casehtml.indexOf("input")<=0 &&  $casehtml.indexOf("textarea")<=0  &&  $casehtml.indexOf("tarea")<=0 && $trow["dxtype"]!="richtext" && $trow["dxtype"]!="text"){
    $casehtml=one_replace("\[value\]",substr(tosval.replace(/\\\'/g,"\'"),0,20)+"...",$casehtml,30); 
    $casehtml=one_replace("\[thisvalue\]",substr(tosval.replace(/\\\'/g,"\'"),0,20)+"...",$casehtml,30);
  }else{
    $casehtml=one_replace("\[value\]",tosval.replace(/\\\'/g,"\'"),$casehtml,30);
    $casehtml=one_replace("\[thisvalue\]",tosval.replace(/\\\'/g,"\'"),$casehtml,30); 
  }
  $casehtml=one_replace("\[hvalue\]",$trow["hvalue"],$casehtml,10); 
  $casehtml=one_replace("\[hexvalue\]",$trow["hexvalue"],$casehtml,10); 
  $casehtml=one_replace("\[ti\]",$trow["ti"],$casehtml,6); 
  $casehtml=one_replace("\[tj\]",$trow["tj"],$casehtml,6); 
  $casehtml=one_replace("\[acthtm\]",$trow["acthtm"],$casehtml,6);
  $casehtml=one_replace("\[atnhtm\]",$trow["atnhtm"],$casehtml,6);
  $casehtml=one_replace("\[dsplnone\]","display:none;",$casehtml,6);
  
  if ($casehtml.indexOf("{key-")>0){
     $ptnhtxt=explode("{key-",$casehtml);
     $totpt=countx($ptnhtxt); 
     for ($f=1;$f<$totpt;$f++){
         $tmpok=qian($ptnhtxt[$f],"}");  
         if ($trow["showkeys"].indexOf($tmpok)>0){
            $casehtml=one_replace("{key-"+$tmpok+"}",$adt[$tmpok][$ix*1],$casehtml);
         }else{
            $casehtml=one_replace("{key-"+$tmpok+"}","",$casehtml);  
         }
      };//
  }
  if ($casehtml.indexOf("\[key-")>0){
       $ptnhtxt=explode("\[key-",$casehtml);
       $totpt=countx($ptnhtxt); 
       for ($f=1;$f<$totpt;$f++){
           $tmpok=qian($ptnhtxt[$f],"\]");  
           if ($trow["showkeys"].indexOf($tmpok)>0){
              $casehtml=one_replace("\[key-"+$tmpok+"\]",$adt[$tmpok][$ix*1],$casehtml);
           }else{
              $casehtml=one_replace("\[key-"+$tmpok+"\]","",$casehtml);   
           }
        };//
  }
  if ($casehtml.indexOf("{ots-")>0){
     $ptnhtxt=explode("{ots-",$casehtml);
     $totpt=countx($ptnhtxt); 
     for ($f=1;$f<$totpt;$f++){
         $tmpok=qian($ptnhtxt[$f],"}");  
         if ($trow["showkeys"].indexOf($tmpok)>0){
            $casehtml=one_replace("{ots-"+$tmpok+"}",otspath($adt[$tmpok][$ix*1]),$casehtml);
         }else{
            $casehtml=one_replace("{ots-"+$tmpok+"}","",$casehtml);  
         }
      };//
  }
  if ($casehtml.indexOf("\[ots-")>0){
       $ptnhtxt=explode("\[ots-",$casehtml);
       $totpt=countx($ptnhtxt); 
       for ($f=1;$f<$totpt;$f++){
           $tmpok=qian($ptnhtxt[$f],"\]");  
           if ($trow["showkeys"].indexOf($tmpok)>0){
              $casehtml=one_replace("\[ots-"+$tmpok+"\]",otspath($adt[$tmpok][$ix*1]),$casehtml);
           }else{
              $casehtml=one_replace("\[ots-"+$tmpok+"\]","",$casehtml);   
           }
        };//
  }
   //以下为值包裹解析
   $casehtml=$casehtml.replace(/@VV@/g,"\[value\]");
   $casehtml=$casehtml.replace(/@TV@/g,"thisvalue");
   $casehtml=$casehtml.replace(/@HV@/g,"hvalue");
   $casehtml=$casehtml.replace(/@ROW@/g,"row");
   return $casehtml;
   }else{
  return "";
   }
 }
 function vtitle(valx,clsx){
     if (clsx!=""){
         qx=qian(clsx,"|");
         hx=hou(clsx,"|");
        if (qx.indexOf(",")>0){
           ptqx=qx.split(",");
           pthx=hx.split(",");
           totpt=ptqx.length;
           tempv="";
           for (a=0;a<totpt;a++){
              if (pthx[a]==valx){
                  tempv=ptqx[a];
              }
           }
           return dftval(tempv,valx);
         }else{
           return valx;
         }
     }else{
         return valx;
     }
 }
 function anyshort(a,b,c){
  return ajaxhtmlpost("/localxres/funx/anyshort/?stid="+a+"-pnum:30-&pnum="+b+"&page="+c,"");
 }
 function makepagerow($pnum,$pg,$atot,$stid,$ccs,$asc,$xky,$xvy){
 console.log("pnum-"+$pnum+"&pg-"+$pg);
  if ($pnum!="" && $pnum!=undefined && $pg!="" && $pg!=undefined){ 
   $pg=intval($pg);
  $radius=7;
  $pagesrdx=turnlab($ccs["pgsrd"]); 
  $pageinx=turnlab($ccs["pgin"]);
  $pageoutx=turnlab($ccs["pgout"]);
  $pageinx=one_replace("{page}",$pg,$pageinx,1);
  $pageinx=one_replace("{asc}",$asc,$pageinx,1);
  $pageinx=one_replace("{xkey}",$xky,$pageinx,1);
  $pageinx=one_replace("{xval}",$xvy,$pageinx,1);
  $pageinx=one_replace("\[page\]",$pg,$pageinx,1);
  $pageinx=one_replace("\[pgtt\]",$pg,$pageinx,1);
  $pageinx=one_replace("\[asc\]",$asc,$pageinx,1);
  $pageinx=one_replace("\[xkey\]",$xky,$pageinx,1);
  $pageinx=one_replace("\[xval\]",$xvy,$pageinx,1);
  $totpage=ceil($atot/$pnum);
  $endpg=($pg*1)+$radius;
  $startpg=($pg-$radius);
  if ($endpg>$totpage){
   $endpage=$totpage;
  }else{
    $endpage=$endpg;
  };
  if ($startpg<1){
    $startpage=1; 
  }else{
    $startpage=$startpg;
  };
  if (($pg*1-1)<1){
   $prepg="1";
  }else{
   $prepg=$pg*1-1;
  }
  if (($pg*1+1)>$endpg){
   $nxtpg=$endpg;
  }else{
   $nxtpg=($pg*1+1);
  }
  $fminner="";
  $fmqk="";
  $fmhv="";
  for ($px=$startpage;$px<$endpage+1;$px++){
   if ($pg!=$px){
    $pout=$pageoutx; 
    $pout=one_replace("{page}",$px,$pout,1);
    $pout=one_replace("{pgtt}",$px,$pout,1);
    $pout=one_replace("{asc}",$asc,$pout,1);
    $pout=one_replace("{xkey}",$xky,$pout,1);
    $pout=one_replace("{xval}",$xvy,$pout,1);
    $pout=one_replace("\[page\]",$px,$pout,1);
    $pout=one_replace("\[pgtt\]",$px,$pout,1);
    $pout=one_replace("\[asc\]",$asc,$pout,1);
    $pout=one_replace("\[xkey\]",$xky,$pout,1);
    $pout=one_replace("\[xval\]",$xvy,$pout,1);
    $fmqk=combinestr4($fmqk,"第",$px,"页,");
    $fmhv=combinestr3($fmhv,$px,",");
    $fminner=$fminner+$pout;   
   }else{
    $fminner=$fminner+$pageinx;
   };//if
 }//for
 if ($totpage>0){
   $fmqk=substr($fmqk,0,strlen($fmqk)-1);
   $fmhv=substr($fmhv,0,strlen($fmhv)-1);
 };
   $xsslt="每页显示30条,每页显示50条,每页显示100条,每页显示150条,每页显示200条,每页显示300条,显示所有记录";
   $xsslv="30,50,100,150,200,300,0";
   $areaslt=qian($("#areacls").val(),"|");
   $areaslv=hou($("#areacls").val(),"|");
   $fmselectjs=formselect($fmqk,$fmhv,$pg,"topage","layui-select","onchange=\"tospage($('#topage').val());\"");
  $fmselectpn=formselect($xsslt,$xsslv,$pnum,"topn","layui-select","onchange=\"setpage($('#topn').val());\"");
  if ($("#areacls").val()!=""){
    $fmselectar=formselect($areaslt,$areaslv,_get($("#areacode").val()),"toar","layui-select","onchange=\"toarea($('#toar').val());\"");
  }else{
    $fmselectar="";
  };
  if ($("#wrdcode").val()!=""){
     slstid=qian($("#wrdcls").val(),"@");
     slstid=slstid.replace("\[","");
     slarea=hou($("#wrdcls").val(),"@");
     slarea=slarea.replace("\]","");
     htmlxz="onchange=\"towrd($('#wrdslct').val(),$('#wrdcode').val())\"";
     $fmselectwr=shortselect(slstid, "wrdslct",_get($("#wrdcode").val()), _get($("#areacode").val()), htmlxz, "key"+slarea,"layui-select","");
  }else{
     $fmselectwr="";
  };
  $pagesrdx=one_replace("{asc}",$asc,$pagesrdx,1);
  $pagesrdx=one_replace("{xkey}",$xky,$pagesrdx,1);
  $pagesrdx=one_replace("{xval}",$xvy,$pagesrdx,1);  
  $pagesrdx=one_replace("{pagenum}",$pnum,$pagesrdx,1); 
  $pagesrdx=one_replace("{prepage}",$pg,$pagesrdx,1); 
  $pagesrdx=one_replace("{pgselect}",$fmselectjs,$pagesrdx,1);
  $pagesrdx=one_replace("{pgnum}",$fmselectpn+$fmselectar,$pagesrdx,1);
  $pagesrdx=one_replace("{pageend}",$totpage,$pagesrdx,1);
  $pagesrdx=one_replace("{totpage}",$totpage,$pagesrdx,1);
  $pagesrdx=one_replace("{totrst}",$atot,$pagesrdx,1);
  $pagesrdx=one_replace("{prepg}",$prepg,$pagesrdx,1);
  $pagesrdx=one_replace("{nxtpg}",$nxtpg,$pagesrdx,1);
  $pagesrdx=one_replace("{pett}","尾页",$pagesrdx,1);
  $pagesrdx=one_replace("{pageinner}",$fminner,$pagesrdx,1);
  $pagesrdx=one_replace("\[asc\]",$asc,$pagesrdx,1);
  $pagesrdx=one_replace("\[xkey\]",$xky,$pagesrdx,1);
  $pagesrdx=one_replace("\[xval\]",$xvy,$pagesrdx,1);
  $pagesrdx=one_replace("\[pagenum\]",$pnum,$pagesrdx,1);
  $pagesrdx=one_replace("\[prepg\]",$prepg,$pagesrdx,1);
  $pagesrdx=one_replace("\[nxtpg\]",$nxtpg,$pagesrdx,1);
  $pagesrdx=one_replace("\[pgselect\]",$fmselectjs,$pagesrdx,1);
  $pagesrdx=one_replace("\[page\]",$pg,$pagesrdx,1);
  $pagesrdx=one_replace("\[pgnum\]",$fmselectpn+$fmselectar+$fmselectwr,$pagesrdx,1);
  $pagesrdx=one_replace("\[pageend\]",$totpage,$pagesrdx);
  $pagesrdx=one_replace("\[totpage\]",$totpage,$pagesrdx,1);
  $pagesrdx=one_replace("\[totye\]",$totpage,$pagesrdx,1);
  $pagesrdx=one_replace("\[totrst\]",$atot,$pagesrdx,1);
  $pagesrdx=one_replace("\[pett\]","尾页",$pagesrdx,1);
  $pagesrdx=one_replace("\[pageinner\]",$fminner,$pagesrdx,1);
 }else{
  
  $pagesrdx=one_replace("{totpage}","0",$pagesrdx,1);
  $pagesrdx=one_replace("{totye}","0",$pagesrdx,1)
  $pagesrdx=one_replace("{totrst}","0",$pagesrdx,1);
  $pagesrdx=one_replace("{pgselect}","",$pagesrdx,1); 
  $pagesrdx=one_replace("{pagenum}","",$pagesrdx,1);
  $pagesrdx=one_replace("\[totpage\]","0",$pagesrdx,1);
  $pagesrdx=one_replace("\[totrst\]","0",$pagesrdx,1);
  $pagesrdx=one_replace("\[pgselect\]","",$pagesrdx,1);
  $pagesrdx=one_replace("\[pagenum\]","",$pagesrdx,1);
 }   
  return $pagesrdx;
}//fun
function formtrow($trowx,$kx,$hvx,$tbsno,$tbolmk,$kyif,$stif,$jx,$srt){  
  $trowx["key"]=$kx;
  $trowx["ti"]=$jx;
  if ($kx!="OPRT" && $kx!="itemOprt"){
    $trowx["ktitle"]=dftval($kyif[$kx]["COLUMN_TITLE"],"");
  }else{
   $trowx["ktitle"]="操作";  
  }
  if ($kx!="OPRT"  && $kx!="itemOprt"){
   
     $trowx["clstxt"]=dftval($kyif[$kx]["COLUMN_CLSTXT"],"");
   
  }else{
   $trowx["clstxt"]="";  
  }
  if ($tbsno=="0"){
   $trowx["hexvalue"]=$hvx;
   $trowx["value"]=tostring($hvx);
   $trowx["hvalue"]=toquote($hvx);
   //$trowx["mvalue"]=fmvalue($stif["tablename"],$srt[$kx][0],$tbsno,$kx,qian($kyif[$kx]["COLUMN_SSHOW"],"|"),$jx,$srt);
  }else{
   $trowx["hexvalue"]=$hvx;
   $trowx["hvalue"]=toquote($hvx);
   $trowx["value"]=tostring($hvx);
   //$trowx["mvalue"]=fmvalue($stif["tablename"],$vx,$tbsno,$kx,qian($kyif[$kx]["COLUMN_SSHOW"],"|"),$jx,$srt);
  }
  $trowx["kexplain"]=$kyif[$kx]["COLUMN_EXPLAIN"];
  $trowx["vqx"]=$kyif[$kx]["COLUMN_VQX"];
  $trowx["key0"]=$kx+$tbsno;
  $trowx["thissno"]=$tbsno;
  $trowx["showkeys"]=$stif["showkeys"];
  $ptshowk=explode(",",$stif["showkeys"]);
  $totpt=countx($ptshowk);
  $tj=0;
  for ($z=0;$z<$totpt;$z++){
   if ($ptshowk[$z]==$kx){
   $tj=$z+1;
   };
  };
  $trowx["tj"]=$tj;
  $trowx["tablename"]=$stif["tablename"];
  allkeys=",";
  eval('allkeys=allkeys+'+$stif["tablename"]+'akb["COLUMN"]["ALLKEY"];');
  $trowx["allkeys"]=allkeys;
  $trowx["shortid"]=$stif["shortid"];
  if ($kx!="OPRT"){
   $trowx["dxtype"]=dftval($kyif[$kx]["COLUMN_DXTYPE"],"varchar"); 
  }else{
   $trowx["dxtype"]="varchar";
  }
  if ($kx!="OPRT"  && $kx!="itemOprt"){
   
   acthtml=dftval($kyif[$kx]["COLUMN_ACTHTM"],"");
   
  }else{
   acthtml="";
  }
  
  if ($kx!="OPRT"  && $kx!="itemOprt"){
   dspled=dftval($kyif[$kx]["COLUMN_DSPLD"],"0");
  }else{
   dspled=1;
  }
  if (dspled*1==0 && dspled!=""){
   $trowx["dsplhtml"]="display:none;";
  }else{
   $trowx["dsplhtml"]="";
  } 
  if ($kx!="OPRT" && $kx!="itemOprt"){
   canged=dftval($kyif[$kx]["COLUMN_CANGE"],"0");
  }else{
   canged=0;
  }
  
  if (canged*1==0 && canged!=""){
   $trowx["rdolhtml"]="readonly";  
  }else{
   $trowx["rdolhtml"]="";  
  }
  $trowx["thisolmk"]=$tbolmk;
   return $trowx;  
 }
function formtrowx($trowx,$kx,$hvx,$tbsno,$tbolmk,$jx,$srt){  
  $trowx["key"]=$kx;
  $trowx["ti"]=$jx;
  
  
  
  if ($tbsno=="0"){
   $trowx["hexvalue"]=$hvx;
   $trowx["value"]=tostring($hvx);
   $trowx["hvalue"]=toquote($hvx);
   //$trowx["mvalue"]=fmvalue($stif["tablename"],$srt[$kx][0],$tbsno,$kx,qian($kyif[$kx]["COLUMN_SSHOW"],"|"),$jx,$srt);
  }else{
   $trowx["hexvalue"]=$hvx;
   $trowx["hvalue"]=toquote($hvx);
   $trowx["value"]=tostring($hvx);
   //$trowx["mvalue"]=fmvalue($stif["tablename"],$vx,$tbsno,$kx,qian($kyif[$kx]["COLUMN_SSHOW"],"|"),$jx,$srt);
  }
  $trowx["key0"]=$kx+$tbsno;
  $trowx["thissno"]=$tbsno;

  
  $trowx["thisolmk"]=$tbolmk;
   return $trowx;  
 }
function formtrowz($trowx,$kx,$hvx,$tbsno,$tbolmk,$kyif,$stif,$jx,$srt){  
  $trowx["key"]=$kx;
  $trowx["ti"]=$jx;
  
  if ($tbsno=="0"){
   $trowx["hexvalue"]=$hvx;
   $trowx["value"]=tostring($hvx);
   $trowx["hvalue"]=toquote($hvx);
   //$trowx["mvalue"]=fmvalue($stif["tablename"],$srt[$kx][0],$tbsno,$kx,qian($kyif[$kx]["COLUMN_SSHOW"],"|"),$jx,$srt);
  }else{
   $trowx["hexvalue"]=$hvx;
   $trowx["hvalue"]=toquote($hvx);
   $trowx["value"]=tostring($hvx);
   //$trowx["mvalue"]=fmvalue($stif["tablename"],$vx,$tbsno,$kx,qian($kyif[$kx]["COLUMN_SSHOW"],"|"),$jx,$srt);
  }
  $trowx["kexplain"]="";
  $trowx["vqx"]=""
  $trowx["key0"]=$kx+$tbsno;
  $trowx["thissno"]=$tbsno;
  $trowx["showkeys"]="";
  
  
  $tj=0;
  
  $trowx["tj"]=$tj;
  $trowx["tablename"]="";
  allkeys=",";
  
  $trowx["allkeys"]=allkeys;
  $trowx["shortid"]="";
  
   if ($kx!="OPRT"  && $kx!="itemOprt"){
    acthtml="";
   }else{
    acthtml="";
   }
  
   if ($kx!="OPRT"  && $kx!="itemOprt"){
    dspled="1";
   }else{
    dspled="1";
   }
  
   if (dspled*1==0 && dspled!=""){
    $trowx["dsplhtml"]="display:none;";
   }else{
    $trowx["dsplhtml"]="";
   } 
  
   if ($kx!="OPRT" && $kx!="itemOprt"){
    canged="0";
   }else{
    canged="0";
   }
  
   if (canged*1==0 && canged!=""){
   //$trowx["rdolhtml"]="readonly";  
    $trowx["rdolhtml"]="";  
   }else{
    $trowx["rdolhtml"]="";  
   }
   
   $trowx["thisolmk"]=$tbolmk;
   return $trowx;  
 }
 function initdetail(){
  //?stid=zWdfMn&SNO=1&cfid=newdftstyle
  stid=GetRequest().stid;
  SNO=GetRequest().SNO;
  
  prehref=decodeURIComponent(location.href);
  houhref=hou(prehref,"?");
  pthref=houhref.split("&");
  totp=pthref.length;
  fmxxx="";
  for (i=0;i<totp;i++){
 if (qian(pthref[i],"=")!="SNO" && qian(pthref[i],"=")!="stid" && qian(pthref[i],"=")!="cfid"){
  fmxxx=fmxxx+"&"+pthref[i];
 }
  }
  
  bodyhtml=document.body.innerHTML;
  if (stid!=undefined && stid!="" && bodyhtml.indexOf("{contentx}")>0){
 if (SNO=="" || SNO==undefined){
   SNO="0";
 }
 
 bkdata=ajaxhtmlpost("/localxres/funx/anyshortnew/?stid="+stid+"&SNO="+SNO+"&tmp=data"+fmxxx,"");  
 document.body.innerHTML=bkdata;
  }else{
 return false;
  }
}
function makepageswc(pgcd,curpage,pagenum,tabnm,shortid,totrst){
    pagesrd=pgcd["pgsrd"];
    pagein=pgcd["pgin"];
    pageout=pgcd["pgout"];
    nextfiv=intval(curpage)+3;
    prefiv=intval(curpage)-3;  
    if (totrst%pagenum==0){
      totye=intval(totrst/pagenum);
    }else{
      totye=intval(totrst/pagenum)+1;  
    }
    if (prefiv<0){
      startp=0;
    }else{
      startp=prefiv;
    }
    if (nextfiv>totye){
       deliv=totye;
    }else{
       deliv=nextfiv;
    }  
    $fmy="";
    $fmslct="";
    $fmslctb="";
    for ($t=0;$t<totye;$t++){
      $fmslct=$fmslct+($t+1)+",";
      $fmslctb=$fmslctb+"第"+($t+1)+"页,";
    };
    if ($totye>0){
      $fmslct=substr($fmslct,0,strlen($fmslct)-1);
      $fmslctb=substr($fmslctb,0,strlen($fmslctb)-1);
    };  
    $fmselect=formselect($fmslctb,$fmslct,$pg,"topage","layui-select","onchange=\"tospage(document.getElementById('topage').value);\"");
    $fmselectpage=formselect($fmslctb,$fmslct,$pg,"topage","layui-select","onchange=\"tospage(document.getElementById('topage').value);\"");
    $fmspage="显示10条/页,显示20条/页,显示25条/页,显示30条/页,显示50条/页,显示100条/页,显示150条/页,显示200条/页,显示250条/页,显示300条/页,显示500条/页,显示800条/页,显示1000条/页,显示所有";
    $fmbpage="10,20,25,30,50,100,150,200,250,300,500,800,1000,0";
    $fmpageset=formselect($fmspage,$fmbpage,$pgn,"setpagenum","layui-select","onchange=\"setpage(document.getElementById('setpagenum').value);\"");  
  for ($t=startp;$t<deliv;$t++){
   if ($pg==($t+1)){
     demo=pagein;
     demo=demo.replce("<page>",($t+1));
     $fmy=$fmy+demo;   
   }else{
     demo=pagein;
     demo=demo.replce("<page>",($t+1));
     $fmy=$fmy+demo;   
   };
  };  
  if (curpage-1<1){
    $prepg=1;
  }else{
    $prepg=curpage-1;
  };
  if (curpage+1>totye){
    $nxtpg=totye;
  }else{
    $nxtpg=prepage+1; 
  };
  pagesrd=pagesrd.replace(/\[tabname\]/g,tabnm);
  pagesrd=pagesrd.replace(/\[shortid\]/g,shortid);
  pagesrd=pagesrd.replace(/\[pageinner\]/g,$fmy);
  pagesrd=pagesrd.replace(/\[firstpage\]/g,"1");
  pagesrd=pagesrd.replace(/\[totye\]/g,totye);
  pagesrd=pagesrd.replace(/\[prepage\]/g,$prepg);
  pagesrd=pagesrd.replace(/\[nextpage\]/g,$nxtpg);
 return pagesrd; 
}
function pageabc($totye,$pg,$pgn,$totallrst,$tbnm){
  if (($totye>0)==false ){
 $totye=1;
  }else{
 $totye=Math.ceil($totye);
  }
  if (($pg>0)==false ){
 $pg=1;
  }
  if (($pgn>0)==false ){
 $pgn=30;
  }
  if ( $pg=="NaN"){
 $pg=1;
  }  
  $nextfiv=intval($pg)+3;
  $prefiv=intval($pg)-3;  
  if ($prefiv<0){
 $startp=0;
  }else{
 $startp=$prefiv;
  }
  if ($nextfiv>$totye){
 $deliv=$totye;
  }else{
 $deliv=$nextfiv;
  }  
  $fmy="";
  $fmslct="";
  $fmslctb="";
  $xid="";
  $stid="";
  for ($t=0;$t<$totye;$t++){
   $fmslct=$fmslct+($t+1)+",";
   $fmslctb=$fmslctb+"第"+($t+1)+"页,";
  };
  if ($totye>0){
   $fmslct=substr($fmslct,0,strlen($fmslct)-1);
   $fmslctb=substr($fmslctb,0,strlen($fmslctb)-1);
  };  

  $fmselect=formselect($fmslctb,$fmslct,$pg,"topage","layui-select","onchange=\"tospage(document.getElementById('topage').value);\"");
   $fmselectjs=formselect($fmslctb,$fmslct,$pg,"topage","layui-select","onchange=\"tospage(document.getElementById('topage').value);\"");

  $fmspage="显示10条/页,显示20条/页,显示25条/页,显示30条/页,显示50条/页,显示100条/页,显示150条/页,显示200条/页,显示250条/页,显示300条/页,显示500条/页,显示800条/页,显示1000条/页,显示所有";
   $fmbpage="10,20,25,30,50,100,150,200,250,300,500,800,1000,0";
   
   $fmpagejs=formselect($fmspage,$fmbpage,$pgn,"setpagenum","layui-select","onchange=\"setpage(document.getElementById('setpagenum').value);\"");  
  for ($t=$startp;$t<$deliv;$t++){
   if ($pg==($t+1)){
   $fmy=$fmy+"<span class=\"layui-laypage-curr\"><em class=\"layui-laypage-em\"></em><em>"+($t+1)+"</em></span>";   
   }else{
   $fmy=$fmy+"<a href=\"javascript:void(0);\" onclick=\"tospage("+($t+1)+")\">"+($t+1)+"</a>";   
   };
  };  
  if ($pg-1<1){
 $lstpg=1;
  }else{
 $lstpg=$pg-1;
  };
  if ($pg+1>$totye){
 $nxtpg=$totye;
  }else{
 $nxtpg=$pg+1; 
  };

  $fmy="<a href=\"javascript:void(0)\" onclick=\"tochange()\"><img id=\"tcg\" src=\"/localxres/iconsetx/pagecontrol/移动.svg\" style=\"width:20px;height:20px;\"></a><a href=\"javascript:void(0);\" id=\"setwh\" style=\"display:none;\" onclick=\"setwh()\">设置</a><a href=\"javascript:void(0)\" onclick=\"window.open(location.href+'')\"><img src=\"/localxres/iconsetx/pagecontrol/qj37.svg\" style=\"width:20px;height:20px;\"></a><span class=\"layui-laypage-count\">共"+$totallrst+"条(共"+$totye+"页)</span><span class=\"layui-laypage-limits\">"+$fmselectjs+"</span><span class=\"layui-laypage-limits\">"+$fmpagejs+"</span><div class=\"layui-box layui-laypage layui-laypage-default\" id=\"layui-laypage-1\"><a href=\"javascript:void(0)\" onclick=\"tospage("+$lstpg+")\" class=\"layui-laypage-prev\" data-page=\""+$lstpg+"\">上一页</a><a href=\"javascript:void(0);\" onclick=\"tospage(1)\" class=\"layui-laypage-first\">首页</a>"+$fmy+"<a href=\"javascript:void(0)\" onclick=\"tospage("+$totye+")\" class=\"layui-laypage-last\">尾页</a><a href=\"javascript:void(0);\" onclick=\"tospage("+$nxtpg+")\" class=\"layui-laypage-next\" data-page=\""+$nxtpg+"\">下一页</a></div>&nbsp;&nbsp;&nbsp;<a class=\"layui-btn\"  onclick=\"quanxuan();\">全选</a>&nbsp;&nbsp;&nbsp;<a href=\"javascript:void(0)\" id=\"isu\" onclick=\"changeb()\"><img src=\"/localxres/iconsetx/pagecontrol/xg0.svg\" style=\"width:20px;height:20px;\"></a><input id=\"isupdate\" type=\"hidden\" value=\"0\" lay-skin=\"primary\">";
 return $fmy; 
}
//页面识别本用户访问是否有错误码--
function pageaaa($totye,$pg,$pgn,$totallrst){
  if (($totye>0)==false ){
  $totye=1;
  }else{
  $totye=Math.ceil($totye);
  }
  if (($pg>0)==false ){
  $pg=1;
  }
  if (($pgn>0)==false ){
  $pgn=30;
  }
  if ( $pg=="NaN"){
  $pg=1;
  }  
  $nextfiv=intval($pg)+3;
  $prefiv=intval($pg)-3;  
  if ($prefiv<0){
  $startp=0;
  }else{
  $startp=$prefiv;
  }
  if ($nextfiv>$totye){
  $deliv=$totye;
  }else{
  $deliv=$nextfiv;
  }  
  $fmy="";
  $fmslct="";
  $fmslctb="";
  $xid="";
  $stid="";
  for ($t=0;$t<$totye;$t++){
   $fmslct=$fmslct+($t+1)+",";
   $fmslctb=$fmslctb+"第"+($t+1)+"页,";
  };
  if ($totye>0){
   $fmslct=substr($fmslct,0,strlen($fmslct)-1);
   $fmslctb=substr($fmslctb,0,strlen($fmslctb)-1);
  };  

  $fmselect=formselect($fmslctb,$fmslct,$pg,"topage","layui-select","onchange=\"tospage(document.getElementById('topage').value);\"");
   $fmselectjs=formselect($fmslctb,$fmslct,$pg,"topage","layui-select","onchange=\"tospage(document.getElementById('topage').value);\"");

  $fmspage="10 条/页,20 条/页,30 条/页,40 条/页,50 条/页,60 条/页,70 条/页,80 条/页,90 条/页,100 条/页";
  $fmbpage="10,20,30,40,50,60,70,80,90,100";
  $fmpagejs=formselect($fmspage,$fmbpage,$pgn,"setpagenum","layui-select","onchange=\"setpagex(document.getElementById('setpagenum').value);\"");   
  
  for ($t=$startp;$t<$deliv;$t++){
   if ($pg==($t+1)){       
  $fmy=$fmy+"<span class=\"layui-laypage-curr\"><em class=\"layui-laypage-em\"></em><em>"+($t+1)+"</em></span>";  
   }else{
  $fmy=$fmy+"<a href=\"javascript:void(0);\" onclick=\"tospagex("+($t+1)+")\">"+($t+1)+"</a>";  
   };
  };  
  if ($pg-1<1){
  $lstpg=1;
  }else{
  $lstpg=$pg-1;
  };
  if ($pg+1>$totye){
  $nxtpg=$totye;
  }else{
  $nxtpg=$pg+1;  
  };
  if ($pg+1<=$totye){
  $nextdemo="<a class=\"layui-laypage-next\" data-page=\""+$nxtpg+"\" href=\"javascript:;\" onclick=\"tospagex("+$nxtpg+")\"><i class=\"layui-icon\"></i></a>";
  }else{
  $nextdemo="<a class=\"layui-laypage-next layui-disabled\" data-page=\""+$nxtpg+"\" href=\"javascript:;\" ><i class=\"layui-icon\"></i></a>";
  }
  if ($pg-1>=1){
  $predemo="<a class=\"layui-laypage-prev \" data-page=\""+$lstpg+"\" href=\"javascript:;\" onclick=\"tospagex("+$lstpg+")\"><i class=\"layui-icon\"></i></a>";
  }else{
  $predemo="<a class=\"layui-laypage-prev layui-disabled\" data-page=\"0\" href=\"javascript:;\"><i class=\"layui-icon\"></i></a>";
  }
  $qianwang="<span class=\"layui-laypage-skip\">前往<input id=\"gtpg\" class=\"layui-input\" min=\"1\" type=\"text\" value=\"1\">页<button class=\"layui-laypage-btn\" onclick=\"gtopg()\" type=\"button\">确定</button></span><span class=\"layui-laypage-count\">共 "+$totallrst+" 条</span>";
  pagedemo="<span class=\"layui-laypage-limits\">"+$fmpagejs+"</span>";
  pagedemo=pagedemo+$predemo+$fmy+$nextdemo+$qianwang;  
 return pagedemo; 
}
function gtopg(){
  sckeyx=$("#sckey").val();
  sckdemo=qian(sckeyx,"|");
  sckdata=hou(sckeyx,"|");
  ptsdemo=sckdemo.split(",");
  ptddemo=sckdata.split(",");
  totpt=ptsdemo.length;
  fmqry="";
  for (i=0;i<totpt;i++){
  tmpval="";
  eval("tmpval=$(\"#"+ptsdemo[i]+"\").val();");
  if (tmpval!="" && tmpval!=undefined){
  fmqry=fmqry+"&"+ptddemo[i]+"="+tmpval;
  }
  }
  srcurl=$("#srcurl").val()+"?page="+$("#gtpg").val()+"&limit="+$("#setpagenum").val()+fmqry;
  z=mktabhtml(srcurl,$("#gtpg").val(),$("#setpagenum").val());

}
function exchangestr($strx,$xid,$tbnm){
  if ($strx!=""){
 $nhtxt=$strx;
 if ($nhtxt.indexOf("get-")>0){
  $ptnhtxt=explode("[get-",$nhtxt);
  $totpt=countx($ptnhtxt);
  for ($f=0;$f<$totpt;$f++){
  $tmpok=qian($ptnhtxt[$f],"]");
  $nhtxt=str_replace("[get-"+$tmpok+"]",_get($tmpok),$nhtxt);  
  };
 }
   if ($nhtxt.indexOf("atv-")>0){ 
 if (strpos($nhtxt,"{atv-")>0){
   $ptatv=explode("{atv-",$nhtxt);
   $totatv=countx($ptatv);
   for ($g=0;$g<$totatv;$g++){
  $tmpatv=qian($ptatv[$g],"}");
  $nhtxt=str_replace("{atv-"+$tmpatv+"}",atv($tmpatv),$nhtxt);
   };
 };
   };
   if ($nhtxt.indexOf("utv-")>0){
 if (strpos($nhtxt,"{utv-")>0){
   $ptutv=explode("{utv-",$nhtxt);
   $totutv=countx($ptutv);
  for ($h=0;$h<$totutv;$h++){
  $tmputv=qian($ptutv[$h],"}");
  $nhtxt=str_replace("{utv-"+$tmputv+"}",utv($tmputv),$nhtxt);
  };
 };
   };
 $nhtxt=str_replace("[shortid]",$xid,$nhtxt);
 $nhtxt=str_replace("[tablename]",$tbnm,$nhtxt);
 return $nhtxt;
  }else{
 return "";
  }
}
function fmvalue($tbnmx,$dvalue,$dsno,$dkey,$sfun,$dn,$arrdt){  
$nhtxt="";
$sfunx="";
$funvalue="";
$newfunx=""; 
tmpvx="";
$colname=$dkey;
$snox=$dsno;
//$ktitle
$sfun=$sfun.toString();
$sttab=$tbnmx;
$thusvalue=$dvalue;
smd5=$tbnmx+$dvalue+$dsno+$dkey+$sfun+$dn;
smd5="a"+smd5.MD5();
eval('tmpvx=sessionStorage.'+smd5+';');
if (tmpvx!="" && tmpvx!=undefined && $dvalue!="" && $dsno!="" && $dkey!=""){
  
  return tostring(tmpvx);
}else{
  if ($dkey=="apps"){   
  }
  $sfun=qian(" "+$sfun,"|");
 if ($sfun=="" || $dn==-1 || $sfun==undefined ){
   if(strlen($dvalue)>20){
   return substr($dvalue,0,20);
   }else{
   return $dvalue;
   };
 }  
fd=0;
$tmpvlx="";
  if (strpos("x"+$sfun,"CASE")>0 && strpos("x"+$sfun,"E@CS")>0){
 $ptfunx=explode("CASE",$sfun);
 $totpf=countx($ptfunx);
 $fd=0;
 for ($pf=1;$pf<$totpf;$pf++){   
  $tmpfn=qian(hou($ptfunx[$pf],"::"),"E@CS");
  $tmpct=qian($ptfunx[$pf],"::");
  $tmptj=substr($ptfunx[$pf],0,1);
  $tmpvlx=qian($ptfunx[$pf],"::");   
  $tmpvlx=$tmpvlx.replace($tmptj,"");  
  switch($tmptj){
   case "@":
   if (((strpos("xxx"+$dvalue,$tmpvlx)>0 && $tmpvlx!="") || $tmpvlx=="") && $fd==0){
   $newfunx=$tmpfn;
   $fd=$fd+1;
   }
   break;
   case "=":
  if ($dvalue==$tmpvlx || intval($dvalue)*1==intval($tmpvlx)*1 && $tmpvlx!="" && $fd==0){
  $newfunx=$tmpfn;   
  $fd=$fd+1;
   };
   break;
   case ">":
   if ((($tmpvlx*1)>($dvalue*1)) && $tmpvlx!="" && $fd==0){
  $newfunx=$tmpfn;
  $fd=$fd+1;
   };
  break;
   case "<":
   if ((($tmpvlx*1)<($dvalue*1)) && $tmpvlx!="" && $fd==0){
  $newfunx=$tmpfn;
  $fd=$fd+1;
   };
   break;
   default:   
   $sfun="";
  }
   };//for
   $sfun="";
   if ($fd==0){   
   }
  }else{
  };  
 if ($newfunx!=""){
   $sfun=turncon($newfunx);   
 }else{
   
   if (strpos("x"+$sfun,"unction ")>0 ){
   }else{
   $sfun=turncon($sfun);  
   }
 }
  if (strpos("x"+$sfun,"{")>0 || strpos("x"+$sfun,"unction ")>0 || strpos($sfun,"}")>0 ){
   if (strpos($sfun,"unction ")>0 && strpos($sfun,"function(")<=0){
  funstr='$nhtxt='+qian(hou($sfun,"unction "),"{")+";";
  xfunstr=substr(funstr,2,strlen(funstr)-2);
  if (xfunstr.indexOf("$")<=0){
   funstr=one_replace("key0",syh()+"p_"+$dkey+$dsno+syh(),funstr,6); 
   funstr=one_replace("key",syh()+$dkey+syh(),funstr,6);
   funstr=one_replace("SNO",syh()+$dsno+syh(),funstr,6);
   funstr=one_replace("table",syh()+$tbnmx+syh(),funstr,6);
   funstr=one_replace("date",syh()+date("Y-m-d")+syh(),funstr,6);
   funstr=one_replace("now",syh()+date("Y-m-d H:i:s")+syh(),funstr,6);
   funstr=one_replace("anymark",syh()+date("YmdHis")+randomWord(false,6)+syh(),funstr,6);
   funstr=one_replace("OLMK",syh()+onlymark()+syh(),funstr,6);
   funstr=one_replace("thiskey",syh()+$dkey+syh(),funstr,6);
   funstr=one_replace("thistable",syh()+$tbnmx+syh(),funstr,6);
   funstr=one_replace("thissno",syh()+$dsno+syh(),funstr,6);
   funstr=one_replace("thisvalue",syh()+tostring($dvalue)+syh(),funstr,3);  
   if (funstr.indexOf("key-")>0){
   $ptnhtxt=explode("key-",funstr);
   $totpt=countx($ptnhtxt); 
   for ($f=1;$f<$totpt;$f++){
   $tmpok=qian($ptnhtxt[syh()+$f],",");  
   if ($trow["showkeys"].indexOf($tmpok)>0){
     funstr=one_replace("key-"+$tmpok,$arrdt[$tmpok][$dn*1],funstr,6);
   }else{
     funstr=one_replace("key-"+$tmpok,"",funstr,6);
   }
   };//for
  }//if key-
  }//if $
  eval(funstr);
   }else{//$unction
  $nhtxt=$sfun;   
   }
   $nhtxt=str_replace("{thisid}","ipt"+$dkey+$dsno,$nhtxt);   
   $nhtxt=str_replace("{thiskey}",$dkey,$nhtxt);
   if (strpos("xxx"+$nhtxt,"{col-key")>0){
  $kfun=array(array());
  $kfun=thekeyfun($kfun,glb(),$tbnmx,$arrdt["table"]["keys"]);  
  $nhtxt=keyexc($dkey,$arrdt["table"]["keys"],$kfun,$nhtxt);
   }
   $nhtxt=str_replace("{thistable}",$tbnmx,$nhtxt);
   $grp=atv("(coode_sysdefault@companyid='"+glc()+"').groupid");
   $nhtxt=str_replace("{grp}",$grp,$nhtxt);
   $nhtxt=str_replace("{thissno}",$dsno,$nhtxt);
   $nhtxt=str_replace("{SNO}",$dsno,$nhtxt);
   $nhtxt=str_replace("{key}",$dkey,$nhtxt);
   $nhtxt=str_replace("{key0}","p_"+$dkey+$dsno,$nhtxt);
   $nhtxt=str_replace("{table}",$tbnmx,$nhtxt);
   $nhtxt=str_replace("{OLMK}",onlymark(),$nhtxt);
   $nhtxt=str_replace("{date}",date("Y-m-d"),$nhtxt);
  $nhtxt=str_replace("{now}",date("Y-m-d H:i:s"),$nhtxt);
   $nhtxt=str_replace("{uid}",glu(),$nhtxt);
   $nhtxt=str_replace("{gid}","",$nhtxt);
   $nhtxt=str_replace("{cid}",glc(),$nhtxt);
   $nhtxt=str_replace("{appid}",_get("appid"),$nhtxt);
   $nhtxt=str_replace("{thisshort}",_get("tmpshortid"),$nhtxt);
   $nhtxt=str_replace("{thisshort}",_get("tmpstid"),$nhtxt);
   $nhtxt=str_replace("{shortid}",_get("shortid"),$nhtxt);
   $nhtxt=str_replace("{shortid}",_get("stid"),$nhtxt);
   $nhtxt=str_replace("{thisvalue}",tostring($dvalue),$nhtxt);
   if ($dvalue=="1" || $dvalue=="checked"){
  $nhtxt=str_replace("{checked}","checked",$nhtxt);
   }else{
  $nhtxt=str_replace("{checked}","",$nhtxt);
   };//
   if ($dvalue==""){
  $nhtxt=str_replace("{imgvalue}",dfp(),$nhtxt);
   }else{
  $nhtxt=str_replace("{imgvalue}",str_replace(";","",$dvalue),$nhtxt);
   };//
   $nhtxt=str_replace("{siteurl}",glw(),$nhtxt);
   $nhtxt=str_replace("{rip}",getip(),$nhtxt);
   $nhtxt=str_replace("{defaultbase}",glb(),$nhtxt);
   $nhtxt=str_replace("{defaultip}",gl(),$nhtxt);
   $nhtxt=str_replace("{today}",date("Y-m-d"),$nhtxt);
   $nhtxt=str_replace("{now}",date("Y-m-d H:i:s"),$nhtxt);
   if (strpos("xxx".$nhtxt,"{duofile-")>0){  
  $ftj=qian(hou($nhtxt,"{duofile-"),"}");
  $nhtxt=str_replace("{duofile-"+$ftj+"}",duofilex($ftj,tostring($dvalue)),$nhtxt); 
   };//

  if ($nhtxt.indexOf("{key-")>0){
   $ptnhtxt=explode("{key-",$nhtxt);
   $totpt=countx($ptnhtxt); 
   for ($f=1;$f<$totpt;$f++){
   $tmpok=qian($ptnhtxt[$f],"}");  
   if (strpos($arrdt[$dkey][0],$tmpok)>0){
  $nhtxt=str_replace("{key-"+$tmpok+"}",$arrdt[$tmpok][$dn*1],$nhtxt);
   }
   };//
  }
  if (strpos("xxx"+$nhtxt,"{col-")>0){
  //$kfun=array(array());
  $kfun=thekeyfun($kfun,glb(),$tbnmx,$arrdt[$dkey][0]);  
  $ptnhtxt=explode("{col-",$nhtxt);
  $totpt=countx($ptnhtxt);
  for ($f=1;$f<$totpt;$f++){
   $tmpok=qian($ptnhtxt[$f],"}");
   $tmpokx=qian($tmpok,":");
   $nhtxt=keyexc($tmpokx,$arrdt[$dkey][0],$kfun,$nhtxt);
  };//
 }
  if ($nhtxt.indexOf("{get-")>0){
   $ptnhtxt=explode("{get-",$nhtxt);
   $totpt=countx($ptnhtxt);
 for ($f=1;$f<$totpt;$f++){
   $tmpok=qian($ptnhtxt[$f],"}");
   $nhtxt=str_replace("{get-"+$tmpok+"}",_get($tmpok),$nhtxt);
 };//
  }
  if ($nhtxt.indexOf("{post-")>0){
 $ptnhtxt=explode("{post-",$nhtxt);
 $totpt=countx($ptnhtxt);
 for ($f=1;$f<$totpt;$f++){
   $tmpok=qian($ptnhtxt[$f],"}");
   $nhtxt=str_replace("{post-"+$tmpok+"}",_post($tmpok),$nhtxt);
 };//
  }
  if ($nhtxt.indexOf("{cookie-")>0){
   $ptnhtxt=explode("{cookie-",$nhtxt);
   $totpt=countx($ptnhtxt);
   for ($f=1;$f<$totpt;$f++){
   $tmpok=qian($ptnhtxt[$f],"}");
   $nhtxt=str_replace("{cookie-"+$tmpok+"}",_cookie($tmpok),$nhtxt);
   };//
  }
 if ($nhtxt.indexOf("{atv-")>0){
  if (strpos($nhtxt,"{atv-")>0){
   $ptatv=explode("{atv-",$nhtxt);
   $totatv=countx($ptatv);
   for ($g=1;$g<$totatv;$g++){
   $tmpatv=qian($ptatv[$g],"}");
   $nhtxt=str_replace("{atv-"+$tmpatv+"}",atv($tmpatv),$nhtxt);
   };//
  };//
 };
 if ($nhtxt.indexOf("{utv-")>0){
  if (strpos($nhtxt,"{utv-")>0){
   $ptutv=explode("{utv-",$nhtxt);
   $totutv=countx($ptutv);
   for ($h=1;$h<$totutv;$h++){
   $tmputv=qian($ptutv[$h],"}");
   $nhtxt=str_replace("{utv-"+$tmputv+"}",utv($tmputv),$nhtxt);
 };//
   };//   
  };
 }else{
  $nhtxt=$dvalue;
 };//

   $nhtxt=turnlab($nhtxt);
   $nhtxt=turnquote($nhtxt);
   eval('sessionStorage.'+smd5+'=$nhtxt;');
   return $nhtxt;
 };
}

function formdiybtn($stid,$diycode){
  $fmx="";
  $fmxy="";
 if ($diycode!=""){
  if (strpos($diycode,",")>0){
  $ptdiy=explode(",",$diycode);
  $totptd=countx($ptdiy);
  $fmx="";
  $fmxy="";
  for ($p=0;$p<$totptd;$p++){
   $ttx=qian($ptdiy[$p],":");
   $uux=hou($ptdiy[$p],":");
   if (strpos($uux,")")>0){
   $fmx=$fmx+"<a class=\"layui-btn\" onclick=\""+$uux+"\">"+$ttx+"</a>";
   if (($gsqc*1)==$p){
  $fmxy=$fmxy+"<li><a href=\"javascript:void(0);\" onclick=\""+$uux+"\" class=\"current\">"+$ttx+"</a></li>";
   }else{
   $fmxy=$fmxy+"<li><a href=\"javascript:void(0);\" onclick=\""+$uux+"\">"+$ttx+"</a></li>";
   };
   }else{
   $fmx=$fmx+"<a class=\"layui-btn\" onclick=\"intourl('"+$uux+"')\">"+$ttx+"</a>";
   if (($gsqc*1)==1){
  $fmxy=$fmxy+"<li><a href=\"javascript:void(0);\" onclick=\"intourl('"+$uux+"')\" class=\"current\">"+$ttx+"</a></li>";
   }else{
   $fmxy=$fmxy+"<li><a href=\"javascript:void(0);\" onclick=\"intourl('"+$uux+"')\">"+$ttx+"</a></li>";
   };
   };
  };//for
   }else{
   $ttx=qian($diycode,":");
   $uux=hou($diycode,":");
   if (strpos($uux,")")>0){
   $fmx=$fmx+"<a class=\"layui-btn\" href=\"javascript:void(0);\" onclick=\""+$uux+"\">"+$ttx+"</a>";
   if (($gsqc*1)==1){
   $fmxy=$fmxy+"<li><a href=\"javascript:void(0);\" onclick=\""+$uux+"\">"+$ttx+"</a></li>";
   }
   }else{
   $fmx=$fmx+"<a class=\"layui-btn\" href=\"javascript:void(0);\" onclick=\"intourl('"+$uux+"')\">"+$ttx+"</a>";
   if (($gsqc*1)==1){
   $fmxy=$fmxy+"<li><a href=\"javascript:void(0);\" onclick=\"intourl('"+$uux+"')\">"+$ttx+"</a></li>";
   };
   };   
  };
 $dbtn="<div id=\"wrap\"><div id=\"content\" ><ul >"+$fmxy+"</ul></div></div>";
 return $dbtn;
  }else{
   return "";
  };
}

function anyjson(url,tbnm,page,xid){
  $jsonx=new Array();
    domn=GetRequest().domn;
    stk=GetRequest().stk;
    if (domn==undefined || stk==undefined){
      bkdata=ajaxhtmlpost(qian(url,"#")+"&datatype=json","");
      datax=eval('('+bkdata+')');
    }else{
      domn=base64Decode(domn);
      datax=urldatap(domn,stk,qian(url,"#")+"&datatype=json","");
    }
  sxy=jsontosx(datax);
  $tabinfo=tablist(sxy,datax,tbnm,datax.keys,datax.totrcd,page,xid);
  $x=$tabinfo["html"];
  $jsonx["totrcd"]=datax.totrcd;
  $jsonx["html"]=$x;
  $jsonx["json"]=bkdata;
  $jsonx["script"]=$tabinfo["tmpdtx"];
  $jsonx["exteval"]=$tabinfo["tmpdtx"];
  $jsonx["keys"]=datax.keys;
  $jsonx["sxy"]=sxy;
  $jsonx["url"]=url;  
  return $jsonx;
}