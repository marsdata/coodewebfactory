<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     function addtosql($sysid,$tabx,$strtype,$rtitle,$sqlstr,$sqlmd5){
 $extx=UX("select count(*) as result from coode_insdata where sysid='".$sysid."' and sqlmd5='".$sqlmd5."'");
 if (intval($extx)==0){
   $sqlx="sysid,relytab,strtype,sqlstring,restitle,sqlmd5,CRTM,UPTM,OLMK";
   $sqly="'$sysid','$tabx','$strtype','$sqlstr','$rtitle','$sqlmd5',now(),now(),'".onlymark()."'";
   $zz=UX("insert into coode_insdata(".$sqlx.")values(".$sqly.")");
   return true;
 }else{
   $xx=UX("update coode_insdata set UPTM=now() where sysid='".$sysid."' and sqlmd5='".$sqlmd5."'");
   return false;
 }
}
$timea=time();
$sysid=$_GET["sysid"];
if ($sysid!="all"){
 if ($sysid!=""){
  $tabcrt=combineurl(localroot(),"/tabcrt-".$sysid.".json");
  $crttxt=file_get_contents($tabcrt);
  $crtdata=json_decode($crttxt,false);
  $data=$crtdata->data;
  $totx=count($data);
  for ($j=0;$j<count($data);$j++){
    $relytab=$data[$j]->relytab;
    $sqlstring=$data[$j]->sqlstring;
    $sqlmd5=$data[$j]->sqlmd5;
    $restitle=$data[$j]->restitle;
    $zz=addtosql($sysid,$relytab,"createsql",$restitle,$sqlstring,$sqlmd5);
  }
  $sysres=combineurl(localroot(),"/sysres-".$sysid.".json");
  $systxt=file_get_contents($sysres);
  $vlsdata=json_decode($systxt,false);
  $vls=$vlsdata->vls;
  $totx=$totx+count($vls);
  for ($k=0;$k<count($vls);$k++){
   $restype=$vls[$k]->restype;
   $rescode=$vls[$k]->rescode;
   $restitle=$vls[$k]->restitle;
   $resmd5=$vls[$k]->resmd5;
   $zz=addtosql($sysid,$restype,"relyres",$restitle,$rescode,$resmd5);
  }
   $timeb=time();
   echo makereturnjson("1","提取成功数量为".$totx.",耗时：".($timeb-$timea)."秒","");
  }else{
   echo makereturnjson("0","缺少参数","");
  }
}else{
 $syscode=dftval($_GET["syscode"],"WEO");
 $sysid="0";
 $tabcrt=combineurl(localroot(),"/tabcrt-".$sysid.".json");
 $crttxt=file_get_contents($tabcrt);
 $crtdata=json_decode($crttxt,false);
 $data=$crtdata->data;
 for ($j=0;$j<count($data);$j++){
   $relytab=$data[$j]->relytab;
   $sqlstring=$data[$j]->sqlstring;
   $sqlmd5=$data[$j]->sqlmd5;
   $restitle=$data[$j]->restitle;
   $zz=addtosql($sysid,$relytab,"createsql",$restitle,$sqlstring,$sqlmd5);
 }
 $sysres=combineurl(localroot(),"/sysres-".$sysid.".json");
 $systxt=file_get_contents($sysres);
 $vlsdata=json_decode($systxt,false);
 $vls=$vlsdata->vls;
 for ($k=0;$k<count($vls);$k++){
  $restype=$vls[$k]->restype;
  $rescode=$vls[$k]->rescode;
  $restitle=$vls[$k]->restitle;
  $resmd5=$vls[$k]->resmd5;
  $zz=addtosql($sysid,$restype,"relyres",$restitle,$rescode,$resmd5);
 }
 $sysid="1";
  $tabcrt=combineurl(localroot(),"/tabcrt-".$sysid.".json");
 $crttxt=file_get_contents($tabcrt);
 $crtdata=json_decode($crttxt,false);
 $data=$crtdata->data;
 for ($j=0;$j<count($data);$j++){
   $relytab=$data[$j]->relytab;
   $sqlstring=$data[$j]->sqlstring;
   $sqlmd5=$data[$j]->sqlmd5;
   $restitle=$data[$j]->restitle;
   $zz=addtosql($sysid,$relytab,"createsql",$restitle,$sqlstring,$sqlmd5);
 }
 $sysres=combineurl(localroot(),"/sysres-".$sysid.".json");
 $systxt=file_get_contents($sysres);
 $vlsdata=json_decode($systxt,false);
 $vls=$vlsdata->vls;
 for ($k=0;$k<count($vls);$k++){
  $restype=$vls[$k]->restype;
  $rescode=$vls[$k]->rescode;
  $restitle=$vls[$k]->restitle;
  $resmd5=$vls[$k]->resmd5;
  $zz=addtosql($sysid,$restype,"relyres",$restitle,$rescode,$resmd5);
 }
 $sysid=$syscode;
  $tabcrt=combineurl(localroot(),"/tabcrt-".$sysid.".json");
 $crttxt=file_get_contents($tabcrt);
 $crtdata=json_decode($crttxt,false);
 $data=$crtdata->data;
 for ($j=0;$j<count($data);$j++){
   $relytab=$data[$j]->relytab;
   $sqlstring=$data[$j]->sqlstring;
   $sqlmd5=$data[$j]->sqlmd5;
   $restitle=$data[$j]->restitle;
   $zz=addtosql($sysid,$relytab,"createsql",$restitle,$sqlstring,$sqlmd5);
 }
 $sysres=combineurl(localroot(),"/sysres-".$sysid.".json");
 $systxt=file_get_contents($sysres);
 $vlsdata=json_decode($systxt,false);
 $vls=$vlsdata->vls;
 for ($k=0;$k<count($vls);$k++){
  $restype=$vls[$k]->restype;
  $rescode=$vls[$k]->rescode;
  $restitle=$vls[$k]->restitle;
  $resmd5=$vls[$k]->resmd5;
  $zz=addtosql($sysid,$restype,"relyres",$restitle,$rescode,$resmd5);
 }
 
$item='{"sysid":"[sysid]","relytab":"[relytab]","restitle":"[restitle]","sqltype":"[sqltype]","sqlval":"[sqlval]","sqlmd5":"[sqlmd5]"},';
$demo='{"status":"1","msg":"获取成功","vls":[<data>],"costtime":"[costtime]"}';
$cdrst=SX("select sysid,relytab,strtype,restitle,sqlstring,sqlmd5 from coode_insdata where sysid='".$syscode."' or sysid='0' or sysid='1' order by strtype");
$totc=countresult($cdrst);
$fmitem="";
for ($i=0;$i<$totc;$i++){
 $ssid=anyvalue($cdrst,"sysid",$i);
 $relytab=anyvalue($cdrst,"relytab",$i);
 $strtype=anyvalue($cdrst,"strtype",$i);
 $restitle=anyvalue($cdrst,"restitle",$i);
 $sqlstring=anyvalue($cdrst,"sqlstring",$i);
 $sqlmd5=anyvalue($cdrst,"sqlmd5",$i);
 $itemx=$item;
 $itemx=str_replace("[sysid]",$ssid,$itemx);
 $itemx=str_replace("[relytab]",$relytab,$itemx);
 $itemx=str_replace("[restitle]",$restitle,$itemx);
 $itemx=str_replace("[sqltype]",$strtype,$itemx);
 $itemx=str_replace("[sqlval]",$sqlstring,$itemx);
 $itemx=str_replace("[sqlmd5]",$sqlmd5,$itemx);
 $fmitem=$fmitem.$itemx;
}
$fmitem=killlaststr($fmitem);
$timeb=time();
$demo=str_replace("<data>",$fmitem,$demo);
$demo=str_replace("[costtime]",($timeb-$timea),$demo);
echo $demo;
}
     session_write_close();
?>