<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include mdir().'RNA/EARTH.php';
    $stk=$_GET["stk"];
    if (strpos(_get("fid"),"login")<=0){
     setcookie("uid",$_COOKIE["uid"],time()+3600,"/");
     setcookie("cid",$_COOKIE["cid"],time()+3600,"/");
     setcookie("uid",$_COOKIE["userid"],time()+3600,"/");
     setcookie("cid",$_COOKIE["comid"],time()+3600,"/");
     setcookie("grpcid",$_COOKIE["grpcid"],time()+3600,"/");
     setcookie("depart",$_COOKIE["depart"],time()+3600,"/");
     setcookie("dpmore",$_COOKIE["dpmore"],time()+3600,"/");
     setcookie("posids",$_COOKIE["posids"],time()+3600,"/");
     setcookie("roleids",$_COOKIE["roleids"],time()+3600,"/");
     setcookie("sysid",$_COOKIE["sysid"],time()+3600,"/");
     setcookie("stoken",$_COOKIE["stoken"],time()+3600,"/");
     setcookie("deadline",time()+3600,time()+3600,"/");
    }
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $srctype=dftval($_GET["srctype"],"");
$srcmark=dftval($_GET["srcmark"],"");
$hosturl=dftval($_GET["hosturl"],"");
$bktxt=file_get_contents("http://".$hosturl."DNA/EXF/anyfuns.php?fid=pushsyssrc&srctype=".$srctype."&srcmark=".$srcmark);
switch($srctype){
   case "fun":
    $bkdata=json_decode($bktxt);
    if (intval($bkdata->status)>0){
      $extx=UX("select count(*) as result from coode_funlist where funname='".$srcmark."'");
      if (intval($extx)>0){
       $zz=UX("update coode_funlist set funfull='".$bkdata->funfull."',PRIME=1 where funname='".$srcmark."'");
      }else{
        $sqlx="funname,funcname,funfull,oldfull,lastfull,CRTM,UPTM,OLMK";
        $sqly="'$srcmark','$srcmark','".$bkdata->funfull."','".$bkdata->funfull."','".$bkdata->funfull."',now(),now(),'".onlymark()."'";
        $sz=UX("insert into coode_funlist(".$sqlx.")values(".$sqly.")");
      }
    }
    echo makereturnjson("1","成功","");
   break;
   case "tabkeyval":
   $skey=hou($fn,".");
   $sno=qian(hou($fn,"SNO:"),".");
   $tbnm=qian($fn,"@");
   $kx=UX("update ".$tbnm."  set ".$skey."='".$bkdata->funfull."' where SNO='".$sno."'");
   break;
   case "tabactshow":
   $ckey=hou($fn,".");
   $tbnm=qian(hou($fn,"@"),".");
   $skey=qian($fn,"@");
   $kx=UX("update coode_keydetailx  set ".$skey."='".$bkdata->funfull."',PRIME=1 where TABLE_NAME='".$tbnm."' and COLUMN_NAME='".$ckey."'");
   break;
   case "temp":
    $bkdata=json_decode($bktxt);
   if (intval($bkdata->status)>0){
    $extx=UX("select count(*) as result from coode_domainunit where dumark='".$srcmark."'");      
    $relyface=$bkdata->relyface;
    $sysid=$bkdata->sysid; 
    $appid=$bkdata->appid; 
    $unittitle=$bkdata->unittitle; 
    $unitclass=$bkdata->unitclass; 
    $unitdescrib=$bkdata->unitdescrib;
    $outurl=$bkdata->outurl; 
    $industry=$bkdata->industry; 
    $business=$bkdata->business; 
    $matter=$bkdata->matter; 
    $casecode=$bkdata->casecode; 
    $cssfilex=$bkdata->cssfilex; 
    $stylex=$bkdata->stylex;  
    $scriptx=$bkdata->scriptx; 
    $jsfilex=$bkdata->jsfilex;
    $cssfiley=$bkdata->cssfiley;
    $jsfiley=$bkdata->jsfiley; 
    $styley=$bkdata->styley; 
    $scripty=$bkdata->scripty;  
    $templatecode=$bkdata->templatecode; 
    $pagesurround=$bkdata->pagesurround;
    if (intval($extx)>0){
      $sqlx="UPTM=now(),unittitle='".$unittitle."',unitclass='".$unitclass."',unitdescrib='".$unitdescrib."',cssfilex='".$cssfilex."',jsfilex='".$jsfilex."',stylex='".$stylex."',scriptx='".$scriptx."',casecode='".$casecode."',templatecode='".$templatecode."',pagesurround='".$pagesurround."',cssfiley='".$cssfiley."',jsfiley='".$jsfiley."',styley='".$styley."',scripty='".$scripty."',pagesurround='".$pagesurround."'";
      $z=UX("update coode_domainunit set ".$sqlx." where dumark='".$srcmark."'");    
     }else{
      $sqlx="relyface,outurl,domainmark,unitmark,dumark,unittitle,unitclass,unitdescrib,cssfilex,jsfilex,stylex,scriptx,cssfiley,jsfiley,styley,scripty,casecode,templatecode,pagesurround,demoresult,pagehtml";
      $sqly="'".$relyface."','','".qian($srcmark,".")."','".hou($srcmark,".")."','".$srcmark."','".$unittitle."','".$unitclass."','".$unitdescrib."','".$cssfilex."','".$jsfilex."','".$stylex."','".$scriptx."','".$cssfiley."','".$jsfiley."','".$styley."','".$scripty."','".$casecode."','".$templatecode."','".$pagesurround."','',''";
      $z=UX("insert into coode_domainunit(".$sqlx.")values(".$sqly.")");    
     }
   }
   echo makereturnjson("1","成功","");
   break;
   case "tab":
   echo $bktxt;
   break;
   default:
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>