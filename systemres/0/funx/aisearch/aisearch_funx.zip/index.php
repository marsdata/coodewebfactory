<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $askstr=unstrs(_post("askstr"));
$casetype=_get("ctype");
$trst=SX("select linemark,apicode from coode_wrdrestpdefine where typecodex='".$casetype."'");
$tott=countresult($trst);
if (intval($tott)==1){
 $restab=anyvalue($trst,"linemark",0);
 $apicode=anyvalue($trst,"apicode",0);
 $airestab="";
}else{
 $trst=SX("select SNO,apicode,airestab from aibot_botlist where botcode='".$casetype."'");
 $restab=$casetype;
 $apicode=anyvalue($trst,"apicode",0);
 $airestab=anyvalue($trst,"airestab",0);
}
$pgss=_get("pgss");
$csql=constval("bdrqtab");
$bdtab="bdairequest".date("Ym");
$csql=str_replace("[bdtab]",$bdtab,$csql);
$zz0=crttab(1,$csql);
$csql1=constval("asktab");
$asktab="wrdresnmask".date("Ym");
$csql1=str_replace("[asktab]",$asktab,$csql1);
$zz1=crttab(1,$csql1);
if (strpos("xx".$askstr,"它")>0 or strpos("xx".$askstr,"他")>0 or strpos("xx".$askstr,"此")>0 or strpos("xx".$askstr,"该")>0 or strpos("xx".$askstr,"这")>0){
 $tota=0;
}else{
 if ($airestab==""){
  $arst=SZ("select typecodex,typetitlex,rescode,restitle,count(rescode) as totr,strnum,STCODE from ".$restab."_wrdresnmpoints where '".$askstr."' like concat('%',nmstr,'%') group by rescode order by totr desc limit 0,5");
  $tota=countresult($arst);
 }else{
  if (strpos($airestab,"-")>0){
   $fst=qian($airestab,"-");
   $scd=hou($airestab,"-");
   $rsql="";
   for ($bb=intval($fst);$bb<intval($scd)+1;$bb++){
    $rsql=$rsql."select typecodex,typetitlex,rescode,restitle,count(rescode) as totr,strnum,STCODE from ".$restab."_wrdresnmpoints".$bb." where '".$askstr."' like concat('%',nmstr,'%') group by rescode union ";
   }
  }else{
    $rsql="";
    $pttab=explode(",",$airestab);
    for ($bb=0;$bb<count($pttab);$bb++){
      $rsql=$rsql."select typecodex,typetitlex,rescode,restitle,count(rescode) as totr,strnum,STCODE from ".$restab."_wrdresnmpoints".$pttab[$bb]." where '".$askstr."' like concat('%',nmstr,'%') group by rescode union ";
    }
  }
  $rsql=substr($rsql,0,strlen($rsql)-6);
  $arst=SZ($rsql." order by totr desc limit 0,5");
  //echo $rsql." order by totr desc limit 0,5";
  $tota=countresult($arst);
 }
}
$demo='{"status":"1","msg":"获取成功","rtnstr":"[rtnstr]","totx":"[totx]","totc":"[totc]","resnames":[<resdata>],"rescharas":[<reschara>]}';
$dataitem='{"tpcode":"[tpcode]","rescode":"[rescode]","restitle":"[restitle]","totr":"[totr]","strnum":"[strnum]"},';
$charaitem='{"tpcode":"[tpcode]","rescode":"[rescode]","restitle":"[restitle]","keytitle":"[keytitle]","keyval":"[keyval]"},';
$fmdata="";
$fmchara="";
$fmcdx="";
$ljc=0;
  $sqlx="strnum,askstr,typecodex,rescode,restitle,nmstr,CRTM,UPTM,OLMK";
  $sqly="strnum,'$askstr',typecodex,rescode,restitle,nmstr,now(),now(),OLMK";
  if ($airestab==""){
    $zz=UZ("insert into ".$asktab."(".$sqlx.") select ".$sqly." from  ".$restab."_wrdresnmpoints where '".$askstr."' like concat('%',nmstr,'%')");
  }else{
    if (strpos($airestab,"-")>0){
      $fst=qian($airestab,"-");
      $scd=hou($airestab,"-");    
      for ($bb=intval($fst);$bb<intval($scd)+1;$bb++){
       //$zz=UZ("insert into ".$asktab."(".$sqlx.") select ".$sqly." from  ".$restab."_wrdresnmpoints".$bb." where '".$askstr."' like concat('%',nmstr,'%')");    
      }
    }else{
      $pttab=explode(",",$airestab);
      for ($bb=0;$bb<count($pttab);$bb++){
       //$zz=UZ("insert into ".$asktab."(".$sqlx.") select ".$sqly." from  ".$restab."_wrdresnmpoints".$pttab[$bb]." where '".$askstr."' like concat('%',nmstr,'%')");    
      }
    }
  }
for ($i=0;$i<$tota;$i++){
  $itemx=$dataitem;
  $tcodex=anyvalue($arst,"typecodex",$i);
  $titlex=anyvalue($arst,"typetitlex",$i);
  $rcodex=anyvalue($arst,"rescode",$i);
  $stcode=anyvalue($arst,"STCODE",$i);
  $chatab=$restab."_chara";
  $rtitlex=anyvalue($arst,"restitle",$i);
  $totr=anyvalue($arst,"totr",$i);
  $strnum=anyvalue($arst,"strnum",$i);
  $itemx=str_replace("[tpcode]",$tcodex,$itemx);
  $itemx=str_replace("[rescode]",$rcodex,$itemx);
  $itemx=str_replace("[restitle]",$rtitlex,$itemx);
  $itemx=str_replace("[totr]",$totr,$itemx);
  $itemx=str_replace("[strnum]",$strnum,$itemx);  
  $sqlx="strnum,askstr,typecodex,rescode,restitle,nmstr,CRTM,UPTM,OLMK";
  $sqly="'$i','$askstr','".$tcodex."','".$rcodex."','".$rtitlex."','".$totr."',now(),now(),'".onlymark()."'";
  $zz=UZ("insert into ".$asktab."(".$sqlx.")values(".$sqly.")");
  $fmdata=$fmdata.$itemx;
  $crst=SZ("select keytitle,keyval from ".$chatab." where typecodex='".$tcodex."' and rescode='".$rcodex."'");
  $totc=countresult($crst);
  $fmcdx=$fmcdx."名为“".$rtitlex."”的".$titlex."，有如下特征：";
  for ($j=0;$j<$totc;$j++){
   $itemy=$charaitem;  
   $ktitle=anyvalue($crst,"keytitle",$j);
   $kval=tostring(anyvalue($crst,"keyval",$j));
   if ($kval=="0000-00-00" or $kval==""){
     $kval="未知";
   }
   $fmcdx=$fmcdx.$ktitle."：".$kval."；";
   $itemy=str_replace("[tpcode]",$tcodex,$itemy);
   $itemy=str_replace("[rescode]",$rcodex,$itemy);
   $itemy=str_replace("[restitle]",$rtitlex,$itemy);
   $itemy=str_replace("[keytitle]",$ktitle,$itemy);
   $itemy=str_replace("[keyval]",$kval,$itemy);
   $fmchara=$fmchara.$itemy;
   $ljc=$ljc+1;
  }
}
if ($tota>0){
 $stc=Array();
 $pgrst=SZ("select askstr,result from ".$bdtab." where pagess='".$pgss."'");
 $totp=countresult($pgrst);
  for ($pp=0;$pp<$totp;$pp++){
    $astr=anyvalue($pgrst,"askstr",$pp);
    $arst=anyvalue($pgrst,"result",$pp);
    $stc[$pp*2]="user:".hou($astr,":");  
    $stc[$pp*2+1]="assistant:".$arst;
  }
 if ($totp==0){
   $stc[$totp*2]="user:已知".$fmcdx."问题是：".$askstr;
 }else{
   $stc[$totp*2]="user:又知".$fmcdx."问题是：".$askstr;
 }
 $aistr=ebot($stc,$pgss,$apicode);
}else{
 $pgrst=SZ("select askstr,result from ".$bdtab." where pagess='".$pgss."'");
 $totp=countresult($pgrst);
 if ($totp==0){
  $stc=Array();
  $stc[0]="user:".$askstr;
  $aistr=ebot($stc,$pgss,$apicode);
 }else{
  $stc=Array();
  for ($pp=0;$pp<$totp;$pp++){
    $astr=anyvalue($pgrst,"askstr",$pp);
    $arst=anyvalue($pgrst,"result",$pp);
    $stc[$pp*2]="user:".hou($astr,":");
    $stc[$pp*2+1]="assistant:".$arst;
  }
  $stc[$totp*2]="user:".$askstr;
  $aistr=ebot($stc,$pgss,$apicode);
 }
}
$fmdata=killlaststr($fmdata);
$fmchara=killlaststr($fmchara);
$demo=str_replace("<resdata>",$fmdata,$demo);
$demo=str_replace("<reschara>",$fmchara,$demo);
$demo=str_replace("[totx]",$tota,$demo);
$demo=str_replace("[totc]",$ljc,$demo);
$demo=str_replace("[rtnstr]",$aistr,$demo);
echo $demo;
     session_write_close();
?>