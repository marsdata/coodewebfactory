<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tabtitle=dftval($_GET["tabtitle"],"");
$dey="我要在MYSQL创建个".$tabtitle."表，只给出一个该表英文表名,无需创建代码";
$rtntxt=file_get_contents(combineurl("http://".glw(),"/localxres/funx/getcodebyai/?askstr=".$dey));
if ($rtntxt!="NoCode."){
  $newrtntxt=str_replace(huanhang(),"",$rtntxt);  
  if (strpos($rtntxt,":")>0 ){
     $newrtntxt=hou($newrtntxt,":");
  }
  echo $newrtntxt;
}
     session_write_close();
?>