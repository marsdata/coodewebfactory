<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $conn=mysql_connect(gl(),glu(),glp());
$ulist=selecteds($conn,glb(),"select comp,depart from coode_userlist where userid='".$_COOKIE["uid"]."'","utf8","");
$totu=countresult($ulist);
$fmcom="";
$fmgrp="";
$fmdpt="";
$fmwjj="";
for ($i=0;$i<$totu;$i++){
    if (strpos("x".$fmcom,anyvalue($ulist,"comp",$i))>0){
    }else{
      $fmcom=$fmcom.anyvalue($ulist,"comp",$i).",";
      $conn=mysql_connect(gl(),glu(),glp());
      $jtid=updatings($conn,glb(),"select groupid as result from coode_sysdefault where companyid='".anyvalue($ulist,"comp",$i)."'","utf8");
      $conn=mysql_connect(gl(),glu(),glp());
      $gsmc=updatings($conn,glb(),"select keyval as result from coode_sysdefault where companyid='".anyvalue($ulist,"comp",$i)."' and  syskey='companyname'","utf8");
        if (strpos("x".$fmwjj,$gsmc."公共文件夹")>0){
        }else{
         $fmwjj=$fmwjj.$gsmc."公共文件夹".",";
        }
       if (strpos("x".$fmgrp,$jtid)>0){  
       }else{
        $fmgrp=$fmgrp.$jtid.",";
        $conn=mysql_connect(gl(),glu(),glp());
        $jtmc=updatings($conn,glb(),"select keyval as result from coode_sysdefault where companyid='".anyvalue($ulist,"comp",$i)."' and companyid=groupid and syskey='companyname'","utf8");
        if (strpos("x".$fmwjj,$jtmc."公共文件夹")>0){
        }else{
         $fmwjj=$fmwjj.$jtmc."公共文件夹".",";        
        }
       };
     }
     
     if (strpos("x".$fmdpt,anyvalue($ulist,"comp",$i).anyvalue($ulist,"depart",$i))>0){
     }else{
      $fmdpt=$fmdpt.anyvalue($ulist,"comp",$i).anyvalue($ulist,"depart",$i).",";
      $conn=mysql_connect(gl(),glu(),glp());
      $dptmc=updatings($conn,glb(),"select grouptitle as result from coode_mygroup where cid='".anyvalue($ulist,"comp",$i)."' and gid='".anyvalue($ulist,"depart",$i)."'","utf8");
        if (strpos("x".$fmwjj,$dptmc."公共文件夹")>0){
        }else{
         $fmwjj=$fmwjj.$dptmc."公共文件夹".",";        
        }
     }
}
if ($totu>0){
  $fmwjj=$fmwjj."u".$_COOKIE["uid"]."个人文件夹".",";  
  $fmjj=substr($fmwjj,0,strlen($fmwjj)-1);
}else{
  $fmjj="";
}
$utxt=str_replace('<?php','',file_get_contents($gml."ORG/vfm-admin/users/users.php"));
eval($utxt);
$totus=count($_USERS);
$fmxy=0;
$tmpdir="";
$fmtmp="";
$bcz=0;
for ($j=0;$j<$totus;$j++){
  if ($_USERS[$j]["name"]==$_COOKIE["uid"]){
    $fmxy=$fmxy+1;
    $tmpdir=$_USERS[$j]["dir"];
    if (strpos($tmpdir,",")>0){
     $pttmp=explode(",",$tmpdir);
     $totpt=count($pttmp);
      for ($p=0;$p<$totpt;$p++){
        $tmpd=str_replace('"','',$pttmp[$p]);
        $tmpd=str_replace('[','',$tmpd);
        $tmpd=str_replace(']','',$tmpd);
        if (strpos("x".$fmjj,unicodeDecode($tmpd))>0){
        }else{
         $bcz=$bcz+1;
        }
        //$fmtmp=$fmtmp.unicodeDecode($tmpd);
      }      
    }else{
        $tmpd=str_replace('"','',$tmpdir);
        $tmpd=str_replace('[','',$tmpd);
        $tmpd=str_replace(']','',$tmpd);
        if (strpos("x".$fmjj,unicodeDecode($tmpd))>0){
        }else{
         $bcz=$bcz+1;
        }
       //$fmtmp=$fmtmp.unicodeDecode($tmpd);
    }
  }
}
if ($bcz>0){
 echo  $fmxy."|".$fmjj."@".$_COOKIE["uid"];
}else{
 if ($fmxy*1==0){//不存在的时候
  echo  "0|".$fmjj."@".$_COOKIE["uid"]; 
 }else{
   echo  "1|";
 }
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>