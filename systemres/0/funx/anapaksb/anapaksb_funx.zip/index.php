<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $hd='Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Connection: keep-alive
Cookie: PHPSESSID=ncumgn2nrlon7gdf84n51erocd
Host: www.zszf.cn
Referer: http://www.zszf.cn/user/index.html
Upgrade-Insecure-Requests: 1
User-Agent: Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36';
$hdd=array("Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","Accept-Encoding: gzip, deflate","Accept-Language: zh-CN,zh;q=0.9","Connection: keep-alive","Cookie: PHPSESSID=ncumgn2nrlon7gdf84n51erocd","Host: www.zszf.cn","Referer: http://www.zszf.cn/user/index.html","Upgrade-Insecure-Requests: 1","User-Agent: Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36)");
$ux="http://www.zszf.cn/user/watermeter-detail.html?device=546054916352";
$hdx["Cookie"]="PHPSESSID=ncumgn2nrlon7gdf84n51erocd";
$hdy="Cookie:PHPSESSID=ncumgn2nrlon7gdf84n51erocd";
$pd["x"]="";
$srd='{"status":"1","msg":"success","laytime":"'.date("Y-m-d H:i:s").'","vls":[{data}]}';
$item='{"wmName":"[wmname]","wmNo":"[wmnum]","currValue":"[currvalue]","wmState":"[wmstate]","cost":"[cost]","left":"[left]","scanTime":"[scantime]"}';
$biao1=request_postx($hdd,$ux,0, $pd);
if (strpos($biao1,"水表名称")>0 and strpos($biao1,"水表号")>0 and strpos($biao1,"已扣费")>0){
 
 $sbhao=hou($biao1,"水表号");
 $sbhao=qian(hou($sbhao,"<td >"),"</td>");
 $sbmz=hou($biao1,"水表名称");
 $sbmz=str_replace("\r\n","",str_replace(" ","",qian(hou($sbmz,"colspan=\"5\">"),"【")));
 $ykf=hou($biao1,"已扣费");
 $ykf=qian(hou($ykf,"<td>"),"元");
 $yue=hou($biao1,"余额");
 $yue=qian(hou($yue,"<td>"),"元");
 $yiyong=hou($biao1,"已用水");
 $yiyong=qian(hou($yiyong,"<td>"),"吨");
 $sbzt=hou($biao1,"水表状态");
 $sbzt=str_replace(" ","",qian(hou(hou($sbzt,"class="),">"),"</span>"));
 $sbzt=str_replace("\r\n","",$sbzt);
 $lateasttime=hou($biao1,"最后抄表时间");
 $lateasttime=qian(hou(hou($lateasttime,"span class="),">"),"<");
 $fmval="";
 $itemx=$item;
 $itemx=str_replace("[wmname]",$sbmz,$itemx);
 $itemx=str_replace("[wmnum]",$sbhao,$itemx);
 $itemx=str_replace("[currvalue]",$yiyong,$itemx);
 $itemx=str_replace("[wmstate]",$sbzt,$itemx);
 $itemx=str_replace("[cost]",$ykf,$itemx);
 $itemx=str_replace("[left]",$yue,$itemx);
 $itemx=str_replace("[scantime]",$lateasttime,$itemx);
 $fmval=$fmval.$itemx;
 $srd=str_replace("{data}",$fmval,$srd);
}else{
 $srd=makereturnjson("0","访问失败，未获取到数据","");
}
echo $srd;
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>