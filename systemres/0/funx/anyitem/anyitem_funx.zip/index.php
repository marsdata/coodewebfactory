<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     eval(RESFUNSET("tabbaseinfo"));
$stid=$_GET["stid"];
$reskey=_get("reskey");
if ($reskey!=""){
  $resval=_get($reskey);
  $tabnm=UX("select tablename as result from coode_shortdata where shortid='".$stid."'");
  $snox=UX("select SNO as result from ".$tabnm." where ".$reskey."='".$resval."'");
}else{
  $snox=$_GET["SNO"];
}
$olmkx=$_GET["OLMK"];
eval(CLASSX("itemvalue"));
$iv=new itemvalue();
if ($stid !=""){
 if ($olmkx!=""){
    echo $iv->itemy($stid,$olmkx);
 }else{
    if ($snox=="0"){
     echo $iv->item0($stid,"0");    
    }else{
        if (intval($snox)>0){
          echo $iv->itemx($stid,$snox);
        }else{
            echo "{\"status\":\"0\",\"msg\":\"no sno\"}";
        }
    }
 }
}else{
 echo "{\"status\":\"0\",\"msg\":\"no stid\"}";
}
     session_write_close();
?>