<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $stidd=_get('stid');
 if (strpos($stidd,"]")>0){
  $stidd=str_replace("[","",$stidd);
  $stidd=str_replace("]","",$stidd);
 };
 if (strpos($stidd,"-")>0){
  $sid=qian($stidd,"-");
 }else{
  $sid=$stidd;
 }; 
 $pagee=$_GET['page'];
 $datatype=$_GET['datatype'];
 $refrx=_get("refresh");
 $savepath=combineurl(localroot(),"/localxres/formx/".$sid."/index.html");
 
  if (($datatype=="" and $refrx=="1") or (file_exists($savepath)==false and $refrx!="1")){
    //$frul="/localxres/funx/anyjsshort/?stid=".$sid."&page=1&pnum=30&rnd=".onlymark();
    $furl=thisurl();
    $furl=str_replace("&refresh=1","&refresh=-1",$furl);
    $furl=str_replace("?refresh=1","?refresh=-1",$furl);
    $mvurl=makeviewurl($furl);
    header("location:/localxres/tempx/loading/index.html?pagetype=formx&stid=".$sid."&vurl=".$mvurl);
  }else{
    eval(CLASSX("shortlist"));
    $shortx=new shortlist();
    echo $shortx->anylist();
  }
     session_write_close();
?>