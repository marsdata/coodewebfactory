<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    //error_reporting(0);
    //register_shutdown_function('zyfshutdownfunc'); 
    //set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $layid=$_GET["layid"];
 $accid=$_GET["accid"];
 $refresh=$_GET["refresh"];
 $furl="/localxres/csspagex/404/black/failure.html";
 $layrst=SX("select pageurl,mobileurl,pagelay,mobilelay from coode_applay where layid='".$layid."'");
 $totlay=countresult($layrst);
 if ($totlay>0){
  $pageurl=anyvalue($layrst,"pageurl",0);
  $mblurl=anyvalue($layrst,"mobileurl",0);
  $pagelay=anyvalue($layrst,"pagelay",0);
  $mobilelay=anyvalue($layrst,"mobilelay",0);
  if ($pageurl!=""){
   if (strpos($pageurl,"?")>0){
    $pageurl=$pageurl."&layid=".$layid."&accid=".$accid."&refresh=".$refresh."&rnd=".onlymark();
   }else{
    $pageurl=$pageurl."?layid=".$layid."&accid=".$accid."&refresh=".$refresh."&rnd=".onlymark();
   }
  }else{  
    $pageurl="/localxres/funx/anytiny/?tiny=".$pagelay."&layid=".$layid."&accid=".$accid."&refresh=".$refresh."&rnd=".onlymark();
  }
  if ($mblurl!=""){
    if (strpos($mblurl,"?")>0){
     $mblurl=$mblurl."&layid=".$layid."&accid=".$accid."&refresh=".$refresh."&rnd=".onlymark();
    }else{
     $mblurl=$mblurl."?layid=".$layid."&accid=".$accid."&refresh=".$refresh."&rnd=".onlymark();
    }
  }else{
    $mblurl="/localxres/funx/anytiny/?tiny=".$mobilelay."&layid=".$layid."&accid=".$accid."&refresh=".$refresh."&rnd=".onlymark();
  }
  if(check_wap()){
     header("location:".$mblurl);   
  }else{ 
     header("location:".$pageurl);
  }
}else{
 header("location:".$furl);
}
     session_write_close();
?>