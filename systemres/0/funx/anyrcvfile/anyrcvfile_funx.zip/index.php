<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     eval(RESFUNSET("tabbaseinfo"));
$tbnm=$_GET["tbnm"];
$key=$_GET["key"];
$sno=$_GET["SNO"];
$omk=_get("olmk");
$cdtk="";
$cdtv="";
$conn=mysql_connect(gl(),glu(),glp());
  $tmpnm=$_FILES["file_data"]["tmp_name"];
  $fnm=$_FILES["file_data"]["name"];
  $fext=hou($fnm,".");
  $tmptp=$_FILES["file_data"]["type"];
  $tmperr=$_FILES["file_data"]["error"];
  
$dinfo=array();
$dinfo=takedbinfo("thishostcore",$tbnm,$dinfo);
if ($tbnm!="" and $key!=""){
  if ($sno*1==0){
    $sno=$omk;
    $oomk=$omk;
  }else{
    $oomk=UX("select ".$dinfo["psolmk"]." as result from ".$tbnm." where SNO=".$sno);
  };
  $areax=garea();//判定是否远程，如果远程的调用执行写入  
   $yy=createdir(combineurl(localroot(),"/localxres/datax/".$tbnm."/files"));
   $rpt=combineurl(localroot(),"/localxres/datax/".$tbnm."/files/");  
  
  $fpn=combineurl($rpt,$tbnm."-".$key."-".$fnm);
  $hurl=combineurl("http://".glw(),str_replace(localroot(),"",$fpn));
  $vurl=combineurl("/",str_replace(localroot(),"",$fpn));
  move_uploaded_file($tmpnm, $fpn);
  $sqlx="TABLE_NAME,COLUMN_NAME,tbsno,tbolmk,CRTM,UPTM,CDTK,CDTV,picb64,OLMK,picurl,piclocal";
  $sqly="'".$tbnm."','".$key."','".$sno."','".$oomk."',now(),now(),'".$cdtk."','".$cdtv."','".$b64."','".onlymark()."','".$vurl."','".$fpn."'";
  $keytype=UX("select dxtype as result from coode_keydetailx where TABLE_NAME='".$tbnm."' and COLUMN_NAME='".$key."'");  
  $xx=UX("insert into coode_itemfile(".$sqlx.")values(".$sqly.")");
  if ($sno*1>0){              
      $filerst=SX("select picurl from coode_itemfile where TABLE_NAME='".$tbnm."' and COLUMN_NAME='".$key."' and (tbsno='".$sno."' or tbsno='".$oomk."') order by CRTM desc");
      $totf=countresult($filerst);
      if ($totf>0){
          $filexx=str_replace("#/#",";",hou($filerst,"#/#"));
      };
      
      if ($keytype=="images" or $keytype=="files"){
        $x=UX("update ".$tbnm." set ".$key."='".$filexx."' where SNO=".$sno);
      }else{
        $x=UX("update ".$tbnm." set ".$key."='".qian($filexx,";")."' where SNO=".$sno);
      }      
  }
  echo "1";
};
     session_write_close();
?>