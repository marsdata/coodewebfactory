<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
       if (substr(str_replace("\\","/",$_SERVER['DOCUMENT_ROOT']),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER['DOCUMENT_ROOT'])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER['DOCUMENT_ROOT']);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
 }
$b64=str_replace(" ","+",$_POST["src"]);
$tbnm=$_GET["tbnm"];
$key=$_GET["key"];
$sno=$_GET["SNO"];
$bb64=$_GET["b64"];//为1的时候修改KEY=b64 不是的时候 key=URL
$editor=$_GET["editor"];//editor不为空的时候为字节流传输
$omk=$_GET["olmk"];//如果omk不为空则是为 新记录的表提交
if ($omk=="" and $sno!="" and $sno!="0"){
 $omk=$sno;
}else{
 $sno="0";
}
$cdtk="";
$cdtv="";
$conn=mysql_connect(gl(),glu(),glp());
$onlymark=onlymark();
if ($editor!=""){//这个是字节流提交方式
  if ($sno!="0"){
    $oomk=UX("select OLMK as result from ".$tbnm." where SNO=".$sno);
  }else{
    $oomk=$omk;
  }
  $tmpnm=$_FILES["file"]["tmp_name"];
  $fnm=$_FILES["file"]["name"];
  $fext=hou($fnm,".");
  $tmptp=$_FILES["file"]["type"];
  $tmperr=$_FILES["file"]["error"];
  $yy=createdir($gml."ORG/BRAIN/images/tables/".$tbnm);
  $rpt=$gml."ORG/BRAIN/images/tables/".$tbnm."/";
  $fpn=$rpt.$tbnm.$key.$oomk."-".$fnm;
  $xpt="/ORG/BRAIN/images/tables/".$tbnm."/".$tbnm.$key.$oomk."-".$fnm;
  $url="/".str_replace($gml,"",$fpn);
  $url=str_replace("//","/",$url);
  $fpn=str_replace("//","/",$fpn);
  move_uploaded_file($tmpnm, $fpn);
  $bup=file_get_contents("http://".glw()."DNA/EXF/qnyupload.php?lcfile=".$fpn);
  $bd=json_decode($bup);
  if ($bd->key!=""){
    $url=$bd->key;
    unlink($fpn);
  };
  $sqlx="TABLE_NAME,COLUMN_NAME,tbsno,tbolmk,CRTM,CDTK,CDTV,picb64,OLMK,picurl,piclocal";
  $sqly="'".$tbnm."','".$key."','".$sno."','".$sno."',now(),'".$cdtk."','".$cdtv."','".$b64."','".$onlymark."','".$url."','".$fpn."'";
  $conn=mysql_connect(gl(),glu(),glp());
  $xx=updatings($conn,glb(),"insert into coode_itemfile(".$sqlx.")values(".$sqly.")","utf8");
  $isno=atv("(coode_itemfile@OLMK='".$onlymark."').SNO");
  if ($sno!="0"){      
   $conn=mysql_connect(gl(),glu(),glp());
   $filerst=selecteds($conn,glb(),"select picurl from coode_itemfile where TABLE_NAME='".$tbnm."' and COLUMN_NAME='".$key."' and (tbsno='".$sno."' or tbsno='".$oomk."')","utf8","");
   $totf=countresult($filerst);
   if ($totf>0){
      $filexx=str_replace("#/#",";",hou($filerst,"#/#"));//这个是本字段下所有包含文件
   };
   $conn=mysql_connect(gl(),glu(),glp());
   if ($keytype=="imgx"){
     $xx=updatings($conn,glb(),"update ".$tbnm." set ".$key."='".$filexx."' where SNO=".$sno,"utf8");    
   }else{
    if ($bb64=="1"){
      $xx=updatings($conn,glb(),"update ".$tbnm." set ".$key."='".$b64."' where SNO=".$sno,"utf8");//如果字段足够大，只需要装一个文件就这个弄
    }else{
      $xx=updatings($conn,glb(),"update ".$tbnm." set ".$key."='".qian($filexx,";")."' where SNO=".$sno,"utf8"); //应该用所用文件表示
    }
   }  
  }
  if ($sno!="0"){
   $bkdata="{\"code\":\"0\",\"msg\":\"okay-上传成功-isno-".$isno."\",\"data\":{\"src\":\"".$xpt."\",\"title\": \"".$fpn."\",\"allfiles\": \"".$filexx."\"}}";
  }else{
   $bkdata="{\"code\":\"0\",\"msg\":\"okay-上传成功-isno-".$isno."\",\"data\":{\"src\":\"".$xpt."\",\"title\": \"".$fpn."\",\"fileurl\": \"".$url."\"}}";
  }
  echo $bkdata;
}else{ 
  if ($sno!="0"){    
    $oomk=UX("select OLMK as result from ".$tbnm." where SNO=".$sno);    
  }else{
    $oomk=$omk;
  }
  $yy=createdir($gml."ORG/BRAIN/images/tables/".$tbnm);
  $rpt=$gml."ORG/BRAIN/images/tables/".$tbnm."/";
  $fpn=b64tofile($b64,$rpt,$tbnm.$key.$oomk);
  $url="/".str_replace($gml,"",$fpn);  
  $conn=mysql_connect(gl(),glu(),glp());
  $url=str_replace("//","/",$url);
  $fpn=str_replace("//","/",$fpn);
  $bup=file_get_contents("http://".glw()."DNA/EXF/qnyupload.php?lcfile=".$fpn);
  $bd=json_decode($bup);
  if ($bd->key!=""){
    $url=$bd->key;
    unlink($fpn);
  };
  $keytype=UX("select dxtype as result from coode_keydetailx where TABLE_NAME='".$tbnm."' and COLUMN_NAME='".$key."'");  
  $sqlx="TABLE_NAME,COLUMN_NAME,tbsno,tbolmk,CDTK,CDTV,picb64,OLMK,picurl,piclocal,CRTM,UPTM";
  $sqly="'".$tbnm."','".$key."','".$sno."','".$sno."','".$cdtk."','".$cdtv."','".$b64."','".$onlymark."','".$url."','".$fpn."',now(),now()";  
  $xx=UX("insert into coode_itemfile(".$sqlx.")values(".$sqly.")");
  $isno=atv("(coode_itemfile@OLMK='".$onlymark."').SNO");
  if ($sno!="0"){    
    $oomk=UX("select OLMK as result from ".$tbnm." where SNO=".$sno);    
    $filerst=SX("select picurl from coode_itemfile where TABLE_NAME='".$tbnm."' and COLUMN_NAME='".$key."' and (tbsno='".$sno."' or tbsno='".$oomk."') order by CRTM desc");
    $totf=countresult($filerst);
    if ($totf>0){
      $filexx=str_replace("#/#",";",hou($filerst,"#/#"));//这个是本字段下所有包含文件
    };
    
    if ($keytype=="imgx"){
      $xx=UX("update ".$tbnm." set ".$key."='".$filexx."' where SNO=".$sno);
    }else{
     if ($bb64=="1"){
       $xx=UX("update ".$tbnm." set ".$key."='".$b64."' where SNO=".$sno);//如果字段足够大，只需要装一个文件就这个弄
     }else{
       $xx=UX("update ".$tbnm." set ".$key."='".qian($filexx,";")."' where SNO=".$sno); //应该用所用文件表示
     }
    }  
    $bkdata="{\"code\":\"0\",\"msg\":\"okay-上传成功-isno-".$isno."\",\"data\":{\"url\":\"".$url."\",\"title\": \"".$fpn."\",\"allfiles\": \"".$filexx."\"}}";
    echo $bkdata;
   }else{
    $bkdata="{\"code\":\"0\",\"msg\":\"okay-上传成功-isno-".$isno."\",\"data\":{\"url\":\"".$url."\",\"title\": \"".$fpn."\",\"fileurl\": \"".$url."\"}}";
    echo $bkdata;
   }
};
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>