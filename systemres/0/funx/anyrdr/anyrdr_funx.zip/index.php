<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $cdtval=dftval($_GET["cdtval"],"");
$qry=dftval($_GET["qrykey"],"");
$cdtmark=dftval($_GET["cdtmark"],"");
//经常遇到不同的值的数据需要进行跳转，如果满足直接跳，不满足调到别的上；省着重新写RDR
$rdrst=SX("select rdrpath,rdrcode from coode_cdtrdr where cdtmark='".$cdtmark."' and cdtval='".$cdtval."'");
$longexp=anyvalue($rdrst,"rdrpath",0);
$rdrcode=anyvalue($rdrst,"rdrcode",0);
if ($rdrcode!=""){
  eval(tostring($rdrcode));
}else{
 if ($longexp!=""){
  if ($qry!=""){
    if (strpos($qry,",")>0){
      $ptq=explode(",",$qry);
      $totp=count($ptq);
      for ($m=0;$m<$totp;$m++){
       $longexp=str_replace("[get-".$ptq[$m]."]",dftval($_GET[$ptq[$m]],""),$longexp);
      }
    }else{
      $longexp=str_replace("[get-".$qry."]",dftval($_GET[$qry],""),$longexp);
    }
    header("location:".$longexp);
  }else{
    header("location:".$longexp);
  }
 }else{
  header("location:/localxres/csspagex/404/black/failure.html");
 }
}
     session_write_close();
?>