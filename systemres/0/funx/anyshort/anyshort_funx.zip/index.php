<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $stidd=qian(_get('stid'),"-");
  $dbmark=_get('dbmark');
 if (strpos($stidd,"]")>0){
  $stidd=str_replace("[","",$stidd);
  $stidd=str_replace("]","",$stidd);
 };
 $pagee=_get('page');
 if (intval($pgn)>0){
   $pagenumm=$pgn;
 }else{
   $pagenumm=_get('pnum');
 }
 if (_get("pnu")=="0"){
  $pagenumm=""; 
  $pagee="";
 }
if ($dbmark==""){
 $tabnm=UX("select tablename as result from coode_shortdata where shortid='".$stidd."'"); 
}else{
 $tabnm=UX("select tablename as result from coode_dbshort where shortid='".$stidd."' and catalog='".$dbmark."'");
} 
   $bkr=anyfunrun("runbfview","","dbmark=".$dbmark."&tabnm=".$tabnm,"");   
   //$nx=addprcx("dbmark=".$dbmark."&tabnm=".$tabnm.huanhang());
    //$nx=addprcx($bkr);
   $exkey=_get('exkey');
   $tbdt=anyshort($stidd,$pagee,$pagenumm);
   if ($exkey!=""){
     if (strpos($exkey,"@")>0){
       $ptkey=explode("@",$exkey);
       for ($j=0;$j<count($ptkey);$j++){
        $kq=qian($ptkey[$j],":");
        $kh=hou($ptkey[$j],":");
        $tbdt=str_replace("\"".$kq."\"","\"".$kh."\"",$tbdt);
       }
     }else{
       $kq=qian($exkey,":");
       $kh=hou($exkey,":");
       $tbdt=str_replace("\"".$kq."\"","\"".$kh."\"",$tbdt);
     }
   }
   echo $tbdt;
     session_write_close();
?>