<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $stid=$_GET['stid'];
 $cfid=$_GET['cfid'];
 $sno=$_GET['SNO'];
 $olmk=$_GET['OLMK'];
$appid=$_GET['appid'];
$pbj0='<script type="text/javascript" src="../../DNA/EXF/sysbase/sysjs.js"></script>
';
$h='<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <title>[title]</title>
         [cssfile]
         [jsfile]
         [stylex]
</head>
 [bodyx]
 [scriptx]
</html>
';
$bdx=' [evalhtml] ';
$pgid="shortnew";
$fmdiv="";
$fmdov="";
$show="1";
$conn=mysql_connect(gl(),glu(),glp());
$x=updatings($conn,glb(),"update coode_compage set htitle=hmark where htitle is null or htitle=''","utf8");
$conn=mysql_connect(gl(),glu(),glp());
$mnrst=selecteds($conn,glb(),"select SNO,pageid,pagemark,pagecls,CRTOR,jsfiles,cssfiles,scriptx,stylex,oldhtml,pagefrm,pagehtml,pagedata,srdhtml,topmark,bottommark,leftmark,contentmark,issys,isdata,allfiles,alltables,alljsfuns,extscripts,extstyles,outhtml,UPTM,CRTM,outpath from coode_compage where pageid='".$pgid."'","utf8","");//比较公私分离是否成功,展示比较用hcss2
$totrst=countresult($mnrst);
 $mnusno=anyvalue($mnrst,"SNO",0);
 $mnuid=anyvalue($mnrst,"pageid",0);
 $mnumark=anyvalue($mnrst,"pagemark",0);
 $mnucls=anyvalue($mnrst,"pagecls",0);
 $mnuutime=anyvalue($mnrst,"UPTM",0);
 $mnuctime=anyvalue($mnrst,"CRTM",0);
 $mnutestcrt=anyvalue($mnrst,"CRTOR",0);
 $mnujsfile=tostring(anyvalue($mnrst,"jsfiles",0));
 $mnucssfile=tostring(anyvalue($mnrst,"cssfiles",0));
 $mnuscpttxt=tostring(anyvalue($mnrst,"scriptx",0));
 $mnustltxt=tostring(anyvalue($mnrst,"stylex",0));
 $mnuoldh=tostring(anyvalue($mnrst,"oldhtml",0));
 $mnupagefrm=tostring(anyvalue($mnrst,"pagefrm",0));
 $mnupagehtml=tostring(anyvalue($mnrst,"pagehtml",0));
 $mnupagedata=tostring(anyvalue($mnrst,"pagedata",0));
 $mnusrdfrm=tostring(anyvalue($mnrst,"srdhtml",0));
 
  if (strpos("x".$mnusrdfrm,"[dovx]")<=0){ 
    if (strpos("x".$mnusrdfrm,"</body>")<=0){
      $mnusrdfrm= "<body>".$mnusrdfrm."[dovx]"."</body>";////如果 字段值不存在DOVx 结构如下 生成个DOVX如果存在 则有BODY 放有BODYZHONG 无的则安排个地方
//      echo "<!--".$mnusrdfrm."-->";
    }else{
     $mnusrdfrm= str_replace("</body>","[dovx]</body>",$mnusrdfrm);
     //echo "<!--".$mnusrdfrm."-->";
    };
  };
 $mnutopfrm=tostring(anyvalue($mnrst,"topmark",0));
 $mnubottomfrm=tostring(anyvalue($mnrst,"bottommark",0));
 $mnuleftfrm=tostring(anyvalue($mnrst,"leftmark",0));
 
 $mnucontentfrm=tostring(anyvalue($mnrst,"contentmark",0));
 
 $mnuisdata=tostring(anyvalue($mnrst,"isdata",0));
 $mnuallfiles=tostring(anyvalue($mnrst,"allfiles",0)); //同理
 $mnualltables=tostring(anyvalue($mnrst,"alltables",0));//这个是确定哪些文件改变  可以造成这个文件更新时刻,原来是这个用途的
 $mnujsfuns=tostring(anyvalue($mnrst,"alljsfuns",0));  //额外扩展
 $mnujsext=tostring(anyvalue($mnrst,"extscripts",0)); //额外扩展
 $mnucssext=tostring(anyvalue($mnrst,"extstyles",0));//
 $mnuouthtml=tostring(anyvalue($mnrst,"outhtml",0)); //总输出 加扩展后输出
 $mnuoutpath=tostring(anyvalue($mnrst,"outpath",0)); //总输出 加扩展后输出
$conn=mysql_connect(gl(),glu(),glp());
$toprst=selecteds($conn,glb(),"select SNO,unittitle,demohtml,demofrm,demodata,demoeval,defaultdata,jsfiles,cssfiles,scriptx,stylex,CRTM,UPTM from coode_comunit where unitmark='".$mnutopfrm."'","utf8","");//比较公私分离是否成功,展示比较用hcss2
$totrst=countresult($toprst);
if ($totrst>0){
 $topsno=anyvalue($toprst,"SNO",0);
 $topeval=tostring(anyvalue($toprst,"demoeval",0));
 $topjsf=tostring(anyvalue($toprst,"jsfiles",0));
 $topcssf=tostring(anyvalue($toprst,"cssfiles",0));
 $topscpt=tostring(anyvalue($toprst,"scriptx",0));
 $topstl=tostring(anyvalue($toprst,"stylex",0));
 $tophtml=tostring(anyvalue($toprst,"demohtml",0));
 $topfrm=tostring(anyvalue($toprst,"demofrm",0));
 $topdata=tostring(anyvalue($toprst,"demodata",0));
 $topeval=tostring(anyvalue($toprst,"demoeval",0));
};
$conn=mysql_connect(gl(),glu(),glp());
$btmrst=selecteds($conn,glb(),"select SNO,unittitle,demohtml,demofrm,demodata,demoeval,defaultdata,jsfiles,cssfiles,scriptx,stylex,CRTM,UPTM from coode_comunit where unitmark='".$mnubottomfrm."'","utf8","");//比较公私分离是否成功,展示比较用hcss2
$totrst=countresult($btmrst);
if ($totrst>0){
 $btmsno=anyvalue($btmrst,"SNO",0);
 $btmeval=tostring(anyvalue($btmrst,"demoeval",0));
 $btmjsf=tostring(anyvalue($btmrst,"jsfiles",0));
 $btmcssf=tostring(anyvalue($btmrst,"cssfiles",0));
 $btmscpt=tostring(anyvalue($btmrst,"scriptx",0));
 $btmstl=tostring(anyvalue($btmrst,"stylex",0));
 $btmhtml=tostring(anyvalue($btmrst,"demohtml",0));
 $btmfrm=tostring(anyvalue($btmrst,"demofrm",0));
 $btmdata=tostring(anyvalue($btmrst,"demodata",0));
 $btmeval=tostring(anyvalue($btmrst,"demoeval",0));
};
$conn=mysql_connect(gl(),glu(),glp());
$leftrst=selecteds($conn,glb(),"select SNO,unittitle,demohtml,demofrm,demodata,demoeval,defaultdata,jsfiles,cssfiles,scriptx,stylex,CRTM,UPTM from coode_comunit where unitmark='".$mnuleftfrm."'","utf8","");//比较公私分离是否成功,展示比较用hcss2
$totrst=countresult($leftrst);
//echo "leftrst--".$leftrst;
if ($totrst>0){
 $leftsno=anyvalue($leftrst,"SNO",0);
 $lefteval=tostring(anyvalue($leftrst,"demoeval",0));
 $leftjsf=tostring(anyvalue($leftrst,"jsfiles",0));
 $leftcssf=tostring(anyvalue($leftrst,"cssfiles",0));
 $leftscpt=tostring(anyvalue($leftrst,"scriptx",0));
 $leftstl=tostring(anyvalue($leftrst,"stylex",0));
 $lefthtml=tostring(anyvalue($leftrst,"demohtml",0));
 $leftfrm=tostring(anyvalue($leftrst,"demofrm",0));
 $leftdata=tostring(anyvalue($leftrst,"demodata",0));
 $lefteval=tostring(anyvalue($leftrst,"demoeval",0));
};
$conn=mysql_connect(gl(),glu(),glp());
$cttrst=selecteds($conn,glb(),"select SNO,unittitle,demohtml,demofrm,demodata,demoeval,defaultdata,jsfiles,cssfiles,scriptx,stylex,CRTM,UPTM from coode_comunit where unitmark='".$mnucontentfrm."'","utf8","");//比较公私分离是否成功,展示比较用hcss2
$totrst=countresult($cttrst);
if ($totrst>0){
 $cttsno=anyvalue($leftrst,"SNO",0);
 $ctteval=tostring(anyvalue($cttrst,"demoeval",0));
 $cttjsf=tostring(anyvalue($cttrst,"jsfiles",0));
 $cttcssf=tostring(anyvalue($cttrst,"cssfiles",0));
 $cttscpt=tostring(anyvalue($cttrst,"scriptx",0));
 $cttstl=tostring(anyvalue($cttrst,"stylex",0));
 $ctthtml=tostring(anyvalue($cttrst,"demohtml",0));
 $cttfrm=tostring(anyvalue($cttrst,"demofrm",0));
 $cttdata=tostring(anyvalue($cttrst,"demodata",0));
 $ctteval=tostring(anyvalue($cttrst,"demoeval",0));
};
$conn=mysql_connect(gl(),glu(),glp());
$strst=selecteds($conn,glb(),"select SNO,TABLE_NAME,COLUMN_NAME,keytitle,clstxt,sysshowfun,changeable,displayed,dxtype,SQX from coode_keydetaily where shortid='".$stid."' order by SQX","utf8","");//比较公私分离是否成功,展示比较用hcss2
//echo $strst;
$totstrst=countresult($strst);
//echo $strst."--------------------";
//echo $datahtml."@#dsf444444444444444444444444";
if ($totrst>0){
 $contsno=anyvalue($contrst,"SNO",0);
 //$conteval=tostring(anyvalue($contrst,"demoeval",0));
 $contjsf=tostring(anyvalue($contrst,"jsfiles",0));
 $contcssf=tostring(anyvalue($contrst,"cssfiles",0));
 $contscpt=tostring(anyvalue($contrst,"scriptx",0));
 $contstl=tostring(anyvalue($contrst,"stylex",0));
 //$conthtml=tostring(anyvalue($contrst,"demohtml",0));
 //$contfrm=tostring(anyvalue($contrst,"demofrm",0));
 //$contdata=tostring(anyvalue($contrst,"demodata",0));
 //$conteval=tostring(anyvalue($contrst,"demoeval",0));
};
  $mnujsfile=$topjsf.";".$btmjsf.";".$leftjsf.";".$contjsf.";".$cttjsf.";";
  $mnucssfile=$topcssf.";".$btmcssf.";".$leftcssf.";".$contcssf.";".$cttcssf.";";
  $mnuscpttxt=$topscpt."\r\n".$btmscpt."\r\n".$leftscpt."\r\n".$cttscpt."\r\n".$fmscriptx."\r\n";
  $mnustltxt=formstyle($topstl."\r\n".$btmstl."\r\n".$leftstl."\r\n".$contstl."\r\n".$cttstl."\r\n");
  $datahtml=anyunion($_GET["ustr"]);//"odlistxs5@SNO=431/newdftstyleXoA,KZkYiExIC@SNO=2/newdftstyleXoA"
  $bodyx=$mnusrdfrm;
  $bodyx=str_replace("[topx]",$tophtml,$bodyx);
  $bodyx=str_replace("[bottomx]",$btmhtml,$bodyx);
  $bodyx=str_replace("[leftx]",$lefthtml,$bodyx);
  $bodyx=str_replace("[contentx]", $datahtml,$bodyx);
  $fmhtml=$h;
  $fmhtml=str_replace("[title]",glt(),$fmhtml);
   $fmhtml=str_replace("[jsfile]",$pbj0.formjs($mnujsfile),$fmhtml);
   $fmhtml=str_replace("[cssfile]",formcss($mnucssfile),$fmhtml);
   $fmhtml=str_replace("[stylex]",$mnustltxt.$mnucssext,$fmhtml);
   $fmhtml=str_replace("[scriptx]",$mnuscpttxt.$mnujsext,$fmhtml);
  $bodyx=str_replace("[anyx]","",$bodyx);//$fmdov
  $bodyx=str_replace("[dovx]","",$bodyx);//$fmdov
  $fmhtml=str_replace("[bodyx]",$bodyx.$btmx,$fmhtml);
echo $fmhtml;
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>