<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $sid=$_GET["stid"];
 $rfrsx=$_GET["refresh"];
 $datatype=_get("datatype");
 $savepath=combineurl(localroot(),"/localxres/formx/".$sid."/detail.html");
 if (($datatype=="" and $rfrsx=="-1") or (file_exists($savepath)==false and $rfrsx!="1")){
    $furl=thisurl();
    $furl=str_replace("&refresh=-1","",$furl);
    $furl=str_replace("?refresh=-1","",$furl);
    $mvurl=makeviewurl($furl);
    header("location:/localxres/tempx/loading/index.html?pagetype=detailx&stid=".$sid."&vurl=".$mvurl);
    //echo "location:/localxres/tempx/loading/index.html?pagetype=detailx&stid=".$sid."&vurl=".$mvurl;
    //echo "gostload";
 }else{
  eval(CLASSX("shortnew"));
  $stnew=new shortnew();
  //echo "gostnew";
  echo $stnew->anydetail($sid,$rfrsx);
 }
     session_write_close();
?>