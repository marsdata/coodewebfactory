<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $w=$_GET["w"];
$h=$_GET["h"];
$size=$w."x".$h;
if (intval($w)>0 and intval($h)>0){
 $image = imagecreatetruecolor($w, $h);
$aspace=intval(intval($w)*intval($h)/100000);
if ($aspace>=10){
 $bgcolor = imagecolorallocate($image, rand(102,204), rand(194,229), 255);
}else{
  switch($aspace){
    case "9":
    $bgcolor = imagecolorallocate($image, rand(132,205), 255, rand(132,153));
    break;
    case "8":
    $bgcolor = imagecolorallocate($image, 255, rand(153,187), rand(102,153));
    break;
    case "7":
    $bgcolor = imagecolorallocate($image, rand(77,102), rand(181,194), 255);
    break;
    case "6":
    $bgcolor = imagecolorallocate($image, rand(0,132), rand(204,225), rand(102,132));
    break;
    case "5":
    $bgcolor = imagecolorallocate($image, 255, rand(113,153), 102);
    break;
    case "4":
    $bgcolor = imagecolorallocate($image, rand(0,77), rand(81,181), 255);
    break;
    case "3":
    $bgcolor = imagecolorallocate($image, 0, rand(104,204), 102);
    break;
    case "2":
    $bgcolor = imagecolorallocate($image, 255, rand(50,113), 77);
    break;
    case "1":
    $bgcolor = imagecolorallocate($image, 255, rand(79,179), 255);
    break;    
    default:
    $bgcolor = imagecolorallocate($image, 255, rand(100,179), rand(150,204));
  }
}
 imagefill($image, 0, 0, $bgcolor);
   $fonttype="";
  if (intval($h)<=60){   
    if (intval($w)<=60){
      $fonttype="xiaofang";    
    }else{    
      $fonttype="hengchangai";
    }
  }else{
    if (intval($w)<=60){
      $fonttype="shuchangshou";
    }else{
      if (intval($h)>(intval($w)*1.5)){
        $fonttype="shuchangshou";
      }else{
        $fonttype="dafang";
      }
    }
  }
 for ($i = 0; $i < strlen($size); $i++) {    
    $fontcolor = imagecolorallocate($image, 0 , 0 , 0);    
    $fontcontent =substr($size,$i,1);        
    switch($fonttype){
      case "xiaofang":
      $fontsize = 6*($w/60);
       $x = ($i * $w / strlen($size)) + 6;
       $y = ($h/2)-1.5;
      break;
      case "hengchangai":
         $fontsize = (6*($w/60)+6*($h/60))/2;
       $x = ($i * intval($w) / strlen($size)) + $fontsize+2;
       $y = ($h/2)-1.5;
      break;
      case "shuchangshou":
       $fontsize = (6*($w/60)+6*($h/60))/2;
       $x = ($w/2)-3;
       $y = ($i * intval($h) / strlen($size)) +$fontsize+2;
       
      break;
      case "dafang":
       $fontsize = (6*($w/60)+6*($h/60))/2;       
       $x = ($i * intval($w) / strlen($size)) + $fontsize+2;
       $y =  (intval($h) /2)- 3*(intval($w)/100);
      break;
      default:
       $fontsize = 6;       
       $x = ($i * intval($w) / strlen($size)) + $fontsize+2;
       $y =  (intval($h) /2)- 3*(intval($w)/100);
    }
    imagestring($image, $fontsize, $x, $y, $fontcontent, $fontcolor);
 }
 header('content-type:image/png');
 imagepng($image);
 imagedestroy($image);
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>