<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tablenm=$_GET["tablenm"];
$sno=$_GET["sno"];
$keyx=$_GET["keyx"];
$prisno=UX("select mainsqx as result from coode_tablist where TABLE_NAME='".$tablenm."'");
switch ($tablenm){
case "coode_shortdata":
 
break;
case "coode_keydetailx":
 
break;
case "coode_keydetaily":
 
break;
default:
  $conn=mysql_connect(gl(),glu(),glp());
  $ox=intval(updatings($conn,glb(),"select  ".$keyx." as result from ".$tablenm."  where ".$prisno."=".$sno,"utf8"))*1;
  switch ($ox){
    case 0;
    $newox=50;
    break;
    case 50;
    $newox=100;
    break;
    case 100;
    $newox=0;
    break;
    default:
    $newox=0;
  }
  $conn=mysql_connect(gl(),glu(),glp());
  $xy=updatings($conn,glb(),"UPDATE ".$tablenm." SET ".$keyx."='".$newox."' WHERE ".$prisno."=".$sno,"utf8");  
}
$conn=mysql_connect(gl(),glu(),glp());
$nex=intval(updatings($conn,glb(),"select  ".$keyx." as result from ".$tablenm."  where ".$prisno."=".$sno,"utf8"))*1;
$conn=mysql_connect(gl(),glu(),glp());
$ksfun=updatings($conn,glb(),"select sysshowfun as result from coode_keydetailx where TABLE_NAME='".$tablenm."' and COLUMN_NAME='".$keyx."' and TABLE_SCHEMA='".glb()."'","utf8");
$kstxt=tostring($ksfun);
$c0p5=qian(hou("-".$kstxt,"CASE=50::"),"E@CS");
$c0p5=str_replace("[thistable]",$tablenm,$c0p5);
$c0p5=str_replace("[thiskey]",$keyx,$c0p5);
$c0p5=str_replace("[thissno]",$sno,$c0p5);
$c0p5=str_replace("{","<",$c0p5);
$c0p5=str_replace("}",">",$c0p5);
$c0=qian(hou("-".$kstxt,"CASE=0::"),"E@CS");
$c0=str_replace("[thistable]",$tablenm,$c0);
$c0=str_replace("[thiskey]",$keyx,$c0);
$c0=str_replace("[thissno]",$sno,$c0);
$c0=str_replace("{","<",$c0);
$c0=str_replace("}",">",$c0);
$c1=qian(hou("-".$kstxt,"CASE=100::"),"E@CS");
$c1=str_replace("[thistable]",$tablenm,$c1);
$c1=str_replace("[thiskey]",$keyx,$c1);
$c1=str_replace("[thissno]",$sno,$c1);
$c1=str_replace("{","<",$c1);
$c1=str_replace("}",">",$c1);
switch ($nex){
    case 0;
    echo $c0;
    break;
    case 50;
    echo $c0p5;
    break;
    case 100;
    echo $c1;
    break;
    default:
    echo $c0;
  }
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>