<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sysid=$_GET["sysid"];
$furl="/localxres/csspagex/404/black/failure.html";
if (strpos($sysid,".")>0){
  $sid=qian($sysid,".");
  $mtd=hou($sysid,".");
  switch($mtd){
  //登录
   case "0":
    $layappx=UX("select loginurl as result from coode_sysinformation where sysid='".$sid."'");
    if ($layappx==""){
      header("location:".$furl);
    }else{
      header("location:/localxres/funx/anylay/?layid=".$layappx);  
    }
   break;
  //管理登录后
   case "1":
    $layappx=UX("select inurl as result from coode_sysinformation where sysid='".$sid."'");
    if ($layappx==""){
      header("location:".$furl);
    }else{
      header("location:/localxres/funx/anylay/?layid=".$layappx);  
    }
   break;
   //会员登录后
   case "2":
    $layappx=UX("select custinurl as result from coode_sysinformation where sysid='".$sid."'");
    if ($layappx==""){
      header("location:".$furl);
    }else{
      header("location:/localxres/funx/anylay/?layid=".$layappx);  
    }
   break;
   case "3":   
   header("location:/localxres/pagex/1/sysorg/nEgVaEBy/jmFOFN/index.html");
   break;
   
   default:
    $layappx=UX("select indexurl as result from coode_sysinformation where sysid='".$sid."'");
    $layid=UX("select inurl as result from coode_appdefault where appid='".$mtd."' and sysid='".$sid."'");
    if ($layid!=""){
     header("location:/localxres/funx/anylay/?layid=".$layid);  
    }else{
      if ($layappx==""){
        header("location:".$furl);
      }else{
        header("location:/localxres/funx/anylay/?layid=".$layapp);  
      }
    }  
  }//swc
}else{
 $layappx=UX("select indexurl as result from coode_sysinformation where sysid='".$sysid."'"); 
    if ($layappx==""){
      header("location:".$furl);
    }else{
      header("location:/localxres/funx/anylay/?layid=".$layappx);  
    }
}
     session_write_close();
?>