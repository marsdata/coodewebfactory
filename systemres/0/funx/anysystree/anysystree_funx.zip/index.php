<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $ddd=$_GET["ddd"];
$fff=$_GET["fff"];
if (substr(str_replace("\\","/",$_SERVER['DOCUMENT_ROOT']),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER['DOCUMENT_ROOT'])."/";
}else{
    $gml=str_replace("\\","/",$_SERVER['DOCUMENT_ROOT']);
};
if ($ddd!=""){
   if (substr($ddd,0,1)=="/"){
    $ddd=hou($ddd,"/");
   }
   if (substr($ddd,-1)!="/"){
    $ddd=$ddd."/";
   }
   $dir = $gml.$ddd;  //要获取的目录
   $ppp="/".$ddd;
}else{
   $dir = $gml;  //要获取的目录
   $ppp="/";
}
$ljwj=0;
$ljsz=0;
$cgsz=10*1024*1024;
//先判断指定的路径是不是一个文件夹
$k=2;
$sxx=SX("select updateurl from coode_sitefile where folder='".$ppp."' and (filetype='folder' or filetype='file')");
$tots=countresult($sxx);
$fmxxx="";
for ($z=0;$z<$tots;$z++){
  $fmxxx=$fmxxx." updateurl='".anyvalue($sxx,"updateurl",$z)."' or ";
}
if ($tots>0){
  $fmxxx=substr($fmxxx,0,strlen($fmxxx)-3);
}
if (is_dir($dir)){
   if ($dh = opendir($dir)){
           while (($file[$k] = readdir($dh) )!= false){
            if ( $file[$k]!="."  and $file[$k]!=".."){
              $filePath[$k] = $dir.$file[$k];
              $fsize[$k]=0;
              $fsize[$k]=0;
              if (is_file($filePath[$k])){
               $filetype[$k]="file";
               $ptex=explode(".",$filePath[$k]);
               $totpx=count($ptex);
               $fext[$k]=$ptex[$totpx-1];
              }else{
               $filetype[$k]="folder";
               $fext[$k]="";
              }
              $fctime[$k]=date("Y-m-d H:i:s");
              $futime[$k]=date("Y-m-d H:i:s");
              $fhash[$k]="";            
              $fhash[$k]="";
              $filenm[$k] = $file[$k];
              $bz[$k]="[1]".$k;
              $pid[$k]='1';    
          $k=$k+1;
          };//iffilek          
         };//whilefilek
    closedir($dh);
    };//iffdh
};//if isdir
$totf=$k-1;
for ($j=0;$j<$totf+2;$j++){ 
 if (strpos($sxx,str_replace($gml,"/",$filePath[$j]))>0){  
 }else{     
   $extx=UX("select count(*) as result from coode_sitefile where updateurl='".str_replace($gml,"/",$dir)."'"); 
   if (intval($extx)>0){
     if (str_replace($gml,"/",$filePath[$j])!=""){
      $x=UX("update coode_sitefile set UPTM=now(),folder='".$ppp."',exname='".$fext[$j]."',filetype='".$filetype[$j]."' where updateurl='".str_replace($gml,"/",$filePath[$j])."'");
     }
   }else{     
     $fmtb="('".$file[$j]."','".$filetype[$j]."','".$fext[$j]."','".$file[$j]."','','".$ppp."','".str_replace($gml,"/",$filePath[$j])."','".$fctime[$j]."','".$futime[$j]."','".$nmd5."','".$fsize[$j]."','".$flnr."','".onlymark()."','".$j."','".$pid[$j]."')";
     if (str_replace($gml,"/",$filePath[$j])!=""){
       $x=UX("insert into coode_sitefile(filename,filetype,exname,filecname,fileexplain,folder,updateurl,CRTM,UPTM,UPMD5,filesize,filetext,OLMK,myid,parid)values".$fmtb);
     }
   }
 }
}
  $t=UX("update coode_sitefile set UPTM=now() where ".$fmxxx);
  $p=UX("update coode_sitefile set exname='jpg' where updateurl like '%.jpg' or updateurl like '%.JPG'");
  $p=UX("update coode_sitefile set exname='png' where updateurl like '%.png' or updateurl like '%.PNG'");
  $p=UX("update coode_sitefile set exname='gif' where updateurl like '%.gif' or updateurl like '%.GIF'");
  $p=UX("update coode_sitefile set exname='svg' where updateurl like '%.svg' or updateurl like '%.SVG'");
  $p=UX("update coode_sitefile set exname='js' where updateurl like '%.js' or updateurl like '%.JS'");
  $p=UX("update coode_sitefile set exname='css' where updateurl like '%.css' or updateurl like '%.CSS'");
  $p=UX("update coode_sitefile set exname='html' where updateurl like '%.html' or updateurl like '%.HTML'");
  $p=UX("update coode_sitefile set exname='htm' where updateurl like '%.htm' or updateurl like '%.HTM'");
  $z=UX("delete from coode_sitefile where timestampdiff(second,UPTM,now())>60 and folder='".$ppp."'");
  $g=UX("update coode_sitefile set PTOF=filename where updateurl=concat('/FACE/',filename) and filetype='folder'");
echo "1";
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>