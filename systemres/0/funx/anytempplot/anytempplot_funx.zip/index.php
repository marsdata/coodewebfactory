<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     //结构长度，和结构名称不确定只能采用拼接方法
$tmpid=dftval($_GET["tempid"],"");
$plotrst=SX("select plotmark,markname from coode_plotlist where plotcls='".$tmpid."'");
$totplot=countresult($plotrst);
$plotitem='{"myid":"[myid]","parid":"[parid]","mymark":"[mymark]","mytitle":"[mytitle]","myurl":"[myurl]","myclick":"[myclick]","mydescrib":"[mydescrib]"},';
$srddemo='{';
for ($i=0;$i<$totplot;$i++){
  $pmark=anyvalue($plotrst,"plotmark",$i);
  $pname=anyvalue($plotrst,"markname",$i);
  $srddemo=$srddemo.'"'.$pmark.'":[';
  $listrst=SX("select myid,parid,mymark,mytitle,myurl,layid,myclick,mydescrib from coode_plotdetail where plotmark='".$pmark."'");
  $totl=countresult($listrst);
  for ($j=0;$j<$totl;$j++){
    $item=$plotitem;
    $myid=anyvalue($listrst,"myid",$j);
    $parid=anyvalue($listrst,"parid",$j);
    $layid=anyvalue($listrst,"layid",$j);
    $mymark=anyvalue($listrst,"mymark",$j);
    $mytitle=anyvalue($listrst,"mytitle",$j);
    $myurl=anyvalue($listrst,"myurl",$j);
    $myclick=anyvalue($listrst,"myclick",$j);
    $mydescrib=anyvalue($listrst,"mydescrib",$j);
    
    $item=str_replace("[myid]",$myid,$item);
    $item=str_replace("[parid]",$parid,$item);
    $item=str_replace("[mymark]",$mymark,$item);
    $item=str_replace("[mytitle]",$mytitle,$item);
    $item=str_replace("[myurl]","/localxres/funx/anylay/?layid=".$layid,$item);
    $item=str_replace("[myclick]",$myclick,$item);
    $item=str_replace("[mydescrib]",$mydescrib,$item);
    $srddemo=$srddemo.$item;
  }
  $srddemo=$srddemo.'],';
}
$srddemo=$srddemo.'}';
echo $srddemo;
     session_write_close();?>