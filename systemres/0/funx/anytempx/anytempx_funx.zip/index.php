<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $dumark=_get("dumark");
$valstr=_get("valstr");
$plancode=_get("plancode");
$refresh=_get("refresh");
$tabnm=_get("tabnm");
$domain=qian($dumark,".");
$mark=hou($dumark,".");
$trst=SX("select pagesurround,casecode,cssfiley,jsfiley,styley,scripty,templatecode from coode_domainunit where dumark='".$dumark."'");
   $srdcode=tostring(anyvalue($trst,"pagesurround",0)); 
   $pagehtml=turnlab($srdcode);
   $cfiley=tostring(anyvalue($trst,"cssfiley",0)); 
   $jfiley=tostring(anyvalue($trst,"jsfiley",0)); 
   $styley=tostring(anyvalue($trst,"styley",0)); 
   $scripty=tostring(anyvalue($trst,"scripty",0)); 
   $alljsfiles=$jfiley;
   $allcssfiles=$cfiley;
   $allstylex=$styley;
   $allscriptx=$scripty;
   $casedemo=tostring(anyvalue($trst,"casecode",0)); 
   $bodycode=tostring(anyvalue($trst,"templatecode",0));
   if ($casedemo!=""){
     eval($casedemo);
   }
   $pagehtml=str_replace("<!--thesecomCSSFILES-->",formcss(onlyone($allcssfiles)),$pagehtml);   
   $pagehtml=str_replace("<!--thesecomJSFILES-->",formjs(onlyone($alljsfiles)),$pagehtml);   
   $pagehtml=str_replace("<!--thiscomSTYLE-->",$allstylex,$pagehtml);   
   $pagehtml=str_replace("<!--thiscomSCRIPT-->",$allscriptx,$pagehtml);   
   $pagehtml=str_replace("<!--thiscomHTML-->",turnlab($tmpcode),$pagehtml);   
   $pagehtml=str_replace("<!--thistitle-->",$utitle,$pagehtml);     
   if ($domain!="" and $mark!=""){
       $outurly="/localxres/tempx/".$domain."/html/".$valstr.".html";
       $outx=combineurl(localroot(),$outurly);
       //$pagehtml=str_replace("/localxres/csspagex/","",$pagehtml);
       overfile($outx,$pagehtml);
       switch($refresh){
         case "1":
          echo $pagehtml;
         break;
         case "2":
          $extx=UX("select count(*) as result from coode_datapages where plancode='$plancode' and keyval='$valstr'");
           $trst=SX("select tabkey,cdt from coode_datatopage where plancode='".$plancode."'");
           //只是计划模板
           $tabk=anyvalue($trst,"tabkey",0);
           $cdt=tostring(anyvalue($trst,"cdt",0));
           if ($cdt==""){
             $zzz=UX("update ".$tabnm." set STATUS=1 where ".$tabk."='$valstr'");
           }else{
             $zzz=UX("update ".$tabnm." set STATUS=1 where ".$tabk."='$valstr' and (".$cdt.")");
           }
           if (intval($extx)==0){
             //相当于页面实例带具体值
             $sqlx="plancode,pagetitle,keyval,pageurl,pagelocal,CRTM,UPTM,OLMK";
             $sqly="'$plancode','$utitle','$valstr','$outurly','$outx',now(),now(),'".onlymark()."'";
             $zz=UX("insert into coode_datapages(".$sqlx.")values(".$sqly.")");
           }
           $cc=UX("update coode_datapages,coode_datatopage set coode_datapages.plantitle=coode_datatopage.plantitle,coode_datapages.dumark=coode_datatopage.dumark,coode_datapages.tabname=coode_datatopage.tabname,coode_datapages.tabkey=coode_datatopage.tabkey where coode_datapages.plancode=coode_datatopage.plancode");
          echo makereturnjson("1","合成成功","");          
         break;
         default:
           if (file_exists($outx)){
            header("location:".$outurly);
           }else{
             echo $pagehtml;
           }
       }
   }else{
       echo "No Para.";
   }
       session_write_close();
?>