<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $tiny=_get('tiny');
 $refresh=_get('refresh');
 $loginvfcode=_get('loginvfcode');
 if ($loginvfcode!=""){
   $timea=varval($loginvfcode)*1;
   $timeb=time();
   
   if (($timeb-$timea)<=60){
    $loginuid=_get("loginuid");
    $pgstoken=_get("pagestoken");
       $urst=SX("select vxuid,userid,wrdid,dpmore,depart,posids,realname from coode_userlist where userid='".$loginuid."'");
       
       if ( countresult($urst)>0){        
          $uid=$loginuid;
          $rname=anyvalue($urst,"realname",0);
          $comid=anyvalue($urst,"wrdid",0);
          setcookie("uid",$uid,time()+3600,"/");          
          setcookie("cid",$comid,time()+3600,"/");                    
          $depart=anyvalue($urst,"depart",0);
          $dpmore=anyvalue($urst,"dpmore",0);
          $posids=anyvalue($urst,"posids",0);          
          setcookie("depart",$depart,time()+3600,"/");
          setcookie("dpts",$dpmore,time()+3600,"/");
          setcookie("posids",$posids,time()+3600,"/");
          $stoken=dftval($pgstoken,md5($uid.$comid.time()));
          setcookie("stoken",$stoken,time()+3600,"/");  
          $sqla="userid,realname,wrdid,sysid,depart,dpmore,posids,stoken,deadline,logintime,loginarea,fromdomain,CRTM,UPTM,OLMK,CRTOR";
          $sqlb="'".$uid."','".$rname."','".$comid."','".$sysid."','".$depart."','".$dpmore."','".$posids."','".$stoken."',date_add(now(), interval 30 minute),now(),'','',now(),now(),'".onlymark()."','".$uidx."'";
          $c=UX("insert into coode_loginstoken(".$sqla.")values(".$sqlb.")");
        }
   }
  }
 $s=_get("s");
 $dttp=_get("datatype");
 $conn=mysql_connect(gl(),glu(),glp());
 $rstx=selecteds($conn,glb(),"select SNO,longexp,appid,sysid,layid,tinytitle,tempid,laypath,shortid,STATUS from coode_tiny where tinymark='".$tiny."'","utf8","");
 $snox=anyvalue($rstx,"SNO",0);
 $lx=anyvalue($rstx,"longexp",0);
 $sysid=anyvalue($rstx,"sysid",0);
 $appid=anyvalue($rstx,"appid",0);
 $shortid=anyvalue($rstx,"shortid",0);
 $tempid=anyvalue($rstx,"tempid",0);
 $stt=anyvalue($rstx,"STATUS",0);
 $laid=anyvalue($rstx,"layid",0);
 $laypath=anyvalue($rstx,"laypath",0);
 $tinytitle=anyvalue($rstx,"tinytitle",0);
 $stid=qian(qian(hou($lx,"stid="),"&"),"-");
 if ($rdr!=""){
   $dttp="rdr";
 }
 $parakey="";
 
 $extpara=0;
 $parakey=hou($_SERVER["QUERY_STRING"],"?");
 $parakey=str_replace("tiny=","tinyid=",$parakey);
    if ($laypath!=""){
      if (strpos($laypath,"/formx/")>0){
        $canshu=hou($lx,"?");
        $visiturl=$laypath."?".$canshu;
      }else{
        $visiturl=$laypath;
      }
    }else{
       $visiturl=tostring($lx);
       $laypath="layfailure";
    }
  if (es($visiturl)>=1){
    $visiturl=exchangestr($visiturl,$shortid,"");
  }else{
    $visiturl="/localxres/csspagex/404/black/failure.html";
  }
  if (strpos($visiturl,"?")>0){
   $visiturl=$visiturl."&".$parakey.$rfrs;
  }else{
   $visiturl=$visiturl."?".$parakey.$rfrs;
  }
 if (strpos($visiturl,"rnd=")<=0){
  if (strpos($visiturl,"?")>0){
   $visiturl=$visiturl."&rnd=".getRandChar(6);
  }else{
   $visiturl=$visiturl."?rnd=".getRandChar(6);
  }
 }
 
 
 $ispmiss=UX("select ispmiss as result from coode_tiny where tinymark='".$tiny."'");
 if (intval($ispmiss)==0){
       //不设权，看黑名单
       $extb=UX("select count(*) as result from coode_visitresaccess where listtype='black' and restype='pagex' and rescode='".$tiny."' and ('xx-,".$_COOKIE["roleids"].",' like concat('%,',roleid,',%') or uid='".$_COOKIE["uid"]."')");
       //echo "select count(*) as result from coode_visitresaccess where listtype='black' and restype='pagex' and rescode='".$tiny."' and ('xx-,".$_COOKIE["roleids"].",' like concat('%,',roleid,',%') or uid='".$_COOKIE["uid"]."')";
       if (intval($extb)>0){
        $visiturl="/localxres/csspagex/404/black/failure.html";        
       }
 }else{
       $extw=UX("select count(*) as result from coode_visitresaccess where listtype='white' and restype='pagex' and rescode='".$tiny."' and ('xx-,".$_COOKIE["roleids"].",' like concat('%,',roleid,',%') or uid='".$_COOKIE["uid"]."')");
       if (intval($extw)==0){
        $visiturl="/localxres/csspagex/404/black/failure.html";        
       }      
 }
 if (strpos("xx".$visiturl,$laypath)>0 and $laypath!=""){
      $fullpath=combineurl(localroot(),$laypath);
      if (file_exists($fullpath)){
      }else{
       $furl=$laypath;
       $mvurl=makeviewurl($furl);
       $visiturl="/localxres/tempx/loading/index.html?pagetype=pagex&tinysno=".$snox."&vurl=".$mvurl;
      }
  }
 switch($dttp){
   case "json":
   echo "{\"status\":\"1\",\"msg\",\"web redirect\",\"redirect\":\"".$visiturl."\"}";
   break;
   case "rdr":
   echo "location:".$visiturl;   
   break;
   default:
   header("location:".$visiturl);
 }
 
     session_write_close();
?>