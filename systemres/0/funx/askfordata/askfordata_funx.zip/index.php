<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     //请求完之后，系统里有这个方法表的返回数据{a:b,c:d}格式。没有的话生成测试数据 返回{a:b,c:d}还要有数据类型 按照数据类型返回测试数据
$dtitle=$_GET["dtitle"];
$layid=$_GET["layid"];
$tinyid=$_GET["tinyid"];
$postmark=$_GET["postmark"];
if ($tinyid=="" or $tinyid=="un"."defined"){
 $tinyid="default";
}
$pnum=$_GET["pnum"];
$page=$_GET["page"];
$dmark=$layid.".".$tinyid;
if ($dmark=="" or $dmark=="."){
 $dmark=substr(md5($_SERVER["HTTP_REFERER"]),0,16);
}
if ($postmark!=""){
  $dmark=$dmark."@".$postmark;
}
$limitdemo='if ($_GET["page"]==""){
 $page="1";
}
if ($_GET["pnum"]==""){
 $pnum="30";
}
$limitdm=" limit ".(($page-1)*$pnum).",".$pnum;'.huanhang();
$askqry=hou($_SERVER["HTTP_REFERER"],"?");
$dfmt=$_POST["dfmt"];
$extx=UX("select count(*) as result from coode_askdata where datamark='".$dmark."' ");
$onedft=array();
$listdfttitle=array(array());
$listdfttype=array(array());
$listdftkey=array(array());
if (intval($extx)>0){
  $drst=SX("select kreturn,atempid from coode_askdata where layid='".$layid."' and tinyid='".$tinyid."' ");
  $dtxt=anyvalue($drst,"kreturn",0);
  $atempid=anyvalue($drst,"atempid",0);
  if ($atempid==""){
   eval(tostring($dtxt));   
   echo $rtnvalue;
  }else{
    $dtxt=UX("select kreturn as result from coode_askdtemp where datamark='".$atempid."' ");    
    eval(tostring($dtxt));
    echo $rtnvalue;
  }
}else if ($layid!="" and $layid !="un"."defined" ){
  $dfmt=str_replace(" ","",$dfmt);
  $dfmt=str_replace("[","{",$dfmt);
  $dfmt=str_replace("]","}",$dfmt);
  $dfmt=substr($dfmt,1,strlen($dfmt)-2);
  $xkeys="";
  //dfmt={ktps:[{keyname:字段名称(string),datatype:字段类型(string),typelen:类型长度(int),typetitle:类型标题(string),changeable:可否更改(bo01)},...],bb:特殊(string){},cc:好处(string){}}
  $ptdfmt=explode("},",$dfmt);
  $totpt=count($ptdfmt);
  for ($i=0;$i<$totpt;$i++){
    $onedft[$i]=$ptdfmt[$i]."}";
    $onekey[$i]=qian($onedft[$i],":");
    $listdftkey[$i][0]=$onekey[$i];
    $oneval[$i]=hou($onedft[$i],":");
    if (isennum($onekey[$i])){
      $xkeys=$xkeys.$onekey[$i].",";
    }
    if (substr($oneval[$i],0,1)!="{"){
     $onetitle[$i]=qian($oneval[$i],"(");
     $onetype[$i]=qian(hou($oneval[$i],"("),")");
     $listdfttitle[$i][0]=$onetitle[$i];
     $listdfttype[$i][0]=$onetype[$i];
    }else{
     if (substr($oneval[$i],0,2)=="{{"){
      $onetitle[$i]="下属列表";
      $onetype[$i]="object";
      $listdfttitle[$i][0]="下属列表";
      $listdfttype[$i][0]="object";
      $preone=substr($oneval[$i],1,strlen($oneval[$i])-2);
      $ptone=explode("},",$preone);//取出第一列，然后分解
      $oneinner=hou("x".$ptone[0],"{");
      $ptinner=explode(",",$oneinner);
      $totpi=count($ptinner);
      for ($j=0;$j<$totpi;$j++){
       $tmpkey=qian($ptinner[$j],":");
       $tmpval=hou($ptinner[$j],":");
       $tmptitle=qian($tmpval,"(");
       $tmptype=qian(hou($tmpval,"("),")");
       $listdftkey[$i][$j+1]=$tmpkey; 
       $listdfttitle[$i][$j+1]=$tmptitle;
       $listdfttype[$i][$j+1]=$tmptype;
      }
     }else{
      $onetitle[$i]="下属单列";
      $onetype[$i]="object";
      $preone=substr($oneval[$i],1,strlen($oneval[$i])-2);
      $ptinner=explode(",",$preone);
      $totpi=count($ptinner);
      for ($j=0;$j<$totpi;$j++){
       $tmpkey=qian($ptinner[$j],":");
       $tmpval=hou($ptinner[$j],":");
       $tmptitle=qian($tmpval,"(");
       $tmptype=qian(hou($tmpval,"("),")");
       $listdftkey[$i][$j+1]=$tmpkey; 
       $listdfttitle[$i][$j+1]=$tmptitle;
       $listdfttype[$i][$j+1]=$tmptype;
      }//for
     }//if 0 2
    }//for i
  }//if ext*
  
$sqlx="datamark,layid,tinyid,keyname,datatitle,dkeys,CRTM,UPTM,CRTOR,OLMK,asktype";
$sqly="'".$dmark."','".$layid."','".$tinyid."','".$_SERVER["HTTP_REFERER"]."','".$dtitle."','".killlaststr($xkeys)."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."','objlf'";
$sqlz=UX("insert into coode_asklist(".$sqlx.")values(".$sqly.")");     
$demox="";
$casex="";
$fundemo='function getvalue($dmk,$dkey,$ktitle,$ktype){
[funbody]
}
';
$swicdemo=' switch($dmk){
case "'.$dmark.'":
                //dosomething
    switch($dkey){
    [casedemo]     
    default:
        //dosomething
     return "";
    }
break;
default:
    return "";    //dosomething
 }
';
  $tmpp=-1;
  $fmpost=array();;
  $fmrtntxt='$rtntxt="{";'.huanhang();
  for ($i=0;$i<$totpt;$i++){
  if (isennum($onekey[$i])){
   if ($onetype[$i]!="object"){
     $demox=$demox.'$'.$onekey[$i].'x=getvalue("'.$dmark.'","'.$onekey[$i].'","'.$onetitle[$i].'","'.$onetype[$i].'");'.huanhang();
     $rtndemo='$rtnval=gettabval("TABLE{CDTX}[PAGE/PNUM]@KEY.SQX");';
     $sqlx="datamark,datatitle,keyname,keytitle,ktypev,keytype,keyverify,fromurl,CRTM,UPTM,OLMK,CRTOR,rtneval";
     $sqly="'".$dmark."','".$dtitle."','".$onekey[$i]."','".$onetitle[$i]."','".$onetype[$i]."','".qian($onetype[$i],":")."','".hou($onetype[$i],":")."','".$_SERVER["HTTP_REFERER"]."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."','".$rtndemo."'";
     $sqlz=UX("insert into coode_askkey(".$sqlx.")values(".$sqly.")");
     $fmrtntxt=$fmrtntxt.'$rtntxt=$rtntxt.\'"'.$onekey[$i].'":"\'.$'.$onekey[$i].'x.\'",\';'.huanhang();
     $casex=$casex.'    case "'.$onekey[$i].'"://'.$onetitle[$i].'('.$onetype[$i].')'.huanhang();
     $casex=$casex.'    $tmpvalue=gettestvalue("'.$dmark.'","'.$onekey[$i].'","'.$onetitle[$i].'","'.$onetype[$i].'");                     //do some thing here;'.huanhang();
     $casex=$casex.'    return $tmpvalue;'.huanhang();
     $casex=$casex.'    break;'.huanhang();
   }else{
     $tmpkeys="";
     $tmptts="";
     $tmptps="";
     $tmpcomk="";
     $fmrtntxt=$fmrtntxt.'$rtntxt=$rtntxt.\'"'.$onekey[$i].'":\'.$'.$onekey[$i].'x.\',\';'.huanhang();
      for ($p=0;$p<count($listdftkey[$i])-1;$p++){
       $tmpkeys=$tmpkeys.$listdftkey[$i][$p+1].",";
       $tmptts=$tmptts.$listdfttitle[$i][$p+1].",";
       $tmptps=$tmptps.$listdfttype[$i][$p+1].",";
       $tmpcomk=$tmpcomk.$listdftkey[$i][$p+1]."@".$listdfttitle[$i][$p+1]."(".$listdfttype[$i][$p+1]."),";
      }
     $casex=$casex.'    case "'.$onekey[$i].'"://'.$onetitle[$i].'('.$onetype[$i].')'.huanhang();
     $casex=$casex.'                  //do some thing here;'.huanhang();
     $casex=$casex.'                  //'.$tmpkeys.';'.huanhang();
     $casex=$casex.'                  //'.$tmptts.';'.huanhang();
     $casex=$casex.'                  //'.$tmptps.';'.huanhang();
     if ($onetitle[$i]=="下属列表"){     
      $demox=$demox.'$'.$onekey[$i].'x=getvalue("'.$dmark.'","'.$onekey[$i].'","'.$onetitle[$i].'","'.$onetype[$i].'");'.huanhang();
      $rtndemo='$rtnval=gettabval("TABLE{CDTX}[PAGE/PNUM]@KEY.SQX");';
      $sqlx="datamark,layid,tinyid,datatitle,keyname,keytitle,ktypev,keytype,keyverify,fromurl,CRTM,UPTM,OLMK,CRTOR,rtneval";
      $sqly="'".$dmark."','".$layid."','".$tinyid."','".$dtitle."','".$onekey[$i]."','".$onetitle[$i]."','OBJECT','OBJECT','OBJECT','".$_SERVER["HTTP_REFERER"]."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."','".$rtndemo."'";
      $sqlz=UX("insert into coode_askkey(".$sqlx.")values(".$sqly.")");      
      $tmpp=$tmpp+1;
      $fmpost[$tmpp]="";
      $casex=$casex.'        //$brst=SX("select '.killlaststr($tmpkeys).' from tabnm where condition ");'.huanhang();
      $casex=$casex.'        $drst=TX("select '.killlaststr($tmpcomk).' from anytest where condition ");'.huanhang();
      $casex=$casex.'        //$drst=VX("select '.killlaststr($tmpcomk).' from anytest where condition ",$dmk."'.$onekey[$i].'");'.huanhang();
      $casex=$casex.'        $totd'.$onekey[$i].'=countresult($drst);'.huanhang();
      $casex=$casex.'        $fmdemo="[";'.huanhang();
      $casex=$casex.'        for ($a=0;$a<$totd'.$onekey[$i].';$a++){'.huanhang();  //--------------------------------------------
      $casex=$casex.'           $fmdemo=$fmdemo."{";'.huanhang();      
      $fkeys="";
      $fvals="";
      $tmpvf="";
      for ($p=0;$p<count($listdftkey[$i])-1;$p++){
       $casex=$casex.'          $'.$listdftkey[$i][$p+1].'y=anyvalue($drst,"'.$listdftkey[$i][$p+1].'",$a);'.huanhang();
       $casex=$casex.'          $fmdemo=$fmdemo."\"'.$listdftkey[$i][$p+1].'\":\"$'.$listdftkey[$i][$p+1].'y\",";'.huanhang();
       $tmpvf=$tmpvf.'intval(verifypost($_POST["'.$listdftkey[$i][$p+1].'"],"'.$listdfttype[$i][$p+1].'"))*';
       $fmpost[$tmpp]=$fmpost[$tmpp].'$'.$listdftkey[$i][$p+1].'y=$_POST["'.$listdftkey[$i][$p+1].'x"];'.huanhang();
       $fkeys=$fkeys.$listdftkey[$i][$p+1].",";
       $fvals=$fvals.'\'$'.$listdftkey[$i][$p+1].'y\',';
       $rtndemo='$rtnval=gettabval("TABLE{CDTX}[PAGE/PNUM]@KEY.SQX");';
       $sqlx="datamark,layid,tinyid,datatitle,keyname,keytitle,ktypev,keytype,keyverify,fromurl,CRTM,UPTM,OLMK,CRTOR,rtneval";
       $sqly="'".$dmark."@".$onekey[$i]."','".$layid."','".$tinyid."','".$dtitle."','".$listdftkey[$i][$p+1]."','".$listdfttitle[$i][$p+1]."','".$listdfttype[$i][$p+1]."','".qian($listdfttype[$i][$p+1],":")."','".hou($listdfttype[$i][$p+1],":")."','".$_SERVER["HTTP_REFERER"]."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."','".$rtndemo."'";
       $sqlz=UX("insert into coode_askkey(".$sqlx.")values(".$sqly.")");       
      }
      $fmpost[$tmpp]=$fmpost[$tmpp].'$sqla="'.killlaststr($fkeys).'";'.huanhang();
      $fmpost[$tmpp]=$fmpost[$tmpp].'$sqlb="'.killlaststr($fvals).'";'.huanhang();
      $fmpost[$tmpp]=$fmpost[$tmpp].'if (('.killlaststr($tmpvf).')==1){'.huanhang();
      $fmpost[$tmpp]=$fmpost[$tmpp].'    $z=UX("insert into anytable($sqla)values($sqlb)")'.huanhang();
      $fmpost[$tmpp]=$fmpost[$tmpp].'    $rtnvalue= "1";'.huanhang();
      $fmpost[$tmpp]=$fmpost[$tmpp].'}else{'.huanhang();
      $fmpost[$tmpp]=$fmpost[$tmpp].'    $rtnvalue= "0";'.huanhang();
      $fmpost[$tmpp]=$fmpost[$tmpp].'}'.huanhang();
      $fmpost[$tmpp]=$fmpost[$tmpp].huanhang();
      if (count($listdftkey[$i])-1>0){
       $casex=$casex.'          $fmdemo=killlaststr($fmdemo)."},";'.huanhang();
      }else{
       $casex=$casex.'          $fmdemo=$fmdemo."},";'.huanhang();
      }
      $casex=$casex.'        };'.huanhang();//write for a
      $casex=$casex.'     if ($totd'.$onekey[$i].'>0){'.huanhang();//write for a
      $casex=$casex.'          $fmdemo=killlaststr($fmdemo)."]";'.huanhang();
      $casex=$casex.'     }else{'.huanhang();
      $casex=$casex.'          $fmdemo=$fmdemo."]";'.huanhang();
      $casex=$casex.'     }'.huanhang();
      $casex=$casex.'    return $fmdemo;'.huanhang();
      $casex=$casex.'    break;'.huanhang();
    }else{
      $demox=$demox.'$'.$onekey[$i].'x=getvalue("'.$dmark.'","'.$onekey[$i].'","'.$onetitle[$i].'","'.$onetype[$i].'");'.huanhang();
      $rtndemo='$rtnval=gettabval("TABLE{CDTX}[PAGE/PNUM]@KEY.SQX");';
      $sqlx="datamark,layid,tinyid,datatitle,keyname,keytitle,ktypev,keytype,keyverify,fromurl,CRTM,UPTM,OLMK,CRTOR,rtneval";
      $sqly="'".$dmark."','".$layid."','".$tinyid."','".$dtitle."','".$onekey[$i]."','".$onetitle[$i]."','object','object','object','".$_SERVER["HTTP_REFERER"]."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."','".$rtndemo."'";
      $sqlz=UX("insert into coode_askkey(".$sqlx.")values(".$sqly.")");
      $casex=$casex.'    $fmdemo="";'.huanhang();      
      $casex=$casex.'    $fmdemo=$fmdemo."{";'.huanhang();
      for ($p=0;$p<count($listdftkey[$i])-1;$p++){
       $casex=$casex.'  $'.$listdftkey[$i][$p+1].'y=computethisvalue();'.huanhang();
       $casex=$casex.'  $fmdemo=$fmdemo."\"'.$listdftkey[$i][$p+1].'\":\"$'.$listdftkey[$i][$p+1].'y\",";'.huanhang();
       $rtndemo='$rtnval=gettabval("TABLE{CDTX}[PAGE/PNUM]@KEY.SQX");';
       $sqlx="datamark,layid,tinyid,datatitle,keyname,keytitle,ktypev,keytype,keyverify,fromurl,CRTM,UPTM,OLMK,CRTOR,rtneval";
       $sqly="'".$dmark."@".$onekey[$i]."','".$layid."','".$tinyid."','".$dtitle."','".$listdftkey[$i][$p+1]."','".$listdfttitle[$i][$p+1]."','".$listdfttype[$i][$p+1]."','".qian($listdfttype[$i][$p+1],":")."','".hou($listdfttype[$i][$p+1],":")."','".$_SERVER["HTTP_REFERER"]."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."','".$rtndemo."'";
       $sqlz=UX("insert into coode_askkey(".$sqlx.")values(".$sqly.")");
      }
      $casex=$casex.'    if (count($listdftkey[$i])-1>0){'.huanhang();
      $casex=$casex.'      $fmdemo=killlaststr($fmdemo)."}";'.huanhang();
      $casex=$casex.'    }else{'.huanhang();
      $casex=$casex.'      $fmdemo=$fmdemo."}";'.huanhang();
      $casex=$casex.'    }'.huanhang();
      $casex=$casex.'    return $fmdemo;'.huanhang();
      $casex=$casex.'    break;'.huanhang();
     }//if onetitle
    }// if object   
   }//if  en num 是英文或数字组成才可以，不然不合法
  }//for i
  $fmrtntxt=$fmrtntxt.'$rtntxt=killlaststr($rtntxt)."}";'.huanhang();
  $fmrtntxt=$fmrtntxt.'$rtnvalue=$rtntxt;'.huanhang();
  $alldemo="";
  $fundemo=str_replace("[funbody]",$swicdemo,$fundemo);
  $fundemo=str_replace("[casedemo]",$casex,$fundemo);
  $alldemo=$fundemo.$limitdemo.$demox.$fmrtntxt;
  $demodata=gohex($alldemo);
   
   $sqla="layid,tinyid,datamark,datatitle,askqry,kid,kdescrib,ktype,linktabkey,kreturn,OLMK,CRTOR,CRTM,UPTM,fromurl,askformat";
   $sqlb="'".$layid."','".$tinyid."','".$dmark."','".$dtitle."','".$askqry."','".killlaststr($tmpkeys)."','".killlaststr($tmptts)."','".killlaststr($tmptps)."','','".$demodata."','".onlymark()."','".$_COOKIE["uid"]."',now(),now(),'".$_SERVER["HTTP_REFERER"]."','".gohex($dfmt)."'";
   $z=UX("insert into coode_askdata(".$sqla.")values(".$sqlb.")");
  if ($tmpp!=-1){
   for ($z=0;$z<$tmpp+1;$z++){
     $sqla="datamark,layid,tinyid,datatitle,askqry,kid,kdescrib,ktype,linktabkey,kreturn,OLMK,CRTOR,CRTM,UPTM,fromurl";
     $sqlb="'".$dmark."@post".$z."','".$layid."','".$tinyid."','".$dtitle."提交','".$askqry."','','','','','".gohex($fmpost[$z])."','".onlymark()."','".$_COOKIE["uid"]."',now(),now(),'".$_SERVER["HTTP_REFERER"]."'";
     $z=UX("insert into coode_askdata(".$sqla.")values(".$sqlb.")");
   }
  }
  eval ($alldemo);
  echo $rtnvalue;
}else{
 echo "{\"status\":\"0\",\"msg\":\"请求数据不全\",\"redirect\":\"\"}";
}//extx *1
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>