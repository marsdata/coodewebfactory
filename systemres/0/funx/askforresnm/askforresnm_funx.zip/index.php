<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $resname=dftval($_POST["resname"],"");
$rescode=dftval($_POST["rescode"],"");
$restype=dftval($_POST["restype"],"");
$resdes=dftval($_POST["resdes"],"");
$vfcode=dftval($_POST["vfcode"],"");
$pagess=dftval($_GET["pagess"],"");
if (es($resname)*es($rescode)*es($restype)==1 and $vfcode==varval($pagess)){
 $url=combineurl("http://io.halo123.cn","/localxres/funx/applyforresnm/");
 $pd=array();
 $acode=md5(onlymark());
 $pd["resname"]=$resname;
 $pd["rescode"]=$rescode;
 $pd["restype"]=$restype;
 $pd["accesscode"]=$acode;
 $pd["resdes"]=$resdes;
 $pd["askman"]=$_COOKIE["uid"];
 $pd["fromhost"]=$_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"];
 $bktxt=request_post($url,$pd);
 $bkdata=json_decode($bktxt);
 $statux=intval($bkdata->status);
 $rdr=$bkdata->redirect;
 switch($statux){
 case 1:
  $sqlx="acccode,restype,rescode,restitle,resarea,fromip,fromhost,askman,CRTM,UPTM,OLMK,STATUS";
  $sqly="'$acode','$restype','$rescode','$resname','".glm()."','','".$_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"]."','".$_COOKIE["uid"]."',now(),now(),'".onlymark()."',1";
  $zz=UX("insert into coode_devespace(".$sqlx.")values(".$sqly.")");
  echo makereturnjson("1","请求成功",$rdr);
  break;
  case -1:
  echo makereturnjson("2","资源名已被使用","");
  break;
  case 0:
  echo makereturnjson("0","请求失败","");
  break;
  default:
 }
}else{
  echo makereturnjson("0","参数不全","");
}
     session_write_close();
?>