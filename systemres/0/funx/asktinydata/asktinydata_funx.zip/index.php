<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tempid=$_GET["tempid"];
$layid=$_GET["layid"];
$keys=$_POST["keys"];
$titles=$_POST["titles"];
$ptk=explode(",",$keys);
$ptt=explode(",",$titles);
$totptk=count($ptk);
$fmbk="{\"status\":\"1\",";
$fromurl=isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
 $extlay=UX("select count(*) as result from coode_applay where layid='".$layid."' ");
 $extaa=UX("select count(*) as result from coode_laytemplist where layid='".$layid."' and tempid='".$tempid."' ");
 if (intval($extaa)==0 and intval($extlay)>0){
    $sqla="layid,tempid,datatitle,CRTM,UPTM,CRTOR,RIP";
    $sqlb="'".$layid."','".$tempid."','',now(),now(),'','".getip()."'";
    $cc=UX("insert into coode_laytemplist(".$sqla.")values(".$sqlb.")");
    $sqlx="datamark,asktype,qrykey,qrytitle,askexp,askfrom,CRTM,UPTM,OLMK,CRTOR";
    $sqly="'".$tempid.".".$layid."','pointline','".$keys."','".$titles."','".$titles."|".$keys."','".$fromurl."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."'";
    $zx=UX("insert into coode_asklist(".$sqlx.")values(".$sqly.")");
 }else{
 }
if (intval($extlay)>0){
 for ($i=0;$i<$totptk;$i++){
  $kk=qian($ptk[$i],"(");
  if (strpos($ptk[$i],")")>0){
   $kv=qian(hou($ptk[$i],"("),")");
  }
  if (strpos($ptk[$i],"]")>0){
   $fmt=qian(hou($ptk[$i],"["),"]");
  }
  $extx=UX("select count(*) as result from coode_laytempkval where layid='".$layid."' and tempid='".$tempid."' and askkey='".$kk."'");
  if (intval($extx)>0){
    $krst=SX("select askkey,asktype,askformat,rtndata from coode_laytempkval where layid='".$layid."' and tempid='".$tempid."' and askkey='".$kk."'");
    $rtnval=anyvalue($krst,"rtndata",0);
    $rtnval=exchangeqry($rtnval);    
    if (strpos($rtnval,"fvalue=")>0){
      $fvalue="";
      eval($rtnval);
      $rtnvalue=$fvalue;
    }else{
      $rtnvalue=$rtnval;
    }
    $fmbk=$fmbk."\"".$kk."\":\"".$rtnvalue."\",";
  }else{
    $exty=UX("select count(*) as result from coode_laytempkval where layid='".$layid."' and tempid='default' and askkey='".$kk."'");
   if (intval($exty)>0){
    $krst=SX("select askkey,asktype,askformat,rtndata from coode_laytempkval where layid='".$layid."'  and askkey='".$kk."'");
    $rtnval=anyvalue($krst,"rtndata",0);
    $rtnval=exchangeqry($rtnval);
    if (strpos($rtnval,"fvalue=")>0){
      $fvalue="";
      eval($rtnval);
      $rtnvalue=$fvalue;
    }else{
      $rtnvalue=$rtnval;
    }
    $fmbk=$fmbk."\"".$kk."\":\"".$rtnvalue."\",";
   }else{
    if ($tempid!="" and $layid!="" and $layid!="un"."defined" and $tempid!="un"."defined"){
     $sqlx="layid,tempid,askkey,asktype,keytitle,askformat,CRTM,UPTM,OLMK,CRTOR,fromurl";
     $sqly="'".$layid."','".$tempid."','".$kk."','".$kv."','".$ptt[$i]."','".$fmt."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."','".$fromurl."'";
     $z=UX("insert into coode_laytempkval(".$sqlx.")values(".$sqly.")");
    }
     $fmbk=$fmbk."\"".$kk."\":\"".""."\",";
   }//if exty
  } //if extx
 }//for
}else{
 for ($i=0;$i<$totptk;$i++){
  $kk=qian($ptk[$i],"(");
  if (strpos($ptk[$i],")")>0){
   $kv=qian(hou($ptk[$i],"("),")");
  }
  if (strpos($ptk[$i],"]")>0){
   $fmt=qian(hou($ptk[$i],"["),"]");
  }
   $fmbk=$fmbk."\"".$kk."\":\"".""."\",";   
 }//for
}
$z=UX("update coode_laytempkval,coode_applay set coode_laytempkval.laytitle=coode_applay.laytitle where coode_laytempkval.layid=coode_applay.layid");
$z=UX("update coode_laytempkval,coode_tiny set coode_laytempkval.temptitle=coode_tiny.tinytitle where coode_laytempkval.tempid=coode_tiny.tinymark");
$z=UX("update coode_laytemplist,coode_applay set coode_laytemplist.laytitle=coode_applay.laytitle where coode_laytemplist.layid=coode_applay.layid");
$z=UX("update coode_laytemplist,coode_tiny set coode_laytemplist.temptitle=coode_tiny.tinytitle where coode_laytemplist.tempid=coode_tiny.tinymark");
if($totptk>0){
  $fmbk=killlaststr($fmbk)."}";
}else{
 $fmbk=$fmbk."}";
}
echo $fmbk;
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>