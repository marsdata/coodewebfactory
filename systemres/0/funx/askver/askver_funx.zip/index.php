<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $restype=_get("restype");
$rescode=_get("rescode");
switch($restype){
 case "formx":
  $drst=SX("select sysid,shorttitle,tablename from coode_shortdata where shortid='".$rescode."'");
  $totd=countresult($drst);
  if (intval($totd)>0){
   $sysid=anyvalue($drst,"sysid",0);
   $shorttitle=anyvalue($drst,"shorttitle",0);
   $tablename=anyvalue($drst,"tablename",0);
   $tabrst=SX("select tabtitle,createsql from coode_tablist where TABLE_NAME='$tablename'");
   $tabtitle=anyvalue($tabrst,"tabtitle",0);
   $createsql=anyvalue($tabrst,"createsql",0);
   $tabmd5=md5($createsql);
   $kxrst=SX("select SNO,md5(concat(COLUMN_NAME,keytitle,COLUMN_DEFAULT,COLUMN_TYPE,classp,clstxt,valuezero,keyexplain,jsonshowfun,sysshowfun,jspostfun,syspostfun,changeable,displayed,dxtype,bfist,aftist,bfupd,aftupd,bfdel,aftdel,SQX,VQX)) as vmd5 from coode_keydetailx where TABLE_NAME='".$tablename."'");
   $totx=countresult($kxrst);
   $fmx="";
   for ($x=0;$x<$totx;$x++){
    $fmx=$fmx.anyvalue($kxrst,"vmd5",$x);
   }
   $formmd5=UX("select md5(concat(sysid,shorttitle,tablename,caseid,detailid,allkeys,showkeys,cdt,orddt,lang,dttp)) as result from coode_shortdata where shortid='".$rescode."'");
   $xmd5=md5($fmx);
   $kyrst=SX("select SNO,md5(concat(COLUMN_NAME,keytitle,COLUMN_DEFAULT,COLUMN_TYPE,classp,clstxt,valuezero,keyexplain,jsonshowfun,sysshowfun,jspostfun,syspostfun,changeable,displayed,dxtype,bfist,aftist,bfupd,aftupd,bfdel,aftdel,SQX,VQX)) as vmd5 from coode_keydetaily where shortid='".$rescode."'");
   $toty=countresult($kyrst);
   $fmy="";
   for ($y=0;$y<$toty;$y++){
    $fmy=$fmy.anyvalue($kyrst,"vmd5",$y);
   }
   $ymd5=md5($fmy);
   echo '{"status":"1","msg":"获取成功","crtsql":"'.$createsql.'","xmd5":"'.$xmd5.'","ymd5":"'.$ymd5.'","tabmd5":"'.$tabmd5.'","formmd5":"'.$formmd5.'"}';
  }else{
   echo '{"status":"-1","msg":"不存在资源"}';
  }
 break;
 case "funx":
 $fmd5=UX("select md5(funfull) as result from coode_funlist where funname='".$rescode."' or funname='".$rescode."()'");
 echo '{"status":"1","msg":"获取成功","fmd5":"'.$fmd5.'"}';
 break;
 case "pagex":
  $laypath=UX("select laypath as result from coode_tiny where tinymark='".$rescode."'");
  if ($laypath!=""){
    $pmd5=UX("select md5(concat(shortid,tabname,tinytitle,longexp,sysid,appid,layid)) as result from coode_tiny where tinymark='".$rescode."'");
    $layfile=combineurl(localroot(),$laypath);
    $lmd5=md5_file($layfile);    
    echo '{"status":"1","pmd5":"'.$pmd5.'","lmd5":"'.$lmd5.'"}';
  }else{
    echo '{"status":"1","pmd5":"'.$pmd5.'","lmd5":""}';
  }
 break;
 case "plotx":
   $plotmd5=UX("select md5(concat(layoutid,plotcls,sysid,appid,levelcount,totpoint,markname,defaultcss,formcode,clickfun)) as result from coode_plotlist where plotmark='".$rescode."'");   
   $kyrst=SX("select SNO,md5(concat(plotmark,level,myid,parid,oriid,mytitle,partitle,orititle,mymark,parmark,primark,myurl,myclick,fontname,mydescrib)) as vmd5 from coode_plotdetail where shortid='".$rescode."'");
   $toty=countresult($kyrst);
   $fmy="";
   for ($y=0;$y<$toty;$y++){
    $fmy=$fmy.anyvalue($kyrst,"vmd5",$y);
   }
   $ymd5=md5($fmy);
   if (intval($toty)>0){
     echo  '{"status":"1","plotmd5":"'.$plotmd5.'","dtlmd5":"'.$ymd5.'"}';
   }else{
     echo  '{"status":"0","plotmd5":"","dtlmd5":""}';
   }
 break;
 default:
 
}
     session_write_close();
?>