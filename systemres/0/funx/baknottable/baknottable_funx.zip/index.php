<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sysid=$_GET["sysid"];
$srctype=$_GET["srctype"];
$x=$_GET["x"];
switch($srctype){
case "unit":
$urst=SX("select unitmark,unittitle,sysid from coode_comunit where sysid='".$sysid."'");
$totu=countresult($urst);
if ($x!=""){
 $z=anyfunrun("bakunit","","unitmark=".anyvalue($urst,"unitmark",$x)."&sysid=".$sysid,"");
 echo "1";
}else{
 echo $totu;
}
break;
case "menu":
$mrst=SX("select menumark,menutitle,sysid,appid from coode_commenu where sysid='".$sysid."'");
$totm=countresult($mrst);
if ($x!=""){
 $z=anyfunrun("bakmenu","","menuid=".anyvalue($mrst,"menumark",$x)."&sysid=".$sysid,"");
 echo "1";
}else{
 echo $totm;
}
break;
case "plot":
$prst=SX("select plotmark,sysid,appid from coode_plotlist where sysid='".$sysid."'");
$totp=countresult($prst);
if ($x!=""){ 
 $z=anyfunrun("bakplot","","sysid=".$sysid,"");
 echo "1";
}else{
 echo $totp;
}
break;
case "page":
$prst=SX("select pageid,pagemark,sysid,appid from coode_compage where sysid='".$sysid."'");
$totp=countresult($prst);
if ($x!=""){
 $z=anyfunrun("bakpage","","pageid=".anyvalue($prst,"pageid",$x)."&sysid=".$sysid,"");
 echo "1";
}else{
 echo $totp;
}
break;
case "cform":
$csrst=SX("select cfid,cftitle,sysid,appid from coode_caseform where sysid='".$sysid."'");
$totcs=countresult($csrst);
if ($x!=""){
 $z=anyfunrun("bakcase","","cfid=".anyvalue($csrst,"cfid",$x)."&sysid=".$sysid,"");
 echo "1";
}else{
 echo $totcs;
}
break;
case "chtml":
$chrst=SX("select cssmark,csstitle,sysid,appid from coode_casehtml where sysid='".$sysid."'");
$totch=countresult($chrst);
if ($x!=""){
 $z=anyfunrun("bakchtml","","chid=".anyvalue($chrst,"cssmark",$x)."&sysid=".$sysid,"");
 echo "1";
}else{
 echo $totch;
}
break;
case "dunit":
$fmdmunitlist="";
$dmrst=SX("select domainmark,unitmark,sysid,appid from coode_domainunit where sysid='".$sysid."'");
$totdm=countresult($dmrst);
if ($x!=""){
  $z=anyfunrun("bakdmunit","","domainmark=".anyvalue($dmrst,"domainmark",$x)."&unitmark=".anyvalue($dmrst,"unitmark",$j)."&sysid=".$sysid,"");
  $fmdmunitlist=$fmdmunitlist."{\"domainmark\":\"".anyvalue($dmrst,"domainmark",$j)."\",\"unitmark\":\"".anyvalue($dmrst,"unitmark",$j)."\",\"sysid\":\"".anyvalue($dmrst,"sysid",$j)."\",\"appid\":\"".anyvalue($dmrst,"appid",$j)."\"},";  
  echo "1";
}else{
  echo $totdm;
}
 $fmdmunitlist=killlaststr($fmdmunitlist);
 
 break;
 default:
 echo "1";
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>