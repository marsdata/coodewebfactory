<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sysid=$_GET["sysid"];
 if ($dbase==""){
    $dbase=glb();
  }
  //想办法搞成= 确定完成的备份，不能老用IN 计算量太大容易卡死
  $kx=UX("delete from coode_datainstall where srcid='".$sysid."_plot'");//houmian后面d后面的duociyuiju后面的多此一举 
  $trst=SX("select createsql,keynames,keytpnms,jsontpnms,jsonconts,tabtitle,srckey,srcttk,contentkeys from coode_tablist where schm='".$dbase."' and TABLE_NAME='coode_plotdetail'");
  $srck=anyvalue($trst,"srckey",0);
  $srctk=anyvalue($trst,"srcttk",0);
  $olrst=SX("select OLMK from coode_plotdetail where VRT='".$sysid."'");
  $olrst=hou($olrst,"#/#");
  $olrst=str_replace("#-#",",",$olrst);
  $olrst=str_replace("#/#",",",$olrst);
  $kx=UX("delete from coode_datainstall where ',,".$olrst.",' like concat('%,',tabolmk,',%') and tabname='coode_plotdetail'");  
  if ($srck==""){
    $srck="VRT";
  }
  if ($srctk==""){
    $srctk="STCODE";
  }  
  $crts=anyvalue($trst,"createsql",0);
  $knms=anyvalue($trst,"keynames",0);
  $ktps=anyvalue($trst,"keytpnms",0);
  $ckeys=anyvalue($trst,"contentkeys",0);  
  $ktps=str_replace("↓","'",$ktps);
  $ktps=str_replace("↑","\\"."'",$ktps);
  $jstp=anyvalue($trst,"jsontpnms",0);    
  $jstp=str_replace("↓","'",$jstp);
  $jstp=str_replace("∵","\":\"",$jstp);  
  $jscons=anyvalue($trst,"jsonconts",0);  
  $jscons=str_replace("↓","'",$jscons);
  $jscons=str_replace("∵","\":\"",$jscons);  
  if ($knms!="" and $ktps!="" and $jstp!=""  ){
    $z=UX("insert into coode_datainstall(schm,srcid,tabname,tabsno,tabolmk,conjson,datajson,datasql,crttab,tabkeys,CRTM,UPTM,CRTOR,itemcrtm,itemuptm,itemcrtor,itemsrcid,itemsrcval,itemsrctt,itemsrctval,itemptof,conkeys)select '".$dbase."','".$sysid."_plot','coode_plotdetail',SNO,OLMK,concat('{',".$jscons.",'}'),concat('{',".$jstp.",'}'),concat('(',".$ktps.",')'),'".$crts."','".$knms."',now(),now(),'".$_COOKIE["uid"]."',CRTM,UPTM,CRTOR,'".$srck."',".$srck.",'".$srctk."',".$srctk.",PTOF,'".$ckeys."' from coode_plotdetail where VRT='".$sysid."'");                   
    $zzy=UX("update coode_datainstall set conjson=concat('〖',mid(conjson,3,length(conjson)-4),'〗') where mid(conjson,1,2)='{\"'");
    $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\":\"','Ｔ')");
    $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\",\"','Ｖ')");        
    $zzy=UX("update coode_datainstall set datajson=concat('〖',mid(datajson,3,length(datajson)-4),'〗') where mid(datajson,1,2)='{\"'");
    $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\":\"','Ｔ')");
    $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\",\"','Ｖ')");        
    $zzz=UX("update coode_datainstall set datasql=concat('〖',mid(datasql,3,length(datasql)-4),'〗') where mid(datasql,1,2)='(\''");
    $zzz=UX("update coode_datainstall set datasql=replace(datasql,'\',\'','∨')");    
    $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\"}〗','〗')");        
    $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\"}〗','〗')");        
    $zzz=UX("update coode_datainstall set datasql=replace(datasql,'∨\')〗','∨〗')");    
    $zzx=UX("update coode_datainstall set conmd5=md5(conjson),datamd5=md5(datasql),crtmd5=md5(crttab),keymd5=md5(frmsql),mymd5=md5(concat(tabname,tabolmk,datajson,datasql,crttab,frmsql,tabkeys))");    
    $zkx=UX("update coode_datainstall set frmsql=concat('insert into ',tabname,'(',tabkeys,')values([DATA])')");    
    $zstt=UX("update coode_datainstall SET STATUS=(length(replace(datasql,'∨','@:@'))-length(replace(datasql,'∨','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),PRIME= (length(replace(datajson,'Ｖ','@:@'))-length(replace(datajson,'Ｖ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),VRT=(length(replace(datajson,'Ｔ','@:@'))-length(replace(datajson,'Ｔ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))+1)");
  }
  $rstx=SX("select plotid,idxplid from coode_sysinformation where sysid='".$sysid."' or sysid='public'");
  $totrst=countresult($rstx);
  $fmyyy="";
  for($i=0;$i<$totrst;$i++){
   $plid=anyvalue($rstx,"plotid",$i);
   $idxplid=anyvalue($rstx,"idxplid",$i);
   $fmyyy=$fmyyy." plotmark='".$plid."' or plotmark='".$idxplid."' or ";
   
  }
    if (intval($totrst)>0){
    $fmyyy=substr($fmyyy,0,strlen($fmyyy)-3);
    $kx=UX("delete from coode_datainstall where srcid='".$sysid."_plst'");//houmian后面d后面的duociyuiju后面的多此一举   
    $trst=SX("select createsql,keynames,keytpnms,jsontpnms,jsonconts,tabtitle,srckey,srcttk,contentkeys from coode_tablist where schm='".$dbase."' and TABLE_NAME='coode_plotlist'");
    $srck=anyvalue($trst,"srckey",0);
    $srctk=anyvalue($trst,"srcttk",0);
    $olrst=SX("select OLMK from coode_plotlist where ".$fmxxx);
    $olrst=hou($olrst,"#/#");
    $olrst=str_replace("#-#",",",$olrst);
    $olrst=str_replace("#/#",",",$olrst);
    $kx=UX("delete from coode_datainstall where ',,".$olrst.",' like concat('%,',tabolmk,',%') and tabname='coode_plotlist'");  
    if ($srck==""){
      $srck="VRT";
    }
    if ($srctk==""){
      $srctk="STCODE";
    }  
    $crts=anyvalue($trst,"createsql",0);
    $knms=anyvalue($trst,"keynames",0);
    $ktps=anyvalue($trst,"keytpnms",0);
    $ckeys=anyvalue($trst,"contentkeys",0);  
    $ktps=str_replace("↓","'",$ktps);
    $ktps=str_replace("↑","\\"."'",$ktps);
    $jstp=anyvalue($trst,"jsontpnms",0);    
    $jstp=str_replace("↓","'",$jstp);
    $jstp=str_replace("∵","\":\"",$jstp);  
    $jscons=anyvalue($trst,"jsonconts",0);  
    $jscons=str_replace("↓","'",$jscons);
    $jscons=str_replace("∵","\":\"",$jscons);  
   if ($knms!="" and $ktps!="" and $jstp!=""  ){
    $z=UX("insert into coode_datainstall(schm,srcid,tabname,tabsno,tabolmk,conjson,datajson,datasql,crttab,tabkeys,CRTM,UPTM,CRTOR,itemcrtm,itemuptm,itemcrtor,itemsrcid,itemsrcval,itemsrctt,itemsrctval,itemptof,conkeys)select '".$dbase."','".$sysid."_plst','coode_plotlist',SNO,OLMK,concat('{',".$jscons.",'}'),concat('{',".$jstp.",'}'),concat('(',".$ktps.",')'),'".$crts."','".$knms."',now(),now(),'".$_COOKIE["uid"]."',CRTM,UPTM,CRTOR,'".$srck."',".$srck.",'".$srctk."',".$srctk.",PTOF,'".$ckeys."' from coode_plotlist where ".$fmyyy);                           
    $zzy=UX("update coode_datainstall set conjson=concat('〖',mid(conjson,3,length(conjson)-4),'〗') where mid(conjson,1,2)='{\"'");
    $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\":\"','Ｔ')");
    $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\",\"','Ｖ')");        
    $zzy=UX("update coode_datainstall set datajson=concat('〖',mid(datajson,3,length(datajson)-4),'〗') where mid(datajson,1,2)='{\"'");
    $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\":\"','Ｔ')");
    $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\",\"','Ｖ')");        
    $zzz=UX("update coode_datainstall set datasql=concat('〖',mid(datasql,3,length(datasql)-4),'〗') where mid(datasql,1,2)='(\''");
    $zzz=UX("update coode_datainstall set datasql=replace(datasql,'\',\'','∨')");    
    $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\"}〗','〗')");        
    $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\"}〗','〗')");        
    $zzz=UX("update coode_datainstall set datasql=replace(datasql,'∨\')〗','∨〗')");    
    $zzx=UX("update coode_datainstall set conmd5=md5(conjson),datamd5=md5(datasql),crtmd5=md5(crttab),keymd5=md5(frmsql),mymd5=md5(concat(tabname,tabolmk,datajson,datasql,crttab,frmsql,tabkeys))");    
    $zkx=UX("update coode_datainstall set frmsql=concat('insert into ',tabname,'(',tabkeys,')values([DATA])')");    
    $zstt=UX("update coode_datainstall SET STATUS=(length(replace(datasql,'∨','@:@'))-length(replace(datasql,'∨','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),PRIME= (length(replace(datajson,'Ｖ','@:@'))-length(replace(datajson,'Ｖ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),VRT=(length(replace(datajson,'Ｔ','@:@'))-length(replace(datajson,'Ｔ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))+1)");
   }
  };
  
$kx=UX("delete from coode_datainstall where srcid='".$sysid."_apps'");//houmian后面d后面的duociyuiju后面的多此一举 
  $trst=SX("select createsql,keynames,keytpnms,jsontpnms,jsonconts,tabtitle,srckey,srcttk,contentkeys from coode_tablist where schm='".$dbase."' and TABLE_NAME='coode_appdefault'");
  $srck=anyvalue($trst,"srckey",0);
  $srctk=anyvalue($trst,"srcttk",0);
  $olrst=SX("select OLMK from coode_appdefault where sysid='".$sysid."'");
  $olrst=hou($olrst,"#/#");
  $olrst=str_replace("#-#",",",$olrst);
  $olrst=str_replace("#/#",",",$olrst);
  $kx=UX("delete from coode_datainstall where ',,".$olrst.",' like concat('%,',tabolmk,',%') and tabname='coode_appdefault'");  
  if ($srck==""){
    $srck="VRT";
  }
  if ($srctk==""){
    $srctk="STCODE";
  }  
  $crts=anyvalue($trst,"createsql",0);
  $knms=anyvalue($trst,"keynames",0);
  $ktps=anyvalue($trst,"keytpnms",0);
  $ckeys=anyvalue($trst,"contentkeys",0);  
  $ktps=str_replace("↓","'",$ktps);
  $ktps=str_replace("↑","\\"."'",$ktps);
  $jstp=anyvalue($trst,"jsontpnms",0);    
  $jstp=str_replace("↓","'",$jstp);
  $jstp=str_replace("∵","\":\"",$jstp);  
  $jscons=anyvalue($trst,"jsonconts",0);  
  $jscons=str_replace("↓","'",$jscons);
  $jscons=str_replace("∵","\":\"",$jscons);  
  if ($knms!="" and $ktps!="" and $jstp!=""  ){
    $z=UX("insert into coode_datainstall(schm,srcid,tabname,tabsno,tabolmk,conjson,datajson,datasql,crttab,tabkeys,CRTM,UPTM,CRTOR,itemcrtm,itemuptm,itemcrtor,itemsrcid,itemsrcval,itemsrctt,itemsrctval,itemptof,conkeys)select '".$dbase."','".$sysid."_apps','coode_appdefault',SNO,OLMK,concat('{',".$jscons.",'}'),concat('{',".$jstp.",'}'),concat('(',".$ktps.",')'),'".$crts."','".$knms."',now(),now(),'".$_COOKIE["uid"]."',CRTM,UPTM,CRTOR,'".$srck."',".$srck.",'".$srctk."',".$srctk.",PTOF,'".$ckeys."' from coode_appdefault where sysid='".$sysid."'");                   
    $zzy=UX("update coode_datainstall set conjson=concat('〖',mid(conjson,3,length(conjson)-4),'〗') where mid(conjson,1,2)='{\"'");
    $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\":\"','Ｔ')");
    $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\",\"','Ｖ')");        
    $zzy=UX("update coode_datainstall set datajson=concat('〖',mid(datajson,3,length(datajson)-4),'〗') where mid(datajson,1,2)='{\"'");
    $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\":\"','Ｔ')");
    $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\",\"','Ｖ')");        
    $zzz=UX("update coode_datainstall set datasql=concat('〖',mid(datasql,3,length(datasql)-4),'〗') where mid(datasql,1,2)='(\''");
    $zzz=UX("update coode_datainstall set datasql=replace(datasql,'\',\'','∨')");    
    $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\"}〗','〗')");        
    $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\"}〗','〗')");        
    $zzz=UX("update coode_datainstall set datasql=replace(datasql,'∨\')〗','∨〗')");    
    $zzx=UX("update coode_datainstall set conmd5=md5(conjson),datamd5=md5(datasql),crtmd5=md5(crttab),keymd5=md5(frmsql),mymd5=md5(concat(tabname,tabolmk,datajson,datasql,crttab,frmsql,tabkeys))");    
    $zkx=UX("update coode_datainstall set frmsql=concat('insert into ',tabname,'(',tabkeys,')values([DATA])')");    
    $zstt=UX("update coode_datainstall SET STATUS=(length(replace(datasql,'∨','@:@'))-length(replace(datasql,'∨','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),PRIME= (length(replace(datajson,'Ｖ','@:@'))-length(replace(datajson,'Ｖ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),VRT=(length(replace(datajson,'Ｔ','@:@'))-length(replace(datajson,'Ｔ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))+1)");
  }
  
$kx=UX("delete from coode_datainstall where srcid='".$sysid."_sys'");//houmian后面d后面的duociyuiju后面的多此一举 
  $trst=SX("select createsql,keynames,keytpnms,jsontpnms,jsonconts,tabtitle,srckey,srcttk,contentkeys from coode_tablist where schm='".$dbase."' and TABLE_NAME='coode_sysinformation'");
  $srck=anyvalue($trst,"srckey",0);
  $srctk=anyvalue($trst,"srcttk",0);
  $olrst=SX("select OLMK from coode_sysinformation where sysid='".$sysid."'");
  $olrst=hou($olrst,"#/#");
  $olrst=str_replace("#-#",",",$olrst);
  $olrst=str_replace("#/#",",",$olrst);
  $kx=UX("delete from coode_datainstall where ',,".$olrst.",' like concat('%,',tabolmk,',%') and tabname='coode_sysinformation'");  
  if ($srck==""){
    $srck="VRT";
  }
  if ($srctk==""){
    $srctk="STCODE";
  }  
  $crts=anyvalue($trst,"createsql",0);
  $knms=anyvalue($trst,"keynames",0);
  $ktps=anyvalue($trst,"keytpnms",0);
  $ckeys=anyvalue($trst,"contentkeys",0);  
  $ktps=str_replace("↓","'",$ktps);
  $ktps=str_replace("↑","\\"."'",$ktps);
  $jstp=anyvalue($trst,"jsontpnms",0);    
  $jstp=str_replace("↓","'",$jstp);
  $jstp=str_replace("∵","\":\"",$jstp);  
  $jscons=anyvalue($trst,"jsonconts",0);  
  $jscons=str_replace("↓","'",$jscons);
  $jscons=str_replace("∵","\":\"",$jscons);  
  if ($knms!="" and $ktps!="" and $jstp!=""  ){
    $z=UX("insert into coode_datainstall(schm,srcid,tabname,tabsno,tabolmk,conjson,datajson,datasql,crttab,tabkeys,CRTM,UPTM,CRTOR,itemcrtm,itemuptm,itemcrtor,itemsrcid,itemsrcval,itemsrctt,itemsrctval,itemptof,conkeys)select '".$dbase."','".$sysid."_sys','coode_sysinformation',SNO,OLMK,concat('{',".$jscons.",'}'),concat('{',".$jstp.",'}'),concat('(',".$ktps.",')'),'".$crts."','".$knms."',now(),now(),'".$_COOKIE["uid"]."',CRTM,UPTM,CRTOR,'".$srck."',".$srck.",'".$srctk."',".$srctk.",PTOF,'".$ckeys."' from coode_sysinformation where sysid='".$sysid."'");                   
    $zzy=UX("update coode_datainstall set conjson=concat('〖',mid(conjson,3,length(conjson)-4),'〗') where mid(conjson,1,2)='{\"'");
    $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\":\"','Ｔ')");
    $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\",\"','Ｖ')");        
    $zzy=UX("update coode_datainstall set datajson=concat('〖',mid(datajson,3,length(datajson)-4),'〗') where mid(datajson,1,2)='{\"'");
    $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\":\"','Ｔ')");
    $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\",\"','Ｖ')");        
    $zzz=UX("update coode_datainstall set datasql=concat('〖',mid(datasql,3,length(datasql)-4),'〗') where mid(datasql,1,2)='(\''");
    $zzz=UX("update coode_datainstall set datasql=replace(datasql,'\',\'','∨')");    
    $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\"}〗','〗')");        
    $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\"}〗','〗')");        
    $zzz=UX("update coode_datainstall set datasql=replace(datasql,'∨\')〗','∨〗')");    
    $zzx=UX("update coode_datainstall set conmd5=md5(conjson),datamd5=md5(datasql),crtmd5=md5(crttab),keymd5=md5(frmsql),mymd5=md5(concat(tabname,tabolmk,datajson,datasql,crttab,frmsql,tabkeys))");    
    $zkx=UX("update coode_datainstall set frmsql=concat('insert into ',tabname,'(',tabkeys,')values([DATA])')");    
    $zstt=UX("update coode_datainstall SET STATUS=(length(replace(datasql,'∨','@:@'))-length(replace(datasql,'∨','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),PRIME= (length(replace(datajson,'Ｖ','@:@'))-length(replace(datajson,'Ｖ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),VRT=(length(replace(datajson,'Ｔ','@:@'))-length(replace(datajson,'Ｔ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))+1)");
  }
  $kx=UX("delete from coode_datainstall where srcid='".$sysid."_marks'");//houmian后面d后面的duociyuiju后面的多此一举 
  $trst=SX("select createsql,keynames,keytpnms,jsontpnms,jsonconts,tabtitle,srckey,srcttk,contentkeys from coode_tablist where schm='".$dbase."' and TABLE_NAME='coode_tiny'");
  $srck=anyvalue($trst,"srckey",0);
  $srctk=anyvalue($trst,"srcttk",0);
  $olrst=SX("select OLMK from coode_tiny where sysid='".$sysid."'");
  $olrst=hou($olrst,"#/#");
  $olrst=str_replace("#-#",",",$olrst);
  $olrst=str_replace("#/#",",",$olrst);
  $kx=UX("delete from coode_datainstall where ',,".$olrst.",' like concat('%,',tabolmk,',%') and tabname='coode_tiny'");  
  if ($srck==""){
    $srck="VRT";
  }
  if ($srctk==""){
    $srctk="STCODE";
  }  
  $crts=anyvalue($trst,"createsql",0);
  $knms=anyvalue($trst,"keynames",0);
  $ktps=anyvalue($trst,"keytpnms",0);
  $ckeys=anyvalue($trst,"contentkeys",0);  
  $ktps=str_replace("↓","'",$ktps);
  $ktps=str_replace("↑","\\"."'",$ktps);
  $jstp=anyvalue($trst,"jsontpnms",0);    
  $jstp=str_replace("↓","'",$jstp);
  $jstp=str_replace("∵","\":\"",$jstp);  
  $jscons=anyvalue($trst,"jsonconts",0);  
  $jscons=str_replace("↓","'",$jscons);
  $jscons=str_replace("∵","\":\"",$jscons);  
  if ($knms!="" and $ktps!="" and $jstp!=""  ){
    $z=UX("insert into coode_datainstall(schm,srcid,tabname,tabsno,tabolmk,conjson,datajson,datasql,crttab,tabkeys,CRTM,UPTM,CRTOR,itemcrtm,itemuptm,itemcrtor,itemsrcid,itemsrcval,itemsrctt,itemsrctval,itemptof,conkeys)select '".$dbase."','".$sysid."_tiny','coode_tiny',SNO,OLMK,concat('{',".$jscons.",'}'),concat('{',".$jstp.",'}'),concat('(',".$ktps.",')'),'".$crts."','".$knms."',now(),now(),'".$_COOKIE["uid"]."',CRTM,UPTM,CRTOR,'".$srck."',".$srck.",'".$srctk."',".$srctk.",PTOF,'".$ckeys."' from coode_tiny where sysid='".$sysid."'");                   
    $zzy=UX("update coode_datainstall set conjson=concat('〖',mid(conjson,3,length(conjson)-4),'〗') where mid(conjson,1,2)='{\"'");
    $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\":\"','Ｔ')");
    $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\",\"','Ｖ')");        
    $zzy=UX("update coode_datainstall set datajson=concat('〖',mid(datajson,3,length(datajson)-4),'〗') where mid(datajson,1,2)='{\"'");
    $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\":\"','Ｔ')");
    $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\",\"','Ｖ')");        
    $zzz=UX("update coode_datainstall set datasql=concat('〖',mid(datasql,3,length(datasql)-4),'〗') where mid(datasql,1,2)='(\''");
    $zzz=UX("update coode_datainstall set datasql=replace(datasql,'\',\'','∨')");    
    $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\"}〗','〗')");        
    $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\"}〗','〗')");        
    $zzz=UX("update coode_datainstall set datasql=replace(datasql,'∨\')〗','∨〗')");    
    $zzx=UX("update coode_datainstall set conmd5=md5(conjson),datamd5=md5(datasql),crtmd5=md5(crttab),keymd5=md5(frmsql),mymd5=md5(concat(tabname,tabolmk,datajson,datasql,crttab,frmsql,tabkeys))");    
    $zkx=UX("update coode_datainstall set frmsql=concat('insert into ',tabname,'(',tabkeys,')values([DATA])')");    
    $zstt=UX("update coode_datainstall SET STATUS=(length(replace(datasql,'∨','@:@'))-length(replace(datasql,'∨','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),PRIME= (length(replace(datajson,'Ｖ','@:@'))-length(replace(datajson,'Ｖ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),VRT=(length(replace(datajson,'Ｔ','@:@'))-length(replace(datajson,'Ｔ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))+1)");
  }
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>