<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $fid=dftval($_GET["funid"],"");
$keys=dftval($_GET["keys"],"");
$fmvalue="";
$tempval="";
if ($keys!=""){
 if (strpos($keys,",")>0){
   $ptkey=explode(",",$keys);
   for ($jj=0;$jj<count($ptkey);$jj++){
     $fmvalue=$fmvalue.'"'.$_POST[$ptkey[$jj]].'",';
   }
   $fmvalue=killlaststr($fmvalue);
   eval('$tempval='.$fid.'('.$fmvalue.');');
 }else{
   eval('$tempval='.$fid.'("'.$_POST[$keys].'");');
 }
}else{
  eval('$tempval='.$fid.'();');
}
echo $tempval;
     session_write_close();
?>