<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     class Sample {
    const API_KEY = "pYQLKlcXi2GDrhgCYUEf0VBn";
    const SECRET_KEY = "DHmiOx3iCvOcKA997rXMHb6hlw4R16yB";
    public function run($arrwords=Array(),$acode) {
        $item='{"role":"[role]","content":"[content]"},';
        $wdata="";
        for ($w=0;$w<count($arrwords);$w++){
         $itemx=$item;
         $prole=qian($arrwords[$w],":");
         $pctt=hou($arrwords[$w],":");
         if ($prole=="user" or $prole=="assistant"){
         }else{
           $prole="user";
         }
         $itemx=str_replace("[role]",$prole,$itemx);
         $itemx=str_replace("[content]",$pctt,$itemx);
         $wdata=$wdata.$itemx;
        }
        $wdata=killlaststr($wdata);
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/completions?access_token={$this->getAccessToken($acode)}",
            CURLOPT_TIMEOUT => 30,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER  => false,
            CURLOPT_SSL_VERIFYHOST  => false,
            CURLOPT_CUSTOMREQUEST => 'POST',
            
            CURLOPT_POSTFIELDS => '{"messages":['.$wdata.']}',
    
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }
    
    /**
     * 使用 AK，SK 生成鉴权签名（Access Token）
     * @return string 鉴权签名信息（Access Token）
     */
    private function getAccessToken($acode){
        $curl = curl_init();
        if ($acode==""){
          $postData = array(
            'grant_type' => 'client_credentials',
            'client_id' => self::API_KEY,
            'client_secret' => self::SECRET_KEY
          );
        }else{
         $arst=SX("select apikey,apival from coode_apipool where apicode='".$acode."'");
         $ak=anyvalue($arst,"apikey",0);
         $av=anyvalue($arst,"apival",0);
          $postData = array(
            'grant_type' => 'client_credentials',
            'client_id' => $ak,
            'client_secret' => $av
          );
        }
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://aip.baidubce.com/oauth/2.0/token',
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_SSL_VERIFYPEER  => false,
            CURLOPT_SSL_VERIFYHOST  => false,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => http_build_query($postData)
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $rtn = json_decode($response);
        return $rtn->access_token;
    }
}
$tot=_get("tot");
$pgss=_get("pgss");
$acode=_get("acode");
$fmtxt="";
if (intval($tot)>0){
 $wordarr=Array();
 for ($ii=0;$ii<intval($tot);$ii++){
   $wordarr[$ii]=_post("askstr".$ii);
   $fmtxt=$fmtxt._post("askstr".$ii);
 }
 $rtn = (new Sample())->run($wordarr,$acode);
 if ($acode!=""){
  $arst=SX("select apikey,apival from coode_apipool where apicode='".$acode."'");
  $ak=anyvalue($arst,"apikey",0);
  $av=anyvalue($arst,"apival",0);
 }else{
  $ak='pYQLKlcXi2GDrhgCYUEf0VBn';
  $av='DHmiOx3iCvOcKA997rXMHb6hlw4R16yB';
 }
 $au='https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/completions?access_token=';
 $sqlx="pagess,askurl,modelx,apikey,apival,askstr,backjson,result,asktime,CRTM,UPTM,OLMK";
 $rtn=str_replace(huanhang(),";",$rtn);
 $rtn=str_replace("\r",";",$rtn);
 $rtn=str_replace("\n",";",$rtn);
 $rtndata=json_decode($rtn,false);
 $rstx=$rtndata->result;
 $rid=$rtndata->id;
 $objx=$rtndata->object;
 $rstx=str_replace(huanhang(),";",$rstx);
 $rstx=str_replace("\r",";",$rstx);
 $rstx=str_replace("\n",";",$rstx);
 $sqly="'$pgss','$au','ebot','$ak','$av','$fmtxt','$rtn','$rstx',now(),now(),now(),'".onlymark()."'";
 $zz=UZ("insert into bdairequest".date("Ym")."(".$sqlx.")values(".$sqly.")");
 echo '{"id":"'.$rid.'","object":"'.$objx.'","result":"'.$rstx.'"}';
}else{
 echo '{"id":"0","object":"coodehost","result":"参数不全"}';
}
     session_write_close();
?>