<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $accessKey = 'd1f75dcf32f945928ff9fe41395b6a25';
$imgendpoint = 'https://api.bing.microsoft.com/v7.0/images/search';
$endpoint = 'https://api.bing.microsoft.com/v7.0/search';
$query = $_GET["askstr"];
$headers = "Ocp-Apim-Subscription-Key: $accessKey\r\n";
$options = array ('http' => array (
    'header' => $headers,
    'method' => 'GET'));
$url = $endpoint . "?q=" . urlencode($query);
$context = stream_context_create($options);
$result = file_get_contents($url, false, $context);
echo $result;
     session_write_close();
?>