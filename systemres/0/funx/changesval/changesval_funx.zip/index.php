<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $stid=_get("stid");
$vkey=_get("vkey");
$vval=_get("vval");
$dyrst=SX("select SNO,COLUMN_NAME,TABLE_NAME from coode_keydetaily where shortid='".$stid."' and '".$vkey."' like concat('%',COLUMN_NAME,'%')");
$totdy=countresult($dyrst);
if (intval($totdy)==1){
  $colnm=anyvalue($dyrst,"COLUMN_NAME",0);
  $tabnm=anyvalue($dyrst,"TABLE_NAME",0);
  $dsno=str_replace("p_".$colnm,"",$vkey);
  $zz=UX("update ".$tabnm." set ".$colnm."='".$vval."' where SNO=".$dsno);
  echo makereturnjson("1","修改成功","");
}else{
 echo makereturnjson("0","修改失败","");
}
     session_write_close();
?>