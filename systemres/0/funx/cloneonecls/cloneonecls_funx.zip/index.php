<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $markx=$_GET["markx"];
$nex=getRandChar(6);
$sox=UX("select layoutid,markname from coode_grouplist where plotmark='".$markx."'");
$oldx=anyvalue($sox,"layoutid",0);
$mknm=anyvalue($sox,"markname",0);
if ($oldx==""){
   $extt=UX("select count(*) as result from coode_shortdata where shortid='".$nex."'");
  if (intval($extt)==0){
    $kx="allkeys,tablename,showkeys,VRT,PTOF,CRTOR,STATUS,STCODE,PRIME,RIP";
    $z=UX("insert into coode_shortdata(".$kx.",shortid,shorttitle,OLMK,cdt,CRTM,UPTM,dttp)select ".$kx.",'".$nex."','".$markx.$mknm."的一级分类','".onlymark()."',' clsmark=\'".$markx."\'',now(),now(),'clstxt' from coode_shortdata where shortid='onecls'");
    $b=UX("update coode_grouplist set layoutid='".$nex."' where plotmark='".$markx."'");
  }  
}else{
 
}
     session_write_close();
?>