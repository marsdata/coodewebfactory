<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       eval(RESFUNSET("dspbasecoprt"));
  $datapath=dftval($_GET["datapath"],"");
  $filepath=dftval($_GET["filepath"],"");
   if ($filepath!=""){
    $allowtypes=_post("allowtypes");
    $onlyof=_post("onlyof");
    $namex="file";
    //$datapath="TAB:dbmk@tabnm/resid_SNO:30.savekey";  AV  SETV 用这个方法快速查看
    //$datapath="DS:dtmk@30.savekey";
    $tmpnm=$_FILES[$namex]["tmp_name"];
    $fnm=$_FILES[$namex]["name"];   
    $tmptp=$_FILES[$namex]["type"];
    $tmperr=$_FILES[$namex]["error"];
    $savepath=combineurl(localroot(),$filepath);
    $yy=createdir($savepath); 
    $rpt=combineurl(localroot(),$savepath);  
    $fnmx=$fnm;   
    $tmpnmx=$tmpnm;
    $fextx=hou($fnm,".");
    $tmptpx=$tmptp;
    $tmperrx=$tmperr;        
    $fpn=combineurl($savepath,$fnmx);
    $fileurl=combineurl($filepath,$fnmx);
      if ($datapath!="" and $onlyof=="1"){
       $nnn=SPV($datapath,$fileurl);
      }      
    $hosturl=combineurl(combineurl("http://".glw(),$filepath),$fnmx);
    move_uploaded_file($tmpnmx, $fpn);        
    $filearr=Array();
    $filrarr=get_file_list($savepath);
    $totf=count($filearr);
    $allowtypex="x//".$allowtypes;
    $fmlist="";
    for ($ff=0;$ff<$totf;$ff++){
      $kzm=hou($filearr[$ff],".");
      if (strpos($allowtypex,$kzm)>0){
         $fmlist=$fmlist.combineurl($filepath,$filearr[$ff]).",";
      }      
    }
    $fmlist=killlaststr($fmlist);
    if ($datapath!="" and $onlyof!="1"){
     $nnn=SPV($datapath,$fmlist);
    }
    echo '{"status":"1","msg":"上传文件成功","fileurl":"'.$fileurl.'","redirect":""}';
  }else{
    echo '{"status":"0","msg":"上传文件失败-参数不全","fileurl":"'.$fileurl.'","redirect":""}';
  }
 
       session_write_close();
?>