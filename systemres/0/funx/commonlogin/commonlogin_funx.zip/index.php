<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $uid=dftval($_GET["uid"],"");
$pass=dftval($_GET["pass"],"");
$sysid=dftval($_GET["sysid"],gln());
  $extx=UX("select count(*) as result from coode_userlist where userid='".$uid."' and passwd='".$pass."'");  
  if (intval($extx)>=1){
       $urst=SX("select userid,wrdid,roleids,depart from coode_userlist where userid='".$uid."' and passwd='".$pass."'");       
        setcookie("uid",$uid,time()+3600,"/");        
        
        setcookie("depart",anyvalue($urst,"depart",0),time()+3600,"/");        
        setcookie("roleids",anyvalue($urst,"roleids",0),time()+3600,"/");            
        setcookie("deadline",time()+3600,time()+3600,"/");
        $stoken=md5(anyvalue($urst,"userid",0).$sysid.time());
        setcookie("stoken",$stoken,time()+3600,"/");        
        $rname=anyvalue($urst,"realname",0);
        if ($rname==""){
          $rname=getRandChar(6);
        }
        $comid=anyvalue($urst,"wrdid",0);
        setcookie("cid",$comid,time()+3600,"/");
        $depart=anyvalue($urst,"depart",0);
        $dpmore=anyvalue($urst,"dpmore",0);
        $posids=anyvalue($urst,"posids",0);        
        $sqla="userid,realname,wrdid,sysid,depart,dpmore,posids,stoken,deadline,logintime,loginarea,fromdomain,CRTM,UPTM,OLMK,CRTOR";
        $sqlb="'".$uid."','".$rname."','".$comid."','".$sysid."','".$depart."','".$dpmore."','".$posids."','".$stoken."',date_add(now(), interval 30 minute),now(),'','',now(),now(),'".onlymark()."','".$uidx."'";
        $c=UX("insert into coode_loginstoken(".$sqla.")values(".$sqlb.")");
        $runstt="1";
        $runmsg="验证成功";
      echo makereturnjson("1","成功","/localxres/funx/anysys/?sysid=".$sysid.".1");
  }else{
      echo makereturnjson("0","失败","");
  }
       session_write_close();
?>