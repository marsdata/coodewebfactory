<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $uid=dftval($_GET["uid"],"");
$pass=dftval($_GET["pass"],"");
 $extu=UX("select count(*) as result from coode_userlist where userid='".$uid."' and passwd='".$pass."'");
  if (intval($extu)==0){
   $sqlx="wrdid,userid,passwd,CRTM,UPTM,CRTOR,OLMK,PRIME";
   $sqly="'','".$uid."','".$pass."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."',0";
   $zz=UX("insert into coode_userlist(".$sqlx.")values(".$sqly.")");
   echo makereturnjson("1","创建系统用户成功","");
  }else{
   echo makereturnjson("0","失败，已存在","");
  }
     session_write_close();
?>