<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $topx=SX("select ftitle,furl,sysid,tinymark from coode_visitcount where sysid='coode' and vclient='".$_COOKIE["uid"]."' order by pcount desc limit 0,7");
$totx=countresult($topx);
if ($totx>=7){
 $z=UX("update coode_plotmydetail set myurl='".anyvalue($topx,"furl",0)."',mytitle='".anyvalue($topx,"ftitle",0)."' where mymark='often1' and plotmark='coodemmenu' and CRTOR='".$_COOKIE["uid"]."'");
 $z=UX("update coode_plotmydetail set myurl='".anyvalue($topx,"furl",1)."',mytitle='".anyvalue($topx,"ftitle",1)."' where mymark='often2' and plotmark='coodemmenu' and CRTOR='".$_COOKIE["uid"]."'");
 $z=UX("update coode_plotmydetail set myurl='".anyvalue($topx,"furl",2)."',mytitle='".anyvalue($topx,"ftitle",2)."' where mymark='often3' and plotmark='coodemmenu' and CRTOR='".$_COOKIE["uid"]."'");
 $z=UX("update coode_plotmydetail set myurl='".anyvalue($topx,"furl",3)."',mytitle='".anyvalue($topx,"ftitle",3)."' where mymark='often4' and plotmark='coodemmenu' and CRTOR='".$_COOKIE["uid"]."'");
 $z=UX("update coode_plotmydetail set myurl='".anyvalue($topx,"furl",4)."',mytitle='".anyvalue($topx,"ftitle",4)."' where mymark='often5' and plotmark='coodemmenu' and CRTOR='".$_COOKIE["uid"]."'");
 $z=UX("update coode_plotmydetail set myurl='".anyvalue($topx,"furl",5)."',mytitle='".anyvalue($topx,"ftitle",5)."' where mymark='often6' and plotmark='coodemmenu' and CRTOR='".$_COOKIE["uid"]."'");
 $z=UX("update coode_plotmydetail set myurl='".anyvalue($topx,"furl",6)."',mytitle='".anyvalue($topx,"ftitle",6)."' where mymark='often7' and plotmark='coodemmenu' and CRTOR='".$_COOKIE["uid"]."'");
};
$nearx=SX("select pgtitle,furl,sysid,tinymark from coode_visitblog where sysid='coode' and clientid='".$_COOKIE["uid"]."'  group by tinymark  order by CRTM desc limit 0,7");
$totn=countresult($nearx);
if ($totn>=7){
 $z=UX("update coode_plotmydetail set myurl='".anyvalue($nearx,"furl",0)."',mytitle='".anyvalue($nearx,"pgtitle",0)."' where mymark='near1' and plotmark='coodemmenu' and CRTOR='".$_COOKIE["uid"]."'");
 
 $z=UX("update coode_plotmydetail set myurl='".anyvalue($nearx,"furl",1)."',mytitle='".anyvalue($nearx,"pgtitle",1)."' where mymark='near2' and plotmark='coodemmenu' and CRTOR='".$_COOKIE["uid"]."'");
 $z=UX("update coode_plotmydetail set myurl='".anyvalue($nearx,"furl",2)."',mytitle='".anyvalue($nearx,"pgtitle",2)."' where mymark='near3' and plotmark='coodemmenu' and CRTOR='".$_COOKIE["uid"]."'");
 $z=UX("update coode_plotmydetail set myurl='".anyvalue($nearx,"furl",3)."',mytitle='".anyvalue($nearx,"pgtitle",3)."' where mymark='near4' and plotmark='coodemmenu' and CRTOR='".$_COOKIE["uid"]."'");
 $z=UX("update coode_plotmydetail set myurl='".anyvalue($nearx,"furl",4)."',mytitle='".anyvalue($nearx,"pgtitle",4)."' where mymark='near5' and plotmark='coodemmenu' and CRTOR='".$_COOKIE["uid"]."'");
 $z=UX("update coode_plotmydetail set myurl='".anyvalue($nearx,"furl",5)."',mytitle='".anyvalue($nearx,"pgtitle",5)."' where mymark='near6' and plotmark='coodemmenu' and CRTOR='".$_COOKIE["uid"]."'");
 $z=UX("update coode_plotmydetail set myurl='".anyvalue($nearx,"furl",6)."',mytitle='".anyvalue($nearx,"pgtitle",6)."' where mymark='near7' and plotmark='coodemmenu' and CRTOR='".$_COOKIE["uid"]."'"); 
};
echo "1";
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>