<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $ptype=dftval($_GET["ptype"],"");
$stid=dftval($_GET["stid"],"");
$mtd="";
$zxz=eval(RESFUNSET("formbase"));
$zxz=eval(RESFUNSET("accoprt"));
$zxz=eval(RESFUNSET("tabbaseinfo"));
$zxz=eval(RESFUNSET("quickvalue"));
$zxz=eval(RESFUNSET("keyfunbase"));
$zxz=eval(RESFUNSET("basedataoprt"));
$dbmk=dftval($_GET["dbmk"],"");
if ($dbmk==""){  
  $tabnm=UX("select tablename as result from coode_shortdata where shortid='".$stid."'");       
  $dinfo=array();
  $dinfo=getdbinfo("",$tabnm,$dinfo);
  $pssno=$dinfo["pssno"];
  switch($ptype){
    case "new":      
       if ($tabnm!=""){
         $sno=dftval($_GET["SNO"],"0");
         eval(CLASSX("verifystring"));
         $vs=new verifystring();
         $ed=array();
         $idata=array();
         $idata=makeidata($stid,$idata,$sno);         
         $ak=getarrkeys($idata);
         $at=stktott($stid,$ak);
         $af=getkvf($stid,$ak);
         $ed=$vs->arrverfy($ak,$at,$af,$idata,$ed);         
        if (intval($ed["errstt"])==0){
           $olmkz=dftval($_POST["p_".$dinfo["psolmk"].$sno],$_POST["p_".$dinfo["psolmk"]]);           
           if (existitem($tabnm,$olmkz,$dinfo["psolmk"])){            
              $istt=makeupdate($tabnm,$idata,$olmkz,$dinfo["psolmk"]);
            $mtd="makeupdate";
           }else{            
             $istt=makeinsert($tabnm,$idata,$dinfo["psolmk"]);
            $mtd="makeinsert";
           }
           if ($istt){
            echo '{"status":"1","msg":"提交成功-'.$mtd.'","redirect":"'.makeredirect($stid.".new","").'"}';
           }else{
            echo '{"status":"0","msg":"提交信息失败,未发现信息:'.$mtd.'","redirect":""}';
           }
        }else{
            echo '{"status":"0","msg":"验证信息失败('.$ed["errstt"].'):'.$ed["allerr"].'","redirect":""}';
        }
       }else{
         echo '{"status":"0","msg":"参数不全","redirect":""}';
       }
    break;
    case "update":
       $sno=dftval($_POST["SNO"],$_POST[$pssno]);       
       if ($tabnm!=""){        
         if ($sno==""){
           $sno=dftval($_GET["SNO"],$_GET[$pssno]);
         }
         eval(CLASSX("verifystring"));
         $vs=new verifystring();
         $ed=array();
         $idata=array();
         $idata=makeidata($stid,$idata,$sno);         
         $ak=getarrkeys($idata);
         $at=stktott($stid,$ak);
         $af=getkvf($stid,$ak);
         $ed=$vs->arrverfy($ak,$at,$af,$idata,$ed);         
        if (intval($ed["errstt"])==0){
          if ($sno=="0"){
            $olmkz=dftval($_POST["p_".$dinfo["psolmk"].$sno],$_POST["p_".$dinfo["psolmk"]]);
            if (existitem($tabnm,$olmkz,$dinfo["psolmk"])){
             $istt=makeupdate($tabnm,$idata,$olmkz,$dinfo["psolmk"]);             
             $mtd="makeupdate";
            }else{
             $istt=makeinsert($tabnm,$idata,$dinfo["psolmk"]);
             $mtd="makeinsert";
            }
          }else{          
            $istt=makerefresh($tabnm,$idata,$sno);
            $mtd="makerefresh";
          }
           if ($istt){
            echo '{"status":"1","msg":"提交成功-'.$mtd.'","redirect":"'.makeredirect($stid.".update","").'"}';
           }else{
            echo '{"status":"0","msg":"提交信息失败(未发现信息):'.$mtd.'","redirect":""}';
           }
        }else{
            echo '{"status":"0","msg":"验证信息失败:'.$ed["allerr"].'","redirect":""}';
        }
       }else{
         echo '{"status":"0","msg":"参数不全","redirect":""}';
       }
    break;
    case "del":
    
     $tabnm=UX("select tablename as result from coode_shortdata where shortid='".$stid."'");
     if ($tabnm!=""){
       $SNO=dftval($_POST["SNO"],$_POST[$pssno]);
       if ($SNO==""){
         $SNO=dftval($_GET["SNO"],$_GET[$pssno]);
       }
       $snos=dftval($_POST["snos"],$_POST[$pssno."s"]);
       if ($snos==""){
         $snos=dftval($_GET["snos"],$_GET[$pssno."s"]);
       }
       $ptsno=explode(",",$snos);
       $totpt=count($ptsno);
       $fmcdt="";
       for ($j=0;$j<$totpt;$j++){
         if ($ptsno[$j]!=""){
            $fmcdt=" or ".$dinfo["pssno"]."=".$ptid[$j];
         }
       }
      if ($SNO==""){
       if ($totpt>0){
        $fmcdt=substr($fmcdt,3,strlen($fmcdt)-3);
        $updstrx="delete from ".$tabnm." where ".$fmcdt;
        $ucdtx=$fmcdt;
        if (updask("","",$stid,$tabnm,"del",$updstrx,$ucdtx)==false){
          if (killsontab("","",$tabnm,$fmcdt)==false){
            $ainfo=array();
            $ainfo=getdbact(glb(),$tabnm,$ainfo);
           if ($ainfo["bfdel"]!=""){
            eval($ainfo["bfdel"]);            
           }
            $zx=UX($updstrx);
           if ($ainfo["aftdel"]!=""){
            eval($ainfo["aftdel"]);
           }
          }//killsontab                  
         }//updask
        echo '{"status":"1","msg":"批量删除成功","redirect":"'.makeredirect($stid.".moredel","").'"}';
       }else{
        echo '{"status":"0","msg":"未选择","redirect":""}';
       }
      }else{
        $updstrx="delete from ".$tabnm." where SNO=".$SNO;
        $ucdtx="SNO=".$SNO;
        $ki=dataeditacc("thishostcore",$tabnm,$SNO,$_COOKIE["uid"],$_COOKIE["rids"],"killitem");
        if ($ki){
  
          $ainfo=array();
          $ainfo=getdbact(glb(),$tabnm,$ainfo);
          $ext=1;
          if ($ainfo["bfdel"]!=""){
           eval($ainfo["bfdel"]);           
          }          
          if ($ext==0){
            echo '{"status":"0","msg":"无权删除-ext0","redirect":""}';
          }else{
            if (killsontab("","",$tabnm,"SNO=".$SNO)==false){
             $zx=UX($updstrx); 
             if ($ainfo["aftdel"]!=""){
              eval($ainfo["aftdel"]);              
             }
             echo '{"status":"1","msg":"单个删除成功'.'","redirect":"'.makeredirect($stid.".onedel","").'"}';
            }else{
             echo '{"status":"0","msg":"无权删除-ext0","redirect":""}';
            }//killson
          }         
         
        }else{
          echo '{"status":"0","msg":"无权删除","redirect":""}';
        }//ki       
       //echo '{"status":"1","msg":"单个删除成功-'.$kk(为BEFOREVIEW 里的KK=).'","redirect":"'.makeredirect($stid.".onedel","").'"}';
      }
     }else{
       echo '{"status":"0","msg":"参数不全","redirect":""}';
     }
     break;
     default:    
   }
}else{  
  $tabnm=UX("select tablename as result from coode_dbshort where shortid='".$stid."' and catalog='".$dbmk."'");
  $dinfo=array();
  $dinfo=takedbinfo($dbmk,$tabnm,$dinfo);
  $pssno=$dinfo["pssno"];
  $psolmk=$dinfo["psolmk"];
  switch($ptype){
    case "new":           
       if ($tabnm!=""){
         $sno=dftval($_GET[$pssno],"0");
         eval(CLASSX("verifystring"));
         $vs=new verifystring();
         $ed=array();
         $idata=array();
         $idata=makedbidata($stid,$idata,$pssno,$sno);
         $ak=getarrkeys($idata);
         $at=dbstktott($dbmk,$stid,$ak);
         $af=dbgetkvf($dbmk,$stid,$ak);
         $ed=$vs->arrverfy($ak,$at,$af,$idata,$ed);
        if (intval($ed["errstt"])==0){
            $istt=makedbinsert($dbmk,$tabnm,$idata,$psolmk);
            $mtd="makedbinsert";
            //echo $istt;
           if ($istt){
            echo '{"status":"1","msg":"提交成功'.$mtd.'","redirect":""}';
           }else{
            echo '{"status":"0","msg":"提交信息失败，未发现信息:'.$mtd.'","redirect":""}';
           }
        }else{
            echo '{"status":"0","msg":"验证信息失败:'.$ed["allerr"].'","redirect":""}';
        }
       }else{
         echo '{"status":"0","msg":"参数不全","redirect":""}';
       }
    break;
    case "update":
       if ($tabnm!=""){
         $sno=dftval($_POST["SNO"],$_POST[$pssno]);
         if ($sno=="" or $sno=="0"){
           $sno=dftval($_GET["SNO"],$_GET[$pssno]);
         }
         eval(CLASSX("verifystring"));
         $vs=new verifystring();
         $ed=array();
         $idata=array();
         $idata=makedbidata($dbmk,$stid,$idata,$pssno,$sno);
         $ak=getarrkeys($idata);
         $at=dbstktott($dbmk,$stid,$ak);
         $af=dbgetkvf($dbmk,$stid,$ak);
         $ed=$vs->arrverfy($ak,$at,$af,$idata,$ed);
        if (intval($ed["errstt"])==0){
           $istt=makedbrefresh($dbmk,$tabnm,$idata,$pssno,$sno);
           $mtd="makedbrefresh";
           if ($istt){
            echo '{"status":"1","msg":"提交成功-'.$mtd.'","redirect":""}';
           }else{
            echo '{"status":"0","msg":"提交信息失败，未发现信息:'.$mtd.'","redirect":""}';
           }
        }else{
            echo '{"status":"0","msg":"验证信息失败:'.$ed["allerr"].'","redirect":""}';
        }
       }else{
         echo '{"status":"0","msg":"参数不全","redirect":""}';
       }
    break;
    case "del":
    $tabnm=UX("select tablename as result from coode_dbshort where shortid='".$stid."'");
    if ($tabnm!=""){
       $SNO=dftval($_POST["SNO"],$_POST[$pssno]);
       if ($SNO==""){
         $SNO=dftval($_GET["SNO"],$_GET[$pssno]);
       }
       $snos=dftval($_POST["snos"],$_POST[$pssno."s"]);
       if ($snos==""){
         $snos=dftval($_GET["snos"],$_GET[$pssno."s"]);
       }
       $ptsno=explode(",",$snos);
       $totpt=count($ptsno);
       $fmcdt="";
       for ($j=0;$j<$totpt;$j++){
         if ($ptsno[$j]!=""){
            $fmcdt=" or ".$pssno."=".$ptid[$j];
         }
       }
      $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
      if ($SNO==""){
       if ($totpt>0){
        $fmcdt=substr($fmcdt,3,strlen($fmcdt)-3);        
        if (killsontab($dinfo["fip"],$dbmk,$tabnm,$fmcdt)==false){
          $ainfo=array();
          $ainfo=getdbact($dbmk,$tabnm,$ainfo);
          if ($ainfo["bfdel"]!=""){
           eval($ainfo["bfdel"]);
          }
          $zx=updatingx($conn,$dinfo["fbase"],"delete from ".$tabnm." where ".$fmcdt,"utf8");
          if ($ainfo["aftdel"]!=""){
           eval($ainfo["aftdel"]);
          }         
         }//ifkil
        echo '{"status":"1","msg":"远程删除成功","redirect":""}';
       }else{
        echo '{"status":"0","msg":"未选择要删除的远程序号","redirect":""}';
       }
      }else{
        if (killsontab($dinfo["fip"],$dbmk,$tabnm,$pssno."=".$SNO)==false){
          $ainfo=array();
          $ainfo=getdbact($dbmk,$tabnm,$ainfo);
          if ($ainfo["bfdel"]!=""){
           eval($ainfo["bfdel"]);
          }
          $zx=updatingx($conn,$dinfo["fbase"],"delete from ".$tabnm." where ".$pssno."=".$SNO,"utf8");
          
          if ($ainfo["aftdel"]!=""){
           eval($ainfo["aftdel"]);
          }         
        }
       echo '{"status":"1","msg":"远程删除成功","redirect":""}';
      }
     }else{
      echo '{"status":"0","msg":"远程删除参数不全","redirect":""}';
     }
     break;     
     default:    
   }
}
     session_write_close();
?>