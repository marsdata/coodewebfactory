<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
       $restype=_get("restype");
  $rescode=_get("rescode");
  switch($restype){
    case "formx":
     $sysid=UX("select sysid as result from coode_shortdata where shortid='".$rescode."'");
     $drst=SX("select sysid,shorttitle,tablename from coode_shortdata where shortid='".$rescode."'");
     $sysid=anyvalue($drst,"sysid",0);
     $shorttitle=anyvalue($drst,"shorttitle",0);
     $tablename=anyvalue($drst,"tablename",0);
     $tabrst=SX("select tabtitle,createsql from coode_tablist where TABLE_NAME='$tablename'");
     $tabtitle=anyvalue($tabrst,"tabtitle",0);
     $createsql=anyvalue($tabrst,"createsql",0);
     $tabmd5=md5($createsql);
     $kxrst=SX("select SNO,md5(concat(COLUMN_NAME,keytitle,COLUMN_DEFAULT,COLUMN_TYPE,classp,clstxt,valuezero,keyexplain,jsonshowfun,sysshowfun,jspostfun,syspostfun,changeable,displayed,dxtype,bfist,aftist,bfupd,aftupd,bfdel,aftdel,SQX,VQX)) as vmd5 from coode_keydetailx where TABLE_NAME='".$tablename."'");
     $totx=countresult($kxrst);
     $fmx="";
     for ($x=0;$x<$totx;$x++){
      $fmx=$fmx.anyvalue($kxrst,"vmd5",$x);
     }
     $formmd5=UX("select md5(concat(sysid,shorttitle,tablename,caseid,detailid,allkeys,showkeys,cdt,orddt,lang,dttp)) as result from coode_shortdata where shortid='".$rescode."'");
     $xmd5=md5($fmx);
     $kyrst=SX("select SNO,md5(concat(COLUMN_NAME,keytitle,COLUMN_DEFAULT,COLUMN_TYPE,classp,clstxt,valuezero,keyexplain,jsonshowfun,sysshowfun,jspostfun,syspostfun,changeable,displayed,dxtype,bfist,aftist,bfupd,aftupd,bfdel,aftdel,SQX,VQX)) as vmd5 from coode_keydetaily where shortid='".$rescode."'");
     $toty=countresult($kyrst);
     $fmy="";
     for ($y=0;$y<$toty;$y++){
      $fmy=$fmy.anyvalue($kyrst,"vmd5",$y);
     }
     $ymd5=md5($fmy);
    break;
    case "funx":
    $thismd5=UX("select md5(funfull) as result from coode_funlist where funname='".$rescode."' or funname='".$rescode."()'");
    break;
    case "plotx":
     $plmd5=UX("select md5(concat(layoutid,plotcls,sysid,appid,levelcount,totpoint,markname,defaultcss,formcode,clickfun)) as result from coode_plotlist where plotmark='".$rescode."'");   
     $kyrst=SX("select SNO,md5(concat(plotmark,level,myid,parid,oriid,mytitle,partitle,orititle,mymark,parmark,primark,myurl,myclick,fontname,mydescrib)) as vmd5 from coode_plotdetail where shortid='".$rescode."'");
     $toty=countresult($kyrst);
     $fmy="";
     for ($y=0;$y<$toty;$y++){
      $fmy=$fmy.anyvalue($kyrst,"vmd5",$y);
     }
     $ymd5=md5($fmy);
    break;
    default:
  }
  
    if ( $_SERVER['SERVER_PORT']=="443"){     
      $fromhost="https://".$_SERVER["HTTP_HOST"];
    }else if ($_SERVER['SERVER_PORT']=="80"){
      $fromhost="http://".$_SERVER["HTTP_HOST"];
    }else{
      $fromhost="http://".$_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"];
    }
    $pdata=Array();
    $pdata["a"]="";
    
    $mthost=anyfunrun("svshost",glm(),"hostid=".$sysid,"");
    if (strpos($mthost,":443")>0){
        $purl="https://".str_replace(":443","",$mthost)."/localxres/funx/askver/?restype=".$restype."&rescode=".$rescode;
    }else{
        $purl="http://".$mthost."/localxres/funx/askver/?restype=".$restype."&rescode=".$rescode;
    }    
    $bktxt=request_post($purl,$pdata);
    $bkdata=json_decode($bktxt,false);
    $bstt=$bkdata->status;
    
    
   switch($restype){
    case "formx":    
      $mxmd5=$bkdata->xmd5;
      $mymd5=$bkdata->ymd5;
      $mfmd5=$bkdata->formmd5;
      $mtmd5=$bkdata->tabmd5;
      if (($tabmd5==$mtmd5 and $formmd5==$mfmd5 and $mxmd5==$xmd5 and $mymd5==$ymd5) or $mthost==killlaststr(glw()) or intval($bstt)==-1){      
       echo makereturnjson("1","无需升级-资源全部一致","");
      }else{
       echo makereturnjson("0","需要升级-资源非全部一致","");
      }
    break;
    case "funx":
    $fmd5=$bkdata->fmd5;
     if ($fmd5==$thismd5){
       echo makereturnjson("1","无需升级-资源全部一致","");
     }else{
       echo makereturnjson("0","需要升级-资源非全部一致","");
     }
    break;
    case "plotx":
    $plotmd5=$bkdata->plotmd5;
    $dtlmd5=$bkdata->dtlmd5;
    if ($plmd5==$plotmd5 and $ymd5==$dtlmd5){
      echo makereturnjson("1","无需升级-资源全部一致","");
    }else{
       echo makereturnjson("0","需要升级-资源非全部一致","");
    }
    break;
    default:
  } 
     session_write_close();
?>