<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $fid=dftval($_GET["fid"],$_GET["dfmark"]);
$dfe=UX("select dfuneval as result from coode_datafun where dfunmark='".$fid."'");
$outtxt="";
if ($dfe!=""){
 eval(tostring($dfe));
 $zz=UX("update coode_datafun set UPTM=now(),CRTM=now(), resulttxt='".str_replace("\'","\\\'",$outtxt)."' where dfunmark='".$fid."'");
 $outdatapath=combineurl(localroot(),"/localxres/dfunx/".$fid."/data.json");
 $ofx=overfile($outdatapath,$outtxt);
 echo $outtxt; 
}
     session_write_close();
?>