<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     eval(RESFUNSET("divfrmfun"));
$instmark=dftval($_GET["instmark"],"");
$expx=dftval($_GET["expx"],"");
$expy=str_replace("=","@",$expx);
$expz=str_replace("@","=",$expx);
$frmmark=dftval($_GET["frmmark"],"");
$wx=dftval($_GET["bodyw"],"800");
$hx=dftval($_GET["bodyh"],"600");
//这是合成测试显示加颜色的页面
$cmbcode="";
$idxrst=SX("select insttitle,scripty,styley,jsfilex,cssfilex,pagesrd from coode_divfrmindex where instmark='".$instmark."' and mothersrd='".$expy."'");
$totidx=countresult($idxrst);
$fmjsf="";
$fmcssf="";
$fmscript="";
$fmstyle="";
if (intval($totidx)>0){
  $insttitle=anyvalue($idxrst,"insttitle",0);
  $scripty=tostring(anyvalue($idxrst,"scripty",0)).constval("toprightclick");
  $styley=tostring(anyvalue($idxrst,"styley",0));
  $jsfilex=tostring(anyvalue($idxrst,"jsfilex",0));
  $cssfilex=tostring(anyvalue($idxrst,"cssfilex",0));
  $pagesrd=tostring(anyvalue($idxrst,"pagesrd",0));
  $fmjsf=formjs(onlyone($jsfilex));
  $fmcssf=formcss(onlyone($cssfilex));
  if ($pagesrd==""){
   $pagesrd=constval("pagesrdcode");
  }
 $dsplno=array();
 $dsplno[0]="";
 $dsplno[1]="display:none;";
 $isdspl=0;
 $dcrst=SX("select myid,parid,frmmark,divcode,divstyle,STATUS from coode_divfrmeles where  instmark='".$instmark."' and mothersrd='".$expz."' and parid=-1");
 //$outx=combineurl(localroot(),"/localxres/test.txt");
 $totd=countresult($dcrst); 
  $myid=anyvalue($dcrst,"myid",0);
  $parid=anyvalue($dcrst,"parid",0);
  $divcode=tostring(anyvalue($dcrst,"divcode",0));
  $thisfmk=anyvalue($dcrst,"frmmark",0);
  $status=anyvalue($dcrst,"STATUS",0);
  $divstyle=anyvalue($dcrst,"divstyle",0);
  if ($thisfmk==$frmmark){
   $bstyle="background-color:royalblue;position:relative;z-index:99;".$divstyle;
   $thisstyle=makedivvalstyle($bstyle,$instmark,$expz,$thisfmk,intval($wx),intval($hx));
   $isdspl=1;
  }else{
   $bstyle="z-index:0;".$divstyle;
   $thisstyle=makedivvalstyle($bstyle,$instmark,$expz,$thisfmk,intval($wx),intval($hx));
  }
 //$fmtest="";
  $d1crst=SX("select myid,parid,frmmark,divcode,divstyle,STATUS from coode_divfrmeles where  instmark='".$instmark."' and mothersrd='".$expz."' and parid=".$myid); 
  $totd1=countresult($d1crst);
  $fmc1="";
  $colorj=array();
  $colorj[0]="#FFC1E0";
  $colorj[1]="#FF95CA";
  $colorj[2]="#FF60AF";
  $colorj[3]="#FF0080";
  $colorj[4]="#D9006C";
  $colork=array();
  $colork[0]="#E6CAFF";
  $colork[1]="#d3a4ff";
  $colork[2]="#BE77FF";
  $colork[3]="#9F35FF";
  $colork[4]="#8600FF";
  $colorl=array();
  $colorl[0]="#FFD2D2";
  $colorl[1]="#FF9797";
  $colorl[2]="#FF5151";
  $colorl[3]="#FF0000";
  $colorl[4]="#CE0000";
  for ($j1=0;$j1<$totd1;$j1++){
    $myid1=anyvalue($d1crst,"myid",$j1);
    $parid1=anyvalue($d1crst,"parid",$j1);
    $divcode1=tostring(anyvalue($d1crst,"divcode",$j1));
    $divstyle1=anyvalue($d1crst,"divstyle",$j1);
    $thisfmk1=anyvalue($d1crst,"frmmark",$j1);
    $status1=anyvalue($dcrst,"STATUS",0);
     if ($thisfmk1==$frmmark){
      $bstyle1="background-color:royalblue;position:relative;z-index:99;".$divstyle1;
      $thisstyle1=makedivnewstyle($bstyle1,$instmark,$expz,$thisfmk1);
      $isdspl=1;
     }else{      
      $bstyle1=$dsplno[$isdspl]."background-color:".$colorj[$j1].";position:relative;z-index:0;".$divstyle1;
      $thisstyle1=makedivnewstyle($bstyle1,$instmark,$expz,$thisfmk1);
     }
      $d2crst=SX("select myid,parid,frmmark,divcode,divstyle,STATUS from coode_divfrmeles where  instmark='".$instmark."' and mothersrd='".$expz."' and parid=".$myid1); 
      $totd2=countresult($d2crst);
      $fmc2="";
      for ($j2=0;$j2<$totd2;$j2++){
       $myid2=anyvalue($d2crst,"myid",$j2);
       $parid2=anyvalue($d2crst,"parid",$j2);
       $divcode2=tostring(anyvalue($d2crst,"divcode",$j2));
       $divstyle2=anyvalue($d2crst,"divstyle",$j2);
       $thisfmk2=anyvalue($d2crst,"frmmark",$j2);
       $status2=anyvalue($d2crst,"STATUS",$j2);
        if ($thisfmk2==$frmmark){
         $bstyle2="background-color:royalblue;position:relative;z-index:99;".$divstyle2;
         $thisstyle2=makedivnewstyle($bstyle2,$instmark,$expz,$thisfmk2);
         $isdspl=1;
        }else{
         $bstyle2=$dsplno[$isdspl]."background-color:".$colork[$j2].";position:relative;z-index:0;".$divstyle2;
         $thisstyle2=makedivnewstyle($bstyle2,$instmark,$expz,$thisfmk2);
        }
          $d3crst=SX("select myid,parid,frmmark,divcode,divstyle,STATUS from coode_divfrmeles where  instmark='".$instmark."' and mothersrd='".$expz."' and parid=".$myid2); 
          $totd3=countresult($d3crst);
          $fmc3="";
          for ($j3=0;$j3<$totd3;$j3++){
           $myid3=anyvalue($d3crst,"myid",$j3);
           $parid3=anyvalue($d3crst,"parid",$j3);
           $divcode3=tostring(anyvalue($d3crst,"divcode",$j3));
            
           $divstyle3=anyvalue($d3crst,"divstyle",$j3);
           $thisfmk3=anyvalue($d3crst,"frmmark",$j3);
           $status3=anyvalue($d3crst,"STATUS",$j3);
        
            if ($thisfmk3==$frmmark){
             $isdspl=1;
             $bstyle3="background-color:royalblue;position:relative;z-index:99;".$divstyle3;
             $thisstyle3=makedivnewstyle($bstyle3,$instmark,$expz,$thisfmk3);
            }else{
             $bstyle3=$dsplno[$isdspl]."background-color:".$colorl[$j3].";position:relative;z-index:0;".$divstyle3;
             $thisstyle3=makedivnewstyle($bstyle3,$instmark,$expz,$thisfmk3);
            }
           $divcode3=str_replace($instmark.$thisfmk3."hcode"," style=\"".$thisstyle3."\"",$divcode3);  
           $fmc3=$fmc3.$divcode3;          
          }
         $divcode2=str_replace($instmark.$thisfmk2."hcode"," style=\"".$thisstyle2."\"",$divcode2);  
         if (intval($status2)==0){
           $divcode2=str_replace($instmark.$thisfmk2."INNER",$fmc3,$divcode2);  
         }
         $fmc2=$fmc2.$divcode2;
      }
    $divcode1=str_replace($instmark.$thisfmk1."hcode"," style=\"".$thisstyle1."\"",$divcode1);  
    if (intval($status1)==0){
      $divcode1=str_replace($instmark.$thisfmk1."INNER",$fmc2,$divcode1);  
    }
    $fmc1=$fmc1.$divcode1;
  }
  $divcode=str_replace($instmark.$thisfmk."hcode"," style=\"".$thisstyle."\"",$divcode);
  $divcode=str_replace($instmark.$thisfmk."INNER",$fmc1,$divcode); 
//{!--shortJSFILES--}
//{!--shortCSSFILES--}
//{!--shortSTYLE--}
//{!--shortSCRIPT--}   
  //overfile($outx,$fmtest);
 $extcode=' {button id="floating-button"}查看属性{/button}
    {div id="property-box"}
      {h2}属性框{/h2}
      {p}这里是属性框的内容。{/p}
    {/div}';
  $pagesrd=turnlab($pagesrd);    
  $pagesrd=str_replace("<!--thistitle-->",$insttitle,$pagesrd);
  $pagesrd=str_replace("<!--thesecomCSSFILES-->",$fmcssf,$pagesrd);
  $pagesrd=str_replace("<!--thesecomJSFILES-->",$fmjsf,$pagesrd);
  $pagesrd=str_replace("<!--thiscomSTYLE-->",$styley,$pagesrd);
  $pagesrd=str_replace("<!--thiscomSCRIPT-->",$scripty,$pagesrd);
  $pagesrd=str_replace("<!--thiscomHTML-->",turnlab($divcode.$extcode),$pagesrd);
  echo $pagesrd;
}else{
  echo "No Code!";
}
     session_write_close();
?>