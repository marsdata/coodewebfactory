<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include mdir().'RNA/EARTH.php';
    $stk=$_GET["stk"];
    if (strpos(_get("fid"),"login")<=0){
     setcookie("uid",$_COOKIE["uid"],time()+3600,"/");
     setcookie("cid",$_COOKIE["cid"],time()+3600,"/");
     setcookie("uid",$_COOKIE["userid"],time()+3600,"/");
     setcookie("cid",$_COOKIE["comid"],time()+3600,"/");
     setcookie("grpcid",$_COOKIE["grpcid"],time()+3600,"/");
     setcookie("depart",$_COOKIE["depart"],time()+3600,"/");
     setcookie("dpmore",$_COOKIE["dpmore"],time()+3600,"/");
     setcookie("posids",$_COOKIE["posids"],time()+3600,"/");
     setcookie("roleids",$_COOKIE["roleids"],time()+3600,"/");
     setcookie("sysid",$_COOKIE["sysid"],time()+3600,"/");
     setcookie("stoken",$_COOKIE["stoken"],time()+3600,"/");
     setcookie("deadline",time()+3600,time()+3600,"/");
    }
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $pushsno=dftval($_GET["pushsno"],"");
$resrst=SX("select restype,resmark,fromhost,vermd5 from coode_respool where SNO=".$pushsno);
$vermd5=anyvalue($resrst,"vermd5",0);
$restype=anyvalue($resrst,"restype",0);
$resmark=anyvalue($resrst,"resmark",0);
$fromhost=anyvalue($resrst,"fromhost",0);
$downurl="http://".$fromhost."/DNA/EXF/anyfuns.php?fid=anyfilevisit&restype=".$restype."&resmark=".$resmark."&vermd5=".$vermd5;
switch($restype){
  case "menu":
  $savepath=combineurl(localroot(),"/seeds/plots/v-".$vermd5."/".$resmark.".zip");
  break;
  default:
  $tps=$restype."s";
  $savepath=combineurl(localroot(),"/seeds/".$tps."/v-".$vermd5."/".$resmark.".zip");
}
$bb=downanyfile($downurl,$savepath);
$zz=UX("update coode_respool set STATUS=1 where SNO=".$pushsno);
echo makereturnjson("1","成功","");
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>