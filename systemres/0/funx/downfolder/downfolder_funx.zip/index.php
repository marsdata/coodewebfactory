<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $ddd=$_GET["ddd"];
if (substr($ddd,-1)=="/"){
  $ddd=substr($ddd,0,strlen($ddd)-1);
}
if (substr($ddd,0,1)!="/"){
  $ddd="/".$ddd;
}
$ppp=str_replace("/localxres/csspagex/","/FACE/",$ddd);
$ppp=str_replace("/localxres/tempx/","/units/",$ddd);
$frst=SX("select SNO,filepath,filetitle,filetype,filename,cloudpath from coode_foldertree where parfolder='".$ppp."'");
$totf=countresult($frst);
$tot=0;
for ($i=0;$i<$totf;$i++){
  $sno=anyvalue($frst,"SNO",$i);
  $filepath=anyvalue($frst,"filepath",$i);
  $filepath=str_replace("/units/","/localxres/tempx/",$filepath);
  $filepath=str_replace("/FACE/","/localxres/csspagex/",$filepath);
  $filetitle=anyvalue($frst,"filetitle",$i);
  $filetype=anyvalue($frst,"filetype",$i);
  $filename=anyvalue($frst,"filename",$i);
  $cloudpath=anyvalue($frst,"cloudpath",$i);
  if ($filetype!="" and file_exists($filepath)==false){
   if ($filetype!="" and $cloudpath!=""){         
     $zz=cdfile($cloudpath,$filepath);
     if (file_exists($filepath)){
       $tot=$tot+1;
     }
   }
  }else{  
  }
    
}
if ($totf>0){
  $zz=UX("update coode_folderreg set UPTM=now(),incloud=0 where foldermark='".$ddd."'");
}
echo '{"status":"1","msg":"成功-'.$tot."/".$totf.'","redirect":""}';
     session_write_close();
?>