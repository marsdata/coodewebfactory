<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tbnm=$_GET["tbnm"];
$key=$_GET["key"];
$sno=$_GET["SNO"];
$cdtk="";
$cdtv="";
$conn=mysql_connect(gl(),glu(),glp());
 if (substr(str_replace("\\","/",$_SERVER['DOCUMENT_ROOT']),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER['DOCUMENT_ROOT'])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER['DOCUMENT_ROOT']);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
 }
 $omk=$_GET["olmk"];
  $tmpnm=$_FILES["file"]["tmp_name"];
  $fnm=$_FILES["file"]["name"];
  $fext=hou($fnm,".");
  $tmptp=$_FILES["file"]["type"];
  $tmperr=$_FILES["file"]["error"];
  $onlymark=onlymark();
  if ($omk==""){
    $omk=$onlymark;    
  }
  
  
if ($tbnm!=""){
  if ($sno*1==0){
    $sno=$omk;
  }else{
    $tkrst=SX("select olmkkey,mainsqx  from coode_tablist where TABLE_NAME='".$tbnm."'");    
    $omkey=anyvalue($tkrst,"olmkkey",0);
    $snokey=anyvalue($tkrst,"mainsqx",0);
    $omk=UX("select ".$omkey." as result from ".$tbnm." where ".$snokey."=".$sno);    
  };
  $yy=createdir(combineurl($gml,"/localxres/iconsetx/".$_COOKIE["uid"]."/todayfiles/".date("Y-m-d")."/".$tbnm));
  $rpt=combineurl($gml,"/localxres/iconsetx/".$_COOKIE["uid"]."/todayfiles/".date("Y-m-d")."/".$tbnm."/");
  $fpn=$rpt.$tbnm.$key.$omk."-".$fnm;
  $url=combineurl("/",str_replace($gml,"",$fpn));
  move_uploaded_file($tmpnm, $fpn);
  $kzm=hou($fpn,".");
   if (strpos($kzm,".jpg")>0 or strpos($kzm,".png")>0 or strpos($kzm,".gif")>0 or strpos($kzm,".bmp")>0  or strpos($kzm,".jpeg")>0 ){
     $img_info = getimagesize($fpn);
     $pw=$img_info[0];
     $ph=$img_info[1];
   }else{
     $pw="0";
     $ph="0";
   }
  $sqlx="TABLE_NAME,COLUMN_NAME,tbsno,tbolmk,CRTM,CDTK,CDTV,picb64,OLMK,picurl,piclocal,pw,ph";
  $sqly="'".$tbnm."','".$key."','".$sno."','".$sno."',now(),'".$cdtk."','".$cdtv."','".$b64."','".$onlymark."','".$url."','".$fpn."','".$pw."','".$ph."'";
  $conn=mysql_connect(gl(),glu(),glp());
  $keytype=updatings($conn,glb(),"select dxtype as result from coode_keydetailx where TABLE_NAME='".$tbnm."' and COLUMN_NAME='".$key."'","utf8");
  $conn=mysql_connect(gl(),glu(),glp());
  $xx=updatings($conn,glb(),"insert into coode_itemfile(".$sqlx.")values(".$sqly.")","utf8");
  if ($sno*1>0){
      $conn=mysql_connect(gl(),glu(),glp());
      $oomk=updatings($conn,glb(),"select ".$omkey." as result from ".$tbnm." where ".$snokey."=".$sno,"utf8");      
      $conn=mysql_connect(gl(),glu(),glp());
      $filerst=selecteds($conn,glb(),"select picurl from coode_itemfile where TABLE_NAME='".$tbnm."' and COLUMN_NAME='".$key."' and (tbsno='".$sno."' or tbsno='".$oomk."')","utf8","");
      $totf=countresult($filerst);
      if ($totf>0){
          $filexx=str_replace("#/#",";",hou($filerst,"#/#"));
      };
      
      if ($keytype=="files" or $keytype=="images"){
        $conn=mysql_connect(gl(),glu(),glp());
        $x=updatings($conn,glb(),"update ".$tbnm." set ".$key."='".$filexx."' where SNO=".$sno,"utf8");
        $conn=mysql_connect(gl(),glu(),glp());
        $x=updatings($conn,glb(),"update ".$tbnm." set ".$key."='".$filexx."' where sNo=".$sno,"utf8");
      }else{
          $ptflx=explode(";",$filexx);
          $totptf=count($ptflx);
          $conn=mysql_connect(gl(),glu(),glp());
          $x=updatings($conn,glb(),"update ".$tbnm." set ".$key."='".$ptflx[$totptf-2]."' where SNO=".$sno,"utf8");
          $conn=mysql_connect(gl(),glu(),glp());
          $x=updatings($conn,glb(),"update ".$tbnm." set ".$key."='".$ptflx[$totptf-2]."' where sNo=".$sno,"utf8");
      }
   }
      echo "{\"code\":\"1\",\"msg\":\"".$url."\"}";
  }else{
      echo "{\"code\":\"0\",\"msg\":\"lose table name\"}";     
  };
     session_write_close();
?>