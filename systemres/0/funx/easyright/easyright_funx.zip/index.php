<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $drt=tostring($_POST["drt"]);
if (strpos("x".$drt,"|")>0){
  $rightcon=qian($drt,"|");
  if ($rightcon!=""){
    $fmli='';
    if (strpos($rightcon,",")>0 or strpos($rightcon,"#-#")>0){
      if (strpos($rightcon,"#-#")>0){
        $ptright=explode("#-#",$rightcon);
      }else{
        $ptright=explode(",",$rightcon);
      }
      $totpt=count($ptright);       
      for ($i=0;$i<$totpt;$i++){
       $ttt="";
       $uuu="";
        if (strpos($ptright[$i],"::")>0){
          $ttt=qian($ptright[$i],"::");
          $uuu=hou($ptright[$i],"::");
          if (strpos($ttt,"----")>0){
           $tp=qian($ttt,"----");
           $tt=hou($ttt,"----");
          }else{
            $tt=$ttt;
            $tp="/localxres/iconsetx/pagecontrol/stt0.svg";
          }
          if (strpos($uuu,")")>0){
           $fmli=$fmli.'<li><a href="javascript:void(0)" onclick="'.$uuu.'"><div class="sidebox"><img src="'.$tp.'" style="width:20px;height:20px;margin-top:16.5px;">'.$tt.'</div></a></li>';
          }else{
           $fmli=$fmli.'<li><a href="javascript:void(0)" onclick="uniturl(\''.$uuu.'\')"><div class="sidebox"><img src="'.$tp.'" style="width:20px;height:20px;margin-top:16.5px;">'.$tt.'</div></a></li>';
          }
        }else{
          if (strpos($ptright[$i],"@")>0){
          $ttt=qian($ptright[$i],"@");
          $uuu=hou($ptright[$i],"@");
          if (strpos($ttt,"----")>0){
           $tp=qian($ttt,"----");
           $tt=hou($ttt,"----");
          }else{
            $tt=$ttt;
            $tp="/localxres/iconsetx/pagecontrol/stt0.svg";
          }
           if (strpos($uuu,")")>0){
            $fmli=$fmli.'<li><a href="javascript:void(0)" onclick="'.$uuu.'"><div class="sidebox"><img src="'.$tp.'" style="width:20px;height:20px;margin-top:16.5px;">'.$tt.'</div></a></li>';
           }else{
            $fmli=$fmli.'<li><a href="javascript:void(0)" onclick="newwin(\''.$tt.'\',\''.$uuu.'\')"><div class="sidebox"><img src="'.$tp.'" style="width:20px;height:20px;margin-top:16.5px;">'.$tt.'</div></a></li>';
           }
          }else{
            $ttt=qian($ptright[$i],":");
            $uuu=hou($ptright[$i],":");
            if (strpos($ttt,"----")>0){
             $tp=qian($ttt,"----");
             $tt=hou($ttt,"----");
            }else{
              $tt=$ttt;
              $tp="/localxres/iconsetx/pagecontrol/stt0.svg";
            }
           if (strpos($uuu,")")>0){
            $fmli=$fmli.'<li><a href="javascript:void(0)" onclick="'.$uuu.'"><div class="sidebox"><img src="'.$tp.'" style="width:20px;height:20px;margin-top:16.5px;">'.$tt.'</div></a></li>';
           }else{
            $fmli=$fmli.'<li><a href="javascript:void(0)" onclick="intourl(\''.$uuu.'\')"><div class="sidebox"><img src="'.$tp.'" style="width:20px;height:20px;margin-top:16.5px;">'.$tt.'</div></a></li>';
           }
          }         
        }
      }//for
    }else{//part
       $ttt="";
       $uuu="";
        if (strpos($rightcon,"::")>0){
          $ttt=qian($rightcon,"::");
          $uuu=hou($rightcon,"::");
          if (strpos($ttt,"----")>0){
           $tp=qian($ttt,"----");
           $tt=hou($ttt,"----");
          }else{
            $tt=$ttt;
            $tp="/localxres/iconsetx/pagecontrol/stt0.svg";
          }
          if (strpos($uuu,")")>0){
           $fmli=$fmli.'<li><a href="javascript:void(0)" onclick="'.$uuu.'"><div class="sidebox"><img src="'.$tp.'" style="width:20px;height:20px;margin-top:16.5px;">'.$tt.'</div></a></li>';
          }else{
           $fmli=$fmli.'<li><a href="javascript:void(0)" onclick="uniturl(\''.$uuu.'\')"><div class="sidebox"><img src="'.$tp.'" style="width:20px;height:20px;margin-top:16.5px;">'.$tt.'</div></a></li>';
          }
        }else{
          if (strpos($ptright[$i],"@")>0){
           if (strpos($uuu,")")>0){
            $fmli=$fmli.'<li><a href="javascript:void(0)" onclick="'.$uuu.'"><div class="sidebox"><img src="'.$tp.'" style="width:20px;height:20px;margin-top:16.5px;">'.$tt.'</div></a></li>';
           }else{
            $fmli=$fmli.'<li><a href="javascript:void(0)" onclick="newwin(\''.$tt.'\',\''.$uuu.'\')"><div class="sidebox"><img src="'.$tp.'" style="width:20px;height:20px;margin-top:16.5px;">'.$tt.'</div></a></li>';
           }
          }else{
           if (strpos($uuu,")")>0){
            $fmli=$fmli.'<li><a href="javascript:void(0)" onclick="'.$uuu.'"><div class="sidebox"><img src="'.$tp.'" style="width:20px;height:20px;margin-top:16.5px;">'.$tt.'</div></a></li>';
           }else{
            $fmli=$fmli.'<li><a href="javascript:void(0)" onclick="intourl(\''.$uuu.'\')"><div class="sidebox"><img src="'.$tp.'" style="width:20px;height:20px;margin-top:16.5px;">'.$tt.'</div></a></li>';
           }
          }         
        }    
    }//part
  $rtn='<div class="side" style="margin-left:-50px;">
   <ul>'.$fmli.'<li style="border:none;"><a href="javascript:goTop();" class="sidetop"><div class="sidebox"><img src="/localxres/csspagex/easyright/img/side_icon05.png">回到顶部</div></a></li>
   </ul></div>
<script type="text/javascript">
$(document).ready(function(){
   $(".side ul li").hover(function(){
      $(this).find(".sidebox").stop().animate({"width":"124px"},200).css({"opacity":"1","filter":"Alpha(opacity=100)","background":"#ae1c1c"})   
   },function(){
      $(this).find(".sidebox").stop().animate({"width":"54px"},200).css({"opacity":"0.8","filter":"Alpha(opacity=80)","background":"#000"})   
   });   
});
function goTop(){
   $(\'html,body\').animate({\'scrollTop\':0},600);
}
</script>';
echo $rtn;
  }else{
   echo "";
  }
}else{
 echo "";
}
     session_write_close();
?>