<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tabname=$_GET["tabname"];
$ID=$_POST["ID"];
$ids=$_POST["ids"];
$ptid=explode(",",$ids);
$totpt=count($ptid);
$fmcdt="";
$fmbdt="";
$pssno="SNO";
if (dftval($_GET["dbnm"],"")==""){
  if (dftval($_GET["laydb"],"")==""){
     $binfo=array();
     $binfo=gettabinfo(glb(),$tabname,$binfo);
  }else{
    $dinfo=array();
    $dinfo=getdbinfo(dftval($_GET["laydb"],""),$tabname,$dinfo);
    if ($dinfo["pssno"]!=""){
     $pssno=$dinfo["pssno"];
    }
     $binfo=array();
     $binfo=gettabinfo(dftval($_GET["laydb"],""),$tabname,$binfo);
  }
}else{
  $dinfo=array();
  $dinfo=getdbinfo(dftval($_GET["dbnm"],""),$tabname,$dinfo);
  if ($dinfo["pssno"]!=""){
    $pssno=$dinfo["pssno"];
  }
     $binfo=array();
     $binfo=gettabinfo(dftval($_GET["dbnm"],""),$tabname,$binfo);
}
for ($j=0;$j<$totpt;$j++){
  if ($ptid[$j]!=""){
    if (dftval($_GET["dbnm"],"")==""){
       $fmcdt=" or SNO=".$ptid[$j];
     }else{
       $fmcdt=" or ".$pssno."=".$ptid[$j];
     }
  }
}
if ($ID==""){
 if ($totpt>0){
  $fmcdt=substr($fmcdt,3,strlen($fmcdt)-3);
  if (dftval($_GET["dbnm"],"")==""){
   if (dftval($_GET["laydb"],"")==""){
       if ($binfo["subsqx"]!=""){
           $bdtrst=SX("select ".$binfo["subsqx"]."  from ".$tabname." where ".$fmcdt);
           $totbd=countresult($bdtrst);
           for ($k=0;$k<$totbd;$k++){
             $fmbdt=$fmbdt." or ".$binfo["subsqx"]."='".anyvalue($bdtrst,$binfo["subsqx"],$k)."' ";
           }
           $fmbdt=substr($fmbdt,3,strlen($fmbdt)-3);
       }else{
           $bdtrst=SX("select ".$binfo["srckey"]."  from ".$tabname." where ".$fmcdt);
           $totbd=countresult($bdtrst);
           for ($k=0;$k<$totbd;$k++){
             $fmbdt=$fmbdt." or ".$binfo["srckey"]."='".anyvalue($bdtrst,$binfo["srckey"],$k)."' ";
           }
           $fmbdt=substr($fmbdt,3,strlen($fmbdt)-3);
       }
       if ($binfo["host"]!=""){
           if (runaccess("ZuIHhcWt4g","判断是否拥有数据源修改权限")){
               $pdata["dsql"]="delete from ".$tabname." where ".$fmbdt;
               $bktxt=request_post("http://".$binfo["host"]."/DNA/oprtdata.asp?mtd=evalsql&uid=".$_COOKIE["uid"],$pdata);
           }
       }
     $zx=UX("delete from ".$tabname." where ".$fmcdt);      
   }else{
       if ($binfo["subsqx"]!=""){
           $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
           $bdtrst=selectedx($conn,dftval($_GET["laydb"],""),"select ".$binfo["subsqx"]."  from ".$tabname." where ".$fmcdt,"utf8","");
           $totbd=countresult($bdtrst);
           for ($k=0;$k<$totbd;$k++){
             $fmbdt=$fmbdt." or ".$binfo["subsqx"]."='".anyvalue($bdtrst,$binfo["subsqx"],$k)."' ";
           }
           $fmbdt=substr($fmbdt,3,strlen($fmbdt)-3);
       }else{
           $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
           $bdtrst=selectedx($conn,dftval($_GET["laydb"],""),"select ".$binfo["srckey"]."  from ".$tabname." where ".$fmcdt,"utf8","");
           $totbd=countresult($bdtrst);
           for ($k=0;$k<$totbd;$k++){
             $fmbdt=$fmbdt." or ".$binfo["srckey"]."='".anyvalue($bdtrst,$binfo["srckey"],$k)."' ";
           }
           $fmbdt=substr($fmbdt,3,strlen($fmbdt)-3);
       }
       if ($binfo["host"]!=""){
           if (runaccess("ZuIHhcWt4g","判断是否拥有数据源修改权限")){
               $pdata["dsql"]="delete from ".$tabname." where ".$fmbdt;
               $bktxt=request_post("http://".$binfo["host"]."/DNA/oprtdata.asp?mtd=evalsql&uid=".$_COOKIE["uid"],$pdata);
           }
       }
      $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
      $zx=updatingx($conn,dftval($_GET["laydb"],""),"delete from ".$tabname." where ".$fmcdt,"utf8");   
   }
  }else{
       if ($binfo["subsqx"]!=""){
           $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
           $bdtrst=selectedx($conn,dftval($_GET["dbnm"],""),"select ".$binfo["subsqx"]."  from ".$tabname." where ".$fmcdt,"utf8","");
           $totbd=countresult($bdtrst);
           for ($k=0;$k<$totbd;$k++){
             $fmbdt=$fmbdt." or ".$binfo["subsqx"]."='".anyvalue($bdtrst,$binfo["subsqx"],$k)."' ";
           }
           $fmbdt=substr($fmbdt,3,strlen($fmbdt)-3);
       }else{
           $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
           $bdtrst=selectedx($conn,dftval($_GET["dbnm"],""),"select ".$binfo["srckey"]."  from ".$tabname." where ".$fmcdt,"utf8","");
           $totbd=countresult($bdtrst);
           for ($k=0;$k<$totbd;$k++){
             $fmbdt=$fmbdt." or ".$binfo["srckey"]."='".anyvalue($bdtrst,$binfo["srckey"],$k)."' ";
           }
           $fmbdt=substr($fmbdt,3,strlen($fmbdt)-3);
       }
       if ($binfo["host"]!=""){
           if (runaccess("ZuIHhcWt4g","判断是否拥有数据源修改权限")){
               $pdata["dsql"]="delete from ".$tabname." where ".$fmbdt;
               $bktxt=request_post("http://".$binfo["host"]."/DNA/oprtdata.asp?mtd=evalsql&uid=".$_COOKIE["uid"],$pdata);
           }
       }
       $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
       $zx=updatingx($conn,dftval($_GET["dbnm"],""),"delete from ".$tabname." where ".$fmcdt,"utf8");
  }
  echo '{"status":"1","msg":"删除成功","redirect":""}';
 }else{
  echo '{"status":"0","msg":"未选择","redirect":""}';
 }
}else{
  if (dftval($_GET["dbnm"],"")==""){
    if (dftval($_GET["laydb"],"")==""){      
       if ($binfo["subsqx"]!=""){
           $subval=UX("select ".$binfo["subsqx"]." as result from ".$tabname." where SNO=".$ID);
           $rupd="delete from ".$tabname."  where ".$binfo["subsqx"]."='".$subval."'";
       }else{
           $subval=UX("select ".$binfo["srckey"]." as result from ".$tabname." where SNO=".$ID);
           $rupd="delete from ".$tabname."  where ".$binfo["srckey"]."='".$subval."'";
       }
       if ($binfo["host"]!=""){
           if (runaccess("ZuIHhcWt4g","判断是否拥有数据源修改权限")){
               $pdata["dsql"]=$rupd;
               $bktxt=request_post("http://".$binfo["host"]."/DNA/oprtdata.asp?mtd=evalsql&uid=".$_COOKIE["uid"],$pdata);
           }
       }
       $zx=UX("delete from ".$tabname." where SNO=".$ID);
    }else{
       if ($binfo["subsqx"]!=""){
           $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
           $subval=updatingx($conn,dftval($_GET["laydb"],""),"select ".$binfo["subsqx"]." as result from ".$tabname." where ".$pssno."=".$ID,"utf8");
           $rupd="delete from ".$tabname."  where ".$binfo["subsqx"]."='".$subval."'";
       }else{
           $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
           $subval=updatingx($conn,dftval($_GET["laydb"],""),"select ".$binfo["srckey"]." as result from ".$tabname." where ".$pssno."=".$ID,"utf8");
           $rupd="delete from ".$tabname."  where ".$binfo["srckey"]."='".$subval."'";
       }
       
       if ($binfo["host"]!=""){
           if (runaccess("ZuIHhcWt4g","判断是否拥有数据源修改权限")){
               $pdata["dsql"]=$rupd;               
               $bktxt=request_post("http://".$binfo["host"]."/DNA/oprtdata.asp?mtd=evalsql&uid=".$_COOKIE["uid"],$pdata);
           }
       }
      $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
      $zx=updatingx($conn,dftval($_GET["laydb"],""),"delete from ".$tabname." where ".$pssno."=".$ID,"utf8"); 
    }
  }else{    
       if ($binfo["subsqx"]!=""){
           $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
           $subval=updatingx($conn,dftval($_GET["dbnm"],""),"select ".$binfo["subsqx"]." as result from ".$tabname." where ".$pssno."=".$ID,"utf8");                      
           $rupd="delete from ".$tabname."  where ".$binfo["subsqx"]."='".$subval."'";           
       }else{
           $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
           $subval=updatingx($conn,dftval($_GET["dbnm"],""),"select ".$binfo["srckey"]." as result from ".$tabname." where ".$pssno."=".$ID,"utf8");
           $rupd="delete from ".$tabname."  where ".$binfo["srckey"]."='".$subval."'";
       }       
       if ($binfo["host"]!=""){
           if (runaccess("ZuIHhcWt4g","判断是否拥有数据源修改权限")){ 
               $pdata["dsql"]=$rupd;
               $bktxt=request_post("http://".$binfo["host"]."/DNA/oprtdata.asp?mtd=evalsql&uid=".$_COOKIE["uid"],$pdata);
           }
       }
       $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
       $zx=updatingx($conn,dftval($_GET["dbnm"],""),"delete from ".$tabname." where ".$pssno."=".$ID,"utf8"); 
  }
  echo '{"status":"1","msg":"删除成功","redirect":""}';
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>