<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sno=$_GET["id"];
$stid=$_GET["stid"];
$qryx="x".dftval($_GET["qrykey"],"");
eval(RESFUNSET("tabbaseinfo"));
eval(RESFUNSET("keyinfo"));
eval(RESFUNSET("keyfunbase"));
if (dftval($_GET["dbnm"],"")==""){
  if (dftval($_GET["laydb"],"")==""){
    $strst=SX("select tablename,showkeys,cdt,orddt from coode_shortdata where shortid='".$stid."' ");
    $tbnm=anyvalue($strst,"tablename",0);
    $sokeys=tostring(anyvalue($strst,"showkeys",0));
    $dinfo=array();
    $dinfo=getdbinfo("",$tbnm,$dinfo);
    if ($dinfo["pssno"]!=""){
      $pssno=$dinfo["pssno"];
    }
  }else{
    $strst=SX("select tablename,showkeys,cdt,orddt from coode_dbshort where shortid='".$stid."' ");
    $tbnm=anyvalue($strst,"tablename",0);
    $sokeys=tostring(anyvalue($strst,"showkeys",0));
    $dinfo=array();
    $dinfo=getdbinfo(dftval($_GET["laydb"],""),$tbnm,$dinfo);
    if ($dinfo["pssno"]!=""){
      $pssno=$dinfo["pssno"];
    }
  }
}else{
 if (dftval($_GET["laydb"],"")==""){
  $strst=SX("select tablename,showkeys,cdt,orddt from coode_dbshort where shortid='".$stid."' ");
  $tbnm=anyvalue($strst,"tablename",0);
  $sokeys=tostring(anyvalue($strst,"showkeys",0));
  $dinfo=array();
  $dinfo=getdbinfo(dftval($_GET["dbnm"],""),$tbnm,$dinfo);
  if ($dinfo["pssno"]!=""){
    $pssno=$dinfo["pssno"];
  }
 }else{
    $strst=SX("select tablename,showkeys,cdt,orddt from coode_dbshort where shortid='".$stid."' ");
    $tbnm=anyvalue($strst,"tablename",0);
    $sokeys=tostring(anyvalue($strst,"showkeys",0));
    $dinfo=array();
    $dinfo=getdbinfo(dftval($_GET["dbnm"],""),$tbnm,$dinfo);
    if ($dinfo["pssno"]!=""){
      $pssno=$dinfo["pssno"];
    }
    $dinfo=getdbinfo(dftval($_GET["laydb"],""),$tbnm,$dinfo);
 }
}
if (intval($sno)>0){
 if (dftval($_GET["dbnm"],"")==""){
   if (dftval($_GET["laydb"],"")==""){
     $tabrst=SX("select ".$sokeys." from ".$tbnm." where ".$pssno."=".$sno);     
   }else{
     $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
     $tabrst=selectedx($conn,dftval($_GET["laydb"],""),"select ".$sokeys." from ".$tbnm." where ".$pssno."=".$sno,"utf8","");    
   }
 }else{
   if (dftval($_GET["laydb"],"")==""){
    $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
    $tabrst=selectedx($conn,dftval($_GET["dbnm"],""),"select ".$sokeys." from ".$tbnm." where ".$pssno."=".$sno,"utf8",""); 
   }else{
     $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
     $tabrst=selectedx($conn,dftval($_GET["laydb"],""),"select ".$sokeys." from ".$tbnm." where ".$pssno."=".$sno,"utf8","");       
   }
 }
 $totrst=countresult($tabrst);
 $ptsk=explode(",",$sokeys);
 $fmvalx="";
 for ($m=0;$m<$totrst;$m++){
  $fmvalx=$fmvalx.'"opr":"1"},{"check":"no",';
   for ($n=0;$n<count($ptsk);$n++){
     if ($ptsk[$n]!="" and $ptsk[$n]!="OPRT"){
       if ($ptsk[$n]==$pssno){
        $fmvalx=$fmvalx.'"id":"'.anyvalue($tabrst,$pssno,$m).'",';
        $fmvalx=$fmvalx.'"'.$pssno.'":"'.anyvalue($tabrst,$pssno,$m).'",';
       }else{
        $fmvalx=$fmvalx.'"'.$ptsk[$n].'":"'.anyvalue($tabrst,$ptsk[$n],$m).'",';
       }
     }//ifptsk
   }//forn
 }//form
}else{
  $kxrst=SX("select keytitle,COLUMN_NAME,dxtype,valuezero from coode_keydetailx where TABLE_NAME='".$tbnm."' and ',".$sokeys.",' like concat('%,',COLUMN_NAME,',%') ");
  $totrst=countresult($kxrst);
  $fmvalx="";
  $fmvalx=$fmvalx.'"opr":"1"},{"check":"no",';
for ($m=0;$m<$totrst;$m++){  
     $colnm=anyvalue($kxrst,"COLUMN_NAME",$m);
     $vzero=anyvalue($kxrst,"valuezero",$m);
     $thusvalue="";
     if ($vzero!=""){
      eval($vzero);
     }
     if ($colnm!="" and $colnm!="OPRT"){
       if ($colnm==$pssno){
        $fmvalx=$fmvalx.'"id":"0",';
        $fmvalx=$fmvalx.'"'.$pssno.'":"0",';
       }else if ($colnm=="OLMK"){
        $fmvalx=$fmvalx.'"OLMK":"'.getRandChar(8).'",';
       }else{
        $fmvalx=$fmvalx.'"'.$colnm.'":"'.$thusvalue.'",';
       }
     }//ifptsk   
 }//form
}
if ($totrst>0){
  $fmvalx=substr($fmvalx,11,strlen($fmvalx)-11).'"opr":"1"}';
  echo '{"total":1,"rows":['.$fmvalx.']}';
}else{
  echo '{"total":0,"rows":[]}';
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>