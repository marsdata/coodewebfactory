<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $info=unstrs($_GET["info"]);
if (substr($info,0,1)=="@"){
    if (strpos($info,":")>0){
     $pp=qian(hou("x".$info,"@"),":");
     $wd=str_replace("\r\n","<br>",hou($info,":"));
    }else{
     $pp=qian(hou("x".$info,"@")," ");   
     $wd=str_replace("\r\n","<br>",hou($info," "));
    }
    
    $whoid="";
    $conn=mysql_connect(gl(),glu(),glp());
    $sqla="mymark,mytitle,orititle,OLMK,CRTM,UPTM,PTOF,CRTOR,tipcls,contentx";
    $sqlb="'".onlymark()."','".$_COOKIE["uid"]."执行发送短消息','发送".$wd."给".$pp."','".onlymark()."',now(),now(),'".$_COOKIE["cid"]."/".$_COOKIE["gid"]."','".$_COOKIE["uid"]."','comblog','".$info."'";
    $x=updatings($conn,glb(),"insert into coode_tips(".$sqla.")values(".$sqlb.")","utf8");
    switch ($pp){
        case "everyone":
        $whoid="eo";
        $whod="所有人";
        break;
        case "Everyone":
        $whoid="eo";
        $whod="所有人";
        break;
        case "EVERYONE":
        $whoid="eo";
        $whod="所有人";
        break;
        case "所有人":
        $whoid="eo";
        $whod="所有人";
        break;
        case "全体":
        $whoid="eo";
        $whod="所有人";
        break;
        case "所有下属":
        $whoid="allson";
        $whod="所有下属";
        break;
        case "直属下属":
        $whoid="directson";
        $whod="直属下属";
        break;
        case "本组":
        $whoid="mygroup";
        $whod="本组";
        break;
        case "本部门":
        $whoid="mygroup";
        $whod="本部门";
        break;
        case "直属领导":
        $whoid="directleader";
        $whod="直属领导";
        break;
        case "所有领导":
        $whoid="allleader";
        $whod="所有领导";
        break;
        default:
        $whoid=$pp;
    }
    $smsg=$wd;
      $conn=mysql_connect(gl(),glu(),glp());
      $myld=updatings($conn,glb(),"select authorize as result from coode_userlist where userid='".$_COOKIE["uid"]."'","utf8");
    switch($whoid){
      case "eo":
      $conn=mysql_connect(gl(),glu(),glp());
      $sqla="appname,appid,sender,receiver,sourcecls,urlpath,CRTM,UPTM,STATUS,CRTOR,OLMK";
      $sqlb="'短消息','shortmsg','".$_COOKIE["uid"]."',userid,'smsg','".$smsg."',now(),now(),0,'".$_COOKIE["uid"]."',RAND()*1000000000";
      $x=updatings($conn,glb(),"insert into coode_deliverx(".$sqla.")select ".$sqlb." from coode_userlist where comp='".$_COOKIE["cid"]."'","utf8");
      $succ="1";
      break;
      case "allson":
      $conn=mysql_connect(gl(),glu(),glp());
      $sqla="appname,appid,sender,receiver,sourcecls,urlpath,CRTM,UPTM,STATUS,CRTOR,OLMK";
      $sqlb="'短消息','shortmsg','".$_COOKIE["uid"]."',userid,'smsg','".$smsg."',now(),now(),0,'".$_COOKIE["uid"]."',RAND()*1000000000";
      $x=updatings($conn,glb(),"insert into coode_deliverx(".$sqla.")select ".$sqlb." from coode_userlist where comp='".$_COOKIE["cid"]."' and authorize like '%".$_COOKIE["uid"]."%'","utf8");
      $succ="1";
      break;
      case "directson":
      $conn=mysql_connect(gl(),glu(),glp());
      $sqla="appname,appid,sender,receiver,sourcecls,urlpath,CRTM,UPTM,STATUS,CRTOR,OLMK";
      $sqlb="'短消息','shortmsg','".$_COOKIE["uid"]."',userid,'smsg','".$smsg."',now(),now(),0,'".$_COOKIE["uid"]."',RAND()*1000000000";
      $x=updatings($conn,glb(),"insert into coode_deliverx(".$sqla.")select ".$sqlb." from coode_userlist where comp='".$_COOKIE["cid"]."' and authorize like '".$_COOKIE["uid"]."%'","utf8");
      $succ="1";
      break;
      case "mygroup":
      $conn=mysql_connect(gl(),glu(),glp());
      $sqla="appname,appid,sender,receiver,sourcecls,urlpath,CRTM,UPTM,STATUS,CRTOR,OLMK";
      $sqlb="'短消息','shortmsg','".$_COOKIE["uid"]."',userid,'smsg','".$smsg."',now(),now(),0,'".$_COOKIE["uid"]."',RAND()*1000000000";
      $x=updatings($conn,glb(),"insert into coode_deliverx(".$sqla.")select ".$sqlb." from coode_userlist where comp='".$_COOKIE["cid"]."' and depart='".$_COOKIE["gid"]."'","utf8");
      $succ="1";
      break;
      case "directleader":
      $zzld=qian($myld,",");
      $conn=mysql_connect(gl(),glu(),glp());
      $sqla="appname,appid,sender,receiver,sourcecls,urlpath,CRTM,UPTM,STATUS,CRTOR,OLMK";
      $sqlb="'短消息','shortmsg','".$_COOKIE["uid"]."',userid,'smsg','".$smsg."',now(),now(),0,'".$_COOKIE["uid"]."',RAND()*1000000000";
      $x=updatings($conn,glb(),"insert into coode_deliverx(".$sqla.")select ".$sqlb." from coode_userlist where comp='".$_COOKIE["cid"]."' and userid='".$zzld."'","utf8");
      $succ="1";
      break;
      case "allleader":
      $conn=mysql_connect(gl(),glu(),glp());
      $sqla="appname,appid,sender,receiver,sourcecls,urlpath,CRTM,UPTM,STATUS,CRTOR,OLMK";
      $sqlb="'短消息','shortmsg','".$_COOKIE["uid"]."',userid,'smsg','".$smsg."',now(),now(),0,'".$_COOKIE["uid"]."',RAND()*1000000000";
      $x=updatings($conn,glb(),"insert into coode_deliverx(".$sqla.")select ".$sqlb." from coode_userlist where comp='".$_COOKIE["cid"]."' and '".$myld."' like concat('%',userid,'%')","utf8");
      $succ="1";
      break;
      default:
      $conn=mysql_connect(gl(),glu(),glp());
      $sqla="appname,appid,sender,receiver,sourcecls,urlpath,CRTM,UPTM,STATUS,CRTOR,OLMK";
      $sqlb="'短消息','shortmsg','".$_COOKIE["uid"]."','".$whoid."','smsg','".$smsg."',now(),now(),0,'".$_COOKIE["uid"]."',RAND()*1000000000";
      $x=updatings($conn,glb(),"insert into coode_deliverx(".$sqla.")select ".$sqlb." from coode_userlist where comp='".$_COOKIE["cid"]."' and '".$whoid."'=userid","utf8");
      $succ="1";
    }
    if ($succ=="1"){
      echo "success:已经将消息（".$wd."）成功发送给".$whod;   
    }else{
      echo "fail:发送(".$wd.")给".$whod."失败";
    }
    
}else if (strpos("x".$info,"save:")>0){
    $svnr=hou($info,"save:");
    $nr=qian($svnr,"----");
    $tt=hou($svnr,"----");
    $conn=mysql_connect(gl(),glu(),glp());
    $sqla="mymark,mytitle,orititle,OLMK,CRTM,UPTM,PTOF,CRTOR,tipcls";
    $sqlb="'".onlymark()."','".$nr."','".$tt."','".onlymark()."',now(),now(),'".$_COOKIE["cid"]."/".$_COOKIE["gid"]."','".$_COOKIE["uid"]."','lovely'";
    $x=updatings($conn,glb(),"insert into coode_tips(".$sqla.")values(".$sqlb.")","utf8");
    
    $conn=mysql_connect(gl(),glu(),glp());
    $sqla="mymark,mytitle,orititle,OLMK,CRTM,UPTM,PTOF,CRTOR,tipcls,contentx";
    $sqlb="'".onlymark()."','".$_COOKIE["uid"]."执行收藏信息','收藏".$nr."备注为".$tt."','".onlymark()."',now(),now(),'".$_COOKIE["cid"]."/".$_COOKIE["gid"]."','".$_COOKIE["uid"]."','comblog','".$info."'";
    $x=updatings($conn,glb(),"insert into coode_tips(".$sqla.")values(".$sqlb.")","utf8");
    echo "success:成功保存".$nr."信息，备注为".$tt;   
}else if(strpos("x".$info,"visit:")>0){
    
    $mk=hou($info,"visit:");
    
    $conn=mysql_connect(gl(),glu(),glp());
    $gurl=updatings($conn,glb(),"select mytitle as result from coode_tips where orititle like '%".$mk."%'","utf8");
    
    $conn=mysql_connect(gl(),glu(),glp());
    $sqla="mymark,mytitle,orititle,OLMK,CRTM,UPTM,PTOF,CRTOR,tipcls,contentx";
    $sqlb="'".onlymark()."','".$_COOKIE["uid"]."执行快捷导航','标记".$mk."找到的地址为".$gurl."','".onlymark()."',now(),now(),'".$_COOKIE["cid"]."/".$_COOKIE["gid"]."','".$_COOKIE["uid"]."','comblog','".$info."'";
    $x=updatings($conn,glb(),"insert into coode_tips(".$sqla.")values(".$sqlb.")","utf8");
    echo "visiturl:".$gurl;
}else if(strpos("x".$info,"target:")>0){
    $tar=hou($info,"target:");
    
    $conn=mysql_connect(gl(),glu(),glp());
    $sqla="mymark,mytitle,OLMK,CRTM,UPTM,PTOF,CRTOR,tipcls";
    $sqlb="'".onlymark()."','".$tar."','".onlymark()."',now(),now(),'".$_COOKIE["cid"]."/".$_COOKIE["gid"]."','".$_COOKIE["uid"]."','mytar'";
    $x=updatings($conn,glb(),"insert into coode_tips(".$sqla.")values(".$sqlb.")","utf8");
    
    $conn=mysql_connect(gl(),glu(),glp());
    $sqla="mymark,mytitle,orititle,OLMK,CRTM,UPTM,PTOF,CRTOR,tipcls,contentx";
    $sqlb="'".onlymark()."','".$_COOKIE["uid"]."新建小目标','小目标为".$tar."','".onlymark()."',now(),now(),'".$_COOKIE["cid"]."/".$_COOKIE["gid"]."','".$_COOKIE["uid"]."','comblog','".$info."'";
    $x=updatings($conn,glb(),"insert into coode_tips(".$sqla.")values(".$sqlb.")","utf8");
    echo "success:成功新建小目标".$tar;   
    
}else if(strpos("x".$info,"edittable")>0){
    $conn=mysql_connect(gl(),glu(),glp());
    $ky=updatings($conn,glb(),"select count(*) as result from coode_userlist where userid='".$_COOKIE["uid"]."' and   comp='".$_COOKIE["cid"]."'","utf8");
    if (($ky*1)>0){
     echo "success:可以编辑表格 @run:localStorage.setItem(\"edittable\",\"1\");";   
    }else{
     echo "success:不可编辑表格 ";   
    }
    
}else if(strpos("x".$info,"closeedit")>0){
    echo "success:撤销编辑表格 @run:localStorage.setItem(\"edittable\",\"0\");";   
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>