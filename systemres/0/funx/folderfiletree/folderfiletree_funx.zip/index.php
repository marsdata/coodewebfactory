<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $itemdemo="{'id':[myid],'folder_name':'[myname]','description':'[mydes]','port_level':'[deep]','parent_id':'[parid]','is_directory':'[isd]','upd_username':'[crtor]','upd_date':'[updt]','upd_time':'[uptm]','crt_username':'[crtor]','crt_date':'[crdt]','crt_time':'[crtm]'},";
$srd="[(fdata)]";
$ddd=$_GET["ddd"];
if (substr($ddd,-1)=="/"){
  $ddd=substr($ddd,0,strlen($ddd)-1);
}
if (substr($ddd,0,1)!="/"){
  $ddd="/".$ddd;
}
//$zz=file_get_contents(combineurl(localroot(),"/localxres/funx/foldertrxx?ddd=".$ddd));
$sqlstrx="select myid as id,parid as parent_id,filename as folder_name,(length(filetype)/3) as is_directory,CRTOR as upd_username,CRTM as crt_date,UPTM as upd_date from coode_foldertrxx where parfolder='".$ddd."'";
$conn=mysql_connect(gl(),glu(),glp());
$fval=selectjson($conn,glb(),$sqlstrx,"utf8");
$srd=str_replace("(fdata)",$fval,$srd);
echo $srd;
     session_write_close();
?>