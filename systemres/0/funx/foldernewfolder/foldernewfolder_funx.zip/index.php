<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $folder=$_GET["folder"];
$newfolder=$_GET["newfolder"];
$worktitle=$_GET["worktitle"];
$workdesc=$_GET["workdesc"];
$parid=$_GET["parid"];
 $frst=SX("select filename,filepath,filetype from coode_foldertrxx where parfolder='".$folder."' and myid='".$parid."'");
  if (countresult($frst)>0){
    if (intval($parid)==1){
     $fpn=combineurl(localroot(),anyvalue($frst,"filepath",0))."/".$newfolder;
    }else{
     $fpn=anyvalue($frst,"filepath",0)."/".$newfolder;
    }
     $lastid=UX("select myid as result from coode_foldertrxx where parfolder='".$folder."' order by myid desc");
     $newid=$lastid+1;
     $extx=UX("select count(*) as result from coode_foldertrxx where filepath='".$fpn."' and parfolder='".$folder."'");
     if (intval($extx)==0){
       $sqlx="myid,parid,parfolder,filepath,filename,filetype,CRTM,UPTM,CRTOR,OLMK,STATUS,filetitle,STCODE";
       $sqly="'".$newid."','".$parid."','".$folder."','".$fpn."','".$newfolder."','',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."',1,'".$worktitle."','".$workdesc."'";
       $z=UX("insert into coode_foldertrxx(".$sqlx.")values(".$sqly.")");
      }else{
       $zz=UX("update coode_foldertrxx set filetitle='".$worktitle."',STCODE='".$workdesc."' where filepath='".$fpn."' and parfolder='".$folder."'");
      }
    is_dir($fpn) OR mkdir($fpn, 0777, true);
    echo '{"status":"1","msg":"新增成功","redirect":""}';
  }else{
   echo '{"status":"0","msg":"新增失败-无法找到父路径","redirect":""}';
  }
     session_write_close();
?>