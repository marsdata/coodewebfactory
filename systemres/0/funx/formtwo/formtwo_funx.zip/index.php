<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sysid=_get("sysid");
$plotid=_get("plotid");
$conn=mysql_connect(gl(),glu(),glp());
$x=updatings($conn,glb(),"delete from coode_clssub where domain='".$sysid."' and clsmark='sysappcls' and compid='compid' and groupid='groupid' and clientid='clientid'","utf8");
$conn=mysql_connect(gl(),glu(),glp());
$plevel=UX("select levelcount as result from coode_plotlist where plotmark='".$plotid."'")*1;
switch ($plevel){
 case 1:
  $conn=mysql_connect(gl(),glu(),glp());
  $frst=selecteds($conn,glb(),"select mymark,myid,mytitle from coode_plotdetail where plotmark='".$plotid."'","utf8","");
  $totf=countresult($frst);
    for ($z=0;$z<$totf;$z++){   
       $sqla="sysid,clsmark,clsdescrib,domain,grpid,keyid,keyval,compid,groupid,clientid,OLMK,CRTOR,PTOF,CRTM,UPTM";
       $sqlb="'".$sysid."','sysappcls','系统app默认分类','".$sysid."','".anyvalue($frst,"mymark",$z)."','".anyvalue($prst,"mymark",$z)."','".anyvalue($trst,"mytitle",$z)."','compid','groupid','clientid','".onlymark()."','".$_COOKIE["uid"]."','".myfirstpos()."',now(),now()";
       $conn=mysql_connect(gl(),glu(),glp());
       $xy=updatings($conn,glb(),"insert into coode_clssub(".$sqla.")values(".$sqlb.")","utf8");
    }//forn
 break;
 default:
  $conn=mysql_connect(gl(),glu(),glp());
  $frst=selecteds($conn,glb(),"select mymark,myid from coode_plotdetail where plotmark='".$plotid."'","utf8","");
  $totf=countresult($frst);
 for ($k=0;$k<$totf;$k++){
  $conn=mysql_connect(gl(),glu(),glp());
  $trst=selecteds($conn,glb(),"select mymark,mytitle,myid from coode_plotdetail where plotmark='".$plotid."' and parid='".anyvalue($frst,"myid",$k)."'","utf8","");
  $tott=countresult($trst);  
   for ($m=0;$m<$tott;$m++){
    $conn=mysql_connect(gl(),glu(),glp());
    $sqla="sysid,clsmark,clsdescrib,domain,grpid,keyid,keyval,compid,groupid,clientid,OLMK,CRTOR,PTOF,CRTM,UPTM";
    $sqlb="'".$sysid."','sysappcls','系统app默认分类','".$sysid."','".anyvalue($frst,"mymark",$k)."','".anyvalue($trst,"mymark",$m)."','".anyvalue($trst,"mytitle",$m)."','compid','groupid','clientid','".onlymark()."','".$_COOKIE["uid"]."','".myfirstpos()."',now(),now()";
    //tiny设置完二级分类自动挂一级分类
    $xy=updatings($conn,glb(),"insert into coode_clssub(".$sqla.")values(".$sqlb.")","utf8");
    $conn=mysql_connect(gl(),glu(),glp());
    $prst=selecteds($conn,glb(),"select mymark,mytitle,myid from coode_plotdetail where plotmark='".$plotid."' and parid='".anyvalue($trst,"myid",$m)."'","utf8","");
    $totpr=countresult($prst);
    for ($n=0;$n<$totpr;$n++){
       $conn=mysql_connect(gl(),glu(),glp());
       $sqla="sysid,clsmark,clsdescrib,domain,grpid,keyid,keyval,compid,groupid,clientid,OLMK,CRTOR,PTOF,CRTM,UPTM";
       $sqlb="'".$sysid."','sysappcls','系统app默认分类','".$sysid."','".anyvalue($trst,"mymark",$m)."','".anyvalue($prst,"mymark",$n)."','".anyvalue($prst,"mytitle",$n)."','compid','groupid','clientid','".onlymark()."','".$_COOKIE["uid"]."','".myfirstpos()."',now(),now()";
       $xy=updatings($conn,glb(),"insert into coode_clssub(".$sqla.")values(".$sqlb.")","utf8");
     }//forn
   }//form
 }//fork
}
$xz=UX("update coode_plotdetail set parid=-1 where parid=0 and plotmark='".$plotid."'");
$xz=UX("update coode_plotdetail set VRT='".$sysid."' where  plotmark='".$plotid."'");
echo "1";
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>