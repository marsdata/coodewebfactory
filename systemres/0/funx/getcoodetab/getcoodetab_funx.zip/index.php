<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sysid=$_GET["sysid"];
$imark=$_GET["imark"];
 $ids=SX("select TABLE_NAME from coode_tablist where issys=1");
 $ids=str_replace("#/#",",",$ids);
 $ids=str_replace("#-#",",",$ids);
 $coretrst=SX("select SNO,sdata,sourceid from coode_pagefuntab where ',,".$ids.",' like concat('%,',sourceid,',%') and sysid='public' and sourcecls='tab'");
 $totrst=countresult($coretrst);
 $fm="";
 for ($i=0;$i<$totrst;$i++){   
   $fm=$fm."CREATE/".anyvalue($coretrst,"sourceid",$i).":".str_replace(";","",anyvalue($coretrst,"sdata",$i))."@@@@";
   $sqla="planid,srcid,sysid,tabname,datasql,CRTOR,RIP,OLMK,CRTM,UPTM,STATUS";
   $z=UX("insert into coode_installplan(".$sqla.")values('".$imark."','crttable','".$sysid."','".anyvalue($coretrst,"sourceid",$i)."','".anyvalue($coretrst,"sdata",$i)."','','".getip()."','".onlymark()."',now(),now(),1)");
 };
 $fmx= " srcid='".$sysid."_plot' or srcid='".$sysid."_marks' or srcid='".$sysid."_apps' or srcid='".$sysid."_sys' ";
 $fmx=$fmx." or srcid='public_plot' or srcid='public_marks' or srcid='public_apps' or srcid='public_sys' or srcid='dataformat'  or srcid='sysda' or srcid='sysrole'  or srcid='".$sysid."_plst' or srcid='syspos'";
  $pubtrst=SX("select tabname,tabolmk,frmsql,datasql from coode_datainstall where ".$fmx);
 $totrst=countresult($pubtrst);
 for ($i=0;$i<$totrst;$i++){
   $sqla="planid,srcid,sysid,tabname,tabolmk,frmsql,datasql,CRTOR,RIP,OLMK,CRTM,UPTM,STATUS";
   $z=UX("insert into coode_installplan(".$sqla.")values('".$imark."','tabdata','".$sysid."','".anyvalue($pubtrst,"tabname",$i)."','".anyvalue($pubtrst,"tabolmk",$i)."','".anyvalue($pubtrst,"frmsql",$i)."','".str_replace(";","",anyvalue($pubtrst,"datasql",$i))."','','".getip()."','".onlymark()."',now(),now(),1)");
   $fm=$fm.anyvalue($pubtrst,"frmsql",$i)."/".anyvalue($pubtrst,"tabname",$i)."----".anyvalue($pubtrst,"tabolmk",$i).":".anyvalue($pubtrst,"datasql",$i)."@@@@";
 };
 echo $fm;
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>