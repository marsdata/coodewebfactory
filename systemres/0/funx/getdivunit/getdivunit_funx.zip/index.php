<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $instmark=$_GET["instmark"];
$expx=$_GET["expx"];
if ($instmark!=""){
 $trst=SX("select SNO,insttitle,instmark,pagesrd,outurl,stylex,scriptx,jsfilex,cssfilex,frmcode,pagesrd,comcode from coode_divfrmindex where instmark='".$instmark."' and mothersrd='".$expx."'"); 
 $insttitle=anyvalue($trst,"insttitle",0);
 $tmpback=$tmpback."\"insttitle\":\"".$insttitle."\","; 
 
 $tmpback=$tmpback."\"instmark\":\"".$instmark."\",";
 $pagesrd=anyvalue($trst,"pagesrd",0);
 $tmpback=$tmpback."\"pagesrd\":\"".$pagesrd."\",";
 
 $tmpback=$tmpback."\"expx\":\"".$expx."\",";
 $outurl=anyvalue($trst,"outurl",0);
 $tmpback=$tmpback."\"outurl\":\"".$outurl."\",";
 
 
 $stylex=anyvalue($trst,"stylex",0);
 $tmpback=$tmpback."\"stylex\":\"".$stylex."\",";
 
 $jsfilex=anyvalue($trst,"jsfilex",0);
 $tmpback=$tmpback."\"jsfilex\":\"".$jsfilex."\",";
 $cssfilex=anyvalue($trst,"cssfilex",0);
 $tmpback=$tmpback."\"cssfilex\":\"".$cssfilex."\",";
 $scriptx=anyvalue($trst,"scriptx",0);
 $tmpback=$tmpback."\"scriptx\":\"".$scriptx."\",";
 $frmcode=anyvalue($trst,"frmcode",0);
 $tmpback=$tmpback."\"frmcode\":\"".$frmcode."\",";
  $pagesrd=anyvalue($trst,"pagesrd",0);
 $tmpback=$tmpback."\"pagesrd\":\"".$pagesrd."\",";
  $comcode=anyvalue($trst,"comcode",0);
 $tmpback=$tmpback."\"comcode\":\"".$comcode."\",";
 echo "{\"status\":\"1\",\"msg\":\"@succ\",".killlaststr($tmpback)."}";
}else{
 echo "{\"status\":\"0\",\"msg\":\"@fail\"}";
}
     session_write_close();
?>