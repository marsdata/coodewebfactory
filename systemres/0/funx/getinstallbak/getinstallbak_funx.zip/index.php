<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $act=$_GET["act"];
$ids=$_GET["ids"];
$imark=$_GET["imark"];
$sysid=$_GET["sysid"];
$fm="";
$extch=SX("select storage from coode_shortaffect where shortid='".$ids."' and tempid='".$act."' and pageid='".$sysid."'");
$totext=countresult($extch);
if (intval($totext)>0){
 $fm=anyvalue($extch,"storage",0);
}else{
switch($act){
 case "publictabs": 
 $pubtrst=SX("select SNO,sdata,sourceid from coode_pagefuntab where sourceid='".$ids."' and sysid='public' and sourcecls='tab'");
 $totrst=countresult($pubtrst);
 $fm="";
 for ($i=0;$i<$totrst;$i++){   
   $fm=$fm."CREATE/".anyvalue($pubtrst,"sourceid",$i).":".str_replace(";","",anyvalue($pubtrst,"sdata",$i))."@@@@";
   $sqla="planid,srcid,sysid,tabname,datasql,CRTOR,RIP,OLMK,CRTM,UPTM";
   $z=UX("insert into coode_installplan(".$sqla.")values('".$imark."','crttable','".$sysid."','".anyvalue($pubtrst,"sourceid",$i)."','".anyvalue($pubtrst,"sdata",$i)."','','".getip()."','".onlymark()."',now(),now())");
 }
 //$ids=killlaststr($ids);
 //$ptids=explode(",",$ids);
 //$totpt=count($ptids);
 $fmpt=" srcid='".$ids."'";
 //for ($i=0;$i<$totpt;$i++){
//  $fmpt=$fmpt." srcid='".$ptids[$i]."' or ";
// }
// $fmpt=substr($fmpt,0,strlen($fmpt)-3);
 $pubtrst=SX("select tabname,tabolmk,frmsql,datasql from coode_datainstall where ".$fmpt);
 //echo "select tabname,tabolmk,frmsql,datasql from coode_datainstall where ".$fmpt;
 $totrst=countresult($pubtrst);
 //echo "totrst-".$totrst;
 for ($i=0;$i<$totrst;$i++){
   $sqla="planid,srcid,sysid,tabname,tabolmk,frmsql,datasql,CRTOR,RIP,OLMK,CRTM,UPTM";
   $z=UX("insert into coode_installplan(".$sqla.")values('".$imark."','tabdata','".$sysid."','".anyvalue($pubtrst,"tabname",$i)."','".anyvalue($pubtrst,"tabolmk",$i)."','".anyvalue($pubtrst,"frmsql",$i)."','".str_replace(";","",anyvalue($pubtrst,"datasql",$i))."','','".getip()."','".onlymark()."',now(),now())");   
   $fm=$fm.anyvalue($pubtrst,"frmsql",$i)."/".anyvalue($pubtrst,"tabname",$i)."----".anyvalue($pubtrst,"tabolmk",$i).":".anyvalue($pubtrst,"datasql",$i)."@@@@";   
 } 
 //最先应该执行这个方法
 break;
 case "publicfuns":
 $pubtrst=SX("select SNO,sourceid,sdata from coode_pagefuntab where sourceid='".$ids."' and sysid='public' and sourcecls='fun'");
 $totrst=countresult($pubtrst);
 $fm="";
 for ($i=0;$i<$totrst;$i++){
   $fm=$fm."fun/".anyvalue($pubtrst,"sourceid",$i).":".anyvalue($pubtrst,"sdata",$i)."@@@@";
   $sqla="planid,srcid,sysid,tabname,itemsrcval,CRTOR,RIP,OLMK,CRTM,UPTM";
   $z=UX("insert into coode_installplan(".$sqla.")values('".$imark."','crtfun','".$sysid."','".anyvalue($pubtrst,"sourceid",$i)."','".anyvalue($pubtrst,"sdata",$i)."','','".getip()."','".onlymark()."',now(),now())");
 } 
 break;
 case "publicclss":
 $pubtrst=SX("select SNO,sourceid,sdata from coode_pagefuntab where sourceid='".$ids."' and sysid='public' and sourcecls='cls'");
 $totrst=countresult($pubtrst);
 $fm="";
 for ($i=0;$i<$totrst;$i++){
   $fm=$fm."cls/".anyvalue($pubtrst,"sourceid",$i).":".anyvalue($pubtrst,"sdata",$i)."@@@@";
   $sqla="planid,srcid,sysid,tabname,itemsrcval,CRTOR,RIP,OLMK,CRTM,UPTM";
   $z=UX("insert into coode_installplan(".$sqla.")values('".$imark."','crtcls','".$sysid."','".anyvalue($pubtrst,"sourceid",$i)."','".anyvalue($pubtrst,"sdata",$i)."','','".getip()."','".onlymark()."',now(),now())");
 }
 break;
 case "publicunitp":
 //$ptids=explode(",",$ids);
 //$totpt=count($ptids);
 $fmpt=" srcid='".$ids."_unit' ";
 //for ($i=0;$i<$totpt;$i++){
  //$fmpt=$fmpt." srcid='".$ptids[$i]."_unit' or ";
 //}
 //$fmpt=substr($fmpt,0,strlen($fmpt)-3);
 $pubtrst=SX("select tabname,tabolmk,frmsql,datasql from coode_datainstall where ".$fmpt);
 $totrst=countresult($pubtrst);
 $fm="";
 for ($i=0;$i<$totrst;$i++){
   $sqla="planid,srcid,sysid,tabname,tabolmk,frmsql,datasql,CRTOR,RIP,OLMK,CRTM,UPTM";
   $z=UX("insert into coode_installplan(".$sqla.")values('".$imark."','tabdata','".$sysid."','".anyvalue($pubtrst,"tabname",$i)."','".anyvalue($pubtrst,"tabolmk",$i)."','".anyvalue($pubtrst,"frmsql",$i)."','".str_replace(";","",anyvalue($pubtrst,"datasql",$i))."','','".getip()."','".onlymark()."',now(),now())");   
   $fm=$fm.anyvalue($pubtrst,"frmsql",$i)."/".anyvalue($pubtrst,"tabname",$i)."----".anyvalue($pubtrst,"tabolmk",$i).":".anyvalue($pubtrst,"datasql",$i)."@@@@";
 }
 break;
 case "publicunits":
 break;
 case "publicpages":
  //$ptids=explode(",",$ids);
 //$totpt=count($ptids);
 $fmpt=" srcid='".$ids."_page'";
 //for ($i=0;$i<$totpt;$i++){
  //$fmpt=$fmpt." srcid='".$ptids[$i]."_page' or ";
 //}
 //$fmpt=substr($fmpt,0,strlen($fmpt)-3);
 $pubtrst=SX("select tabname,tabolmk,frmsql,datasql from coode_datainstall where ".$fmpt);
 $totrst=countresult($pubtrst);
 $fm="";
 for ($i=0;$i<$totrst;$i++){
   $sqla="planid,srcid,sysid,tabname,tabolmk,frmsql,datasql,CRTOR,RIP,OLMK,CRTM,UPTM";
   $z=UX("insert into coode_installplan(".$sqla.")values('".$imark."','tabdata','".$sysid."','".anyvalue($pubtrst,"tabname",$i)."','".anyvalue($pubtrst,"tabolmk",$i)."','".anyvalue($pubtrst,"frmsql",$i)."','".str_replace(";","",anyvalue($pubtrst,"datasql",$i))."','','".getip()."','".onlymark()."',now(),now())");   
   $fm=$fm.anyvalue($pubtrst,"frmsql",$i)."/".anyvalue($pubtrst,"tabname",$i)."----".anyvalue($pubtrst,"tabolmk",$i).":".anyvalue($pubtrst,"datasql",$i)."@@@@";
 }
 break;
 case "publiccases":
  //$ptids=explode(",",$ids);
 //$totpt=count($ptids);
 $fmpt=" srcid='".$ids."_case'";
 //for ($i=0;$i<$totpt;$i++){
  //$fmpt=$fmpt." srcid='".$ptids[$i]."_case' or ";
 //}
 //$fmpt=substr($fmpt,0,strlen($fmpt)-3);
 $pubtrst=SX("select tabname,tabolmk,frmsql,datasql from coode_datainstall where ".$fmpt);
 $totrst=countresult($pubtrst);
 $fm="";
 for ($i=0;$i<$totrst;$i++){
   $sqla="planid,srcid,sysid,tabname,tabolmk,frmsql,datasql,CRTOR,RIP,OLMK,CRTM,UPTM";
   $z=UX("insert into coode_installplan(".$sqla.")values('".$imark."','tabdata','".$sysid."','".anyvalue($pubtrst,"tabname",$i)."','".anyvalue($pubtrst,"tabolmk",$i)."','".anyvalue($pubtrst,"frmsql",$i)."','".str_replace(";","",anyvalue($pubtrst,"datasql",$i))."','','".getip()."','".onlymark()."',now(),now())");   
   $fm=$fm.anyvalue($pubtrst,"frmsql",$i)."/".anyvalue($pubtrst,"tabname",$i)."----".anyvalue($pubtrst,"tabolmk",$i).":".anyvalue($pubtrst,"datasql",$i)."@@@@";
 }
 break;
  case "publicmenus":  
 $fmpt=" srcid='".$ids."_menu'";
 $pubtrst=SX("select tabname,tabolmk,frmsql,datasql from coode_datainstall where ".$fmpt);
 $totrst=countresult($pubtrst);
 $fm="";
 for ($i=0;$i<$totrst;$i++){
   $sqla="planid,srcid,sysid,tabname,tabolmk,frmsql,datasql,CRTOR,RIP,OLMK,CRTM,UPTM";
   $z=UX("insert into coode_installplan(".$sqla.")values('".$imark."','tabdata','".$sysid."','".anyvalue($pubtrst,"tabname",$i)."','".anyvalue($pubtrst,"tabolmk",$i)."','".anyvalue($pubtrst,"frmsql",$i)."','".str_replace(";","",anyvalue($pubtrst,"datasql",$i))."','','".getip()."','".onlymark()."',now(),now())");   
   $fm=$fm.anyvalue($pubtrst,"frmsql",$i)."/".anyvalue($pubtrst,"tabname",$i)."----".anyvalue($pubtrst,"tabolmk",$i).":".anyvalue($pubtrst,"datasql",$i)."@@@@";
 }
 break;
  case "publicchtmls":
  
 $fmpt=" srcid='".$ids."_chtml'";
 
 //$fmpt=substr($fmpt,0,strlen($fmpt)-3);
 $pubtrst=SX("select tabname,tabolmk,frmsql,datasql from coode_datainstall where ".$fmpt);
 $totrst=countresult($pubtrst);
 $fm="";
 for ($i=0;$i<$totrst;$i++){
   $sqla="planid,srcid,sysid,tabname,tabolmk,frmsql,datasql,CRTOR,RIP,OLMK,CRTM,UPTM";
   $z=UX("insert into coode_installplan(".$sqla.")values('".$imark."','tabdata','".$sysid."','".anyvalue($pubtrst,"tabname",$i)."','".anyvalue($pubtrst,"tabolmk",$i)."','".anyvalue($pubtrst,"frmsql",$i)."','".str_replace(";","",anyvalue($pubtrst,"datasql",$i))."','','".getip()."','".onlymark()."',now(),now())");   
   $fm=$fm.anyvalue($pubtrst,"frmsql",$i)."/".anyvalue($pubtrst,"tabname",$i)."----".anyvalue($pubtrst,"tabolmk",$i).":".anyvalue($pubtrst,"datasql",$i)."@@@@";
 }
 break;
 case "sysfuns":
 $pubtrst=SX("select SNO,sourceid,sdata from coode_pagefuntab where sysid='".$sysid."' and sourcecls='fun' and sourceid='".$ids."'");
 $totrst=countresult($pubtrst);
 $fm="";
 for ($i=0;$i<$totrst;$i++){
   $fm=$fm."fun/".anyvalue($pubtrst,"sourceid",$i).":".anyvalue($pubtrst,"sdata",$i)."@@@@";
   $sqla="planid,srcid,sysid,tabname,itemsrcval,CRTOR,RIP,OLMK,CRTM,UPTM";
   $z=UX("insert into coode_installplan(".$sqla.")values('".$imark."','crtfun','".$sysid."','".anyvalue($pubtrst,"sourceid",$i)."','".anyvalue($pubtrst,"sdata",$i)."','','".getip()."','".onlymark()."',now(),now())");
 } 
 break;
 case "sysclss":
 $pubtrst=SX("select SNO,sourceid,sdata from coode_pagefuntab where sysid='".$sysid."' and sourcecls='cls' and sourceid='".$ids."'");
 $totrst=countresult($pubtrst);
 $fm="";
 for ($i=0;$i<$totrst;$i++){
   $fm=$fm."cls/".anyvalue($pubtrst,"sourceid",$i).":".anyvalue($pubtrst,"sdata",$i)."@@@@";
   $sqla="planid,srcid,sysid,tabname,itemsrcval,CRTOR,RIP,OLMK,CRTM,UPTM";
   $z=UX("insert into coode_installplan(".$sqla.")values('".$imark."','crtcls','".$sysid."','".anyvalue($pubtrst,"sourceid",$i)."','".anyvalue($pubtrst,"sdata",$i)."','','".getip()."','".onlymark()."',now(),now())");
 }
 break;
 case "sysunitp":
 //$ptids=explode(",",$ids);
 //$totpt=count($ptids);
 $fmpt=" srcid='".$ids."_unit' ";
 //for ($i=0;$i<$totpt;$i++){
  //$fmpt=$fmpt." srcid='".$ptids[$i]."_unit' or ";
 //}
 //$fmpt=substr($fmpt,0,strlen($fmpt)-3);
 $pubtrst=SX("select tabname,tabolmk,frmsql,datasql from coode_datainstall where ".$fmpt);
 $totrst=countresult($pubtrst);
 $fm="";
 for ($i=0;$i<$totrst;$i++){
   $sqla="planid,srcid,sysid,tabname,tabolmk,frmsql,datasql,CRTOR,RIP,OLMK,CRTM,UPTM";
   $z=UX("insert into coode_installplan(".$sqla.")values('".$imark."','tabdata','".$sysid."','".anyvalue($pubtrst,"tabname",$i)."','".anyvalue($pubtrst,"tabolmk",$i)."','".anyvalue($pubtrst,"frmsql",$i)."','".str_replace(";","",anyvalue($pubtrst,"datasql",$i))."','','".getip()."','".onlymark()."',now(),now())");   
   $fm=$fm.anyvalue($pubtrst,"frmsql",$i)."/".anyvalue($pubtrst,"tabname",$i)."----".anyvalue($pubtrst,"tabolmk",$i).":".anyvalue($pubtrst,"datasql",$i)."@@@@";
 }
 break;
 case "sysunits":
 $corefs=SX("select updateurl from coode_sitefile where PTOF='".$ids."'");
 $corefs=hou($corefs,"#/#");
 $corefs=str_replace("#/#",",",$corefs);
 $corefs=str_replace("#-#",",",$corefs);
 $fm=$corefs;
 break;
 case "syspages":
 //$ptids=explode(",",$ids);
 //$totpt=count($ptids);
 $fmpt=" srcid='".$ids."_page'";
 //for ($i=0;$i<$totpt;$i++){
  //$fmpt=$fmpt." srcid='".$ptids[$i]."_page' or ";
 //}
 //$fmpt=substr($fmpt,0,strlen($fmpt)-3);
 $pubtrst=SX("select tabname,tabolmk,frmsql,datasql from coode_datainstall where ".$fmpt);
 $totrst=countresult($pubtrst);
 $fm="";
 for ($i=0;$i<$totrst;$i++){
   $sqla="planid,srcid,sysid,tabname,tabolmk,frmsql,datasql,CRTOR,RIP,OLMK,CRTM,UPTM";
   $z=UX("insert into coode_installplan(".$sqla.")values('".$imark."','tabdata','".$sysid."','".anyvalue($pubtrst,"tabname",$i)."','".anyvalue($pubtrst,"tabolmk",$i)."','".anyvalue($pubtrst,"frmsql",$i)."','".str_replace(";","",anyvalue($pubtrst,"datasql",$i))."','','".getip()."','".onlymark()."',now(),now())");   
   $fm=$fm.anyvalue($pubtrst,"frmsql",$i)."/".anyvalue($pubtrst,"tabname",$i)."----".anyvalue($pubtrst,"tabolmk",$i).":".anyvalue($pubtrst,"datasql",$i)."@@@@";
 }
 break;
 case "syscases":
  //$ptids=explode(",",$ids);
 //$totpt=count($ptids);
 $fmpt=" srcid='".$ids."'";
 //for ($i=0;$i<$totpt;$i++){
  //$fmpt=$fmpt." srcid='".$ptids[$i]."_case' or ";
 //}
 //$fmpt=substr($fmpt,0,strlen($fmpt)-3);
 $pubtrst=SX("select tabname,tabolmk,frmsql,datasql from coode_datainstall where ".$fmpt);
 $totrst=countresult($pubtrst);
 $fm="";
 for ($i=0;$i<$totrst;$i++){
   $sqla="planid,srcid,sysid,tabname,tabolmk,frmsql,datasql,CRTOR,RIP,OLMK,CRTM,UPTM";
   $z=UX("insert into coode_installplan(".$sqla.")values('".$imark."','tabdata','".$sysid."','".anyvalue($pubtrst,"tabname",$i)."','".anyvalue($pubtrst,"tabolmk",$i)."','".anyvalue($pubtrst,"frmsql",$i)."','".str_replace(";","",anyvalue($pubtrst,"datasql",$i))."','','".getip()."','".onlymark()."',now(),now())");   
   $fm=$fm.anyvalue($pubtrst,"frmsql",$i)."/".anyvalue($pubtrst,"tabname",$i)."----".anyvalue($pubtrst,"tabolmk",$i).":".anyvalue($pubtrst,"datasql",$i)."@@@@";
 }
 break;
 case "systabs":
  $pubtrst=SX("select SNO,sourceid,sdata from coode_pagefuntab where sysid='".$sysid."' and sourcecls='tab' and sourceid='".$ids."'");
 $totrst=countresult($pubtrst);
 $fm="";
 for ($i=0;$i<$totrst;$i++){
   $fm=$fm."CREATE/".anyvalue($pubtrst,"sourceid",$i).":".anyvalue($pubtrst,"sdata",$i)."@@@@";
   $sqla="planid,srcid,sysid,tabname,datasql,CRTOR,RIP,OLMK,CRTM,UPTM";
   $z=UX("insert into coode_installplan(".$sqla.")values('".$imark."','crttable','".$sysid."','".anyvalue($pubtrst,"sourceid",$i)."','".anyvalue($pubtrst,"sdata",$i)."','','".getip()."','".onlymark()."',now(),now())");
 }
 //$ptids=explode(",",$ids);
 //$totpt=count($ptids);
 $fmpt=" srcid='".$ids."' ";
 //for ($i=0;$i<$totpt;$i++){
  //$fmpt=$fmpt." srcid='".$ptids[$i]."' or ";
 //}
 //$fmpt=substr($fmpt,0,strlen($fmpt)-3);
 $pubtrst=SX("select tabname,tabolmk,frmsql,datasql from coode_datainstall where ".$fmpt);
 $totrst=countresult($pubtrst);
 for ($i=0;$i<$totrst;$i++){
   $sqla="planid,srcid,sysid,tabname,tabolmk,frmsql,datasql,CRTOR,RIP,OLMK,CRTM,UPTM";
   $z=UX("insert into coode_installplan(".$sqla.")values('".$imark."','tabdata','".$sysid."','".anyvalue($pubtrst,"tabname",$i)."','".anyvalue($pubtrst,"tabolmk",$i)."','".anyvalue($pubtrst,"frmsql",$i)."','".str_replace(";","",anyvalue($pubtrst,"datasql",$i))."','','".getip()."','".onlymark()."',now(),now())");   
   $fm=$fm.anyvalue($pubtrst,"frmsql",$i)."/".anyvalue($pubtrst,"tabname",$i)."----".anyvalue($pubtrst,"tabolmk",$i).":".anyvalue($pubtrst,"datasql",$i)."@@@@";
 }
 break;
 case "sysshorts":
 $tbnm=_get("tbnm");
 $fmpt=" srcid='".$tbnm."' and datasql like '%".$ids."%' "; 
 $pubtrst=SX("select tabname,tabolmk,frmsql,datasql from coode_datainstall where ".$fmpt);
 $totrst=countresult($pubtrst);
 for ($i=0;$i<$totrst;$i++){
   $sqla="planid,srcid,sysid,tabname,tabolmk,frmsql,datasql,CRTOR,RIP,OLMK,CRTM,UPTM";
   $z=UX("insert into coode_installplan(".$sqla.")values('".$imark."','tabdata','".$sysid."','".anyvalue($pubtrst,"tabname",$i)."','".anyvalue($pubtrst,"tabolmk",$i)."','".anyvalue($pubtrst,"frmsql",$i)."','".str_replace(";","",anyvalue($pubtrst,"datasql",$i))."','','".getip()."','".onlymark()."',now(),now())");   
   $fm=$fm.anyvalue($pubtrst,"frmsql",$i)."/".anyvalue($pubtrst,"tabname",$i)."----".anyvalue($pubtrst,"tabolmk",$i).":".anyvalue($pubtrst,"datasql",$i)."@@@@";
 }
 break;
 default:
 }
}
if ($fm==""){ 
 echo "nodata";
}else{
 if (intval($totext)==0){
   $z=UX("insert into coode_shortaffect(shortid,storage,tempid,pageid)values('".$ids."','".$fm."','".$act."','".$sysid."')");
 }
 echo $fm;
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>