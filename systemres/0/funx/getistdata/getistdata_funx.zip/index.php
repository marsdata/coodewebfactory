<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $timea=time();
$sysid=$_GET["sysid"];
$item='{"sysid":"[sysid]","relytab":"[relytab]","restitle":"[restitle]","sqltype":"[sqltype]","sqlval":"[sqlval]","sqlmd5":"[sqlmd5]"},';
$demo='{"status":"1","msg":"获取成功","vls":[<data>],"costtime":"[costtime]"}';
$cdrst=SX("select sysid,relytab,strtype,restitle,sqlstring,sqlmd5 from coode_insdata where sysid='".$sysid."' order by strtype");
$totc=countresult($cdrst);
$fmitem="";
for ($i=0;$i<$totc;$i++){
 $ssid=anyvalue($cdrst,"sysid",$i);
 $relytab=anyvalue($cdrst,"relytab",$i);
 $strtype=anyvalue($cdrst,"strtype",$i);
 $restitle=anyvalue($cdrst,"restitle",$i);
 $sqlstring=anyvalue($cdrst,"sqlstring",$i);
 $sqlmd5=anyvalue($cdrst,"sqlmd5",$i);
 $itemx=$item;
 $itemx=str_replace("[sysid]",$ssid,$itemx);
 $itemx=str_replace("[relytab]",$relytab,$itemx);
 $itemx=str_replace("[restitle]",$restitle,$itemx);
 $itemx=str_replace("[sqltype]",$strtype,$itemx);
 $itemx=str_replace("[sqlval]",$sqlstring,$itemx);
 $itemx=str_replace("[sqlmd5]",$sqlmd5,$itemx);
 $fmitem=$fmitem.$itemx;
}
$fmitem=killlaststr($fmitem);
$timeb=time();
$demo=str_replace("<data>",$fmitem,$demo);
$demo=str_replace("[costtime]",($timeb-$timea),$demo);
echo $demo;
     session_write_close();
?>