<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       eval(RESFUNSET("dspbasecoprt"));
$datapath=_get("datapath");
$dpath=$datapath;
$dataval=PV($dpath);
  $dtype=qian($dpath,":");
  $exp=hou($dpath,":");
  switch($dtype){
  case "TAB":
   $dbmk=qian($exp,"@");
   $tbexp=hou($exp,"@");
   $tbnm=qian($tbexp,"/");
   $keyexp=hou($tbexp,"/");
   $reskey=qian(hou($keyexp,"resid_"),":");
   $resval=qian(hou($keyexp,":"),".");
   $askkey=hou($keyexp,".");
   if ($dbmk=="thishostcore"){
    $crst=SX("select clstxt,keytitle from coode_keydetailx where TABLE_NAME='".$tbnm."' and COLUMN_NAME='".$askkey."'");
    $clstxt=anyvalue($crst,"clstxt",0);
    $keytitle=anyvalue($crst,"keytitle",0);
    $tabtitle=UX("select tabtitle as result from coode_tablist where TABLE_NAME='".$tbnm."'");
    if (strpos($clstxt,"key-")>0){
     $ckey=qian(hou($clstxt,"key-"),"]");
     $clstxt=UX("select ".$ckey." as result from ".$tbnm." where ".$reskey."='".$resval."'");
    }else if (strpos($clstxt,"]")>0){
     $stid=str_replace("[","",$clstxt);
     $stid=str_replace("]","",$stid);
     $clstxt=anyshort($stid,"","");     
    }    
    $fmtxt="";
    if ($clstxt!=""){
     $ttt=qian($clstxt,"|");
     $vvv=hou($clstxt,"|");
     $pttt=explode(",",$ttt);
     $ptvv=explode(",",$vvv);
     $totpt=count($pttt);
     for ($jj=0;$jj<$totpt;$jj++){
       $fmtxt=$fmtxt.'"a'.$ptvv[$jj].'":"'.$pttt[$jj].'['.$ptvv[$jj].']",';
     }
     //$ptvv[$jj]
     echo '{"status":"1","clstxt":"'.$clstxt.'","tabtitle":"'.$tabtitle.'","keytitle":"'.$keytitle.'","dataval":"'.$dataval.'"}';
    }else{
     echo makereturnjson("-1","获取失败","");
    }
   }else{
     $dbrst=SX("select dbip,dbus,dbps,dbname from coode_dblist where dbmark='".$dbmk."'");   
     $totdb=countresult($dbrst);
     if ($totdb>0){
      $fip=anyvalue($dbrst,"dbip",0);
      $fuser=anyvalue($dbrst,"dbus",0);
      $fpass=anyvalue($dbrst,"dbps",0);
      $fbase=anyvalue($dbrst,"dbname",0);
      $conn=mysql_connect($fip,$fuser,$fpass);     
      $crst=SX("select clstxt,keytitle from coode_dbkeydx where TABLE_CATALOG='".$dbmk."' and TABLE_NAME='".$tbnm."' and COLUMN_NAME='".$askkey."'");
      $clstxt=anyvalue($crst,"clstxt",0);
      $keytitle=anyvalue($crst,"keytitle",0);
      $tabtitle=UX("select tabtitle as result from coode_dbtablist where TABLE_NAME='".$tbnm."'");
      if (strpos($clstxt,"key-")>0){
       $ckey=qian(hou($clstxt,"key-"),"]");
       $clstxt=updatings($conn,$fbase,"select ".$ckey." as result from ".$tbnm." where ".$reskey."='".$resval."'","utf8");
      }else if (strpos($clstxt,"]")>0){
       $stid=str_replace("[","",$clstxt);
       $stid=str_replace("]","",$stid);
       $_GET["dbmk"]=$dbmk;
       $clstxt=anyshort($stid,"","");
      }       
      if ($clstxt!=""){
        $ttt=qian($clstxt,"|");
        $vvv=hou($clstxt,"|");
        $pttt=explode(",",$ttt);
        $ptvv=explode(",",$vvv);
        $totpt=count($pttt);
        for ($jj=0;$jj<$totpt;$jj++){
         $fmtxt=$fmtxt.'"'.$ptvv[$jj].'":"'.$pttt[$jj].'['.$ptvv[$jj].']",';
        }
       echo '{"status":"1","clstxt":"'.$clstxt.'","tabtitle":"'.$tabtitle.'","keytitle":"'.$keytitle.'","dataval":"'.$dataval.'"}';
      }else{
       echo makereturnjson("-1","获取失败","");
      }    
    }else{
     echo makereturnjson("-1","获取失败","");
    }//totdb
   }  //thishostcore
  break;
  case "DS":
    $dtmk=qian($exp,"@");
    $dsexp=hou($exp,"@");
    $dssno=qian($dsexp,".");
    $dskey=hou($dsexp,".");
    $crst=SX("select clstxt,keytitle from coode_dspckey where datamark='".$dtmark."' and keymark='".$dskey."'");
      $clstxt=anyvalue($crst,"clstxt",0);
      $keytitle=anyvalue($crst,"keytitle",0);
      $tabtitle=UX("select datatitle as result from coode_dataspace where datamark='".$dtmark."'");
    if (strpos($clstxt,"key-")>0){
     $ckey=qian(hou($clstxt,"key-"),"]");
     $keytype=UX("select keytype as result from coode_dspckey where datamark='".$dtmark."'  and keymark='".$ckey."'");
     $clstxt=UX("select ".$keytype."val as result from coode_dspcval where datamark='".$dtmark."' and keymark='".$dskey."' and datasno='".$dssno."'");
    }else if (strpos($clstxt,"]")>0){
     $stid=str_replace("[","",$clstxt);
     $stid=str_replace("]","",$stid);
     $clstxt=anyshort($stid,"","");
    }
    $fmtxt="";
    if ($clstxt!=""){
     $ttt=qian($clstxt,"|");
     $vvv=hou($clstxt,"|");
     $pttt=explode(",",$ttt);
     $ptvv=explode(",",$vvv);
     $totpt=count($pttt);
     for ($jj=0;$jj<$totpt;$jj++){
       $fmtxt=$fmtxt.'"'.$ptvv[$jj].'":"'.$pttt[$jj].'['.$ptvv[$jj].']",';
     }
      echo '{"status":"1","clstxt":"'.$clstxt.'","tabtitle":"'.$tabtitle.'","keytitle":"'.$keytitle.'","dataval":"'.$dataval.'"}';
    }else{
      echo makereturnjson("-1","获取失败","");
    }
   break;
  default:
   echo makereturnjson("-1","获取失败","");
 }
       session_write_close();
?>