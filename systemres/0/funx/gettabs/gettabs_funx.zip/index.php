<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $dbname=dftval(_get("dbname"),"");
$dbip=dftval(_get("dbip"),"");
$dbus=dftval(_get("dbuser"),"");
$dbps=dftval(_get("dbpass"),"");
if ($dbip=="" or $dbus=="" or $dbps==""){
  $dbrst=SX("select dbip,dbus,dbps,dbdomain,UPTM,CRTM,VRT from coode_dblist where dbname='".$dbname."'");
  $totdb=countresult($dbrst);
  $dbip=anyvalue($dbrst,"dbip",0);
  $dbus=anyvalue($dbrst,"dbus",0);
  $dbps=anyvalue($dbrst,"dbps",0);
  $dbdomain=anyvalue($dbrst,"dbdomain",0);
  $uptm=anyvalue($dbrst,"UPTM",0);
  $crtm=anyvalue($dbrst,"CRTM",0);
  $vrt=anyvalue($dbrst,"VRT",0);  
  if (intval($totdb)==0){
  $dbrst=SX("select dbip,dbus,dbps,dbdomain,UPTM,CRTM,VRT from coode_mydblist where dbname='".$dbname."'");
   $totdb=countresult($dbrst);
   $dbip=anyvalue($dbrst,"dbip",0);
   $dbus=anyvalue($dbrst,"dbus",0);
   $dbps=anyvalue($dbrst,"dbps",0);
   $dbdomain=anyvalue($dbrst,"dbdomain",0);
   $uptm=anyvalue($dbrst,"UPTM",0);
   $crtm=anyvalue($dbrst,"CRTM",0);
   $vrt=anyvalue($dbrst,"VRT",0);
  }
}
if ($dbname!="" and $dbip!="" and $dbus!="" and $dbps!=""){
  if (intval($totdb)>0){
   $tbrst=SX("select TABLE_NAME,CRTM,UPTM,VRT from coode_dbtablist where schm='".$dbname."'" );
  }else{
   $tbrst=SX("select TABLE_NAME,CRTM,UPTM,VRT from coode_mydbtablist where schm='".$dbname."'" );
  }
 $conn=mysql_connect($dbip,$dbus,$dbps);
 $result=selecteds($conn,"information_schema","select TABLE_NAME from COLUMNS where TABLE_SCHEMA='".$dbname."' group by TABLE_NAME","utf8","");
 $vmd5=md5($result);
 //$vmd5!=$vrt
 if (1>0){
     $totr=countresult($result);
     $filePath[1] ='系统表';
      $bz[1]="[1]";
      $pid[1]='0';
      $nid[1]='1';
      $filePath[2] ='erp表';
      $bz[2]="[2]";
      $pid[2]='0';
      $nid[2]='2';
      $filePath[3] ='app表';
      $bz[3]="[3]";
      $pid[3]='0';
      $nid[3]='3';
      $filePath[4] ='其他表';
      $bz[4]="[4]";
      $pid[4]='0';
      $nid[4]='4';
   for ($k=0;$k<$totr;$k++){
      $filePath[$k+5] =anyvalue($result,"TABLE_NAME",$k);
      $filenm[$k+5] =anyvalue($result,"TABLE_NAME",$k);
      $bz[$k+5]="[1]".($k+1);
      if (intval($totdb)>0){
        $dbtab="coode_dbtablist";
        $dx="coode_dbkeydx";
        $dy="coode_dbkeydy";
        $dl="coode_dblist";
      }else{
        $dbtab="coode_mydbtablist";
        $dx="coode_mydbkeydx";
        $dy="coode_mydbkeydy";
        $dl="coode_mydblist";
      }
      if (strpos($tbrst,$filenm[$k+5])>0){
       $zz=UX("update ".$dbtab." set UPTM=now(),fip='".$dbip."',fuser='".$dbus."',fpass='".$dbps."',fbase='".$dbname."' where TABLE_NAME='".$filenm[$k+5]."' and schm='".$dbname."'");
      }else{      
       $x=UX("insert into ".$dbtab."(TABLE_NAME,tabtitle,CRTM,UPTM,CRTOR,PTOF,VRT,OLMK,schm,fip,fuser,fpass,fbase)values('".$filenm[$k+5]."','',now(),now(),'".$_COOKIE['uid']."','','','".date('Ymdhis').getRandChar(6)."','".$dbname."','".$dbip."','".$dbus."','".$dbps."','".$dbname."')"); 
      }  
      $pid[$k+5]='4';
       $nid[$k+5]=$k+5;
      if (strpos(".".anyvalue($result,"TABLE_NAME",$k),'coode')>0){
       $pid[$k+5]='1';
       $nid[$k+5]=$k+5;
      };
      if (strpos(".".anyvalue($result,"TABLE_NAME",$k),'erp')>0){
        $pid[$k+5]='2';
        $nid[$k+5]=$k+5;
      };
      if (strpos(".".anyvalue($result,"TABLE_NAME",$k),'".$_COOKIE["cid"]."')>0){
       $pid[$k+5]='3';
       $nid[$k+5]=$k+5;
      };
   }; //for
   $totk=$totr+4;
   $fmbt="";
   $fmbtb="";
   $fmbtc="";
   for  ($p=1;$p<=$totk;$p++){
     $fmbtc=$fmbtc."{\"id\":\"".$nid[$p]."\",\"name\":\"".$filePath[$p]."\",\"pid\":\"".$pid[$p]."\"},";
   };
   $fmbtc="[".substr($fmbtc,0,strlen($fmbtc)-1)."]";
   if ($totk>0){
    $gqsl=UX("select count(*) as result from  ".$dbtab."  where timestampdiff(minute,UPTM,now())>30 and schm='".$dbname."'");    
    if ($totk/(intval($gqsl)+1)>=5){
     $z=UX("delete from  ".$dbtab."  where timestampdiff(minute,UPTM,now())>30 and schm='".$dbname."'");  
     $bx=UX("delete from ".$dx." where TABLE_SCHEMA='".$dbname."' and TABLE_NAME not in(select TABLE_NAME from coode_dbtablist where schm='".$dbname."')");
     $by=UX("delete from ".$dy." where TABLE_SCHEMA='".$dbname."' and TABLE_NAME not in(select TABLE_NAME from coode_dbtablist where schm='".$dbname."')");
    }
   }
   echo $fmbtc; 
   $zz=UX("update ".$dl." set UPTM=CRTM,VRT='".$vmd5."' where dbname='".$dbname."'");
 }else{
 
 }
     
}else{
 $totr=0;
 echo file_get_contents("http://".$dbdomain."/DNA/FUN/1/databasefrm/?dbname=".$dbname);
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>