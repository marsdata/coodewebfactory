<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $fromurl=isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
$tempid=$_GET["tempid"];
$layid=$_GET["layid"];
$fmkeys="";
$fmval="";
$demo0='{"status":"0","msg":"未发现初始化数据","initkey":"","initval":[]}';
$demo1='{"status":"1","msg":"已发现初始化数据","keytps":"(ktps)","keytts":"(ktts)","initkey":"(keys)","initval":[(fmval)]}';
$demo2='{"status":"2","msg":"提交的参数不全","initkey":"","initval":[]}';
if ($tempid=="" or $tempid=="un"."defined"){
  $tempid="default";
}
if (layid=="" or $layid=="un"."defined"  or $tempid=="default" ){
  $trst=SX("select SNO,tinymark,layid from coode_tiny where '".$fromurl."' like concat('%',laypath,'%')");
  $tott=countresult($trst);
  if (intval($tott)>0){
    $layid=anyvalue($trst,"layid",0);
    $tempid=anyvalue($trst,"tinymark",0);
    $demo=$demo1;
  }else{
   if ($layid!=""){
     $demo=$demo1;
   }else{
     $demo=$demo2;
   }
  }
}else{
  $demo=$demo1;
}
$fmktps="";
$fmktts="";
 if ($layid!=""){
   $temprst=SX("select tempid,layid,valtitle,valtype,valkey,valuex from coode_tempinitval where tempid='".$tempid."' and layid='".$layid."'");
   $totr=countresult($temprst);
   if ($totr>0){
    for ($j=0;$j<$totr;$j++){
     $fmkeys=$fmkeys.anyvalue($temprst,"valkey",$j).",";
     $fmktps=$fmktps.anyvalue($temprst,"valtype",$j).",";
     $fmktts=$fmktts.anyvalue($temprst,"valtitle",$j).",";
     $fmval=$fmval.'"'.anyvalue($temprst,"valkey",$j).'":"'.tostring(anyvalue($temprst,"valuex",$j)).'",';
    }   
    $fmkeys=killlaststr($fmkeys);
    $fmktps=killlaststr($fmktps);
    $fmktts=killlaststr($fmktts);
    $fmval=killlaststr($fmval);
    $demo=str_replace("(ktps)",$fmktps,$demo);
    $demo=str_replace("(ktts)",$fmktts,$demo);
    $demo=str_replace("(keys)",$fmkeys,$demo);
    $demo=str_replace("(fmval)",$fmval,$demo);
   }else{
    $demo=$demo0;
   }
 }else{
   $demo=$demo0;
 }
 echo $demo;
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>