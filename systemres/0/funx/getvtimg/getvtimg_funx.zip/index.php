<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $imgvmark=dftval($_GET["imgvmark"],"");
$airst=SX("select SNO,savepath,imgtitle,imgcode,imgsize,imgtype from coode_askimgtask where imgvcode='".$imgvmark."'");
$imgcode=anyvalue($airst,"imgcode",0);
$imgsize=anyvalue($airst,"imgsize",0);
$imgtype=anyvalue($airst,"imgtype",0);
$imgtitle=anyvalue($airst,"imgtitle",0);
echo '{"status":"1","msg":"成功","imgtitle":"'.$imgtitle.'","imgcode":"'.$imgcode.'","imgsize":"'.$imgsize.'","imgtype":"'.$imgtype.'"}';
     session_write_close();
?>