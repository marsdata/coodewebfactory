<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sno=$_GET["SNO"];
$trst=SX("select layid,tinymark from coode_tiny where SNO=".$sno);
$layid=anyvalue($trst,"layid",0);
$tinyid=anyvalue($trst,"tinymark",0);
$trsno=UX("select SNO as result from coode_askdata where layid='".$layid."' and tinyid='".$tinyid."' and datamark not like '%@%'");
if ($trsno!=""){
  header("location:/localxres/tempx/htmleditor/index.html?funid=coode_askdata@SNO:".$trsno.".kreturn");
}else{
  header("location:/localxres/csspagex/404/black/failure.html?funid=coode_askdata@SNO:".$trsno.".kreturn");
}
     session_write_close();
?>