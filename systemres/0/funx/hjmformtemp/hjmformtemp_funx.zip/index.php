<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include mdir().'RNA/EARTH.php';
    $stk=$_GET["stk"];
    if (strpos(_get("fid"),"login")<=0){
     setcookie("uid",$_COOKIE["uid"],time()+3600,"/");
     setcookie("cid",$_COOKIE["cid"],time()+3600,"/");
     setcookie("uid",$_COOKIE["userid"],time()+3600,"/");
     setcookie("cid",$_COOKIE["comid"],time()+3600,"/");
     setcookie("grpcid",$_COOKIE["grpcid"],time()+3600,"/");
     setcookie("depart",$_COOKIE["depart"],time()+3600,"/");
     setcookie("dpmore",$_COOKIE["dpmore"],time()+3600,"/");
     setcookie("posids",$_COOKIE["posids"],time()+3600,"/");
     setcookie("roleids",$_COOKIE["roleids"],time()+3600,"/");
     setcookie("sysid",$_COOKIE["sysid"],time()+3600,"/");
     setcookie("stoken",$_COOKIE["stoken"],time()+3600,"/");
     setcookie("deadline",time()+3600,time()+3600,"/");
    }
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $mnum=$_GET["mnum"];
  $dtlrst=SX("select srcArea,srcID,eqmCode,eqmLcCode,srcTitle,mSize,mVersion,mVender,inDepart,inDptID,muser,itemCrtID,inPlace,mType,linkMan,lMPos,lMTel,svsMan,sMPos,sMTel,hbPackUrl,bePackUrl from gmc_mmCls where eqmCode='tempcode'");
  $srcarea=anyvalue($dtlrst,"srcArea",0);
  $srcid=anyvalue($dtlrst,"srcID",0);
  $eqmcode=anyvalue($dtlrst,"eqmCode",0);
  $eqmlccode=anyvalue($dtlrst,"eqmLcCode",0);
  $srctitle=$_GET["srctitle"];
  $msize=anyvalue($dtlrst,"mSize",0);
  $mversion=anyvalue($dtlrst,"mVersion",0);
  $mvender=anyvalue($dtlrst,"mVender",0);
  $indepart=anyvalue($dtlrst,"inDepart",0);
  $indptid=anyvalue($dtlrst,"inDptID",0);
  $muser=anyvalue($dtlrst,"muser",0);
  $itemcrtid=anyvalue($dtlrst,"itemCrtID",0);
  $inplace=anyvalue($dtlrst,"inPlace",0);
  $mtype=anyvalue($dtlrst,"mType",0);
  $linkman=anyvalue($dtlrst,"linkMan",0);
  $lmpos=anyvalue($dtlrst,"lMPos",0);
  $lmtel=anyvalue($dtlrst,"lMTel",0);
  $svsman=anyvalue($dtlrst,"svsMan",0);
  $smpos=anyvalue($dtlrst,"sMPos",0);
  $smtel=anyvalue($dtlrst,"sMTel",0);
  $hbpackurl=anyvalue($dtlrst,"hbPackUrl",0);
  $bepackurl=anyvalue($dtlrst,"bePackUrl",0);
  $billid=onlymark();
  $editpass=UX("select editPass as result from coode_userlist where userid='".$itemcrtid."'");
  $sqla="srcArea,srcID,srcTitle,eqmID,eqmTitle,eqmSize,mType,itemCTime,itemUTime,muser,itemCrtID";
  $sqlb="'".$srcarea."','".$billid."','".$srctitle.date("Y-m-d H:i:s")."','".$eqmcode."','".$srctitle."','".$msize."','".$mtype."',now(),now(),'".$muser."','".$itemcrtid."'";
  $dd=UX("insert into gmc_eqmbill(".$sqla.")values(".$sqlb.")");
  $sqlx="srcArea,srcID,eqmCode,eqmLcCode,srcTitle,mSize,mVersion,mType,linkMan,lMPos,lMTel,svsMan,sMPos,sMTel,hbPackUrl,bePackUrl,mVender,inDepart,inDptID,muser,itemCrtID,inPlace,itemCTime,itemUTime,itemOnlyMark,mCode,billID,editPass";
  $sqly="'".$srcarea."','".$srcid."','".$eqmcode."','".$eqmlccode."','".$srctitle."','".$msize."','".$mversion."','".$mtype."','".$linkman."','".$lmpos."','".$lmtel."','".$svsman."','".$smpos."','".$smtel."','".$hbpackurl."','".$bepackurl."','".$mvender."','".$indepart."','".$indptid."','".$muser."','".$itemcrtid."','".$inplace."',now(),now(),'".onlymark()."',";
  for ($i=0;$i<intval($mnum);$i++){
   $extx=1;
   $hjmc=hmcode();
   while (intval($extx)==1){
    $hjmc=hmcode();
    $extx=UX("select count(*) as result from gmc_manmachine where srcArea='".$srcarea."' and mCode='".$hjmc."'");
   }
   $sqlz=$sqly."'".$hjmc."','".$billid."','".$editpass."'";
   $z=UX("insert into gmc_manmachine(".$sqlx.")values(".$sqlz.")");
  }
  $totbill=UX("select count(*) as result from gmc_eqmbill where eqmID='".$srcid."'");
  $totact=UX("select count(*) as result from gmc_manmachine where srcID='".$srcid."'");
  $z=UX("update gmc_eqmbill set totBill='".$totbill."',totAct='".$totact."' where eqmID='".$srcid."'");
  $z=UX("update gmc_manmachine set totBill='".$totbill."',totAct='".$totact."' where srcID='".$srcid."'");
eval(CLASSX("makeqrcode"));
$mq=new makeqrcode();
$gmcrst=SX("select sNo,srcArea,mCode from gmc_manmachine where itemOprt='' ");
$totrst=countresult($gmcrst);
$totleft=$total-$totrst;
 for ($i=0;$i<$totrst;$i++){
   $snox=anyvalue($gmcrst,"sNo",$i);
   $srcarea=anyvalue($gmcrst,"srcArea",$i);
   $mcode=anyvalue($gmcrst,"mCode",$i);
   $url="http://kitty.halo123.cn/DNA/EXF/anyfuns.php?fid=gotohjm&mcode=".$srcarea.$mcode;
   $qmark=$srcarea."-".$mcode;
   $q=$mq->makecode($qmark,"string",$url,"",$srcarea,$mcode);
   $zz=UX("update gmc_manmachine set itemOprt=1 where sNo=".$snox);
 }
 $zz=UX("update gmc_manmachine,coode_qrcodeurl set gmc_manmachine.mQrUrl=coode_qrcodeurl.qrimgurl,gmc_manmachine.mQrData=coode_qrcodeurl.qrimgbase64 where gmc_manmachine.srcArea=coode_qrcodeurl.bdomain and gmc_manmachine.mCode=coode_qrcodeurl.bmark and gmc_manmachine.mQrUrl=''");
   $snox=$_GET["SNO"];   
   $dtlrst=SX("select srcArea,srcID,eqmCode,eqmLcCode,srcTitle,mSize,mVender,inDepart,inPlace,mType,linkMan,lMPos,lMTel,svsMan,sMPos,sMTel,hbPackUrl,bePackUrl from gmc_mmCls where sNo=".$snox);
   $srcarea=anyvalue($dtlrst,"srcArea",0);
   $srcid=anyvalue($dtlrst,"srcID",0);
   $eqmcode=anyvalue($dtlrst,"eqmCode",0);
   $eqmrst=SX("select sNo,mCode from gmc_manmachine where srcArea='".$srcarea."' and eqmCode='".$eqmcode."'");
   $tote=countresult($eqmrst);
   for ($m=0;$m<$tote;$m++){
    $mcd=anyvalue($eqmrst,"mCode",$m);
    $zz=UX("insert into gmc_mmOFware(srcHeadImg,srcArea,srcID,eqmCode,eqmLcCode,orgID,orgTitle,orgType,itemCTime,itemUTime,itemPUTime,mCode,muser,itemCrtID)select srcHeadImg,srcArea,srcID,eqmCode,eqmLcCode,orgID,orgTitle,orgType,itemCTime,itemUTime,itemPUTime,'".$mcd."',muser,'".$itemcrtid."' from gmc_mmCOFware where     srcArea='".$srcarea."' and eqmCode='".$eqmcode."'");
   }
   $apikey=UX("select apikey as result from gmc_userdblist where muser='".$muser."'");
   if ($apikey!=""){
     $zv=UX("update gmc_manmachine set srcID=concat(srcArea,'.',mCode),hbPackUrl=concat('http://".glw()."DNA/EXF/anyfuns.php?fid=heartbeat&mcode=',mCode,'&apikey=".$apikey."'),bePackUrl=concat('http://".glw()."DNA/EXF/anyfuns.php?fid=mfunaction&mcode=',mCode,'&apikey=".$apikey."') where muser='".$muser."'");
   }
   $mx=clearvarlike("gmc_manmachine");
   $my=clearvarlike("gmc_mmOFware");
   $mz=clearvarlike("gmc_mmCOFware");
echo makereturnjson("1","成功","");
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>