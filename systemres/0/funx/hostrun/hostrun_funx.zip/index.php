<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $host=_get("host");
 $fid=_get('fid');
 $fmqry="";
 $fmpost="";
 $qrykey=_get("qrykey");
 $postkey=_get("postkey");
 if ($qrykey!=""){
  if (strpos($qrykey,",")>0){
    $ptqry=explode(",",$qrykey);    
    for ($j=0;$j<count($ptqry);$j++){
      $fmqry=$fmqry.$ptqry[$j]."=".$_GET[$ptqry[$j]]."&";
    }
  }else{
    $fmqry=$qrykey."=".$_GET[$qrykey];
  }
 }
 if ($postkey!=""){
  if (strpos($postkey,",")>0){
    $ptpost=explode(",",$postkey);    
    for ($j=0;$j<count($ptpost);$j++){
      $fmpost=$fmqry.$ptpost[$j]."=".$_POST[$ptpost[$j]]."&";
    }
  }else{
    $fmpost=$postkey."=".$_POST[$postkey];
  }
 }
 echo anyfunrun($fid,$host,$fmqry,$fmpost);
     session_write_close();
?>