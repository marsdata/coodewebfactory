<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $host=_get("host");
 $stidd=_get('stid');
  $dbmark=_get('dbmark');
 if (strpos($stidd,"]")>0){
  $stidd=str_replace("[","",$stidd);
  $stidd=str_replace("]","",$stidd);
 };
 $pagee=_get('page');
 if (intval($pgn)>0){
   $pagenumm=$pgn;
 }else{
   $pagenumm=_get('pnum');
 }
 if (_get("pnu")=="0"){
  $pagenumm=""; 
  $pagee="";
 }
 echo anyfunrun("anyshort",$host,"stid=".$stidd."&dbmark=".$dbmark."&page=".$pagee."&pnum=".$pagenumm."&qry="._get("qry")."&dataype="._get("datatype"),"");
     session_write_close();
?>