<?php
function gl(){return "[cdip]";}//DESCRIB glb():本系统mysql 数据库IP END@glb()
function glu(){return "[cduser]";}//DESCRIB glu():本系统mysql 数据库用户名 END@glu()
function glp(){return "[cdpass]";}//DESCRIB glp():本系统mysql 数据库密码 END@glp()
function glb(){return "[cdbase]";}//DESCRIB glb():本系统mysql 数据库 END@lgb()
function gln(){return "[firstsys]";}//DESCRIB gln():当前使用系统名称 END@gln()
function gla(){return "[ak]";}//DESCRIB gla():当前apikey END@gln()
function glv(){return "[av]";}//DESCRIB glv():当前api verfy 使用系统版本号 END@gln()
function glt(){return "[sitename]";}//DESCRIB glt():当前实例名称 END@glt()
function glm(){return "[motherhost]";}//DESCRIB glm():母系统域名 END@glt() localhost 为本地模式不联网
function hostcode(){return "[hostcode]";}//DESCRIB glr():授权注册码 END@glt() 申请试用后，提供服务器IP地址，给您安装，转移操作
function runblog(){return "[runblog]";}//日志记录是否开启
function runprocess(){return "[runprocess]";}//日志记录是否开启
function remoteway(){return "[remoteway]";}//远程模式，可以上传资源到母机
function bl(){return "[bdip]";}//DESCRIB glb():业务系统mysql 数据库IP END@glb()
function blu(){return "[bduser]";}//DESCRIB glu():业务系统mysql 数据库用户名 END@glu()
function blp(){return "[bdpass]";}//DESCRIB glp():业务系统mysql 数据库密码 END@glp()
function blb(){return "[bdbase]";}//DESCRIB glb():业务系统mysql 数据库 END@lgb()
function bln(){return "[secondsys]";}//DESCRIB gln():当前业务使用系统名称 END@gln()
function blt(){return "[bussname]";}//DESCRIB glt():当前实例名称 END@glt()
//-------------配置分界线
function _get($str){ $val = !empty($_GET[$str]) ? $_GET[$str] : ""; return $val; } //DESCRIB ():  END@()

function _post($str){ $val = !empty($_POST[$str]) ? $_POST[$str] : ""; return $val; } //DESCRIB ():  END@()

function _server($str){$val = !empty($_SERVER[$str]) ? $_SERVER[$str] : ""; return $val; }//DESCRIB ():  END@()

function _cookie($str){$val = !empty($_COOKIE[$str]) ? $_COOKIE[$str] : ""; return $val; }//DESCRIB ():  END@()

function _session($str){$val = !empty($_SESSION[$str]) ? $_SESSION[$str] : "";   return $val; }//DESCRIB ():  END@()

function cdfile($rurl,$lcfile){$ch=curl_init($rurl);$downloadPath=$lcfile;$downloadPathName=$downloadPath;$lcpath=urltopath($lcfile);is_dir($lcpath) OR mkdir($lcpath, 0777, true); $fp=fopen($downloadPathName,'wb') or die('open failed!');curl_setopt($ch,CURLOPT_FILE,$fp);curl_setopt($ch,CURLOPT_HEADER,0);$res=curl_exec($ch);curl_close($ch);fclose($fp); }//新建或打开文件,将curl下载的文件写入文件

function combineurl($qu,$hu){if (substr($qu,-1)=="/"){$qu=killlaststr($qu);}if (substr($hu,0,1)=="/"){return $qu.$hu;}else{return $qu."/".$hu;}}//DESCRIB ():  END@()

function countresult($fullresult){if (strpos($fullresult,"数据库报错")<=0){$partkn=explode("#/#",$fullresult);$countkn=count($partkn);return $countkn-2;}else{return 0;}}//DESCRIB ():  END@()

function RESFUNSET($setid){
    $allowed_domains = [$_SERVER["HTTP_HOST"], 'divlovecss.com'];
if (!check_domain($allowed_domains)) {
    die('Unauthorized domain.');
}
$start_date = '1987-11-23';
$end_date = '2099-12-31';
if (!check_time($start_date, $end_date)) {
    die('The script is not available at this time.');
}
  if (strpos("xxx".$_GET["setonlyonce"],$setid."/")>0){
      $setxyz="";
      $setrst="";
  }else{
       if (file_exists(combineurl(localroot(),"/localxres/sfunx/".$setid."/index.php"))){
           include combineurl(localroot(),"/localxres/sfunx/".$setid."/index.php");
        }else{ 
           $setrst=SX("select funbody,OLMK from coode_funsetfile where setname='".$setid."' or  setname='".$setid."()'");
           $totset=countresult($setrst);
          if (intval($totset)>0 and anyvalue($setrst,"funbody",0)!=""){
              $setxyz=anyvalue($setrst,"funbody",0); 
          }
          $setrst=tostring($setxyz);
        }
  };
  if ($_GET["setonlyonce"]=="" ){
      $_GET["setonlyonce"]=$setid."/";
      $_SESSION["setonlyonce"]=$setid."/";
  }else{
     $_GET["setonlyonce"]=$_GET["setonlyonce"].$setid."/";
  };
  return $setrst;
}//DESCRIB ():也可以远程获取 如果已存在了运行了一次就不在运行 class  END@()

function glw(){
    if ($_SERVER["SERVER_PORT"] == "80"){
      return $_SERVER["HTTP_HOST"]."/";
    }else{
      return $_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"]."/";  
    }
}//DESCRIB glw():本服务器域名  结尾要加/ 如果没有域名请用本机分配的固定IP,结尾也要加/ END@glw()

function getRandChar($length){$str = null;$strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";$max = strlen($strPol)-1;for($i=0;$i<$length;$i++){$str.=$strPol[rand(0,$max)]; }return $str;}

function huanhang(){return "\r\n";}//DESCRIB ():  END@()

function hou($fullstr,$astr){if ($fullstr!="" and $astr!=""){$cunzaibu=strpos("x".$fullstr,$astr);if ($cunzaibu>0 ){$spos=strpos($fullstr,$astr);$lens=strlen($astr);$alll=strlen($fullstr);return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));}else{return $fullstr;};}else{return "";}}//DESCRIB (): 完美兼容中文混合取字符串后面 END@()

function killlaststr($strx){ return substr($strx,0,strlen($strx)-1);}

function localroot(){if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){$gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";}else{$gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);};if (strpos($gml,":")>0){$qdq=qian($gml,":");$gml=strtoupper($qdq).":".hou($gml,":");};return $gml;}//DESCRIB localroot(): 获取本地根目录 END@localroot()

function mysql_connect($fi,$fu,$fp){return new mysqli($fi,$fu,$fp);}//DESCRIB mysql_connect(): 连接数据库方法，如果是php5.5- 去掉此函数并修改select相关方法 END@mysql_connect()

function qian($fullstr,$astr){if ($fullstr!="" and $astr!=""){$cunzaibu=strpos("x".$fullstr,$astr);if ($cunzaibu>0 ){$astrlen=strpos($fullstr,$astr);$fmrt=substr($fullstr,0,$astrlen);return $fmrt;}else{return $fullstr;}}else{return "";}}//DESCRIB qian(): 完美兼容中文混合 END@qian()

function SX($asqlstr){$conn=mysql_connect(gl(),glu(),glp());return selecteds($conn,glb(),$asqlstr,"utf8","");}//DESCRIB ():  END@()

function String2Hex($string){if (substr($string,0,10)=="dTYPE_HEX:"){return $string;}else{$hex='';for ($i=0; $i < strlen($string); $i++){$hex .= dechex(ord($string[$i]));}return $hex;}}

function urltopath($url){$ptxyz=explode("/",$url);$totp=count($ptxyz);$lslen=strlen($ptxyz[$totp-1]);return substr($url,0,strlen($url)-$lslen);}//DESCRIB ():  END@()

function UX($asqlstr){$conn=mysql_connect(gl(),glu(),glp());return updatings($conn,glb(),$asqlstr,"utf8");}//DESCRIB ():  END@()

function onlymark(){
   return makeguid();
}//DESCRIB ():  END@()


function es($strx){
    $strx=str_replace(" ","",$strx);
    $strx=str_replace("un"."defined","",$strx);
    if ($strx!=""){
        return 1;
    }else{
        return 0;
    }
}

function maketiny($tinyid,$rfr){
    if ($rfr!=""){
      return "/localxres/funx/anytiny/?tinyi==".$tinyid."&refresh=".$rfr;
    }else{
      return "/localxres/funx/anytiny/?tiny=".$tinyid; 
    }
}

function dftval($valx,$valy){
    if (notemptyb($valx)){
        return $valx;
    }else{
        return $valy;
    }
}

function tostring($vlsx){
  if (strpos("x".$vlsx,"TYPE_HEX:")>0){
    $houvlx=Hex2String(hou($vlsx,"TYPE_HEX:"));
    $houvlx=str_replace("-r-n","\r\n",str_replace("\\'","'",$houvlx));
    return str_replace("-/-/","\\",$houvlx);
  }else{
    $vlsx=str_replace("-r-n","\r\n",str_replace("\\'","'",$vlsx));
    return str_replace("-/-/","\\",$vlsx);
  };
}


function unstrs($gfstring){
  if ($gfstring!=""){
    $gftxt=str_replace('«','<'.'?'.'p'.'hp',$gfstring);
    $gftxt=str_replace('»','?'.'>',$gftxt);
    $gftxt=str_replace("^","'",$gftxt);
    $gftxt=str_replace("卍卍","\r\n",$gftxt);
    $gftxt=str_replace("卍","\r\n",$gftxt);
    $gftxt=str_replace("\\\"","\"",$gftxt);
    $gftxt=str_replace('\\','',$gftxt);
    $gftxt=str_replace("δ","&",$gftxt);
    $gftxt=str_replace("&amp;","&",$gftxt);
    $gftxt=str_replace("＝","=",$gftxt);
    $gftxt=str_replace('？','?',$gftxt);
    $gftxt=str_replace("＋","+",$gftxt);
    $gftxt=str_replace("/r/n","\r\n",$gftxt);
    $gftxt=str_replace("|~","\"",$gftxt); //要转义的 ""
    $gftxt=str_replace('/~','\"',$gftxt); //不转
    $gftxt=str_replace('@r@n','".\'\r\n\'."',$gftxt);
    $gftxt=str_replace('/-r/-n','\r\n',$gftxt);
    $gftxt=str_replace("↘","\\",$gftxt);
    return $gftxt;
   }else{
    return "";
   }
  }
  
function downanyfile($usrc,$mysrc){//文件存不存在都下载，覆盖原来
  if ($usrc!="" and $mysrc!=""){
    $pathmy=urltopath($mysrc);
    $ptmy=explode(".",$mysrc);
    $totpt=count($ptmy);
    $kzm=$ptmy[$totpt-1];
    
   is_dir($pathmy) OR mkdir($pathmy, 0777, true); 
      switch($kzm){
        case "css":
          $z=overfile($mysrc,file_get_contents($usrc));
        break;
        case "js":
          $z=overfile($mysrc,file_get_contents($usrc));
        break;
        case "json":
          $z=overfile($mysrc,file_get_contents($usrc));
        break;
        case "html":
          $z=overfile($mysrc,file_get_contents($usrc));
        break;
        case "htm":
          $z=overfile($mysrc,file_get_contents($usrc));
        break;
        case "gif":
          GrabImage($usrc, $mysrc);
        break;
        case "jpg":
          GrabImage($usrc, $mysrc);
        break;
        case "png":
          GrabImage($usrc, $mysrc);
        break;
        case "svg":
          $z=overfile($mysrc,file_get_contents($usrc));
        break;
        case "woff":          
          $z=cdfile($usrc,$mysrc);
        break;
        case "woff2":
          $z=cdfile($usrc,$mysrc);
        break;
        case "font":
          $z=cdfile($usrc,$mysrc);
        break;
        case "ttf":
          $z=cdfile($usrc,$mysrc);
        break;
        case "wav":
          $z=cdfile($usrc,$mysrc);
        break;
        case "mp3":
          $z=cdfile($usrc,$mysrc);
        break;
        case "zip":
          $z=cdfile($usrc,$mysrc);
        break;
        case "rar":
          $z=cdfile($usrc,$mysrc);
        break;
        default:            
      }//     switch      
      if (file_exists($mysrc)){
        return true;
      }else{
        return false;
      }
  }else{
    return false;
  }
}

function anyvalue($fullresult,$keynm,$sqc)
{
  $keyname=qian($fullresult,"#/#");
  $partkn=explode("#-#",$keyname);
  $partresult=explode("#/#",$fullresult);
  $countprs=count($partresult);
  $countkn=count($partkn);
  $tempkey=0;
  for ($x=0;$x<=$countkn-1;$x++)
   {
    if ($partkn[$x]==$keynm)
    {
     $tempkey=$x;
     };
   };
  $sqcresult=$partresult[$sqc+1];
  $partpart=explode("#-#",$sqcresult);
  return $partpart[$tempkey];
}//DESCRIB ():  END@()

function makenew($tabx,$tkeys,$tvals){
    if ($tvals!="" and $tabx!="" and $tkeys!=""){
        $z=UX("insert into ".$tabx."(".$tkeys.")values(".$tvals.")");
        return true;
    }else{
        return false;
    }
}

function spacex($nx){
    $tmpx="";
    for ($i=0;$i<$nx;$i++){
        $tmpx=$tmpx." ";
    }
    return $tmpx;
}


function getip(){
global $ip;
if (getenv("HTTP_CLIENT_IP"))
  $ip = getenv("HTTP_CLIENT_IP");
 else if(getenv("HTTP_X_FORWARDED_FOR"))
  $ip = getenv("HTTP_X_FORWARDED_FOR");
 else if(getenv("REMOTE_ADDR"))
  $ip = getenv("REMOTE_ADDR");
 else $ip = "Unknow";
return $ip;
}//DESCRIB ():  END@()


function updating($con,$db,$sqlstr){
//mysql_select_db($db, $con);
$con -> query("set names 'utf8'"); //数据库输出编码 
$con -> select_db($db); //打开数据库
$result = $con->query($sqlstr); //查询成功
//$result = mysql_query($sqlstr);
 if (strpos($sqlstr,"result")>0)
  {
  if ($result){
    while($row = mysqli_fetch_array($result))
    {
     mysqli_close($con);
     return empty($row["result"])?"":$row["result"];
    }
  }else{
    $sqlerror=mysqli_error($con);
     mysqli_close($con);
    return "failure:SE-".$sqlerror."@".$sqlstr;
  }
 }else
 {
   mysqli_close($con);
   return $result?1:0;
  }; 
}//DESCRIB ():  END@()

function updatingx($con,$db,$sqlstr,$lan){
 //mysql_select_db($db, $con);
 //mysql_query("SET NAMES ".$lan);    
 if (gettype($con)=="object" and $con){
 $con -> query("set names '".$lan."'"); //数据库输出编码
 $con -> select_db($db); //打开数据库
 $result = $con->query($sqlstr); //查询成功
//$result = mysql_query($sqlstr);
  if (strpos($sqlstr,"result")>0){
   if ($result){
      while($row = mysqli_fetch_array($result))
      {
        mysqli_close($con);
        return empty($row["result"])?"":$row["result"];
      }
   }else{
     $sqlerror=mysqli_error($con);
     mysqli_close($con);  
     return "failure:SE-".$sqlerror."@".$sqlstr;
   }
  }else{
   mysqli_close($con);
   return $result?1:0;
  };
 }else{
  if (gettype($con)=="object"){
   return "failure:SE-".mysqli_error();
  }else{
  //远程
   $purl="http://".$con["host"]."/localxres/funx/updatingx/?db=".$db."&uid=".glr();
   $pdata=array();
   $pdata["sqlstr"]=$sqlstr;
   return request_post($purl,$pdata);
  }
 } 
}//DESCRIB ():  END@()


function selected($con,$db,$sqlstr,$way){
 $formrt="";
 $partsql=get_between($sqlstr,"elect "," from");
 $partk=explode(",",$partsql);
 $totkey=count($partk);
 //mysql_select_db($db, $con);
 //mysql_query("SET NAMES GB2312"); 
 //$result = mysql_query($sqlstr);
  $con -> query("set names '".$lan."'"); //数据库输出编码
  $con -> select_db($db); //打开数据库
  $result = $con->query($sqlstr); //查询成功  
 for ($x=0;$x<=$totkey-1;$x++)
  {
   if ($x<$totkey-1)
    {
     $formrt=$formrt.str_replace(" ","",$partk[$x])."#-#";
    }
   else
   {
    $formrt=$formrt.str_replace(" ","",$partk[$x]);
    };
 };
$formrt=$formrt."#/#";
while($row = mysqli_fetch_array($result))
  {
   for ($x=0;$x<=$totkey-1;$x++)
   {
    if ($x<$totkey-1)
     {
      $formrt=$formrt.$row[$partk[$x]]."#-#";
     }
     else
     {
      $formrt=$formrt.$row[$partk[$x]];
      };
   };
  $formrt=$formrt."#/#";
  };
 mysqli_close($con);
 return $formrt;
 }//DESCRIB ():  END@()

function updatings($con,$fb,$sqlx,$lag){
  $fmwhere="";
if (strpos("x".$sqlx,"select")>0 or strpos("x".$sqlx,"update")>0 or strpos("x".$sqlx,"insert")>0  or strpos("x".$sqlx,"delete")>0){
   $ddrst=updatingx($con,$fb,$sqlx,$lag);
}else{
  $_GET["UPDTSTR"]=_get("UPDTSTR");
 if (strpos("xxx".$_GET["UPDTSTR"],$fb.$sqlx)>0){
   $ddrst="failure:die to repeat in ".$fb."-running_".$sqlx;
 }else{
  if (strpos("x".$sqlx,"UPDATE ")>0 and strpos("x".$sqlx," SET ")>0 ){
  //发现修改 先检查是否真的变动了，如果没有变动则跳过不然后边有好多访问数据请求浪费时间  

    $_GET["tbnm"]=qian(hou($sqlx,"UPDATE ")," SET ");
    $_GET["tbnm"]=str_replace(" ","",$_GET["tbnm"]);
    $prisno=UX("select mainsqx as result from coode_tablist where TABLE_NAME='".$_GET["tbnm"]."'");
    $gsno=hou($sqlx,$prisno."=");
    $gsno=str_replace(" ","",$gsno);
    $gsno=str_replace(")","",$gsno);
    $gsno=str_replace("'","",$gsno);
    $_GET["SNO"]=$gsno;
    $sqlstr=qian(hou($sqlx," SET ")," WHERE ");
    $cstj=hou($sqlx," WHERE ");
    //用这个判断就可以
    $ptsql=explode(",",$sqlstr);
    $totp=count($ptsql);
    $fmallkx="";
    $evx="";
   // echo "SNO=".$gsno;
  if ($totp>0 and $sqlstr!=""){
    for ($z=0;$z<$totp;$z++){
      $pppx=$ptsql[$z];
      $tkkk=qian($pppx,"=");
      $tvvv=hou($pppx,"=");
      $fmallkx=$fmallkx.$tkkk.",";
      if (substr($tvvv,0,1)=="'" or substr($tvvv,-1)=="'"){
        $evx='$_POST[\'p_'.$tkkk.$gsno.'\']='.$tvvv.';';
        $fmwhere=$fmwhere." and ".$ptsql[$z];
      }else{
        $tvvv="'".$tvvv."'";
        $evx='$_POST[\'p_'.$tkkk.$gsno.'\']='.$tvvv.';';
        $fmwhere=$fmwhere." and ".$ptsql[$z];
      }
     // echo $evx."---";
      eval($evx);      
    }//for    //单个接受字段里如果有,逗号会被分割
  //  echo $fmwhere."--";
  }else{//totp!>0
      $pppx=$sqlstr;
      $tkkk=qian($pppx,"=");
      $tvvv=hou($pppx,"=");
      $fmallkx=$fmallkx.$tkkk.",";
      if (substr($tvvv,0,1)=="'" or substr($tvvv,-1)=="'"){
        $evx='$_POST[\'p_'.$tkkk.$gsno.'\']='.$tvvv.';';
        $fmwhere=$fmwhere." and ".$ptsql[$z];
      }else{
        $tvvv="'".$tvvv."'";
        $evx='$_POST[\'p_'.$tkkk.$gsno.'\']='.$tvvv.';';
        $fmwhere=$fmwhere." and ".$ptsql[$z];
      }
     // echo $evx."---";
      eval($evx);      
    };//if    
    $fmwhere=$cstj.$fmwhere;
    $fmallkx=substr($fmallkx,0,strlen($fmallkx)-1);  
    $_GET["kies"]=$fmallkx;
    $_GET["kies"]=str_replace(" ","",$_GET["kies"]);
   //$frst=anyfunrun("anyrcv",$_GET["appid"],"");
  }else{//update
   if (strpos("x".$sqlx,"INSERT ")>0 and strpos("x".$sqlx," INTO ")>0){
    //发现新增
    $_GET["SNO"]="0";
    $_GET["tbnm"]=qian(hou($sqlx,"INTO "),"(");
    $_GET["tbnm"]=str_replace(" ","",$_GET["tbnm"]);
    $_GET["kies"]=qian(hou($sqlx,$_GET["tbnm"]."("),")VALUES");
    $_GET["kies"]=str_replace(" ","",$_GET["kies"]);
    $allkx=$_GET["kies"];
    $allvx=hou($sqlx,"VALUES(");
    $allvx=substr($allvx,0,strlen($allvx)-1);
    //为什么只用一个HOU因为后面的括号有可能是值所以一个括号容易出错
    $ptkx=explode(",",$allkx);
    $ptvx=explode(",",$allvx);
    $totp=count($ptkx);
    $evx="";
    if ($totp>0 and $allvx!=""){
     for ($z=0;$z<$totp;$z++){
      if (substr($ptvx[$z],0,1)=="'"){
        $evx='$_POST[\'p_'.$ptkx[$z].'0\']='.$ptvx[$z].';';
      }else{
        $ptvx[$z]="'".$ptvx[$z]."'";
        $evx='$_POST[\'p_'.$ptkx[$z].'0\']='.$ptvx[$z].';';
      }
      eval($evx);      
     }
    }
  }else{//insert
    //未发现 则执行查询
    if (strpos("x".$sqlx,"DELETE ")>0 and strpos("x".$sqlx," FROM ")>0){
       $_GET["tbnm"]=qian(hou($sqlx,"FROM ")," WHERE ");       
       $_GET["kies"]="-killitem";
       $gcdt=hou($sqlx,"where ");
       if ($gsno!=""){
         $gcdt=" SNO=".$gsno;
       }else{
         if ($golmk!=""){
           $gcdt=" OLMK='".$golmk."'";
         }else{
         }
       }
      $gcdt=str_replace(" ","",$gcdt);
      if (strpos($gcdt,"=")>0 or strpos($gcdt,"like")>0){       
        $_GET["killcdt"]=$gcdt;
      }else{
        $_GET["killcdt"]="";
      }
    }else{   //delete  
    }//delete
   }//insert 
  }  //update
  
    if ($_GET["UPDTSTR"]==""){//这个判断防止死循环
      $_GET["UPDTSTR"]=$fb.$sqlx;
    }else{
      $_GET["UPDTSTR"]=$_GET["UPDTSTR"]."/".$fb.$sqlx;
    }
    if ($fmwhere==""){
     $ddrst=makercv();
    }else{
      $conn=mysql_connect(gl(),glu(),glp());
      $dontchange=updatingx($conn,glb(),"select count(*) as result from ".$_GET["tbnm"]." where ".$fmwhere,"utf8");
      if ($dontchange*1>0){//没变一样，就不执行makercv 不然太耗时间
        //$ddrst=updatingx($con,$fb,$sqlx,$lag); 啥也不执行
        $ddrst="select count(*) as result from ".$_GET["tbnm"]." where ".$fmwhere;
      }else{
        $ddrst=makercv();
      }
    }
  }
 }//防止死循环 
 return $ddrst;
}//DESCRIB ():  END@()



function selecteds($con,$fb,$sqlx,$lag,$ext){
 $frst=selectedx($con,$fb,$sqlx,$lag,$ext);  
//先存贮这里,到一定时间转储,半夜的时候如果有人访问则判断;
 return $frst;
}//DESCRIB ():  END@()

function request_post($url = '', $post_data = array()) {
        if (empty($url) || empty($post_data)) {
            return false;
        }

        $o = "";
        foreach ( $post_data as $k => $v ) 
        { 
            $o.= "$k=" . urlencode( $v ). "&" ;
        }
        $post_data = substr($o,0,-1);
        $postUrl = $url;
        $curlPost = $post_data;
        $ch = curl_init();//初始化curl
        curl_setopt($ch, CURLOPT_URL,$postUrl);//抓取指定网页
        curl_setopt($ch, CURLOPT_HEADER, 0);//设置header
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//要求结果为字符串且输出到屏幕上
        curl_setopt($ch, CURLOPT_POST, 1);//post提交方式
        curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
        $data = curl_exec($ch);//运行curl
        curl_close($ch);
        return $data;
    }
    
function makereturnjson($sttx,$msgx,$rdrurl){
    if ($sttx!="" and $msgx!=""){
        return '{"status":"'.$sttx.'","msg":"'.$msgx.'","redirect":"'.$rdrurl.'"}';
    }else{
        return '{"status":"0","msg":"未定义状态","redirect":"'.$rdrurl.'"}';
    }
}

function anyfunrun($fid,$hostx,$gkey,$pkey){
  $pd=array();
  if (strpos($pkey,"&")>0){
      $ptk=explode("&",$pkey);
      $totp=count($ptk);
      
      for ($kk=0;$kk<$totp;$kk++){
          $tmpkx=$ptk[$kk];
          if ($tmpkx!=""){
           $pd[qian($tmpkx,"=")]=hou($tmpkx,"=");
          }
      }
  }else{
      
      if ($pkey!=""){
          $pd[qian($pkey,"=")]=hou($pkey,"=");
      }else{
          $pd["a"]="";
      }
  }
  //echo combineurl("http://".glw(),"/localxres/funx/".$fid."/?".$gkey);
  $hosty=dftval($hostx,glw());
  $bktxt= request_post(combineurl("http://".$hosty,"/localxres/funx/".$fid."/?".$gkey."&rnd=".onlymark()),$pd);
  $bkdata=json_decode($bktxt,false);
  if (intval($bkdata->status)>0){
     return $bktxt;
  }else{
      if ($bktxt!=""){
          return $bktxt;
      }else{
        return makereturnjson("-1","请求失败，服务器没反应",combineurl("http://".glw(),"/localxres/funx/".$fid."/?".$gkey));
      }
  }
}


function overfile($fnm,$ftxt){
  $lsx=explode("/",$fnm);
  $totls=count($lsx);
  $frt=str_replace($lsx[$totls-1],"",$fnm);
  is_dir($frt) OR mkdir($frt, 0777, true); 
 $myfile = fopen($fnm, "w") or die("Unable to open file!");
 $txt = $ftxt;
 fwrite($myfile, $txt);
 fclose($myfile);
 return 1;
}

function getFile($url, $save_dir ="", $filename ="", $type = 0) {  
    if (trim($url) == '') {  
        return false;  
    }  
    if (trim($save_dir) == '') {  
        $save_dir = './';  
    }  
    if (0 !== strrpos($save_dir, '/')) {  
        $save_dir.= '/';  
    }  
    //创建保存目录  
    if (!file_exists($save_dir) && !mkdir($save_dir, 0777, true)) {  
        return false;  
    }  
    //获取远程文件所采用的方法  
    if ($type) {  
        $ch = curl_init();  
        $timeout = 5;  
        curl_setopt($ch, CURLOPT_URL, $url);  
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);  
        $content = curl_exec($ch);  
        curl_close($ch);  
    } else {  
        ob_start();  
        readfile($url);  
        $content = ob_get_contents();  
        ob_end_clean();  
    }  
    //echo $content;  
    $size = strlen($content);  
    //文件大小  
    $fp2 = @fopen($save_dir . $filename, 'a');  
    fwrite($fp2, $content);  
    fclose($fp2);  
    unset($content, $url);  
    return array(  
        'file_name' => $filename,  
        'save_path' => $save_dir . $filename,  
        'file_size' => $size  
    );  
}

function GrabImage($url, $filename = "") {
 if ($url == ""):return false;
 endif;
 //如果$url地址为空，直接退出
 if ($filename == "") {
 //如果没有指定新的文件名
  $ext = strrchr($url, ".");
  //得到$url的图片格式
  if ($ext != ".gif" && $ext != ".jpg" && $ext != ".jpeg"  && $ext != ".png"):return false;
  endif;
  //如果图片格式不为.gif或者.jpg，直接退出
  $filename = date("dMYHis") . $ext;
  //用天月面时分秒来命名新的文件名
 }else{ 
   $lcpath=urltopath($filename);
   is_dir($lcpath) OR mkdir($lcpath, 0777, true); 
 }
 ob_start();//打开输出
 readfile($url);//输出图片文件
 $img = ob_get_contents();//得到浏览器输出
 ob_end_clean();//清除输出并关闭
 $size = strlen($img);//得到图片大小 
 $fp2 = @fopen($filename, "a");
 fwrite($fp2, $img);//向当前目录写入图片文件，并重新命名
 fclose($fp2);
 return $filename;//返回新的文件名
}



function deltree($pathdir) { 
// echo $pathdir;//调试时用的 
  $rtnstr="";
  if(is_empty_dir($pathdir)){ 
    rmdir($pathdir);//直接删除 
    $rtnstr=$rtnstr."成功删除目录".$pathdir."<br />";
   }else{//否则读这个目录，除了.和..外 
     $d=dir($pathdir); 
    while($a=$d->read()) { 
      if(is_file($pathdir.'/'.$a) && ($a!='.') && ($a!='..')){
         unlink($pathdir.'/'.$a);
        $rtnstr=$rtnstr."成功删除文件".$pathdir."/".$a."<br />";
       }  //如果是文件就直接删除 
      if(is_dir($pathdir.'/'.$a) && ($a!='.') && ($a!='..')) {//如果是目录 
          if(!is_empty_dir($pathdir.'/'.$a)) {//是否为空
            //如果不是，调用自身，不过是原来的路径+他下级的目录名 
            $rtnstr=$rtnstr.deltree($pathdir.'/'.$a); 
           } 
           if(is_empty_dir($pathdir.'/'.$a)) {//如果是空就直接删除 
             rmdir($pathdir.'/'.$a); 
             $rtnstr=$rtnstr."成功删除目录".$pathdir."/".$a."<br />";
            } 
       } 
       rmdir($pathdir);//直接删除 
     }//while 
    $d->close(); 
  // echo "必须先删除目录下的所有文件";//我调试时用的 
  } //empty
  return $rtnstr;
} 

function is_empty_dir($pathdir) { 
   //判断目录是否为空 
   $d=opendir($pathdir); 
   $i=0; 
   while($a=readdir($d)) { 
      $i++; 
    } 
    closedir($d); 
   if($i>2){
      return false;
   } else {
     return true; 
   }
}

function copy_dir($src="", $dst="")
{
    if (empty($src) || empty($dst))
    {
        return false;
    }
    $dir = opendir($src);
    is_dir($dst) OR mkdir($dst, 0777, true); 
    while (false !== ($file = readdir($dir)))
    {
        if (($file != '.') && ($file != '..'))
        {
            if (is_dir($src . '/' . $file))
            {
                copy_dir($src . '/' . $file, $dst . '/' . $file);
            }
            else
            {
                copy($src . '/' . $file, $dst . '/' . $file);
            }
        }
    }
    closedir($dir);
    return true;
}

function copy_underdir($from_dir,$to_dir){//只复制目录里文件内容到另一个目录
    if (substr($to_dir,-1)=="/"){
      $to_dir=killlaststr($to_dir);
    }
     if (!is_dir($from_dir)){
        return false;
    }    
    $from_files = scandir($from_dir);    
    if (!file_exists($to_dir)){        
      is_dir($to_dir) OR mkdir($to_dir, 0777, true); 
    }
    if (!empty($from_files)){
        foreach ($from_files as $file){
            if ($file == '.' || $file == '..' ){
                continue;
            }              
            if (is_dir($from_dir.'/'.$file)){//如果是目录，则调用自身
                copy_dir($from_dir.'/'.$file,$to_dir.'/'.$file);
            }else{//直接copy到目标文件夹
                copy($from_dir.'/'.$file,$to_dir.'/'.$file);
            }
        }
    }
   return true;
 }
 
function unzip($file,$outPath){
   if (substr($outpath,-1)=="/"){
     $outpath=killlaststr($outpath);
   }
   $zip = new ZipArchive;
   $openRes = $zip->open($file);
  if ($openRes === TRUE) {
    $zip->extractTo($outPath);
    $zip->close;
    //echo "opentrue-".$file."----to--".$outPath;
    return true;
  }else{
    return false;
  }
}

function Zip($dir, $zipfilename){
       if (@function_exists('gzcompress')){
         $curdir = getcwd();
         if (is_array($dir)){
            $filelist = $dir;
         }else{
            $filelist = $this -> GetFileList($dir);
         }
         if ((!empty($dir))&&(!is_array($dir))&&(file_exists($dir))) chdir($dir);
         else chdir($curdir);
         if (count($filelist)>0){
            foreach($filelist as $filename) {
                   if (is_file($filename)){
                     $fd = fopen ($filename, "r");
                     $content = fread ($fd, filesize ($filename));
                     fclose ($fd);
                     if (is_array($dir)) $filename = basename($filename);
                     $this -> addFile($content, $filename);
                   }
            }
            $out = $this -> file();
            chdir($curdir);
            $fp = fopen($zipfilename, "w");
            fwrite($fp, $out, strlen($out));
            fclose($fp);
         }
         return 1;
       }
       else return 0;
}
function vermd5($sysid,$appid,$srctype,$srcid,$vmd5){
   $ex0=UX("select count(*) as result from coode_appsrc where sysid='".$sysid."' and appid='".$appid."' and srcid='".$srcid."'");
   if ($sysid!="" and $appid!="" and $srctype!="" and $srcid!="" and $vmd5!=""){
    if (intval($ex0)==0){
     $sqla="sysid,appid,srctype,srcid,vermd5,lastupdate";
     $sqlb="'".$sysid."','".$appid."','".$srctype."','".$srcid."','".$vmd5."','".date("Y-m-d H:i:s")."'";
     $c=makenew("coode_appsrc",$sqla,$sqlb);
    }else{
     $z=UX("update coode_appsrc set vermd5='".$vmd5."' where  sysid='".$sysid."' and appid='".$appid."' and srcid='".$srcid."'");
    }
    return true;
   }else{
    return false;   
   }
  
}
function tinytounit($sysid,$appid,$layid,$dm,$mk,$tiny,$shortid,$htmlc,$outurl){
     $hcode=array();
     $hcode=$this->splithtml($hcode,$htmlc);
     $cssfiles=$hcode["cssfilex"];
     $jsfiles=$hcode["jsfilex"].$hcode["jsfilez"].$hcode["jsfiley"];
     $stylex=$hcode["stylex"].$hcode["stylez"].$hcode["scriptx"];
     $scriptx=$hcode["scriptz"].$hcode["scripty"];
     $htmlcode=$hcode["htmlx"];
     $democode=$hcode["demox"];     
     $ext0=UX("select count(*) as result from coode_unittiny where dumark='".$dm.".".$mk."' and tinyid='".$tiny."'");
     if (intval($ext0)==0){
      $sqlx="sysid,appid,layid,shortid,tinyid,domainmark,unitmark,dumark,outurl,cssfilex,stylex,jsfilex,scriptx,pagesurround,templatecode,CRTM,UPTM,CRTOR,RIP";
      $sqly="'".$sysid."','".$appid."','".$layid."','".$shortid."','".$tiny."','".$dm."','".$mk."','".$dm.".".$mk."','".$outurl."','".$cssfiles."','".gohex($stylex)."','".$jsfiles."','".gohex($scriptx)."','".gohex($democode)."','".gohex($htmlcode)."',now(),now(),'".$_COOKIE["uid"]."','".getip()."'";
      $sqlz=UX("insert into coode_unittiny(".$sqlx.")values(".$sqly.")");
     }else{
      $sqlx="sysid='".$sysid."',appid='".$appid."',layid='".$layid."',shortid='".$shortid."',domainmark='".$dm."',unitmark='".$mk."',dumark='".$dm.".".$mk."',outurl='".$outurl."',cssfilex='".$cssfiles."',stylex='".gohex($stylex)."',jsfilex='".$jsfiles."',scriptx='".gohex($scriptx)."',pagesurround='".gohex($democode)."',templatecode='".gohex($htmlcode)."',UPTM=now() ";
      $z=UX("update coode_unittiny set ".$sqlx." where tinyid='".$tiny."' and dumark='".$dm.".".$mk."'");
     }
     return true;
  }

function reg($sysid,$mblx,$vcd,$sessidx){
   $extx=UX("select count(*) as result from coode_afcode where etel='".$mblx."' and code='".$vcdx."' and appid='".$sessidx."'");
   $exty=UX("select count(*) as result from ".sysconfigval($sysid,"usertable")." where userid='".$mblx."'");
   if (intval($extx)>0 and intval($exty)==0){
     return '{"status":"1","msg":"注册成功，默认密码123456，请及时修改","redirect":""}';
   }else{
     return '{"status":"0","msg":"注册失败，已存在用户或验证码不对","redirect":""}';
   }
 
}
function TX($tsql){
    if ($tsql!=""){
     $keyx=qian(hou($tsql,"elect"),"from");
     $keyx=str_replace(" ","",$keyx);
     if (strpos($tsql,"limit")>0){
        $pnumx=hou(hou($tsql,"limit"),",");
     }else{
        $pnumx="30";
     }
     $ptkx=explode(",",$keyx);
     $totp=count($ptkx);
     $headx="";
     $bodyx="";
     for ($i=0;$i<$totp;$i++){
        $mykey[$i]=qian($ptkx[$i],"@");
        $mytit[$i]=qian(hou($ptkx[$i],"@"),"(");
        $mytype[$i]=qian(hou($ptkx[$i],"("),")");
        $headx=$headx.$mykey[$i]."#-#";
     }
     $headx=$headx."#/#";
     for ($j=0;$j<intval($pnumx);$j++){
        for ($i=0;$i<$totp;$i++){
         $bodyx=$bodyx.gettestvalue($j,$mykey[$i],$mytit[$i],$mytype[$i])."#-#";
        }
        $bodyx=$bodyx."#/#";
     }
     return $headx.$bodyx;
    }else{
     return "ERROR#/#NO SQLSTR";   
    }
}

function VX($tsql,$dmk){
    if ($tsql!=""){
     $keyx=qian(hou($tsql,"elect"),"from");
     $keyx=str_replace(" ","",$keyx);
     if (strpos($tsql,"limit")>0){
        $pnumx=hou(hou($tsql,"limit"),",");
     }else{
        $pnumx="30";
     }
     $ptkx=explode(",",$keyx);
     $totp=count($ptkx);
     $headx="";
     $bodyx="";
     for ($i=0;$i<$totp;$i++){
        $mykey[$i]=qian($ptkx[$i],"@");
        $mytit[$i]=qian(hou($ptkx[$i],"@"),"(");
        $mytype[$i]=qian(hou($ptkx[$i],"("),")");
        $headx=$headx.$mykey[$i]."#-#";
     }
     $headx=$headx."#/#";
     for ($j=0;$j<intval($pnumx);$j++){
        for ($i=0;$i<$totp;$i++){
         $bodyx=$bodyx.getlinkvalue($dmk,$j,$mykey[$i],$mytit[$i],$mytype[$i])."#-#";
        }
        $bodyx=$bodyx."#/#";
     }
     return $headx.$bodyx;
    }else{
     return "ERROR#/#NO SQLSTR";   
    }
}

function zip($dir_path, $zipName)
    { 
        $relationArr = array(
            $dir_path => array(
                'originName' => $dir_path,
                'is_dir' => true,
                'children' => array()
            )
        );
        $key = array_keys($relationArr);
        $val = array_values($relationArr);
        $this->modifiyFileName($dir_path, $relationArr[$dir_path]['children']);
        $zip = new ZipArchive();
        //ZIPARCHIVE::CREATE没有即是创建
        $zip->open($zipName, ZipArchive::CREATE);
        $this->zipDir($key[0], '', $zip, $val[0]['children']);
        $zip->close();
        $this->restoreFileName($key[0], $val[0]['children']);
        return true;
    }
    



function takevaljson($jsonfile){
 $jsontxt=file_get_contents($jsonfile);
 $jsondata=json_decode($jsontxt);
 $tabnm=$jsondata->tabnm;
 $crtsql=$jsondata->crtsql;
 $vls=$jsondata->vls;
 $stt=$jsondata->status;
 $fmk="";
 $fmv="";
 if (intval($stt)>0){
  $exttab=UX("select count(*) as result from coode_tablist where TABLE_NAME='".$tabnm."'");
  if (intval($exttab)==0){
   $z0=crttab(0,$crtsql);   
   $sqlx="TABLE_NAME,tabtitle,CRTM,UPTM,OLMK";
   $sqly="'$tabnm','$tabnm',now(),now(),'".onlymark()."'";
   $zz=UX("insert into coode_tablist(".$sqlx.")values(".$sqly.")");
   return false;
  }else{
   $tbrst=SX("select srckey,srcttk,parreskey from coode_tablist where TABLE_NAME='".$tabnm."'");
   $srckey=anyvalue($tbrst,"srckey",0);
   $parkey=anyvalue($tbrst,"parreskey",0);
   $srcval="";
   $parval="";
   $fmupdt="";
   $fmcdt="";
   if ($srckey!=""){
    for ($j=0;$j<count($vls);$j++){
     if ($vls[$j]->keymark==$srckey or $vls[$j]->keymark==$parkey){
       if ($vls[$j]->keymark==$srckey){
         $srcval=$vls[$j]->kvalue;
       }else{
         $parval=$vls[$j]->kvalue;
       }
     }else{
       $fmupdt=$fmupdt.$vls[$j]->keymark."='".str_replace("'","\'",$vls[$j]->kvalue)."',";
       $fmcdt=$fmcdt." ".$vls[$j]->keymark."='".$vls[$j]->kvalue."' and";
     }   
    }//for
     $fmupdt=killlaststr($fmupdt);
    if ($srcval==""){
      return false;
    }
    if ($parkey!=""){     
      if ($parval==""){
       return false;
      }
      $extdd=UX("select count(*) as result from ".$tabnm." where  ".$srckey."='".$srcval."' and ".$parkey."='".$parval."'");      
    }else{     
      $extdd=UX("select count(*) as result from ".$tabnm." where  ".$srckey."='".$srcval."'");
    }
    if ($extdd==0){
     for ($j=0;$j<count($vls);$j++){
      $fmk=$fmk.$vls[$j]->keymark.",";
      $fmv=$fmv."'".str_replace("'","\'",$vls[$j]->kvalue)."',";
     }
     $fmk=killlaststr($fmk);
     $fmv=killlaststr($fmv); 
     $zz=UX("insert into ".$tabnm."(".$fmk.")values(".$fmv.")");  
     //$zz=addprcx ("insert into ".$tabnm."(".$fmk.")values(".$fmv.")@tabdataoprt");
    }else{   
     if ($parkey!=""){
       $zz=UX("update ".$tabnm." set ".$fmupdt." where ".$parkey."='".$parval."' and ".$srckey."='".$srcval."'");      
     }else{
       $zz=UX("update ".$tabnm." set ".$fmupdt." where ".$srckey."='".$srcval."'");      
       //$zz1=addprcx("update ".$tabnm." set ".$fmupdt." where ".$srckey."='".$srcval."'@tabdataoprt");
     }
    }//ifextdd
    if ($parkey!=""){     
      $extd=UX("select count(*) as result from ".$tabnm." where  ".$srckey."='".$srcval."' and ".$parkey."='".$parval."'");
    }else{
      $extd=UX("select count(*) as result from ".$tabnm." where  ".$srckey."='".$srcval."'");
    }
    if (intval($extd)>0){
      return true;
    }else{
      return false;
    }
   }else{
     return false;
   }//srckey
  }//exttab
 }else{//stt
   return false;
 }
}


function resvermd5($restype,$rescode){
  switch($restype){
    case "funx":
    $zz=UX("update coode_funlist set vermd5=md5(concat(funcname,funfull)) where funname='".$rescode."' or  funname='".$rescode."()'");
    $vmd5=UX("select vermd5 as result from coode_funlist where funname='".$rescode."'");
    break;
    case "dfunx":
    $zz=UX("update coode_datafun set vermd5=md5(concat(dftitle,dfuneval)) where dfunmark='".$rescode."'");
    $vmd5=UX("select vermd5 as result from coode_datafun where dfunmark='".$rescode."'");
    break;
    case "sfunx":
    $zz=UX("update coode_funsetfile set vermd5=md5(concat(setcname,funbody)) where setname='".$rescode."'");
    $vmd5=UX("select vermd5 as result from coode_funsetfile where setname='".$rescode."'");
    break;
    case "mfunx":
    $zz=UX("update coode_multifunlist set vermd5=md5(concat(funcname,funbody)) where funname='".$rescode."'");
    $vmd5=UX("select vermd5 as result from coode_multifunlist where funname='".$rescode."'");
    break;
    case "afunx":
    $zz=UX("update coode_affairfunlist set vermd5=md5(concat(funcname,funbody)) where funname='".$rescode."'");
    $vmd5=UX("select vermd5 as result from coode_affairfunlist where funname='".$rescode."'");
    break;
    case "dataspacex":
      $d1rst=SX("select datatitle,jsondata from coode_dataspace where datamark='".$rescode."'");
      $d2rst=SX("select md5(concat(keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib)) as result from coode_dspckey where datamark='".$rescode."'");      
      $vmd5=md5($d1rst.$d2rst);
      $zz=UX("update coode_dataspace set vermd5='".$vmd5."' where datamark='".$rescode."'");
    break;
    case "databasex":
     $zz=UX("update coode_dblist set vermd5=md5(concat(dbname,dbtitle,dbtype,dbip,dbus,dbps,dbdomain)) where dbmark='".$rescode."'");
     $vmd5=UX("select vermd5 as result from coode_dblist where dbmark='".$rescode."'");
    break;
    case "tabx":
      $d1rst=SX("select tabtitle,createsql from coode_tablist where TABLE_NAME='".$rescode."'");
      $d2rst=SX("select md5(concat(keytitle,valuezero,keyexplain,jsshowfun,sysshowfun,jspostfun,syspostfun,bfist,aftist,bfupd,aftupd,bfdel,aftdel,SQX,VQX,isfixed,changeable,displayed,dxtype,COLUMN_TYPE)) as result from coode_keydetailx where TABLE_NAME='".$rescode."'");
      $vmd5=md5($d1rst.$d2rst);
      $zz=UX("update coode_tablist set vermd5='".$vmd5."' where TABLE_NAME='".$rescode."'");
    break;
    case "formx":
      $d1rst=SX("select shorttitle,caseid,detailid,tablename,cdt,orddt,dttp,addtitle,addpage from coode_tablist where shortid='".$rescode."'");
      $d2rst=SX("select md5(concat(keytitle,valuezero,keyexplain,jsshowfun,sysshowfun,jspostfun,syspostfun,bfist,aftist,bfupd,aftupd,bfdel,aftdel,SQX,VQX,isfixed,changeable,displayed,dxtype,COLUMN_TYPE)) as result from coode_keydetaily where shortid='".$rescode."'");
      $d3rst=SX("select jsfiles,cssfiles,scriptx,stylex,diytop,diybottom from coode_shortcss where shortid='".$rescode."'");
      $vmd5=md5($d1rst.$d2rst.d3rst);
      $zz=UX("update coode_shortdata set vermd5='".$vmd5."' where shortid='".$rescode."'");
    break;
    case "plotx":
      $d1rst=SX("select plotcls,levelcount,totpoint,markname from coode_plotlist where plotmark='".$rescode."'");
      $d2rst=SX("select md5(concat(level,myid,parid,oriid,mytitle,mymark,myurl,myclick,fontname,fontshow,mydescrib)) as result from coode_plotdetail where plotmark='".$rescode."'");
      $vmd5=md5($d1rst.$d2rst);
      $zz=UX("update coode_plotlist set vermd5='".$vmd5."' where plotmark='".$rescode."'");
    break;
    case "groupx":
      $d1rst=SX("select layoutid,markname,defaultcss,formcode,clickfun from coode_grouplist where plotmark='".$rescode."'");
      $d2rst=SX("select md5(concat(domain,keyid,keyval,compid,groupid,clientid,totsrc)) as result from coode_grpclass where clsmark='".$rescode."'");
      $vmd5=md5($d1rst.$d2rst);
      $zz=UX("update coode_grouplist set vermd5='".$vmd5."' where plotmark='".$rescode."'");
    break;
    case "tempx":
      $d1rst=SX("select relyface,unittitle,md5(concat(unitclass,funcls,outurl,casecode,cssfilex,stylex,scriptx,jsfilex,templatecode,pagesurround)) from coode_domainunit where dumark='".$rescode."'");
      $d2rst=SX("select md5(concat(keytype,keydemo)) as result from coode_codedemo where dumark='".$rescode."'");
      $d3rst=SX("select evalcode from coode_makedujsfile where dumark='".$rescode."'");
      $d4rst=SX("select evalcode from coode_makeformact where dumark='".$rescode."'");
      $vmd5=md5($d1rst.$d2rst.$d3rst.$d4rst);
      $zz=UX("update coode_domainunit set vermd5='".$vmd5."' where dumark='".$rescode."'");
    break;
    case "csspagex":
    $zz=UX("update coode_faceist set vermd5=md5(concat(facetype,facecolor,filepath)) where faceid='".$rescode."'");
    $vmd5=UX("select vermd5 as result from coode_facelist where faceid='".$rescode."'");
    break;
    case "pagex":
      $d1rst=SX("select imghead,tinytitle,longexp,shortid,tabname,sysid,appid,layid from coode_tiny where tinymark='".$rescode."'");
      $d2rst=SX("select md5(concat(unittitle,unitclass,outurl,cssfilex,stylex,scriptx,jsfilex,casecode,templatecode,pagesurround)) as result from coode_unittiny where tinyid='".$rescode."'");
      $vmd5=md5($d1rst.$d2rst);
      $zz=UX("update coode_tiny set vermd5='".$vmd5."' where tinyid='".$rescode."'");
    break;
    case "cdtrdrx":
      $d1rst=SX("select md5(concat(cdtval,rdrpath,rdrcode)) from coode_cdtrdr where cdtmark='".$rescode."'");
      
      $vmd5=md5($d1rst);
      $zz=UX("update coode_cdtrdr set vermd5='".$vmd5."' where cdtmark='".$rescode."'");
    break;
    case "parardrx":
    $zz=UX("update coode_parardr set vermd5=md5(concat(paratitle,paratype,parapoint,paraval,fromurl,rdrpath,rdrcode,ismbl)) where paramark='".$rescode."'");
    $vmd5=UX("select vermd5 as result from coode_parardr where paramark='".$rescode."'");
    break;
    case "constx":
    $zz=UX("update coode_sysconstant set vermd5=md5(concat(constanttitle,constanttype,constantvalue)) where  constantid='".$rescode."'");
    $vmd5=UX("select vermd5 as result from coode_parardr where paramark='".$rescode."'");
    break;
    case "configx":
    $zz=UX("update coode_sysconfig set vermd5=md5(concat(sysktitle,sysval)) where  syskey='".$rescode."'");
    $vmd5=UX("select vermd5 as result from coode_sysconfig where paramark='".$rescode."'");
    break;
    case "sysx":
    $zz=UX("update coode_sysinformation set vermd5=md5(concat(sysname,indexurl,loginurl,inurl,custinurl,outurl,totres)) where  sysid='".$rescode."'");
    $vmd5=UX("select vermd5 as result from coode_sysinformation where sysid='".$rescode."'");
    break;
    case "appx":
    $zz=UX("update coode_appdefault set vermd5=md5(concat(appname,sysid,faceimg,appdetail,inurl,outurl)) where  appid='".$rescode."'");
    $vmd5=UX("select vermd5 as result from coode_appdefault where appid='".$rescode."'");
    break;
    case "layx":
    $zz=UX("update coode_appdefault set vermd5=md5(concat(sysid,sysid,laytitle,colora,colorb,pagelay,mobilelay)) where  layid='".$rescode."'");
    $vmd5=UX("select vermd5 as result from coode_applay where layid='".$rescode."'");
    break;
    case "prarx":
    $zz=UX("update coode_para set vermd5=md5(concat(paratitle,paradescrib,parapath,paravender,parawebsite,paraversion)) where  paramark='".$rescode."'");
    $vmd5=UX("select vermd5 as result from coode_para where paramark='".$rescode."'");
    break;
    case "apix":
    $zz=UX("update coode_apipool set vermd5=md5(concat(apikey,apival,apititle,parcode,partitle)) where  appid='".$rescode."'");
    $vmd5=UX("select vermd5 as result from coode_apipool where appid='".$rescode."'");
    break;
    default:
  }
  return $vmd5;
}

function KT($cstr){
  $ktypex=file_get_contents(combineurl("http://".glw(),"/localxres/funx/aikeytypes/?chkeyx=".$cstr));
  $ktypex=strtolower($ktypex);
  $dtype=qian($ktypex,"(");
  $dtlen=qian(hou($ktypex,"("),")");
  //bit date time timestamp datetime year enum set text blob
  switch($dtype){
    case "bit":
    return $dtype;
    break;  
    case "timestamp":
    return $dtype;
    break;   
    case "time":
    return $dtype;
    break;   
    case "year":
    return $dtype;
    break;   
    case "enum":
    return $dtype;
    break;   
    case "set":
    return $dtype;
    break;   
    case "date":
    return $dtype;
    break;
    case "datetime":
    return $dtype;
    break;
    case "text":
    return $dtype;
    break;
    case "longtext":
    return $dtype;
    break;
    case "blob":
    return $dtype;
    break;
    case "decimal":
    return $dtype."(10,4)";
    break;
    default:
    return $ktypex;
  }
}

function RD($dmark){
$datamark=$dmark;
$dkrst=SX("select datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib   from coode_dspckey where datamark='".$datamark."' order by sqx");
  $totdk=countresult($dkrst);
  $fmtps="";
  $fmrcd="datasno,";
  $fmca="";
  $fmcb="";
  $clstxt="";
  for ($i=0;$i<$totdk;$i++){
   $keyx[$i]=anyvalue($dkrst,"keymark",$i);
   $keyy[$i]=anyvalue($dkrst,"keytitle",$i);
   $keytp[$i]=anyvalue($dkrst,"keytype",$i);
   $keylen[$i]=anyvalue($dkrst,"keylen",$i);
   $clstxtx[$i]=anyvalue($dkrst,"clstxt",$i);
   $classp[$i]=anyvalue($dkrst,"classp",$i);
   $keydxtype[$i]=anyvalue($dkrst,"dxtype",$i);
   $fmtps=$fmtps.'{"keyid":"'.$keyx[$i].'","keytitle":"'.$keyy[$i].'","keytype":"'.$keytp[$i].'","keylen":"'.$keylen[$i].'"},';
   $fmrcd=$fmrcd.$keyx[$i].",";
  }//totdk
  $fmtps=killlaststr($fmtps);
  $fmrcd=killlaststr($fmrcd)."@/@";
  $fmrcd=str_replace(",","@-@",$fmrcd);
  $jsondata='{"data":[<datavls>]}';
  $datademo='{"status":"1","datamark":"<datamark>","datatitle":"<datatitle>","totrcd":"<totrcd>","keytps":[<ktps>],"vls":[<datavls>]}';
  $datatitle=UX("select datatitle as result from coode_dataspace where datamark='".$datamark."'");
  $datarst=SX("select datasno,keymks,valmd5,keyvals from coode_dspcvindex where datamark='".$datamark."'");
  $totda=countresult($datarst);
  $datademo=str_replace("<datamark>",$datamark,$datademo);
  $datademo=str_replace("<datatitle>",$datatitle,$datademo);
  $datademo=str_replace("<ktps>",$fmtps,$datademo);
  $datademo=str_replace("<totrcd>",$totda,$datademo);
  $fmvalx="";
 
  for ($j=0;$j<$totda;$j++){
   $datasno=anyvalue($datarst,"datasno",$j);
   $keymks=anyvalue($datarst,"keymks",$j);
   $valmd5=anyvalue($datarst,"valmd5",$j);
   $keyvals=anyvalue($datarst,"keyvals",$j);
   $rcdrowx="";
   $fmitem="{";
   if ($keyvals!=""){
     $ptkey=explode(",",$keymks);     
     $ptval=explode("@-@",$keyvals);     
     for ($k=0;$k<count($ptkey);$k++){
       $valx[$ptkey[$k]]=$ptval[$k];             
       $rcdrowx=$rcdrowx.$ptval[$k].",";
       if ($classp[$k]==1){
         $fmca=$fmca.$ptval[$k].",";
       }
       if ($classp[$k]==2){
         $fmcb=$fmcb.$ptval[$k].",";
       }
     }//fork
       $fmrcd=$fmrcd.$datasno.",".$rcdrowx;
       $fmrcd=killlaststr($fmrcd).";";
    }else{
     $detailrst=SX("select keymark,keytype,intval,tinyintval,dateval,datetimeval,varcharval,textval,longtextval,decimalval,classp from coode_dspcval where datamark='".$datamark."' and datasno='".$datasno."'");
     $totdtl=countresult($detailrst);       
     for ($k=0;$k<$totdtl;$k++){
         $kmk=anyvalue($detailrst,"keymark",$k);
         $ktp=anyvalue($detailrst,"keytype",$k);
         $classpx=anyvalue($detailrst,"classp",$k);
         $intval=anyvalue($detailrst,"intval",$k);
         $tinyintval=anyvalue($detailrst,"tinyintval",$k);
         $dateval=anyvalue($detailrst,"dateval",$k);
         $datetimeval=anyvalue($detailrst,"datetimeval",$k);
         $varcharval=anyvalue($detailrst,"varcharval",$k);
         $textval=anyvalue($detailrst,"textval",$k);
         $longtextval=anyvalue($detailrst,"longtextval",$k);
         $decimalval=anyvalue($detailrst,"decimalval",$k);
         switch($ktp){
           case "int":
           $valx[$kmk]=$intval;
           break;
           case "tinyint":
           $valx[$kmk]=$tinyintval;
           break;
           case "dateval":
           $valx[$kmk]=$dateval;
           break;
           case "datetimeval":
           $valx[$kmk]=$datetimeval;
           break;
           case "varcharval":
           $valx[$kmk]=$varcharval;
           break;
           case "textval":
           $valx[$kmk]=$textval;
           break;
           case "longtextval":
           $valx[$kmk]=$longtextval;
           break;
           case "decimalval":
           $valx[$kmk]=$decimalval;
           break;
           default:
         }//swc
         $rcdrowx=$rcdrowx.$valx[$kmk].",";         
         if (intval($classpx)==1){
           $fmca=$fmca.$valx[$kmk].",";
         }
         if (intval($classpx)==2){
           $fmcb=$fmcb.$valx[$kmk].",";
         }
     }//fork     
     $fmrcd=$fmrcd.$datasno.",".$rcdrowx;
     $fmrcd=killlaststr($fmrcd).";";     
    }//ifkeyval
    
    for ($i=0;$i<$totdk;$i++){
       $fmitem=$fmitem.'"'.$keyx[$i].'":"'.$valx[$keyx[$i]].'",';
    }
     $fmitem=killlaststr($fmitem).'}';
     $fmvalx=$fmvalx.$fmitem.',';
  }//forj
  $fmvalx=killlaststr($fmvalx);
  $fmca=killlaststr($fmca);
  $fmcb=killlaststr($fmcb);
  if ($fmca!="" and $fmcb!=""){
   $clstxt=$fmcb."|".$fmca;
  }
 
  $fmrcd=str_replace(",","@-@",$fmrcd);
  $fmrcd=str_replace(";","@/@",$fmrcd);
  
  $datademo=str_replace("<datavls>",$fmvalx,$datademo);
  $jsondata=str_replace("<datavls>",$fmvalx,$jsondata);
  
  $jshortpath=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/jsshort.json");
  $jsonpath=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/data.json");
  $coodex=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/coodercd.txt");
  $coodeclstxt=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/coodeclstxt.txt");
  $z0=overfile($jshortpath,$datademo);
  $z1=overfile($jsonpath,$jsondata);
  $newrcd=str_replace("@-@","#"."-#",str_replace("@/@","#"."/#",$fmrcd));
  $z2=overfile($coodex,$newrcd);
  $z3=overfile($coodeclstxt,$clstxt);
  return true;
}

function ND($dmark,$pk,$pvstr){
 if (es($dmark)*es($pk)*es($pvstr)==1){
 $lastsno=UX("select datasno as result from coode_dspcvindex where datamark='".$dmark."' order by datasno desc");
 $newsno=intval($lastsno)+1;
 $kval=array();
  if (strpos($pk,"&")>0){
    $ptk=explode("&",$pk);
    $totpt=count($ptk);
    for ($nn=0;$nn<$totpt;$nn++){
      $tempk=$ptk[$nn];
      $tempv=dftval($_POST[$tempk],"");
    }
    $ptv=explode("&",$pvstr);
    $totptv=count($ptv);
    for ($mm=0;$mm<$totptv;$mm++){
       $temppart=$ptv[$mm];
       $tempkey=qian($ptv[$mm],"=");
       $tempval=unstrs(hou($ptv[$mm],"="));
       $kval[$tempkey]=dftval($tempval,unstrs($_POST[$tempkey]));       
    }
    $tt=UX("insert into coode_dspcval(datamark,datasno,keymark,keytitle,keytype,keylen,CRTM,UPTM,OLMK)select datamark,'".($newsno)."',keymark,keytitle,keytype,keylen,now(),now(),RAND()*1000000 from coode_dspckey where datamark='".$dmark."'");
    $dskrst=SX("select keymark,keytype,keytitle from coode_dspckey where datamark='".$dmark."'");
    $totds=countresult($dskrst);
    $fmk="";
    $fmv="";
    for ($oo=0;$oo<$totds;$oo++){
       $kmk=anyvalue($dskrst,"keymark",$oo);
       $ktp=anyvalue($dskrst,"keytype",$oo);
       $fmk=$fmk.$kmk.",";
       $fmv=$fmv.$kval[$kmk]."@-@";
       $kxx=$ktp."val";
       $dx=UX("update coode_dspcval set ".$kxx."='".$kval[$kmk]."',UPTM=now() where datamark='".$dmark."' and datasno='".($newsno)."' and keymark='".$kmk."'");      
    }
    $fmk=killlaststr($fmk);
    $fmv=killlaststr($fmv);
    $fmv=killlaststr($fmv);
    $fmv=killlaststr($fmv);
    $allkeys=$fmk;
    $tempdata=$fmv;
    $zz=UX("insert into coode_dspcvindex(datamark,datasno,keymks,valmd5,keyvals,CRTM,UPTM,CRTOR,OLMK)values('".$dmark."','".($newsno)."','".$allkeys."','".md5($tempdata)."','".$tempdata."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."') ON DUPLICATE KEY update UPTM=now(),keymks='".$allkeys."',valmd5='".md5($tempdata)."',keyvals='".$tempdata."'");
    //$bb=addprcx("insert into coode_dspcvindex(datamark,datasno,keymks,valmd5,keyvals,CRTM,UPTM,CRTOR,OLMK)values('".$dmark."','".($newsno)."','".$allkeys."','".md5($tempdata)."','".$tempdata."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."') ON DUPLICATE KEY update UPTM=now(),keymks='".$allkeys."',valmd5='".md5($tempdata)."',keyvals='".$tempdata."'".huanhang());
  }else{
      $temppart=$pvstr;
      $tempkey=qian($pvstr,"=");
      $tempval=unstrs(hou($pvstr,"="));
      $kval[$tempkey]=dftval($tempval,unstrs($_POST[$tempkey]));       
    
    $tt=UX("insert into coode_dspcval(datamark,datasno,keymark,keytitle,keytype,keylen,CRTM,UPTM,OLMK)select datamark,'".($newsno)."',keymark,keytitle,keytype,keylen,now(),now(),RAND()*1000000 from coode_dspckey where datamark='".$dmark."'");
    $dskrst=SX("select keymark,keytype,keytitle from coode_dspckey where datamark='".$dmark."'");
    $totds=countresult($dskrst);
    $fmk="";
    $fmv="";
    for ($oo=0;$oo<$totds;$oo++){
       $kmk=anyvalue($dskrst,"keymark",$oo);
       $ktp=anyvalue($dskrst,"keytype",$oo);
       $fmk=$fmk.$kmk.",";
       $fmv=$fmv.$kval[$kmk]."@-@";
       $kxx=$ktp."val";
       $dx=UX("update coode_dspcval set ".$kxx."='".$kval[$kmk]."',UPTM=now() where datamark='".$dmark."' and datasno='".($newsno)."' and keymark='".$kmk."'");      
    }
    $fmk=killlaststr($fmk);
    $fmv=killlaststr($fmv);
    $fmv=killlaststr($fmv);
    $fmv=killlaststr($fmv);
    $allkeys=$fmk;
    $tempdata=$fmv;
    $zz=UX("insert into coode_dspcvindex(datamark,datasno,keymks,valmd5,keyvals,CRTM,UPTM,CRTOR,OLMK)values('".$dmark."','".($newsno)."','".$allkeys."','".md5($tempdata)."','".$tempdata."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."') ON DUPLICATE KEY update UPTM=now(),keymks='".$allkeys."',valmd5='".md5($tempdata)."',keyvals='".$tempdata."'");
  }
 }else{
   return -3.14;
 }
}
//在已有的DASP中更改

function check_domain($allowed_domains) {
    $current_domain = $_SERVER['HTTP_HOST'];
    return in_array($current_domain, $allowed_domains);
}

function check_time($start_date, $end_date) {
    $current_date = new DateTime();
    $start = new DateTime($start_date);
    $end = new DateTime($end_date);
    return $current_date >= $start && $current_date <= $end;
}

function gohex($vlsx){
  if (strpos($vlsx,"TYPE_HEX:")>0){
    return $vlsx;
  }else{
    $vlsx=str_replace("\\","-/-/",$vlsx);
    return "dTYPE_HEX:".String2Hex(str_replace("\r\n","-r-n",$vlsx));
  }
}

function extab($dtp,$tbnm){
    eval(RESFUNSET("tabbaseinfo"));
    if ( intval($dtp)==0){
      $conn=mysql_connect(gl(),glu(),glp());
      $extx=updatings($conn,"information_schema","select count(*) as result from TABLES where TABLE_SCHEMA='".glb()."' and TABLE_NAME='".$tbnm."'","utf8");
      if (intval($extx)>0){
         return true;
      }else{
         return false;
      }
    }else{
        $conn=mysql_connect(bl(),blu(),blp());
        $extx=updatings($conn,"information_schema","select count(*) as result from TABLES where TABLE_SCHEMA='".blb()."' and TABLE_NAME='".$tbnm."'","utf8");
      if (intval($extx)>0){
         return true;
      }else{
         return false;
      } 
    }
}

function crttab($dtp,$sqlx){
    $tbnmx=qian($sqlx,"(");
    $tbnmx=hou($tbnmx,"TABLE");
    $tbnmx=hou($tbnmx,"table");
    $tbnmx=str_replace(" ","",$tbnmx);
    if (extab($dtp,$tbnmx)==false){
      if ( intval($dtp)==0){
          $conn=mysql_connect(gl(),glu(),glp());
          $nn=updatingx($conn,glb(),$sqlx,"utf8");
      }else{
          $conn=mysql_connect(bl(),blu(),blp());
          $nn=updatingx($conn,blb(),$sqlx,"utf8");
      }
    };
    return extab($dtp,$tbnmx);
}

function SY($dmk){
    return file_get_contents(combineurl(localroot(),"/localxrex/dataspacex/".$dmk."/coodercd.txt"));
}

function CX($sqlrcd,$skey){
  $totcx=countresult($sqlrcd);
  $fmall="";
  for ($cc=0;$cc<$totcx;$cc++){
      $fmall=$fmall.anyvalue($sqlrcd,$skey,$cc).",";
  }
  return killlaststr($fmall);
}

function deletefiles($directory,$pn) {  
    // 打开目录  pn=1 删除所有文件包括子目录  0为删除当前目录文件
    $handle = opendir($directory);  
  
    // 遍历目录中的文件和子目录  
    while (false !== ($file = readdir($handle))) {  
        if ($file != "." && $file != "..") {  
            $path = $directory . "/" . $file;  
  
            // 如果是文件，则删除它  
            if (is_file($path)) {  
                unlink($path);  
            }  
            // 如果是目录，则递归调用deleteFiles函数  
            else if (is_dir($path)) {  
                if ($pn==1){
                 deleteFiles($path);  
                }
            }  
        }  
    }  
  
    // 关闭目录句柄  
    closedir($handle);  
}  
//CORE CODE END

?>