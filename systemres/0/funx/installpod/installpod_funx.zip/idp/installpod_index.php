<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
   error_reporting(0);
   register_shutdown_function('zyfshutdownfunc'); 
   set_error_handler('zyferror'); 
   include 'installpod_base.php';          
   eval(RESFUNSET("resrelyrp"));
eval(RESFUNSET("tabdataoprt"));
eval(RESFUNSET("dspbasecoprt"));
    $fromhost=$_GET["fromhost"];
    $restype=$_GET["restype"];
    $rescode=$_GET["rescode"];
    $sysid=$_GET["sysid"];
function tornx($txx){
  if ($txx==true){
    return 1;
  }else{
    return 0;
  }
}
$succx=0;
 if (es($fromhost)*es($restype)*es($rescode)==1){
   if (strpos($fromhost,":")>0){
    $dkh=hou($fromhost,":");
   }else{
    $dkh="";
   }
   if ($dkh=="443"){
     $reshost="https://".qian($fromhost,":");
   }else{
     $reshost="http://".$fromhost;
   }
    
    switch($restype){
      case "pagex":
       $resurl=combineurl($reshost,"/systemres/".$sysid."/pagex/seedx/".$rescode."/".$rescode."_pagex.zip");
       $newurl=combineurl(localroot(),"/remotexres/receive/pagex/".$rescode."_pagex.zip");
       $newpath=combineurl(localroot(),"/remotexres/receive/pagex/".$rescode."/");
      break;
      case "tempx":
      $resurl=combineurl($reshost,"/systemres/".$sysid."/tempx/".qian($rescode,".")."/".qian($rescode,".")."_tempx.zip");
      $newurl=combineurl(localroot(),"/remotexres/receive/tempx/".str_replace(".","_",$rescode)."_tempx.zip");
      $newpath=combineurl(localroot(),"/remotexres/receive/tempx/".qian($rescode,".")."/");
      $tarpath=combineurl(localroot(),"/localxres/tempx/".qian($rescode,".")."/"); 
      break;
      default:
      $resurl=combineurl($reshost,"/systemres/".$sysid."/".$restype."/".str_replace(".","_",$rescode)."/".str_replace(".","_",$rescode)."_".$restype.".zip");
      $newurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".str_replace(".","_",$rescode)."_".$restype.".zip");
      $newpath=combineurl(localroot(),"/remotexres/receive/".$restype."/".qian($rescode,".")."/");
      $tarpath=combineurl(localroot(),"/localxres/".$restype."/".qian($rescode,".")."/"); 
    }
    $err="";
      $kk=unlink($newurl);
      $kk2=deltree($newpath);
     if (downanyfile($resurl,$newurl)){
       $zz=unzip($newurl,$newpath);
       //unlink($newurl);
       
     }else{
       $err="下载资源失败；";
       $tarpath="";
     }
     
   
      switch($restype){
       case "pagex":
         $jsonf0=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-resdata.json");
         $uu=takevaljson($jsonf0);
         $succx=$succx+tornx($uu);
         $jsonf1=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-pagedata.json");
         $uu=takevaljson($jsonf1);
         $succx=$succx+tornx($uu);
         $jsonf2=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-app.json");
         $uu=takevaljson($jsonf2);
         $succx=$succx+tornx($uu);
         $jsonf3=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-lay.json");
         $uu=takevaljson($jsonf3);
         $succx=$succx+tornx($uu);
         $jsonf4=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-temp.json");
         $uu=takevaljson($jsonf4);
         $succx=$succx+tornx($uu);
         $trst=SX("select sysid,appid,layid from coode_tiny where tinymark='".$rescode."'");
         $totx=countresult($trst);
         $sysid=anyvalue($trst,"sysid",0);
         $appid=anyvalue($trst,"appid",0);
         $layid=anyvalue($trst,"layid",0);
         if ($totx>0){
          $tarpath=combineurl(localroot(),"/localxres/pagex/".$sysid."/".$appid."/".$layid."/".$rescode."/"); 
         }else{
          $tarpath="";
         }
       break;
       case "tabx":
       $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);            
            $z0=crttab(0,anyfunrun("gettabcrt",$fromhost,"tabnm=".$rescode,""));
       $vls=$relydata->vls;
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$verx.".json"); 
         $uu=takevaljson($jsonf);
         $succx=$succx+tornx($uu);
       }
       $zz=anyfunrun("initialize","","","");
       break;
       case "formx":
       $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $vls=$relydata->vls;
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$verx.".json"); 
         $uu=takevaljson($jsonf);
         $succx=$succx+tornx($uu);
       }
       
       break;
       case "plotx":
       $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $vls=$relydata->vls;
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$verx.".json"); 
         $uu=takevaljson($jsonf);
         $succx=$succx+tornx($uu);
       }
       break;
       case "groupx":
       $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $vls=$relydata->vls;
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$verx.".json"); 
         $uu=takevaljson($jsonf);
         $succx=$succx+tornx($uu);
       }
       break;
       case "dataspacex":
       $kk0=UX("delete from coode_dataspace where datamark='".$rescode."'");
       $kk1=UX("delete from coode_dspckey where datamark='".$rescode."'");
       $kk0=UX("delete from coode_dspcvindex where datamark='".$rescode."'");
       $kk1=UX("delete from coode_dspckeyx where datamark='".$rescode."'");
       $kk1=UX("delete from coode_dspckeyy where datamark='".$rescode."'");
       $kk1=UX("delete from coode_dspckeyz where datamark='".$rescode."'");
       
       
       $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $vls=$relydata->vls;
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$verx.".json"); 
         $uu=takevaljson($jsonf);
         $succx=$succx+tornx($uu);
       }
       $jsfile=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/jsshort.json");
       $jsshort=file_get_contents($jsfile);
       $jsdata=json_decode($jsshort,false);
       $ktps=$jsdata->keytps;
       $vls=$jsdata->vls;
       $fmktp="";
       for ($kk=0;$kk<count($ktps);$kk++){
          $keyid=$ktps[$kk]->keyid;
         if ($keyid!="datasno"){
           $fmktp=$fmktp.$ktps[$kk]->keyid."&";
         }
       }
       $fmktp=killlaststr($fmktp);
       for ($ii=0;$ii<count($vls);$ii++){
         $fmvls="";
         for ($kk=0;$kk<count($ktps);$kk++){
           $tmpvx="";
           $keyid=$ktps[$kk]->keyid;
           if ($keyid!="datasno"){
            
            eval('$tmpvx=$vls[$ii]->'.$keyid.';');
            $fmvls=$fmvls.$keyid."=".$tmpvx."&";
           }
         }
         $fmvls=killlaststr($fmvls);
         $nn=ND($rescode,$fmktp,$fmvls);
       }
       $xx=UX("insert into coode_dspckeyx(domainmark,datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib)select domainmark,datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib from coode_dspckey where datamark='".$rescode."'");
       break;
       default:
         $jsonf=combineurl(localroot(),"/remotexres/receive/".$restype."/".qian($rescode,".")."/".str_replace(".","_",$rescode)."_".$restype."-resdata.json");
         $uu=takevaljson($jsonf);
         $succx=$succx+tornx($uu);
    }
     if ($tarpath!=""){     
      $zz=copy_underdir($newpath,$tarpath);
       if ($restype=="tempx" or $restype=="pagex"){
        $localcss=combineurl(localroot(),"/localxres/csspagex/");       
        $zz1=copy_underdir($tarpath,$localcss);
        $zxc=deletefiles($localcss,0);//删除其余文件
        if ($restype=="pagex"){
         $myurl=combineurl("http://".glw(),"/localxres/funx/maketinytounit/?tinyid=".$rescode."&newdo=tempx");
         $zz=file_get_contents($myurl);         
        }
       }
     }
  $vvvmd5=resvermd5($restype,$rescode);
  $zz0=UX("update coode_sysregres set vermd5='".$vvvmd5."' where resmark='".$rescode."' and restype='".$restype."'");
  $zz1=UX("update coode_syshostres set vermd5='".$vvvmd5."' where rescode='".$rescode."' and restype='".$restype."'");
  $zz2=UX("update coode_syshostres set STATUS=1 where vermd5=mtver  and rescode='".$rescode."' and restype='".$restype."'");
  $zz3=UX("update coode_syshostres set PRIME=1 where vermd5!='' and rescode='".$rescode."' and restype='".$restype."'");
  echo makereturnjson("1","成功安装".$succx."条。".$err,"");
}else{
  echo makereturnjson("0","安装失败-参数不全-".$fromhost."/".$restype."/".$rescode,"");
}
          
?>