<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sysid=$_GET["sysid"];
$sqltype=_get("sqltype");
$restype=_get("restype");
$rescode=_get("rescode");
if ($sqltype=="createsql"){
  $sqlstr=tostring(UX("select sqlstring as result from coode_insdata where relytab='".$rescode."'"));
  $conn=mysql_connect(gl(),glu(),glp());
  $zz=updatingx($conn,glb(),$sqlstr,"utf8");
  $zz1=UX("update coode_insdata set STATUS=1 where relytab='".$rescode."'");
}else{
    if (restype=="tempx"){      
      $newpath=combineurl(localroot(),"/resjar/".$restype."/".qian($rescode,".")."/");
    }else{
      $newpath=combineurl(localroot(),"/resjar/".$restype."/".str_replace(".","_",$rescode)."/");
    }    
    $sqltxt=file_get_contents(combineurl($newpath,$rescode."_".$restype."-install.sql"));
    $ptsql=explode(huanhang(),$sqltxt);
    for ($nn=0;$nn<count($ptsql);$nn++){
      if ($ptsql[$nn]!=""){
        $svals=$ptsql[$nn];
        $svals=str_replace("〖","('",$svals);
        $svals=str_replace("〗","')",$svals);
        $svals=str_replace("∨","','",$svals);
        $svals=str_replace("丷",shuangyinhao(),$svals);        
        $svals=str_replace("@DYH@)","'",$svals);
        $svals=str_replace("(@DYH@","'",$svals);
        $nx=UX($svals);
      }
    }
$zz1=UX("update coode_insdata set STATUS=1 where relytab='".$restype."' and sqlstring='".$rescode."'");
}
echo makereturnjson("1","操作".$rescode."成功","");
     session_write_close();
?>