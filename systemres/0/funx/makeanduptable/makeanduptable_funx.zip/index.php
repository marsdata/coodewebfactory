<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tnm=$_GET["tablename"];
$kk='0';
$totpt=0;
$conn=mysql_connect(gl(),glu(),glp());
$trst=selecteds($conn,"information_schema","select TABLE_CATALOG,TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,ORDINAL_POSITION,COLUMN_DEFAULT,IS_NULLABLE,DATA_TYPE,CHARACTER_MAXIMUM_LENGTH,CHARACTER_OCTET_LENGTH,NUMERIC_PRECISION,NUMERIC_SCALE,CHARACTER_SET_NAME,COLLATION_NAME,COLUMN_TYPE,COLUMN_KEY,EXTRA,PRIVILEGES,COLUMN_COMMENT from COLUMNS where TABLE_SCHEMA='".glb()."' and TABLE_NAME='".$tnm."'","utf8","");
$totrst=countresult($trst);
$fmc="";
for ($k=0;$k<$totrst;$k++){
   $sTABLE_CATALOG[$k]=anyvalue($trst,"TABLE_CATALOG",$k);
   $sTABLE_SCHEMA[$k]=anyvalue($trst,"TABLE_SCHEMA",$k);
   $sTABLE_NAME[$k]=anyvalue($trst,"TABLE_NAME",$k);
   $sCOLUMN_NAME[$k]=anyvalue($trst,"COLUMN_NAME",$k);
   $sORDINAL_POSITION[$k]=anyvalue($trst,"ORDINAL_POSITION",$k);
   $sCOLUMN_DEFAULT[$k]=anyvalue($trst,"COLUMN_DEFAULT",$k);
   $sIS_NULLABLE[$k]=anyvalue($trst,"IS_NULLABLE",$k);
   $sDATA_TYPE[$k]=anyvalue($trst,"DATA_TYPE",$k);
   $sCHARACTER_MAXIMUM_LENGTH[$k]=anyvalue($trst,"CHARACTER_MAXIMUM_LENGTH",$k);
   $sCHARACTER_OCTET_LENGTH[$k]=anyvalue($trst,"CHARACTER_OCTET_LENGTH",$k);
   $sNUMERIC_PRECISION[$k]=anyvalue($trst,"NUMERIC_PRECISION",$k);
   $sNUMERIC_SCALE[$k]=anyvalue($trst,"NUMERIC_SCALE",$k);
   $sCHARACTER_SET_NAME[$k]=anyvalue($trst,"CHARACTER_SET_NAME",$k);
   $sCOLLATION_NAME[$k]=anyvalue($trst,"COLLATION_NAME",$k);
   $sCOLUMN_TYPE[$k]=anyvalue($trst,"COLUMN_TYPE",$k);
   $sCOLUMN_KEY[$k]=anyvalue($trst,"COLUMN_KEY",$k);
   $sEXTRA[$k]=anyvalue($trst,"EXTRA",$k);
   $sPRIVILEGES[$k]=anyvalue($trst,"PRIVILEGES",$k);
   $sCOLUMN_COMMENT[$k]=anyvalue($trst,"COLUMN_COMMENT",$k);
   $somark[$k]=date('Ymdhis').getRandChar(6);
  switch($sDATA_TYPE[$k]){
    case "int":
    if ($sCOLUMN_NAME[$k]=="SNO"){
      $fmc=$fmc.$sCOLUMN_NAME[$k]." int(11) NOT NULL AUTO_INCREMENT,";
    }else{
      $fmc=$fmc.$sCOLUMN_NAME[$k]." int(11) NOT NULL,";
    }
    break;
    case "bigint":
    if ($sCOLUMN_NAME[$k]=="SNO"){
      $fmc=$fmc.$sCOLUMN_NAME[$k]." bigint(20) NOT NULL AUTO_INCREMENT,";
    }else{
      $fmc=$fmc.$sCOLUMN_NAME[$k]." bigint(20) NOT NULL,";
    }
    break;
    case "tinyint":
    if ($sCOLUMN_NAME[$k]=="SNO"){
      $fmc=$fmc.$sCOLUMN_NAME[$k]." tinyint(4) NOT NULL AUTO_INCREMENT,";
    }else{
      $fmc=$fmc.$sCOLUMN_NAME[$k]." tinyint(4) NOT NULL,";
    }
    break;
    case "decimal":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." decimal(10,2) NOT NULL,";
    break;
    case "varchar":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." varchar(".$sCHARACTER_MAXIMUM_LENGTH[$k].") NOT NULL,";
    break;
    case "text":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." text NOT NULL,";
    break;
    case "longtext":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." longtext NOT NULL,";
    break;
    case "date":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." date NOT NULL,";
    break;
    case "datetime":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." datetime NOT NULL,";
    break;    
    default:
   }  
 }//for
 $fmc=$fmc."PRIMARY KEY (SNO),";
  $btree=betrees($tnm);
  if ($btree==""){
    $fmc=killlaststr($fmc);
  }else{
    $fmc=$fmc.$btree;
  }
  $crtsql="CREATE TABLE ".$tnm." (".$fmc.") ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;";
  $q=UX("update coode_tablist set createsql='".$crtsql."' where TABLE_NAME='".$tnm."' and schm='".glb()."'");
  $p=UX("update coode_pagefuntab set sdata='".$crtsql."' where sourceid='".$tnm."' and sourcecls='tab'");
 echo "1";
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>