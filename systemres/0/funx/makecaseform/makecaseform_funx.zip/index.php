<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $cfid=$_GET["cfid"];
$contrst=SX("select SNO,cssfiles,jsfiles,stylex,scriptx,casevarchar,casetext,caseclstxt,caseclsduo,casedate,casedttm,caseint,casesrd,caserow,casedecimal,caseimage,caseimgx,casefile,caseduofile,casecheck,caseinline from coode_caseform where cfid='".$cfid."'");//比较公私分离是否成功,展示比较用hcss2
$fmcode="";
$casecode["varchar"]=anyvalue($contrst,"casevarchar",0);
$fmcode=$fmcode."codevarchar='".$casecode["varchar"]."';\r\n";
$casecode["text"]=anyvalue($contrst,"casetext",0);
$fmcode=$fmcode."codetext='".$casecode["text"]."';\r\n";
$casecode["tarea"]=anyvalue($contrst,"casetext",0);
$fmcode=$fmcode."codetarea='".$casecode["tarea"]."';\r\n";
$casecode["clstxt"]=anyvalue($contrst,"caseclstxt",0);
$fmcode=$fmcode."codeclstxt='".$casecode["clstxt"]."';\r\n";
$casecode["clsduo"]=anyvalue($contrst,"caseclsduo",0);
$fmcode=$fmcode."codeclsduo='".$casecode["clsduo"]."';\r\n";
$casecode["date"]=anyvalue($contrst,"casedate",0);
$fmcode=$fmcode."codedate='".$casecode["date"]."';\r\n";
$casecode["dttm"]=anyvalue($contrst,"casedttm",0);
$fmcode=$fmcode."codedttm='".$casecode["dttm"]."';\r\n";
$casecode["int"]=anyvalue($contrst,"caseint",0);
$fmcode=$fmcode."codeint='".$casecode["int"]."';\r\n";
$casecode["decimal"]=anyvalue($contrst,"casedecimal",0);
$fmcode=$fmcode."codedecimal='".$casecode["decimal"]."';\r\n";
$casecode["image"]=anyvalue($contrst,"caseimage",0);
$fmcode=$fmcode."codeimage='".$casecode["image"]."';\r\n";
$casecode["imgx"]=anyvalue($contrst,"caseimgx",0);
$fmcode=$fmcode."codeimgx='".$casecode["imgx"]."';\r\n";
$casecode["filex"]=anyvalue($contrst,"casefile",0);
$fmcode=$fmcode."codefilex='".$casecode["filex"]."';\r\n";
$casecode["duofile"]=anyvalue($contrst,"caseduofile",0);
$fmcode=$fmcode."codeduofile='".$casecode["duofile"]."';\r\n";
$casecode["check"]=anyvalue($contrst,"casecheck",0);
$fmcode=$fmcode."codecheck='".$casecode["check"]."';\r\n";
$casecode["inline"]=anyvalue($contrst,"caseinline",0);
$fmcode=$fmcode."codeinline='".$casecode["inline"]."';\r\n";
$casecode["row"]=anyvalue($contrst,"caserow",0);
$fmcode=$fmcode."coderow='".$casecode["row"]."';\r\n";
$casecode["srd"]=anyvalue($contrst,"casesrd",0);
$fmcode=$fmcode."codesrd='".$casecode["srd"]."';\r\n";
$x=overfile(combineurl(localroot(),"/DNA/DFT/".$cfid."_caseform.js"),$fmcode);
echo $fmcode;
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>