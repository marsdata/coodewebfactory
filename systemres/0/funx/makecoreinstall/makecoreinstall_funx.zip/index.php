<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $fmtablist="";
$fmfunlist="";
$fmclslist="";
$fmdatalist="";
$fmcdt="";
$sysid="0";
 $motherhost=UX("select motherhost as result from coode_sysinformation where sysid='0'");
$z=anyfunrun("bakdtf","","","");
$srddemo='configdata={"sysid":"'.$sysid.'","motherhost":"'.$motherhost.'","unitnum":"[unum]","menunum":"[mnum]","plotnum":"[pnum]","pagenum":"[pgnum]","cformnum":"[cfnum]","chtmlnum":"[chnum]","dunitnum":"[dunum]","tablist":[demotab],"funlist":[demofunlist],"clslist":[democlslist],"datalist":[demodata]}';
$unum=anyfunrun("baknottable","","sysid=".$sysid."&srctype=face","");
$unum=anyfunrun("baknottable","","sysid=".$sysid."&srctype=const","");
$unum=anyfunrun("baknottable","","sysid=".$sysid."&srctype=varv","");
$mnum=anyfunrun("baknottable","","sysid=".$sysid."&srctype=menu","");
$pnum=anyfunrun("baknottable","","sysid=".$sysid."&srctype=plot","");
$dunum=anyfunrun("baknottable","","sysid=".$sysid."&srctype=dunit","");
$srddemo=str_replace("[unum]",$unum,$srddemo);
$srddemo=str_replace("[mnum]",$mnum,$srddemo);
$srddemo=str_replace("[pnum]",$pnum,$srddemo);
$srddemo=str_replace("[pgnum]",$pgnum,$srddemo);
$srddemo=str_replace("[cfnum]",$cfnum,$srddemo);
$srddemo=str_replace("[chnum]",$chnum,$srddemo);
$srddemo=str_replace("[dunum]",$dunum,$srddemo);
$trst=SX("select TABLE_NAME,createsql,tabtitle,VRT from coode_tablist where sysid='0'");
$tott=countresult($trst);
for ($i=0;$i<$tott;$i++){
  $fmtablist=$fmtablist."{\"tabtitle\":\"".anyvalue($trst,"tabtitle",$i)."\",\"tabname\":\"".anyvalue($trst,"TABLE_NAME",$i)."\"},";  
  $fmcdt=$fmcdt." srcid='".anyvalue($trst,"TABLE_NAME",$i)."' or ";  
}
$fmcdt=$fmcdt." srcid='dataformat' or srcid='0_tiny' or srcid='0_sys' or srcid like '".$sysid."%page' or srcid like '".$sysid."%menu' or srcid like '".$sysid."%unit' or srcid like concat('0%','case') or srcid like '0%chtml'  or srcid='0_plot'  or srcid='0_plst'  or  srcid like '".$sysid."%dmunit' or ";
$fmcdt=substr($fmcdt,0,strlen($fmcdt)-3);
$fmtablist=killlaststr($fmtablist);
$frst=SX("select funname,funcname,funfull from coode_funlist where sysid='0'");
$totf=countresult($frst);
for ($i=0;$i<$totf;$i++){
  $fmfunlist=$fmfunlist."{\"funtitle\":\"".anyvalue($frst,"funcname",$i)."\",\"funname\":\"".str_replace("()","",anyvalue($frst,"funname",$i))."\"},";
}
$fmfunlist=killlaststr($fmfunlist);
$frst=SX("select funname,funcname,funfull from coode_phpcls where sysid='0'");
$totf=countresult($frst);
for ($i=0;$i<$totf;$i++){
  $froot=combineurl(localroot(),"/DEVELOPING/0/install/funandcls/".str_replace("()","",anyvalue($frst,"funname",$i)).".txt");
  //$z=overfile($froot,anyvalue($frst,"funfull",$i)); 
  $fmclslist=$fmclslist."{\"funtitle\":\"".anyvalue($frst,"funcname",$i)."\",\"funname\":\"".str_replace("()","",anyvalue($frst,"funname",$i))."\"},";
}
$fmclslist=killlaststr($fmclslist);
$drst=SX("select datasql,tabname,frmsql,tabolmk,mymd5 from coode_datainstall where ".$fmcdt);
$totd=countresult($drst);
$dataarr=array(array());
$dataarr=arrdata($dataarr,$drst);
for ($i=1;$i<$totd+1;$i++){
  $fmdatalist=$fmdatalist."{\"tabolmk\":\"".$dataarr["tabolmk"][$i]."@".$dataarr["tabname"][$i]."\",\"mymd5\":\"".$dataarr["mymd5"][$i]."\"},";
}
$fmdatalist=killlaststr($fmdatalist);
$srddemo=str_replace("demotab",$fmtablist,$srddemo);
$srddemo=str_replace("demofunlist",$fmfunlist,$srddemo);
$srddemo=str_replace("democlslist",$fmclslist,$srddemo);
$srddemo=str_replace("demodata",$fmdatalist,$srddemo);
 $froot=combineurl(localroot(),"/DEVELOPING/0/install/js/config.js");
$z=overfile($froot,$srddemo); 
header("location:/DEVELOPING/0/install/baktab.html");
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>