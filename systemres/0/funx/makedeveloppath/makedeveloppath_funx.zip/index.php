<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $sysid=$_GET["sysid"];
 is_dir(localroot()."DEVELOPING/".$sysid) OR mkdir(localroot()."DEVELOPING/".$sysid, 0777, true); 
 copy_dir(localroot()."DEVELOPING/x/install",localroot()."DEVELOPING/".$sysid."/install");  
    is_dir(localroot()."DEVELOPED/allsys") OR mkdir(localroot()."DEVELOPED/allsys", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/DNA") OR mkdir(localroot()."DEVELOPED/allsys/DNA", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/RNA") OR mkdir(localroot()."DEVELOPED/allsys/RNA", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/BIOL") OR mkdir(localroot()."DEVELOPED/allsys/BIOL", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/SPEC") OR mkdir(localroot()."DEVELOPED/allsys/SPEC", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/FACE") OR mkdir(localroot()."DEVELOPED/allsys/FACE", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/ORG") OR mkdir(localroot()."DEVELOPED/allsys/ORG", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/PARA") OR mkdir(localroot()."DEVELOPED/allsys/PARA", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/SYS") OR mkdir(localroot()."DEVELOPED/allsys/SYS", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/SYS/0") OR mkdir(localroot()."DEVELOPED/allsys/SYS/0", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/SYS/0/install") OR mkdir(localroot()."DEVELOPED/allsys/SYS/0", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/SYS/1") OR mkdir(localroot()."DEVELOPED/allsys/SYS/1", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/SYS/1/install") OR mkdir(localroot()."DEVELOPED/allsys/SYS/1/install", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/SYS/public") OR mkdir(localroot()."DEVELOPED/allsys/SYS/public", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/SYS/public/install") OR mkdir(localroot()."DEVELOPED/allsys/SYS/public/install", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/SYS/".$sysid) OR mkdir(localroot()."DEVELOPED/allsys/SYS/".$sysid, 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/SYS/".$sysid."/install") OR mkdir(localroot()."DEVELOPED/allsys/SYS/".$sysid."/install", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/DEVELOPING") OR mkdir(localroot()."DEVELOPED/allsys/DEVELOPING", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/DEVELOPING/0") OR mkdir(localroot()."DEVELOPED/allsys/DEVELOPING/0", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/DEVELOPING/0/install") OR mkdir(localroot()."DEVELOPED/allsys/DEVELOPING/0/install", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/DEVELOPING/1") OR mkdir(localroot()."DEVELOPED/allsys/DEVELOPING/1", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/DEVELOPING/1/install") OR mkdir(localroot()."DEVELOPED/allsys/DEVELOPING/1/install", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/DEVELOPING/public") OR mkdir(localroot()."DEVELOPED/allsys/DEVELOPING/public", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/DEVELOPING/public/install") OR mkdir(localroot()."DEVELOPED/allsys/DEVELOPING/public/install", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/DEVELOPING/".$sysid) OR mkdir(localroot()."DEVELOPED/allsys/DEVELOPING/".$sysid, 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/DEVELOPING/".$sysid."/install") OR mkdir(localroot()."DEVELOPED/allsys/DEVELOPING/".$sysid."/install", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/DEVELOPING/x") OR mkdir(localroot()."DEVELOPED/allsys/DEVELOPING/x", 0777, true); 
   is_dir(localroot()."DEVELOPED/allsys/DEVELOPING/x/install") OR mkdir(localroot()."DEVELOPED/allsys/DEVELOPING/x/install", 0777, true); 
   copy_dir(localroot()."DEVELOPING/x/install",localroot()."DEVELOPED/allsys/DEVELOPING/x/install");  
   is_dir(localroot()."DEVELOPED/allsys/DEVELOPED") OR mkdir(localroot()."DEVELOPED/allsys/DEVELOPED", 0777, true); 
   copy_dir(localroot()."RNA",localroot()."DEVELOPED/allsys/RNA");   
   copy_dir(localroot()."DNA",localroot()."DEVELOPED/allsys/DNA");   
   copy_dir(localroot()."SPEC",localroot()."DEVELOPED/allsys/SPEC");
   copy_dir(localroot()."ORG",localroot()."DEVELOPED/allsys/ORG");
   copy_dir(localroot()."PARA",localroot()."DEVELOPED/allsys/PARA");
   
   is_dir(localroot()."DEVELOPED/".$sysid) OR mkdir(localroot()."DEVELOPED/".$sysid, 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/DNA") OR mkdir(localroot()."DEVELOPED/".$sysid."/DNA", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/RNA") OR mkdir(localroot()."DEVELOPED/".$sysid."/RNA", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/BIOL") OR mkdir(localroot()."DEVELOPED/".$sysid."/BIOL", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/SPEC") OR mkdir(localroot()."DEVELOPED/".$sysid."/SPEC", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/FACE") OR mkdir(localroot()."DEVELOPED/".$sysid."/FACE", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/ORG") OR mkdir(localroot()."DEVELOPED/".$sysid."/ORG", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/PARA") OR mkdir(localroot()."DEVELOPED/".$sysid."/PARA", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/SYS") OR mkdir(localroot()."DEVELOPED/".$sysid."/SYS", 0777, true); \
   is_dir(localroot()."DEVELOPED/".$sysid."/SYS/0") OR mkdir(localroot()."DEVELOPED/".$sysid."/SYS/0", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/SYS/0/install") OR mkdir(localroot()."DEVELOPED/".$sysid."/SYS/0", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/SYS/1") OR mkdir(localroot()."DEVELOPED/".$sysid."/SYS/1", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/SYS/1/install") OR mkdir(localroot()."DEVELOPED/".$sysid."/SYS/1/install", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/SYS/public") OR mkdir(localroot()."DEVELOPED/".$sysid."/SYS/public", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/SYS/public/install") OR mkdir(localroot()."DEVELOPED/".$sysid."/SYS/public/install", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/SYS/".$sysid) OR mkdir(localroot()."DEVELOPED/".$sysid."/SYS/".$sysid, 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/SYS/".$sysid."/install") OR mkdir(localroot()."DEVELOPED/".$sysid."/SYS/".$sysid."/install", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/DEVELOPING") OR mkdir(localroot()."DEVELOPED/".$sysid."/DEVELOPING", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/0") OR mkdir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/0", 0777, true);
   is_dir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/0/install") OR mkdir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/0", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/1") OR mkdir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/1", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/1/install") OR mkdir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/1/install", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/public") OR mkdir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/public", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/public/install") OR mkdir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/public/install", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/".$sysid) OR mkdir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/".$sysid, 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/".$sysid."/install") OR mkdir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/".$sysid."/install", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/x") OR mkdir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/x", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/x/install") OR mkdir(localroot()."DEVELOPED/".$sysid."/DEVELOPING/x/install", 0777, true); 
   is_dir(localroot()."DEVELOPED/".$sysid."/DEVELOPED") OR mkdir(localroot()."DEVELOPED/".$sysid."/DEVELOPED", 0777, true); 
   copy_dir(localroot()."RNA",localroot()."DEVELOPED/".$sysid."/RNA");   
   copy_dir(localroot()."DNA",localroot()."DEVELOPED/".$sysid."/DNA");   
   copy_dir(localroot()."SPEC",localroot()."DEVELOPED/".$sysid."/SPEC");
   copy_dir(localroot()."ORG",localroot()."DEVELOPED/".$sysid."/ORG");
   copy_dir(localroot()."PARA",localroot()."DEVELOPED/".$sysid."/PARA");
 
   is_dir(localroot()."DEVELOPED/basefiles") OR mkdir(localroot()."DEVELOPED/basefiles", 0777, true); 
   is_dir(localroot()."DEVELOPED/basefiles/DNA") OR mkdir(localroot()."DEVELOPED/basefiles/DNA", 0777, true); 
   is_dir(localroot()."DEVELOPED/basefiles/RNA") OR mkdir(localroot()."DEVELOPED/basefiles/RNA", 0777, true); 
   is_dir(localroot()."DEVELOPED/basefiles/BIOL") OR mkdir(localroot()."DEVELOPED/basefiles/BIOL", 0777, true); 
   is_dir(localroot()."DEVELOPED/basefiles/SPEC") OR mkdir(localroot()."DEVELOPED/basefiles/SPEC", 0777, true); 
   is_dir(localroot()."DEVELOPED/basefiles/FACE") OR mkdir(localroot()."DEVELOPED/basefiles/FACE", 0777, true); 
   is_dir(localroot()."DEVELOPED/basefiles/ORG") OR mkdir(localroot()."DEVELOPED/basefiles/ORG", 0777, true); 
   is_dir(localroot()."DEVELOPED/basefiles/PARA") OR mkdir(localroot()."DEVELOPED/basefiles/PARA", 0777, true); 
   is_dir(localroot()."DEVELOPED/basefiles/SYS") OR mkdir(localroot()."DEVELOPED/basefiles/SYS", 0777, true); 
   is_dir(localroot()."DEVELOPED/basefiles/DEVELOPING") OR mkdir(localroot()."DEVELOPED/basefiles/DEVELOPING", 0777, true); 
   is_dir(localroot()."DEVELOPED/basefiles/DEVELOPING/x") OR mkdir(localroot()."DEVELOPED/basefiles/DEVELOPING/x", 0777, true); 
   is_dir(localroot()."DEVELOPED/basefiles/DEVELOPING/x/install") OR mkdir(localroot()."DEVELOPED/basefiles/DEVELOPING/x/install", 0777, true); 
   is_dir(localroot()."DEVELOPED/basefiles/DEVELOPED") OR mkdir(localroot()."DEVELOPED/basefiles/DEVELOPED", 0777, true); 
   copy_dir(localroot()."RNA",localroot()."DEVELOPED/basefiles/RNA");   
   copy_dir(localroot()."DNA",localroot()."DEVELOPED/basefiles/DNA");   
   copy_dir(localroot()."SPEC",localroot()."DEVELOPED/basefiles/SPEC");
   copy_dir(localroot()."ORG",localroot()."DEVELOPED/basefiles/ORG");
   copy_dir(localroot()."PARA",localroot()."DEVELOPED/basefiles/PARA");   
 
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>