<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sno=$_GET["SNO"];
if ($sno!=""){
  $tinyrst=SX("select sysid,appid,layid,tempid,shortid,tinymark,longexp,laypath from coode_tiny where SNO=".$sno);
}
$tot=countresult($tinyrst);
if ($tot>0 and strpos($tinyrst,"报错")<=0){
 $sysid=anyvalue($tinyrst,"sysid",0);
 $appid=anyvalue($tinyrst,"appid",0);
 $layid=anyvalue($tinyrst,"layid",0);
 $laypath=anyvalue($tinyrst,"laypath",0);
 $tempid=anyvalue($tinyrst,"tempid",0);
 $shortid=anyvalue($tinyrst,"shortid",0);
 $tinyid=anyvalue($tinyrst,"tinymark",0);
 $longexp=tostring(anyvalue($tinyrst,"longexp",0));
if ($tempid!=""){
   $layf=combineurl(localroot(),"/localxres/tempx/".qian($tempid,"."));
   $layp=combineurl(localroot(),"/localxres/pagex/".qian($tempid,".")."/".$tinyid);
   $tempout=UX("select outurl as result from coode_domainunit where dumark='".$tempid."'");
   $newlx="/localxres/pagex/".$sysid."/".qian($tempid,".")."/".hou($tempid,".").".html";
   is_dir($layp) OR mkdir($layp, 0777, true);  
   
   copy_dir($layf,$layp);             
       
   echo anyfunrun("maketinyshow","","tinyid=".$tinyid,"");
 }else{
  echo makereturnjson("0","渲染失败-缺少系统参数","");
 }//laypath
}else{
 echo makereturnjson("0","渲染失败-有报错","");
}//报-错
     session_write_close();
?>