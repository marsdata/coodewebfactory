<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tabnm=$_GET["tabname"];
$tabsno=$_GET["tabsno"];
$tabkey=$_GET["tabkey"];
$prekey=$_GET["prekey"];
$preval=$_GET["key".$prekey];
$xsx=SX("select COLUMN_NAME,acthtml,clstxt,dxtype from coode_keydetailx where TABLE_NAME='".$tabnm."'");
$tot=countresult($xsx);
$fmk="";
for ($i=0;$i<$tot;$i++){
  $fmk=$fmk.anyvalue($xsx,"COLUMN_NAME",$i).",";
  if (anyvalue($xsx,"COLUMN_NAME",$i)==$tabkey){
   $newonex=anyvalue($xsx,"clstxt",$i);
   $acthtmlx=tostring(anyvalue($xsx,"acthtml",$i));
   $dxtype=tostring(anyvalue($xsx,"dxtype",$i));   
  }
}
$dvalue=".";//因为变换选项，所以不存在值
        $fmk=killlaststr($fmk);
                    if (strpos($prekey,",")>0){
                      $ptpre=explode(",",$prekey);
                      $totpt=count($ptpre);
                      for ($i=0;$i<$totpt;$i++){
                        $prepts[$i]=$_GET["key".$ptpre[$i]];
                      }                       
                    }
                    if (strpos($newonex,"key")>0 ){
                      $prerst=SX("select ".$fmk." from ".$tabnm." where SNO=".$tabsno);
                      for ($i=0;$i<$tot;$i++){
                       $_GET["key".anyvalue($xsx,"COLUMN_NAME",$i)]=anyvalue($prerst,anyvalue($xsx,"COLUMN_NAME",$i),0);
                      }
                    }; 
                    if (strpos($prekey,",")>0){
                     for ($i=0;$i<$totpt;$i++){
                       $_GET["key".$ptpre[$i]]=$prepts[$i];
                     };
                    }else{                     
                     $_GET["key".$prekey]=$preval;                                         
                    }
                    $newonex=str_replace("[","",$newonex);
                    $newonex=str_replace("]","",$newonex);
                    $newonex=str_replace("{","",$newonex);
                    $newonex=str_replace("}","",$newonex);
                      if (strpos($newonex,",")>0){
                       $ptnewo=explode(",",$newonex);
                       $totpn=count($ptnewo);
                       $fmmaq="";
                       $fmmah="";
                       for($zm=0;$zm<$totpn-1;$zm++){
                         $bknw=anyshort($ptnewo[$zm],"","");
                         $fmmaq=$fmmaq.qian($bknw,"|").",";
                         $fmmah=$fmmah.hou($bknw,"|").",";
                       }
                        $bknw=anyshort($ptnewo[$totpn-1],"","");
                        $fmmaq=$fmmaq.qian($bknw,"|");
                        $fmmah=$fmmah.hou($bknw,"|");
                        $newonex=$fmmaq."|".$fmmah;                             
                      }else{//发现有多个取值
                        $newonex=anyshort($newonex,"","");
                      }         
            $tmpact="";
            if (strlen($acthtmlx)>5){
              $sresult=array(array());              
              $tmpact=fmvalue($tbnm,$dvalue,$tabsno,$tabkey,$acthtmlx,1,$sresult);
             };
             if (strlen($tmpatn)>5){
               $ckcd=$tmpatn;
             }else{
               $ckcd=" onclick=\"qajaxp('修改记录','/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tabnm."&kies=".$tabkey."&SNO=".$tabsno."','p_".$tabkey.$tabsno."='+getduovalue('"."p_".$tabkey.$tabsno."'));\"";
             };
                 if ($dxtype=="clstxt"){
                     $fmtmpselect=formselect(qian($newonex,"|"),hou($newonex,"|"),$dvalue,"p_".$tabkey.$tabsno,"lay-select",$ckcd);                      
                 }                 
                 if ($dxtype=="clsduo"){                               
                     $fmtmpselect="<input type=\"hidden\" id=\""."p_".$tabkey.$tabsno."\" value=\"".$dvalue."\">".formselectx(qian($newonex,"|"),hou($newonex,"|"),$dvalue,"p_".$tabkey.$tabsno,"","");
                 };  
     echo $fmtmpselect;
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>