<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $sysid=$_GET["sysid"];
$aa=time();
$wrdidx=$_GET["wrdid"]; 
if ($sysid!=""){   
   $jurlx=combineurl(localroot(),"/systemres/".$sysid."/".$sysid.".json");
   $resjson=file_get_contents($jurlx);
   $savepath=combineurl(localroot(),"/systemres/".$sysid."/install/resjar/".$sysid.".json");
   $zz=overfile($savepath,$resjson);
   $json=json_decode($resjson,false);
   $totres=$json->totrcd;
   $jurlx=combineurl(localroot(),"/systemres/".$sysid."/".$sysid."01.json");
   $resjson=file_get_contents($jurlx);
   $savepath=combineurl(localroot(),"/systemres/".$sysid."/install/resjar/".$sysid."01.json");
   $zz=overfile($savepath,$resjson);
   
   $jurlx=combineurl(localroot(),"/systemres/".$sysid."/coode01.json");
   $resjson=file_get_contents($jurlx);
   $savepath=combineurl(localroot(),"/systemres/".$sysid."/install/resjar/coode01.json");
   $zz=overfile($savepath,$resjson);
   
   $jurlx=combineurl(localroot(),"/systemres/".$sysid."/basetab.json");
   $resjson=file_get_contents($jurlx);
   $savepath=combineurl(localroot(),"/systemres/".$sysid."/install/resjar/basetab.json");
   $zz=overfile($savepath,$resjson);
   
  if ($sysid!="0" and $sysid!="1"){
    $systt=UX("select sysname as result from coode_sysinformation where sysid='".$sysid."'");
    $fdir=combineurl(localroot(),"/localxres/tempx/stepregx/");
    $todir=combineurl(localroot(),"/systemres/".$sysid."/install/stepregx/");
    $zz1=copy_underdir($fdir,$todir);
    $fdir=combineurl(localroot(),"/localxres/tempx/runingbox/");
    $todir=combineurl(localroot(),"/systemres/".$sysid."/install/runingbox/");
    $zz1=copy_underdir($fdir,$todir);        
    $udf=combineurl(localroot(),"/localxres/tempx/stepregx/USERDEFINE.txt");
    $udb=combineurl(localroot(),"/systemres/".$sysid."/install/resjar/USERDEFINE.txt");
    $utxt=file_get_contents($udf);    
    $utxt=str_replace("[sysid]",$sysid,$utxt);
    $utxt=str_replace("[syscode]",getRandChar(6),$utxt);
    $utxt=str_replace("[systitle]",$systt,$utxt);
    $zz=overfile($udb,$utxt);
    $bb=time();
  echo makereturnjson("1","制作成功-耗时".($bb-$aa)."秒","");
 }else{
  echo makereturnjson("0","制作失败,缺少参数","");
 }
}else{
  if ($wrdidx!=""){
    $fdir=combineurl(localroot(),"/localxres/tempx/runingbox/");
    $todir=combineurl(localroot(),"/systemres/".$wrdidx."/install/runingbox/");
    $zz1=copy_underdir($fdir,$todir);   
    $tprst=SX("select SNO,tabtype,typecodex,typetitlex,linemark,objmarks from coode_wrdrestpdefine where worldmarks='".$wrdidx."'");
    $totr=countresult($tprst);
    $todir=combineurl(localroot(),"/systemres/".$wrdidx."/install/resjar/");
    for ($jj=0;$jj<$totr;$jj++){
      $rtype=anyvalue($tprst,"typecodex",$jj);
      $fdir3=combineurl(localroot(),"/systemres/".$wrdidx."/".$rtype."/");
      $zz3=copy_underdir($fdir3,$todir.$rtype."/");   
    }
    $bb=time();
    echo makereturnjson("1","制作成功-耗时".($bb-$aa)."秒","");
  }else{
    echo makereturnjson("0","制作失败,缺少参数","");
  }
}
       session_write_close();
?>