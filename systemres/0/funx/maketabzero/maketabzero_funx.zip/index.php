<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tabnm=_get("tabnm");
$plancode=_get("plancode");
$plrst=SX("select dumark,tinyid,tabname,tabkey,cdt from coode_datatopage where plancode='$plancode'");
$zz=UX("update ".$tabnm." set STATUS=1");
$dumark=anyvalue($plrst,"dumark",0);
$tinyid=anyvalue($plrst,"tinyid",0);
$tabnm=anyvalue($plrst,"tabname",0);
$tabkey=anyvalue($plrst,"tabkey",0);
$cdt=tostring(anyvalue($plrst,"cdt",0));
if ($cdt==""){
  $zz=UX("update ".$tabnm." set STATUS=0");
}else{
  $zz=UX("update ".$tabnm." set STATUS=0 where ".$cdt);
}
echo makereturnjson("1","设置表状态成功","");
     session_write_close();
?>