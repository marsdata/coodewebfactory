<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     //$nn=file_get_contents("users.php");
//$xx=str_replace('<?php','',$nn);
//eval($xx);
//$totpu=count($_USERS);
$totpu=0;
//$fmau="";
for ($t=0;$t<$totpu;$t++){
  if (strpos("x".$fmau,$_USERS[$t]["name"])>0){
  }else{
    $fmau=$fmau.$_USERS[$t]["name"].",";
  }
}
$conn=mysql_connect(gl(),glu(),glp());
$comlist=selecteds($conn,glb(),"select keyval,PTOF,companyid,groupid from coode_sysdefault where syskey='companyname'","utf8","");
$totcom=countresult($comlist);
$fmgrp="";
$fmcom="";
for ($i=0;$i<$totcom;$i++){
  if (strpos("x".$fmgrp,anyvalue($comlist,"groupid",$i))>0){
  }else{
    $fmgrp=$fmgrp.anyvalue($comlist,"groupid",$i).",";
    if (anyvalue($comlist,"groupid",$i)==anyvalue($comlist,"companyid",$i)){      
      $yy=createdir($gml."ORG/STORAGE/".anyvalue($comlist,"keyval",$i)."公共文件夹");
    }
  }
  if (strpos("x".$fmcom,anyvalue($comlist,"companyid",$i))>0){
  }else{
    $fmcom=$fmcom.anyvalue($comlist,"companyid",$i).",";
    $comgrp[anyvalue($comlist,"companyid",$i)]=anyvalue($comlist,"groupid",$i);
    $comnm[anyvalue($comlist,"companyid",$i)]=anyvalue($comlist,"keyval",$i);
    $comgrpname[anyvalue($comlist,"companyid",$i)]=anyvalue($comlist,"keyval",$i);
    $yy=createdir($gml."ORG/STORAGE/".anyvalue($comlist,"keyval",$i)."公共文件夹");    
  }
}
$fmdpt="";
$conn=mysql_connect(gl(),glu(),glp());
$dptlist=selecteds($conn,glb(),"select gid,grouptitle from coode_mygroup where ',".$fmcom.",' like concat('%,',cid,',%')","utf8","");
$totdpt=countresult($dptlist);
for ($j=0;$j<$totdpt;$j++){
  if (strpos("x".$fmdpt,anyvalue($dptlist,"cid",$j).anyvalue($dptlist,"gid",$j))>0){
  }else{
    $fmdpt=$fmdpt.anyvalue($dptlist,"cid",$j).anyvalue($dptlist,"gid",$j).",";
      $comdptnm[anyvalue($dptlist,"cid",$j).anyvalue($dptlist,"gid",$j)]= anyvalue($dptlist,"grouptitle",$j); 
      $yy=createdir($gml."ORG/STORAGE/".anyvalue($dptlist,"grouptitle",$j)."公共文件夹");    
  }
}
$conn=mysql_connect(gl(),glu(),glp());
$usrlist=selecteds($conn,glb(),"select userid,realname,depart,comp from coode_userlist where ',".$fmcom.",' like concat('%,',comp,',%') and passwd<>'' and depart<>''","utf8","");
$totusr=countresult($usrlist);
$fmusr="";
for ($j=0;$j<$totusr;$j++){
  if (strpos("x".$fmusr,anyvalue($dptlist,"userid",$j))>0){
  }else{
     $fmusr=$fmusr."u".anyvalue($usrlist,"userid",$j).",";      
      $yy=createdir($gml."ORG/STORAGE/u".anyvalue($usrlist,"userid",$j)."个人文件夹");    
     
    if (strpos("x".$fmau,anyvalue($usrlist,"userid",$j))>0){
    }else{
      //$fmau=$fmau.anyvalue($usrlist,"userid",$j).",";
      //$_USERS[$totpu]["name"]=anyvalue($usrlist,"userid",$j);
      //$_USERS[$totpu]["pass"]='$1$xSvU2wEa$Y.3Y0BLvdwi2fSsg60HUt0';
      //$_USERS[$totpu]["role"]='admin';
      //$_USERS[$totpu]["dir"]='["'.str_replace("\\","\\",unicode_encode($comgrpname[anyvalue($usrlist,"comp",$j)])."公共文件夹").'","'.str_replace("\\","\\",unicode_encode($comnm[anyvalue($usrlist,"comp",$j)])."公共文件夹").'","'.str_replace("\\","\\",unicode_encode($comdptnm[anyvalue($usrlist,"depart",$j)])."公共文件夹").'","u'.anyvalue($usrlist,"userid",$j).'"]';
      //$totpu=$totpu+1;
    }                                                             
  }//if
}//for
  //    $_USERS[$totpu]["name"]='coodesys';
   //   $_USERS[$totpu]["pass"]='$1$xSvU2wEa$Y.3Y0BLvdwi2fSsg60HUt0';
    //  $_USERS[$totpu]["role"]='superadmin';
     // $_USERS[$totpu]["email"]='58201123@qq.com';
      
//$c=var_export($_USERS,true);
//$otxt='<?php';
//$ktxt=$otxt."\r\n".$c.";";
//$px=overfile("users.php",$ktxt);
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>