<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $dlx=array();
$dlx=dirlist(combineurl(localroot(),"/localxres/iconsetx/"),$dlx);
for ($k=0;$k<count($dlx);$k++){
  $tmpdir=urlfname($dlx[$k]);
  $extx=UX("select count(*) as result from coode_iconset where setmark='".$tmpdir."'");
  if ($tmpdir!=""){
    if (intval($extx)==0){    
     $sqla="setarea,setmark,CRTM,UPTM,OLMK";
     $sqlb="'localxres','$tmpdir',now(),now(),'".onlymark()."'";
     $zz=UX("insert into coode_iconset(".$sqla.")values(".$sqlb.")");          
   }else{
     $zz=UX("update coode_iconset set UPTM=now() where setmark='".$tmpdir."'");
   }
 }
}
echo makereturnjson("1","新增成功","");
     session_write_close();
?>