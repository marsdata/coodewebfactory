<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $new=$_GET["new"];
$uid=$_GET["uid"];
$cid=$_GET["cid"];
$gid=$_GET["gid"];
$sid=atv("(coode_sysdefault@companyid='".$cid."' and syskey='service').keyval");
$newgrppos=anyfunrun("showanyorg","","cid=".$cid."config","");//铺展开group pos  的节点列表
$splid=atv("(coode_sysinformation@sysid='".$sid."').plotid");
$plevel=atv("(coode_plotlist@plotmark='".$splid."').levelcount");
$conn=mysql_connect(gl(),glu(),glp());
$frst=selecteds($conn,glb(),"select mymark,mytitle,myid from coode_plotdetail where plotmark='".$splid."' and parid=-1","utf8","");
$totf=countresult($frst);
$n=0;
for ($p=0;$p<$totf;$p++){
   $oricls[$n]=anyvalue($frst,"mymark",$p);
   $oriclnm[$n]=anyvalue($frst,"mytitle",$p)."应用";   
   $n=$n+1;
};
$psplid=atv("(coode_sysinformation@sysid='public').plotid");
$conn=mysql_connect(gl(),glu(),glp());
$pfrst=selecteds($conn,glb(),"select mymark,mytitle,myid from coode_plotdetail where plotmark='".$psplid."' and parid=-1","utf8","");
$totpf=countresult($pfrst);
for ($p=0;$p<$totpf;$p++){
   $oricls[$n]=anyvalue($pfrst,"mymark",$p);
   $oriclnm[$n]=anyvalue($pfrst,"mytitle",$p)."应用";   
   $n=$n+1;
};
for ($i=0;$i<($totf+$totpf);$i++){
  if ($i<$totf){
  }else{
   $plevel=atv("(coode_plotlist@plotmark='".$psplid."').levelcount");
   $sid='public';
  }
  if (($new*1)==1){//如果是第一次，则删除历史
     $conn=mysql_connect(gl(),glu(),glp());
     $xxx=updatings($conn,glb(),"delete from coode_plotmydetail where plotmark='oricls".$oricls[$i].$uid.$cid."'","utf8");
     $conn=mysql_connect(gl(),glu(),glp());
     $xxz=updatings($conn,glb(),"delete from coode_plotmylist where plotmark like '%".$uid."%'","utf8"); 
     $extp="0";
  }else{//如果不是第一次 看看是否存在如果存在后续不插入
     $conn=mysql_connect(gl(),glu(),glp());
     $extp=updatings($conn,glb(),"select count(*) as result from coode_plotmydetail where plotmark='oricls".$oricls[$i].$uid.$cid."'","utf8"); 
  }
   $conn=mysql_connect(gl(),glu(),glp());
   $y=updatings($conn,glb(),"insert into coode_plotmylist(plotmark,markname,CRTM,OLMK,UPTM)values('oricls".$oricls[$i].$uid.$cid."','".$oriclnm[$i]."',now(),'".onlymark()."',now())","utf8");   
   //登记个人节点
   //    echo $oricls[$i];
  if (($extp*1)==0){
    $conn=mysql_connect(gl(),glu(),glp());
    $pcls=selecteds($conn,glb(),"select keyval,grpid,keyid,imghead from coode_class where clsmark='sysappcls' and domain='".$sid."' and grpid='".$oricls[$i]."' and clientid='".$uid."' and compid='".$cid."' ","utf8","");//获取第一级的页面
    $totp=countresult($pcls);
    $conn=mysql_connect(gl(),glu(),glp());
    $myids=0;
    for ($j=0;$j<$totp;$j++){        
         $conn=mysql_connect(gl(),glu(),glp());
         $clsrst=selecteds($conn,glb(),"select appid,appname,groupvl,inurl,VRT,faceimg from coode_appmylist where owner='".$uid."' and VRT='".$oricls[$i]."' and groupvl='".anyvalue($pcls,"keyid",$j)."'","utf8","");
         $totcls=countresult($clsrst);         
        if ($plevel*1!=1){
          $myids=$myids+1;
          $paridx=$myids;
          //tiny设置完二级分类自动挂一级分类   这一行是第一级导航
          $conn=mysql_connect(gl(),glu(),glp());     
          $keya="plotmark,level,myid,parid,mytitle,mymark,parmark,orimark,myurl,myclick,CRTOR,mydescrib,prime,PTOF,CRTM,UPTM,STATUS";
          if ($totcls==1 and $plevel==2){//如果是三层 这里有totcls==1的情况，下面就不用在写totcls=1的情况
             $mclick="menuCAClick(\'".anyvalue($clsrst,"inurl",0)."\',this, \'page".getRandChar(6)."\')";                                 
             $vala="'oricls".$oricls[$i].$uid.$cid."',0,'".$myids."','-1','".anyvalue($pcls,"keyval",$j)."-".anyvalue($clsrst,"appname",0)."','".anyvalue($pcls,"keyid",$j)."','','','".anyvalue($clsrst,"myurl",0)."','".$mclick."','".$_COOKIE["uid"]."','".anyvalue($pcls,"imghead",$j)."',0,'".$cid."/@".qian($gid,",")."',now(),now(),1";
          }else{//totcls>则当导航
             $vala="'oricls".$oricls[$i].$uid.$cid."',0,'".$myids."','-1','".anyvalue($pcls,"keyval",$j)."','".anyvalue($pcls,"keyid",$j)."','','','javascript:void(0);','javascript:void(0);','".$_COOKIE["uid"]."','".anyvalue($pcls,"imghead",$j)."',0,'".$cid."/@".qian($gid,",")."',now(),now(),1";
             //同时小导航也要生成 吗的下边好像有
             //for($zz=0;$zz<$totcls;){
             // $myids=$myids+1;
             //$conn=mysql_connect(gl(),glu(),glp());             
             // $mclick="menuCAClick(\'".anyvalue($clsrst,"inurl",$zz)."\',this, \'page".getRandChar(6)."\')";  
             // $keya="plotmark,level,myid,parid,mytitle,mymark,parmark,orimark,myurl,myclick,CRTOR,mydescrib,prime,PTOF,CRTM,UPTM,STATUS";
             // $valz="'oricls".$oricls[$i].$uid.$cid."',0,'".$myids."','".$paridx."','".anyvalue($clsrst,"appname",$zz)."','".anyvalue($clsrst,"appid",$zz)."','','','".anyvalue($clsrst,"inurl",$zz)."',''".$mclick."'','".$_COOKIE["uid"]."','".anyvalue($clsrst,"imghead",$zz)."',0,'".$cid."/@".qian($gid,",")."',now(),now(),1";
            //  $yx=updatings($conn,glb(),"insert into coode_plotmydetail(".$keya.")values(".$valz.")","utf8");
            // }
          }
             $conn=mysql_connect(gl(),glu(),glp());             
             $yx=updatings($conn,glb(),"insert into coode_plotmydetail(".$keya.")values(".$vala.")","utf8");
        }else{         
        }//等于一的时候不插入
        for ($k=0;$k<$totcls;$k++){
          if (anyvalue($clsrst,"appname",$k)!=""){
            if ($plevel*1!=1){             
             //这一层是第二层的 如果plevel有三层这一层还要斟酌一下变成继续深入的
             //先看看还有没有第三层，如果有
             if ($totcls>1 and $plevel==2){//如果本层只有一项，而且是二级菜单，则一级里把INURL 纳入 而且还要看看一共有几层 不用考虑tcls=1情况，上面写了，没有下层了
              $myids=$myids+1;
              $keyb="plotmark,level,myid,parid,mytitle,mymark,parmark,orimark,myurl,myclick,CRTOR,mydescrib,prime,PTOF,CRTM,UPTM,STATUS";
              $mclick="menuCAClick(\'".anyvalue($clsrst,"inurl",$k)."\',this, \'page".getRandChar(6)."\')";                    
              $tinyx=getRandChar(4);            
              $valb="'oricls".$oricls[$i].$uid.$cid."',0,'".$myids."','".$paridx."','".anyvalue($clsrst,"appname",$k)."','".$tinyx."','','','".anyvalue($clsrst,"inurl",$k)."','".$mclick."','".$_COOKIE["uid"]."','".anyvalue($clsrst,"faceimg",$k)."',0,'".$cid."/@".qian($gid,",")."',now(),now(),1";
              $tinyx="";
              $conn=mysql_connect(gl(),glu(),glp());
              $yx=updatings($conn,glb(),"insert into coode_plotmydetail(".$keyb.")values(".$valb.")","utf8");
              //echo "insert into coode_plotmydetail(".$keyb.")values(".$valb.")";
             }else{//非plevel==2 and totcls>1 下面执行
                  $conn=mysql_connect(gl(),glu(),glp());
                  $cls3rst=selecteds($conn,glb(),"select appid,appname,groupvl,inurl,VRT,faceimg from coode_appmylist where owner='".$uid."' and VRT='".anyvalue($pcls,"keyid",$j)."' and groupvl='".anyvalue($clsrst,"groupvl",$k)."'","utf8","");
                  $tot3cls=countresult($clsrst);
               if ($plevel==3){//
                  if ($tot3cls==1){
                     $myids=$myids+1;                     
                     $keyb="plotmark,level,myid,parid,mytitle,mymark,parmark,orimark,myurl,myclick,CRTOR,mydescrib,prime,PTOF,CRTM,UPTM,STATUS";
                     $mclick="menuCAClick(\'".anyvalue($cls3rst,"inurl",$k)."\',this, \'page".getRandChar(6)."\')";                    
                     $tinyx=getRandChar(4);            
                     $apxname=atv("coode_class@clsmark='sysappcls' and compid='".$cid."' and clientid='".$uid."' and grpid='".anyvalue($pcls,"keyid",$j)."' and keyid='".anyvalue($clsrst,"groupvl",$k)."'");
                     $valb="'oricls".$oricls[$i].$uid.$cid."',0,'".$myids."','".$paridx."','".$apxname."-".anyvalue($cls3rst,"appname",0)."','".$tinyx."','','','".anyvalue($cls3rst,"inurl",0)."','".$mclick."','".$_COOKIE["uid"]."','".anyvalue($cls3rst,"faceimg",0)."',0,'".$cid."/@".qian($gid,",")."',now(),now(),1";
                     $tinyx="";
                     $conn=mysql_connect(gl(),glu(),glp());
                     $yx=updatings($conn,glb(),"insert into coode_plotmydetail(".$keyb.")values(".$valb.")","utf8");
                  }else{//tot3cls>1
                   $myids=$myids+1;     
                   $par3id=$myids;
                   $apxname=atv("coode_class@clsmark='sysappcls' and compid='".$cid."' and clientid='".$uid."' and grpid='".anyvalue($pcls,"keyid",$j)."' and keyid='".anyvalue($clsrst,"groupvl",$k)."'");
                   $keyb="plotmark,level,myid,parid,mytitle,mymark,parmark,orimark,myurl,myclick,CRTOR,mydescrib,prime,PTOF,CRTM,UPTM,STATUS";
                   $mclick="menuCAClick(\'".anyvalue($clsrst,"inurl",$k)."\',this, \'page".getRandChar(6)."\')";                    
                   $tinyx=getRandChar(4);            
                   $valb="'oricls".$oricls[$i].$uid.$cid."',0,'".$myids."','".$paridx."','".$apxname."','".$tinyx."','','','javascript:void(0)','javascript:void(0)','".$_COOKIE["uid"]."','".anyvalue($clsrst,"faceimg",$k)."',0,'".$cid."/@".qian($gid,",")."',now(),now(),1";
                   $tinyx="";
                   $conn=mysql_connect(gl(),glu(),glp());
                   $yx=updatings($conn,glb(),"insert into coode_plotmydetail(".$keyb.")values(".$valb.")","utf8");
                     for ($e=0;$e<$tot3cls;$e++){
                      $myids=$myids+1;                      
                      $keyb="plotmark,level,myid,parid,mytitle,mymark,parmark,orimark,myurl,myclick,CRTOR,mydescrib,prime,PTOF,CRTM,UPTM,STATUS";
                      $mclick="menuCAClick(\'".anyvalue($cls3rst,"inurl",$e)."\',this, \'page".getRandChar(6)."\')";                    
                      $tinyx=getRandChar(4);            
                      $valb="'oricls".$oricls[$i].$uid.$cid."',0,'".$myids."','".$par3id."','".anyvalue($cls3rst,"appname",$e)."','".$tinyx."','','','".anyvalue($cls3rst,"inurl",$e)."','".$mclick."','".$_COOKIE["uid"]."','".anyvalue($cls3rst,"faceimg",$e)."',0,'".$cid."/@".qian($gid,",")."',now(),now(),1";
                      $tinyx="";
                      $conn=mysql_connect(gl(),glu(),glp());
                      $yx=updatings($conn,glb(),"insert into coode_plotmydetail(".$keyb.")values(".$valb.")","utf8");
                     }//fore               
                  }//iftotcls3=1                  
               }//plevel=3               
             }//totcls>1 plevel2             
            }else{//一下PLEVEL==1
              $myids=$myids+1;
             //这一层是第二层的 如果plevel有三层这一层还要斟酌一下变成继续深入的
              $keyb="plotmark,level,myid,parid,mytitle,mymark,parmark,orimark,myurl,myclick,CRTOR,mydescrib,prime,PTOF,CRTM,UPTM,STATUS";
              $mclick="menuCAClick(\'".anyvalue($clsrst,"inurl",$k)."\',this, \'page".getRandChar(6)."\')";                    
               $tinyx=getRandChar(4);            
              $valb="'oricls".$oricls[$i].$uid.$cid."',0,'".$myids."',-1,'".anyvalue($pcls,"keyval",$j)."-".anyvalue($clsrst,"appname",$k)."','".$tinyx."','','','".anyvalue($clsrst,"inurl",$k)."','".$mclick."','".$_COOKIE["uid"]."','".anyvalue($clsrst,"faceimg",$k)."',0,'".$cid."/@".qian($gid,",")."',now(),now(),1";
              $tinyx="";
              $conn=mysql_connect(gl(),glu(),glp());
              $yx=updatings($conn,glb(),"insert into coode_plotmydetail(".$keyb.")values(".$valb.")","utf8");
              //以上是为1级菜单的情况        
            }//plevel
          }//if appname
        }//if totcls        
    }//tot totp:j
  }//if extp1=0
}//totf+totpf
echo "1";
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>