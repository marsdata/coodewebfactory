<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $fromurl=_post("fromurl");
 $otsurl=_post("otsurl");
 $otscode=qian($otsurl,"://"); 
 $otsu=qian(hou($otsurl,"://"),"/");
 $otspath=hou($otsurl,$otsu);
  
 $uidx=UX("select uid as result from users where name='".$otsu."'");
 if ($uidx!=""){
  if (strlen($uidx)==1){
   $uidy="0".$uidx;
  }else{
   $uidy=$uidx;
  }
  $fnm=urlfname($otsurl);
  $otspx=str_replace($fnm,"",$otspath);
  if (substr($otspx,0,1)=="/"){
   $otspy=hou($otspx,"/");
  }else{
   $otspy=$otspx;
  }
  $hsdir=0;
  $nparid='0';
  $nparpath='/';
 if (strpos($otspy,"/")>0){
   $ptots=explode("/",$otspy);
   $totp=count($ptots);
    for ($j=0;$j<$totp;$j++){
     switch($j){
       case 0:
       $extp=UX("select count(*) as result from filemap where uid='".$uidx."' and name='".$ptots[0]."'");
        if (intval($extp)==0){
          $sqlx="insert into filemap(name,uid,pid,path,isdir,type,size,origin,time)";
          $sqly="values('".$ptots[0]."','".$uidx."',0,'/',1,0,0,'os',now())";
          $zz=UX($sqlx.$sqly);         
        }
        $nrst=SX("select id,path,name from filemap where uid='".$uidx."' and pid=0 and name='".$ptots[0]."' and path='/'");
        $nparid=anyvalue($nrst,"id",0);
        $nnm=anyvalue($nrst,"name",0);
        $nparpath='/'.$ptots[0].'/';
       break;
       default:
       if ($ptots[$j]!=""){
        $prst=SX("select id,path from filemap where uid='".$uidx."' and name='".$ptots[$j-1]."'");
        $parid=anyvalue($prst,"id",0);
        $parpath=anyvalue($prst,"path",0);
        $extp=UX("select count(*) as result from filemap where uid='".$uidx."' and name='".$ptots[$j]."' and pid='".$parid."'");
        if (intval($extp)==0){
          $sqlx="insert into filemap(name,uid,pid,path,isdir,type,size,origin,time)";
          $sqly="values('".$ptots[$j]."','".$uidx."',".$parid.",'".$parpath."',1,0,0,'os',now())";
          $zz=UX($sqlx.$sqly);
        }
        $nrst=SX("select id,path,name from filemap where uid='".$uidx."' and pid='".$parid."' and name='".$ptots[$j]."'");
        $nparid=anyvalue($nrst,"id",0);
        $nparpath=anyvalue($nrst,"path",0).$ptots[$j]."/";
       }
     }//swc     
   }//forj
   $hsdir=1;
  }else{
   $hsdir=0;
  }
  
  $folmk=md5($otsurl);
  $kzm=kuozhanming($fnm);
  $fileurl=combineurl("http://".glw(),"/data/".$uidy."/".date("Ymd")."/".$folmk.".".$kzm);
  $lcfilepath=combineurl(localroot(),"/data/".$uidy."/".date("Ymd")."/".$folmk.".".$kzm);
  if (downanyfile($fromurl,$lcfilepath)){
     $fsize=filesize($lcfilepath);
     $stktab="cdots_filestock";
     $kzm=kuozhanming($fnm);
     $fvmd5=md5_file($lcfilepath);
     $extf=UX("select count(*) as result from ".$stktab." where otscode='".$otscode."' and filelcpath='".$lcfilepath."'");
     if (intval($extf)==0){
       $sqlx="otscode,otsuser,fileaskpath,otspath,filefrom,filelcpath,fileurl,filetype,filesize,stocktime,filevmd5,CRTM,UPTM,OLMK";
       $sqly="'$otscode','$uidx','$otsurl','$otspath','$fromurl','$lcfilepath','$fileurl','$kzm','$fsize','$fvmd5',now(),now(),now(),'".onlymark()."'";
       $zz=UX("insert into ".$stktab."(".$sqlx.")values(".$sqly.")");
     }else{
       $zz1=UX("update ".$stktab." set UPTM=now(),stocktime=now() where otscode='".$otscode."' and filelcpath='".$newpath."'");
     }
     $exti=UX("select count(*) as result from fileinfo where location='".$lcfilepath."'");
     if (intval($exti)==0){
       $sqlx="hash,mime,location,md5,size,time";
       $sqly="'$folmk','application/octet-stream','$lcfilepath','$fvmd5','$fsize',now()";
       $zz=UX("insert into fileinfo(".$sqlx.")values(".$sqly.")");       
     }else{
       $zz1=UX("update fileinfo set time=now() where  location='".$lcfilepath."'");
     }
        $extp=UX("select count(*) as result from filemap where uid='".$uidx."' and name='".$fnm."' and pid='".$nparid."'");
        if (intval($extp)==0){
          $sqlx="insert into filemap(name,location,mime,uid,pid,path,isdir,type,size,origin,time)";
          $sqly="values('".$fnm."','".$lcfilepath."','application/octet-stream','".$uidx."','".$nparid."','".$nparpath."',0,0,'".$fsize."','os',now())";
          $zz=UX($sqlx.$sqly);          
        }
     echo '{"status":"1","msg":"上传文件成功","cldurl":"'.$newurl.'"}';
  }else{
    echo makereturnjson("-1","上传文件失败","");
  }    
 }else{
  echo makereturnjson("-1","用户不存在","");
 }
 
 
     session_write_close();
?>