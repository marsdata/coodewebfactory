<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $plotmark=_get("plotmark");
$demo='{"id":[id],"parentId":[pid],"title":"[title]","url":"[url]","type":"[type]"},';
$ps=SX("select myid,parid,mytitle,myurl,orimark from coode_plotdetail where plotmark='".$plotmark."'");
$totx=countresult($ps);
$fmdemo;
for ($ii=0;$ii<intval($totx);$ii++){
  $sid=anyvalue($ps,"myid",$ii);
  $pid=anyvalue($ps,"parid",$ii);
  if (intval($pid)==-1){
    $pid="0";
  }
  $titlex=anyvalue($ps,"mytitle",$ii);
  $urlx=anyvalue($ps,"myurl",$ii);
  $typex=anyvalue($ps,"orimark",$ii);
  $demox=$demo;
  $demox=str_replace("[id]",$sid,$demox);
  $demox=str_replace("[pid]",$pid,$demox);
  $demox=str_replace("[title]",$titlex,$demox);
  $demox=str_replace("[url]",$urlx,$demox);
  $demox=str_replace("[type]",$typex,$demox);
  $fmdemo=$fmdemo.$demox;
}
echo '['.killlaststr($fmdemo).']';
       session_write_close();
?>