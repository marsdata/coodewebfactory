<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $dmark=$_GET["dmark"];
if ($dmark==""){
 $dmark=substr(md5($_SERVER["HTTP_REFERER"]),0,16);
}
$dtitle=$_GET["dtitle"];
$ddescrib=$_GET["ddescrib"];
$extx=UX("select count(*) as result from coode_datapost where datamark='".$dmark."'");
if (intval($extx)==0){
 $pe=UX("select posteval as result from coode_datapost where datamark='".$dmark."'");  
 eval(tostring($pe));
 echo "1";
}else{
 $demo="//".$ddescrib;
 $res = file_get_contents('php://input');
 $ptres=explode($res,"&");
 $pkeys=array();
 $totp=count($ptres);
 $tmpkeys="";
 $tmpvals="";
 $tmpvf="";
 $fmfff='function verifypost($valx,$vtype){'.huanhang();
 $fmfff=$fmfff.'  switch($vtype){'.huanhang();
 for ($i=0;$i<$totp;$i++){
   $tmpkeys=$tmpkeys.$ptres[$i].",";
   $tmpvals=$tmpvals."'$".$ptres[$i]."y',";
   $tmpvf=$tmpvf.'intval(verifypost($_POST["'.$ptres[$i].'"],""))*';
   $demo=$demo.'$'.$ptres[$i].'y=$_POST["'.$ptres[$i].'"];'.huanhang();
   $fmfff=$fmfff.'    case "'.$ptres[$i].'":'.huanhang();
   $fmfff=$fmfff.'    dosomejudgehere;'.huanhang();
   $fmfff=$fmfff.'    break;'.huanhang();   
 }
 $fmfff=$fmfff.'    default:'.huanhang();
 $fmfff=$fmfff.'    return 1;'.huanhang();
 $fmfff=$fmfff.'  }'.huanhang();
 $fmfff=$fmfff.'}'.huanhang();
 $fm000='if (('.killlaststr($tmpvf).')==1){'.huanhang();
 $fmaaa='$sqla="'.killlaststr($tmpkeys).'";'.huanhang();
 $fmbbb='$sqlb="'.killlaststr($tmpvals).'";'.huanhang();
 $fmccc='$sqlz=UX("insert into anytable($sqla)values($sqlb)");'.huanhang();
 $fm111='}'.huanhang();
 $demo=demo.$fm000.$fmaaa.$fmbbb.$fmccc.$fm111.$fmfff;
 $sqlx="datamark,datatitle,posteval,CRTOR,CRTM,UPTM,OLMK,fromurl";
 $sqly="'".$dmark."','".$dtitle."','".gohex($demo)."','".$_COOKIE["uid"]."',now(),now(),'".onlymark()."','".$_SERVER["HTTP_REFERER"]."'";
 $sqlz=UX("insert into coode_datapost(".$sqlx.")values(".$sqly.")");
 echo "0";
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>