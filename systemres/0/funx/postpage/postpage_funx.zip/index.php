<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $appid=$_GET["appid"];
$xurl=$_GET["xurl"];
$omk="";
if ($appid!="un"."defined" and $appid!=""){
    $omk=onlymark();
  $conn=mysql_connect(gl(),glu(),glp());
  $zz=updatings($conn,glb(),"delete from coode_pmass where STATUS=0 or (STATUS=1 and timestampdiff(minute,UPTM,now())>0 )","utf8");
  $conn=mysql_connect(gl(),glu(),glp());
  $xx=updatings($conn,glb(),"insert into coode_pmass(permid,permtitle,appid,compid,groupid,metcls,method,behiver,keyx,valx,dataarea,CRTM,UPTM,CRTOR,STATUS,PTOF,OLMK,clientid)select permid,permtitle,appid,compid,groupid,metcls,method,behiver,keyx,valx,dataarea,CRTM,UPTM,CRTOR,STATUS,PTOF,RAND()*1000000000,'".$omk."' from coode_pmiss where compid='".$_COOKIE["cid"]."' and groupid='".$_COOKIE["cid"]."/".$_COOKIE["gid"]."' and clientid='".$_COOKIE["uid"]."' and appid='".$appid."'","utf8");
  $conn=mysql_connect(gl(),glu(),glp());
  $yy=updatings($conn,glb(),"insert into coode_pmass(permid,permtitle,appid,compid,groupid,metcls,behiver,keyx,valx,dataarea,CRTM,UPTM,CRTOR,STATUS,PTOF,method,OLMK,clientid)select permid,permtitle,'".$appid."',compid,groupid,metcls,behiver,keyx,valx,dataarea,CRTM,UPTM,CRTOR,STATUS,PTOF,'".$xurl."',RAND()*1000000000,'".$omk."' from coode_pmiss where appid='postpage'","utf8");
}
echo $omk;
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>