<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include mdir().'RNA/EARTH.php';
    $stk=$_GET["stk"];
    if (strpos(_get("fid"),"login")<=0){
     setcookie("uid",$_COOKIE["uid"],time()+3600,"/");
     setcookie("cid",$_COOKIE["cid"],time()+3600,"/");
     setcookie("uid",$_COOKIE["userid"],time()+3600,"/");
     setcookie("cid",$_COOKIE["comid"],time()+3600,"/");
     setcookie("grpcid",$_COOKIE["grpcid"],time()+3600,"/");
     setcookie("depart",$_COOKIE["depart"],time()+3600,"/");
     setcookie("dpmore",$_COOKIE["dpmore"],time()+3600,"/");
     setcookie("posids",$_COOKIE["posids"],time()+3600,"/");
     setcookie("roleids",$_COOKIE["roleids"],time()+3600,"/");
     setcookie("sysid",$_COOKIE["sysid"],time()+3600,"/");
     setcookie("stoken",$_COOKIE["stoken"],time()+3600,"/");
     setcookie("deadline",time()+3600,time()+3600,"/");
    }
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $srctype=dftval($_GET["srctype"],"");
$srcmark=dftval($_GET["srcmark"],"");
switch($srctype){
  case "fun":
  $frst=SX("select funcname,funfull from coode_funlist where funname='".$srcmark."'");
  $fnm=anyvalue($frst,"funcname",0);
  $ffull=anyvalue($frst,"funfull",0);
  echo '{"status":"1","funtitle":"'.$fnm.'","funfull":"'.$ffull.'"}';
  break;
  case "tabkeyval":
   $skey=hou($fn,".");
   $sno=qian(hou($fn,"SNO:"),".");
   $tbnm=qian($fn,"@");
   $ffull=UX("select ".$skey." as result from ".$tbnm." where SNO='".$sno."'");
   echo '{"status":"1","funtitle":"","funfull":"'.$ffull.'"}';
  break;
  case "tabactshow":
   $ckey=hou($fn,".");
   $tbnm=qian(hou($fn,"@"),".");
   $skey=qian($fn,"@");
   $ffull=UX("select ".$skey." as result from coode_keydetailx where TABLE_NAME='".$tbnm."' and COLUMN_NAME='".$ckey."'");
   echo '{"status":"1","funtitle":"","funfull":"'.$ffull.'"}';
  break;
  case "temp":
  $trst=SX("select relyface,sysid,appid,unittitle,unitclass,unitdescrib,outurl,industry,business,matter,casecode,cssfilex,stylex,scriptx,jsfilex,cssfiley,jsfiley,styley,scripty,templatecode,demoresult,pagesurround from coode_domainunit where dumark='".$srcmark."'");
 $relyface=anyvalue($trst,"relyface",0);
 $tmpback=$tmpback."\"relyface\":\"".$relyface."\",";
 $sysid=anyvalue($trst,"sysid",0);
 $tmpback=$tmpback."\"sysid\":\"".$sysid."\",";
 $appid=anyvalue($trst,"appid",0);
 $tmpback=$tmpback."\"appid\":\"".$appid."\",";
 $unittitle=anyvalue($trst,"unittitle",0);
 $tmpback=$tmpback."\"unittitle\":\"".$unittitle."\",";
 $unitclass=anyvalue($trst,"unitclass",0);
 $tmpback=$tmpback."\"unitclass\":\"".$unitclass."\",";
 $unitdescrib=anyvalue($trst,"unitdescrib",0);
 $tmpback=$tmpback."\"unitdescrib\":\"".$unitdescrib."\",";
 $outurl=anyvalue($trst,"outurl",0);
 $tmpback=$tmpback."\"outurl\":\"".$outurl."\",";
 $industry=anyvalue($trst,"industry",0);
 $tmpback=$tmpback."\"industry\":\"".$industry."\",";
 $business=anyvalue($trst,"business",0);
 $tmpback=$tmpback."\"business\":\"".$business."\",";
 $matter=anyvalue($trst,"matter",0);
 $tmpback=$tmpback."\"matter\":\"".$matter."\",";
 $casecode=anyvalue($trst,"casecode",0);
 $tmpback=$tmpback."\"casecode\":\"".$casecode."\",";
 $cssfilex=anyvalue($trst,"cssfilex",0);
 $tmpback=$tmpback."\"cssfilex\":\"".$cssfilex."\",";
 $stylex=anyvalue($trst,"stylex",0);
 $tmpback=$tmpback."\"stylex\":\"".$stylex."\",";
 $scriptx=anyvalue($trst,"scriptx",0);
 $tmpback=$tmpback."\"scriptx\":\"".$scriptx."\",";
 $jsfilex=anyvalue($trst,"jsfilex",0);
 $tmpback=$tmpback."\"jsfilex\":\"".$jsfilex."\",";
 $cssfiley=anyvalue($trst,"cssfiley",0);
 $tmpback=$tmpback."\"cssfiley\":\"".$cssfiley."\",";
 $jsfiley=anyvalue($trst,"jsfiley",0);
 $tmpback=$tmpback."\"jsfiley\":\"".$jsfiley."\",";
 $styley=anyvalue($trst,"styley",0);
 $tmpback=$tmpback."\"styley\":\"".$styley."\",";
 $scripty=anyvalue($trst,"scripty",0); 
 $tmpback=$tmpback."\"scripty\":\"".$scripty."\",";
 $templatecode=anyvalue($trst,"templatecode",0);
 $tmpback=$tmpback."\"templatecode\":\"".$templatecode."\",";
 $demoresult=anyvalue($trst,"demoresult",0);
 $tmpback=$tmpback."\"demoresult\":\"".$demoresult."\",";
 $pagesurround=anyvalue($trst,"pagesurround",0);
  $tmpback=$tmpback."\"pagesurround\":\"".$pagesurround."\",";
  echo "{\"status\":\"1\",\"msg\":\"@succ\",".killlaststr($tmpback)."}";
  break;
  case "tab":
  $fmvls="";
  $dxrst=SX("select SNO,OLMK from coode_keydetailx where TABLE_NAME='".$srcmark."' ");
  $totdx=countresult($dxrst);
  for ($a=0;$a<$totdx;$a++){
     $snox=anyvalue($dxrst,"SNO",$a);
     $fmvls=$fmvls."{\"table\":\"coode_keydetailx\",\"SNO\":\"".$snox."\"},";
  }
  $dyrst=SX("select SNO,OLMK from coode_keydetaily where TABLE_NAME='".$srcmark."' ");
  $totdy=countresult($dyrst);
  for ($b=0;$b<$totdy;$b++){
     $snox=anyvalue($dyrst,"SNO",$b);
     $fmvls=$fmvls."{\"table\":\"coode_keydetaily\",\"SNO\":\"".$snox."\"},";
  }
  $dzrst=SX("select SNO,OLMK from coode_keydetailz where TABLE_NAME='".$srcmark."' ");
  $totdz=countresult($dzrst);
  for ($c=0;$c<$totdz;$c++){
     $snox=anyvalue($dzrst,"SNO",$c);
     $fmvls=$fmvls."{\"table\":\"coode_keydetailz\",\"SNO\":\"".$snox."\"},";
  }
  $dsrst=SX("select SNO,OLMK from coode_shortdata where tablename='".$srcmark."' ");
  $totds=countresult($dsrst);
  for ($s=0;$s<$totds;$s++){
     $snox=anyvalue($dsrst,"SNO",$s);
     $fmvls=$fmvls."{\"table\":\"coode_shortdata\",\"SNO\":\"".$snox."\"},";
  }
  $dsrst=SX("select SNO,OLMK from coode_shortcss where tablename='".$srcmark."' ");
  $totds=countresult($dsrst);
  for ($s=0;$s<$totds;$s++){
     $snox=anyvalue($dsrst,"SNO",$s);
     $fmvls=$fmvls."{\"table\":\"coode_shortdata\",\"SNO\":\"".$snox."\"},";
  }
  $dsrst=SX("select SNO,OLMK from coode_tablist where TABLE_NAME='".$srcmark."' ");
  $totds=countresult($dsrst);
  for ($s=0;$s<$totds;$s++){
     $snox=anyvalue($dsrst,"SNO",$s);
     $fmvls=$fmvls."{\"table\":\"coode_tablist\",\"SNO\":\"".$snox."\"},";
  }
  echo '{"status":"1","msg":"成功","vls":[".killlaststr($fmvls)."]}';
  break;
  default:
  
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>