<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
       eval(CLASSX("SignatureHelper"));
    $params = array ();  
    $accessKeyId = "LTAI4G3wbpQFRvJBeVAKrMtn";  
    $accessKeySecret = "yMyXcblDMxTCQK2HcZLAVo9d9qTeEn";  
    $params["PhoneNumbers"] = $_GET["mobile"];      
    $params["SignName"] = "鸿蓝大总管";   
    $msgtype=$_GET["msgtype"];    
    switch($msgtype){        
    case "khtz":
    $params["TemplateCode"] = "SMS_216426655";  
    $params['TemplateParam'] = Array (  
        "uname" => $_GET["uname"],"shijian" => $_GET["shijian"],"place" => $_GET["place"],"meetname" => $_GET["meetname"]
    ); 
    break;
    case "csmm":
    $params["TemplateCode"] = "SMS_213091342";  
    $params['TemplateParam'] = Array (  
        "code" => $_GET["code"]
    ); 
    break;
    case "sbsj":
    $params["TemplateCode"] = "SMS_210079952";  
    $params['TemplateParam'] = Array (  
        "mid" => $_GET["mid"] ,"mname" => $_GET["mname"] ,"event" => $_GET["event"]  
    ); 
    break;
    case "fytx":
    $params["TemplateCode"] = "SMS_209826403";  
    $params['TemplateParam'] = Array (  
        "name" => $_GET["name"] ,"num" => $_GET["num"]  
    ); 
    break;
    case "fyyc":
    $params["TemplateCode"] = "SMS_211485093";  
    $params['TemplateParam'] = Array (  
        "name" => $_GET["name"] ,"ptel" => $_GET["ptel"],"dui" => $_GET["dui"],"tiwen" => $_GET["tiwen"],"brjc" => $_GET["brjc"],"jrjc" => $_GET["jrjc"],"jrtw" => $_GET["jrtw"]
    ); 
    break;
    case "cxtj":
    $params["TemplateCode"] = "SMS_209831455";  
    $params['TemplateParam'] = Array ();
    break;
    case "rjdq":
    $params["TemplateCode"] = "SMS_207971144";  
    $params['TemplateParam'] = Array (  
        "sysmark" => $_GET["sysmark"] ,"address" => $_GET["address"]  
    ); 
    break;
    case "sbdq":
    $params["TemplateCode"] = "SMS_207971220";  
        $params['TemplateParam'] = Array (  
        "mid" => $_GET["mid"] ,"mname" => $_GET["mname"]  
    );     
    break;
    case "ddsbdq":
    $params["TemplateCode"] = "SMS_207971484";  
        $params['TemplateParam'] = Array (  
        "mid" => $_GET["mid"] ,"mname" => $_GET["mname"],"address" => $_GET["address"] 
    );     
    break;
    default:    
    }
    $params['OutId'] = onlymark();  
    
    $params['SmsUpExtendCode'] = "1234567";  
    // *** 需用户填写部分结束, 以下代码若无必要无需更改 ***  
    if(!empty($params["TemplateParam"]) && is_array($params["TemplateParam"])) {  
        $params["TemplateParam"] = json_encode($params["TemplateParam"], JSON_UNESCAPED_UNICODE);  
    }      
    $helper = new SignatureHelper();
    if ($_GET["mobile"]!="" && $_GET["msgtype"]!=""){
    $content = $helper->request(  
        $accessKeyId,  
        $accessKeySecret,  
        "dysmsapi.aliyuncs.com",  
        array_merge($params, array(  
            "RegionId" => "cn-hangzhou",  
            "Action" => "SendSms",  
            "Version" => "2017-05-25",  
        ))  
    );      
     $sqlx="acckid,acckse,mobile,signname,templatecode,backcontent,CRTM,UPTM,OLMK";
     $fmcon="RequestId:".$content->RequestId."@Message:".$content->Message."@BizId:".$content->BizID."@Code:".$content->Code;
     $sqly="'".$accessKeyId."','".$accessKeySecret."','".$params["PhoneNumbers"]."','".$params["SignName"]."','".$params["TemplateCode"]."','".$fmcon."',now(),now(),'".onlymark()."'";
     $sqlz=makenew("sms_blog",$sqlx,$sqly);
     //object(stdClass)#3 (4) { ["RequestId"]=> string(36) "508353BD-A5AF-4D99-9FDC-F49D4614BD43" ["Message"]=> string(2) "OK" ["BizId"]=> string(20) "684800609381557257'0" ["Code"]=> string(2) "OK" }
     //var_dump($content);  
    }else{
     echo "0";
    }
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>