<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       setcookie('uid',NULL);
setcookie('uid','deleted',time()-3600*24*367,'/');
setcookie('cid',NULL);
setcookie('cid','deleted',time()-3600*24*367,'/');
setcookie('depart',NULL);
setcookie('depart','deleted',time()-3600*24*367,'/');
setcookie('dpmore',NULL);
setcookie('dpmore','deleted',time()-3600*24*367,'/');
setcookie('posids',NULL);
setcookie('posids','deleted',time()-3600*24*367,'/');
setcookie('roleids',NULL);
setcookie('roleids','deleted',time()-3600*24*367,'/');
setcookie('sysid',NULL);
setcookie('sysid','deleted',time()-3600*24*367,'/');
setcookie('stoken',NULL);
setcookie('stoken','deleted',time()-3600*24*367,'/');
setcookie('deadline',NULL);
setcookie('deadline','deleted',time()-3600*24*367,'/');
echo makereturnjson("1","退出成功","");
       session_write_close();
?>