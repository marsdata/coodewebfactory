<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $ak=_post("ak");
$av=_post("av");
$faceids=_post("faceids");
$faceids=$faceids.",";
 $fromhost=_post("fromhost");
 $ptfc=explode(",",$faceids);
 for ($i=0;$i<count($ptfc);$i++){
  if ($ptfc[$i]!=""){
   $extf=UX("select count(*) as result from coode_facelist where faceid='".$ptfc[$i]."'");
   if (intval($extf)==0){
     $sqlx="faceid,csshost,CRTM,UPTM,OLMK,STATUS";
     $sqly="'$ptfc[$i]','$fromhost',now(),now(),'".onlymark()."',-2";
     $zz=UX("insert into coode_facelist(".$sqlx.")values(".$sqly.")");
   }else{
     $zz=UX("update coode_facelist set csshost='".$fromhost."',STATUS=-2 where faceid='".$ptfc[$i]."'");
   }//if extf
  }//ifptfc
 }//for
$extu=UX("select count(*) as result from coode_scvuser where apikey='".$ak."'");
if (intval($extu)==0){
  $sqlx="hostdomain,apikey,apival,lastvisit,CRTM,UPTM,hostrolex";
  $sqly="'$fromhost','$ak','$av',now(),now(),now(),'commonuser'";
  $zz=UX("insert into coode_scvuser(".$sqlx.")values(".$sqly.")");
}else{
  $z0=UX("update coode_scvuser set hostdomain='".$fromhost."',apival='".$av."' where  apikey='".$ak."'");
}
echo makereturnjson("1","告知成功",$faceids);
     session_write_close();
?>