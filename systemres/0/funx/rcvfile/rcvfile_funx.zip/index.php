<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $image=str_replace(' ','+',$_POST['src']);
$base_img = str_replace('data:image/jpeg;base64,', '', $image);
$base_img = str_replace('data:image/png;base64,', '', $base_img);
$markid=$_GET['markid'];
$pcls=$_GET['pcls'];
$sno=$_GET['sno'];
$numx=$_GET['numx'];
$pdtid=$_GET['pdtid'];//version
$clsa=$_GET['clsa'];
$clsb=$_GET['clsb'];
$olmk=$_GET['olmk'];
$conn=mysql_connect(gl(),glu(),glp());
$desc=updatings($conn,glb(),"select myname as result from app_aclass where classmark='".$pcls."' and parsno='".$clsa."' and mysno='".$clsb."'","utf8");

$extdkey=$_GET['ekey'];
if ($extdkey!="undefined" and $extdkey!="undefinedundefined" and $extdkey!="" and strpos($extdkey,";")>0){
 $extdkey=str_replace(",","|",$extdkey);
 $extkey=hou($extdkey,";");
 $extckey=qian($extdkey,";");
 if (substr($extckey,-1)=="|"){
  $extckey=substr($extckey,0,strlen($extckey)-1);
 }
 if (substr($extkey,-1)==","){
  $extkey=str_replace(",","|",substr($extkey,0,strlen($extkey)-1));
 };
 
}else{
 $extdkey="";
}



if (strpos("xx".$image,"http")>0){
  $picurl=$image;
}else{
  $imageName = "25220_".date("His",time())."_".rand(1111,9999).'.jpg';
  $path = "../images/".date("Ymd",time());
  if (!is_dir($path)){ //判断目录是否存在 不存在就创建
    mkdir($path,0777,true);
  }
  $imageSrc= $path."/". $imageName; //图片名字
  $picurl="http://".glw().$imageSrc;
  $dftpic="http://shifu.link/images/sfll.png";
} 
$ks="taskid,productcls,productmodel,productdescrib,version,picurl,tel,exkey,tasktitle,describ,price,num,unit,status,partof,createtime,onlymark";
$vs=$markid.",".$clsa.",".$clsb.",".$desc.",".$pdtid.",".$picurl.",,".$extdkey.",,,0,".$numx.",0,0,GUEST,".date("Y-m-d H:i:s").",".$olmk;
$cdtt="onlymark=".$olmk;
$xxx=upnew("sys_taskproduct",$ks,$vs,$cdtt);
//echo $xxx;
$conn=mysql_connect(gl(),glu(),glp());
$xx=updatings($conn,glb(),"update sys_taskext set pdtpic='".$picurl."' where pdtpic='".$dftpic."' and taskid='".$markid."'","utf8");
$ptek=explode("|",$extkey);
$ptck=explode("|",$extckey);
$totp=count($ptek);
for ($m=0;$m<$totp;$m++){
 $ksx="tablenm,ekey,extkey,extvalue,status,partof";
 $vsx="sys_taskproduct,".$ptck[$m].",".$ptek[$m].",".$_GET["p".$ptek[$m]].",0,";
 $cdttx="onlymark='".$markid.$sno.$ptek[$m]."' ";
 $xxxx=upnew("sys_extvalue",$ksx,$vsx,$cdttx);
};
if (strpos("xx".$image,";base64")>0){
  $ifp = fopen( $imageSrc, "wb" );
  fwrite( $ifp, base64_decode($base_img));
  if (!$ifp) {
   $tmparr1=array('data'=>null,"code"=>1,"msg"=>"图片生成失败");
   echo json_encode($tmparr1);
  }else{
   $tmparr2=array('data'=>1,"code"=>0,"msg"=>"图片生成成功");
   echo json_encode($tmparr2);
  }
}else{
    $tmparr2=array('data'=>1,"code"=>0,"msg"=>"NO NEED TO CREATE");
   echo json_encode($tmparr2);
    
}

     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>