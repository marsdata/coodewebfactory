<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $plotmark=_get("plotmark");
$totx=_get("totx");
$deeplv=0;
for ($ii=0;$ii<intval($totx);$ii++){
  $newid=$_POST["poid".$ii];
  $parid=$_POST["poparid".$ii];
  if (intval($parid)==0){
    $parid="-1";
  }else{
  }
  $titlex=$_POST["title".$ii];
  $urlx=$_POST["url".$ii];
  if (intval($parid)<=0){
    $omark="folder";
    $lv=1;
  }else{
    $lv=intval(UX("select level as result from coode_plotdetail where plotmark='".$plotmark."' and myid='".$parid."'"))+1;
    $omark="file";
    $nn=UX("update coode_plotdetail set orimark='folder' where myid='".$parid."' and plotmark='".$plotmark."'");
  }
  $extplot=UX("select count(*) as result from coode_plotdetail where myid='".$newid."' and parid='".$parid."' and plotmark='".$plotmark."'");
  if ($extplot*1==0){
    $sqlx="plotmark,CRTM,UPTM,myid,parid,mytitle,myurl,mymark,orimark,level";
    $sqly="'".$plotmark."',now(),now(),'".$newid."','".$parid."','".$titlex."','".$urlx."','".getRandChar(4)."','".$omark."','".$lv."'";
    $zz=UX("insert into coode_plotdetail(".$sqlx.")values(".$sqly.")");
  }else{
    $zz=UX("update coode_plotdetail set UPTM=now(),mytitle='".$titlex."',myurl='".$urlx."' where myid='".$newid."' and parid='".$parid."' and plotmark='".$plotmark."'");
  }
  if ($lv>=$deeplv){
    $deeplv=$lv;
  }  
}
$extp=UX("select count(*) as result from coode_plotlist where plotmark='".$plotmark."'");
if (intval($extp)==0){
  $new=UX("insert coode_plotlist(plotmark,markname,CRTM,UPTM,CRTOR)values('".$plotmark."','".$plotmark."',now(),now(),'".$_COOKIE["uid"]."')");
}
$uu=UX("update coode_plotlist set levelcount='".$deeplv."' where plotmark='".$plotmark."'");
$zzz=anyfunrun("retabsno","","tabnm=coode_plotdetail","");
echo makereturnjson("1","接收成功","");
       session_write_close();
?>