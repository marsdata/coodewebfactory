<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $pushmark=dftval($_GET["pushmark"],"");
$fromhost=dftval($_GET["fromhost"],"");
$restype=dftval($_GET["restype"],"");
$rescode=dftval($_GET["rescode"],"");
$vermd5=dftval($_GET["vermd5"],"");
$sysid=dftval($_GET["sysid"],"");
$restitle=dftval($_GET["restitle"],"");
if (es($fromhost)*es($restype)*es($rescode)==1){
  if (strpos($sysid,",")>0){
    $ptsys=explode(",",$sysid);
    $ptver=explode(",",$vermd5);
    $ptcode=explode(",",$rescode);
    $pttype=explode(",",$restype);
    $ptname=explode(",",$restitle);
    for ($kk=0;$kk<count($ptsys);$kk++){
     if ($ptsys[$kk]!=""){
      $sqlx="fromhost,sysid,resid,restype,pushmark,vermd5,restitle,pushtime,CRTM,UPTM,OLMK";
      $sqly="'$fromhost','".$ptsys[$kk]."','$ptcode[$kk]','$pttype[$kk]','$pushmark$kk','$ptver[$kk]','$ptname[$kk]',now(),now(),now(),'".onlymark()."'";
      $zz=UX("insert into coode_rcvres(".$sqlx.")values(".$sqly.")");
      $zzz=UX("update coode_rcvres set pushtime=now() where fromhost='".$fromhost."' and sysid='".$ptsys[$kk]."' and resid='".$ptcode[$kk]."' and restype='".$pttype[$kk]."'");
     }
    }
  }else{
   $sqlx="fromhost,sysid,resid,restype,pushmark,vermd5,restitle,pushtime,CRTM,UPTM,OLMK";
   $sqly="'$fromhost','".$sysid."','$rescode','$restype','$pushmark','$vermd5','$restitle',now(),now(),now(),'".onlymark()."'";
   $zz=UX("insert into coode_rcvres(".$sqlx.")values(".$sqly.")");
   $zzz=UX("update coode_rcvres set pushtime=now() where fromhost='".$fromhost."' and sysid='".$sysid."' and resid='".$rescode."' and restype='".$restype."'");
  }
 echo makereturnjson("1","接收成功","");
}else{
 echo makereturnjson("0","缺少参数","");
}
     session_write_close();
?>