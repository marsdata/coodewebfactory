<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $code =$_GET['code'];
$state =$_GET['state'];
$vxarea=$_COOKIE["vxarea"];
$appid=constval($vxarea."vxappid");
$appsecret=constval($vxarea."vxappse");
$mobile=$_COOKIE["logintel"];
$loginvfcode=$_COOKIE["loginvfcode"];
$fromhost=$_COOKIE["fromhost"];
$areatype=$_COOKIE["areatype"];
$areacode=$_COOKIE["areacode"];
$pgstoken=$_COOKIE["pagestoken"];
$orihost="";
if (strpos($fromhost,":")>0){
  $dkh=hou($fromhost,":");
  if ($dkh=="443"){
    $orihost="https://".qian($fromhost,":");
  }else{
    $orihost="http://".$fromhost;
  }
}else{
 $orihost="http://".$fromhost;
}
if ($code!="" ){
 $token_url = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid='.$appid.'&secret='.$appsecret.'&code='.$code.'&grant_type=authorization_code';
 $token = json_decode(str_replace("\\","",file_get_contents($token_url)));
 if (isset($token->errcode)) {
  echo '<h1>错误：</h1>'.$token->errcode;
  echo '<br/><h2>错误信息：</h2>'.$token->errmsg;
  exit;
 }
 $access_token_url = 'https://api.weixin.qq.com/sns/oauth2/refresh_token?appid='.$appid.'&grant_type=refresh_token&refresh_token='.$token->refresh_token;
 $access_token = json_decode(str_replace("\\","",file_get_contents($access_token_url)));
 if (isset($access_token->errcode)) {
  echo '<h1>错误：</h1>'.$access_token->errcode;
  echo '<br/><h2>错误信息：</h2>'.$access_token->errmsg;
  exit;
 }
 
 $user_info_url = 'https://api.weixin.qq.com/sns/userinfo?access_token='.$access_token->access_token.'&openid='.$access_token->openid.'&lang=zh_CN'; 
 $backtxt=str_replace("\\","",file_get_contents($user_info_url));
 if ($backtxt!=""){   
   $user_info= json_decode($backtxt);   
   if (isset($user_info->errcode)) {//userinfo
    echo '<h1>错误：</h1>'.$user_info->errcode;
    echo '<br/><h2>错误信息：</h2>'.$user_info->errmsg;
    exit;
   }else{//userinfo
      $openidx=qian(hou($backtxt,"openid\":\""),"\"");
      $nicknamex=qian(hou($backtxt,"nickname\":\""),"\"");
      $sexx=qian(hou($backtxt,"sex\":"),",");
      if ($sexx=="1"){
        $sexy="男";
      }else{
        $sexy="女";
      }
      $cityx=qian(hou($backtxt,"city\":\""),"\"");
      $provincex=qian(hou($backtxt,"province\":\""),"\"");
      $countryx=qian(hou($backtxt,"country\":\""),"\"");
      $headimgurlx=qian(hou($backtxt,"headimgurl\":\""),"\"");
      $vfaccount="";
      $urst=SX("select vxuid,userid,dpmore,depart,posids,realname from coode_userlist where userid='".$mobile."'");
      if ( countresult($urst)>0){
        $vxuid=anyvalue($urst,"vxuid",0);
         //如果有该手机号的记录，并且记录一致,如果已经存在
        if ($vxuid=="" or $vxuid==$openidx){//vxuid
          //更新最新的微信平台信息
          $uid=$mobile;
          $rname=anyvalue($urst,"realname",0);
          $comid=garea();          
          setcookie("uid",$uid,time()+3600,"/");          
          setcookie("cid",$comid,time()+3600,"/");                    
          $depart=anyvalue($urst,"depart",0);
          $dpmore=anyvalue($urst,"dpmore",0);
          $posids=anyvalue($urst,"posids",0);          
          setcookie("depart",$depart,time()+3600,"/");
          setcookie("dpts",$dpmore,time()+3600,"/");
          setcookie("posids",$posids,time()+3600,"/");
          $stoken=dftval($pgstoken,md5($uid.$comid.time()));
          setcookie("stoken",$stoken,time()+3600,"/");  
          //将获取到的用户信息提交给orihost
          $oritellurl=combineurl($orihost,"/localxres/funx/upduser/");
          $pd=Array();
          $pd["uid"]=$mobile;
          $pd["vxuid"]=$openidx;
          $pd["nickname"]=$nicknamex;
          $pd["sexy"]=$sexy;
          $pd["cityx"]=$cityx;
          $pd["prov"]=$provincex;
          $pd["country"]=$countryx;
          $pd["vxhead"]=$headimgurlx;
          $bkp=request_post($oritellurl,$pd);
          $sqla="userid,realname,wrdid,sysid,depart,dpmore,posids,stoken,deadline,logintime,loginarea,fromdomain,CRTM,UPTM,OLMK,CRTOR";
          $sqlb="'".$uid."','".$rname."','".$comid."','".$sysid."','".$depart."','".$dpmore."','".$posids."','".$stoken."',date_add(now(), interval 30 minute),now(),'','',now(),now(),'".onlymark()."','".$uidx."'";
          $c=UX("insert into coode_loginstoken(".$sqla.")values(".$sqlb.")");
          $z=UX("update coode_userlist set vxuid='".$openidx."',nickname='".$nicknamex."',sex='".$sexy."',country='".$countryx."',province='".$provincex."',city='".$cityx."',vxpic='".$headimgurlx."' where userid='".$mobile."'");          
          $z=UX("update coode_userlist set headpic=vxpic where userid='".$mobile."' and headpic=''");          
        }else{//vxuid
           //echo "如果存在信息且不一致，则跳到绑定手机号,如果验证成功则更改该用户的vxuid,否则不动";
          $vfaccount="1";
        }//vxuid
      }else{// countrst urst
        if ($mobile!=""){
          $usqlx="realname,vxuid,userid,wrdid,dpmore,depart,posids,headpic,vxpic,nickname,sex,province,city,CRTM,UPTM,OLMK";
          $usqly="'".$nicknamex."','".$openidx."','".$mobile."','".garea()."','','','comuser','".$headimgurlx."','".$headimgurlx."','".$nicknamex."','".$sexy."','".$provincex."','".$cityx."',now(),now(),'".onlymark()."'";    
          $zz=UX("insert into coode_userlist(".$usqlx.")values(".$usqly.")");
          $uid=$mobile;
          $rname="newuser";
          $comid=garea();
          $depart="nodepart";
          $dpmore="nodepart";
          $posids="comuser";
          setcookie("uid",$uid,time()+3600,"/");          
          setcookie("cid",$comid,time()+3600,"/");
          setcookie("depart",$depart,time()+3600,"/");
          setcookie("dpts",$dpmore,time()+3600,"/");
          setcookie("posids",$posids,time()+3600,"/");
          $stoken=dftval($pgstoken,md5($uid.$comid.time()));
          setcookie("stoken",$stoken,time()+3600,"/");  
          //将获取到的用户信息提交给orihost
          $sqla="userid,realname,wrdid,sysid,depart,dpmore,posids,stoken,deadline,logintime,loginarea,fromdomain,PTOF,CRTM,UPTM,OLMK,CRTOR";
          $sqlb="'".$mobile."','".$rname."','".$comid."','".$sysid."','".$depart."','".$dpmore."','".$posids."','".$stoken."',date_add(now(), interval 30 minute),now(),'','','".$uid."',now(),now(),'".onlymark()."','".$uidx."'";
          $c=UX("insert into coode_loginstoken(".$sqla.")values(".$sqlb.")");
         }else{
           echo "未获取到用户信息:".$user_info_url."&mbl-".$mobile;      
         }
         //echo "添加信息后要验证是否正确，如果不正确则删除该记录，因为是新增的，也要手机校验；否则DEADLINE 超时删除";
      }//if countrst urst
   }//uinfo
   if ($vfaccount==""){
       switch($areatype){
        case "tiny":
        header("location:".$orihost."/localxres/funx/anytiny/?tiny=".$areacode."&pagestoken=".$pgstoken."&loginvfcode=".$loginvfcode."&loginuid=".$mobile);
        //echo $orihost."/localxres/funx/anytiny/?tiny=".$areacode."&pagestoken=".$pgstoken."&loginvfcode=".$loginvfcode."&loginuid=".$mobile;
        break;
        case "masscode":      
        header("location:".$orihost."/localxres/funx/masscode/?mcode=".$areacode."&pagestoken=".$pgstoken."&loginvfcode=".$loginvfcode."&loginuid=".$mobile);
        break;
        default:
      }
   }else{
     //跳转到手机短信验证带$openidx  和 loginarea .远程版本或者加跳转选择    
     header("location:/localxres/pagex/2/wrproute/kFTUPVSu/R0VHEc/index.html?areatype=".$areatype."&openid=".$openidx."&mobile=".$mobile."&areacode=".$areacode."&pgstoken=".$pgstoken."&vxarea=".$vxarea."&loginvfcode=".$loginvfcode."&fromhost=".$fromhost."&rnd=".onlymark());
   }
 }else{ //backtxt  
   echo $mobile."未获取到用户信息:".$user_info_url."&mbl-".$mobile;
 } //backtxt
}else{//code
 echo "回调传入参数不全";
}//code
     session_write_close();
?>