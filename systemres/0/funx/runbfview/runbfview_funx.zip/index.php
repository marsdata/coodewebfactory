<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $dbmark=dftval($_GET["dbmark"],"");
$tabnm=dftval($_GET["tabnm"],"");
if ($dbmark=="thiscorehost" or $dbmark==""){
  $bfview=UX("select beforeview as result from coode_tablist where TABLE_NAME='".$tabnm."'"); 
  if ($bfview!=""){  
   eval (tostring($bfview));   
   echo makereturnjson("1","执行成功",$ud);
  }else{
   echo makereturnjson("0","未执行","");
  }  
}else{
 echo makereturnjson("2","执行成功","");
}
     session_write_close();
?>