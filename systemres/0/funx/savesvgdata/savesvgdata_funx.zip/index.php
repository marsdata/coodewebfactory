<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $imgvmark=dftval($_GET["imgvmark"],"");
$imgurl=dftval($_GET["imgurl"],"");
$imgdata=unstrs($_POST["imgdata"],"");
if ($imgvmark==""){
 $kzmx=kuozhanming($imgurl);
 if ($kzmx=="svg"){
  $surl=combineurl(localroot(),$imgurl);
  $zz=overfile($surl,$imgdata);
 }
}else{
 $typex=dftval($_GET["typex"],"");
 $sizex=dftval($_GET["sizex"],"");
 $airst=SX("select SNO,savepath from coode_askimgtask where imgvcode='".$imgvmark."'");
 $surl=anyvalue($airst,"savepath",0); 
 $kzmx=kuozhanming($surl);
 if ($kzmx=="svg" and $typex=="svg"){
   $zz=overfile($surl,$imgdata);
   $zz=UX("update coode_askimgtask set imgcode='".gohex($imgdata)."' where  imgvcode='".$imgvmark."'");
 }else{   
   $surl=str_replace($kzmx,$typex,$surl);
   $qq=downanyfile($imgdata,$surl);
   $zz=UX("update coode_askimgtask set  imgcode='".$imgdata."',imgtype='".$typex."',imgsize='".$sizex."' where  imgvcode='".$imgvmark."'");
 }
}
echo makereturnjson("1","保存成功","");
     session_write_close();
?>