<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     require combineurl(localroot(), '/localxres/parax/Twilio/autoload.php');
use Twilio\Rest\Client;
// Your Account SID and Auth Token from twilio.com/console
// To set up environmental variables, see http://twil.io/secure
$account_sid = "AC98a5df2d97cac9fd0a86c9e69c968df3";
$auth_token = "919ff06f06f84ff044c52f448c78f9dc";
// In production, these should be environment variables. E.g.:
// $auth_token = $_ENV["TWILIO_AUTH_TOKEN"]
// A Twilio number you own with SMS capabilities
$twilio_number = "+16205248454";
$client = new Client($account_sid, $auth_token);
$client->messages->create(
    // Where to send a text message (your cell phone?)
    '+8618841880246',
    array(
        'from' => $twilio_number,
        'body' => '测试一下发送短信',
        "statusCallback" => "http://kitty.halo123.cn/localxres/funx/oprtsms/"
    )
);

echo makereturnjson("1","发送成功","");
     session_write_close();
?>