<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       eval(RESFUNSET("dspbasecoprt"));
$datapath=_get("datapath");
$clsval=_post("clsval");
$fmcls="";
if (strpos($clsval,",")>0){
 $ptcls=explode(",",$clsval);
 $totpt=count($ptcls);
 for ($jj=0;$jj<$totpt;$jj++){
    if (strpos($ptcls[$jj],"[")>0){
       $tmpcls=qian(hou($ptcls[$jj],"["),"]");
       $fmcls=$fmcls.$tmpcls.",";
    }else{
       $tmpcls=$ptcls[$jj];
       $fmcls=$fmcls.$tmpcls.",";
    }
 }
}else{
    if (strpos($clsval,"[")>0){
       $tmpcls=qian(hou($clsval,"["),"]");
       $fmcls=$fmcls.$tmpcls.",";
    }else{
       $tmpcls=$clsval;
       $fmcls=$fmcls.$tmpcls.",";
    }
}
$fmcls=killlaststr($fmcls);
$nnn=SPV($datapath,$fmcls);
echo makereturnjson("1","设置成功","");
       session_write_close();
?>