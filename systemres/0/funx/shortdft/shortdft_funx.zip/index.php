<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $stid=$_GET["shortid"];
$dbmk=dftval($_GET["dbmk"],"");
if ($dbmk==""){
  $strst=SX("select tablename,showkeys,sysid from coode_shortdata where shortid='".$stid."'");
}else{
  $strst=SX("select tablename,showkeys,sysid from coode_dbshort where shortid='".$stid."' and catalog='".$dbmk."'");
}
$tbnm=anyvalue($strst,"tablename",0);
$showkeys=anyvalue($strst,"showkeys",0);
eval(RESFUNSET("keyinfo"));
eval(RESFUNSET("keyfunbase"));
if ($dbmk==""){
 $sysid=UX("select concat('x',sysid) as result from coode_tablist where TABLE_NAME='".$tbnm."'");
 if ($sysid=="x"){
  $sysid="noname";
 }else{
  $sysid=substr($sysid,1,strlen($sysid)-1);
 }
}else{
 $sysid=UX("select concat('x',sysid) as result from coode_dbtablist where TABLE_NAME='".$tbnm."' and catalog='".$dbmk."'");
 if ($sysid=="x"){
  $sysid="noname";
 }else{
  $sysid=substr($sysid,1,strlen($sysid)-1);
 }
}
if ($dbmk==""){
   $kclsrst=SX("select SNO,clstxt from coode_keydetailx where TABLE_NAME='".$tbnm."' and 'xx,".$showkeys.",' like concat('%,',COLUMN_NAME,',%') and clstxt like '%@%'");
   $totkc=countresult($kclsrst);
   $fmclstxt="";
   for ($p=0;$p<$totkc;$p++){
     $clskey=anyvalue($kclsrst,"clstxt",$p);
     $clskeyx=str_replace("[","",$clskey);
     $clskeyx=str_replace("]","",$clskeyx);
     $clsst=qian($clskeyx,"@");
     $clsqry=str_replace(".",",",hou($clskeyx,"@"));
     $fmcls="";
     if (strpos($clsqry,",")>0){
      $ptcls=explode(",",$clsqry);
      $totcls=count($ptcls);
      for ($c=0;$c<$totcls;$c++){
       $fmcls=$fmcls.",".hou($ptcls[$c],"=");
      }
     }else{
       $fmcls=",".hou($clsqry,"=");
     }
     $clsxrst=SX("select tablename,showkeys,orddt from coode_shortdata where shortid='".$clsst."'");
     $clsxkey=anyvalue($clsxrst,"showkeys",0);
     $clstabnm=anyvalue($clsxrst,"tablename",0);
     $orddt=anyvalue($clsxrst,"orddt",0);
     $ctitle=qian($clsxkey,",");
     $cval=hou($clsxkey,",");
     $clsshk=$ctitle.' as ktitle,'.$cval.' as kval'.$fmcls;
     $bkclstxt=tablejson("",$clstabnm,$clsshk,"1>0 ".$orddt,"");
     $fmclstxt=$fmclstxt.$clsst.'Data='.$bkclstxt.';'.huanhang();
   }
   $_GET["sid"]=$stid;
   $stdfttxt=$fmclstxt."STDFT".$stid."=".anyshort("stbase","","").';';
   $savepath0="/localxres/tabx/".$tbnm."/".$stid.".js";
   $savever0="/localxres/tabx/".$tbnm."/".$stid."jsversion/".date("YmdHis").".js";
 }else{
   $kclsrst=SX("select SNO,clstxt from coode_dbkeydx where TABLE_NAME='".$tbnm."' and 'xx,".$showkeys.",' like concat('%,',COLUMN_NAME,',%') and clstxt like '%@%' and TABLE_CATALOG='".$dbmk."'");
   $totkc=countresult($kclsrst);
   $fmclstxt="";
   for ($p=0;$p<$totkc;$p++){
     $clskey=anyvalue($kclsrst,"clstxt",$p);
     $clskeyx=str_replace("[","",$clskey);
     $clskeyx=str_replace("]","",$clskeyx);
     $clsst=qian($clskeyx,"@");
     $clsqry=str_replace(".",",",hou($clskeyx,"@"));
     $fmcls="";
     if (strpos($clsqry,",")>0){
      $ptcls=explode(",",$clsqry);
      $totcls=count($ptcls);
      for ($c=0;$c<$totcls;$c++){
       $fmcls=$fmcls.",".hou($ptcls[$c],"=");
      }
     }else{
       $fmcls=",".hou($clsqry,"=");
     }
     $clsxrst=SX("select tablename,showkeys,orddt from coode_shortdata where shortid='".$clsst."' ");
     $clsxkey=anyvalue($clsxrst,"showkeys",0);
     $clstabnm=anyvalue($clsxrst,"tablename",0);
     $orddt=anyvalue($clsxrst,"orddt",0);
     $ctitle=qian($clsxkey,",");
     $cval=hou($clsxkey,",");
     $clsshk=$ctitle.' as ktitle,'.$cval.' as kval'.$fmcls;
     $bkclstxt=tablejson("",$clstabnm,$clsshk,"1>0 ".$orddt,"");
     $fmclstxt=$fmclstxt.$clsst.'Data='.$bkclstxt.';'.huanhang();
   }
   $_GET["sid"]=$stid;
   $backtxt=file_get_contents("http://".glw()."localxres/funx/anyshort/?stid=stbeUd&sid=".$stid."&dmk=".$dbmk."&rnd=".getRandChar(8));
   echo "http://".glw()."localxres/funx/anyshort/?stid=stbeUd&sid=".$stid."&dbmk=".$dbmk."&rnd=".getRandChar(8).huanhang();
   echo $backtxt;
   $stdfttxt=$fmclstxt."STDFT".$stid."=".$backtxt;   
   $savepath0="/localxres/tabx/".$dbmk."/".$tbnm."/".$stid.".js";
   $savever0="/localxres/tabx/".$dbmk."/".$tbnm."/".$stid."jsversion/".date("YmdHis").".js";
 }
 if (file_exists($savepath0)){
    $oldstdfttxt=file_get_contents($savepath0);
 }else{
    $oldstdfttxt="";
 }
if ($oldstdfttxt!=$stdfttxt and $tbnm!=""){
 $x=overfile(combineurl(localroot(),$savepath0),$stdfttxt);
 $y=overfile(combineurl(localroot(),$savever0),$stdfttxt);
 $bbb0=file_get_contents("http://".glw()."localxres/funx/qnyupload/?lcfile=".combineurl(localroot(),$savepath0));
 $cbb0=file_get_contents("http://".glw()."localxres/funx/qnyupload/?lcfile=".combineurl(localroot(),$savever0));
 $ok=unlink(combineurl(localroot(),$savever0));
}
$kbase=thekeyfun($kbase,$dbmk,"SHORTID",$stid);
$fmcc="";
$fmcd="";
$fmcc=$kbase["CODE"]["JS"];
if ($dbmk==""){
 $savepath1="/localxres/tabx/".$tbnm."/".$stid."_detail.js";
 $savever1="/localxres/tabx/".$tbnm."/".$stid."detailjsversion/".date("YmdHis").".js";
}else{
 $savepath1="/localxres/tabx/".$dbmk."/".$tbnm."/".$stid."_detail.js";
 $savever1="/localxres/tabx/".$dbmk."/".$tbnm."/".$stid."detailjsversion/".date("YmdHis").".js";
}
if (file_exists($savepath1)){
  $oldfmcc=file_get_contents($savepath1);
}else{
  $oldfmcc="";
}
if (qian($oldfmcc,"versioninfo")!=$fmcc){
 $fmcc=$fmcc.'versioninfo="updatetime:'.date("Y-m-d H:i:s").'";';
 $x=overfile(combineurl(localroot(),$savepath1),$fmcc);
 $y=overfile(combineurl(localroot(),$savever1),$fmcc);
 $bbb1=file_get_contents("http://".glw()."localxres/funx/qnyupload/?lcfile=".combineurl(localroot(),$savepath1));
 $cbb1=file_get_contents("http://".glw()."localxres/funx/qnyupload/?lcfile=".combineurl(localroot(),$savever1));
 $ok=unlink(combineurl(localroot(),$savever1));
}
if ($dbmk==""){
 $kb=thekeyinfo($kb,glb(),$tbnm,"*");
 $akb=allkeyinfo($akb,glb(),$tbnm);
 $_GET["tablename"]=$tbnm;
 $_GET["sid"]=$stid;
 $fmcd= "TBFRM".$tbnm."=".anyshort("tabcol","","").";\r\n";
 $fmcd=$fmcd.$kb["CODE"]["JS"].$akb["CODE"]["JS"];
 $savepath2="/localxres/tabx/".$tbnm."/".$stid."_table.js";
 $savever2="/localxres/tabx/".$tbnm."/".$stid."tablejsversion/".date("YmdHis").".js";
}else{
 $kb=thekeyinfo($kb,$dbmk,$tbnm,"*");
 $akb=allkeyinfo($akb,$dbmk,$tbnm);
 $_GET["tablename"]=$tbnm;
 $_GET["sid"]=$stid;
 $fmcd= "TBFRM".$tbnm."=".file_get_contents("http://".glw()."localxres/funx/anyshort/?stid=tabd2K&tbname=".$tbnm."&dmk=".$dbmk).";\r\n";
 $fmcd=$fmcd.$kb["CODE"]["JS"].$akb["CODE"]["JS"];
 $savepath2="/localxres/tabx/".$dbmk."/".$tbnm."/".$stid."_table.js";
 $savever2="/localxres/tabx/".$dbmk."/".$tbnm."/".$stid."tablejsversion/".date("YmdHis").".js";
}
if (file_exists($savepath2)){
  $oldfmcd=file_get_contents($savepath2);
}else{
  $oldfmcd="";
}
if (qian($oldfmcd,"versioninfo")!=$fmcd){
 $fmcd=$fmcd.'versioninfo="updatetime:'.date("Y-m-d H:i:s").'";';
 $x=overfile(combineurl(localroot(),$savepath2),$fmcd);
 $y=overfile(combineurl(localroot(),$savever2),$fmcd);
 $bbb2=file_get_contents("http://".glw()."localxres/funx/qnyupload/?lcfile=".combineurl(localroot(),$savepath2));
 $cbb2=file_get_contents("http://".glw()."localxres/funx/qnyupload/?lcfile=".combineurl(localroot(),$savever2));
 $ok=unlink(combineurl(localroot(),$savever2));
}
echo '{"status":"1","msg":"成功","redirect":""}'; 
       session_write_close();
?>