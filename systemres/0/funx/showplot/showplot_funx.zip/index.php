<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $plid=$_GET['plid'];
 $case=$_GET["case"];
 $conn=mysql_connect(gl(),glu(),glp());
 $nx=updatings($conn,glb(),"update coode_plotdetail set parid=-1 where plotmark='".$plid."' and parid=0","utf8");
  $conn=mysql_connect(gl(),glu(),glp());
 $rst=selecteds($conn,glb(),"select CRTM,myid,parid,mytitle,mymark,myurl,myclick,level,mydescrib,layid from coode_plotdetail where plotmark='".$plid."'","utf8","");
 $totpt=countresult($rst);
$fmrst="[";
 for ($i=0;$i<$totpt;$i++){
 $layid=anyvalue($rst,"layid",$i);
 $myurl=anyvalue($rst,"myurl",$i);
 if ($myurl==""){
   $myurl="/localxres/funx/anylay/?layid=".$layid;
 }
 if ($case=="tb"){
  if (anyvalue($rst,"parid",$i)==0){     
     $fmrst=$fmrst."{\"id\":".anyvalue($rst,"myid",$i).",\"pId\":". anyvalue($rst,"parid",$i).",\"name\":\"".anyvalue($rst,"mytitle",$i)."\",\"url\":\"".$myurl."\",\"describ\":\"".anyvalue($rst,"mydescrib",$i)."\",\"click\":\"".str_replace("'","‘",anyvalue($rst,"myclick",$i))."\",open:true},";
   }else{
     $fmrst=$fmrst."{\"id\":".anyvalue($rst,"myid",$i).",\"pId\":". anyvalue($rst,"parid",$i).",\"name\":\"".anyvalue($rst,"mytitle",$i)."\",\"url\":\"".$myurl."\",\"describ\":\"".anyvalue($rst,"mydescrib",$i)."\",\"click\":\"".str_replace("'","‘",anyvalue($rst,"myclick",$i))."\"},";
   };
 }else{
  if (anyvalue($rst,"parid",$i)==0){
     $fmrst=$fmrst."{\"id\":".anyvalue($rst,"myid",$i).",\"pId\":". anyvalue($rst,"parid",$i).",\"name\":\"".anyvalue($rst,"mytitle",$i)."\",\"url\":\"".$myurl."\",\"target\":\"".anyvalue($rst,"mymark",$i)."\",\"describ\":\"".anyvalue($rst,"mydescrib",$i)."\",\"click\":\"".anyvalue($rst,"myclick",$i)."\",open:true},";
   }else{
     $fmrst=$fmrst."{\"id\":".anyvalue($rst,"myid",$i).",\"pId\":". anyvalue($rst,"parid",$i).",\"name\":\"".anyvalue($rst,"mytitle",$i)."\",\"url\":\"".$myurl."\",\"target\":\"".anyvalue($rst,"mymark",$i)."\",\"describ\":\"".anyvalue($rst,"mydescrib",$i)."\",\"click\":\"".anyvalue($rst,"myclick",$i)."\"},";
   };
 }
};
if ($totpt>0){
 $fmrst=substr($fmrst,0,strlen($fmrst)-1);
};
$fmrst=$fmrst."]";
if ($case=="tb"){
 $fmrst=str_replace("pId","pid",$fmrst);
 $fmrst=str_replace("pid\":-1","pid\":0",$fmrst);
 $fmrst=str_replace("click","grade",$fmrst);
echo "{\"data\":".$fmrst."}";
}else{
echo $fmrst;
}
     session_write_close();
?>