<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snos=dftval($_GET["snos"],"");
$xss=dftval($_GET["xss"],"");
$ptsno=explode(",",$snos);
$ptxs=explode(",",$xss);
$totpt=count($ptsno);
$xsd=array();
$fnm=array();
$fpth=array();
$ftp=array();
$furl=array();
$fmx="";
for ($i=0;$i<$totpt;$i++){
  if ($ptsno[$i]!=""){
   $fmx=$fmx." or SNO=".$ptsno[$i];  
   $xsd[$ptsno[$i]]=$ptxs[$i];
  }
}
$srdx='{"status":"1","msg":"成功","totrcd":"{totrcd}","vls":[{datalist}]}';
$itemx='{"sno":"{sno}","filename":"{filename}","filepath":"{filepath}","fileurl":"{fileurl}","filetype":"{filetype}","degree":"{degree}"}';
$fmx=substr($fmx,3,strlen($fmx)-3);
$srst=SX("select SNO,filename,filepath,filetype from coode_foldertree where ".$fmx);
$totrst=countresult($srst);
for ($j=0;$j<$totrst;$j++){
  $snox=anyvalue($srst,"SNO",$j);  
  $fpth[$snox]=anyvalue($srst,"filepath",$j);
  $fnm[$snox]=anyvalue($srst,"filename",$j);
  $ftp[$snox]=anyvalue($srst,"filetype",$j);
  $furl[$snox]=str_replace($_SERVER["HTTP_HOST"],"qny.halo123.cn","http://".hou($fpth[$snox],"wwwroot/"));
  if (strpos($fpth[$snox],"/xgd/")>0){
    $fpth[$snox]="j:/老板洗过的照片/".hou($fpth[$snox],"/xgd/");
  }else{
    $fpth[$snox]="未知是否洗过的:".hou($fpth[$snox],"/wzd/");        
  }  
}
$fmdemo="";
for ($i=0;$i<$totpt;$i++){
  $demo=$itemx;
  $demo=str_replace("{filename}",$fnm[$ptsno[$i]],$demo);
  $demo=str_replace("{filepath}",$fpth[$ptsno[$i]],$demo);
  $demo=str_replace("{fileurl}",$furl[$ptsno[$i]],$demo);
  $demo=str_replace("{filetype}",$ftp[$ptsno[$i]],$demo);
  $demo=str_replace("{degree}",$xsd[$ptsno[$i]],$demo);  
  $demo=str_replace("{sno}",$ptsno[$i],$demo);
  $fmdemo=$fmdemo.$demo.",";
}
$srdx=str_replace("{datalist}",$fmdemo,$srdx);
$srdx=str_replace("{totrcd}",$totpt,$srdx);
echo $srdx;
     session_write_close();
?>