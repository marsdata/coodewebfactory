<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snox=dftval($_GET["snox"],"");
$ssmark=dftval($_GET["ssmarkx"],"");
$svgrst=SX("select SNO,imgtitle,imglcurl from coode_icons where SNO=".$snox);
$imgtitle=anyvalue($svgrst,"imgtitle",0);
$imglcurl=anyvalue($svgrst,"imglcurl",0);
$img2url=combineurl(localroot(),"/localxres/iconsetx/restype/databasex.png");
$imgsvg=file_get_contents($imglcurl);
echo strlen($imgsvg)."--wc";
$dey=str_replace("\"","'",$imgsvg)."这是svg图标代码，文件名是".$imgtitle.",请问该图标都表示哪些含义,要所有的含义，格式为含义:content";
$pd=array();
$url="http://fuckshop.spccode.com/index.php";
$pd["askstr"]=$dey;
$bktxt=request_post($url,$pd);
echo $bktxt."-nm";
$datax=json_decode($bktxt,false);
$status=$datax->code;
$datay=$datax->data;
$htmlx=$datay->html;
$htmlz=$htmlx;
$htmlz=str_replace("\n","\r\n",$htmlz);
if (intval($status)==200){
  $rtntxt=$htmlz; 
}else{
  $rtntxt='NoCode.';
}
if ($rtntxt!="NoCode."){
 $rtntxt=str_replace(huanhang(),"",$rtntxt);
 $rtntxt=str_replace("?","",$rtntxt);
 $rtntxt=str_replace(" ","",$rtntxt); 
 $zz=UX("update coode_icons set imgdescrib='".$rtntxt."',STATUS=1 where SNO=".$snox); 
 $z=finishmtask($ssmark,$snox,"");
 echo makereturnjson("1","获取意义成功","");
}else{
 echo makereturnjson("0","获取意义失败","");
}//nocode
 
     session_write_close();
?>