<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $zz=UX("update coode_userlist set vxpic='/localxres/iconsetx/18841880246/todayfiles/2023-05-16/QrVG5U/rlzy.png' where vxpic=''");
$zz=UX("update coode_userlist set headpic='/localxres/iconsetx/18841880246/todayfiles/2023-05-16/QrVG5U/rlzy.png' where headpic=''");
$ptel=dftval($_GET["ptel"],$_COOKIE["uid"]);
$drst=SX("select SNO,realname,sex,depart,authorize,passwd,userid,wrdid,headpic,nickname,business,editPass,apiKey from coode_userlist where userid='".$ptel."' ");
$totd=countresult($drst);
if (intval($totd)>0 and strpos($drst,"报错")<=0){
  echo "{\"uname\":\"".dftval(anyvalue($drst,"realname",0),$ptel)."\",\"business\":\"".anyvalue($drst,"business",0)."\",\"sth\":\"".date("H")."\",\"workot\":\"".$wot."\",\"haspass\":\"".$haspass."\",\"signstate\":\"".$sttt."\",\"userid\":\"".$ptel."\",\"comid\":\"".anyvalue($drst,"wrdid",0)."\",\"usex\":\"".anyvalue($drst,"sex",0)."\",\"age\":\"0\",\"pdepart\":\"".anyvalue($drst,"depart",0)."\",\"groupmng\":\"".anyvalue($drst,"authorize",0)."\",\"uheadx\":\"".anyvalue($drst,"headpic",0)."\",\"nickname\":\"".anyvalue($drst,"nickname",0)."\",\"last3\":\"\",\"editpass\":\"".anyvalue($drst,"editPass",0)."\",\"apikey\":\"".anyvalue($drst,"apiKey",0)."\",\"usno\":\"".anyvalue($drst,"SNO",0)."\"}";
}else{
  echo "{\"uname\":\"\",\"sth\":\"".date("H")."\",\"business\":\"\",\"workot\":\"\",\"haspass\":\"\",\"signstate\":\"\",\"userid\":\"\",\"comid\":\"\",\"usex\":\"\",\"age\":\"0\",\"pdepart\":\"\",\"groupmng\":\"\",\"uheadx\":\"/localxres/iconsetx/18841880246/todayfiles/2023-05-16/QrVG5U/rlzy.png\",\"nickname\":\"游客\",\"last3\":\"\",\"editpass\":\"\",\"apikey\":\"\",\"usno\":\"\"}";
}
     session_write_close();
?>