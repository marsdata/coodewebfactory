<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $demo='{"status":"1","msg":"获取成功","syscode":"'.gln().'","systitle":"'.glt().'","s00":"[s00]","s10":"[s10]","sWEO0":"[sWEO0]","s01":"[s01]","s11":"[s11]","sWEO1":"[sWEO1]"}';
$resrst=SX("select sysid,count(sqlmd5) as totres from coode_insdata where STATUS=0 group by sysid");
$totres=countresult($resrst);
for ($i=0;$i<$totres;$i++){
  $sysid=anyvalue($resrst,"sysid",$i);
  $totres=anyvalue($resrst,"totres",$i);
  if ($sysid!="0" and $sysid!="1"){
   $demo=str_replace("[sWEO0]",$totres,$demo);
  }else{
   $demo=str_replace("[s".$sysid."0]",$totres,$demo);
  }
}
$demo=str_replace("[s00]",0,$demo);
$demo=str_replace("[s10]",0,$demo);
$demo=str_replace("[sWEO0]",0,$demo);
$resrst=SX("select sysid,count(sqlmd5) as totres from coode_insdata where STATUS=1 group by sysid");
$totres=countresult($resrst);
for ($i=0;$i<$totres;$i++){
  $sysid=anyvalue($resrst,"sysid",$i);
  $totres=anyvalue($resrst,"totres",$i);
  if ($sysid!="0" and $sysid!="1"){
    $demo=str_replace("[sWEO1]",$totres,$demo);
  }else{
    $demo=str_replace("[s".$sysid."1]",$totres,$demo);
  }  
}
$demo=str_replace("[s01]",0,$demo);
$demo=str_replace("[s11]",0,$demo);
$demo=str_replace("[sWEO1]",0,$demo);
echo $demo;
     session_write_close();
?>