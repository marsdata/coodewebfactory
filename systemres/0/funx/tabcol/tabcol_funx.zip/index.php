<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tbnm=$_GET["tbname"];
$dbmk=dftval($_GET["dbmk"],"");
$cid=dftval($_GET["cid"],"");
$uid=dftval($_GET["uid"],"");
$_COOKIE["cid"]=$cid;
$_COOKIE["uid"]=$uid;
eval(RESFUNSET("quickvalue"));
eval(RESFUNSET("tabbaseinfo"));
eval(RESFUNSET("keyinfox"));
eval(RESFUNSET("keyfunbase"));
$kb=thekeyinfox($kb,$dbmk,$tbnm,"*");
if ($dbmk==""){
  $kbase=thekeyfun($kbase,"",$tbnm,"*");
}else{
  $kbase=thekeyfun($kbase,$dbmk,$tbnm,"*");
}
$akb=allkeyinfox($akb,$dbmk,$tbnm);
if ($dbmk==""){
   $fmcd= "TBFRM".$tbnm."=".anyshort("tabcol","tbname=".$tbnm."&setonlyonce=".$_GET["setonlyonce"],"").";\r\n";
}else{
   $fmcd= "TBFRM".$tbnm."=".file_get_contents("http://".glw()."localxres/funx/anyshort/?stid=tabd2K&tbname=".$tbnm."&dmk=".$dbmk).";\r\n";
}
$fmcd=$fmcd.$kb["CODE"]["JS"].$kbase["CODE"]["JS"].$akb["CODE"]["JS"];
if ($dbmk==""){
  $sysid=UX("select concat('x',sysid) as result from coode_tablist where TABLE_NAME='".$tbnm."'");
  if ($sysid=="x"){
    $sysid="noname";
  }else{
    $sysid=substr($sysid,1,strlen($sysid)-1);
  }
}else{
  $sysid=UX("select concat('x',sysid) as result from coode_dbtablist where TABLE_NAME='".$tbnm."' and catalog='".$dbmk."'");
  if ($sysid=="x"){
    $sysid="noname";
  }else{
    $sysid=substr($sysid,1,strlen($sysid)-1);
  }
}
if ($dbmk==""){
 $savepath="/localxres/tabx/".$tbnm."/".$tbnm.".js";
 $savever="/localxres/tabx/".$tbnm."/".$tbnm."jsversion/";
}else{
 $savepath="/localxres/tabx/".$dbmk."/".$tbnm."/".$tbnm.".js";
 $savever="/localxres/tabx/".$dbmk."/".$tbnm."/".$tbnm."jsversion/";
}
$fullpath=combineurl(localroot(),$savepath);
$fullver=combineurl(localroot(),$savever);
$oldcd=file_get_contents($fullpath);
if (qian($oldcd,"fileverinfo")!=$fmcd){
 $fmcd=$fmcd.'fileverinfo="updatetime:'.date("Y-m-d H:i:s").'";';
 $x=overfile($fullpath,$fmcd);
 $x=deltree($fullver); 
 //$ok=unlink($fullver);
}
echo '{"status":"1","msg":"成功","redirect":"'.$savepath.'"}';
     session_write_close();
?>