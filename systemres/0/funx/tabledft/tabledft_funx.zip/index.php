<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tnm=$_GET["tablename"];
eval(RESFUNSET("tabbaseinfo"));
$dbmk=dftval($_GET["dbmk"],"");
$dinfo=array();
$dinfo=takedbinfo($dbmk,$tnm,$dinfo);
$succ=0;
if ($tnm!="" and $tnm!="un"."defined"){
 if (dbmk==""){
  $colrst=SX("select SNO,COLUMN_NAME from coode_keydetailx where TABLE_NAME='".$tnm."'");
  $totc=countresult($colrst);
 }else{
  $colrst=SX("select SNO,COLUMN_NAME from coode_dbkeydx where TABLE_NAME='".$tnm."' and TABLE_CATALOG='".$dbmk."'");
  $totc=countresult($colrst);
 }
 $clm=""; 
 for ($p=0;$p<$totc;$p++){
   $clm=$clm.anyvalue($colrst,"COLUMN_NAME",$p).",";
 }
 $xtrst=SX("select TABLE_NAME,COLUMN_NAME,DATA_TYPE,CHARACTER_MAXIMUM_LENGTH,keytitle,keyexplain,clstxt,jsshowfun,jspostfun,sysshowfun,syspostfun,dxtype from coode_keydetaily where TABLE_SCHEMA='".glb()."' and TABLE_NAME='coode_keydefault' and 'xx,".$clm.",' not like concat('%,',COLUMN_NAME,',%')");
 $xtotrst=countresult($xtrst);
 if ($xtotrst>0){
  for ($k=0;$k<$xtotrst;$k++){
   $sTABLE_NAME[$k]=anyvalue($xtrst,"TABLE_NAME",$k);
   $sCOLUMN_NAME[$k]=anyvalue($xtrst,"COLUMN_NAME",$k);
   $sDATA_TYPE[$k]=anyvalue($xtrst,"DATA_TYPE",$k);
   $sCHARACTER_MAXIMUM_LENGTH[$k]=anyvalue($xtrst,"CHARACTER_MAXIMUM_LENGTH",$k);
   $skeytitle[$k]=anyvalue($xtrst,"keytitle",$k);
   $skeyexplain[$k]=anyvalue($xtrst,"keyexplain",$k);
   $sclstxt[$k]=anyvalue($xtrst,"clstxt",$k);
   $sjsshowfun[$k]=anyvalue($xtrst,"jsshowfun",$k);
   $sjspostfun[$k]=anyvalue($xtrst,"jspostfun",$k);
   $ssysshowfun[$k]=anyvalue($xtrst,"sysshowfun",$k);
   $ssyspostfun[$k]=anyvalue($xtrst,"syspostfun",$k);
   $sdxtype[$k]=anyvalue($xtrst,"dxtype",$k);
   $scn[$k]=anyvalue($xtrst,"COLUMN_NAME",$k);
  $succ=$succ+1;
   if ( ($sCHARACTER_MAXIMUM_LENGTH[$k]*1)>0){
     $atl="ALTER TABLE ".$tnm." ADD ".$sCOLUMN_NAME[$k]." ".$sDATA_TYPE[$k]."(".$sCHARACTER_MAXIMUM_LENGTH[$k].") not null";
   }else{
     if ($sCOLUMN_NAME[$k]=="SNO"){
       $atl="ALTER TABLE ".$tnm." ADD  SNO int not null  auto_increment ,ADD primary key (SNO)";       
     }else{
       $atl="ALTER TABLE ".$tnm." ADD ".$sCOLUMN_NAME[$k]." ".$sDATA_TYPE[$k]." not null";
     }
   }
    if ($dbmk==""){
      $conn=mysql_connect(gl(),glu(),glp());
      $glbb=glb();
    }else{
      $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
      $glbb=$dinfo["fbase"];
    }
    $z=updatingx($conn,$glbb,$atl,"utf8");   
   }//for
  }//if
 }//if
 if ($dbmk==""){
   $bbx=UX("update coode_keydetailx set SQX=(ORDINAL_POSITION),CRTOR='".$_COOKIE["uid"]."' where TABLE_NAME='".$tnm."'"); 
   $bbx=UX("update coode_keydetaily set keyexplain=keytitle,SQX=(ORDINAL_POSITION),CRTOR='".$_COOKIE["uid"]."' where TABLE_NAME='".$tnm."' and SQX=0"); 
   $bbx=UX("update coode_keydetailz set SQX=(ORDINAL_POSITION),CRTOR='".$_COOKIE["uid"]."' where TABLE_NAME='".$tnm."'"); 
 }else{
   $bbx=UX("update coode_dbkeydx set SQX=(ORDINAL_POSITION),CRTOR='".$_COOKIE["uid"]."' where TABLE_CATALOG='".$dbmk."' and TABLE_NAME='".$tnm."'");
   $bbx=UX("update coode_dbkeydy set keyexplain=keytitle,SQX=(ORDINAL_POSITION),CRTOR='".$_COOKIE["uid"]."' where TABLE_CATALOG='".$dbmk."' and TABLE_NAME='".$tnm."' and SQX=0"); 
   $bbx=UX("update coode_dbkeydz set SQX=(ORDINAL_POSITION),CRTOR='".$_COOKIE["uid"]."' where TABLE_CATALOG='".$dbmk."' and TABLE_NAME='".$tnm."'"); 
 }
 echo makereturnjson("1","成功",$succ);
     session_write_close();
?>