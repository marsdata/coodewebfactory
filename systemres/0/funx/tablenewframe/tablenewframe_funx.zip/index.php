<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $kk='0';
$totpt=0;
$catalog=dftval($_GET["dmk"],_get("catalog"));
$tnm=dftval($_GET["tnm"],_get("tabnm"));
eval(RESFUNSET("tabbaseinfo"));
$dbinfo=array();
$dbinfo=takedbinfo($catalog,$tnm,$dbinfo);
$fip=$dbinfo["fip"];
$fuser=$dbinfo["fuser"];
$fpass=$dbinfo["fpass"];
$fbase=$dbinfo["fbase"];
$conn=mysql_connect($fip,$fuser,$fpass);
$btree=dbbetrees($conn,$fbase,$tnm);  
$conn=mysql_connect($fip,$fuser,$fpass);
$trst=selecteds($conn,"information_schema","select TABLE_CATALOG,TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,ORDINAL_POSITION,COLUMN_DEFAULT,IS_NULLABLE,DATA_TYPE,CHARACTER_MAXIMUM_LENGTH,CHARACTER_OCTET_LENGTH,NUMERIC_PRECISION,NUMERIC_SCALE,CHARACTER_SET_NAME,COLLATION_NAME,COLUMN_TYPE,COLUMN_KEY,EXTRA,PRIVILEGES,COLUMN_COMMENT from COLUMNS where TABLE_SCHEMA='".$fbase."' and TABLE_NAME='".$tnm."'","utf8","");
$totrst=countresult($trst);
if ($tnm=="coode_dbkeydx" or $tnm=="coode_dbkeydy"  or $tnm=="coode_dbkeydz"){
 $expk="X/ORDINAL_POSITION,COLUMN_DEFAULT,IS_NULLABLE,CHARACTER_OCTET_LENGTH,NUMERIC_PRECISION,NUMERIC_SCALE,DATETIME_PRECISION,CHARACTER_SET_NAME,COLLATION_NAME,COLUMN_TYPE,COLUMN_KEY,EXTRA,PRIVILEGES,COLUMN_COMMENT";
}else{
 $expk="";
}
for ($k=0;$k<$totrst;$k++){
   $sTABLE_CATALOG[$k]=anyvalue($trst,"TABLE_CATALOG",$k);
   $sTABLE_SCHEMA[$k]=anyvalue($trst,"TABLE_SCHEMA",$k);
   $sTABLE_NAME[$k]=anyvalue($trst,"TABLE_NAME",$k);
   $sCOLUMN_NAME[$k]=anyvalue($trst,"COLUMN_NAME",$k);
   $sORDINAL_POSITION[$k]=anyvalue($trst,"ORDINAL_POSITION",$k);
   $sCOLUMN_DEFAULT[$k]=anyvalue($trst,"COLUMN_DEFAULT",$k);
   $sIS_NULLABLE[$k]=anyvalue($trst,"IS_NULLABLE",$k);
   $sDATA_TYPE[$k]=anyvalue($trst,"DATA_TYPE",$k);
   $sCHARACTER_MAXIMUM_LENGTH[$k]=anyvalue($trst,"CHARACTER_MAXIMUM_LENGTH",$k);
   $sCHARACTER_OCTET_LENGTH[$k]=anyvalue($trst,"CHARACTER_OCTET_LENGTH",$k);
   $sNUMERIC_PRECISION[$k]=anyvalue($trst,"NUMERIC_PRECISION",$k);
   $sNUMERIC_SCALE[$k]=anyvalue($trst,"NUMERIC_SCALE",$k);
   $sCHARACTER_SET_NAME[$k]=anyvalue($trst,"CHARACTER_SET_NAME",$k);
   $sCOLLATION_NAME[$k]=anyvalue($trst,"COLLATION_NAME",$k);
   $sCOLUMN_TYPE[$k]=anyvalue($trst,"COLUMN_TYPE",$k);
   $sCOLUMN_KEY[$k]=anyvalue($trst,"COLUMN_KEY",$k);
   $sEXTRA[$k]=anyvalue($trst,"EXTRA",$k);
   $sPRIVILEGES[$k]=anyvalue($trst,"PRIVILEGES",$k);
   $sCOLUMN_COMMENT[$k]=anyvalue($trst,"COLUMN_COMMENT",$k);
   $somark[$k]=date('Ymdhis').getRandChar(6);
}
if ($tnm!="coode_dbtablist"){
  $txrst=SX("select createsql,tabtype from coode_dbtablist where TABLE_NAME='".$tnm."' and catalog='".$catalog."'");
  $ocrtsql=anyvalue($txrst,"createsql",0);
  $tabtype=anyvalue($txrst,"tabtype",0);
  $purl="http://".glw()."localxres/funx/freetabmake/?tnm=".$tnm."&uid=".$_COOKIE["uid"]."&btree=".gohex($btree);
  $pdata=array();
  $pdata["prst"]=$trst;
  $pdata["ocrt"]=$ocrtsql;
  $tbfrm=request_post($purl , $pdata);  
  //"-CREATESQL:".$crtsql."/JSCON:".$fmjscon."/CONKEYS:".$fmik."/ALLKEYS:".$allkx."/TKEYS:".$fmk."/KEYTYPES:".$fmktp."/JSONKTPS:".$fmjstp."/";
  $crtsql=qian(hou($tbfrm,"CREATESQL:"),"/");
  if ($ocrtsql!=$crtsql){
   $rework="1";
   $qz=UX("update coode_dbtablist set PRIME=1,UPTM=now() where TABLE_NAME='".$tnm."' and catalog='".$catalog."'");
  };
 };
 $fmjscon=qian(hou($tbfrm,"JSCON:"),"/");
 $fmik=qian(hou($tbfrm,"CONKEYS:"),"/");
 $allkx=qian(hou($tbfrm,"ALLKEYS:"),"/");
 $fmk=qian(hou($tbfrm,"TKEYS:"),"/");
 $fmktp=qian(hou($tbfrm,"KEYTYPES:"),"/");
 $fmjstp=qian(hou($tbfrm,"JSONKTPS:"),"/");  
 $clm="";
 
 $fmknm=$_POST["fmknm"];
 $fmktt=$_POST["fmktt"];
 $ptfmknm=explode(",",$fmknm);
 $ptfmktt=explode(",",$fmktt);
 $totpk=count($ptfmknm);
 
 for ($k=0;$k<$totrst;$k++){ 
   $ext=UX("select count(*) as result from coode_dbkeydx where TABLE_CATALOG='".$catalog."' and TABLE_NAME='".$sTABLE_NAME[$k]."' and COLUMN_NAME='".$sCOLUMN_NAME[$k]."'");
   $clm=$clm.$sCOLUMN_NAME[$k].",";    
   if ($ext==0){//如果从数据库里修改表格数据 系统记录结构表未发现结构则新增并找到是否有默认的字段设置    
     $tmpkk="";
     $tmpkt="";
     for ($z=0;$z<$totpk;$z++){
       if ($ptfmknm[$z]==$sCOLUMN_NAME[$k]){
         $tmpkt=$ptfmktt[$z];
       }
     }         
     $x=UX("insert into coode_dbkeydx(TABLE_CATALOG,TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,ORDINAL_POSITION,COLUMN_DEFAULT,IS_NULLABLE,DATA_TYPE,CHARACTER_MAXIMUM_LENGTH,CHARACTER_OCTET_LENGTH,NUMERIC_PRECISION,NUMERIC_SCALE,CHARACTER_SET_NAME,COLLATION_NAME,COLUMN_TYPE,COLUMN_KEY,EXTRA,PRIVILEGES,COLUMN_COMMENT,OLMK,CRTM,PTOF,classp,keytitle,keyexplain,jsshowfun,sysshowfun,jspostfun,syspostfun,UPTM,changeable,clstxt,displayed,CRTOR)values('".$catalog."','".$sTABLE_SCHEMA[$k]."','".$sTABLE_NAME[$k]."','".$sCOLUMN_NAME[$k]."','".$sORDINAL_POSITION[$k]."','".$sCOLUMN_DEFAULT[$k]."','".$sIS_NULLABLE[$k]."','".$sDATA_TYPE[$k]."','".$sCHARACTER_MAXIMUM_LENGTH[$k]."','".$sCHARACTER_OCTET_LENGTH[$k]."','".$sNUMERIC_PRECISION[$k]."','".$sNUMERIC_SCALE[$k]."','".$sCHARACTER_SET_NAME[$k]."','".$sCOLLATION_NAME[$k]."','".$sCOLUMN_TYPE[$k]."','".$sCOLUMN_KEY[$K]."','".$sEXTRA[$k]."','".$sPRIVILEGES[$k]."','".$sCOLUMN_COMMENT[$k]."','".$somark[$k]."',now(),'".glb()."',0,'".$tmpkt."','','','','','',now(),1,'',1,'".$_COOKIE["uid"]."')");      
     //echo "insert into coode_dbkeydx(TABLE_CATALOG,TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,ORDINAL_POSITION,COLUMN_DEFAULT,IS_NULLABLE,DATA_TYPE,CHARACTER_MAXIMUM_LENGTH,CHARACTER_OCTET_LENGTH,NUMERIC_PRECISION,NUMERIC_SCALE,CHARACTER_SET_NAME,COLLATION_NAME,COLUMN_TYPE,COLUMN_KEY,EXTRA,PRIVILEGES,COLUMN_COMMENT,OLMK,CRTM,PTOF,classp,keytitle,keyexplain,jsshowfun,sysshowfun,jspostfun,syspostfun,UPTM,changeable,clstxt,displayed,CRTOR)values('".$catalog."','".$sTABLE_SCHEMA[$k]."','".$sTABLE_NAME[$k]."','".$sCOLUMN_NAME[$k]."','".$sORDINAL_POSITION[$k]."','".$sCOLUMN_DEFAULT[$k]."','".$sIS_NULLABLE[$k]."','".$sDATA_TYPE[$k]."','".$sCHARACTER_MAXIMUM_LENGTH[$k]."','".$sCHARACTER_OCTET_LENGTH[$k]."','".$sNUMERIC_PRECISION[$k]."','".$sNUMERIC_SCALE[$k]."','".$sCHARACTER_SET_NAME[$k]."','".$sCOLLATION_NAME[$k]."','".$sCOLUMN_TYPE[$k]."','".$sCOLUMN_KEY[$K]."','".$sEXTRA[$k]."','".$sPRIVILEGES[$k]."','".$sCOLUMN_COMMENT[$k]."','".$somark[$k]."',now(),'".glb()."',0,'".$tmpkt."','','','','','',now(),1,'',1,'".$_COOKIE["uid"]."')";
     $y=UX("insert into coode_dbkeydy(TABLE_CATALOG,TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,ORDINAL_POSITION,COLUMN_DEFAULT,IS_NULLABLE,DATA_TYPE,CHARACTER_MAXIMUM_LENGTH,CHARACTER_OCTET_LENGTH,NUMERIC_PRECISION,NUMERIC_SCALE,CHARACTER_SET_NAME,COLLATION_NAME,COLUMN_TYPE,COLUMN_KEY,EXTRA,PRIVILEGES,COLUMN_COMMENT,OLMK,CRTM,PTOF,classp,keytitle,keyexplain,jsshowfun,sysshowfun,jspostfun,syspostfun,UPTM,changeable,clstxt,displayed,shortid,CRTOR)values('".$catalog."','".$sTABLE_SCHEMA[$k]."','".$sTABLE_NAME[$k]."','".$sCOLUMN_NAME[$k]."','".$sORDINAL_POSITION[$k]."','".$sCOLUMN_DEFAULT[$k]."','".$sIS_NULLABLE[$k]."','".$sDATA_TYPE[$k]."','".$sCHARACTER_MAXIMUM_LENGTH[$k]."','".$sCHARACTER_OCTET_LENGTH[$k]."','".$sNUMERIC_PRECISION[$k]."','".$sNUMERIC_SCALE[$k]."','".$sCHARACTER_SET_NAME[$k]."','".$sCOLLATION_NAME[$k]."','".$sCOLUMN_TYPE[$k]."','".$sCOLUMN_KEY[$K]."','".$sEXTRA[$k]."','".$sPRIVILEGES[$k]."','".$sCOLUMN_COMMENT[$k]."','".$somark[$k]."',now(),'".glb()."',0,'".$tmpkt."','','','','','',now(),1,'',1,'".$sTABLE_NAME[$k]."','".$_COOKIE["uid"]."')");
   }else{
       $x0=UX("update coode_dbkeydx set UPTM=now(),ORDINAL_POSITION='".$sORDINAL_POSITION[$k]."' where COLUMN_NAME='".$sCOLUMN_NAME[$k]."' and  TABLE_CATALOG='".$catalog."' and TABLE_NAME='".$tnm."'");     
       $x1=UX("update coode_dbkeydy set UPTM=now(),ORDINAL_POSITION='".$sORDINAL_POSITION[$k]."' where COLUMN_NAME='".$sCOLUMN_NAME[$k]."' and  TABLE_CATALOG='".$catalog."' and TABLE_NAME='".$tnm."'");
       $x2=UX("update coode_dbkeydz set UPTM=now(),ORDINAL_POSITION='".$sORDINAL_POSITION[$k]."' where COLUMN_NAME='".$sCOLUMN_NAME[$k]."' and  TABLE_CATALOG='".$catalog."' and TABLE_NAME='".$tnm."'");
       
       $x0=UX("update coode_dbkeydx set SQX='".$sORDINAL_POSITION[$k]."' where COLUMN_NAME='".$sCOLUMN_NAME[$k]."' and  TABLE_CATALOG='".$catalog."' and TABLE_NAME='".$tnm."' and SQX=0");     
       $x1=UX("update coode_dbkeydy set SQX='".$sORDINAL_POSITION[$k]."' where COLUMN_NAME='".$sCOLUMN_NAME[$k]."' and  TABLE_CATALOG='".$catalog."' and TABLE_NAME='".$tnm."' and SQX=0");
       $x2=UX("update coode_dbkeydz set SQX='".$sORDINAL_POSITION[$k]."' where COLUMN_NAME='".$sCOLUMN_NAME[$k]."' and  TABLE_CATALOG='".$catalog."' and TABLE_NAME='".$tnm."' and SQX=0");
       
       $x0=UX("update coode_dbkeydx set keytitle='".getktt($sCOLUMN_NAME[$k])."' where COLUMN_NAME='".$sCOLUMN_NAME[$k]."' and  TABLE_CATALOG='".$catalog."' and TABLE_NAME='".$tnm."' and (keytitle='' or keytitle=COLUMN_NAME)");     
       $x1=UX("update coode_dbkeydy set keytitle='".getktt($sCOLUMN_NAME[$k])."' where COLUMN_NAME='".$sCOLUMN_NAME[$k]."' and  TABLE_CATALOG='".$catalog."' and TABLE_NAME='".$tnm."' and (keytitle='' or keytitle=COLUMN_NAME)");
       $x2=UX("update coode_dbkeydz set keytitle='".getktt($sCOLUMN_NAME[$k])."' where COLUMN_NAME='".$sCOLUMN_NAME[$k]."' and  TABLE_CATALOG='".$catalog."' and TABLE_NAME='".$tnm."' and (keytitle='' or keytitle=COLUMN_NAME)");
   }
 } 
     $x0=UX("update coode_dbkeydx set dxtype='varchar' where  dxtype='' and DATA_TYPE='varchar'");
     $x0=UX("update coode_dbkeydx set dxtype='date' where  dxtype='' and DATA_TYPE='date'");
     $x0=UX("update coode_dbkeydx set dxtype='datetime' where  dxtype='' and DATA_TYPE='datetime'");
     $x0=UX("update coode_dbkeydx set dxtype='text' where  dxtype='' and DATA_TYPE='text'");
     $x0=UX("update coode_dbkeydx set dxtype='int' where  dxtype='' and DATA_TYPE='int'");
     $x0=UX("update coode_dbkeydx set dxtype='tinyint' where  dxtype='' and DATA_TYPE='tinyint'");
     $x0=UX("update coode_dbkeydx set dxtype=DATA_TYPE where  dxtype=''");
     $x0=UX("update coode_dbkeydx set keytitle=COLUMN_NAME where  keytitle=''");
     $x1=UX("update coode_dbkeydy set keytitle=COLUMN_NAME where  keytitle=''");
     $x2=UX("update coode_dbkeydz set keytitle=COLUMN_NAME where  keytitle=''");
     $y0=UX("update coode_dbkeydx,coode_dkeydefine set coode_dbkeydx.keytitle=coode_dkeydefine.keyTitle,coode_dbkeydx.keyexplain=coode_dkeydefine.keyDescrib,coode_dbkeydx.clstxt=coode_dkeydefine.clsTxt,coode_dbkeydx.jsshowfun=coode_dkeydefine.jsRunCode,coode_dbkeydx.sysshowfun=coode_dkeydefine.htmlCode,coode_dbkeydx.dxtype=coode_dkeydefine.dxType,coode_dbkeydx.COLUMN_DEFAULT=coode_dkeydefine.defaultValue,coode_dbkeydx.displayed=coode_dkeydefine.disPlay,coode_dbkeydx.valuezero=coode_dkeydefine.valueZero,coode_dbkeydx.COLUMN_DEFAULT=coode_dkeydefine.defaultValue where coode_dbkeydx.COLUMN_NAME=coode_dkeydefine.keyMark and  coode_dbkeydx.COLUMN_NAME=coode_dbkeydx.keytitle and coode_dkeydefine.tabType=''");
     $y1=UX("update coode_dbkeydy,coode_dkeydefine set coode_dbkeydy.keytitle=coode_dkeydefine.keyTitle,coode_dbkeydy.keyexplain=coode_dkeydefine.keyDescrib,coode_dbkeydy.clstxt=coode_dkeydefine.clsTxt,coode_dbkeydy.jsshowfun=coode_dkeydefine.jsRunCode,coode_dbkeydy.sysshowfun=coode_dkeydefine.htmlCode,coode_dbkeydy.dxtype=coode_dkeydefine.dxType,coode_dbkeydy.COLUMN_DEFAULT=coode_dkeydefine.defaultValue,coode_dbkeydy.displayed=coode_dkeydefine.disPlay,coode_dbkeydy.valuezero=coode_dkeydefine.valueZero,coode_dbkeydy.COLUMN_DEFAULT=coode_dkeydefine.defaultValue where coode_dbkeydy.COLUMN_NAME=coode_dkeydefine.keyMark and  coode_dbkeydy.COLUMN_NAME=coode_dbkeydy.keytitle and coode_dkeydefine.tabType=''");
     $y2=UX("update coode_dbkeydz,coode_dkeydefine set coode_dbkeydz.keytitle=coode_dkeydefine.keyTitle,coode_dbkeydz.keyexplain=coode_dkeydefine.keyDescrib,coode_dbkeydz.clstxt=coode_dkeydefine.clsTxt,coode_dbkeydz.jsshowfun=coode_dkeydefine.jsRunCode,coode_dbkeydz.sysshowfun=coode_dkeydefine.htmlCode,coode_dbkeydz.dxtype=coode_dkeydefine.dxType,coode_dbkeydz.COLUMN_DEFAULT=coode_dkeydefine.defaultValue,coode_dbkeydz.displayed=coode_dkeydefine.disPlay,coode_dbkeydz.valuezero=coode_dkeydefine.valueZero,coode_dbkeydz.COLUMN_DEFAULT=coode_dkeydefine.defaultValue where coode_dbkeydz.COLUMN_NAME=coode_dkeydefine.keyMark and  coode_dbkeydz.COLUMN_NAME=coode_dbkeydz.keytitle and coode_dkeydefine.tabType=''");
     if ($tabtype!=""){
          $y0=UX("update coode_dbkeydx,coode_dkeydefine set coode_dbkeydx.keytitle=coode_dkeydefine.keyTitle,coode_dbkeydx.keyexplain=coode_dkeydefine.keyDescrib,coode_dbkeydx.clstxt=coode_dkeydefine.clsTxt,coode_dbkeydx.jsshowfun=coode_dkeydefine.jsRunCode,coode_dbkeydx.sysshowfun=coode_dkeydefine.htmlCode,coode_dbkeydx.dxtype=coode_dkeydefine.dxType,coode_dbkeydx.COLUMN_DEFAULT=coode_dkeydefine.defaultValue,coode_dbkeydx.displayed=coode_dkeydefine.disPlay,coode_dbkeydx.valuezero=coode_dkeydefine.valueZero,coode_dbkeydx.COLUMN_DEFAULT=coode_dkeydefine.defaultValue  where coode_dbkeydx.COLUMN_NAME=coode_dkeydefine.keyMark and  coode_dbkeydx.COLUMN_NAME=coode_dbkeydx.keytitle and coode_dkeydefine.tabType='".$tabtype."'");
          $y1=UX("update coode_dbkeydy,coode_dkeydefine set coode_dbkeydy.keytitle=coode_dkeydefine.keyTitle,coode_dbkeydy.keyexplain=coode_dkeydefine.keyDescrib,coode_dbkeydy.clstxt=coode_dkeydefine.clsTxt,coode_dbkeydy.jsshowfun=coode_dkeydefine.jsRunCode,coode_dbkeydy.sysshowfun=coode_dkeydefine.htmlCode,coode_dbkeydy.dxtype=coode_dkeydefine.dxType,coode_dbkeydy.COLUMN_DEFAULT=coode_dkeydefine.defaultValue,coode_dbkeydy.displayed=coode_dkeydefine.disPlay,coode_dbkeydy.valuezero=coode_dkeydefine.valueZero,coode_dbkeydy.COLUMN_DEFAULT=coode_dkeydefine.defaultValue  where coode_dbkeydy.COLUMN_NAME=coode_dkeydefine.keyMark and  coode_dbkeydy.COLUMN_NAME=coode_dbkeydy.keytitle and coode_dkeydefine.tabType='".$tabtype."'");
          $y2=UX("update coode_dbkeydz,coode_dkeydefine set coode_dbkeydz.keytitle=coode_dkeydefine.keyTitle,coode_dbkeydz.keyexplain=coode_dkeydefine.keyDescrib,coode_dbkeydz.clstxt=coode_dkeydefine.clsTxt,coode_dbkeydz.jsshowfun=coode_dkeydefine.jsRunCode,coode_dbkeydz.sysshowfun=coode_dkeydefine.htmlCode,coode_dbkeydz.dxtype=coode_dkeydefine.dxType,coode_dbkeydz.COLUMN_DEFAULT=coode_dkeydefine.defaultValue,coode_dbkeydz.displayed=coode_dkeydefine.disPlay,coode_dbkeydz.valuezero=coode_dkeydefine.valueZero,coode_dbkeydz.COLUMN_DEFAULT=coode_dkeydefine.defaultValue  where coode_dbkeydz.COLUMN_NAME=coode_dkeydefine.keyMark and  coode_dbkeydz.COLUMN_NAME=coode_dbkeydz.keytitle and coode_dkeydefine.tabType='".$tabtype."'");
     }
     $q0=UX("update coode_dbkeydx set classp=6 where (COLUMN_NAME='sNo' or  COLUMN_NAME='SNO') and classp=0 ");
     $q1=UX("update coode_dbkeydx set classp=7 where (COLUMN_NAME='OLMK' or  COLUMN_NAME='itemOnlyMark') and classp=0 ");
     $q1=UX("update coode_dbkeydx set classp=9 where (COLUMN_NAME='VRT' or  COLUMN_NAME='itemVerMd5') and classp=0 ");
     $q1=UX("update coode_dbkeydx set classp=10 where (COLUMN_NAME='CRTOR' or  COLUMN_NAME='itemCrtID') and classp=0 ");
     $q1=UX("update coode_dbkeydx set classp=11 where (COLUMN_NAME='PTOF' or  COLUMN_NAME='itemCrtComID') and classp=0 ");
  $xtrst=SX("select keytitle,keyexplain,clstxt,jsshowfun,jspostfun,sysshowfun,syspostfun,dxtype,classp,COLUMN_NAME from coode_dbkeydx where TABLE_CATALOG='".$catalog."' and TABLE_NAME='".$tnm."'"); 
  $xtotrst=countresult($xtrst);
  $fmkk="";
  $fmvv="";
  for ($k=0;$k<$xtotrst;$k++){
  $skeytitle[$k]=anyvalue($xtrst,"keytitle",$k);
  $skeyexplain[$k]=anyvalue($xtrst,"keyexplain",$k);
  $sclstxt[$k]=anyvalue($xtrst,"clstxt",$k);
  $sjsshowfun[$k]=anyvalue($xtrst,"jsshowfun",$k); 
  $ssysshowfun[$k]=anyvalue($xtrst,"sysshowfun",$k);  
  $sdxtype[$k]=anyvalue($xtrst,"dxtype",$k);
  $scn[$k]=anyvalue($xtrst,"COLUMN_NAME",$k);
  $clsp[$k]=anyvalue($xtrst,"classp",$k);
  switch($clsp[$k]){
     case "6":
     $pssno=$scn[$k];
     break;
     case "7":
     $psolmk=$scn[$k];
     break;
     case "9":
     $md5key=$scn[$k];
     break;
     case "10":
     $ickey=$scn[$k];
     break;
     case "11":
     $iwkey=$scn[$k];
     break;
     default:
  }
  if ($tabtype!="" and $skeytitle[$k]!="" and $skeytitle[$k]!=$scn[$k]){
   $extkk=UX("select count(*) as result from coode_dkeydefine where keyMark='".$scn[$k]."' and tabType='".$tabtype."'");
   if (intval($extkk)==0 ){
     $sqlm="tabType,keyMark,keyTitle,dxType,clsTxt,itemCTime,itemUTime,itemPUTime,inUse,disPlay";
     $sqln="'$tabtype','$scn[$k]','$skeytitle[$k]','$sdxtype[$k]','$sclstxt[$k]',now(),now(),now(),1,1";
     $zx=UX("insert into coode_dkeydefine(".$sqlm.")values(".$sqln.")");
   }else{
     $xz=UX("update coode_dkeydefine set keyTitle='".$sKeyTitle[$k]."',dxType='".$sdxtype[$k]."',clsTxt='".$sclstxt[$k]."',itemUTime=now() where keyMark='".$scn[$k]."' and tabType='".$tabtype."'");
   }
  }
    if ($skeytitle[$k]!=""){
      $fmkk=$fmkk.$skeytitle[$k].",";
    }else{
       $fmkk=$fmkk.$scn[$k].",";
    }
    $fmvv=$fmvv.$scn[$k].",";
};
  if ($xtotrst>0){
    $fmkk=substr($fmkk,0,strlen($fmkk)-1);
    $fmvv=substr($fmvv,0,strlen($fmvv)-1);
  }
  $allkx=$fmkk."|".$fmvv;  
 
  $yx=UX("update coode_dbshort set allkeys='".$allkx."' where tablename='".$tnm."' and catalog='".$catalog."'");
  
//只要超过10分钟不在本次更新时间范围的就删除
  $dtlkey="TABLE_CATALOG,TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,ORDINAL_POSITION,COLUMN_DEFAULT,IS_NULLABLE,DATA_TYPE,CHARACTER_MAXIMUM_LENGTH,CHARACTER_OCTET_LENGTH,NUMERIC_PRECISION,NUMERIC_SCALE,DATETIME_PRECISION,CHARACTER_SET_NAME,COLLATION_NAME,COLUMN_TYPE,COLUMN_KEY,EXTRA,PRIVILEGES,COLUMN_COMMENT,CRTM,OLMK,PTOF,classp,clstxt,keytitle,keyexplain,jsshowfun,sysshowfun,jspostfun,syspostfun,changeable,UPTM";  
  
   $x=UX("delete from coode_dbkeydx where timestampdiff(minute,UPTM,now())>2 and TABLE_CATALOG='".$catalog."' and TABLE_NAME='".$tnm."' ");
//只要超过10分钟不在本次更新时间范围的就删除  
  
   $x=UX("delete from coode_dbkeydy where timestampdiff(minute,UPTM,now())>2 and TABLE_CATALOG='".$catalog."' and TABLE_NAME='".$tnm."' ");
  
   $x=UX("delete from coode_dbkeydz where timestampdiff(minute,UPTM,now())>2 and TABLE_CATALOG='".$catalog."' and TABLE_NAME='".$tnm."' ");
//只要超过10分钟不在本次更新时间范围的就删除  
  
//只要超过10分钟不在本次更新时间范围的就删除
  $tbtt=UX("select tabtitle as result from coode_dbtablist where TABLE_NAME='".$tnm."' and catalog='".$catalog."'"); 
  $q=UX("update coode_dbtablist set jsonconts='".$fmjscon."',contentkeys='".$fmik."',allkeys='".$allkx."',createsql='".$crtsql."',keynames='".$fmk."',keytpnms='".$fmktp."',jsontpnms='".$fmjstp."' where TABLE_NAME='".$tnm."' and catalog='".$catalog."'");
  $mkx=UX("select keynames as result from coode_tablist  where TABLE_NAME='".$tnm."' and catalog='".$catalog."'");
  if (substr($mkx,0,5)=="OLMK,"){
    $woutolmk=hou($mkx,"OLMK,");
  }else{
    $woutolmk=str_replace(",OLMK","",$mkx);
  }
  $olx=UX("update ".$tnm." set ".$psolmk."=substring(md5(RAND()),1,9) where ".$psolmk."=''");
  $olx=UX("update ".$tnm." set itemCTime=now() where itemCTime='0000-00-00 00:00:00'");
  $olx=UX("update ".$tnm." set itemUTime=now() where itemUTime='0000-00-00 00:00:00'");
  $olx=UX("update ".$tnm." set itemPUTime=now() where itemPUTime='0000-00-00 00:00:00'");
  $z=UX("update coode_dbtablist set rescode=concat(schm,'/',TABLE_NAME),mainsqx='".$pssno."',olmkkey='".$psolmk."',md5key='".$md5key."',ickey='".$ickey."',iwkey='".$iwkey."' where TABLE_NAME='".$tnm."' and catalog='".$catalog."'");
  
  $p=UX("delete from coode_dbkeydx where TABLE_NAME='".$tnm."' and COLUMN_NAME='' and TABLE_CATALOG='".$catalog."'");
  $p=UX("delete from coode_dbkeydy where TABLE_NAME='".$tnm."' and COLUMN_NAME='' and TABLE_CATALOG='".$catalog."'");
  $p=UX("delete from coode_dbkeydz where TABLE_NAME='".$tnm."' and COLUMN_NAME='' and TABLE_CATALOG='".$catalog."'");
  $xx=UX("update coode_dbkeydx set OLMK=RAND()*10000000000 where OLMK=''");
  $xx=UX("update coode_dbkeydy set displayed=0 where COLUMN_NAME='OPRT' or COLUMN_NAME='itemOprt'");
  $xx=UX("update coode_dbkeydy set OLMK=RAND()*10000000000 where OLMK=''");
  $xx=UX("update coode_dbkeydz set OLMK=RAND()*10000000000 where OLMK=''");
  $xx=UX("update coode_dbkeydx set rescode=concat(TABLE_SCHEMA,'/',TABLE_NAME,'.',COLUMN_NAME) where rescode=''");
  $xx=UX("update coode_dbkeydy set rescode=concat(TABLE_SCHEMA,'/',shortid,'.',COLUMN_NAME) where rescode=''");
  $xx=UX("update coode_dbkeydz set rescode=concat(TABLE_SCHEMA,'/',shortid,'.',COLUMN_NAME) where rescode=''");
 echo makereturnjson("1","获取成功","0");
     session_write_close();
?>