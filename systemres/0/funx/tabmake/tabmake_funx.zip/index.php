<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $prst=_post("prst");
$btree=tostring(_get("btree"));
$regcode=_get("regcode");
$tnm=_get("tnm");
$uid=_get("uid");
$trst=$prst;
$totrst=countresult($trst);
$fmc="";
$fmk="";
$fmik="";
$fmktp="";
$fmjstp="";
$fmjscon="";
$tbdk="X/CRTM/UPTM/CRTOR/STATUS/OLMK/VRT/STCODE/PTOF/PRIME/RIP/SNO/OPRT/";
if ($tnm=="coode_keydetailx" or $tnm=="coode_keydetaily"){
 $expk="X/ORDINAL_POSITION,COLUMN_DEFAULT,IS_NULLABLE,CHARACTER_OCTET_LENGTH,NUMERIC_PRECISION,NUMERIC_SCALE,DATETIME_PRECISION,CHARACTER_SET_NAME,COLLATION_NAME,COLUMN_TYPE,COLUMN_KEY,EXTRA,PRIVILEGES,COLUMN_COMMENT";
}else{
 $expk="";
}
for ($k=0;$k<$totrst;$k++){
   $sTABLE_CATALOG[$k]=anyvalue($trst,"TABLE_CATALOG",$k);
   $sTABLE_SCHEMA[$k]=anyvalue($trst,"TABLE_SCHEMA",$k);
   $sTABLE_NAME[$k]=anyvalue($trst,"TABLE_NAME",$k);
   $sCOLUMN_NAME[$k]=anyvalue($trst,"COLUMN_NAME",$k);
   $sORDINAL_POSITION[$k]=anyvalue($trst,"ORDINAL_POSITION",$k);
   $sCOLUMN_DEFAULT[$k]=anyvalue($trst,"COLUMN_DEFAULT",$k);
   $sIS_NULLABLE[$k]=anyvalue($trst,"IS_NULLABLE",$k);
   $sDATA_TYPE[$k]=anyvalue($trst,"DATA_TYPE",$k);
   $sCHARACTER_MAXIMUM_LENGTH[$k]=anyvalue($trst,"CHARACTER_MAXIMUM_LENGTH",$k);
   $sCHARACTER_OCTET_LENGTH[$k]=anyvalue($trst,"CHARACTER_OCTET_LENGTH",$k);
   $sNUMERIC_PRECISION[$k]=anyvalue($trst,"NUMERIC_PRECISION",$k);
   $sNUMERIC_SCALE[$k]=anyvalue($trst,"NUMERIC_SCALE",$k);
   $sCHARACTER_SET_NAME[$k]=anyvalue($trst,"CHARACTER_SET_NAME",$k);
   $sCOLLATION_NAME[$k]=anyvalue($trst,"COLLATION_NAME",$k);
   $sCOLUMN_TYPE[$k]=anyvalue($trst,"COLUMN_TYPE",$k);
   $sCOLUMN_KEY[$k]=anyvalue($trst,"COLUMN_KEY",$k);
   $sEXTRA[$k]=anyvalue($trst,"EXTRA",$k);
   $sPRIVILEGES[$k]=anyvalue($trst,"PRIVILEGES",$k);
   $sCOLUMN_COMMENT[$k]=anyvalue($trst,"COLUMN_COMMENT",$k);
   $somark[$k]=date('Ymdhis').getRandChar(6);
   if ($sCOLUMN_NAME[$k]=="SNO"){
   }else{
       if (strpos($expk,$sCOLUMN_NAME[$k])>0){
       }else{
        $fmk=$fmk.$sCOLUMN_NAME[$k].",";
       };
    if ($k<$totrst-1){
        if (strpos($tbdk,"/".$sCOLUMN_NAME[$k]."/")>0){
        }else{
          if (strpos($expk,$sCOLUMN_NAME[$k])>0){
          }else{
           $fmik=$fmik.$sCOLUMN_NAME[$k].",";
           $fmjscon=$fmjscon."↓\"".$sCOLUMN_NAME[$k]."∵↓,".$sCOLUMN_NAME[$k].",↓\",↓,";
          }
        }
    }else{
          if (strpos($expk,$sCOLUMN_NAME[$k])>0){
          }else{
           if (strpos($tbdk,"/".$sCOLUMN_NAME[$k]."/")>0){
             $fmjscon=$fmjscon."↓\"tablename∵".$tnm."\"↓";
           }else{
             $fmik=$fmik.$sCOLUMN_NAME[$k].",";
             $fmjscon=$fmjscon."↓\"".$sCOLUMN_NAME[$k]."∵↓,".$sCOLUMN_NAME[$k].",↓\"↓";
           }
          }
    }
         if (strpos($expk,$sCOLUMN_NAME[$k])>0){
         }else{
           if ($k<$totrst-1){
             $fmktp=$fmktp.$sCOLUMN_NAME[$k].",↓↑,↑↓,";
             $fmjstp=$fmjstp."↓\"".$sCOLUMN_NAME[$k]."∵↓,".$sCOLUMN_NAME[$k].",↓\",↓,";
           }else{
             $fmktp=$fmktp.$sCOLUMN_NAME[$k];
             $fmjstp=$fmjstp."↓\"".$sCOLUMN_NAME[$k]."∵↓,".$sCOLUMN_NAME[$k].",↓\"↓";
           }
         }
   }
   
  switch($sDATA_TYPE[$k]){
    case "int":
    if ($sCOLUMN_NAME[$k]=="SNO"){
      $fmc=$fmc.$sCOLUMN_NAME[$k]." int(11) NOT NULL AUTO_INCREMENT,";
    }else{
      $fmc=$fmc.$sCOLUMN_NAME[$k]." int(11) NOT NULL,";
    }
    break;
    case "bigint":
    if ($sCOLUMN_NAME[$k]=="SNO"){
      $fmc=$fmc.$sCOLUMN_NAME[$k]." bigint(20) NOT NULL AUTO_INCREMENT,";
    }else{
      $fmc=$fmc.$sCOLUMN_NAME[$k]." bigint(20) NOT NULL,";
    }
    break;
    case "tinyint":
    if ($sCOLUMN_NAME[$k]=="SNO"){
      $fmc=$fmc.$sCOLUMN_NAME[$k]." tinyint(4) NOT NULL AUTO_INCREMENT,";
    }else{
      $fmc=$fmc.$sCOLUMN_NAME[$k]." tinyint(4) NOT NULL,";
    }
    break;
    case "decimal":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." decimal(10,2) NOT NULL,";
    break;
    case "varchar":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." varchar(".$sCHARACTER_MAXIMUM_LENGTH[$k].") NOT NULL,";
    break;
    case "text":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." text NOT NULL,";
    break;
    case "longtext":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." longtext NOT NULL,";
    break;
    case "date":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." date NOT NULL,";
    break;
    case "datetime":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." datetime NOT NULL,";
    break;    
    default:
  }
  
}
$fmc=$fmc."PRIMARY KEY (SNO),";
$fmk=killlaststr($fmk);
$fmik=killlaststr($fmik);
$fmktp="concat(↓↑↓,".$fmktp.",↓↑↓)";
$fmjstp="concat(".$fmjstp.")";
if ($btree==""){
  $fmc=killlaststr($fmc);
}else{
  $fmc=$fmc.$btree;
}
$ocrt=$_POST["ocrt"];
$crtsql="CREATE TABLE ".$tnm." (".$fmc.") ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;";
if ($ocrt==$crtsql){
 echo "-CREATESQL:".$crtsql."/JSCON:".$fmjscon."/CONKEYS:".$fmik."/ALLKEYS:".$allkx."/TKEYS:".$fmk."/KEYTYPES:".$fmktp."/JSONKTPS:".$fmjstp."/";
}else{
  eval(CLASSX("cattrade"));
  $cfd=new cattrade();
  $_GET["toacc"]="1";
  $glf=$cfd->getleft($uid);
  if (intval($glf)>=50){
    $cfd->cutfood($uid,50,"system",$uid."消耗50颗猫粮获得创建表格代码");
    $glf=$cfd->getleft($uid);
    echo "-CREATESQL:".$crtsql."/JSCON:".$fmjscon."/CONKEYS:".$fmik."/ALLKEYS:".$allkx."/TKEYS:".$fmk."/KEYTYPES:".$fmktp."/JSONKTPS:".$fmjstp."/";
  }else{
    $crtsql="";
    $fmjscon="";
    $fmik="";
    $allkx="";
    $fmk="";
    $fmktp="";
    $fmjstp="";
    echo "-CREATESQL:".$crtsql."/JSCON:".$fmjscon."/CONKEYS:".$fmik."/ALLKEYS:".$allkx."/TKEYS:".$fmk."/KEYTYPES:".$fmktp."/JSONKTPS:".$fmjstp."/";
  }
}
  
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>