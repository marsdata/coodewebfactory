<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $rescode=_get("rescode");
$trst=SX("select linemark,objmarks from coode_wrdrestpdefine where typecodex='".$rescode."'");
$linemark=anyvalue($trst,"linemark",0);
$objmarks=anyvalue($trst,"objmarks",0);
$zz=UX("update ".$linemark." set STATUS=0");
$totx=UX("select count(*) as result  from ".$linemark." where STATUS=0");
$zz=UX("update coode_wrdrestpdefine set STCODE=".$totx." where typecodex='".$rescode."'");
echo makereturnjson("1","归零成功","");
     session_write_close();
?>