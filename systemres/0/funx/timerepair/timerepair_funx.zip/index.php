<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tbnm=$_GET["tablename"];
$conn=mysql_connect(gl(),glu(),glp());
$tmrst=selecteds($conn,glb(),"select COLUMN_NAME,TABLE_SCHEMA,DATA_TYPE from coode_keydetailx where TABLE_NAME='".$tbnm."' and (DATA_TYPE='datetime' or DATA_TYPE='date')","utf8","");
$tot=countresult($tmrst);
for ($i=0;$i<$tot;$i++){ 
  $knm=anyvalue($tmrst,"COLUMN_NAME",$i);
  $tbs=anyvalue($tmrst,"TABLE_SCHEMA",$i);
  $dtp=anyvalue($tmrst,"DATA_TYPE",$i);
  $conn=mysql_connect(gl(),glu(),glp());
  if ($dtp=="datetime"){
   $x=updatings($conn,glb(),"update ".$tbnm." set ".$knm."='1987-11-23 18:18:18' where ".$knm."='0000-00-00 00:00:00'","utf8");
  }else{
   $x=updatings($conn,glb(),"update ".$tbnm." set ".$knm."='1987-11-23' where ".$knm."='0000-00-00'","utf8");
  }   
}
   $conn=mysql_connect(gl(),glu(),glp());
   $x=updatings($conn,glb(),"update ".$tbnm." set OLMK=RAND()*100000000000 where OLMK=''","utf8");
echo $tot;
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>