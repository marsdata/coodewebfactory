<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $layid=$_GET["layid"];
$tinyid=$_GET["tinyid"];
//如果tinyid填写空则只能表示为更具体的页面请求，layid不能为空，下回请求的时候可以至传TINYID
$rcvkey=$_POST["keys"];
$rcvtitle=$_POST["rcvtt"];
$rcvktitle=$_POST["ktitles"];
$fromurl=$_SERVER["HTTP_REFERER"];
$funrun=0;
$runstt="1";
$runmsg="已执行";
$runrdr="";
if ($layid!="" and $layid!="un"."defined"){
  $tprst=SX("select rcvid,rcvtitle,rcvfun,askformat,rtempid from coode_tinyrcvpost where  layid='".$layid."' and tinyid='".$tinyid."'");
  $tott=countresult($tprst);
  if (intval($tott)>0){
   $rcvid=anyvalue($tprst,"rcvid",0);
   $rcvtitle=anyvalue($tprst,"rcvtitle",0);
   $rcvfun=anyvalue($tprst,"rcvfun",0);
   $rtempid=anyvalue($tprst,"rtempid",0);
   $askformat=anyvalue($tprst,"askformat",0);
   if ($rcvfun=="" and $rtempid==""){
     echo "{\"status\":\"0\",\"msg\":\"方法未定义\",\"redirect\":\"\"}";
   }else{
     if ($rtempid==""){
       eval(tostring($rcvfun));   
     }else{
       //如果自己没有方法看看是否已经定义默认模板了，如果有则从默认里找
       $rcvfun=UX("select rcvfun as result from coode_tinyrcvtemp where rcvid='".$rtempid."'");
       if ($rcvfun!=""){
         eval(tostring($rcvfun));   
       }
     }
     if ($funrun==1){
     //postblog
      echo "{\"status\":\"".$runstt."\",\"msg\":\"".$runmsg."\",\"redirect\":\"".$runrdr."\"}";
     }else{
      echo "{\"status\":\"0\",\"msg\":\"方法未执行或数据格式不正确\",\"redirect\":\"\"}";
     }
   }
  }else{
    $demo='$rcvtitle="'.$rcvtitle.'";'.huanhang();
    $demo=$demo.'$layid="'.$layid.'";'.huanhang();
    $demo=$demo.'$tinyid="'.$tinyid.'";'.huanhang();
    $demo=$demo.'$runstt="0";'.huanhang();
    $demo=$demo.'$runmsg="";'.huanhang();
    $demo=$demo.'$runrdr="";'.huanhang();
    $demo=$demo.'$rcvkeys="'.$rcvkey.'";'.huanhang();
    $demo=$demo.'$rcvtitles="'.$rcvktitle.'";'.huanhang();
    
    $ptkey=explode(",",$rcvkey);
    $totpt=count($ptkey);
    for ($i=0;$i<$totpt;$i++){
      $kname=qian($ptkey[$i],"(");
      $ktype=qian(hou($ptkey[$i],"("),")");
      if (strpos($ktype,"[")>0){
       $ksize=qian(hou($ktype,"["),"]");
       $ktype=qian($ktype,"[");
      }else{
       $ksize="";
      }
      switch ($ktype){
       case "url":
       break;
       default:
       $demo=$demo.'$'.$kname.'x=$_POST["'.$kname.'"];'.huanhang(); 
      }
      //这里可以加上校验格式的方法
    }
    $demo=$demo.'$funrun=1;'.huanhang();
    $sqlx="tinyid,layid,rcvid,rcvtitle,rcvfun,askformat,CRTM,UPTM";
    $sqly="'".$tinyid."','".$layid."','','".$rcvtitle."','".gohex($demo)."','',now(),now()";
    $z=UX("insert into coode_tinyrcvpost(".$sqlx.")values(".$sqly.")");
    echo "{\"status\":\"0\",\"msg\":\"方法不存在，已申请\",\"redirect\":\"\"}";
  }
  $z=UX("update coode_tinyrcvpost set rcvid=concat(layid,'.',tinyid) where rcvid=''");
  
}else{
  echo "{\"status\":\"0\",\"msg\":\"layid为空\",\"redirect\":\"\"}";
}
     session_write_close();
?>