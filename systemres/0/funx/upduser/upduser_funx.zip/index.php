<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $uid=_post("uid");
$vxuid=_post("vxuid");
$nickname=_post("nickname");
$sexy=_post("sexy");
$cityx=_post("cityx");
$prov=_post("prov");
$country=_post("country");
$vxhead=_post("vxhead");
$avx=Array(Array());
$avx=AV("coode_userlist@userid=".$uid.":::realname");
$rnm=dftval($avx[0][1],"");
$bkx=UV("coode_userlist@userid=".$uid."&vxpic=".$vxhead."&realname=".$rnm."&nickname=".$nickname."&sex=".$sexy."&headpic=".$vxhead."&vxuid=".$vxuid."&country=".$country."&city=".$cityx."&province=".$prov);
if (intval($bkx*1)==0){
  echo makereturnjson("1","成功新增或修改".$uid."的用户信息","");
}else{
  echo makereturnjson("0",$uid."的用户信息操作失败，代码:".$bkx,"");
}
     session_write_close();
?>