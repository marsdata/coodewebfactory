<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $ddd=$_GET["ddd"];
if (substr($ddd,-1)=="/"){
  $ddd=substr($ddd,0,strlen($ddd)-1);
}
if (substr($ddd,0,1)!="/"){
  $ddd="/".$ddd;
}
$q=anyfunrun("foldertree","","ddd=".$ddd,"");
$frst=SX("select SNO,filepath,filetitle,filetype,filename,CRTM from coode_foldertree where parfolder='".$ddd."' and STATUS=1");//上传有变动的  STATUS=1 为修改后变动
$totf=countresult($frst);
$tot=0;
for ($i=0;$i<$totf;$i++){
  $sno=anyvalue($frst,"SNO",$i);
  $filepath=anyvalue($frst,"filepath",$i);
  $filetitle=anyvalue($frst,"filetitle",$i);
  $filetype=anyvalue($frst,"filetype",$i);
  $filename=anyvalue($frst,"filename",$i);
  $uppath=str_replace(localroot(),"",$filepath);
   if ($filetype!=""){
     $z=file_get_contents("http://".glw()."DNA/EXF/qnyupload.php?lcfile=".$filepath);
     $y=json_decode($z, true);
     if(intval($y["status"])==1){
       $z=UX("update coode_foldertree set CRTM=now(),STATUS=0,cloudpath='".$y["key"]."' where SNO=".$sno);
       $tot=$tot+1;
     }
   }  
}
if ($tot>0){
 $ffrst=SX("select SNO,myid,parid,filepath,filetitle,filetype,filename,CRTM from coode_foldertree where parfolder='".$ddd."'");//上传有变动的  STATUS=1 为修改后变动
 $totff=countresult($ffrst);
 $demox='{"myid":"[myid]","parid":"[parid]","filepath":"[filepath]","filetitle":"[filetitle]","filetype":"[filetype]","ctime":"[ctime]"},';
 $srd="$a".md5($ddd)."='{[";
 $fmx="";
 $fmy="";
  for ($i=0;$i<$totff;$i++){
   $sno=anyvalue($frst,"SNO",$i);
   $myid=anyvalue($ffrst,"myid",$i);
   $parid=anyvalue($ffrst,"parid",$i);
   $filepath=anyvalue($ffrst,"filepath",$i);
   $filetitle=anyvalue($ffrst,"filetitle",$i);
   $filetype=anyvalue($ffrst,"filetype",$i);
   $filename=anyvalue($ffrst,"filename",$i);
   $ctime=anyvalue($ffrst,"CRTM",$i);
   $uppath=str_replace(localroot(),"",$filepath);
   $demoy=$demox;
   $demoy=str_replace("[myid]",$myid,$demoy);
   $demoy=str_replace("[parid]",$parid,$demoy);
   $demoy=str_replace("[filepath]",$uppath,$demoy);
   $demoy=str_replace("[filetitle]",$filetitle,$demoy);
   $demoy=str_replace("[filetype]",$filetype,$demoy);
   $demoy=str_replace("[ctime]",$ctime,$demoy);
   $fmx=$fmx.$demoy;
  }
   $fmx=killlaststr($fmx);
   $fmy=$srd.$fmx."]}';";
   $verfile=combineurl(localroot(),$ddd."/fileversion.json");    
   $v=overfile($verfile,$fmy);
   $bbb=file_get_contents("http://".glw()."DNA/EXF/qnyupload.php?lcfile=".$verfile);
 }
$zz=UX("update coode_folderreg set incloud=1,UPTM=now() where foldermark='".$ddd."'");
echo '{"status":"1","msg":"成功-'.$tot."/".$totf.'","redirect":""}';
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>