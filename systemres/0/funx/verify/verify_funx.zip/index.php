<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     @$uid=$_POST['uid'];
@$cid=$_POST['gid'];
@$scv=$_POST['scv'];
@$tel=$_POST['tel'];
@$eml=$_POST['eml'];
@$hashpa=$_POST['hashpa'];
@$vcode=$_POST['vcode'];
$tourl=$_GET['tourl'];
$fromurl=$_GET['fromurl'];
  if ($uid!="" and $hashpa!=""){ 
    eval(CLASSX("coodelogin"));    
    $loginx=new coodelogin();
    $lgx=$loginx->login($uid,$hashpa,$cid,$scv);             
    $apx=$loginx->applistset();             
    $pmx=$loginx->permitset();             
    $mnx=$loginx->menuset();   
    $rdrct=$loginx->$redirecty;
    $z=syspagepmt($cid);
    $Z=UX("update coode_tablist set STATUS=1");
    $Z=UX("update coode_tiny set STATUS=1");
    $Z=UX("update coode_funlist set STATUS=1");
    $tbrst=SX("select TABLE_NAME from coode_tablist where STATUS=1");
    $tottb=countresult($tbrst);
   for ($i=0;$i<$tottb;$i++){
    $a=makecomtabbw(anyvalue($tbrst,"TABLE_NAME",$i),$cid,gln());
    $a=maketabpmt(anyvalue($tbrst,"TABLE_NAME",$i),gln());
   }
   $funrst=SX("select funname from coode_funlist where STATUS=1");
   $totfun=countresult($funrst);
   for ($i=0;$i<$totfun;$i++){
    $a=makecomfunbw(str_replace("()","",anyvalue($funrst,"funname",$i)),$cid,gln());
    $a=makefunpmt(str_replace("()","",anyvalue($funrst,"funname",$i)),gln());
   }
   $sqlx="funid,clientid,shortid,shorty,valx,reurl,appid,sysid,scvid,starttime,endtime";
   $z=UX("insert into coode_fpmtrole(".$sqlx.",comid,roleid)select ".$sqlx.",'".$cid."','DataMaster' from coode_fpmtsys where concat(funid,'".$cid."','DataMaster') not in (select concat(funid,comid,roleid) from coode_fpmtrole)");
   $sqlx="permid,permtitle,appid,grpvalx,clientid,metcls,method,behiver,valx,dataarea,sysid";
   $z=UX("insert into coode_tpmtrole(".$sqlx.",compid,groupid)select ".$sqlx.",'".$cid."','DataMaster' from coode_tpmtsys where concat(permid,'".$cid."','DataMaster') not in (select concat(permid,compid,groupid) from coode_tpmtrole)");
   $sqlx="pagemark,clientid,shortid,shorty,valx,reurl,appid,sysid,starttime,endtime";
   $z=UX("insert into coode_ppmtrole(".$sqlx.",comid,roleid)select ".$sqlx.",'".$cid."','DataMaster' from coode_ppmtsys where concat(pagemark,'".$cid."','DataMaster') not in (select concat(pagemark,comid,roleid) from coode_ppmtrole)");     
        if (isx1($lgx,"Login Success")){
         if ($rdrct==""){
           $rdrct=qian(hou($lgx,"redirect\":\""),"\"");
         }
         echo "{\"status\":\"1\",\"msg\":\"you can login sys\",\"redirect\":\"".$rdrct."\"}";
        }else{
         echo "{\"status\":\"0\",\"msg\":\"not allowed to login\",\"redirect\":\"\"}";  
        }
        
    }else{//ext  不能存在值
      echo "{\"status\":\"-1\",\"msg\":\"not allowed to login\",\"redirect\":\"\"}";
    }
 
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>