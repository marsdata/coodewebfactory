<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tel=_get("tel");
$pgss=_get("pgss");
$vcode=_get("vcode");
$pgstoken=_get("pgstoken");
$loginvfcode=_get("loginvfcode");
$fromhost=_get("fromhost");
$openid=_get("openid");
$areatype=_get("areatype");
$areacode=_get("areacode");
$vxarea=_get("vxarea");
$ocode=varval($pgss);
if ($ocode==$vcode and $tel!="" and $openid!="" and  $vcode!=""){
 $urst=SX("select vxuid,userid,dpmore,depart,posids,realname from coode_userlist where userid='".$tel."'");
          $userid=anyvalue($urst,"userid",0);
          setcookie("uid",$userid,time()+3600,"/");          
          setcookie("cid",garea(),time()+3600,"/");                    
          $depart=anyvalue($urst,"depart",0);
          $dpmore=anyvalue($urst,"dpmore",0);
          $posids=anyvalue($urst,"posids",0);          
          setcookie("depart",$depart,time()+3600,"/");
          setcookie("dpts",$dpmore,time()+3600,"/");
          setcookie("posids",$posids,time()+3600,"/");
          $stoken=md5($userid.garea().time());
          setcookie("stoken",$stoken,time()+3600,"/");  
 $z=UX("update coode_userlist set vxuid='".$openid."' where userid='".$tel."'");
 
if ($loginvfcode==""){
   if ($areatype==""){
     $loginarea=_get("loginarea");
     $qrykey=_get("qrykey");
     $qryval=_get("qryval");
     echo makereturnjson("1","验证成功","/localxres/funx/worchatlogin/?mobile=".$tel."&loginarea=".$loginarea."&qrykey=".$qrykey."&qryval=".$qryval."&vxarea=".$vxarea."&pagestoken=".$pgstoken);
   }else{
     echo makereturnjson("1","通用验证成功","/localxres/funx/vxlogin/?vxarea=".$vxarea."&mobile=".$tel."&areatype=".$areatype."&areacode=".$areacode."&pagestoken=".$pgstoken);
   }
 }else{
   echo makereturnjson("1","远程验证成功","/localxres/funx/vxrmtlogin/?vxarea=".$vxarea."&mobile=".$tel."&areatype=".$areatype."&areacode=".$areacode."&fromhost=".$fromhost."&loginvfcode=".$loginvfcode."&pagestoken=".$pgstoken);
 }
}else{
  echo makereturnjson("0","验证失败","");
}
     session_write_close();
?>