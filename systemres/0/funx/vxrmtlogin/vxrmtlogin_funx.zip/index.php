<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $vxarea=_get("vxarea");
$appidx=UX("select appid as result from coode_apipool where apicode='".$vxarea."'");
$appid=dftval($appidx,constval($vxarea."vxappid"));
$mobile=$_GET["mobile"];
$areatype=$_GET["areatype"];
$areacode=$_GET["areacode"];
$fromhost=$_GET["fromhost"];
$loginvfcode=$_GET["loginvfcode"];
$pagestoken=dftval($_GET["pagestoken"],"");
setcookie("loginvfcode",$loginvfcode,time()+3600,"/");          
setcookie("fromhost",$fromhost,time()+3600,"/");          
setcookie("logintel",$mobile,time()+3600,"/");          
setcookie("areatype",$areatype,time()+3600,"/");
setcookie("areacode",$areacode,time()+3600,"/");
setcookie("pagestoken",$pagestoken,time()+3600,"/");
setcookie("vxarea",$vxarea,time()+3600,"/");
 if ($mobile!="" and $areatype!=""){
   $vxsvsuri=combineurl("http://".glw(),"/localxres/funx/rmtvxauth/");
   header('location:https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$appid.'&redirect_uri='.$vxsvsuri.'&response_type=code&scope=snsapi_userinfo&state=123&connect_redirect=1#wechat_redirect');
 }else{
   if (strpos($_SERVER["HTTP_REFERER"],"?")>0){
     header('location:'.$_SERVER['HTTP_REFERER']."&mobile=0");
   }else{
     header('location:'.$_SERVER['HTTP_REFERER']."?mobile=0");
   }
 }
     session_write_close();
?>