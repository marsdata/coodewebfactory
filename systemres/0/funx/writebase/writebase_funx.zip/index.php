<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $motherhost=$_POST["motherhost"];
$sitecode=$_POST["sitecode"];
$sitename=$_POST["sitename"];
$cdip=$_POST["cdip"];
$cduser=$_POST["cduser"];
$cdpass=$_POST["cdpass"];
$cdbase=$_POST["cdbase"];
  if ($_SERVER["SERVER_PORT"] == "80"){
  $thishost=$_SERVER["HTTP_HOST"];
  }else{
  $thishost=$_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"];  
  }
$bktxt=file_get_contents("http://".$motherhost."/localxres/funx/askforcode/?hdomain=".$thishost."&hostcode=".$sitecode."&hostname=".$sitename);
$bkjson=json_decode($bktxt,flase);
$stt=$bkjson->status*1;
if ($stt>0){
 $ak=$bkjson->kcode;
 $av=$bkjson->vcode;
 $conx=mysql_connect($cdip,$cduser,$cdpass);
 if ($conx){
  $dfttxt=file_get_contents("http://".$motherhost."/localxres/funx/getcoredft/"); 
  $dfttxt=str_replace("[cdip]",$cdip,$dfttxt);
  $dfttxt=str_replace("[cduser]",$cduser,$dfttxt);
  $dfttxt=str_replace("[cdpass]",$cdpass,$dfttxt);
  $dfttxt=str_replace("[cdbase]",$cdbase,$dfttxt);
  $dfttxt=str_replace("[ak]",$ak,$dfttxt);
  $dfttxt=str_replace("[av]",$av,$dfttxt);
  $dfttxt=str_replace("[firstsys]","1",$dfttxt);
  $dfttxt=str_replace("[sitename]",$sitename,$dfttxt);
  $dfttxt=str_replace("[hostcode]",$sitecode,$dfttxt);
  $dfttxt=str_replace("[runblog]","1",$dfttxt);
  $dfttxt=str_replace("[runprocess]","1",$dfttxt);
  $dfttxt=str_replace("[remoteway]","1",$dfttxt);
  $dftfile=combineurl(localroot(),"/localxres/USERDEFINE.php");
  $zz=overfile($dftfile,$dfttxt);
  $basetxt=file_get_contents("http://".$motherhost."/localxres/funx/getcoretxt/"); 
  $basefile=combineurl(localroot(),"/localxres/EARTH.php");
  $zz=overfile($basefile,$basetxt);  
  $oprtfile=combineurl(localroot(),"/install/runingbox/insoprt_base.php");
  $oprttxt=file_get_contents($oprtfile); 
  $oprttxt=str_replace("[cdip]",$cdip,$oprttxt);
  $oprttxt=str_replace("[cduser]",$cduser,$oprttxt);
  $oprttxt=str_replace("[cdpass]",$cdpass,$oprttxt);
  $oprttxt=str_replace("[cdbase]",$cdbase,$oprttxt);
  $oprttxt=str_replace("[ak]",$ak,$oprttxt);
  $oprttxt=str_replace("[av]",$av,$oprttxt);
  $oprttxt=str_replace("[firstsys]","1",$oprttxt);
  $oprttxt=str_replace("[sitename]",$sitename,$oprttxt);
  $oprttxt=str_replace("[hostcode]",$sitecode,$oprttxt);
  $oprttxt=str_replace("[runblog]","1",$oprttxt);
  $oprttxt=str_replace("[runprocess]","1",$oprttxt);
  $oprttxt=str_replace("[remoteway]","1",$oprttxt);
  $zz=overfile($oprtfile,$oprttxt);
  $podfile=combineurl(localroot(),"/install/runingbox/installpod_base.php");
  $podtxt=file_get_contents($podfile); 
  $podtxt=str_replace("[cdip]",$cdip,$podtxt);
  $podtxt=str_replace("[cduser]",$cduser,$podtxt);
  $podtxt=str_replace("[cdpass]",$cdpass,$podtxt);
  $podtxt=str_replace("[cdbase]",$cdbase,$podtxt);
  $podtxt=str_replace("[ak]",$ak,$podtxt);
  $podtxt=str_replace("[av]",$av,$podtxt);
  $podtxt=str_replace("[firstsys]","1",$podtxt);
  $podtxt=str_replace("[sitename]",$sitename,$podtxt);
  $podtxt=str_replace("[hostcode]",$sitecode,$podtxt);
  $podtxt=str_replace("[runblog]","1",$podtxt);
  $podtxt=str_replace("[runprocess]","1",$podtxt);
  $podtxt=str_replace("[remoteway]","1",$podtxt);
  $zz=overfile($podfile,$podtxt);
  echo makereturnjson("1","核心文件写入成功","runingbox/index.html?ssmark=".getRandChar(8)."&motherhost=".$motherhost);
 }else{
  echo makereturnjson("0","数据库连接失败","");  
 }
}else{
  echo makereturnjson("0","母服务器响应失败","");
}
       session_write_close();
?>