<?php
//--------------------------------new
require_once "../lib/WxPay.Api.php";
require_once '../lib/WxPay.Notify.php';
require_once "WxPay.Config.php";
require_once 'log.php';
require_once 'curlx.php';
 
class PayNotifyCallBack extends WxPayNotify {
 
//查询订单
 
  public function Queryorder($transaction_id){
 
    $input = new WxPayOrderQuery();
 
    $input->SetTransaction_id($transaction_id);
 
    $result = WxPayApi::orderQuery($input);
 
      if (array_key_exists("return_code", $result) && array_key_exists("result_code", $result) && $result["return_code"] == "SUCCESS" && $result["result_code"] == "SUCCESS" ) {
        return true; 
      } 
    return false;
   }
 
  

	
//重写回调处理函数
 
  public function notify($objData, $config, &$msg){
    $notfiyOutput = array();
    if (!array_key_exists("transaction_id", $data)) {
         $msg = "输入参数不正确";
         return false;
     } 
       //查询订单，判断订单真实性
     if (!$this->Queryorder($data["transaction_id"])) {
         $msg = "订单查询失败";
        return false;
      }
    //$data中各个字段在return_code为SUCCESS的时候有返回 SUCCESS/FAIL
 
    //此字段是通信标识，非交易标识，交易是否成功需要查看result_code来判断
 
    //成功后写入自己的数据库
 
    if ($data['return_code'] == 'SUCCESS' && $data['result_code'] == 'SUCCESS') {
       //自己的业务逻辑
      $out_trade_no = $data['out_trade_no']; 
      $bank_type = $data['bank_type']; 
      $fee_type = $data['fee_type'];
      $time_end = $data['time_end'];
      $amount = $data['total_fee'];
      $nurl="http://shifu.link/config/anyfuns.php?fid=vxnotify&myid=".$out_trade_no."&vxid=".$data["transaction_id"]."&prc=".$amount."&status=".$data['result_code'];
       //$xx=file_get_contents($nurl);
      $pdt["x"]=" ";
      $nfsys=request_post($nurl , $pdt);
      $xx=file_get_contents($nurl);
$vurl='http://shifu.link/config/anyfuns.php?fid=anytest&tt=sadf';
      $xx=file_get_contents($vurl);
     }else{
    
      $out_trade_no = $data['out_trade_no']; 
      $bank_type = $data['bank_type']; 
      $fee_type = $data['fee_type'];
      $time_end = $data['time_end'];
      $amount = $data['total_fee'];
      $nurl="http://shifu.link/config/anyfuns.php?fid=vxnotify&myid=".$out_trade_no."&vxid=".$data["transaction_id"]."&prc=".$amount."&status=".$data['result_code'];
       //$xx=file_get_contents($nurl);
      $pdt["x"]=" ";
      $nfsys=request_post($nurl , $pdt);
      $xx=file_get_contents($nurl);
            $vurl='http://shifu.link/config/anyfuns.php?fid=anytest';
      $xx=file_get_contents($vurl);
     }
    return true;
   }//fun
}//class
  //    $out_trade_no = $data['out_trade_no']; 
  //    $bank_type = $data['bank_type']; 
  //    $fee_type = $data['fee_type'];
  //    $time_end = $data['time_end'];
  //    $amount = $data['total_fee'];
 //     $nurl="http://shifu.link/config/anyfuns.php?fid=vxnotify&myid=".$out_trade_no."&vxid=".$data["transaction_id"]."&prc=".$amount."&status=".$data['result_code'];
//$xx=file_get_contents($nurl);

//$vurl='http://shifu.link/config/anyfuns.php?fid=anytest';
//$xx=file_get_contents($vurl);
 //echo "helloworld";
//class WxPayNotify extends WxPayNotifyReply
$config = new WxPayConfig();
$notify = new PayNotifyCallBack();
$notify->Handle($config, false);

//$notify = new PayNotifyCallBack();
 
//$notify->Handle(false);
