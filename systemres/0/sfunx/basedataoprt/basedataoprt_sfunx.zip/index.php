<?php
function dataeditacc($dbmarkx,$tabnmx,$tbsnox,$askuidx,$askrids,$oprtway){
  $dinfo=array();
  $dinfo=takedbinfo($dbmarkx,$tabnmx,$dinfo);
  $dfip=$dinfo["fip"];
  $dfuser=$dinfo["fuser"];
  $dfpass=$dinfo["fpass"];
  $dfbase=$dinfo["fbase"];
  $ickey=$dinfo["ickey"];
  $iwkey=$dinfo["iwkey"];
  $pssno=$dinfo["pssno"];
  $akeys=$dinfo["akeys"];
  if ($dbmarkx=="thishostcore"){
   $crtorx=UX("select ".$ickey." as result from ".$tabnmx." where ".$pssno."=".$tbsnox);     
   $vrtx=UX("select VRT as result from ".$tabnmx." where ".$pssno."=".$tbsnox);     
  }else{
   $conn=mysql_connect($dfip,$dfuser,$dfpass);
   $crtorx=updatings($conn,$dfbase,"select ".$ickey." as result from ".$tabnmx." where ".$pssno."=".$tbsnox,"utf8");
   $conn=mysql_connect($dfip,$dfuser,$dfpass);
   $vrtx=updatings($conn,$dfbase,"select VRT as result from ".$tabnmx." where ".$pssno."=".$tbsnox,"utf8");
  }
  if ($vrtx=="locked"){
            if ($oprtway=="killitem"){
              return false;
            }else if($oprtway=="viewdata"){              
            }else{              
            } 
  }
 $acc=UX("select count(*) as result from coode_tabitemaccess where dbmark='".$dbmarkx."' and dbtabnm='".$tbnmx."' and dbtabsno='".$snox."' and askman='".$askuidx."' and accstt>0");
 //echo "crtorx-".$crtorx."---".$askuidx."/"."--".$acc."fxxx";
 if ($crtorx==$askuidx or intval($acc)>0  or $crtorx==""){
  if ($crtorx==""){
       if ($oprtway=="killitem"){        
          return true;        
       } else if ($oprtway=="viewdata"){
          return "*";
       }else{
          //echo "oprtway--".$oprtway."f--x";
          return "";
       }
  }
  if ($crtorx==$askuidx){
     $tacc=SX("select SNO,viewkeys,updatekeys,itemkill from coode_tabaccess where dbmark='".$dbmarkx."' and dbtabnm='".$tbnmx."' and accesscdt='1>0' and accessrole='everyone'");
     $totta=countresult($tacc);
     if (intval($totta)>0){
       $vkeys=anyvalue($tacc,"viewkeys",0);
       $updkeys=anyvalue($tacc,"updatekeys",0);
       $ikx=anyvalue($tacc,"itemkill",0);
       if ($oprtway=="killitem"){
         if (intval($ikx)==0){
          return true;
         }else{
          return false;
         }
       } else if ($oprtway=="viewdata"){
          return $vkeys;
       }else{
          //echo "oprtway--".$oprtway."f--x";
          return baohanwai($updkeys,$oprtway);
       }
     }else{//tota
      //如果不存在全局设定则直接可操作
       if ($oprtway=="killitem"){        
          return true;        
       } else if ($oprtway=="viewdata"){
          return "";
       }else{
          return "";
       }
     }//tota
  }else{//c=a
     $tacc=SX("select SNO,viewkeys,updatekeys,itemkill from coode_tabitemaccess where dbmark='".$dbmarkx."' and dbtabnm='".$tbnmx."' and dbtabsno='".$snox."' and askman='".$askuidx."' and accstt>0");
     $totta=countresult($tacc);
     if (intval($totta)>0){
       $vkeys=anyvalue($tacc,"viewkeys",0);
       $updkeys=anyvalue($tacc,"updatekeys",0);
       $ikx=anyvalue($tacc,"itemkill",0);
       if ($oprtway=="killitem"){
         if (intval($ikx)==0){
          return true;
         }else{
          return false;
         }
       } else if ($oprtway=="viewdata"){
          return $vkeys;
       }else{
          return baohanwai($updkeys,$oprtway);
       }      
     }else{//tota
       if ($oprtway=="killitem"){        
          return true;        
       } else if ($oprtway=="viewdata"){
          return "";
       }else{
          return "";
       }
     }//tota
  }//c=a
 }else{//c=a  a>0   
   $tmpa=0;
   $rrst=SX("select SNO,accesscdt,updatekeys,itemkill,accessrole,viewkeys,updatekeys,itemkill from coode_tabaccess where dbmark='".$dbmarkx."' and dbtabnm='".$tabnmx."' and 'xx-".$askrids."' like concat('%',accessrole,'%')");
   $totr=countresult($rrst);
   if (intval($totr)>0){
     $viewx="";
     $updx="";
     for ($aa=0;$aa<$totr;$aa++){
       $acccdt=anyvalue($rrst,"accesscdt",$aa);
       $accrole=anyvalue($rrst,"accessrole",$aa);
       $accviews=anyvalue($rrst,"viewkeys",$aa);
       $accupds=anyvalue($rrst,"updatekeys",$aa);
       $acckill=anyvalue($rrst,"itemkill",$aa);
        if ($dbmarkx=="thishostcore"){
          $extitem=UX("select count(*) as result from ".$tabnmx." where ".$acccdt." and ".$pssno."=".$tbsnox);
          if (intval($extitem)>0){            
            if ($oprtway=="killitem"){
             if (intval($acckill)==0){
               $tmpa=$tmpa+1;
             }
            }else if($oprtway=="viewdata"){
              $viewx=$viewx.$accviews.",";
              $tmpa=$tmpa+1;
            }else{
              $updx=$updx.$accupds.",";
              $tmpa=$tmpa+1;
            }                                    
          }
        }else{
          $conn=mysql_connect($dfip,$dfuser,$dfpass);
          $extitem=updatings($conn,$dfbase,"select count(*) as result from ".$tabnmx." where ".$acccdt." and ".$pssno."=".$tbsnox,"utf8");
          if (intval($extitem)>0){            
            if ($oprtway=="killitem"){
             if (intval($acckill)==0){
               $tmpa=$tmpa+1;
             }
            }else if($oprtway=="viewdata"){
              $viewx=$viewx.$accviews.",";
              $tmpa=$tmpa+1;
            }else{
              $updx=$updx.$accupds.",";
              $tmpa=$tmpa+1;
            }                                    
          }
        }//dbmarkx=thiscore
     }//foraa     
    }//if totr
    
    if ($tmpa>0){
            if ($oprtway=="killitem"){
              return true;
            }else if($oprtway=="viewdata"){
              return onlyone($viewx);
            }else{
              return baohanwai($updx,$oprtway);
            }       
    }else{//tmpa
       $tmpb=0;
       $tmpc=0;
       $brst=SX("select SNO,accesscdt,accessrole,updatekeys,itemkill from coode_tabaccess where dbmark='".$dbmarkx."' and dbtabnm='".$tabnmx."'");
       $totrx=countresult($brst);
       for ($bb=0;$bb<$totrx;$bb++){
          $snox=anyvalue($brst,"SNO",$bb);
          $acccdt=anyvalue($brst,"accesscdt",$bb);
          $accrole=anyvalue($brst,"accessrole",$bb);
          $upkeys=anyvalue($brst,"updatekeys",$bb);
          $itemkill=anyvalue($brst,"itemkill",$bb);
          if ($dbmarkx=="thishostcore"){
            $extitem=UX("select count(*) as result from ".$tabnmx." where ".$acccdt." and ".$pssno."=".$tbsnox);
            if (intval($extitem)>0){
              $extqx=UX("select count(*) as result from coode_tabitemaccess where dbmark='".$dbmarkx."' and dbtabnm='".$tbnmx."' and dbtabsno='".$snox."' and askman='".$askuidx."' and auditrole='".$accrole."'");
              if (intval($extqx)==0){
                $tmpb=$tmpb+1;
                $acctitle=$askuidx."向".$accrole."申请操作".$dbmarkx."-".$tabnmx."的权限";
                $sqlx="allkeys,accmark,acctitle,dbmark,dbtabnm,dbtabsno,askman,infocrtor,infocid,auditrole,CRTM,UPTM,OLMK";
                $sqly="'".$akeys."','".getRandChar(8)."','".$acctitle."','".$dbmarkx."','".$tabnmx."','".$tbsnox."','".$askuidx."','','','".$accrole."',now(),now(),'".onlymark()."'";
                $zz=UX("insert into coode_tabitemaccess(".$sqlx.")values(".$sqly.")");
              }
            }
          }else{
            $conn=mysql_connect($dfip,$dfuser,$dfpass);
            $extitem=updatings($conn,$dfpass,"select count(*) as result from ".$tabnmx." where ".$acccdt." and ".$pssno."=".$tbsnox,"utf8");
            if (intval($extitem)>0){
              $extqx=UX("select count(*) as result from coode_tabitemaccess where dbmark='".$dbmarkx."' and dbtabnm='".$tbnmx."' and dbtabsno='".$snox."' and askman='".$askuidx."' and auditrole='".$accrole."'");
              if (intval($extqx)==0){
                $tmpb=$tmpb+1;
                $acctitle=$askuidx."向".$accrole."申请操作".$dbmarkx."-".$tabnmx."的权限";
                $sqlx="allkeys,accmark,acctitle,dbmark,dbtabnm,dbtabsno,askman,infocrtor,infocid,auditrole,CRTM,UPTM,OLMK";
                $sqly="'".$akeys."','".getRandChar(8)."','".$acctitle."','".$dbmarkx."','".$tabnmx."','".$tbsnox."','".$askuidx."','','','".$accrole."',now(),now(),'".onlymark()."'";
                $zz=UX("insert into coode_tabitemaccess(".$sqlx.")values(".$sqly.")");
              }
            }
          }//if dbmarkx
          
        }//forb              
              $extqx=UX("select count(*) as result from coode_tabitemaccess where dbmark='".$dbmarkx."' and dbtabnm='".$tbnmx."' and dbtabsno='".$snox."' and askman='".$askuidx."' and infocrtor='".$crtorx."'");
             if (intval($extqx)==0){
              $acctitle=$askuidx."向".$accrole."申请操作".$dbmarkx."-".$tabnmx."的权限";
              $sqlx="allkeys,accmark,acctitle,dbmark,dbtabnm,dbtabsno,askman,infocrtor,infocid,auditrole,CRTM,UPTM,OLMK";
              $sqly="'".$akeys."','".getRandChar(8)."','".$acctitle."','".$dbmarkx."','".$tabnmx."','".$tbsnox."','".$askuidx."','".$crtorx."','','',now(),now(),'".onlymark()."'";
              $zz=UX("insert into coode_tabitemaccess(".$sqlx.")values(".$sqly.")");
              
             }
            if ($oprtway=="killitem"){
              return false;
            }else if($oprtway=="viewdata"){
              return "asktorole";
            }else{
              return "asktorole";
            }       
    }//if tmpa
 }//if c=a  a>0
 
}//fun
function makeinsert($tabnm,$istdata=array(),$olmkkey){
   eval(RESFUNSET("picpick"));
   if (dftval($_POST["p_".$olmkkey.$_GET["SNO"]],$_POST["p_".$olmkkey])=="" ){
       $olmkx=onlymark();
   }else{
       $olmkx=dftval($_POST["p_".$olmkkey.$_GET["SNO"]],$_POST["p_".$olmkkey]);
   }
   $olmkzz=$olmkx;
   if (count($istdata)>0 and $tabnm!=""){
       $istkx=array_keys($istdata);
       $fmkx="";
       $fmvx="";
       switch($olmkkey){
         case "OLMK":
         $extk="CRTM,UPTM,CRTOR,OLMK,RIP";
         $extv="now(),now(),'".$_COOKIE["uid"]."','".$olmkx."','".getip()."'";
         break;
         case "itemOnlyMark":
         $extk="itemCTime,itemUTime,itemCrtID,itemOnlyMark,itemAccMark";
         $extv="now(),now(),'".$_COOKIE["uid"]."','".$olmkx."','".getip()."'";
         break;
         default:
         $extk="";
         $extv="";
       }
       
       $ainfo=array();
       $ainfo=getdbact(glb(),$tabnm,$ainfo);
       $binfo=array();
       $binfo=gettabinfo(glb(),$tabnm,$binfo);
       for ($bx=0;$bx<count($istkx);$bx++){
           $kx=$istkx[$bx];
           $vx=$istdata[$kx];
           if ($kx==$binfo["srckey"]){
               $srcval=$vx;
           }
           if ($kx!="SNO"  and $kx!="OLMK" and $kx!="DFROM" and $kx!="CRTM" and $kx!="UPTM"  and $kx!="CRTOR" and $kx!="RIP"  and $kx!="VRT"  and $kx!="STCODE" and $kx!="STATUS" and $kx!="PRIME"  and $kx!="OPRT"  and $kx!="sNo" and $kx!="itemCTime" and $kx!="itemUTime" and $kx!="itemPUTime" and $kx!="itemPVerMd5" and $kx!="itemCrtID" and $kx!="itemCtPos" and $kx!="itemCrtComID" and $kx!="itemAccMark" and $kx!="itemAffTable" and $kx!="itemCgAffairs" and $kx!="itemOnlyMark"  and $vx!="" and $kx!=$binfo["subsqx"]){
             $fmkx=$fmkx.$kx.",";
             if (strlen($vx)>200 or strpos($vx,huanhang())>0 ){       
               $fmvx=$fmvx."'".gohex($vx)."',";
             }else{
               $fmvx=$fmvx."'".str_replace("'","\\'",$vx)."',";    
             }
           }
       }
      
       if ($ainfo["bfist"]!=""){
           eval($ainfo["bfist"]);
       }
       
       $nist=UX("insert into ".$tabnm."(".$fmkx.$extk.")values(".$fmvx.$extv.")");
              
       if ($ainfo["aftist"]!=""){
           eval($ainfo["aftist"]);
       }
       $mx=clearvarlike($tabnm);
       $bbx=samedata("","",$tabnm);
       
       $extn=UX("select count(*) as result from ".$tabnm." where ".$olmkkey."='".$olmkzz."'");
       if (intval($extn)>0){
           $bbz=tabaffect("",$tabnm);
           $ccz=tabpicpick($tabnm,"0",$olmkx); 
           $clsrst=SX("select shortid,shorttitle from coode_shortdata where tablename='".$tabnm."' and dttp='clstxt'");
           $totcls=countresult($clsrst);
           for ($jj=0;$jj<$totcls;$jj++){
             $shtid=anyvalue($clsrst,"shortid",$jj);
             $dxrst=SX("select SNO,TABLE_NAME from coode_keydetailx where clstxt like '%".$shtid."%' group by TABLE_NAME");
             $totdx=countresult($dxrst);
             for ($kk=0;$kk<$totdx;$kk++){
               $ktabnm=anyvalue($dxrst,"TABLE_NAME",$kk);
               $zz=file_get_contents(combineurl("http://".glw(),"/localxres/funx/tabcol/?tablename=".$ktabnm."&cid=".$_COOKIE["cid"]."&uid=".$_COOKIE["uid"]));
             }
           }
            if ($binfo["md5key"]!="" and $binfo["md5key"]!=$binfo["mainsqx"]){
             $ddd=UX("update ".$tabnm." set ".$binfo["md5key"]."=md5(concat(".$binfo["ckeys"].")) where ".$olmkkey."='".$olmkzz."'");          
            }
           return true;
       }else{
           return false;
       }
   }else{
       return false;
   }
}
function makedbinsert($dbmk,$tabnm,$istdata=array(),$psomk){
   if (count($istdata)>0 and $tabnm!=""){
       $istkx=array_keys($istdata);
       $fmkx="";
       $fmvx="";
       if ($psomk=="OLMK"){
       }
       switch($psomk){
         case "OLMK":
         $extk=",CRTM,UPTM,CRTOR,OLMK";
         $extv=",now(),now(),'".$_COOKIE["uid"]."','".dftval($_POST["p_".$psomk."0"],$_POST["p_".$psomk])."'";
         break;
         case "itemOnlyMark":
         $extk=",itemCTime,itemUTime,itemCrtID,itemOnlyMark,itemAccMark";
         $extv=",now(),now(),'".$_COOKIE["uid"]."','".dftval($_POST["p_".$psomk."0"],$_POST["p_".$psomk])."','".getip()."'";
         break;
         default:
         $extk="";
         $extv="";
       }
       $dinfo=array();
       $dinfo=takedbinfo($dbmk,$tabnm,$dinfo);
       for ($bx=0;$bx<count($istkx);$bx++){
           $kx=$istkx[$bx];
           $vx=$istdata[$kx];
           if ($kx==$dinfo["pskey"]){
               $srcval=$vx;
           }
           if ($kx!="SNO"  and $kx!="OLMK" and $kx!="DFROM" and $kx!="CRTM" and $kx!="UPTM"  and $kx!="CRTOR" and $kx!="RIP"  and $kx!="VRT"  and $kx!="STCODE" and $kx!="STATUS" and $kx!="PRIME"  and $kx!="OPRT" and $vx!="" and $kx!=$pssno and $kx!="sNo" and $kx!="itemCTime" and $kx!="itemUTime" and $kx!="itemPUTime" and $kx!="itemPVerMd5" and $kx!="itemCrtID" and $kx!="itemCtPos" and $kx!="itemCrtComID" and $kx!="itemAccMark" and $kx!="itemAffTable" and $kx!="itemCgAffairs" and $kx!="itemOnlyMark"  and $kx!=$dinfo["subsqx"] and $kx!=$dinfo["mainsqx"]){
             $fmkx=$fmkx.$kx.",";
             if (strlen($vx)>200 or strpos($vx,huanhang())>0 ){
               $fmvx=$fmvx."'".gohex($vx)."',";
             }else{
               $fmvx=$fmvx."'".str_replace("'","\\'",$vx)."',";  
             }
           }
       }
       $fmkx=killlaststr($fmkx);
       $fmvx=killlaststr($fmvx);
       $ainfo=array();
       $ainfo=getdbact($dbmk,$tabnm,$ainfo);
       if ($ainfo["bfist"]!=""){
           eval($ainfo["bfist"]);
       }
       $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
       $nist=updatingx($conn,$dinfo["fbase"],"insert into ".$tabnm."(".$fmkx.$extk.")values(".$fmvx.$extv.")","utf8");
       
       //上面这一行就是数据增加操作
       if ($ainfo["aftist"]!=""){
           eval($ainfo["aftist"]);
       }
       $mx=clearvarlike($tabnm);
       $bbx=samedata("","",$tabnm);
       $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
       $extn=updatingx($conn,$dinfo["fbase"],"select count(*) as result from ".$tabnm." where ".$psomk."='".dftval($_POST["p_".$psomk."0"],$_POST["p_".$psomk])."'","utf8");
       if (intval($extn)>0){
             $clsrst=SX("select shortid,shorttitle from coode_shortdata where tablename='".$tabnm."' and dttp='clstxt'");
             $totcls=countresult($clsrst);
             for ($jj=0;$jj<$totcls;$jj++){
               $shtid=anyvalue($clsrst,"shortid",$jj);
               $dxrst=SX("select SNO,TABLE_NAME from coode_keydetailx where clstxt like '%".$shtid."%' group by TABLE_NAME");
               $totdx=countresult($dxrst);
               for ($kk=0;$kk<$totdx;$kk++){
                 $ktabnm=anyvalue($dxrst,"TABLE_NAME",$kk);
                 $lrst=SX("select shortid,shorttitle from coode_shortdata where tablename='".$ktabnm."' and dttp!='clstxt'");
                 $totl=countresult($lrst);
                 for ($ll=0;$ll<$totl;$ll++){
                   $lstid=anyvalue($lrst,"shortid",$ll);
                   $zz=file_get_contents(combineurl("http://".glw(),"/localxres/funx/shortdft/?shortid=".$lstid."&cid=".$_COOKIE["cid"]."&uid=".$_COOKIE["uid"]));                 
                 }
                 
               }
             }
          // $bbz=tabaffect("",$tabnm);
           // $ccz=tabpicpick($tabnm,"0",dftval($_POST["p_".$psomk."0"],$_POST["p_".$psomk]));           
            if ($binfo["md5key"]!="" and $binfo["md5key"]!=$binfo["mainsqx"]){
             $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
             $ddd=updatingx($conn,$dinfo["fbase"],"update ".$tabnm." set ".$binfo["md5key"]."=md5(concat(".$binfo["ckeys"].")) where ".$psomk."='".dftval($_POST["p_".$psomk."0"],$_POST["p_".$psomk])."'","utf8");          
            }
           return true;
       }else{
           return false;
       }
       
   }else{
       return false;
   }
}
function makeupdate($tabnm,$istdata=array(),$olmkx,$olmkkey){
   eval(RESFUNSET("picpick"));
   if (count($istdata)>0 and $tabnm!=""){
       $istkx=array_keys($istdata);
       $fmsqlx="";
       $fmsqly="";
       $fmsqla="";
       $fmsqlb="";
       $updkx="";
       for ($bx=0;$bx<count($istkx);$bx++){
          $kx=$istkx[$bx];
          $updkx=$updkx.$kx.",";
       }
       $updkx=killlaststr($updkx);
       $tbsnok=UX("select mainsqx as result from coode_tablist where TABLE_NAME='".$tabnm."'");        
       $tbsnox=UX("select ".$tbsnok." as result  from ".$tabnm." where ".$olmkkey."='".$olmkx."'");
       
       $dnkey=dataeditacc("thishostcore",$tabnm,$tbsnox,$_COOKIE["uid"],$_COOKIE["rids"],$updkx);
       for ($bx=0;$bx<count($istkx);$bx++){
           $kx=$istkx[$bx];
           $vx=$istdata[$kx];
           if ($kx!="OLMK" and $kx!="SNO" and $kx!="sNo" and $kx!=$tbsnok   and $kx!="itemOnlyMark"  and $vx!="" ){
            if ($dnkey==""){
              if ($vx==" " or $vx=="."){
                $vx="";
              }
              if (strlen($vx)>200 or strpos($vx,huanhang())>0 ){ 
                $fmsqlx=$fmsqlx.$kx."='".gohex($vx)."',";
                $fmsqly=$fmsqly." and ".$kx."='".gohex($vx)."' ";
              }else{
                $fmsqlx=$fmsqlx.$kx."='".str_replace("'","\\'",$vx)."',";  
                $fmsqly=$fmsqly." and ".$kx."='".str_replace("'","\\'",$vx)."' ";
              }                        
             }else if ($dnkey=="asktorole"){
             }else{
               if (strpos("xx-,".$dnkey.",",",".$kx.",")>0){
             
               }else{
                 if ($vx==" " or $vx=="."){
                   $vx="";
                 }
                 if (strlen($vx)>200 or strpos($vx,huanhang())>0 ){ 
                  $fmsqlx=$fmsqlx.$kx."='".gohex($vx)."',";
                  $fmsqly=$fmsqly." and ".$kx."='".gohex($vx)."' ";
                 }else{
                  $fmsqlx=$fmsqlx.$kx."='".str_replace("'","\\'",$vx)."',";  
                  $fmsqly=$fmsqly." and ".$kx."='".str_replace("'","\\'",$vx)."' ";
                 }  
               }//ifdnkey kx
           }//if dn==""
          }//olmk
       }//for
       
       //$fmsqly=substr($fmsqly,4,strlen($fmsqly)-4);
       $ainfo=array();
       $ainfo=getdbact(glb(),$tabnm,$ainfo);
       $fmsqlx=killlaststr($fmsqlx);
       $ext=1;
       
         $updstrx="update ".$tabnm." set ".$fmsqlx." where ".$olmkkey."='".$olmkx."'";
         $ucdtx=$olmkkey."='".$olmkx."'";
             
         if ($ainfo["bfupd"]!=""){
           eval($ainfo["bfupd"]);
         }
         
         $mx=clearvarlike($tabnm);
         
         if (intval($ext)>0){
             //echo $updstrx;
            if ($fmsqlx!=""){
             $nupd0=UX($updstrx);//核心修改update 使用OLMK作为数据定位依             
            }
            if ($olmkkey=="OLMK"){
              $nupd1=UX("update ".$tabnm." set UPTM=now() where OLMK='".$olmkx."'");
            }else{
              $nupd1=UX("update ".$tabnm." set itemUTime=now() where itemOnlyMark='".$olmkx."'");
            }
            if ($ainfo["aftupd"]!=""){
              eval($ainfo["aftupd"]);
            }
            $bbx=samedata("","",$tabnm);
            
            $extn=UX("select count(*) as result from ".$tabnm." where ".$olmkkey."='".$olmkx."' ".$fmsqly);
            
            if (intval($extn)>0 and $fmsqlx!=""){
             $clsrst=SX("select shortid,shorttitle from coode_shortdata where tablename='".$tabnm."' and dttp='clstxt'");
             $totcls=countresult($clsrst);
             for ($jj=0;$jj<$totcls;$jj++){
               $shtid=anyvalue($clsrst,"shortid",$jj);
               $dxrst=SX("select SNO,TABLE_NAME from coode_keydetailx where clstxt like '%".$shtid."%' group by TABLE_NAME");
               $totdx=countresult($dxrst);
               for ($kk=0;$kk<$totdx;$kk++){
                 $ktabnm=anyvalue($dxrst,"TABLE_NAME",$kk);
                 $lrst=SX("select shortid,shorttitle from coode_shortdata where tablename='".$ktabnm."' and dttp!='clstxt'");
                 $totl=countresult($lrst);
                 for ($ll=0;$ll<$totl;$ll++){
                   $lstid=anyvalue($lrst,"shortid",$ll);
                   $zz=file_get_contents(combineurl("http://".glw(),"/localxres/funx/shortdft/?shortid=".$lstid."&cid=".$_COOKIE["cid"]."&uid=".$_COOKIE["uid"]));                 
                 }
                 
               }
             }
             $bbz=tabaffect("",$tabnm);
             $ccz=tabpicpick($tabnm,"0",$olmkx);
             return true;
            }else{
             return false;
            }
          }else{
            return false;     
          }
      
   }else{
       return false;
   }
}
function makerefresh($tabnm,$istdata=array(),$snox){
    eval(RESFUNSET("picpick"));       
    //var_dump($istdata);
    //echo $tabnm;
    //echo count($istdata);
   if (count($istdata)>0 and $tabnm!=""){
       $istkx=array_keys($istdata);
       $fmsqlx="";
       $fmsqly="";
       $fmsqla="";
       $fmsqlb="";
       
       $binfo=array();
       $binfo=gettabinfo(glb(),$tabnm,$binfo);
       //var_dump($binfo);
       //var_dump($istkx);
       $tabnamex=$tabnm;
       $updkx="";
       for ($bx=0;$bx<count($istkx);$bx++){
          $kx=$istkx[$bx];
          $updkx=$updkx.$kx.",";
       }
       $updkx=killlaststr($updkx);
       $dnkey=dataeditacc("thishostcore",$tabnm,$snox,$_COOKIE["uid"],$_COOKIE["rids"],$updkx);       
       //echo "dnkey-".$dnkey."@";
       for ($bx=0;$bx<count($istkx);$bx++){
           $kx=$istkx[$bx];
           $vx=$istdata[$kx];           
           //echo $kx."--".$vx."@@";
           if ($kx!="SNO"  and $kx!="OLMK"  and $kx!="SNO" and $kx!="sNo" and $kx!=$binfo["mainsqx"]  and $kx!=$pssno and $kx!="sNo" and  $kx!="itemOnlyMark"  and $vx!="" ){
           //echo "dnke---".$dnkey;
             if ($dnkey==""){
               if ($vx==" " or $vx=="  " or $vx=="."){
                 $vx="";
               }
               if (strlen($vx)>200 or strpos($vx,huanhang())>0 ){ 
                 $fmsqlx=$fmsqlx.$kx."='".gohex($vx)."',";
                 $fmsqly=$fmsqly." and ".$kx."='".gohex($vx)."' ";
               }else{
                 $fmsqlx=$fmsqlx.$kx."='".str_replace("'","\\'",$vx)."',";  
                 $fmsqly=$fmsqly." and ".$kx."='".str_replace("'","\\'",$vx)."' ";
               }
             }else if ($dnkey=="asktorole"){
             }else{
               if (strpos("xx-,".$dnkey.",",",".$kx.",")>0){
             
               }else{
                 if ($vx==" " or $vx=="."){
                   $vx="";
                 }
                 if (strlen($vx)>200 or strpos($vx,huanhang())>0 ){ 
                  $fmsqlx=$fmsqlx.$kx."='".gohex($vx)."',";
                  $fmsqly=$fmsqly." and ".$kx."='".gohex($vx)."' ";
                 }else{
                  $fmsqlx=$fmsqlx.$kx."='".str_replace("'","\\'",$vx)."',";  
                  $fmsqly=$fmsqly." and ".$kx."='".str_replace("'","\\'",$vx)."' ";
                 }  
               }//ifdnkey kx
            }//if dn==""
           }//kx SNO
           
       }
       $fmsqly=substr($fmsqly,4,strlen($fmsqly)-4);
       $ainfo=array();
       $ainfo=getdbact(glb(),$tabnm,$ainfo);
       $fmsqlx=killlaststr($fmsqlx);
       $ext=1;      
        if ($ainfo["bfupd"]!=""){
           eval ($ainfo["bfupd"]);
        }    
        //echo $fmsqlx;
        //echo "ext-".$ext."@@";
        if (intval($ext)>0){
         //核心修改refresh 使用sno作为数据定位依据         
         if ($fmsqlx!=""){
           $nupd0=UX("update ".$tabnamex." set ".$fmsqlx." where ".$binfo["mainsqx"]."='".$snox."'");
           //echo "update ".$tabnamex." set ".$fmsqlx." where ".$binfo["mainsqx"]."='".$snox."'";
         }else{
           //echo "mediyou";
         }
         if ($tabnamex!="coode_tiny" and $tabnamex!="coode_tablist" and $tabnamex!="coode_shortdata" and $tabnamex!="coode_keydetailx" and $tabnamex!="coode_keydetaily" and $tabnamex!="coode_keydetailz"){
           $nupd0=UX("update ".$tabnamex." set PRIME=1 where ".$binfo["mainsqx"]."='".$snox."'");
           $nupd00=UX("update ".$tabnamex." set itemCtPos=1 where ".$binfo["mainsqx"]."='".$snox."'");
         }
         $nupd1=UX("update ".$tabnamex." set UPTM=now() where ".$binfo["mainsqx"]."='".$snox."'");
         $nupd2=UX("update ".$tabnamex." set itemUTime=now() where ".$binfo["mainsqx"]."='".$snox."'");         
         if ($ainfo["aftupd"]!=""){
            eval($ainfo["aftupd"]);
         }
         $mx=clearvarlike($tabnm);
         $bbx=samedata("","",$tabnamex);
         $extn=UX("select count(*) as result from ".$tabnamex." where ".$binfo["mainsqx"]."='".$snox."' ");
          if (intval($extn)>0 and $fmsqlx!=""){
              //$bbz=tabaffect("",$tabnamex);
              //$ccz=tabpicpick($tabnamex,$snox,"");
             $clsrst=SX("select shortid,shorttitle from coode_shortdata where tablename='".$tabnamex."' and dttp='clstxt'");
             $totcls=countresult($clsrst);
             for ($jj=0;$jj<$totcls;$jj++){
               $shtid=anyvalue($clsrst,"shortid",$jj);
               $dxrst=SX("select SNO,TABLE_NAME from coode_keydetailx where clstxt like '%".$shtid."%' group by TABLE_NAME");
               $totdx=countresult($dxrst);
               for ($kk=0;$kk<$totdx;$kk++){
                 $ktabnm=anyvalue($dxrst,"TABLE_NAME",$kk);
                 $zz=file_get_contents(combineurl("http://".glw(),"/localxres/funx/tabcol/?tablename=".$ktabnm."&cid=".$_COOKIE["cid"]."&uid=".$_COOKIE["uid"]));
                 $exrst=SX("select SNO,shortid from coode_shortdata where tablename='".$ktabnm."' and dttp!='clstxt'");
                 $totex=countresult($exrst);
                 for ($m=0;$m<$totex;$m++){
                  $shortid=anyvalue($exrst,"shortid",$m);
                  $zz=file_get_contents(combineurl("http://".glw(),"/localxres/funx/shortdft/?shortid=".$shortid."&cid=".$_COOKIE["cid"]."&uid=".$_COOKIE["uid"]));
                  $zz1=file_get_contents(combineurl("http://".glw(),"/localxres/funx/shortcol/?shortid=".$shortid."&cid=".$_COOKIE["cid"]."&uid=".$_COOKIE["uid"]));
                 }
               }
             }
            return true;
          }else{
            return false;
          }        
        }else{
          //echo "extiszero";
        }//ext
      
   }else{
       return false;
   }
}
function makedbrefresh($dbmk,$tabnm,$istdata=array(),$pssno,$snox){
     if (count($istdata)>0 and $tabnm!=""){
       $istkx=array_keys($istdata);
       $fmsqlx="";
       $fmsqly="";
       //var_dump($istdata);
       $dinfo=array();
       $dinfo=takedbinfo($dbmk,$tabnm,$dinfo);
       for ($bx=0;$bx<count($istkx);$bx++){
           $kx=$istkx[$bx];
           $vx=$istdata[$kx];
           if ($kx!="SNO"  and $kx!="OLMK" and $kx!="DFROM" and $kx!="CRTM" and $kx!="UPTM"  and $kx!="CRTOR" and $kx!="RIP"  and $kx!="VRT"  and $kx!="STCODE" and $kx!="STATUS" and $kx!="PRIME"  and $kx!="OPRT" and $kx!="sNo"  and $kx!=$pssno and $kx!="itemCTime" and $kx!="itemUTime" and $kx!="itemPUTime" and $kx!="itemPVerMd5" and $kx!="itemCrtID" and $kx!="itemCtPos" and $kx!="itemCrtComID" and $kx!="itemAccMark" and $kx!="itemAffTable" and $kx!="itemCgAffairs" and $kx!="itemOnlyMark"  and $vx!=""  and strpos($dnkeys,",".$kx.",")<=0){
             if ($vx==" " or $vx=="."){
                $vx="";
             }
             if (strlen($vx)>200 or strpos($vx,huanhang())>0 ){ 
               $fmsqlx=$fmsqlx.$kx."='".gohex(str_replace("'","\\'",$vx))."',";
             }else{
               $fmsqlx=$fmsqlx.$kx."='".str_replace("'","\\'",$vx)."',";                 
             }
             $fmsqly=$fmsqly." and ".$kx."='".str_replace("'","\\'",$vx)."' ";
           }
       }
       //$fmsqly=substr($fmsqly,4,strlen($fmsqly)-4);
       $fmsqlx=killlaststr($fmsqlx);
       $ainfo=array();
       $ainfo=getdbact($dbmk,$tabnm,$ainfo);
       $ext=1;
       if ($ainfo["bfupd"]!=""){
           eval($ainfo["bfupd"]);
       }
       if (intval($ext)>0){
        $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);//更改脚本如下
        $nupd=updatingx($conn,$dinfo["fbase"],"update ".$tabnm." set ".$fmsqlx." where ".$pssno."='".$snox."'","utf8");
       // echo "update ".$tabnm." set ".$fmsqlx." where ".$pssno."='".$snox."'";
         if ($ainfo["aftupd"]!=""){
           eval($ainfo["aftupd"]);
         }
         $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
         $extn=updatingx($conn,$dinfo["fbase"],"select count(*) as result from ".$tabnm." where ".$pssno."='".$snox."' ".$fmsqly,"utf8");
         if (intval($extn)>0){
           $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
           $ddd=updatingx($conn,$dinfo["fbase"],"update ".$tabnm." set ".$dinfo["md5key"]."=md5(concat(".$dinfo["ckeys"].")) where ".$dinfo["mainsqx"]."=".$snox,"utf8");
           return true;
         }else{
           return false;
         }
       }else{
           return false;
       }
    }else{
         return false;
    }
}

?>