<?php
function makeselect($opname,$opvalue,$prevalue,$selectselfname,$selectselfclass,$htmcod,$hcange){
 $smd5="a".md5($opname.$opvalue.$prevalue.$selectselfname.$selectselfclass.$htmcod);
 $ssvalue=$_SESSION[$smd5];
 if ($ssvalue!=""){
   return $ssvalue;
 }else{
  $partopname=explode(",",$opname);
  $partopvalue=explode(",",$opvalue);
  $totopnm=count($partopname);
  $totopvl=count($partopvalue);
  $sfxz=0;
  $formselects="";
  $onlyone="";
  if ($totopnm==$totopvl){
   $formselects=$formselects."<SELECT id=\"".$selectselfname."\" name=\"".$selectselfname."\" ".$htmcod." onchange=\"".$hcange."\">\r\n";
   for ($tempk=0;$tempk<=$totopnm-1;$tempk++){
      if ($partopvalue[$tempk]==$prevalue || $partopname[$tempk]==$prevalue) {
       $sfxz=$sfxz+1;  
       $formselects=$formselects."<option value=\"".$partopvalue[$tempk]."\" selected>".$partopname[$tempk]."</option>\r\n";
       $onlyone=$partopname[$tempk];
       }
      else{
        if  ($selectselfclass=="readonly"){
        }else{
          $formselects=$formselects."<option value=\"".$partopvalue[$tempk]."\" >".$partopname[$tempk]."</option>\r\n";         
        };  
       };
    };
    if  ($selectselfclass=="readonly"){
       $formselects=$prevalue;//$formselects."</SELECT>"
    }else{
       $formselects=$formselects."</SELECT>\r\n";
    }
  };
   $_SESSION[$smd5]=$formselects;
  return $formselects;
 };
}
function makeselectx($opname,$opvalue,$prevalue,$selectselfname,$selectselfclass,$htmcod,$hcange){
 $smd5="a".md5($opname.$opvalue.$prevalue.$selectselfname.$selectselfclass.$htmcod);
 $ssvalue=$_SESSION[$smd5];
 if ($ssvalue!=""){
   return $ssvalue;
 }else{
  $partopname=explode(",",$opname);
  $partopvalue=explode(",",$opvalue);
  $totopnm=count($partopname);
  $totopvl=count($partopvalue);
  $sfxz=0;
  $formselects="";
  $onlyone="";
  if ($totopnm==$totopvl){
   $formselects=$formselects."<SELECT id=\"".$selectselfname."\" name=\"".$selectselfname."\" ".$htmcod." multiple=\"multiple\" onchange=\"".$hcange."\">\r\n";
   for ($tempk=0;$tempk<=$totopnm-1;$tempk++){
      if ($partopvalue[$tempk]==$prevalue || $partopname[$tempk]==$prevalue) {
       $sfxz=$sfxz+1;  
       $formselects=$formselects."<option value=\"".$partopvalue[$tempk]."\" selected>".$partopname[$tempk]."</option>\r\n";
       $onlyone=$partopname[$tempk];
       }
      else{
        if  ($selectselfclass=="readonly"){
        }else{
          $formselects=$formselects."<option value=\"".$partopvalue[$tempk]."\" >".$partopname[$tempk]."</option>\r\n";         
        };  
       };
    };
    if ($sfxz==0 and $prevalue!=""){
       $formselects=$formselects."<option value=\"".$prevalue."\" selected>".$prevalue."</option>"; 
    }
    if  ($selectselfclass=="readonly"){
       $formselects=$prevalue;//$formselects."</SELECT>"
    }else{
       $formselects=$formselects."</SELECT>\r\n";
    }
  };
   $_SESSION[$smd5]=$formselects;
  return $formselects;
 };
}
function formselect($opname,$opvalue,$prevalue,$selectselfname,$selectselfclass,$htmcod){
 $smd5="a".md5($opname.$opvalue.$prevalue.$selectselfname.$selectselfclass.$htmcod);
 $ssvalue=$_SESSION[$smd5];
 if ($ssvalue!=""){
   return $ssvalue;
 }else{
  $partopname=explode(",",$opname);
  $partopvalue=explode(",",$opvalue);
  $totopnm=count($partopname);
  $totopvl=count($partopvalue);
  $sfxz=0;
  $formselects="";
  $onlyone="";
  if ($totopnm==$totopvl){
    if (strpos($htmcod,"nchange")>0){
     $lf=" lay-filter=\"brickType\" ";
   }else{
     $lf="";
   }
   $formselects=$formselects."<SELECT id=\"".$selectselfname."\" name=\"".$selectselfname."\" ".$htmcod.$lf." lay-search class=\"".$selectselfclass."\">\r\n";
   $formselects=$formselects."<option value=\".\" >无选项</option>\r\n";         
   for ($tempk=0;$tempk<=$totopnm-1;$tempk++){
      if ($partopvalue[$tempk]==$prevalue || $partopname[$tempk]==$prevalue) {
       $sfxz=$sfxz+1;  
       $formselects=$formselects."<option value=\"".$partopvalue[$tempk]."\" selected>".$partopname[$tempk]."</option>\r\n";
       $onlyone=$partopname[$tempk];
      }else{
       $formselects=$formselects."<option value=\"".$partopvalue[$tempk]."\" >".$partopname[$tempk]."</option>\r\n";         
      };
    };
    if ($sfxz==0 and $prevalue!=""){
       $formselects=$formselects."<option value=\"".$prevalue."\" selected>".$prevalue."</option>"; 
    }
   $formselects=$formselects."</SELECT>\r\n";
  };
   $_SESSION[$smd5]=$formselects;
  return $formselects;
 };
}
function formselectonly($opname,$opvalue,$prevalue,$selectselfname,$selectselfclass,$htmcod){
 $smd5="a".md5($opname.$opvalue.$prevalue.$selectselfname.$selectselfclass.$htmcod);
 $ssvalue=$_SESSION[$smd5];
 if ($ssvalue!=""){
   return $ssvalue;
 }else{
  $partopname=explode(",",$opname);
  $partopvalue=explode(",",$opvalue);
  $totopnm=count($partopname);
  $totopvl=count($partopvalue);
  $sfxz=0;
  $formselects="";
  $onlyone="";
  if ($totopnm==$totopvl){
    if (strpos($htmcod,"nchange")>0){
     $lf=" lay-filter=\"brickType\" ";
   }else{
     $lf="";
   }
   $formselects=$formselects."<SELECT id=\"".$selectselfname."\" name=\"".$selectselfname."\" ".$htmcod.$lf." lay-search class=\"".$selectselfclass."\">\r\n";
   for ($tempk=0;$tempk<=$totopnm-1;$tempk++){
      if ($partopvalue[$tempk]==$prevalue || $partopname[$tempk]==$prevalue) {
       $sfxz=$sfxz+1;  
       $formselects=$formselects."<option value=\"".$partopvalue[$tempk]."\" selected>".$partopname[$tempk]."</option>\r\n";
       $onlyone=$partopname[$tempk];
      };
    };
    if ($sfxz==0 and $prevalue!=""){
       $formselects=$formselects."<option value=\"".$prevalue."\" selected>".$prevalue."</option>"; 
    }
     $formselects=$formselects."</SELECT>\r\n";
  };
   $_SESSION[$smd5]=$formselects;
  return $formselects;
 };
}
function formselectb($opname,$opvalue,$prevalue,$selectselfname,$selectselfclass,$htmcod){
 $smd5="b".md5($opname.$opvalue.$prevalue.$selectselfname.$selectselfclass.$htmcod);
 $ssvalue=$_SESSION[$smd5];
 if ($ssvalue!=""){
   return $ssvalue;
 }else{
  $partopname=explode(",",$opname);
  $partopvalue=explode(",",$opvalue);
  $totopnm=count($partopname);
  $totopvl=count($partopvalue);
  $sfxz=0;
  $formselects="";
  $onlyone="";
  
  if ($totopnm==$totopvl){
    if (strpos($htmcod,"nchange")>0){
     $lf=" lay-filter=\"brickType\" ";
   }else{
     $lf="";
   }
   $formselects=$formselects."<SELECT id=\"".$selectselfname."\" name=\"".$selectselfname."\" ".$htmcod.$lf." lay-search class=\"".$selectselfclass."\">";
     $formselects=$formselects."<option value=\".\" >无选项</option>";         
   for ($tempk=0;$tempk<=$totopnm-1;$tempk++){
      if ($partopvalue[$tempk]==$prevalue || $partopname[$tempk]==$prevalue) {
       $sfxz=$sfxz+1;  
       $formselects=$formselects."<option value=\"".$partopvalue[$tempk]."\" selected>".$partopname[$tempk]."</option>";
       $onlyone=$partopname[$tempk];
       }else{
          $formselects=$formselects."<option value=\"".$partopvalue[$tempk]."\" >".$partopname[$tempk]."</option>";
       };
    };
    if ($sfxz==0 and $prevalue!=""){
       $formselects=$formselects."<option value=\"".$prevalue."\" selected>".$prevalue."</option>"; 
    }
    $formselects=$formselects."</SELECT>";
  };
   $_SESSION[$smd5]=$formselects;
   return $formselects;
 };
}
function formselectbonly($opname,$opvalue,$prevalue,$selectselfname,$selectselfclass,$htmcod){
 $smd5="b".md5($opname.$opvalue.$prevalue.$selectselfname.$selectselfclass.$htmcod);
 $ssvalue=$_SESSION[$smd5];
 if ($ssvalue!=""){
   return $ssvalue;
 }else{
  $partopname=explode(",",$opname);
  $partopvalue=explode(",",$opvalue);
  $totopnm=count($partopname);
  $totopvl=count($partopvalue);
  $sfxz=0;
  $formselects="";
  $onlyone="";
  if ($totopnm==$totopvl){
    if (strpos($htmcod,"nchange")>0){
     $lf=" lay-filter=\"brickType\" ";
   }else{
     $lf="";
   }
   $formselects=$formselects."<SELECT id=\"".$selectselfname."\" name=\"".$selectselfname."\" ".$htmcod.$lf." lay-search class=\"".$selectselfclass."\">";
     $formselects=$formselects."<option value=\".\" >无选项</option>";         
    for ($tempk=0;$tempk<=$totopnm-1;$tempk++){
      if ($partopvalue[$tempk]==$prevalue || $partopname[$tempk]==$prevalue) {
        $sfxz=$sfxz+1;  
        $formselects=$formselects."<option value=\"".$partopvalue[$tempk]."\" selected>".$partopname[$tempk]."</option>";
        $onlyone=$partopname[$tempk];
       }
    };
    if ($sfxz==0 and $prevalue!=""){
       $formselects=$formselects."<option value=\"".$prevalue."\" selected>".$prevalue."</option>"; 
    }
    $formselects=$formselects."</SELECT>";
  };
   $_SESSION[$smd5]=$formselects;
   return $formselects;
 };
}
function formselectx($opname,$opvalue,$prevalue,$selectselfname,$selectselfclass,$htmcod){
 $smd5="a".md5($opname.$opvalue.$prevalue.$selectselfname.$selectselfclass.$htmcod);
 if ($_SESSION[$smd5]!=""){
   return $_SESSION[$smd5];
 }else{
  $partopname=explode(",","无选项,".$opname);
  $partopvalue=explode(",",".,".$opvalue);
  $totopnm=count($partopname);
  $totopvl=count($partopvalue);
  $sfxz=0;
  $formselects="\r\n";//<div class=\"container\">
  if ($totopnm==$totopvl){
   $formselects=$formselects."<select  name=\"sl".$selectselfname."\"  ".$htmcod." class=\"".$selectselfname."\" lay-ignore=\"1\"  style=\"float:right;width:0px;height:0px;\" multiple=\"multiple\">\r\n";
       $formselects=$formselects."<optgroup label=\"".$selectselfname."\"  >\r\n";
   for ($tempk=0;$tempk<=$totopnm-1;$tempk++) {
     if (strpos("xx-".$prevalue.",",$partopvalue[$tempk].",")>0) {
       $sfxz=$sfxz+1;  
       $formselects=$formselects."<option value=\"".$selectselfname."--".$partopvalue[$tempk]."\" selected >".$partopname[$tempk]."</option>\r\n";
       }else{
        $formselects=$formselects."<option value=\"".$selectselfname."--".$partopvalue[$tempk]."\"  >".$partopname[$tempk]."</option>\r\n";
       };
   };
       $formselects=$formselects."</optgroup>\r\n</select>\r\n";
 };
$tmpscpt='<script>
$(function() {        
        $(".'.$selectselfname.'").fSelect();
          $(".fs-option").click(function(){
        var xx=$("dd");
        totdd=xx.length;
        for (k=0;k<totdd;k++){
         tmpvvv=$(xx[k]).attr("lay-value");
         if (tmpvvv.indexOf("--")>0){
          $(xx[k]).parent().parent().hide();
         };
        };
         var slctx=$(".selected");
           totx=slctx.length;
            for (i=0;i<totx;i++){
             tmpvx="";
             tmpq="";
             tmpv="";
             tmpz="";
             tmpvx=$(slctx[i]).attr("data-value");
             tmpq=qian(tmpvx,"--");
             tmpv=hou(tmpvx,"--");
              eval(tmpq+"=\'\'");
            };
            for (i=0;i<totx;i++){
             tmpvx="";
             tmpq="";
             tmpv="";
             tmpz="";
             tmpvx=$(slctx[i]).attr("data-value");
             tmpq=qian(tmpvx,"--");
             tmpv=hou(tmpvx,"--");
             eval(tmpq+"="+tmpq+"+\'"+tmpv+",\';");
             eval("tmpz="+tmpq+";");
              $("#"+tmpq).val(onlyone(tmpz,\',\'));
            };
            var tmpcss=$(this).attr("class");
          tmpvb=$(this).attr("data-value");
          tmpbq=qian(tmpvb,"--");
          tmpbv=hou(tmpvb,"--");
            if (tmpcss.indexOf("selected")>0){
             eval(tmpbq+"="+tmpbq+".replace(\'"+tmpbv+",\',\'\');");
             eval(tmpbq+"="+tmpbq+".replace(\'"+tmpbv+",\',\'\');");
             eval("tmpz="+tmpbq);
             $("#"+tmpbq).val(onlyone(tmpz,\',\'));
             }else{
              eval("tpof=typeof("+tmpbq+");");
              if (tpof=="object"){
               eval(tmpbq+"=\'\';");
              }
             eval(tmpbq+"="+tmpbq+"+\'"+tmpbv+",\';");
             eval("tmpz="+tmpbq+";");
             $("#"+tmpbq).val(onlyone(tmpz,\',\'));
            };
      });
    });    
     </script>
';
   $_SESSION[$smd5]=$formselects."\r\n".$tmpscpt;
  return $formselects."\r\n".$tmpscpt;//</div>
 };//session
}
function qmselect($cltxt,$prev,$slid,$slcls,$hcd){
    if (strpos($cltxt,"|")>0){
        $qq=qian($cltxt,"|");
        $hh=hou($cltxt,"|");
        return formselect($qq,$hh,$prev,$slid,$slcls,$hcd);
    }else{
        if (strpos("x".$cltxt,"[")>0 or strpos("x".$cltxt,"{")>0){
            $cltxt=str_replace("[","",$cltxt);
            $cltxt=str_replace("]","",$cltxt);
            $cltxt=str_replace("{","",$cltxt);
            $cltxt=str_replace("}","",$cltxt);
            $qqhh=anyshort($cltxt,"","");
            $qq=qian($qqhh,"|");
            $hh=hou($qqhh,"|");
            return formselect($qq,$hh,$prev,$slid,$slcls,$hcd);
        }else{
            return "";
        }
    }
}
function fmradio($txtx,$selectselfname,$selectselfclass,$prev,$ckcode){
$choose="";
 if (strpos("x".$txtx,"|")>0){
   $kk=qian($txtx,"|");
   $pk=explode(",",$kk);
   $totpk=count($pk);
   $vv=hou($txtx,"|");
   $pv=explode(",",$vv);
   $fmiptx="";
  $choose="";
   if ($totpk<=5){
       $fmiptx=$fmiptx."<label id=\"".$selectselfname.$ii."\"><input name=\"".$selectselfname."\" type=\"radio\" class=\"".$selectselfclass."\" value=\"\">NONE</label>";
     for ($ii=0;$ii<$totpk;$ii++){
        if ($pv[$ii]==$prev){
         $fmiptx=$fmiptx."<!--radios--><label id=\"".$selectselfname.$ii."\"><input name=\"".$selectselfname."\" type=\"radio\" class=\"".$selectselfclass."\" checked ".$ckcode." value=\"".$pv[$ii]."\">".$pk[$ii]."</label><!--radioe-->";
        }else{
         $fmiptx=$fmiptx."<!--radios--><label id=\"".$selectselfname.$ii."\"><input name=\"".$selectselfname."\" type=\"radio\" class=\"".$selectselfclass."\"  ".$ckcode." value=\"".$pv[$ii]."\">".$pk[$ii]."</label><!--radioe-->";
        };
      };
   $choose=$fmiptx; 
   }else{
  
   };
   //小于等于5和大于5的
 };
 return $choose;
}
function fmcheck($txtx,$selectselfname,$selectselfclass,$prev,$ckcode){
 $choose="";
 if (strpos("x".$txtx,"/")>0){
   $kk=qian($txtx,"/");
   $pk=explode(",",$kk);
   $totpk=count($pk);
   $vv=hou($txtx,"/");
   $pv=explode(",",$vv);
   $fmiptx="";
   if ($totpk<=5){
      for ($ii=0;$ii<$totpk;$ii++){
         if (strpos(",".$prev.",",",".$pv[$ii].",")>0){
           $fmiptx=$fmiptx."<!--checkboxs--><label id=\"".$selectselfname.$ii."\"><input name=\"".$selectselfname."\" type=\"checkbox\" class=\"".$selectselfclass."\"  checked ".$ckcode." value=\"".$pv[$ii]."\">".$pk[$ii]."</label><!--checkboxe-->";
         }else{
           $fmiptx=$fmiptx."<!--checkboxs--><label id=\"".$selectselfname.$ii."\"><input name=\"".$selectselfname."\" type=\"checkbox\" class=\"".$selectselfclass."\" ".$ckcode." value=\"".$pv[$ii]."\">".$pk[$ii]."</label><!--checkboxe-->";
         };
      };
     $choose=$fmiptx; 
   };
  };
 return $choose;
}
function fmchoose($clstxtx,$prevalue,$selectselfname,$selectselfclass,$htmcod,$ckcod){
$choose="";
  if (strpos($clstxtx,"TYPE"."_HEX")>0){
    $clstxtx=Hex2String(hou($clstxtx,"TYP"."E_HEX:")); 
  };
  
 if (strpos("x".$clstxtx,"[")>0 or strpos("x".$clstxtx,"{")>0){
   if (strpos("x".$clstxtx,"[")>0){
     $mark=qian(hou("x".$clstxtx,"["),"]");
   }else{
     $mark=qian(hou("x".$clstxtx,"{"),"}");
   };
   //mark再细分,可以做联动,区分
   if (strpos($mark,"-")>0){
        $tmplike=hou($mark,"-");
        $mark=qian($mark,"-");
        $conn=mysql_connect(gl(),glu(),glp());
       if (strpos("x".$clstxtx,"[")>0){
          $tmpprv=hou($clstxtx,"]");
       }else{
         $tmpprv=hou($clstxtx,"}");
       };
       $rtn=anyshort($mark,$tmplike,$tmpprv);
   }else{
        $conn=mysql_connect(gl(),glu(),glp());
       $rtn=anyshort($mark,"","");
   };
   
   if (strpos("x".$clstxtx,"[")>0){
    $xx=formselect(qian($rtn,"|"),hou($rtn,"|"),$prevalue,$selectselfname,$selectselfclass,$htmcod);
   }else{
    $xx="<input type=\"hidden\" id=\"".$selectselfname."\">".formselectx(qian($rtn,"|"),hou($rtn,"|"),$prevalue,$selectselfname,$selectselfclass,$htmcod);
   };
 }else{//非引用
      if (strpos($clstxtx,"|")>0){
          $tmpis=1;
       $xx=formselect(qian($clstxtx,"|"),hou($clstxtx,"|"),$prevalue,$selectselfname,$selectselfclass,$htmcod);
      };       
      if (strpos($clstxtx,"/")>0){
          $tmpis=2;
       $xx="<input type=\"hidden\" id=\"".$selectselfname."\">".formselectx(qian($clstxtx,"/"),hou($clstxtx,"/"),$prevalue,$selectselfname,$selectselfclass,$htmcod);
      };       
 };
  return $xx;
}
?>