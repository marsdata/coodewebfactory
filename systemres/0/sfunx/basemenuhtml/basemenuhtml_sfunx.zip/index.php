<?php
function fmmymenu($mx=array(),$mnid,$clsid){
 $conn=mysql_connect(gl(),glu(),glp());
 $rst=selecteds($conn,glb(),"select myid,parid,mytitle,mymark,myurl,myclick,mydescrib from coode_plotmydetail where plotmark='".$mnid."'","utf8","");
 $totp=countresult($rst);
 $totq=countresult($rst);
 $totr=countresult($rst);
 $tots=countresult($rst);
  $fmdx="";
 $fmkv="";
  $ttp0=0;
 for ($p=0;$p<$totp;$p++){
  if ( anyvalue($rst,"parid",$p)=="0" or anyvalue($rst,"parid",$p)=="-1"){
   $fmkv=$fmkv."myid".$ttp0.":".$mnid.anyvalue($rst,"myid",$p)."#/#";
   $fmkv=$fmkv."myname".$ttp0.":".anyvalue($rst,"mymark",$p)."#/#";
   $fmkv=$fmkv."mytxt".$ttp0.":".anyvalue($rst,"mytitle",$p)."#/#";
   $fmkv=$fmkv."myurl".$ttp0.":".anyvalue($rst,"myurl",$p)."#/#";
   $fmkv=$fmkv."myclick".$ttp0.":".anyvalue($rst,"myclick",$p)."#/#";
    $fmkv=$fmkv."mydescrib".$ttp0.":".anyvalue($rst,"mydescrib",$p)."#/#";
    $fmkv=$fmkv."mylevel".$ttp0.":".($ttp0+1)."#/#";
   $fmkv=$fmkv."myclass".$ttp0.":".""."#/#";
   $ttp0=$ttp0+1;
   $fmdx=$fmdx."d(";  
   $lv1=anyvalue($rst,"myid",$p);
   $ttp1=0;
   for ($q=0;$q<$totq;$q++){
    if ( anyvalue($rst,"parid",$q)==$lv1){
      $fmkv=$fmkv."myid".($ttp0-1).".".$ttp1.":".$mnid.anyvalue($rst,"myid",$q)."#/#";
      $fmkv=$fmkv."myname".($ttp0-1).".".$ttp1.":".anyvalue($rst,"mymark",$q)."#/#";
      $fmkv=$fmkv."mytxt".($ttp0-1).".".$ttp1.":".anyvalue($rst,"mytitle",$q)."#/#";
      $fmkv=$fmkv."myurl".($ttp0-1).".".$ttp1.":".anyvalue($rst,"myurl",$q)."#/#";
      $fmkv=$fmkv."myclick".($ttp0-1).".".$ttp1.":".anyvalue($rst,"myclick",$q)."#/#";
      $fmkv=$fmkv."mydescrib".($ttp0-1).".".$ttp1.":".anyvalue($rst,"mydescrib",$q)."#/#";
      $fmkv=$fmkv."mylevel".($ttp0-1).".".$ttp1.":".$ttp0.".".($ttp1+1)."#/#";
      $fmkv=$fmkv."myclass".($ttp0-1).".".$ttp1.":".""."#/#";
      $fmdx=$fmdx."d(";  
      $ttp1=$ttp1+1;
      $lv2=anyvalue($rst,"myid",$q);
      $ttp2=0;
       for ($r=0;$r<$totr;$r++){
         if ( anyvalue($rst,"parid",$r)==$lv2){
          $fmkv=$fmkv."myid".($ttp0-1).".".($ttp1-1).".".$ttp2.":".$mnid.anyvalue($rst,"myid",$r)."#/#";
          $fmkv=$fmkv."myname".($ttp0-1).".".($ttp1-1).".".$ttp2.":".anyvalue($rst,"mymark",$r)."#/#";
          $fmkv=$fmkv."mytxt".($ttp0-1).".".($ttp1-1).".".$ttp2.":".anyvalue($rst,"mytitle",$r)."#/#";
          $fmkv=$fmkv."myurl".($ttp0-1).".".($ttp1-1).".".$ttp2.":".anyvalue($rst,"myurl",$r)."#/#";
          $fmkv=$fmkv."myclick".($ttp0-1).".".($ttp1-1).".".$ttp2.":".anyvalue($rst,"myclick",$r)."#/#";
          $fmkv=$fmkv."mydescrib".($ttp0-1).".".($ttp1-1).".".$ttp2.":".anyvalue($rst,"mydescrib",$r)."#/#";
          $fmkv=$fmkv."mylevel".($ttp0-1).".".($ttp1-1).".".$ttp2.":".$ttp0.".".$ttp1.".".($ttp2+1)."#/#";
          $fmkv=$fmkv."myclass".($ttp0-1).".".($ttp1-1).".".$ttp2.":".""."#/#";
          $fmdx=$fmdx."d(";  
         $ttp2=$ttp2+1;
          $lv3=anyvalue($rst,"myid",$r);
         $ttp3=0;
           for ($s=0;$s<$tots;$s++){
             if ( anyvalue($rst,"parid",$s)==$lv3){
               $fmkv=$fmkv."myid".($ttp0-1).".".($ttp1-1).".".($ttp2-1).".".$ttp3.":".$mnid.anyvalue($rst,"myid",$s)."#/#";
               $fmkv=$fmkv."myname".($ttp0-1).".".($ttp1-1).".".($ttp2-1).".".$ttp3.":".anyvalue($rst,"mymark",$s)."#/#";
               $fmkv=$fmkv."mytxt".($ttp0-1).".".($ttp1-1).".".($ttp2-1).".".$ttp3.":".anyvalue($rst,"mytitle",$s)."#/#";
               $fmkv=$fmkv."myurl".($ttp0-1).".".($ttp1-1).".".($ttp2-1).".".$ttp3.":".anyvalue($rst,"myurl",$s)."#/#";
               $fmkv=$fmkv."myclick".($ttp0-1).".".($ttp1-1).".".($ttp2-1).".".$ttp3.":".anyvalue($rst,"myclick",$s)."#/#";
               $fmkv=$fmkv."mydescrib".($ttp0-1).".".($ttp1-1).".".($ttp2-1).".".$ttp3.":".anyvalue($rst,"mydescrib",$s)."#/#";
               $fmkv=$fmkv."mylevel".($ttp0-1).".".($ttp1-1).".".($ttp2-1).".".$ttp3.":".$ttp0.".".$ttp1.".".$ttp2.".".($ttp3+1)."#/#";
               $fmkv=$fmkv."myclass".($ttp0-1).".".($ttp1-1).".".($ttp2-1).".".$ttp3.":".""."#/#";
               $fmdx=$fmdx."d(";  
               $ttp3=$ttp3+1;
               $lv4=anyvalue($rst,"myid",$s);
               $fmdx=$fmdx.")3,";  
             };//ifs
            };//for s
          $fmdx=$fmdx.")2,";  
          };//if r
        };//for r
     $fmdx=$fmdx.")1,";  
    };//if p==lv1
   };//for q
  $fmdx=$fmdx.")0,";
  };//if totp p==0
 };//for totp
  $conn=mysql_connect(gl(),glu(),glp());
  $mnrst=selecteds($conn,glb(),"select plotmark,markname from coode_plotlist where plotmark='".$mnid."'","utf8","");
  $mntitle=anyvalue($mnrst,"markname",0);
  if ($mntitle!=""){
    $fmkv=$fmkv."mntitle:".$mntitle."#/#";
  }
  $conn=mysql_connect(gl(),glu(),glp());
  $xrst=selecteds($conn,glb(),"select lvone,lvtwo,lvthree,lvfour,srdhtml,stylex,cssfiles,scriptx,jsfiles from coode_commenu where menumark='".$clsid."'","utf8","");
  $jshtml=anyvalue($xrst,"scriptx",0);
  
  if (strpos($jshtml,"TY"."PE_HEX:")>0){
   $jshtml=Hex2String(hou($jshtml,"TY"."PE_HEX:"));//str_replace("
","\r\n",str_replace("\\"."'","'",$gphpc));
   $jshtml=str_replace("
","\r\n",str_replace("\\"."'","'",$jshtml));
   if (strpos($jshtml,"script")<=0){
    $jshtml="<script>\r\n".$jshtml."</script>\r\n";
   };
  }
  $csshtml=anyvalue($xrst,"stylex",0);
  if (strpos($csshtml,"TY"."PE"."_HEX:")>0){
   $csshtml=Hex2String(hou($csshtml,"TY"."PE"."_HEX:"));
   $csshtml=str_replace("
","\r\n",str_replace("\\"."'","'",$csshtml));
  };
  $jslocal=anyvalue($xrst,"jsfiles",0);
  $xhtml=fmtmpmenu($fmdx,$fmkv,tostring(anyvalue($xrst,"srdhtml",0)),tostring(anyvalue($xrst,"lvone",0)),tostring(anyvalue($xrst,"lvtwo",0)),tostring(anyvalue($xrst,"lvthree",0)),tostring(anyvalue($xrst,"lvfour",0)));
//  echo "--------aaaaaa---------------".$fmdx."-------------------------";
//  echo "----------bbbbbb-------------".$fmkv."-------------------------";
  $mx["menujsfile"]=anyvalue($xrst,"jsfiles",0);
  $mx["menujstxt"]=$jshtml;
  $mx["menucssfile"]=anyvalue($xrst,"cssfiles",0);
  $mx["menucsstxt"]=$csshtml;
  $mx["menuhtml"]=$xhtml;
 return $mx;
}
function fmanymenu($mx=array(),$mnid,$clsid){
 $conn=mysql_connect(gl(),glu(),glp());
 $rst=selecteds($conn,glb(),"select myid,parid,mytitle,mymark,myurl,myclick,mydescrib from coode_plotdetail where plotmark='".$mnid."'","utf8","");
 $totp=countresult($rst);
  if ($totp==0){
    $conn=mysql_connect(gl(),glu(),glp());
    $rst=selecteds($conn,glb(),"select myid,parid,mytitle,mymark,myurl,myclick,mydescrib from coode_plotmydetail where plotmark='".$mnid."'","utf8","");
    $totp=countresult($rst);
  }
 $totq=countresult($rst);
 $totr=countresult($rst);
 $tots=countresult($rst);
 $fmdx="";
 $fmkv="";
  $ttp0=0;
 for ($p=0;$p<$totp;$p++){
  if ( anyvalue($rst,"parid",$p)=="0" or  anyvalue($rst,"parid",$p)=="-1"){
   $fmkv=$fmkv."myid".$ttp0.":".$mnid.anyvalue($rst,"myid",$p)."#/#";
   $fmkv=$fmkv."myname".$ttp0.":".anyvalue($rst,"mymark",$p)."#/#";
   $fmkv=$fmkv."mytxt".$ttp0.":".anyvalue($rst,"mytitle",$p)."#/#";
   $fmkv=$fmkv."myurl".$ttp0.":".anyvalue($rst,"myurl",$p)."#/#";
   $fmkv=$fmkv."myclick".$ttp0.":".anyvalue($rst,"myclick",$p)."#/#";
   $fmkv=$fmkv."mylevel".$ttp0.":".($ttp0+1)."#/#";
   $fmkv=$fmkv."mydescrib".$ttp0.":".anyvalue($rst,"mydescrib",$p)."#/#";
   $fmkv=$fmkv."myclass".$ttp0.":".""."#/#";
   $ttp0=$ttp0+1;
   $fmdx=$fmdx."d(";  
   $lv1=anyvalue($rst,"myid",$p);
   $ttp1=0;
   for ($q=0;$q<$totq;$q++){
    if ( anyvalue($rst,"parid",$q)==$lv1){
      $fmkv=$fmkv."myid".($ttp0-1).".".$ttp1.":".$mnid.anyvalue($rst,"myid",$q)."#/#";
      $fmkv=$fmkv."myname".($ttp0-1).".".$ttp1.":".anyvalue($rst,"mymark",$q)."#/#";
      $fmkv=$fmkv."mytxt".($ttp0-1).".".$ttp1.":".anyvalue($rst,"mytitle",$q)."#/#";
      $fmkv=$fmkv."myurl".($ttp0-1).".".$ttp1.":".anyvalue($rst,"myurl",$q)."#/#";
      $fmkv=$fmkv."myclick".($ttp0-1).".".$ttp1.":".anyvalue($rst,"myclick",$q)."#/#";
      $fmkv=$fmkv."mylevel".($ttp0-1).".".$ttp1.":".$ttp0.".".($ttp1+1)."#/#";
      $fmkv=$fmkv."mydescrib".($ttp0-1).".".$ttp1.":".anyvalue($rst,"mydescrib",$q)."#/#";
      $fmkv=$fmkv."myclass".($ttp0-1).".".$ttp1.":".""."#/#";
      $fmdx=$fmdx."d(";  
      $ttp1=$ttp1+1;
      $lv2=anyvalue($rst,"myid",$q);
      $ttp2=0;
       for ($r=0;$r<$totr;$r++){
         if ( anyvalue($rst,"parid",$r)==$lv2){
          $fmkv=$fmkv."myid".($ttp0-1).".".($ttp1-1).".".$ttp2.":".$mnid.anyvalue($rst,"myid",$r)."#/#";
          $fmkv=$fmkv."myname".($ttp0-1).".".($ttp1-1).".".$ttp2.":".anyvalue($rst,"mymark",$r)."#/#";
          $fmkv=$fmkv."mytxt".($ttp0-1).".".($ttp1-1).".".$ttp2.":".anyvalue($rst,"mytitle",$r)."#/#";
          $fmkv=$fmkv."myurl".($ttp0-1).".".($ttp1-1).".".$ttp2.":".anyvalue($rst,"myurl",$r)."#/#";
          $fmkv=$fmkv."myclick".($ttp0-1).".".($ttp1-1).".".$ttp2.":".anyvalue($rst,"myclick",$r)."#/#";
          $fmkv=$fmkv."mylevel".($ttp0-1).".".($ttp1-1).".".$ttp2.":".$ttp0.".".$ttp1.".".($ttp2+1)."#/#";
          $fmkv=$fmkv."mydescrib".($ttp0-1).".".($ttp1-1).".".$ttp2.":".anyvalue($rst,"mydescrib",$r)."#/#";
          $fmkv=$fmkv."myclass".($ttp0-1).".".($ttp1-1).".".$ttp2.":".""."#/#";
          $fmdx=$fmdx."d(";  
         $ttp2=$ttp2+1;
          $lv3=anyvalue($rst,"myid",$r);
         $ttp3=0;
           for ($s=0;$s<$tots;$s++){
             if ( anyvalue($rst,"parid",$s)==$lv3){
               $fmkv=$fmkv."myid".($ttp0-1).".".($ttp1-1).".".($ttp2-1).".".$ttp3.":".$mnid.anyvalue($rst,"myid",$s)."#/#";
               $fmkv=$fmkv."myname".($ttp0-1).".".($ttp1-1).".".($ttp2-1).".".$ttp3.":".anyvalue($rst,"mymark",$s)."#/#";
               $fmkv=$fmkv."mytxt".($ttp0-1).".".($ttp1-1).".".($ttp2-1).".".$ttp3.":".anyvalue($rst,"mytitle",$s)."#/#";
               $fmkv=$fmkv."myurl".($ttp0-1).".".($ttp1-1).".".($ttp2-1).".".$ttp3.":".anyvalue($rst,"myurl",$s)."#/#";
               $fmkv=$fmkv."myclick".($ttp0-1).".".($ttp1-1).".".($ttp2-1).".".$ttp3.":".anyvalue($rst,"myclick",$s)."#/#";
               $fmkv=$fmkv."mydescrib".($ttp0-1).".".($ttp1-1).".".$ttp2.":".anyvalue($rst,"mydescrib",$r)."#/#";
               $fmkv=$fmkv."mylevel".($ttp0-1).".".($ttp1-1).".".($ttp2-1).".".$ttp3.":".$ttp0.".".$ttp1.".".$ttp2.".".($ttp3+1)."#/#";
               $fmkv=$fmkv."myclass".($ttp0-1).".".($ttp1-1).".".($ttp2-1).".".$ttp3.":".""."#/#";
               $fmdx=$fmdx."d(";  
               $ttp3=$ttp3+1;
               $lv4=anyvalue($rst,"myid",$s);
               $fmdx=$fmdx.")3,";  
             };//ifs
            };//for s
          $fmdx=$fmdx.")2,";  
          };//if r
        };//for r
     $fmdx=$fmdx.")1,";  
    };//if p==lv1
   };//for q
  $fmdx=$fmdx.")0,";
  };//if totp p==0
 };//for totp
  $conn=mysql_connect(gl(),glu(),glp());
  $mnrst=selecteds($conn,glb(),"select plotmark,markname from coode_plotlist where plotmark='".$mnid."'","utf8","");
  $mntitle=anyvalue($mnrst,"markname",0);
  if ($mntitle!=""){
    $fmkv=$fmkv."mntitle:".$mntitle."#/#";
  }
  eval(CLASSX("templateupdt"));
  $tup=new templateupdt();
  $mbase=$tup->commenuup($clsid,"view",$mbase);
  $jshtml=$mbase["tmpcode"]["scriptx"];
  $csshtml=$mbase["tmpcode"]["stylex"];
  $jslocal=$mbase["tmpcode"]["jsfiles"];
  $xhtml=fmtmpmenu($fmdx,$fmkv,tostring($mbase["tmpcode"]["srdhtml"]),tostring($mbase["tmpcode"]["lvone"]),tostring($mbase["tmpcode"]["lvtwo"]),tostring($mbase["tmpcode"]["lvthree"]),tostring($mbase["tmpcode"]["lvfour"]));
  //echo "--------aaaaaa---------------".$fmdx."-------------------------";
  //echo "----------bbbbbb-------------".$fmkv."-------------------------";
  $mx["menujsfile"]=$mbase["tmpcode"]["jsfiles"];
  $mx["menujstxt"]=$jshtml;
  $mx["menucssfile"]=$mbase["tmpcode"]["cssfiles"];
  $mx["menucsstxt"]=$csshtml;
  $mx["menuhtml"]=$xhtml;
 return $mx;
}
function fmtmpmenu($frmtxt,$exptxt,$lelsur,$lev1,$lev2,$lev3,$lev4){
 $tmlev=0;
 $fmmntxt="";
if (strpos($frmtxt,")0")>0){
 $ptfrm0=explode(")0",$frmtxt);
 $totlv0=count($ptfrm0);
 for ($p=0;$p<$totlv0-1;$p++){ //lv0
  $fmmntxt=$fmmntxt.$lev1;
  $fmmntxt=str_replace("[myclick]","[myclick".$p."]",$fmmntxt);
  $fmmntxt=str_replace("[mydescrib]","[mydescrib".$p."]",$fmmntxt);
  $fmmntxt=str_replace("[myid]","[myid".$p."]",$fmmntxt);
  $fmmntxt=str_replace("[mytype]","[mytype".$p."]",$fmmntxt);
  $fmmntxt=str_replace("[myname]","[myname".$p."]",$fmmntxt);
  $fmmntxt=str_replace("[mytxt]","[mytxt".$p."]",$fmmntxt);
  $fmmntxt=str_replace("[mylevel]","[mylevel".$p."]",$fmmntxt);
  $fmmntxt=str_replace("[myurl]","[myurl".$p."]",$fmmntxt);
  $fmmntxt=str_replace("[myclass]","[myclass".$p."]",$fmmntxt);
   
  $fmmntxt=str_replace("[mytxt]","[mytxt".$p."]",$fmmntxt);
  $fmmntxt=str_replace("[1linner]","[1linner".$p."]",$fmmntxt);
//  echo "fmmntxt=".$fmmntxt;
  $lv1txt=hou("x".$ptfrm0[$p],"d(");
  $tmlev=1; 
     $tmp1inner="";
  if(strpos($lv1txt,")1")>0){
   $ptfrm1=explode(")1",$lv1txt);
   $totlv1=count($ptfrm1); 
     for ($q=0;$q<$totlv1-1;$q++){ //lv1 ,1分两层就是3层都够了
      $lv2txt=hou("x".$ptfrm1[$p],"d(");
      $tmlev=2; 
      $tmp1inner=$tmp1inner.$lev2;
      $tmp1inner=str_replace("[myclick]","[myclick".$p.".".$q."]",$tmp1inner);
      $tmp1inner=str_replace("[myid]","[myid".$p.".".$q."]",$tmp1inner);
      $tmp1inner=str_replace("[mytype]","[mytype".$p.".".$q."]",$tmp1inner);
      $tmp1inner=str_replace("[myname]","[myname".$p.".".$q."]",$tmp1inner);
      $tmp1inner=str_replace("[myurl]","[myurl".$p.".".$q."]",$tmp1inner);
      $tmp1inner=str_replace("[myclass]","[myclass".$p.".".$q."]",$tmp1inner);
       $tmp1inner=str_replace("[mydescrib]","[mydescrib".$p.".".$q."]",$tmp1inner);
      $tmp1inner=str_replace("[mytxt]","[mytxt".$p.".".$q."]",$tmp1inner);
      $tmp1inner=str_replace("[mylevel]","[mylevel".$p.".".$q."]",$tmp1inner);
      $tmp1inner=str_replace("[2linner]","[2linner".$p.".".$q."]",$tmp1inner);
       $tmp2inner="";
     if(strpos($lv2txt,")2")>0){
       $ptfrm2=explode(")2",$lv2txt);
       $totlv2=count($ptfrm2);        
      for ($r=0;$r<$totlv2-1;$r++){ //lv2 ,1分两层就是3层都够了
        $lv3txt=hou("x".$ptfrm2[$p],"d(");
        $tmlev=3; 
        $tmp2inner=$tmp2inner.$lev3;
        $tmp2inner=str_replace("[myclick]","[myclick".$p.".".$q.".".$r."]",$tmp2inner);
        $tmp2inner=str_replace("[myid]","[myid".$p.".".$q.".".$r."]",$tmp2inner);
        $tmp2inner=str_replace("[mytype]","[mytype".$p.".".$q.".".$r."]",$tmp2inner);
        $tmp2inner=str_replace("[myname]","[myname".$p.".".$q.".".$r."]",$tmp2inner);
        $tmp2inner=str_replace("[myurl]","[myurl".$p.".".$q.".".$r."]",$tmp2inner);
        $tmp2inner=str_replace("[myclass]","[myclass".$p.".".$q.".".$r."]",$tmp2inner);
        $tmp2inner=str_replace("[mydescrib]","[mydescrib".$p.".".$q.".".$r."]",$tmp2inner);
        $tmp2inner=str_replace("[mytxt]","[mytxt".$p.".".$q.".".$r."]",$tmp2inner);
        $tmp2inner=str_replace("[mylevel]","[mylevel".$p.".".$q.".".$r."]",$tmp2inner);
        $tmp2inner=str_replace("[3linner]","[3linner".$p.".".$q.".".$r."]",$tmp2inner);
        $tmp3inner="";
        if (strpos($lv3txt,")3")>0){         
         $ptfrm3=explode(")3",$lv3txt);
         $totlv3=count($ptfrm3);        
         for ($s=0;$s<$totlv3-1;$s++){ //lv2 ,1分两层就是3层都够了
          $lv4txt=hou("x".$ptfrm3[$p],"d(");
          $tmlev=4;
          $tmp3inner=$tmp3inner.$lev4;
          $tmp3inner=str_replace("[myclick]","[myclick".$p.".".$q.".".$r.".".$s."]",$tmp3inner);
          $tmp3inner=str_replace("[myid]","[myid".$p.".".$q.".".$r.".".$s."]",$tmp3inner);
          $tmp3inner=str_replace("[mytype]","[mytype".$p.".".$q.".".$r.".".$s."]",$tmp3inner);
          $tmp3inner=str_replace("[myname]","[myname".$p.".".$q.".".$r.".".$s."]",$tmp3inner);
          $tmp3inner=str_replace("[myurl]","[myurl".$p.".".$q.".".$r.".".$s."]",$tmp3inner);
          $tmp3inner=str_replace("[myclass]","[myclass".$p.".".$q.".".$r.".".$s."]",$tmp3inner);
           $tmp3inner=str_replace("[mydescrib]","[mydescrib".$p.".".$q.".".$r.".".$s."]",$tmp3inner);
          $tmp3inner=str_replace("[mytxt]","[mytxt".$p.".".$q.".".$r.".".$s."]",$tmp3inner);
          $tmp3inner=str_replace("[mylevel]","[mylevel".$p.".".$q.".".$r.".".$s."]",$tmp3inner);
         };//for 
        };//if )3
         $tmp2inner=str_replace("[3linner".$p.".".$q.".".$r."]",$tmp3inner,$tmp2inner);
       };//for
     };//if )2
       $tmp1inner=str_replace("[2linner".$p.".".$q."]",$tmp2inner,$tmp1inner);
    };//for
     //  echo "tmp1inner=".$tmp1inner;
   };//if )1
       $fmmntxt=str_replace("[1linner".$p."]",$tmp1inner,$fmmntxt);
  };//for
};// strpos(")0")>0
//
$tmpdes=explode("#/#",$exptxt);
$tottmp=count($tmpdes);
 $mntitle="";
 for ($k=0;$k<$tottmp-1;$k++){
  $tmpk=qian($tmpdes[$k],":");
  $tmpv=hou($tmpdes[$k],":");
  $fmmntxt=str_replace("[".$tmpk."]",$tmpv,$fmmntxt);
  if ($tmpk=="mntitle" or $tmpk=="mntxt"){
    $mntitle=$tmpv;
  }
 };//从头替换;
  $mndata=str_replace("[menudata]",$fmmntxt,$lelsur);
  $mndata=str_replace("[menutitle]",$mntitle,$mndata);
  $mndata=str_replace("[menutxt]",$mntitle,$mndata);
 return $mndata;
}
?>