<?php
function filetocloud($fromurl,$otsurl){
$otsx=qian($otsurl,"://");
 $otsrst=SX("select hostdomain,exdurl from cdots_otshosts where otscode='".$otsx."'");
 $toto=countresult($otsrst);
  if ($toto>0){
   $hdomain=anyvalue($otsrst,"hostdomain",0);
   $exdurl=anyvalue($otsrst,"exdurl",0);
   $urlx=combineurl("http://".$hdomain,$exdurl."/");
  }else{
   $hdomain=$otsx.".halo123.cn";
   $exdurl="/localxres/funx/otsrcv";
   $urlx=combineurl("http://".$hdomain,$exdurl."/");
  }
 if ($urlx!=""){
  $pd=Array();
  $pd["fromurl"]=$fromurl;
  $pd["otsurl"]=$otsurl;
  $bktxt=request_post($urlx,$pd);
  $bkjson=json_decode($bkjson,false);
  return $bktxt;
  if (intval($bkjson->status)>0){
    return true;//$zz;
  }else{
    return false;
  }
 }else{
  return false;
 }
}
function otstourl($otsurl,$otshost){
 $fpath=hou($otsurl,"://");
 return combineurl("http://".$otshost,"/localxres/funx/otsfile/?fname=".$fpath);
}
?>