<?php
function tinyhtml(){
  $h='<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <title>{title}</title>
         {cssfile}
         {jsfile}
         <script type="text/javascript" src="/DNA/EXF/sysbase/sysjs.js"></script>
         <script type="text/javascript" src="/DNA/EXF/sysbase/jquery.min.js"></script>         
         {stylex}
</head>
  {bodyx}
  {scriptx}
</html>
';
  return $h;
}
function combinehtml($fathercode=array(),$soncode=array(),$entermark){
  $comcode=array();
  $comcode["stylex"]=tostring($fathercode["stylex"]).tostring($soncode["stylex"]);
  $comcode["scriptx"]=tostring($fathercode["scriptx"]).tostring($soncode["scriptx"]);
  $comcode["cssfiles"]=tostring($fathercode["cssfiles"]).tostring($soncode["cssfiles"]);
  $comcode["jsfiles"]=tostring($fathercode["jsfiles"]).tostring($soncode["jsfiles"]);
  $comcode["html"]=str_replace($entermark,tostring($soncode["html"]),$tostring($fathercode["html"]));
  return $comcode;
}
function combineanycss($expstr,$comcode=array()){  
  $partexp=explode("/",$expstr);//这里都是页面级别的，不是UNIT级别的
  $totpe=count($partexp);
  $comcode["stylex"]="";
  $comcode["scriptx"]="";
  $comcode["cssfiles"]="";
  $comcode["jsfiles"]="";
  $comcode["html"]="";
  for ($z=0;$z<$totpe;$z++){
    $cssmark=qian($partexp[$z],":");
    $cssid=hou($partexp[$z],":");
    switch ($cssmark){
      case "shortid":
      $conn=mysql_connect(gl(),glu(),glp());
       $xrst=selecteds($conn,glb(),"select stylex,scriptx,cssfiles,jsfiles from coode_shortcss where shortid='".$cssid."'","utf8","");
       $comcode["stylex"]=$comcode["stylex"].tostring(anyvalue($xrst,"stylex",0));
       $comcode["scriptx"]=$comcode["scriptx"].tostring(anyvalue($xrst,"scriptx",0));
       $comcode["cssfiles"]=$comcode["cssfiles"].";".tostring(anyvalue($xrst,"cssfiles",0));
       $comcode["jsfiles"]=$comcode["jsfiles"].";".tostring(anyvalue($xrst,"jsfiles",0));
      break;
      case "caseid":
      $conn=mysql_connect(gl(),glu(),glp());
       $xrst=selecteds($conn,glb(),"select stylex,scriptx,cssfiles,jsfiles from coode_caseform where cfid='".$cssid."'","utf8","");
       $comcode["stylex"]=$comcode["stylex"].tostring(anyvalue($xrst,"stylex",0));
       $comcode["scriptx"]=$comcode["scriptx"].tostring(anyvalue($xrst,"scriptx",0));
       $comcode["cssfiles"]=$comcode["cssfiles"].";".tostring(anyvalue($xrst,"cssfiles",0));
       $comcode["jsfiles"]=$comcode["jsfiles"].";".tostring(anyvalue($xrst,"jsfiles",0));
      break;
      case "pageid":
      $conn=mysql_connect(gl(),glu(),glp());
       $xrst=selecteds($conn,glb(),"select stylex,scriptx,cssfiles,jsfiles,srdhtml from coode_compage where pageid='".$cssid."'","utf8","");
       $comcode["stylex"]=$comcode["stylex"].tostring(anyvalue($xrst,"stylex",0));
       $comcode["scriptx"]=$comcode["scriptx"].tostring(anyvalue($xrst,"scriptx",0));
       $comcode["cssfiles"]=$comcode["cssfiles"].";".tostring(anyvalue($xrst,"cssfiles",0));
       $comcode["jsfiles"]=$comcode["jsfiles"].";".tostring(anyvalue($xrst,"jsfiles",0));
       
      break;
      case "cssmkid":
      $conn=mysql_connect(gl(),glu(),glp());
       $xrst=selecteds($conn,glb(),"select stylex,scriptx,cssfiles,jsfiles from coode_casehtml where cssmark='".$cssid."'","utf8","");
       $comcode["stylex"]=$comcode["stylex"].tostring(anyvalue($xrst,"stylex",0));
       $comcode["scriptx"]=$comcode["scriptx"].tostring(anyvalue($xrst,"scriptx",0));
       $comcode["cssfiles"]=$comcode["cssfiles"].";".tostring(anyvalue($xrst,"cssfiles",0));
       $comcode["jsfiles"]=$comcode["jsfiles"].";".tostring(anyvalue($xrst,"jsfiles",0));      
      break;
      default:        
    }
  };
  return $comcode;
}
?>