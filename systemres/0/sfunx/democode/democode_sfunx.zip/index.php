<?php
function makeformkdemo($ctype,$shortidx){
    $strst=SX("select caseid,detailid,tablename,showkeys from coode_shortdata where shortid='".$shortidx."'");
    $shks="xxx,".tostring(anyvalue($strst,"showkeys",0)).",bbb";
    if ($ctype=="tab"){
     $caseidx=anyvalue($strst,"caseid",0);
    }else{
     $caseidx=anyvalue($strst,"detailid",0);
    }
    $tbnmx=anyvalue($strst,"tablename",0);
    if ($shks!="" and $tbnmx!=""){
      $sqlm="demomark,casetype,shortid,caseid,keydxtype,keyname,CRTM,UPTM,OLMK,hcode,jsrun";
      $sqln="RAND()*100000,'$ctype','$shortidx','$caseidx',dxtype,COLUMN_NAME,now(),now(),RAND()*100000,sysshowfun,jsshowfun";
      if ($ctype=="tab"){
        $kk=UX("delete from coode_formkeydemo where casetype='tab' and shortid='".$shortidx."'");
        $zz=UX("insert into coode_formkeydemo(".$sqlm.")select ".$sqln." from coode_keydetailx where TABLE_NAME='".$tbnmx."' and '".$shks."' like concat('%,',COLUMN_NAME,',%') and concat('tab','$caseidx','$shortidx',COLUMN_NAME) not in (select concat(casetype,caseid,shortid,keyname) from coode_formkeydemo) order by SQX");
      }else{
        $kk=UX("delete from coode_formkeydemo where casetype='form' and shortid='".$shortidx."'");
        $zz=UX("insert into coode_formkeydemo(".$sqlm.")select ".$sqln." from coode_keydetaily where shortid='".$shortidx."'  and concat('form','$caseidx','$shortidx',COLUMN_NAME) not in (select concat(casetype,caseid,shortid,keyname) from coode_formkeydemo) order by SQX");
      }
      $z3=UX("update coode_formkeydemo,coode_codedemo set coode_formkeydemo.hcode=coode_codedemo.keydemo where coode_formkeydemo.caseid=coode_codedemo.dumark and  coode_formkeydemo.keydxtype=coode_codedemo.keytype and coode_formkeydemo.hcode=''");
      $z31=UX("update coode_formkeydemo,coode_codedemo set coode_formkeydemo.jsrun=coode_codedemo.keydemo where coode_formkeydemo.caseid=coode_codedemo.dumark and  concat(coode_formkeydemo.keydxtype,'FUNCTION')=coode_codedemo.keytype and coode_formkeydemo.jsrun=''");
      if ($ctype=="tab"){
        $z4=UX("update coode_formkeydemo,coode_codedemo set coode_formkeydemo.hsrd=coode_codedemo.keydemo where coode_formkeydemo.caseid=coode_codedemo.dumark and  concat(coode_formkeydemo.keydxtype,'td')=coode_codedemo.keytype and coode_formkeydemo.hsrd=''");
        $z41=UX("update coode_formkeydemo,coode_codedemo set coode_formkeydemo.hsrd=coode_codedemo.keydemo where coode_formkeydemo.caseid=coode_codedemo.dumark and  'tabtd'=coode_codedemo.keytype and coode_formkeydemo.hsrd=''");
        $z5=UX("update coode_formkeydemo,coode_codedemo set coode_formkeydemo.hisrd=coode_codedemo.keydemo where coode_formkeydemo.caseid=coode_codedemo.dumark and  concat(coode_formkeydemo.keydxtype,'th')=coode_codedemo.keytype and coode_formkeydemo.hisrd=''");
        $z51=UX("update coode_formkeydemo,coode_codedemo set coode_formkeydemo.hisrd=coode_codedemo.keydemo where coode_formkeydemo.caseid=coode_codedemo.dumark and  'tabhdtd'=coode_codedemo.keytype and coode_formkeydemo.hisrd=''");
        $z5=UX("update coode_formkeydemo,coode_codedemo set coode_formkeydemo.onerow=coode_codedemo.keydemo where coode_formkeydemo.caseid=coode_codedemo.dumark and  'tabtr'=coode_codedemo.keytype and coode_formkeydemo.onerow=''");
        $z51=UX("update coode_formkeydemo,coode_codedemo set coode_formkeydemo.multirow=coode_codedemo.keydemo where coode_formkeydemo.caseid=coode_codedemo.dumark and  'tabthtr'=coode_codedemo.keytype and coode_formkeydemo.multirow=''");
      }else{
        $z4=UX("update coode_formkeydemo,coode_codedemo set coode_formkeydemo.hsrd=coode_codedemo.keydemo where coode_formkeydemo.caseid=coode_codedemo.dumark and  concat(coode_formkeydemo.keydxtype,'SRD')=coode_codedemo.keytype and coode_formkeydemo.hsrd=''");
        $z41=UX("update coode_formkeydemo,coode_codedemo set coode_formkeydemo.hsrd=coode_codedemo.keydemo where coode_formkeydemo.caseid=coode_codedemo.dumark and  'itemsrd'=coode_codedemo.keytype and coode_formkeydemo.hsrd=''");
        $z5=UX("update coode_formkeydemo,coode_codedemo set coode_formkeydemo.hisrd=coode_codedemo.keydemo where coode_formkeydemo.caseid=coode_codedemo.dumark and  concat(coode_formkeydemo.keydxtype,'INLINE')=coode_codedemo.keytype and coode_formkeydemo.hisrd=''");
        $z51=UX("update coode_formkeydemo,coode_codedemo set coode_formkeydemo.hisrd=coode_codedemo.keydemo where coode_formkeydemo.caseid=coode_codedemo.dumark and  'inline'=coode_codedemo.keytype and coode_formkeydemo.hisrd=''");
        $z5=UX("update coode_formkeydemo,coode_codedemo set coode_formkeydemo.onerow=coode_codedemo.keydemo where coode_formkeydemo.caseid=coode_codedemo.dumark and  'onerow'=coode_codedemo.keytype and coode_formkeydemo.onerow=''");
        $z51=UX("update coode_formkeydemo,coode_codedemo set coode_formkeydemo.multirow=coode_codedemo.keydemo where coode_formkeydemo.caseid=coode_codedemo.dumark and  'duorow'=coode_codedemo.keytype and coode_formkeydemo.multirow=''");
      }
       return true;
    }else{
        return false;
    }
    
}
function getcodedemo($ktype,$dm,$dk){
   
        $krst=SX("select keytype,keydemo from coode_codedemo where domain='".$dm."' and mark='".$dk."'");
        $totk=countresult($krst);
        $rtndemo="";
        $find=0;
        for ($i=0;$i<$totk;$i++){
            if (anyvalue($krst,"keytype",$i)==$ktype){
                $rtndemo=tostring(anyvalue($krst,"keydemo",$i));
                $find=$find+1;
            }
        }
        if ($find>0){
        }else{
          $_SESSION[$kmark]="";
          $sqlx="domain,mark,dumark,keytype,keydemo,CRTM,UPTM,OLMK,CRTOR";
          $sqly="'".$dm."','".$dk."','".$dm.".".$dk."','".$ktype."','',now(),now(),'".onlymark()."',''";
          $sqlz=UX("insert into coode_codedemo(".$sqlx.")values(".$sqly.")");
        }
        return $rtndemo;   
 }

?>