<?php
//万以下数据库用数据空间比较实用x
//增，改，删要在这里操作
//核心文件里只做快速查询
//indexv里面不能放置大值text,longtext不能放
//本系统要建立个名词表，动词表，把资源名和写程序操作的名都初步识别一下，根据识别的，两个有的，抛给GPT,让他回答
//本系统 比如做关键词，有这个词之后就抛给GPT本系统的相关信息
//在已有的DASP中加数据,可以只增加个别字段，其他可以默认值，或者为空，如果别的字段有时间，则默认时间必须填
//资源名 ND,  标签，函数集，本系统
//资源名 ND,  标签，本系统  两个字段各种组合能确定是这个资源
//防爆开关ND450  标签 重庆
//防爆开关ND450  标签 煤科院  独有的特征比较好找，语言意思，多个条件更容易缩小范围。
//问一次之后就提取这句话里的所有要素，然后在根据这个这些要素这么回复，问咨询者，我这么回答是否满意
//根据是否满意，或者不对进行判断，系统重新反思这个模式中哪个要素是不正确的；将不正确的回复记录下来
//然后我给重新回答，建立新的映射
//资源名创建，资源标题，charatab=coode_user,coode_manager,xx特征与角色很多；集团特征再定义；多选，特征表；
//资源在不同的特征下面的信息不一样，可以列出所有信息，针对他自己的，一类人；具备这些特点的有几个；也可以同时查询
//每个独立系统里都有一个自己的资源名称表，其他表都算是特征表coode_resdefine kmc_resdefine
function getdsno($dtmk,$cdtx){
  if (strpos($cdtx,"&")>0){
  $ptcdt=explode("&",$cdtx);
  $totpt=count($ptcdt);
  $drst=SY($dtmk);
  $fmsno="";
  for ($ii=0;$ii<countresult($drst);$ii++){
   $tempsum=0;  
   for ($qq=0;$qq<$totpt;$qq++){
   $qk=qian($ptcdt[$qq],"=");
   $qv=hou($ptcdt[$qq],"=");
   $av=anyvalue($drst,$qk,$ii);
   if (strpos("xxx".$qv,":@:")>0){
    $qvv=hou($qv,":@:");
    if (strpos("//.".$av,$qvv)>0){
    $tempsum=$tempsum+1;
    }
   }else{
    if ($av==$qv){
    $tempsum=$tempsum+1;
    }
   }//strpos
   } //qq
   if ($tempsum==$totpt){
    $fmsno=$fmsno.$ii.",";
   }
  }
  }else{
   $totpt=1;
   for ($ii=0;$ii<countresult($drst);$ii++){
    $qk=qian($cdtx,"=");
    $qv=hou($cdtx,"=");
    $av=anyvalue($drst,$qk,$ii);
    $tempsum=0;
    if (strpos("xxx".$qv,":@:")>0){    
     $qvv=hou($qv,":@:");    
     if (strpos("//.".$av,$qvv)>0){
      $tempsum=$tempsum+1;
     }
    }else{
    if ($av==$qv){
      $tempsum=$tempsum+1;
    }
    }  
    if ($tempsum==$totpt){
    $fmsno=$fmsno.$ii.",";
    }
   }//for
  }
  return killlaststr($fmsno);
}
function DV($dtmk,$dtsno,$dtkey){
  $dkrst=SX("select keytitle,keytype from coode_dspcval where datamark='".$dtmk."' and keymark='".$dtkey."' and datasno='".$dtsno."'");
  $totdk=countresult($dkrst);
  if ($totdk>0){
   $keytype=anyvalue($dkrst,"keytype",0);
   $valkey=$keytype."val";
   switch($keytype){
   case "varchar":
   break;
   case "text":
   break;
   case "longtext":
   break;
   case "int":
   break;
   case "tinyint":
   break;
   case "date":
   break;
   case "datetime":
   break;
   case "decimal":
   break;
   default:
  }
   $val=UX("select ".$valkey." as result from coode_dspcval where datamark='".$dtmk."' and keymark='".$dtkey."' and datasno='".$dtsno."'");
   return $val;
  }else{
   return "";
  }
}
function PV($dpath){
  //$datapath="TAB:dbmk@tabnm/resid_SNO:30.savekey";  AV  SETV 用这个方法快速查看
  //$datapath="DS:dtmk@30.savekey";
  $dtype=qian($dpath,":");
  $exp=hou($dpath,":");
  switch($dtype){
  case "TAB":
  $dbmk=qian($exp,"@");
  $tbexp=hou($exp,"@");
  $tbnm=qian($tbexp,"/");
  $keyexp=hou($tbexp,"/");
  $reskey=qian(hou($keyexp,"resid_"),":");
  $resval=qian(hou($keyexp,":"),".");
  $askkey=hou($keyexp,".");
  if ($dbmk="thishostcore"){
   $val=UX("select ".$askkey." as result from ".$tbnm." where ".$reskey."='".$resval."'");
  }else{
   $dbrst=SX("select dbip,dbus,dbps,dbname from coode_dblist where dbmark='".$dbmk."'");   
   $totdb=countresult($dbrst);
   if ($totdb>0){
    $fip=anyvalue($dbrst,"dbip",0);
    $fuser=anyvalue($dbrst,"dbus",0);
    $fpass=anyvalue($dbrst,"dbps",0);
    $fbase=anyvalue($dbrst,"dbname",0);
    $conn=mysql_connect($fip,$fuser,$fpass);
    $val=updatings($conn,$fbase,"select ".$askkey." as result from ".$tbnm." where ".$reskey."='".$resval."'","utf8");
   }else{
    return "";
   }
  }
  return $val;
  break;
  case "DS":
   $dtmk=qian($exp,"@");
   $dsexp=hou($exp,"@");
   $dssno=qian($dsexp,".");
   $dskey=hou($dsexp,".");
   return DV($dtmk,$dssno,$dskey);
  break;
  default:
   return $dpath;
  }
 }
 function SPV($dpath,$nv){
  $dtype=qian($dpath,":");
  $exp=hou($dpath,":");
  switch($dtype){
  case "TAB":
   $dbmk=qian($exp,"@");
   $tbexp=hou($exp,"@");
   $tbnm=qian($tbexp,"/");
   $keyexp=hou($tbexp,"/");
   $reskey=qian(hou($keyexp,"resid_"),":");
   $resval=qian(hou($keyexp,":"),".");
   $askkey=hou($keyexp,".");
   if ($dbmk="thishostcore"){
    $val=UX("update ".$tbnm." set ".$askkey."='".$nv."' where ".$reskey."='".$resval."'");
  }else{
   $dbrst=SX("select dbip,dbus,dbps,dbname from coode_dblist where dbmark='".$dbmk."'");   
   $totdb=countresult($dbrst);
   if ($totdb>0){
    $fip=anyvalue($dbrst,"dbip",0);
    $fuser=anyvalue($dbrst,"dbus",0);
    $fpass=anyvalue($dbrst,"dbps",0);
    $fbase=anyvalue($dbrst,"dbname",0);
    $conn=mysql_connect($fip,$fuser,$fpass);
    $nn=updatings($conn,$fbase,"update ".$tbnm." set ".$askkey."='".$nv."' where ".$reskey."='".$resval."'","utf8");
    return true;
   }else{
    return false;
   }//iftotdb
  }//ifthiscore
  return PV($dpath);
  break;
  case "DS":
   $dtmk=qian($exp,"@");
   $dsexp=hou($exp,"@");
   $dssno=qian($dsexp,".");
   $dskey=hou($dsexp,".");
   $zz=UD($dtmk,"datasno=".$dssno,$dskey."=".$nv);
   return PV($dpath);
  break;
  default:
   return $dpath;
  }
}
function KN($cstr){
  return file_get_contents(combineurl("http://".glw(),"/localxres/funx/aikeynames/?chkeys=".$cstr));
}
function KCN($cstr){
  return file_get_contents(combineurl("http://".glw(),"/localxres/funx/aikeycols/?enkeys=".$cstr));
}
function TNM($cstr){
  $bktbnm=file_get_contents(combineurl("http://".glw(),"/localxres/funx/aitabname/?tabtitle=".$cstr));
  $bktbnm=strtolower(qian($bktbnm," "));
  if ($bktbnm!=""){
   return $bktbnm;
  }else{
   return chitopy($bktbnm);
  }
}
function getktt($colnm){
  $krst=SX("select keytitle,count(keytitle) as totk from coode_keydetailx where COLUMN_NAME='".$colnm."' and keytitle!='".$colnm."' group by keytitle order by totk desc");
  $totk=countresult($krst);
  if (intval($totk)>0){
   return anyvalue($krst,"keytitle",0);
  }else{
   return $colnm;
  }
}
function COLTNM($cstr){
  $bktbnm=file_get_contents(combineurl("http://".glw(),"/localxres/funx/aicoltotbnm/?enkeys=".$cstr));
  if (strpos($bktbnm,"@")>0){
   $bktbnme=strtolower(qian($bktbnm,"@"));
   $bktbnmc=hou($bktbnm,"@");
   return $bktbnme."@".$bktbnmc;
  }else{
   return "";
  }  
}
function KT($cstr){
  $ktypex=file_get_contents(combineurl("http://".glw(),"/localxres/funx/aikeytypes/?chkeyx=".$cstr));
  $ktypex=strtolower($ktypex);
  $dtype=qian($ktypex,"(");
  $dtlen=qian(hou($ktypex,"("),")");
  //bit date time timestamp datetime year enum set text blob
  switch($dtype){
  case "bit":
  return $dtype;
  break;  
  case "timestamp":
  return $dtype;
  break;  
  case "time":
  return $dtype;
  break;  
  case "year":
  return $dtype;
  break;  
  case "enum":
  return $dtype;
  break;  
  case "set":
  return $dtype;
  break;  
  case "date":
  return $dtype;
  break;
  case "datetime":
  return $dtype;
  break;
  case "text":
  return $dtype;
  break;
  case "longtext":
  return $dtype;
  break;
  case "blob":
  return $dtype;
  break;
  case "decimal":
  return $dtype."(10,4)";
  break;
  default:
  return $ktypex;
 }
}
function ECTD($tabx,$cdtx){
 $fmcdt="";
 if (strpos($cdtx,"&")>0){
  $ptcdt=explode("&",$cdtx);
  for ($zz=0;$zz<count($ptcdt);$zz++){  
  $kq=qian($ptcdt[$zz],"=");
  $vh=hou($ptcdt[$zz],"=");
   if ($vh!="" and $kq!=""){
    $fmcdt=$fmcdt." ".$kq."='".$vh."' and";
   }
  }
  }else{
  $kq=qian($cdtx,"=");
  $vh=hou($cdtx,"=");
   if ($vh!="" and $kq!=""){
    $fmcdt=$fmcdt." ".$kq."='".$vh."' and";
   }
  }
  $fmcdt=$fmcdt." 1>0";
    $extd=UX("select count(*) as result from ".$tabx." where ".$fmcdt);
    if (intval($extd)>0){
     return true;
    }else{
     return false;
    }
}
function KCTD($tabx,$cdtx){
 $fmcdt="";
 if (strpos($cdtx,"&")>0){
  $ptcdt=explode("&",$cdtx);
  for ($zz=0;$zz<count($ptcdt);$zz++){  
    $kq=qian($ptcdt[$zz],"=");
    $vh=hou($ptcdt[$zz],"=");
    if ($vh!="" and $kq!=""){
     $fmcdt=$fmcdt." ".$kq."='".$vh."' and";
    }
  }
  }else{
     $kq=qian($cdtx,"=");
     $vh=hou($cdtx,"=");
     if ($vh!="" and $kq!=""){
      $fmcdt=$fmcdt." ".$kq."='".$vh."' and";
     }
  }
  $fmcdt=$fmcdt." 1>0";
  $extd=UX("delete from ".$tabx." where ".$fmcdt);
  if (intval($extd)>0){
    return true;
  }else{
    return false;
  }
}
function RD($dmark){
$datamark=$dmark;
$dkrst=SX("select datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib  from coode_dspckey where datamark='".$datamark."' order by sqx");
  $totdk=countresult($dkrst);
  $fmtps="";
  $fmrcd="datasno,";
  $fmca="";
  $fmcb="";
  $clstxt="";
  for ($i=0;$i<$totdk;$i++){
  $keyx[$i]=anyvalue($dkrst,"keymark",$i);
  $keyy[$i]=anyvalue($dkrst,"keytitle",$i);
  $keytp[$i]=anyvalue($dkrst,"keytype",$i);
  $keylen[$i]=anyvalue($dkrst,"keylen",$i);
  $clstxtx[$i]=anyvalue($dkrst,"clstxt",$i);
  $classp[$i]=anyvalue($dkrst,"classp",$i);
  $keydxtype[$i]=anyvalue($dkrst,"dxtype",$i);
  $fmtps=$fmtps.'{"keyid":"'.$keyx[$i].'","keytitle":"'.$keyy[$i].'","keytype":"'.$keytp[$i].'","keylen":"'.$keylen[$i].'"},';
  $fmrcd=$fmrcd.$keyx[$i].",";
  }//totdk
  $fmtps=killlaststr($fmtps);
  $fmrcd=killlaststr($fmrcd)."@/@";
  $fmrcd=str_replace(",","@-@",$fmrcd);
  $jsondata='{"data":[<datavls>]}';
  $datademo='{"status":"1","datamark":"<datamark>","datatitle":"<datatitle>","totrcd":"<totrcd>","keytps":[<ktps>],"vls":[<datavls>]}';
  $datatitle=UX("select datatitle as result from coode_dataspace where datamark='".$datamark."'");
  $datarst=SX("select datasno,keymks,valmd5,keyvals from coode_dspcvindex where datamark='".$datamark."'");
  $totda=countresult($datarst);
  $datademo=str_replace("<datamark>",$datamark,$datademo);
  $datademo=str_replace("<datatitle>",$datatitle,$datademo);
  $datademo=str_replace("<ktps>",$fmtps,$datademo);
  $datademo=str_replace("<totrcd>",$totda,$datademo);
  $fmvalx="";
 
  for ($j=0;$j<$totda;$j++){
  $datasno=anyvalue($datarst,"datasno",$j);
  $keymks=anyvalue($datarst,"keymks",$j);
  $valmd5=anyvalue($datarst,"valmd5",$j);
  $keyvals=anyvalue($datarst,"keyvals",$j);
  $rcdrowx="";
  $fmitem="{";
  if ($keyvals!=""){
  $ptkey=explode(",",$keymks);  
  $ptval=explode("@-@",$keyvals);  
  for ($k=0;$k<count($ptkey);$k++){
   $valx[$ptkey[$k]]=$ptval[$k];    
   $rcdrowx=$rcdrowx.$ptval[$k].",";
   if ($classp[$k]==1){
   $fmca=$fmca.$ptval[$k].",";
   }
   if ($classp[$k]==2){
   $fmcb=$fmcb.$ptval[$k].",";
   }
  }//fork
   $fmrcd=$fmrcd.$datasno.",".$rcdrowx;
   $fmrcd=killlaststr($fmrcd).";";
  }else{
  $detailrst=SX("select keymark,keytype,intval,tinyintval,dateval,datetimeval,varcharval,textval,longtextval,decimalval,classp from coode_dspcval where datamark='".$datamark."' and datasno='".$datasno."'");
  $totdtl=countresult($detailrst);   
  for ($k=0;$k<$totdtl;$k++){
   $kmk=anyvalue($detailrst,"keymark",$k);
   $ktp=anyvalue($detailrst,"keytype",$k);
   $classpx=anyvalue($detailrst,"classp",$k);
   $intval=anyvalue($detailrst,"intval",$k);
   $tinyintval=anyvalue($detailrst,"tinyintval",$k);
   $dateval=anyvalue($detailrst,"dateval",$k);
   $datetimeval=anyvalue($detailrst,"datetimeval",$k);
   $varcharval=anyvalue($detailrst,"varcharval",$k);
   $textval=anyvalue($detailrst,"textval",$k);
   $longtextval=anyvalue($detailrst,"longtextval",$k);
   $decimalval=anyvalue($detailrst,"decimalval",$k);
   switch($ktp){
    case "int":
    $valx[$kmk]=$intval;
    break;
    case "tinyint":
    $valx[$kmk]=$tinyintval;
    break;
    case "dateval":
    $valx[$kmk]=$dateval;
    break;
    case "datetimeval":
    $valx[$kmk]=$datetimeval;
    break;
    case "varcharval":
    $valx[$kmk]=$varcharval;
    break;
    case "textval":
    $valx[$kmk]=$textval;
    break;
    case "longtextval":
    $valx[$kmk]=$longtextval;
    break;
    case "decimalval":
    $valx[$kmk]=$decimalval;
    break;
    default:
   }//swc
   $rcdrowx=$rcdrowx.$valx[$kmk].",";   
   if (intval($classpx)==1){
    $fmca=$fmca.$valx[$kmk].",";
   }
   if (intval($classpx)==2){
    $fmcb=$fmcb.$valx[$kmk].",";
   }
  }//fork  
  $fmrcd=$fmrcd.$datasno.",".$rcdrowx;
  $fmrcd=killlaststr($fmrcd).";";  
  }//ifkeyval
  
  for ($i=0;$i<$totdk;$i++){
   $fmitem=$fmitem.'"'.$keyx[$i].'":"'.$valx[$keyx[$i]].'",';
  }
  $fmitem=killlaststr($fmitem).'}';
  $fmvalx=$fmvalx.$fmitem.',';
  }//forj
  $fmvalx=killlaststr($fmvalx);
  $fmca=killlaststr($fmca);
  $fmcb=killlaststr($fmcb);
  if ($fmca!="" and $fmcb!=""){
  $clstxt=$fmcb."|".$fmca;
  }
 
  $fmrcd=str_replace(",","@-@",$fmrcd);
  $fmrcd=str_replace(";","@/@",$fmrcd);
  
  $datademo=str_replace("<datavls>",$fmvalx,$datademo);
  $jsondata=str_replace("<datavls>",$fmvalx,$jsondata);
  
  $jshortpath=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/jsshort.json");
  $jsonpath=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/data.json");
  $coodex=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/coodercd.txt");
  $coodeclstxt=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/coodeclstxt.txt");
  $z0=overfile($jshortpath,$datademo);
  $z1=overfile($jsonpath,$jsondata);
  $newrcd=str_replace("@-@","#"."-#",str_replace("@/@","#"."/#",$fmrcd));
  $z2=overfile($coodex,$newrcd);
  $z3=overfile($coodeclstxt,$clstxt);
  return true;
}
function ND($dmark,$pvstr){
 if (es($dmark)*es($pvstr)==1){
 $lastsno=UX("select datasno as result from coode_dspcvindex where datamark='".$dmark."' order by datasno desc");
 $newsno=intval($lastsno)+1;
 $kval=array();
  if (strpos($pvstr,"&")>0){
  $ptv=explode("&",$pvstr);
  $totptv=count($ptv);
  for ($mm=0;$mm<$totptv;$mm++){
   $temppart=$ptv[$mm];
   $tempkey=qian($ptv[$mm],"=");
   $tempval=unstrs(hou($ptv[$mm],"="));
   $kval[$tempkey]=dftval($tempval,unstrs($_POST[$tempkey]));   
  }
  $tt=UX("insert into coode_dspcval(datamark,datasno,keymark,keytitle,keytype,keylen,CRTM,UPTM,OLMK)select datamark,'".($newsno)."',keymark,keytitle,keytype,keylen,now(),now(),RAND()*1000000 from coode_dspckey where datamark='".$dmark."'");
  $dskrst=SX("select keymark,keytype,keytitle from coode_dspckey where datamark='".$dmark."'");
  $totds=countresult($dskrst);
  $fmk="";
  $fmv="";
  for ($oo=0;$oo<$totds;$oo++){
   $kmk=anyvalue($dskrst,"keymark",$oo);
   $ktp=anyvalue($dskrst,"keytype",$oo);
   $fmk=$fmk.$kmk.",";
   $fmv=$fmv.$kval[$kmk]."@-@";
   $kxx=$ktp."val";
   $dx=UX("update coode_dspcval set ".$kxx."='".$kval[$kmk]."',UPTM=now() where datamark='".$dmark."' and datasno='".($newsno)."' and keymark='".$kmk."'");  
  }
  $fmk=killlaststr($fmk);
  $fmv=killlaststr($fmv);
  $fmv=killlaststr($fmv);
  $fmv=killlaststr($fmv);
  $allkeys=$fmk;
  $tempdata=$fmv;
  $zz=UX("insert into coode_dspcvindex(datamark,datasno,keymks,valmd5,keyvals,CRTM,UPTM,CRTOR,OLMK)values('".$dmark."','".($newsno)."','".$allkeys."','".md5($tempdata)."','".$tempdata."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."') ON DUPLICATE KEY update UPTM=now(),keymks='".$allkeys."',valmd5='".md5($tempdata)."',keyvals='".$tempdata."'");
  //$bb=addprcx("insert into coode_dspcvindex(datamark,datasno,keymks,valmd5,keyvals,CRTM,UPTM,CRTOR,OLMK)values('".$dmark."','".($newsno)."','".$allkeys."','".md5($tempdata)."','".$tempdata."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."') ON DUPLICATE KEY update UPTM=now(),keymks='".$allkeys."',valmd5='".md5($tempdata)."',keyvals='".$tempdata."'".huanhang());
  }else{
  $temppart=$pvstr;
  $tempkey=qian($pvstr,"=");
  $tempval=unstrs(hou($pvstr,"="));
  $kval[$tempkey]=dftval($tempval,unstrs($_POST[$tempkey]));   
  
  $tt=UX("insert into coode_dspcval(datamark,datasno,keymark,keytitle,keytype,keylen,CRTM,UPTM,OLMK)select datamark,'".($newsno)."',keymark,keytitle,keytype,keylen,now(),now(),RAND()*1000000 from coode_dspckey where datamark='".$dmark."'");
  $dskrst=SX("select keymark,keytype,keytitle from coode_dspckey where datamark='".$dmark."'");
  $totds=countresult($dskrst);
  $fmk="";
  $fmv="";
  for ($oo=0;$oo<$totds;$oo++){
   $kmk=anyvalue($dskrst,"keymark",$oo);
   $ktp=anyvalue($dskrst,"keytype",$oo);
   $fmk=$fmk.$kmk.",";
   $fmv=$fmv.$kval[$kmk]."@-@";
   $kxx=$ktp."val";
   $dx=UX("update coode_dspcval set ".$kxx."='".$kval[$kmk]."',UPTM=now() where datamark='".$dmark."' and datasno='".($newsno)."' and keymark='".$kmk."'");  
  }
  $fmk=killlaststr($fmk);
  $fmv=killlaststr($fmv);
  $fmv=killlaststr($fmv);
  $fmv=killlaststr($fmv);
  $allkeys=$fmk;
  $tempdata=$fmv;
  $zz=UX("insert into coode_dspcvindex(datamark,datasno,keymks,valmd5,keyvals,CRTM,UPTM,CRTOR,OLMK)values('".$dmark."','".($newsno)."','".$allkeys."','".md5($tempdata)."','".$tempdata."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."') ON DUPLICATE KEY update UPTM=now(),keymks='".$allkeys."',valmd5='".md5($tempdata)."',keyvals='".$tempdata."'");
  }
  $nn=RD($dmark);
 }else{
  return -3.14;
 }
}
//在已有的DASP中更改
function UD($dmark,$cdtx,$newv){
$succ=0;
  if ($cdtx=="alldata"){  
   if (strpos($newv,"&")>0){
   $ptnv=explode("&",$newv);
   $totv=count($ptnv);
   for ($bb=0;$bb<$totv;$bb++){
    $vkey=qian($ptnv[$bb],"=");
    $vval=hou($ptnv[$bb],"=");
    $vktp=UX("select keytype as result from coode_dscpkey where datamark='".$dmark."' and keymark='".$vkey."'");
    $zz=UX("update coode_dscpval set ".$vktp."val='".$vval."' where datamark='".$dmark."' and keymark='".$vkey."'");   
   }
   }else{
    $vkey=qian($newv,"=");
    $vval=hou($newv,"=");
    $vktp=UX("select keytype as result from coode_dscpkey where datamark='".$dmark."' and keymark='".$vkey."'");
    $zz=UX("update coode_dscpval set ".$vktp."val='".$vval."' where datamark='".$dmark."' and keymark='".$vkey."'");
   }
  $allrst=SX("select SNO,datasno from coode_dspcvindex where datamark='".$dmark."'");
  $totall=countresult($allrst);
  for ($p=0;$p<$totall;$p++){
   $dsno=anyvalue($allrst,"datasno",$p);
   $detailrst=SX("select keymark,keytype,intval,tinyintval,dateval,datetimeval,varcharval,textval,longtextval,decimalval,classp from coode_dspcval where datamark='".$dmark."' and datasno='".$dsno."'");
   $totdtl=countresult($detailrst);   
   $rcdrowx="";
   $keyrowx="";
   for ($k=0;$k<$totdtl;$k++){
    $kmk=anyvalue($detailrst,"keymark",$k);
    $ktp=anyvalue($detailrst,"keytype",$k);
    $classpx=anyvalue($detailrst,"classp",$k);
    $intval=anyvalue($detailrst,"intval",$k);
    $tinyintval=anyvalue($detailrst,"tinyintval",$k);
    $dateval=anyvalue($detailrst,"dateval",$k);
    $datetimeval=anyvalue($detailrst,"datetimeval",$k);
    $varcharval=anyvalue($detailrst,"varcharval",$k);
    $textval=anyvalue($detailrst,"textval",$k);
    $longtextval=anyvalue($detailrst,"longtextval",$k);
    $decimalval=anyvalue($detailrst,"decimalval",$k);
    switch($ktp){
    case "int":
    $valx[$kmk]=$intval;
    break;
    case "tinyint":
    $valx[$kmk]=$tinyintval;
    break;
    case "dateval":
    $valx[$kmk]=$dateval;
    break;
    case "datetimeval":
    $valx[$kmk]=$datetimeval;
    break;
    case "varcharval":
    $valx[$kmk]=$varcharval;
    break;
    case "textval":
    $valx[$kmk]=$textval;
    break;
    case "longtextval":
    $valx[$kmk]=$longtextval;
    break;
    case "decimalval":
    $valx[$kmk]=$decimalval;
    break;
    default:
    }//swc
    $rcdrowx=$rcdrowx.$valx[$kmk].",";
    $keyrowx=$keyrowx.$kmk.",";
    if (intval($classpx)==1){
    $fmca=$fmca.$valx[$kmk].",";
    }
    if (intval($classpx)==2){
    $fmcb=$fmcb.$valx[$kmk].",";
    }
   }//fork
   $keyrowx=killlaststr($keyrowx);
   $rcdrowx=str_replace(",","@-@",killlaststr($rcdrowx));
   $zz=UX("update coode_dspcindex set keymks='".$keyrowx."',keyvals='".$rcdrowx."' where datamark='".$dmark."' and datasno='".$dsno."'");
   $succ=$succ+1;
  }//forp
  }else{
  $dsnox=getdsno($dmark,$cdtx);
  if (strpos($dsnox,",")>0){
  $ptdsno=explode(",",$dsnox);
  $totpt=count($ptdsno);
  }else{
  $totpt=1;
  $ptdsno[0]=$dsnox;
  }
  if ($dsnox!=""){
  //则执行更改操作
  if ($totpt>0){
   for ($aa=0;$aa<$totpt;$aa++){
   if (strpos($newv,"&")>0){
    $ptnv=explode("&",$newv);
    $totv=count($ptnv);
    for ($bb=0;$bb<$totv;$bb++){
    $vkey=qian($ptnv[$bb],"=");
    $vval=hou($ptnv[$bb],"=");
    $vktp=UX("select keytype as result from coode_dscpkey where datamark='".$dmark."' and keymark='".$vkey."'");
    $zz=UX("update coode_dscpval set ".$vktp."val='".$vval."' where datamark='".$dmark."' and keymark='".$vkey."' and datasno='".$ptdsno[$aa]."'");
    }
   }else{
    $vkey=qian($newv,"=");
    $vval=hou($newv,"=");
    $vktp=UX("select keytype as result from coode_dscpkey where datamark='".$dmark."' and keymark='".$vkey."'");
    $zz=UX("update coode_dscpval set ".$vktp."val='".$vval."' where datamark='".$dmark."' and keymark='".$vkey."' and datasno='".$ptdsno[$aa]."'");
   }//ifstrpos
   }//foraa
  }else{
   if (strpos($newv,"&")>0){
   $ptnv=explode("&",$newv);
   $totv=count($ptnv);
   for ($bb=0;$bb<$totv;$bb++){
    $vkey=qian($ptnv[$bb],"=");
    $vval=hou($ptnv[$bb],"=");
    $vktp=UX("select keytype as result from coode_dscpkey where datamark='".$dmark."' and keymark='".$vkey."'");
    $zz=UX("update coode_dscpval set ".$vktp."val='".$vval."' where datamark='".$dmark."' and keymark='".$vkey."' and datasno='".$dsnox."'");
   }
   }else{
    $vkey=qian($newv,"=");
    $vval=hou($newv,"=");
    $vktp=UX("select keytype as result from coode_dscpkey where datamark='".$dmark."' and keymark='".$vkey."'");
    $zz=UX("update coode_dscpval set ".$vktp."val='".$vval."' where datamark='".$dmark."' and keymark='".$vkey."' and datasno='".$dsnox."'");
   }
  }//if pt
  for ($aa=0;$aa<$totpt;$aa++){
   $detailrst=SX("select keymark,keytype,intval,tinyintval,dateval,datetimeval,varcharval,textval,longtextval,decimalval,classp from coode_dspcval where datamark='".$dmark."' and datasno='".$ptdsno[$aa]."'");
   $totdtl=countresult($detailrst);   
   $rcdrowx="";
   $keyrowx="";
   for ($k=0;$k<$totdtl;$k++){
    $kmk=anyvalue($detailrst,"keymark",$k);
    $ktp=anyvalue($detailrst,"keytype",$k);
    $classpx=anyvalue($detailrst,"classp",$k);
    $intval=anyvalue($detailrst,"intval",$k);
    $tinyintval=anyvalue($detailrst,"tinyintval",$k);
    $dateval=anyvalue($detailrst,"dateval",$k);
    $datetimeval=anyvalue($detailrst,"datetimeval",$k);
    $varcharval=anyvalue($detailrst,"varcharval",$k);
    $textval=anyvalue($detailrst,"textval",$k);
    $longtextval=anyvalue($detailrst,"longtextval",$k);
    $decimalval=anyvalue($detailrst,"decimalval",$k);
    switch($ktp){
    case "int":
    $valx[$kmk]=$intval;
    break;
    case "tinyint":
    $valx[$kmk]=$tinyintval;
    break;
    case "dateval":
    $valx[$kmk]=$dateval;
    break;
    case "datetimeval":
    $valx[$kmk]=$datetimeval;
    break;
    case "varcharval":
    $valx[$kmk]=$varcharval;
    break;
    case "textval":
    $valx[$kmk]=$textval;
    break;
    case "longtextval":
    $valx[$kmk]=$longtextval;
    break;
    case "decimalval":
    $valx[$kmk]=$decimalval;
    break;
    default:
    }//swc
    $rcdrowx=$rcdrowx.$valx[$kmk].",";
    $keyrowx=$keyrowx.$kmk.",";
    if (intval($classpx)==1){
    $fmca=$fmca.$valx[$kmk].",";
    }
    if (intval($classpx)==2){
    $fmcb=$fmcb.$valx[$kmk].",";
    }
   }//fork
   $keyrowx=killlaststr($keyrowx);
   $rcdrowx=str_replace(",","@-@",killlaststr($rcdrowx));
   $zz=UX("update coode_dspcvindex set keymks='".$keyrowx."',keyvals='".$rcdrowx."' where datamark='".$dmark."' and datasno='".$ptdsno[$aa]."'");
   $succ=$succ+1;
  }//for pt
  }//if dsnox
}//if cdt=alldata
  $nn=RD($dmark);
  return $succ;
}//fun
//在已有的DASP中删除指定条件的这里的条件必须用A=B&C=D&E=:@:F表示LIKE
function KD($dmark,$cdtx){
  $drst=SY($dmark);
  $totd=countresult($drst);
  $succ=0;
  for ($pp=0;$pp<$totd;$pp++){
  if ($cdtx!=""){
  if (strpos($cdtx,"&")>0){
  $ptcdt=explode("&",$cdtx);
  $totpt=count($ptcdt);
  $tempsum=0;
  for ($qq=0;$qq<$totpt;$qq++){
   $qk=qian($ptcdt[$qq],"=");
   $qv=hou($ptcdt[$qq],"=");
   $av=anyvalue($drst,$qk,$pp);
   if (strpos("xxx".$qv,":@:")>0){
    if (strpos("xx".$av,$qv)>0){
    $tempsum=$tempsum+1;
    }
   }else{
    if ($av==$qv){
    $tempsum=$tempsum+1;
    }
   }
  } //for qq
  }else{
   $totpt=1;
   $qk=qian($cdtx,"=");
   $qv=hou($cdtx,"=");
   $av=anyvalue($drst,$qk,$pp);
   if (strpos("xxx".$qv,":@:")>0){
    if (strpos("xx".$av,$qv)>0){
    $tempsum=$tempsum+1;
    }
   }else{
    if ($av==$qv){
    $tempsum=$tempsum+1;
    }
   }  
  }//ifcdtx &
  }else{//if cdtx
  $totpt=-1;
  $tempsum=-1;
  }//if cdtx
  if ($totpt==$tempsum and $totpt>0){
  //则执行删除操作
   $zz=UX("delete from coode_dscpval  where datamark='".$dmark."' and datasno='".anyvalue($drst,"datasno",$pp)."'");
   $zz=UX("delete from coode_dscpindex  where datamark='".$dmark."' and datasno='".anyvalue($drst,"datasno",$pp)."'");
   $succ=$succ+1;
  }
  }//fortotd
  if ($cdtx=="alldata"){
  $zz=UX("delete from coode_dscpval  where datamark='".$dmark."'");
  $zz=UX("delete from coode_dscpvindex  where datamark='".$dmark."'");
  $p2=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/jsshort.json");
  $p3=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/data.json");
  $p4=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/coodercd.txt");
  $p5=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/coodeclstxt.txt");
  
  $k2=unlink($p2);
  $k3=unlink($p3);
  $k4=unlink($p4);
  $k5=unlink($p5);
  }
  $nn=RD($dmark);
  return $succ;
}
//新建一个结构，不填充数据
function NS($datamark,$datatitle,$kdefine){
  $extds=UX("select count(*) as result from coode_dataspace where datamark='".$datamark."'");
  if (intval($extds)==0){
  $ptkdf=explode(",",$kdefine);
  $toto=count($ptkdf);
  $srcid=$datamark;
  $srcarea="";
  $sqla="datamark,datatitle,CRTM,UPTM,CRTOR,OLMK";
  $sqlb="'$datamark','$datatitle',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";
  $zab=UX("insert into coode_dataspace(".$sqla.")values(".$sqlb.")");
  if ($srcid!=""){
  $strudemo='{"dspccode":"[dspccode]","dspctitle":"[dspctitle]","keynames":"[keynames]","ktps":[<kdata>]}';
  $itemdemo='{"keyname":"[keyname]","keytitle":"[keytitle]","dxtype":"[dxtype]","datatype":"[datatype]","keylen":"[keylen]"},';
  $strudemo=str_replace("[dspctitle]",$datatitle,$strudemo);
  $fma="";
  for ($bb=0;$bb<intval($toto);$bb++){
   $titlex=qian($ptkdf[$bb],"(");  
   $orgid=getRandChar(8);
   //String2Hex($titlex);
   $otypex=qian(hou($ptkdf[$bb],"("),")");
    switch($otypex){
    case "tinyint":
    $keytype="tinyint";
    $keylen="4";
    break;
    case "int":
    $keytype="int";
    $keylen="11";
    break;
    case "varchar20":
    $keytype="varchar";
    $keylen="20";
    break;
    case "varchar50":
    $keytype="varchar";
    $keylen="50";
    break;
    case "varchar100":
    $keytype="varchar";
    $keylen="100";
    break;
    case "varchar255":
    $keytype="varchar";
    $keylen="255";
    break;
    case "varchar1024":
    $keytype="varchar";
    $keylen="1024";
    break;
    case "decimal1":
    $keytype="decimal";
    $keylen="10.1";
    break;
    case "decimal2":
    $keytype="decimal";
    $keylen="10.2";
    break;
    case "decimal3":
    $keytype="decimal";
    $keylen="10.3";
    break;
    case "decimal4": 
    $keytype="decimal";
    $keylen="10.4";
    break;
    case "select":
    $keytype="varchar";
    $keylen="1024";
    break;
    case "multiselect":
    $keytype="varchar";
    $keylen="1024";
    break;
    case "checkbox":
    $keytype="varchar";
    $keylen="1024";
    break;
    case "multicheckbox":
    $keytype="varchar";
    $keylen="1024";
    break;
    case "imagex":
    $keytype="varchar";
    $keylen="1024";
    break;
    case "images":
    $keytype="varchar";
    $keylen="1024";
    break;
    case "filex":
    $keytype="varchar";
    $keylen="1024";
    break;
    case "files":
    $keytype="varchar";
    $keylen="1024";
    break;
    }
   $itemx=$itemdemo;
   $itemx=str_replace("[keyname]",$orgid,$itemx);
   $itemx=str_replace("[keytitle]",$titlex,$itemx);
   $itemx=str_replace("[dxtype]",$otypex,$itemx);
   $itemx=str_replace("[datatype]",$keytype,$itemx);
   $itemx=str_replace("[keylen]",$keylen,$itemx);
   $fma=$fma.$itemx;
   if ($titlex!="" and $titlex!="undefined"){
    $extx=UX("select count(*) as result from coode_dspckey where domainmark='".$srcarea."' and datamark='".$srcid."' and keytitle='".$titlex."' ");
    if (intval($extx)==0){
    $z=UX("insert into coode_dspckey(domainmark,datamark,dxtype,keytype,keylen,keymark,keytitle,CRTM,UPTM,CRTOR)values('".$srcarea."','".$srcid."','".$otypex."','".$ktype."','".$keylen."','".$orgid."','".$titlex."',now(),now(),'".$_COOKIE["uid"]."')");   
    }else{
    $z=UX("update coode_dspckey set UPTM=now(),dxtype='".$otypex."',keytype='".$keytype."',keylen='".$keylen."' where domainmark='".$srcarea."' and datamark='".$srcid."' and keytitle='".$titlex."' ");
    }  
   }
   }
   $fma=killlaststr($fma);
   $strudemo=str_replace("[kdata]",$fma,$strudemo);
   if ($srcid!=""){
   $strujson=combineurl(localroot(),"/localxres/dataspacex/".$srcid."/","structure.json");   
   $zz=overfile($strujson,$strudemo);
   }
   $bb=UX("delete from coode_dspckey where timestampdiff(second,UPTM,now())>30 and domainmark='".$srcarea."' and datamark='".$srcid."' ");  
   $sqlx="domainmark,datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib,CRTM,UPTM,CRTOR,OLMK";
   $zzx=UX("insert into coode_dspckeyx(".$sqlx.")select ".$sqlx." from coode_dspckey where datamark='".$datamark."' and concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey where datamark='".$datamark."')");
   $bbx=UX("delete from coode_dspckeyx where concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey)");
   $zzy=UX("insert into coode_dspckeyy(".$sqlx.")select ".$sqlx." from coode_dspckey where datamark='".$datamark."' and concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey where datamark='".$datamark."')");
   $bby=UX("delete from coode_dspckeyy where concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey)");
   $zzz=UX("insert into coode_dspckeyz(".$sqlx.")select ".$sqlx." from coode_dspckey where datamark='".$datamark."' and concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey where datamark='".$datamark."')");
   $bbz=UX("delete from coode_dspckeyz where concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey)");
   //在表单表格显示中计算xyz的文件structurex.json
   return 1;
  }else{
   return 0;
  }
  }else{
   return 0;
  }
}
//删除一个结构
function KS($datamark){
  $zz0=UX("delete from coode_dspcval where datamark='".$datamark."'");
  $zz1=UX("delete from coode_dspcindex where datamark='".$datamark."'");
  $zz2=UX("delete from coode_dspckey where datamark='".$datamark."'");
  $zz3=UX("delete from coode_dspckeyx where datamark='".$datamark."'");
  $zz4=UX("delete from coode_dspckeyy where datamark='".$datamark."'");
  $zz5=UX("delete from coode_dspckeyz where datamark='".$datamark."'");
  $p1=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/structure.json");
  $p2=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/jsshort.json");
  $p3=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/data.json");
  $p4=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/coodercd.txt");
  $p5=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/coodeclstxt.txt");
  $k1=unlink($p1);
  $k2=unlink($p2);
  $k3=unlink($p3);
  $k4=unlink($p4);
  $k5=unlink($p5);
  return 1;
}
//克隆结构
function CSX($fromdmk,$todmk){
 $dssql="datamark,datatitle,CRTM,UPTM,OLMK";
 $extd=UX("select count(*) as result from coode_dataspace where datamark='".$todmk."'");
 if (intval($extd)==0){
  $zz=UX("insert into coode_dataspace(".$dssql.")select '".$todmk."',datatitle,CRTM,UPTM,OLMK from coode_dataspace where datamark='".$fromdmk."'");  
 }
 $ksql0="datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib,CRTM,STATUS,UPTM,OLMK";
 $ksql0b="'".$todmk."',keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib,CRTM,STATUS,UPTM,OLMK";
 $extd=UX("delete from coode_dspckey where datamark='".$todmk."'"); 
 $zz=UX("insert into coode_dspckey(".$ksql0.")select '".$todmk."',".$ksql0b." from coode_dspckey where datamark='".$fromdmk."'");  
 
 
 $ksqlx="datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib,CRTM,STATUS,UPTM,OLMK";
 $ksqlxb="'".$todmk."',keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib,CRTM,STATUS,UPTM,OLMK";
 $extd=UX("delete from coode_dspckeyx where datamark='".$todmk."'");
 $zz=UX("insert into coode_dspckeyx(".$ksqlx.")select '".$todmk."',".$ksqlxb." from coode_dspckeyx where datamark='".$fromdmk."'");  
 $ksqly="datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib,CRTM,STATUS,UPTM,OLMK";
 $ksqlyb="'".$todmk."',keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib,CRTM,STATUS,UPTM,OLMK";
 $extd=UX("delete from coode_dspckeyy where datamark='".$todmk."'"); 
 $zz=UX("insert into coode_dspckeyy(".$ksqly.")select '".$todmk."',".$ksqlyb." from coode_dspckeyy where datamark='".$fromdmk."'");  
 
 $ksqlz="datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib,CRTM,STATUS,UPTM,OLMK";
 $ksqlzb="'".$todmk."',keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib,CRTM,STATUS,UPTM,OLMK";
 $extd=UX("delete from coode_dspckeyz where datamark='".$todmk."'"); 
 $zz=UX("insert into coode_dspckeyz(".$ksqlz.")select '".$todmk."',".$ksqlzb." from coode_dspckeyz where datamark='".$fromdmk."'");  
 $nn=RD($todmk);
 return 1;
}
//克隆结构加全部数据
function CDX($fromdmk,$todmk){
 $firstx=CSX($fromdmk,$todmk);
 $vsql="datamark,datasno,keymark,keytitle,keytype,keylen,clstxt,classp,intval,tinyintval,dateval,datetimeval,varcharval,textval,longtextval,decimalval,CRTM,UPTM,OLMK";
 $vsqlb="datasno,keymark,keytitle,keytype,keylen,clstxt,classp,intval,tinyintval,dateval,datetimeval,varcharval,textval,longtextval,decimalval,CRTM,UPTM,OLMK";
 $extd=UX("delete from coode_dspcval where datamark='".$todmk."'"); 
 $zz=UX("insert into coode_dspcval(".$vsql.")select '".$todmk."',".$vsqlb." from coode_dspcval where datamark='".$fromdmk."'");  
 
 $vsql="datamark,datasno,keymks,valmd5,keyvals,CRTM,UPTM,OLMK";
 $vsqlb="datasno,keymks,valmd5,keyvals,CRTM,UPTM,OLMK";
 $extd=UX("delete from coode_dspcindex where datamark='".$todmk."'"); 
 $zz=UX("insert into coode_dspcindex(".$vsql.")select '".$todmk."',".$vsqlb." from coode_dspcval where datamark='".$fromdmk."'");  
 $nn=RD($todmk);
 return 1;
}
//克隆结构加部分数据
function CDY($fromdmk,$todmk,$fcdt){
  $firstx=CSX($fromdmk,$todmk);
  $cdtx=$fcdt;
  $drst=SY($dmark);
  $totd=countresult($drst);
  $succ=0;
  for ($pp=0;$pp<$totd;$pp++){
  if ($cdtx!=""){
  if (strpos($cdtx,"&")>0){
  $ptcdt=explode("&",$cdtx);
  $totpt=count($ptcdt);
  $tempsum=0;
  for ($qq=0;$qq<$totpt;$qq++){
   $qk=qian($ptcdt[$qq],"=");
   $qv=hou($ptcdt[$qq],"=");
   $av=anyvalue($drst,$qk,$pp);
   if (strpos("xxx".$qv,":@:")>0){
    if (strpos("xx".$av,$qv)>0){
    $tempsum=$tempsum+1;
    }
   }else{
    if ($av==$qv){
    $tempsum=$tempsum+1;
    }
   }
  } 
  }else{
   $totpt=1;
   $qk=qian($cdtx,"=");
   $qv=hou($cdtx,"=");
   $av=anyvalue($drst,$qk,$pp);
   if (strpos("xxx".$qv,":@:")>0){
    if (strpos("xx".$av,$qv)>0){
    $tempsum=$tempsum+1;
    }
   }else{
    if ($av==$qv){
    $tempsum=$tempsum+1;
    }
   }  
  }
  }else{
  $totd=1;
  $tempsum=$totd;
  }
  if ($totpt==$tempsum){
  //则执行克隆操作
  $vsql="datamark,datasno,keymark,keytitle,keytype,keylen,clstxt,classp,intval,tinyintval,dateval,datetimeval,varcharval,textval,longtextval,decimalval,CRTM,UPTM,OLMK";
  $vsqlb="datasno,keymark,keytitle,keytype,keylen,clstxt,classp,intval,tinyintval,dateval,datetimeval,varcharval,textval,longtextval,decimalval,CRTM,UPTM,OLMK";
  $extd=UX("delete from coode_dspcval where datamark='".$todmk."' and datasno='".anyvalue($drst,"datasno",$pp)."'"); 
  $zz=UX("insert into coode_dspcval(".$vsql.")select '".$todmk."',".$vsqlb." from coode_dspcval where datamark='".$fromdmk."' and datasno='".anyvalue($drst,"datasno",$pp)."'");  
 
  $vsql="datamark,datasno,keymks,valmd5,keyvals,CRTM,UPTM,OLMK";
  $vsqlb="datasno,keymks,valmd5,keyvals,CRTM,UPTM,OLMK";
  $extd=UX("delete from coode_dspcindex where datamark='".$todmk."' and datasno='".anyvalue($drst,"datasno",$pp)."'"); 
  $zz=UX("insert into coode_dspcindex(".$vsql.")select '".$todmk."',".$vsqlb." from coode_dspcval where datamark='".$fromdmk."' and datasno='".anyvalue($drst,"datasno",$pp)."'");   
  $succ=$succ+1;
  }
  }//fortotd
  $nn=RD($dmark);
  return $succ;
}
//表格及所有表单克隆所有数据
function CDFX($fromdmk,$todmk){
 $firstx=CDX($fromdmk,$todmk);
 $vsql="datamark,dscode,dstitle,dskeys,datatype,caseid,detailid,qrycdt,oderby,dataver,beforeview,CRTM,UPTM,OLMK";
 $vsqlb="dscode,dstitle,dskeys,datatype,caseid,detailid,qrycdt,oderby,dataver,beforeview,CRTM,UPTM,OLMK";
 $extd=UX("delete from coode_dsshort where datamark='".$todmk."'"); 
 $zz=UX("insert into coode_dsshort(".$vsql.")select '".$todmk."',".$vsqlb." from coode_dsshort where datamark='".$fromdmk."'");  
 return 1;
}
//表格及所有表单条件数据克隆
function CDFY($fromdmk,$todmk,$fcdt){
  $CL=CDY($fromdmk,$todmk,$fcdt);
  $vsql="datamark,dscode,dstitle,dskeys,datatype,caseid,detailid,qrycdt,oderby,dataver,beforeview,CRTM,UPTM,OLMK";
  $vsqlb="dscode,dstitle,dskeys,datatype,caseid,detailid,qrycdt,oderby,dataver,beforeview,CRTM,UPTM,OLMK";
  $extd=UX("delete from coode_dsshort where datamark='".$todmk."'"); 
  $zz=UX("insert into coode_dsshort(".$vsql.")select '".$todmk."',".$vsqlb." from coode_dsshort where datamark='".$fromdmk."'");  
 return 1;
}
//从小数据到表格，先判断是否冲突
function D2T($fromdmk,$totabnm){
 $exttab=UX("select count(*) as result from coode_tablist where TABLE_NAME='".$totabnm."'");
 $crtdemo='CREATE TABLE [tabnm] (SNO int(11) NOT NULL AUTO_INCREMENT,[otherkeys]PRIMARY KEY (SNO)) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;';
 $keydemo='[keymark] [keytype][keylen] NOT NULL,';
  if (intval($exttab)==0){
  $dkrst=SX("select datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib  from coode_dspckey where datamark='".$datamark."' order by sqx");
  $totdk=countresult($dkrst);
  $fmtps="";
  $fmrcd="";
  $fmca="";
  $fmcb="";
  $clstxt="";
  if ($totdk>0){
  for ($i=0;$i<$totdk;$i++){
   $keyx[$i]=anyvalue($dkrst,"keymark",$i);
   $keyy[$i]=anyvalue($dkrst,"keytitle",$i);
   $keytp[$i]=anyvalue($dkrst,"keytype",$i);
   $keylen[$i]=anyvalue($dkrst,"keylen",$i);
   $clstxtx[$i]=anyvalue($dkrst,"clstxt",$i);
   $classp[$i]=anyvalue($dkrst,"classp",$i);
   $keydxtype[$i]=anyvalue($dkrst,"dxtype",$i);
   $kdemox=$keydemo;
   $kdemox=str_replace("[keymark]",$keyx[$i],$kdemox);
   $kdemox=str_replace("[keytype]",$keytp[$i],$kdemox);
   if ($keylen[$i]!=""){
   $kdemox=str_replace("[keylen]","(".str_replace(".",",",$keylen[$i]).")",$kdemox);
   }else{
   $kdemox=str_replace("[keylen]","",$kdemox);
   }
   $fmtps=$fmtps.$kdemox;   
  }//totdk
  $crtdemo=str_replace("[tabnm]",$totabnm,$crtdemo);
  $crtdemo=str_replace("[otherkeys]",$fmtps,$crtdemo);  
  $conn=mysql_connect(gl(),glu(),glp());
  $glbb=glb();  
  $z=updatingx($conn,$glbb,$crtdemo,"utf8"); 
  $dspkeys="keymark,keytitle,clstxt,classp,sqx,keytype,dxtype,keydescrib";
  $tabkeys="TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,keytitle,clstxt,classp,SQX,DATA_TYPE,dxtype,keyexplain";
  $zz=UX("insert into coode_keydetailx(".$tabkeys.")select '".glb()."','".$totabnm."',".$dspkeys." from coode_dspckey where datamark='".$fromdmk."'");
  return true;
  }else{
  return false;
  }
  }else{
  return false;
  }
}
//从表格到小数据，先判断是否冲突
function T2D($fromtabnm,$todmk){
  $tabtitle=UX("select tabtitle as result from coode_tablist where TABLE_NAME='".$fromtabnm."'");
  $tkrst=SX("select SNO,COLUMN_NAME,keytitle,dxtype,DATA_TYPE from coode_keydetailx where TABLE_NAME='".$fromtabnm."'");
  $totk=countresult($tkrst);
  $fmkdfn="";
  for ($k=0;$k<$totk;$k++){
  $snox=anyvalue($tkrst,"SNO",$k);
  $colnm=anyvalue($tkrst,"COLUMN_NAME",$k);
  $coltitle=anyvalue($tkrst,"keytitle",$k);
  $dxtype=anyvalue($tkrst,"dxtype",$k);
  if ($colnm=="SNO"){
  $colnm="datasno";
  }
  $fmkdfn=$fmkdfn.$colnm."(".$dxtype."),";
  }
  $fmkdfn=killlaststr($fmkdfn);  
  if (NS($todmk,$tabtitle,$fmkdfn)){
  $zz=UX("update coode_dspckey,coode_keydetailx set coode_dspckey.keytitle=coode_keydetail.keytitle where coode_dspckey.keymark=coode_dspckey.COLUMN_NAME and coode_dspckey.datamark='".$todmk."' and coode_keydetailx.TABLE_NAME='".$fromtabnm."'");
  $nn=RD($todmk);
  return true;
  }else{
  return false;
  };
}
function D2TV($fromdmk,$totabnm,$cdt){
  $drst=SY($dmark);
  $totd=countresult($drst);
  $succ=0;
  for ($pp=0;$pp<$totd;$pp++){
  if ($cdtx!=""){
  if (strpos($cdtx,"&")>0){
  $ptcdt=explode("&",$cdtx);
  $totpt=count($ptcdt);
  $tempsum=0;
  for ($qq=0;$qq<$totpt;$qq++){
   $qk=qian($ptcdt[$qq],"=");
   $qv=hou($ptcdt[$qq],"=");
   $av=anyvalue($drst,$qk,$pp);
   if (strpos("xxx".$qv,":@:")>0){
    if (strpos("xx".$av,$qv)>0){
    $tempsum=$tempsum+1;
    }
   }else{
    if ($av==$qv){
    $tempsum=$tempsum+1;
    }
   }
  } 
  }else{
   $totpt=1;
   $qk=qian($cdtx,"=");
   $qv=hou($cdtx,"=");
   $av=anyvalue($drst,$qk,$pp);
   if (strpos("xxx".$qv,":@:")>0){
    if (strpos("xx".$av,$qv)>0){
    $tempsum=$tempsum+1;
    }
   }else{
    if ($av==$qv){
    $tempsum=$tempsum+1;
    }
   }  
  }
  }else{
  $totpt=-1;
  $tempsum=-1;
  }
  if ($totpt==$tempsum){
  //则执行给表格新增操作
   if ($totpt>0){
   $thisrst=SX("select SNO,datasno,keymks,keyvals from coode_dspcvindex where datamark='".$dmark."' and datasno='".anyvalue($drst,"datasno",$pp)."'");
   $kmks=anyvalue($thisrst,"keymks",0);
   $kvals=anyvalue($thisrst,"keyvals",0);
   $kvalx=str_replace("@-@","','",$kvals);
   $zxz=UX("insert into ".$totabnm."(".$kmks.")values('".$kvalx."')");
   }
   $succ=$succ+1;
  }//totpt=tempsum
  }//fortotd
  if ($cdtx=="alldata"){  
  $allrst=SX("select SNO,datasno,keymks,keyvals from coode_dspcvindex where datamark='".$dmark."'");
  $totall=countresult($allrst);
  for ($px=0;$px<$totall;$px++){
   $kmks=anyvalue($thisrst,"keymks",$px);
   $kvals=anyvalue($thisrst,"keyvals",$px);
   $kvalx=str_replace("@-@","','",$kvals);
   $zxz=UX("insert into ".$totabnm."(".$kmks.")values('".$kvalx."')");
  }//forp
  $succ=$totall;
  }
  
  return $succ;
}
function T2DV($fromtabnm,$todmk,$cdt){
  $tballk=UX("select contentkeys as result from coode_tablist where TABLE_NAME='".$fromtabnm."'");
  $succ=0;
  if ($tballk!=""){
  $ptk=explode(",",$tballk);
  $totptk=count($ptk);
  $dtrst=SX("select ".$tballk." from ".$fromtabnm." where ".$cdt);
  $totdt=countresult($dtrst);
  $fmval="";
  if (intval($totdt)>0){
  for ($dd=0;$dd<$totdt;$dd++){
   for ($kk=0;$kk<$totptk;$kk++){
    $fmval=$fmval.$ptk[$kk]."=".anyvalue($dtrst,$ptk[$kk],$dd)."&";
   }//forkk
   $fmval=killlaststr($fmval);
   $xx=ND($todmk,$tballk,$fmval);
   $succ=$succ+1;
  }//fordd
  }//iftotdt
  }//iftballk
  $zz=RD($todmk);
  return $succ;
}
function D2F($dsid){
 $dkrst=SX("select datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib  from coode_dspckey where datamark='".$dsid."' order by sqx");
  $totdk=countresult($dkrst);
  $fmtps='{"keyid":"datasno","keytitle":"编号","keytype":"varchar","keylen":"100","dxtype":"varchar","classp":"0","clstxt":""},';
  $fmrcd="datasno,";
  $fmca="";
  $fmcb="";
  $clstxt="";
  for ($i=0;$i<$totdk;$i++){
  $keyx[$i]=anyvalue($dkrst,"keymark",$i);
  $keyy[$i]=anyvalue($dkrst,"keytitle",$i);
  $keytp[$i]=anyvalue($dkrst,"keytype",$i);
  $keylen[$i]=anyvalue($dkrst,"keylen",$i);
  $clstxtx[$i]=anyvalue($dkrst,"clstxt",$i);
  $classp[$i]=anyvalue($dkrst,"classp",$i);
  $keydxtype[$i]=anyvalue($dkrst,"dxtype",$i);
  $fmtps=$fmtps.'{"keyid":"'.$keyx[$i].'","keytitle":"'.$keyy[$i].'","keytype":"'.$keytp[$i].'","keylen":"'.$keylen[$i].'","dxtype":"'.$keydxtype[$i].'","classp":"'.$classp[$i].'","clstxt":"'.$clstxtx[$i].'"},';
  $fmrcd=$fmrcd.$keyx[$i].",";
  }//totdk
  $fmtps=killlaststr($fmtps);
  $fmrcd=killlaststr($fmrcd)."@/@";
  $fmrcd=str_replace(",","@-@",$fmrcd);
  $jsondata='{"data":[<datavls>]}';
  $datademo='{"status":"1","datamark":"<datamark>","datatitle":"<datatitle>","totrcd":"<totrcd>","keytps":[<ktps>],"vls":[<datavls>]}';
  $datatitle=UX("select datatitle as result from coode_dataspace where datamark='".$dsid."'");
  $datarst=SX("select datasno,keymks,valmd5,keyvals from coode_dspcvindex where datamark='".$dsid."' and datasno!=0 order by datasno");
  $totda=countresult($datarst);
  $datademo=str_replace("<datamark>",$datamark,$datademo);
  $datademo=str_replace("<datatitle>",$datatitle,$datademo);
  $datademo=str_replace("<ktps>",$fmtps,$datademo);
  $datademo=str_replace("<totrcd>",$totda,$datademo);
  $fmvalx="";
 
  for ($j=0;$j<$totda;$j++){
  $datasno=anyvalue($datarst,"datasno",$j);
  $keymks=anyvalue($datarst,"keymks",$j);
  $valmd5=anyvalue($datarst,"valmd5",$j);
  $keyvals=anyvalue($datarst,"keyvals",$j);
  $rcdrowx="";
  $fmitem='{';
  $detailrst=SX("select keymark,keytype,intval,tinyintval,dateval,datetimeval,varcharval,textval,longtextval,decimalval,classp from coode_dspcval where datamark='".$dsid."' and datasno='".$datasno."'");
  $totdtl=countresult($detailrst);   
  for ($k=0;$k<$totdtl;$k++){
   $kmk=anyvalue($detailrst,"keymark",$k);
   $ktp=anyvalue($detailrst,"keytype",$k);
   $classpx=anyvalue($detailrst,"classp",$k);
   $intval=anyvalue($detailrst,"intval",$k);
   $tinyintval=anyvalue($detailrst,"tinyintval",$k);
   $dateval=anyvalue($detailrst,"dateval",$k);
   $datetimeval=anyvalue($detailrst,"datetimeval",$k);
   $varcharval=anyvalue($detailrst,"varcharval",$k);
   $textval=anyvalue($detailrst,"textval",$k);
   $longtextval=anyvalue($detailrst,"longtextval",$k);
   $decimalval=anyvalue($detailrst,"decimalval",$k);
   switch($ktp){
    case "int":
    $valx[$kmk]=$intval;
    break;
    case "tinyint":
    $valx[$kmk]=$tinyintval;
    break;
    case "date":
    $valx[$kmk]=$dateval;
    break;
    case "datetime":
    $valx[$kmk]=$datetimeval;
    break;
    case "varchar":
    $valx[$kmk]=$varcharval;
    break;
    case "text":
    $valx[$kmk]=$textval;
    break;
    case "longtext":
    $valx[$kmk]=$longtextval;
    break;
    case "decimal":
    $valx[$kmk]=$decimalval;
    break;
    default:
   }//swc
   $rcdrowx=$rcdrowx.$valx[$kmk].",";
   if (intval($classpx)==1){
    $fmca=$fmca.$valx[$kmk].",";
   }
   if (intval($classpx)==2){
    $fmcb=$fmcb.$valx[$kmk].",";
   }
  }//fork
  $fmrcd=$fmrcd.$datasno.",".$rcdrowx;
  $fmrcd=killlaststr($fmrcd).";";   
  $fmitem=$fmitem.'"datasno":"'.$datasno.'",';
  for ($i=0;$i<$totdk;$i++){
   $fmitem=$fmitem.'"'.$keyx[$i].'":"'.$valx[$keyx[$i]].'",';
  }
  $fmitem=killlaststr($fmitem).'}';
  $fmvalx=$fmvalx.$fmitem.',';
  }//forj
  $fmvalx=killlaststr($fmvalx);
  $fmca=killlaststr($fmca);
  $fmcb=killlaststr($fmcb);
  if ($fmca!="" and $fmcb!=""){
  $clstxt=$fmcb."|".$fmca;
  } 
  $fmrcd=str_replace(",","@-@",$fmrcd);
  $fmrcd=str_replace(";","@/@",$fmrcd);
  $datademo=str_replace("<datavls>",$fmvalx,$datademo);
  $jsondata=str_replace("<datavls>",$fmvalx,$jsondata);  
  $jshortpath=combineurl(localroot(),"/localxres/dataspacex/".$dsid."/jsshort.json");
  $jsonpath=combineurl(localroot(),"/localxres/dataspacex/".$dsid."/data.json");
  $coodex=combineurl(localroot(),"/localxres/dataspacex/".$dsid."/coodercd.txt");
  $coodeclstxt=combineurl(localroot(),"/localxres/dataspacex/".$dsid."/coodeclstxt.txt");
  $z0=overfile($jshortpath,$datademo);
  $z1=overfile($jsonpath,$jsondata);
  $newrcd=str_replace("@-@","#"."-#",str_replace("@/@","#"."/#",$fmrcd));
  $z2=overfile($coodex,$newrcd);
  $z3=overfile($coodeclstxt,$clstxt);
  return true;
}
//1-5级别，分组；系统中有；PLOT;标签，名称；
//数据与文件分离；数据就是数据，携带的文件，文件要有自己的资源码；可以隶属数据，可以隶属资源；
//表格也是保存的时候所有非备注字段大索引
//表单类型，有需参条件约束，不需参条件约束，无条件约束等集中数据
//提交一次数据，在前端显示，同时更新所有表单，所有约束后的结果数据，有进度条显示；这样查询能飞快
?>