<?php
function dbshortinfo($dbmk,$shortid,$stbase=array()){
    $strst=SX("select tablename,caseid,skeys,showkeys,cdt,orddt,lang,dttp,addpage,addtitle,shorttitle,detailid,STCODE from coode_dbshort where shortid='".$shortid."' and catalog='".$dbmk."'");  
  $stbase["shortid"]=$shortid;
  $stbase["tablename"]=tostring(anyvalue($strst,"tablename",0));
  $stbase["showkeys"]=tostring(anyvalue($strst,"showkeys",0));
  $stbase["tabkeys"]=tostring(anyvalue($strst,"showkeys",0));
  $stbase["skeys"]=tostring(anyvalue($strst,"skeys",0));
  $stbase["cdt"]=tostring(anyvalue($strst,"cdt",0));
  $stbase["orddt"]=tostring(anyvalue($strst,"orddt",0));
  $stbase["beforeview"]="";
  $stbase["caseid"]=tostring(anyvalue($strst,"caseid",0));
  $stbase["pageid"]=tostring(anyvalue($strst,"lang",0));
  $stbase["dttp"]=tostring(anyvalue($strst,"dttp",0));  
  $stbase["addpage"]=tostring(anyvalue($strst,"addpage",0));
  $stbase["addtitle"]=tostring(anyvalue($strst,"addtitle",0));
  $stbase["shorttitle"]=tostring(anyvalue($strst,"shorttitle",0));
  
  $stbase["lang"]=tostring(anyvalue($strst,"lang",0));
  $stbase["detailid"]=tostring(anyvalue($strst,"detailid",0));
  $stbase["tabkv"]=tostring(anyvalue($strst,"STCODE",0)); 
  return $stbase;
}//keyarea 里面的字段是禁止看的字段，这样比较好操作。
function shortinfo($shortid,$stbase=array()){
  $conn=mysql_connect(gl(),glu(),glp());
  $strst=selecteds($conn,glb(),"select tablename,caseid,skeys,showkeys,cdt,orddt,lang,dttp,addpage,addtitle,shorttitle,detailid,tabcls from coode_shortdata where shortid='".$shortid."'","utf8","");
  $stbase["shortid"]=$shortid;
  
  $stbase["tablename"]=tostring(anyvalue($strst,"tablename",0));
  $stbase["showkeys"]=tostring(anyvalue($strst,"showkeys",0));
  $stbase["tabkeys"]=tostring(anyvalue($strst,"showkeys",0));
  $stbase["skeys"]=tostring(anyvalue($strst,"skeys",0));
  $stbase["cdt"]=tostring(anyvalue($strst,"cdt",0));
  $stbase["orddt"]=tostring(anyvalue($strst,"orddt",0));
  $stbase["beforeview"]="";
  $stbase["caseid"]=tostring(anyvalue($strst,"caseid",0));
  $stbase["pageid"]=tostring(anyvalue($strst,"lang",0));
  $stbase["dttp"]=tostring(anyvalue($strst,"dttp",0));  
  $stbase["addpage"]=tostring(anyvalue($strst,"addpage",0));
  $stbase["addtitle"]=tostring(anyvalue($strst,"addtitle",0));
  $stbase["shorttitle"]=tostring(anyvalue($strst,"shorttitle",0));
  $stbase["detailid"]=tostring(anyvalue($strst,"detailid",0));  
  $stbase["tabkv"]=tostring(anyvalue($strst,"tabcls",0));  
  return $stbase;
}//keyarea 里面的字段是禁止看的字段，这样比较好操作。
function formatbase($fmtid,$fmtbase=array()){
   $conn=mysql_connect(gl(),glu(),glp());
   $fmtrst=selecteds($conn,glb(),"select jsonid,jsontitle,keytpexc,datefmt,dttmfmt,dkeyexc,keyitem,jsonsrd,jsonitem from coode_dataformat where jsonid='".$fmtid."'","utf8","");    
   $totx=countresult($fmtrst);
   if ($totx>0){
     $fmtbase["jsonid"]=anyvalue($fmtrst,"jsonid",0);
     $fmtbase["jsontitle"]=anyvalue($fmtrst,"jsontitle",0);
     $fmtbase["keytpexc"]=tostring(anyvalue($fmtrst,"keytpexc",0));
     $fmtbase["datefmt"]=anyvalue($fmtrst,"datefmt",0);
     $fmtbase["dttmfmt"]=anyvalue($fmtrst,"dttmfmt",0);
     $fmtbase["dkeyexc"]=anyvalue($fmtrst,"dkeyexc",0);
     $fmtbase["keyitem"]=tostring(anyvalue($fmtrst,"keyitem",0));
     $fmtbase["jsonsrd"]=tostring(anyvalue($fmtrst,"jsonsrd",0));
     $fmtbase["jsonitem"]=tostring(anyvalue($fmtrst,"jsonitem",0));
   }else{
     $getfmt=file_get_contents("http://".glm()."/localxres/funx/getdatafmt/");
     $z=runinstall("","",$getfmt,onlymark());
     $conn=mysql_connect(gl(),glu(),glp());
     $fmtrst=selecteds($conn,glb(),"select jsonid,jsontitle,keytpexc,datefmt,dttmfmt,dkeyexc,keyitem,jsonsrd,jsonitem from coode_dataformat where jsonid='".$fmtid."'","utf8","");    
     $totx=countresult($fmtrst);
     $fmtbase["jsonid"]=$fmtid;
     $fmtbase["jsontitle"]="";
     $fmtbase["keytpexc"]="";
     $fmtbase["datefmt"]="";
     $fmtbase["dttmfmt"]="";
     $fmtbase["dkeyexc"]="";
     $fmtbase["keyitem"]="";
     $fmtbase["jsonsrd"]="";
     $fmtbase["jsonitem"]="";
   }
  return $fmtbase;
}
?>