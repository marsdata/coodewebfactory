<?php
function fmvalue($tbnmx,$dvalue,$dsno,$dkey,$sfun,$dn,$arrdt=array(array())){
$smd5="a".md5($tbnmx.$dvalue.$dsno.$dkey.$sfun.$dn);
$nhtxt="";
$colname=$dkey;
$snox=$dsno;
//$ktitle
$sttab=$tbnmx;
$thusvalue=$dvalue;
if ($_SESSION[$smd5]!="" and ($dvalue.$dsno.$dkey)!=""){
  return $_SESSION[$smd5];
}else{
 if (($sfun=="" or $dn==-1) and $dsno!="demo"){
      return $dvalue;
 }
  
  //echo $sfun."---------------------------";
  if (strpos("x".$sfun,"CASE")>0 and strpos("x".$sfun,"E@CS")>0){
    $ptfunx=explode("CASE",$sfun);
    $totpf=count($ptfunx);
    $fd=0;
    for ($pf=0;$pf<$totpf;$pf++){
       $tmpfn=qian(hou($ptfunx[$pf],"::"),"E@CS");
       $tmpct=qian($ptfunx[$pf],"::");
       $tmptj=substr($ptfunx[$pf],0,1);
       $tmpvlx=hou($tmpct,$tmptj);
       if ($tmptj=="@"){
         if (((strpos("xxx".$dvalue,$tmpvlx)>0 and $tmpvlx!="") or $tmpvlx=="") and $fd==0){
           $sfun=$tmpfn;
           $fd=$fd+1;
         };
       }else{
         if ($tmptj!="="){
           if ($tmptj==">"){
            if ((($tmpvlx*1)>($dvalue*1)) and $tmpvlx!="" and $fd==0){
             $sfun=$tmpfn;
             $fd=$fd+1;
            };
           }
           if ($tmptj=="<"){
            if ((($tmpvlx*1)<($dvalue*1)) and $tmpvlx!="" and $fd==0){
             $sfun=$tmpfn;
             $fd=$fd+1;
            };
           }
         }else{
          if (($dvalue==$tmpvlx or (intval($dvalue)*1)==(intval($tmpvlx)*1)) and $tmpvlx!="" and $fd==0){
             $sfun=$tmpfn;
             $fd=$fd+1;
           };
         };
       }
    };//for
    if ($fd==0){      
    }
  }else{
  };  
 if (strpos(".".$sfun,"FUN:")>0 or strpos(".".$sfun,"unction ")>0) { 
    $sfun=turncon($sfun);
   //把sfun 的中括号换成尖括号 防止解析出来 的中括号再被解析 比如thisvalue里如果有中括号的就不该被解析 如果遇到同样的东西解析 可以换种形式比如 js里的huanhang();就可以很好的规避跟PHP的换行在一起
     
     $thisvalue="";
     if (strpos(".".$sfun,"FUN:")>0 ){
      $funx=hou(".".$sfun,"FUN:");
      $funx=str_replace("funvalue","fvalue",$funx);
     }else{
      $funx='$fvalue='.qian(hou($sfun,"function"),"{").';';
     }
     $funx=str_replace("{thisid}","ipt".$dkey.$dsno,$funx);
     $funx=str_replace("{thiskey}",$dkey,$funx);
      $funx=str_replace("{thistable}",$tbnmx,$funx);
     $funx=str_replace("{thissno}",$dsno,$funx);
        $funx=str_replace("{tmpks}",$dkey.$dsno,$funx);
            $funx=str_replace("{SNO}",$dsno,$funx);
            $funx=str_replace("{key}",$dkey,$funx);
            $funx=str_replace("{key0}","p_".$dkey.$dsno,$funx);
            $funx=str_replace("{table}",$tbnmx,$funx);
            $funx=str_replace("{OLMK}",onlymark(),$funx);
      $funx=str_replace("{date}",date("Y-m-d"),$funx);
       $funx=str_replace("{now}",date("Y-m-d H:i:s"),$funx);
     $funx=str_replace("{thisshort}",$_GET["tmpshortid"],$funx);
     $funx=str_replace("{thisshort}",$_GET["tmpstid"],$funx);
     $funx=str_replace("{shortid}",$_GET["shortid"],$funx);
     $funx=str_replace("{shortid}",$_GET["stid"],$funx);
     $funx=str_replace("{thisvalue}",tostring($dvalue),$funx);
     $funx=str_replace("{siteurl}",glw(),$funx);
      $funx=str_replace("{rip}",getip(),$funx);
     $funx=str_replace("{uid}",$_COOKIE["uid"],$funx);
     $funx=str_replace("{posids}",$_COOKIE["posids"],$funx);
     $funx=str_replace("{depart}",$_COOKIE["depart"],$funx);
     $funx=str_replace("{dpts}",$_COOKIE["dpts"],$funx);
     $funx=str_replace("{cid}",$_COOKIE["cid"],$funx);
     $funx=str_replace("{grpcid}",$_COOKIE["grpcid"],$funx);
     if (strpos("xxx".$sfunx,"{col-key")>0){
        $kfun=array(array());
        $kfun=thekeyfun($kfun,glb(),$tbnmx,$arrdt["table"]["keys"]);                             
        $funx=keyexc($dkey,$arrdt["table"]["keys"],$kfun,$funx);
     }
     $grp=atv("(coode_sysdefault@companyid='".$_COOKIE["cid"]."').groupid");
     $funx=str_replace("{grp}",$grp,$funx);
     $funx=str_replace("{appid}",$_GET["appid"],$funx);
     $funx=str_replace("{defaultbase}",glb(),$funx);
     $funx=str_replace("{defaultip}",gl(),$funx);
   
   if ($dvalue=="1" or $dvalue=="checked"){
      $funx=str_replace("{checked}","checked",$funx);
    }else{
      $funx=str_replace("{checked}","",$funx);
    };//
   
   if ($dvalue==""){
     $funx=str_replace("{imgvalue}",dfp(),$funx);
   }else{
     $funx=str_replace("{imgvalue}",$dvalue,$funx);
   };//
   
     $funx=str_replace("{today}",date("Y-m-d"),$funx);
     $funx=str_replace("{now}",date("Y-m-d H:i:s"),$funx);
     
   if (strpos("xxx".$funx,"{duofile-")>0){
     $ftj=qian(hou($funx,"{duofile-"),"}");
     $funx=str_replace("{duofile-".$ftj."}",duofilex($ftj,$dvalue),$funx);     
   };//
     
     $ptnhtxt=explode("{key-",$funx);
     $totpt=count($ptnhtxt);
     for ($f=0;$f<$totpt;$f++){
       $tmpok=qian($ptnhtxt[$f],"}");
       $funx=str_replace("{key-".$tmpok."}",$arrdt[$tmpok][$dn],$funx);
     };//
     if (strpos("xxx".$sfunx,"{col-")>0){
        $kfun=array(array());
        $kfun=thekeyfun($kfun,glb(),$tbnmx,$arrdt["table"]["keys"]);                     
        $ptnhtxt=explode("{col-",$funx);
        $totpt=count($ptnhtxt);
       for ($f=0;$f<$totpt;$f++){
         $tmpok=qian($ptnhtxt[$f],"}");
         $tmpokx=qian($tmpok,":");         
         $funx=keyexc($tmpokx,$arrdt["table"]["keys"],$kfun,$funx);
       };//
      }
   $ptnhtxt=explode("{get-",$funx);
   $totpt=count($ptnhtxt);
   for ($f=0;$f<$totpt;$f++){
      $tmpok=qian($ptnhtxt[$f],"}");
      $funx=str_replace("{get-".$tmpok."}",$_GET[$tmpok],$funx);
     //$arrdt[[$tmpok][$dn]
   };//
   $ptnhtxt=explode("{post-",$funx);
   $totpt=count($ptnhtxt);
   for ($f=0;$f<$totpt;$f++){
      $tmpok=qian($ptnhtxt[$f],"}");
      $funx=str_replace("{post-".$tmpok."}",$_POST[$tmpok],$funx);
     //$arrdt[[$tmpok][$dn]
   };//
   $ptnhtxt=explode("{cookie-",$funx);
   $totpt=count($ptnhtxt);
   for ($f=0;$f<$totpt;$f++){
      $tmpok=qian($ptnhtxt[$f],"}");
      $funx=str_replace("{cookie-".$tmpok."}",$_COOKIE[$tmpok],$funx);
     //$arrdt[[$tmpok][$dn]
   };//
   $ptnhtxt=explode("{session-",$funx);
   $totpt=count($ptnhtxt);
   for ($f=0;$f<$totpt;$f++){
      $tmpok=qian($ptnhtxt[$f],"}");
      $funx=str_replace("{session-".$tmpok."}",$_SESSION[$tmpok],$funx);
     //$arrdt[[$tmpok][$dn]
   };//
     if (strpos($funx,"{atv-")>0){
       $ptatv=explode("{atv-",$funx);
       $totatv=count($ptatv);
       for ($g=0;$g<$totatv;$g++){
         $tmpatv=qian($ptatv[$g],"}");
         $funx=str_replace("{atv-".$tmpatv."}",atv($tmpatv),$funx);
       //$arrdt[[$tmpok][$dn]
      };//
   };//
  if (strpos($funx,"{utv-")>0){
    $ptutv=explode("{utv-",$funx);
    $totutv=count($ptutv);
    for ($h=0;$h<$totutv;$h++){
      $tmputv=qian($ptutv[$h],"}");
      $funx=str_replace("{utv-".$tmputv."}",utv($tmputv),$funx);
     //$arrdt[[$tmpok][$dn]
    };//
  };//
    eval($funx);
    $nhtxt=$fvalue; 
 }else{
   $sfun=turncon($sfun);
  if (strpos("x".$sfun,"{")>0 or strpos($sfun,"}")>0 ){
   $nhtxt=str_replace("{thisid}","ipt".$dkey.$dsno,$sfun);   
   $nhtxt=str_replace("{thiskey}",$dkey,$nhtxt);
   if (strpos("xxx".$nhtxt,"{col-key")>0){
        $kfun=array(array());
        $kfun=thekeyfun($kfun,glb(),$tbnmx,$arrdt["table"]["keys"]);                             
       $nhtxt=keyexc($dkey,$arrdt["table"]["keys"],$kfun,$nhtxt);
    }
   $nhtxt=str_replace("{thistable}",$tbnmx,$nhtxt);
   $grp=atv("(coode_sysdefault@companyid='".$_COOKIE["cid"]."').groupid");
   $nhtxt=str_replace("{grp}",$grp,$nhtxt);
   $nhtxt=str_replace("{thissno}",$dsno,$nhtxt);
            $nhtxt=str_replace("{SNO}",$dsno,$nhtxt);
            $nhtxt=str_replace("{key}",$dkey,$nhtxt);
            $nhtxt=str_replace("{key0}","p_".$dkey.$dsno,$nhtxt);
            $nhtxt=str_replace("{table}",$tbnmx,$nhtxt);
            $nhtxt=str_replace("{OLMK}",onlymark(),$nhtxt);
      $nhtxt=str_replace("{date}",date("Y-m-d"),$nhtxt);
       $nhtxt=str_replace("{now}",date("Y-m-d H:i:s"),$nhtxt);
   $nhtxt=str_replace("{uid}",$_COOKIE["uid"],$nhtxt);
   $nhtxt=str_replace("{posids}",$_COOKIE["posids"],$nhtxt);
   $nhtxt=str_replace("{depart}",$_COOKIE["depart"],$nhtxt);
   $nhtxt=str_replace("{dpts}",$_COOKIE["dpts"],$nhtxt);
   $nhtxt=str_replace("{cid}",$_COOKIE["cid"],$nhtxt);
   $nhtxt=str_replace("{grpcid}",$_COOKIE["grpcid"],$nhtxt);
   $nhtxt=str_replace("{appid}",$_GET["appid"],$nhtxt);
   $nhtxt=str_replace("{thisshort}",$_GET["tmpshortid"],$nhtxt);
   $nhtxt=str_replace("{thisshort}",$_GET["tmpstid"],$nhtxt);
   $nhtxt=str_replace("{shortid}",$_GET["shortid"],$nhtxt);
   $nhtxt=str_replace("{shortid}",$_GET["stid"],$nhtxt);
   $nhtxt=str_replace("{thisvalue}",tostring($dvalue),$nhtxt);
   if ($dvalue=="1" or $dvalue=="checked"){
     $nhtxt=str_replace("{checked}","checked",$nhtxt);
   }else{
     $nhtxt=str_replace("{checked}","",$nhtxt);
   };//
   if ($dvalue==""){
     $nhtxt=str_replace("{imgvalue}",dfp(),$nhtxt);
   }else{
     $nhtxt=str_replace("{imgvalue}",$dvalue,$nhtxt);
   };//
   $nhtxt=str_replace("{siteurl}",glw(),$nhtxt);
   $nhtxt=str_replace("{rip}",getip(),$nhtxt);
   $nhtxt=str_replace("{defaultbase}",glb(),$nhtxt);
   $nhtxt=str_replace("{defaultip}",gl(),$nhtxt);
   $nhtxt=str_replace("{today}",date("Y-m-d"),$nhtxt);
   $nhtxt=str_replace("{now}",date("Y-m-d H:i:s"),$nhtxt);
   //echo "<!-- find dkey=.--".$dkey."--".$nhtxt." -->";
   if (strpos("xxx".$nhtxt,"{duofile-")>0){     
     $ftj=qian(hou($nhtxt,"{duofile-"),"}");
     //echo "<!-- find duofile.--".$ftj." -->";
     $nhtxt=str_replace("{duofile-".$ftj."}",duofilex($ftj,tostring($dvalue)),$nhtxt);     
   };//
   $ptnhtxt=explode("{key-",$nhtxt);
   $totpt=count($ptnhtxt);
    //echo "totptk=".$totpt;
    // var_dump($arrdt);
   for ($f=0;$f<$totpt;$f++){
      $tmpok=qian($ptnhtxt[$f],"}");
      $nhtxt=str_replace("{key-".$tmpok."}",$arrdt[$tmpok][$dn],$nhtxt);
     //$arrdt[[$tmpok][$dn]
   };//
     if (strpos("xxx".$nhtxt,"{col-")>0){
        $kfun=array(array());
        $kfun=thekeyfun($kfun,glb(),$tbnmx,$arrdt["table"]["keys"]);                     
        $ptnhtxt=explode("{col-",$nhtxt);
        $totpt=count($ptnhtxt);       
       for ($f=0;$f<$totpt;$f++){
         $tmpok=qian($ptnhtxt[$f],"}");
         $tmpokx=qian($tmpok,":");
         $nhtxt=keyexc($tmpokx,$arrdt["table"]["keys"],$kfun,$nhtxt);
       };//
    }
   $ptnhtxt=explode("{get-",$nhtxt);
   $totpt=count($ptnhtxt);
   for ($f=0;$f<$totpt;$f++){
      $tmpok=qian($ptnhtxt[$f],"}");
      $nhtxt=str_replace("{get-".$tmpok."}",$_GET[$tmpok],$nhtxt);
     //$arrdt[[$tmpok][$dn]
   };//
   $ptnhtxt=explode("{post-",$nhtxt);
   $totpt=count($ptnhtxt);
   for ($f=0;$f<$totpt;$f++){
      $tmpok=qian($ptnhtxt[$f],"}");
      $nhtxt=str_replace("{post-".$tmpok."}",$_POST[$tmpok],$nhtxt);
     //$arrdt[[$tmpok][$dn]
   };//
   $ptnhtxt=explode("{cookie-",$nhtxt);
   $totpt=count($ptnhtxt);
   for ($f=0;$f<$totpt;$f++){
      $tmpok=qian($ptnhtxt[$f],"}");
      $nhtxt=str_replace("{cookie-".$tmpok."}",$_COOKIE[$tmpok],$nhtxt);
     //$arrdt[[$tmpok][$dn]
   };//
   $ptnhtxt=explode("{session-",$nhtxt);
   $totpt=count($ptnhtxt);
   for ($f=0;$f<$totpt;$f++){
      $tmpok=qian($ptnhtxt[$f],"}");
      $nhtxt=str_replace("{session-".$tmpok."}",$_SESSION[$tmpok],$nhtxt);
     //$arrdt[[$tmpok][$dn]
   };//
   if (strpos($nhtxt,"{atv-")>0){
    $ptatv=explode("{atv-",$nhtxt);
    $totatv=count($ptatv);
    for ($g=0;$g<$totatv;$g++){
      $tmpatv=qian($ptatv[$g],"}");
      $nhtxt=str_replace("{atv-".$tmpatv."}",atv($tmpatv),$nhtxt);
     //$arrdt[[$tmpok][$dn]
    };//
   };//
   if (strpos($nhtxt,"{utv-")>0){
     $ptutv=explode("{utv-",$nhtxt);
     $totutv=count($ptutv);
     for ($h=0;$h<$totutv;$h++){
      $tmputv=qian($ptutv[$h],"}");
      $nhtxt=str_replace("{utv-".$tmputv."}",utv($tmputv),$nhtxt);
     //$arrdt[[$tmpok][$dn]
      };//
    };//
  }else{
     $nhtxt=$sfun;//未发现里面有{  } 无法转译
  };//if sfun {  } <
 };// if FUN:
 //echo "@@@".$dvalue."----".$nhtxt;
   $nhtxt=turnlab($nhtxt);
   $_SESSION[$smd5]=$nhtxt;
   return $nhtxt;
 };//session
}
?>