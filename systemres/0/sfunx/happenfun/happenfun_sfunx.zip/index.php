<?php
$temp="";
?>