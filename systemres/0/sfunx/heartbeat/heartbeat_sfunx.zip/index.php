<?php
function pathfile($dpath){
 $tmptot=0;
 if (substr($dpath,0,1)!="/"){
   $dpath="/".$dpath;
 }
 $alist=Array();
 $flist=Array();
 $newpath=addendx(combineurl(localroot(),$dpath));
 $flist=get_file_list($newpath);
 $totf=count($flist);
 if ($totf<500){
  for ($i=0;$i<$totf;$i++){
   $filenm=$flist[$i];
   $filetype=kuozhanming($filenm);
   $extf=UX("select count(*) as result from coode_filelist where filename='".$filenm."' and filetype='".$filetype."' and lcpath='".$newpath."'");
   if ($filetype!=""){
    if (intval($extf)==0){
     $sqlx="filename,filetype,scantime,createtime,updtime,lcpath,filelcurl,fileurl,CRTM,UPTM,OLMK";
     $sqly="'$filenm','$filetype',now(),now(),now(),'$newpath','".combineurl($newpath,$filenm)."','".combineurl($dpath,$filenm)."',now(),now(),'".onlymark()."'";
     $zz=UX("insert into coode_filelist(".$sqlx.")values(".$sqly.")");
    }else{
     $zzx=UX("update coode_filelist set scantime=now(),UPTM=now() where filename='".$filenm."' and filetype='".$filetype."' and lcpath='".$newpath."'");
    }
    $alist[$tmptot]=$filenm;
    $tmptot=$tmptot+1;
   }
  }
}else{
  $zzx=UX("update coode_filelist set filesize='".$totf."' where filelcurl='".$newpath."'");
}
 $dlist=Array();
 $dlist=dirlist($newpath);
 $totd=count($dlist);
if ($totf<500){
 for ($j=0;$j<$totd;$j++){
   $dnm=lastsplit($dlist[$j],"/");
   $fdpath=addendx(combineurl($newpath,$dnm));
   $filetype="folder";
   $extd=UX("select count(*) as result from coode_filelist where filename='".$dnm."' and filetype='".$filetype."' and lcpath='".$newpath."'");
   if (intval($extd)==0){
     $sqlx="filename,filetype,scantime,createtime,updtime,lcpath,filelcurl,fileurl,CRTM,UPTM,OLMK";
     $sqly="'$dnm','$filetype',now(),now(),now(),'$newpath','".combineurl($newpath,$dnm)."','".combineurl($dpath,$dnm)."',now(),now(),'".onlymark()."'";
     $zz=UX("insert into coode_filelist(".$sqlx.")values(".$sqly.")");
   }else{
     $zzx=UX("update coode_filelist set scantime=now(),UPTM=now() where filename='".$dnm."' and filetype='".$filetype."' and lcpath='".$newpath."'");
   }
   $alist[$tmptot]=$dnm;
   $tmptot=$tmptot+1;
 }
}else{
 $zzx=UX("update coode_filelist set filesize='".$totd."' where filelcurl='".$newpath."'");
}
 $zzv=UX("update coode_filelist set typeimg=concat('/localxres/iconsetx/filetypexcool/',filetype,'.png')");
 $zzv1=UX("update coode_filelist set typeimg=fileurl where filetype='jpg' or filetype='jpeg' or filetype='png'  or filetype='gif'  or filetype='svg'");
 $zzk=UX("delete from coode_filelist where timestampdiff(minute,UPTM,now())>10 and  lcpath='".$newpath."'");
 return $alist;
}
function addotask($tatt,$turl,$anamtd){
  $sqlx="taskmark,tasktitle,taskurl,anamethod,lastscan,finishtime,requesttype,infotype,CRTM,UPTM,OLMK";
  $sqly="'".getRandChar(8)."','".$tatt."','".$turl."','".$anamtd."',now(),now(),'get','detail',now(),now(),'".onlymark()."'";
  $zz=UX("insert into coode_oncetask(".$sqlx.")values(".$sqly.")");
  return true;
}
function addptask($tatt,$turl,$anamtd,$minx){
  $sqlx="taskmark,tasktitle,taskurl,anamethod,period,lastscan,finishtime,requesttype,infotype,CRTM,UPTM,OLMK";
  $sqly="'".getRandChar(8)."','".$tatt."','".$turl."','".$anamtd."','".$minx."',now(),now(),'get','detail',now(),now(),'".onlymark()."'";
  $zz=UX("insert into coode_oncetask(".$sqlx.")values(".$sqly.")");
  return true;
}
function mlive($mcid,$mtitle){
    $extx=UX("select count(*) as result from coode_mlist where machineid='".$mcid."'");
    if (intval($extx)==0){
        $sqlx="machineid,mtitle,asktime,CRTM,OLMK";
        $sqly="'$mcid','$mtitle',now(),now(),'".onlymark()."'";
        $zz=UX("insert into coode_mlist(".$sqlx.")values(".$sqly.")");
        return true;
    }else{
        $zza=UX("update coode_mlist set asktime=now() where machineid='".$mcid."'");
        return true;
    }
}//系统扫描设备也是系统的一部分
function visitresacc($restpx,$rescdx,$vurlx,$rolex,$uidx){
 switch($restpx){
   case "fun":
   if ($rescdx!="anytiny"){
     $rescdy=qian(hou($vurlx,"tiny="),"&");
   }else{
     $ispmiss=UX("select ispmiss as result from coode_funlist where funname='".$rescdx."'");
     if (intval($ispmiss)==0){
       //不设权，看黑名单
       $extb=UX("select count(*) as result from coode_visitresaccess where listtype='black' and restype='funx' and rescode='".$rescdx."' and ('xx-,".$_COOKIE["roleids"].",' like concat('%,',roleid,',%') or uid='".$_COOKIE["uid"]."')");
       if (intval($extb)>0){
        die(makereturnjson("0","无权访问",""));
       }
     }else{
       $extw=UX("select count(*) as result from coode_visitresaccess where listtype='white' and restype='funx' and rescode='".$rescdx."' and ('xx-,".$_COOKIE["roleids"].",' like concat('%,',roleid,',%') or uid='".$_COOKIE["uid"]."')");     
       if (intval($extw)==0){
        die(makereturnjson("0","无权访问",""));
       }      
     }
   }
   break;
   case "page":
     $ispmiss=UX("select ispmiss as result from coode_tiny where '".$vurlx."' like concat('%',tinymark,'%')");
     if (intval($ispmiss)==0){
       //不设权，看黑名单
       $extb=UX("select count(*) as result from coode_visitresaccess where listtype='black' and restype='pagex' and '".$vurlx."' like concat('%',rescode,'%') and ('xx-,".$_COOKIE["roleids"].",' like concat('%,',roleid,',%') or uid='".$_COOKIE["uid"]."')");
       if (intval($extb)>0){
        $visiturl="/localxres/csspagex/404/black/failure.html";
        header("location:".$visiturl);
       }
     }else{
       $extw=UX("select count(*) as result from coode_visitresaccess where listtype='white' and restype='pagex' and '".$vurlx."' like concat('%',rescode,'%') and ('xx-,".$_COOKIE["roleids"].",' like concat('%,',roleid,',%') or uid='".$_COOKIE["uid"]."')");
       if (intval($extw)==0){
        $visiturl="/localxres/csspagex/404/black/failure.html";
        header("location:".$visiturl);
       }      
     }
   break;
   default:
 }
}
function refreshstoken($stk){
    if (runblog()==1){
      $qqq=newvisit();
    }
    $thisu=thisurl();
    $thisrtp=qian(hou($thisu,"/localxres/"),"/");
    $thisrcd=qian(hou($thisu,"/localxres/".$thisrtp."/"),"/");
    $vv=visitresacc($thisrtp,$thisrcd,$thisu,$_COOKIE["roleids"],$_COOKIE["uid"]);
    $exrst=SX("select userid,realname,depart,dpmore,posids,dpmore,wrdid,grpcid,sysid from coode_loginstoken where stoken='".$stk."' and timestampdiff(second,now(),deadline)>0");
    if (countresult($exrst)>0){
        $z=UX("update coode_loginstoken set deadline=date_add(now(),interval 60 minute) where stoken='".$stk."'");
        $userid=anyvalue($exrst,"userid",0);
        $realname=anyvalue($exrst,"realname",0);
        $depart=anyvalue($exrst,"depart",0);
        $dpmore=anyvalue($exrst,"dpmore",0);
        $posids=anyvalue($exrst,"posids",0);
        $comid=anyvalue($exrst,"wrdid",0);
        $sysid=anyvalue($exrst,"sysid",0);
        $grpcid=anyvalue($exrst,"grpcid",0);
        setcookie("uid",$userid,time()+3600,"/");
        setcookie("cid",$comid,time()+3600,"/");
        setcookie("userid",$userid,time()+3600,"/");
        setcookie("comid",$comid,time()+3600,"/");
        setcookie("grpcid",$grpcid,time()+3600,"/");
        setcookie("depart",$depart,time()+3600,"/");
        setcookie("dpmore",$dpmore,time()+3600,"/");
        setcookie("posids",$posids,time()+3600,"/");
        setcookie("sysid",$sysid,time()+3600,"/");
        setcookie("stoken",$stk,time()+3600,"/");
        $_COOKIE["uid"]=$userid;
        $_COOKIE["cid"]=$comid;
        $_COOKIE["userid"]=$userid;
        $_COOKIE["comid"]=$comid;
        $_COOKIE["grpcid"]=$grpcid;
        $_COOKIE["depart"]=$depart;
        $_COOKIE["dpmore"]=$dpmore;
        $_COOKIE["posids"]=$posids;
        $_COOKIE["sysid"]=$sysid;
        $_COOKIE["stoken"]=$stk;
        return true;
    }else{
        return false;
    }
    
}
function datatohost($hostdurl,$thisstid,$sttp){
 $hosturlz=combineurl($hostdurl,"/?ak=".gla()."&av=".glv());
 eval(RESFUNSET("tabbaseinfo"));
 if ($sttp==""){
  $strst=SX("select shortid,showkeys,tablename from coode_shortdata where shortid='".$thisstid."'");
  $shortid=anyvalue($strst,"shortid",0);
  $showks=anyvalue($strst,"showkeys",0);
  $tabnmx=anyvalue($strst,"tablename",0);
  $tabrst=SX("select SNO,srckey,createsql from coode_tablist where TABLE_NAME='".$tabnmx."'");
  $tabsno=anyvalue($tabrst,"SNO",0);
  $srckey=anyvalue($tabrst,"srckey",0);
  $crtsql=anyvalue($tabrst,"createsql",0);
  if (es($shortid)*es($showks)*es($tabnmx)*es($tabsno)*es($srckey)==1){
    $dbmarky="thishostcore";
    $tabnmy=$tabnmx;
    $hostkeyy=$showks;
    $jsonkeyy=$showks;
    $jsonreskeyy=$srckey;
    $jsondatay=anyshort($thisstid,"1","9999");   
    $zz=jsondatatohost($hosturlz,$dbmarky,$tabnmy,$crtsql,$hostkeyy,$jsondatay,$jsonkeyy,$jsonreskeyy);
    return true;
  }else{
    return false; 
  } 
 }else{
  $strst=SX("select catalog,shortid,showkeys,tablename from coode_dbshort where shortid='".$thisstid."'");
  $catalog=anyvalue($strst,"catalog",0);
  $shortid=anyvalue($strst,"shortid",0);
  $showks=anyvalue($strst,"showkeys",0);
  $tabnmx=anyvalue($strst,"tablename",0);
  $tabrst=SX("select SNO,srckey,createsql from coode_dbtablist where TABLE_NAME='".$tabnmx."' and catalog='".$catalog."'");
  $tabsno=anyvalue($tabrst,"SNO",0);
  $srckey=anyvalue($tabrst,"srckey",0);
  $crtsql=anyvalue($tabrst,"createsql",0);
  if (es($shortid)*es($showks)*es($tabnmx)*es($tabsno)*es($srckey)==1){
     
      $dinfo=array();     
      $dinfo=takedbinfo($catalog,$tabnmx,$dinfo);
      $dbnmx=$dinfo["dbnm"];
      $dbip=$dinfo["fip"];
      $dbuser=$dinfo["fuser"];
      $dbpass=$dinfo["fpass"];
      $dbbase=$dinfo["fbase"];
      $dbmarky=$catalog;
      $tabnmy=$tabnmx;
      $hostkeyy=$showks;
      $jsonkeyy=$showks;
      $jsonreskeyy=$reskey;
      $jsondatay=anyshort($thisstid,"1","9999");
      $zz=jsondatatohost($hosturlz,$dbmarky,$tabnmy,$crtsql,$hostkeyy,$jsondatay,$jsonkeyy,$jsonreskeyy);
      return true;
   }else{
      return false;
   }
 }
} 
function hosttodata($hostdm,$thisstid,$sttp){
 if ($sttp==""){
  $strst=SX("select shortid,showkeys,tablename from coode_shortdata where shortid='".$thisstid."'");
  $catalog="thishostcore";
  $shortid=anyvalue($strst,"shortid",0);
  $showks=anyvalue($strst,"showkeys",0);
  $tabnmx=anyvalue($strst,"tablename",0);
  $tabrst=SX("select SNO,srckey,createsql from coode_tablist where TABLE_NAME='".$tabnmx."'");
  $tabsno=anyvalue($tabrst,"SNO",0);
  $srckey=anyvalue($tabrst,"srckey",0);
  $crtsql=anyvalue($tabrst,"createsql",0); 
 }else{
  $strst=SX("select catalog,shortid,showkeys,tablename from coode_dbshort where shortid='".$thisstid."'");
  $catalog=anyvalue($strst,"catalog",0);
  $shortid=anyvalue($strst,"shortid",0);
  $showks=anyvalue($strst,"showkeys",0);
  $tabnmx=anyvalue($strst,"tablename",0);
  $tabrst=SX("select SNO,srckey,createsql from coode_dbtablist where TABLE_NAME='".$tabnmx."' and catalog='".$catalog."'");
  $tabsno=anyvalue($tabrst,"SNO",0);
  $srckey=anyvalue($tabrst,"srckey",0);
  $crtsql=anyvalue($tabrst,"createsql",0);
 }
 $leiji="";
 $stidx=getstidbyplan($hostdm,$catalog,$tabnmx,$showks,$srckey);
 $leiji=$hostdm."---".$catalog."---".$tabnmx."---".$showks."---".$srckey."gogog@".$stidx."@@@";
 if ($stidx!=""){
   $jsonurlx=combineurl("http://".$hostdm,"/localxres/funx/anyshort/?stid=".$stidx."&dbmk=".$catalog);
   $hearkeyy=$showks;      
   $bb=hostdatadown($jsonurlx,$catalog,$tabnmx,$showks,$showks,$srckey);
   //$jsonurlx.":::".
   return true;
 }else{   
   return false;
 }
}
function killhostdata($hostdm,$dbmk,$tabnm,$tabsno){  
  $strst=SX("select dbmark,dbtabnm,thiskeys,reskeys from coode_clientdataplan where dbmark='".$dbmk."' and dbtabnm='".$tabnm."' and chostrole like '%".$hostdm."%'");
  $catalog="thishostcore";
  $shortid=anyvalue($strst,"shortid",0);
  $showks=anyvalue($strst,"thiskeys",0);  
  $srckey=anyvalue($strst,"reskeys",0);
  $stidx=getstidbyplan($hostdm,$dbmk,$tabnm,$showks,$srckey);
 if (strlen($stidx)<10 and $stidx!=""){
      eval(RESFUNSET("tabbaseinfo"));
      $dinfo=array();     
      $dinfo=takedbinfo($dbmk,$tabnm,$dinfo);
      $dbnmx=$dinfo["dbnm"];
      $dbip=$dinfo["fip"];
      $dbuser=$dinfo["fuser"];
      $dbpass=$dinfo["fpass"];
      $dbbase=$dinfo["fbase"];
      $pssno=$dinfo["pssno"];
      $psolmk=$dinfo["psolmk"];
     if ($dbmk=="" or $dbmk=="thishostcore"){
       $olmkv=UX("select ".$psolmk." as result from ".$tabnm." where ".$pssno."=".$tabsno);
     }else{
       $conn=mysql_connect($dbip,$dbuser,$dbpass);
       $olmkv=updatings($conn,$dbbase,"select ".$psolmk." as result from ".$tabnm." where ".$pssno."=".$tabsno,"utf8");
     }   
   $murlx=combineurl("http://".$hostdm,"/localxres/funx/clientkilldata/?ak=".gla()."&av=".glv()."&dbmk=".$dbmk."&stid=".$stidx."&tabolmk=".$olmkv);
   $mx=$murlx;
   $bktxt=file_get_contents($murlx);
   $bkdata=json_decode($bktxt,false);
   if (intval($bkdata->status)>0){
     return $bkdata->redirect;
   }else{
     return false;
   }
 }else{
   return false;
 }
}
function KAFB($dbmkx,$tbsno,$tanm,$tbnm,$expstr){
   if (es($tbsno)*es($tanm)*es($tbnm)*es($expstr)==1){
      eval(RESFUNSET("tabbaseinfo"));
      $dinfo=array();     
      $dinfo=takedbinfo(dftval($dbmkx,"thishostcore"),$tbnm,$dinfo);
      $dbnmx=$dinfo["dbnm"];
      $dbip=$dinfo["fip"];
      $dbuser=$dinfo["fuser"];
      $dbpass=$dinfo["fpass"];
      $dbbase=$dinfo["fbase"];
      $pssno=$dinfo["pssno"];
      $psolmk=$dinfo["psolmk"];
      $fma="";
      $fmb="";
      $onlyone=0;
      if (strpos($expstr,"&")>0){
        $ptcdt=explode("&",$expstr);
        for ($zz=0;$zz<count($ptcdt);$zz++){     
          $kq=qian($ptcdt[$zz],"=");
          $vh=hou($ptcdt[$zz],"=");
          if ($vh!="" and $kq!=""){
           $fma=$fma.$kq.",";
           $fmb=$fmb.$vh.",";
          }
        }
        $fma=killlaststr($fma);
        $fmb=killlaststr($fmb);
      }else{
          $kq=qian($expstr,"=");
          $vh=hou($expstr,"=");
           $fma=$fma.$kq;
           $fmb=$fmb.$vh;
           $onlyone=1;
      }
      if ($pssno!=""){
        $conn=mysql_connect($dbip,$dbuser,$dbpass);
        if ($onlyone==1){
           $zz=updatings($conn,$dbbase,"delete from ".$tanm." where ".$fma." in (select ".$fmb." from ".$tbnm." where ".$pssno."='".$tbsno."')","utf8");
        }else{
           $zz=updatings($conn,$dbbase,"delete from ".$tanm." where concat(".$fma.") in (select concat(".$fmb.") from ".$tbnm." where ".$pssno."='".$tbsno."')","utf8");
        }
        return true;
      }else{
        return false;
      }
    }else{
      return false;
    }
}
?>