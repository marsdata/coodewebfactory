<?php
function changeist($strx){
  if (strpos($strx,"('")>0 ){
    $ptist=explode("('",$strx);
    $totpt=count($ptist);
    for ($i=0;$i<$totpt;$i++){
      $tmppt=qian($ptist[$i],"')");
      $tmppx=qian($ptist[$i],"')");
      $tmppt=str_replace("∨","','",$tmppt);
      $strx=str_replace("('".$tmppx."')","('".$tmppt."')",$strx);
    };
    return $strx;
  }else{
    return $strx;
  }
}
function runinstall($x,$y,$z,$i){ 
 if ($z!=""){  
   $sysid=$_GET["sysid"];
   $z=$z."@@@@";
   $ptz=explode("@@@@",$z);
   $totp=count($ptz);
   $succ=0;
   $xyz="";
   $abc="";
  for ($i=0;$i<$totp;$i++){
   if ($ptz[$i]!=""){
    $tmpq=qian($ptz[$i],"/");    
    $fcid=qian(hou($ptz[$i],"/"),":");
    $tmph=hou($ptz[$i],":"); 
    switch($tmpq){
      case "CREATE":
      
      $tmptab=qian(hou($ptz[$i],"/"),":");      
      if (_get("drop")=="1"){
          $conn=mysql_connect(gl(),glu(),glp());
          $extx=updatingx($conn,glb(),"DROP TABLE IF EXISTS ".$tmptab,"utf8");
      }
      $conn=mysql_connect(gl(),glu(),glp());
      $extx=updatingx($conn,"information_schema","select count(*) as result from TABLES where TABLE_NAME='".$tmptab."' and TABLE_SCHEMA='".glb()."'","utf8");      
        if (intval($extx)==0){         
         if ($tmph!=""){
           $z=maketabpmt($tmptab,$sysid);
           $conn=mysql_connect(gl(),glu(),glp());            
           $x=updatingx($conn,glb(),$tmph,"utf8");           
           $conn=mysql_connect(gl(),glu(),glp());           
           $extj=updatingx($conn,"information_schema","select count(*) as result from TABLES where TABLE_NAME='".$tmptab."'  and TABLE_SCHEMA='".glb()."'","utf8");
           if (intval($extj)>0){
            $succ=$succ+1;
             $abc=$abc."crttable:".$tmptab.";";
           }else{
             $xyz=$xyz."crttable:".$tmptab.";";
           }
         }else{           
           $succ=$succ+1;
         }
        }else{
           $succ=$succ+1;
        }
      break;
      case "fun":
        $z=makefunpmt($fcid,$sysid);
        if (datatofun($fcid,$tmph,$i)){
          $succ=$succ+1;
          $abc=$abc."crtfun:".$fcid.";";
        }else{
          $xyz=$xyz."crtfun:".$fcid.";";
        }
      break;
      case "cls":        
        if (datatocls($fcid,$tmph,$i)){
          $succ=$succ+1;
          $abc=$abc."crtcls:".$fcid.";";
        }else{
          $xyz=$xyz."crtcls:".$fcid.";";
        }
      break;
      default:
       if (strpos("xxx".$tmpq,"insert")>0){
           $tmptab=qian(hou($ptz[$i],"/"),"----");
           $tmptolmk=qian(hou($ptz[$i],"----"),":");
         if (_get("drop")=="1"){
          $conn=mysql_connect(gl(),glu(),glp());
          $etx=updatingx($conn,glb(),"delete from ".$tmptab." where OLMK='".$tmptolmk."'","utf8");
         }
         $extj=UX("select count(*) as result from ".$tmptab." where OLMK='".$tmptolmk."'");
         if (intval($extj)==0){
           if ($tmph!=""){
             $tmph=changeist($tmph);
             $tmph=str_replace("'","\\'",$tmph);
             $tmpq=str_replace("[DATA]",$tmph,$tmpq);        
             $tmpq=str_replace("∨","','",$tmpq);
             $tmpq=str_replace("〖","'",$tmpq);
             $tmpq=str_replace("〗","'",$tmpq);
             $conn=mysql_connect(gl(),glu(),glp());
             $x=updatingx($conn,glb(),$tmpq,"utf8");                          
             $exti=UX("select count(*) as result from ".$tmptab." where OLMK='".$tmptolmk."'");             
             if (intval($exti)>0){
              $succ=$succ+1;
               $abc=$abc.$tmptab.":".$tmptolmk.";";
             }else{
               $xyz=$xyz.$tmptab.":".$tmptolmk."{".$tmpq."};";
             };    
           }else{             
             $succ=$succ+1;
             $abc=$abc.$tmptab.":".$tmptolmk.";";
           }
          }else{
            $succ=$succ+1;
            $abc=$abc.$tmptab.":".$tmptolmk.";";
          }
        }else{
         $succ=$succ+1;          
        }
    }; //switch
   }else{
     $succ=$succ+1; 
   };//ifptz
  };//for
  if ($succ>=$totp){
    return "1:succ-".$succ."/".$totp."----SUCCESS/".$abc."FAILURE/".$xyz;
  }else{         
    return "0:fail-".$succ."/".$totp."----SUCCESS/".$abc."FAILURE/".$xyz;
  }
 }else{                  
   return "1:null";
 }        
}//DESCRIB ():  END@()
?>