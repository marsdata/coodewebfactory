<?php
function thekeyfun($kbase=array(array()),$dbmk,$tbnm,$keys){
if ($tbnm!="SHORTID" and $tbnm!="shortid"){
  if ($dbmk=="" or $dbmk=="thishostcore" or $dbmk==glb()){
   if ($keys=="*" or $keys==""){
    $krest=SX("select COLUMN_NAME,COLUMN_TYPE,COLUMN_DEFAULT,classp,keytitle,keyexplain,acthtml,atnhtml,valuezero,jsshowfun,jspostfun,sysshowfun,syspostfun,changeable,displayed,clstxt,bfist,aftist,bfupd,aftupd,bfdel,aftdel,thcode,tdcode,dxtype,SQX,VQX,keyexplain,PRIME,parallelto,isfixed from coode_keydetailx where TABLE_SCHEMA='".glb()."' and TABLE_NAME='".$tbnm."' ");
   }else{
    $krest=SX("select COLUMN_NAME,COLUMN_TYPE,COLUMN_DEFAULT,classp,keytitle,keyexplain,acthtml,atnhtml,valuezero,jsshowfun,jspostfun,sysshowfun,syspostfun,changeable,displayed,clstxt,bfist,aftist,bfupd,aftupd,bfdel,aftdel,thcode,tdcode,dxtype,SQX,VQX,keyexplain,PRIME,parallelto,isfixed from coode_keydetailx where TABLE_SCHEMA='".glb()."' and TABLE_NAME='".$tbnm."' and ',".$keys.",SNO,' like concat('%,',COLUMN_NAME,',%')");
   };
  }else{
   if ($keys=="*" or $keys==""){
    $krest=SX("select COLUMN_NAME,COLUMN_TYPE,COLUMN_DEFAULT,classp,keytitle,keyexplain,acthtml,atnhtml,valuezero,jsshowfun,jspostfun,sysshowfun,syspostfun,changeable,displayed,clstxt,bfist,aftist,bfupd,aftupd,bfdel,aftdel,thcode,tdcode,dxtype,SQX,VQX,keyexplain,PRIME,parallelto,isfixed from coode_dbkeydx where TABLE_CATALOG='".$dbmk."' and TABLE_NAME='".$tbnm."' ");
   }else{
    $krest=SX("select COLUMN_NAME,COLUMN_TYPE,COLUMN_DEFAULT,classp,keytitle,keyexplain,acthtml,atnhtml,valuezero,jsshowfun,jspostfun,sysshowfun,syspostfun,changeable,displayed,clstxt,bfist,aftist,bfupd,aftupd,bfdel,aftdel,thcode,tdcode,dxtype,SQX,VQX,keyexplain,PRIME,parallelto,isfixed from coode_dbkeydx where TABLE_CATALOG='".$dbmk."' and TABLE_NAME='".$tbnm."' and ',".$keys.",SNO,' like concat('%,',COLUMN_NAME,',%')");
   }; 
  }
  $stid="";
}else{
    
   if ($dbmk=="" or $dbmk=="thishostcore" or $dbmk==glb()){
     $krest=SX("select TABLE_NAME,COLUMN_NAME,COLUMN_TYPE,COLUMN_DEFAULT,classp,keytitle,keyexplain,acthtml,atnhtml,jsshowfun,jspostfun,valuezero,sysshowfun,syspostfun,changeable,displayed,clstxt,bfist,aftist,bfupd,aftupd,bfdel,aftdel,thcode,tdcode,dxtype,SQX,VQX,keyexplain,PRIME,parallelto,isfixed from coode_keydetaily where TABLE_SCHEMA='".glb()."' and shortid='".$keys."' order by SQX"); 
     $tbnm=anyvalue($krest,"TABLE_NAME",0);
     $stid=$keys;
   }else{            
     $krest=SX("select TABLE_NAME,COLUMN_NAME,COLUMN_TYPE,COLUMN_DEFAULT,classp,keytitle,keyexplain,acthtml,atnhtml,jsshowfun,jspostfun,valuezero,sysshowfun,syspostfun,changeable,displayed,clstxt,bfist,aftist,bfupd,aftupd,bfdel,aftdel,thcode,tdcode,dxtype,SQX,VQX,keyexplain,PRIME,parallelto,isfixed from coode_dbkeydy where TABLE_CATALOG='".$dbmk."' and shortid='".$keys."' order by SQX","utf8","");         
     $tbnm=anyvalue($krest,"TABLE_NAME",0);
     $stid=$keys;
   }
}
  $fromu=$_SERVER['HTTP_REFERER'];
  $getlayid="";
  $gettinyid="";
  if (strpos($fromu,"layid=")>0){
      $getlayid=qian(hou($fromu,"layid="),"&");
  }
  if (strpos($fromu,"tinyid=")>0){
      $gettinyid=qian(hou($fromu,"tinyid="),"&");
  }
  $totkc=countresult($krest);
  $dd=$tbnm."kbase=new Array();\r\n";
  $dd=$dd.$tbnm."kbase[\"COLUMN\"]=new Array();\r\n";
 for ($c=0;$c<$totkc;$c++){
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"]=new Array();\r\n";
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_TYPE"]=anyvalue($krest,"COLUMN_TYPE",$c);
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_TYPE\"]=\"".anyvalue($krest,"COLUMN_TYPE",$c)."\";\r\n";    
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_TITLE"]=anyvalue($krest,"keytitle",$c);
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_TITLE\"]=\"".anyvalue($krest,"keytitle",$c)."\";\r\n";    
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_CLASSP"]=anyvalue($krest,"classp",$c);
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_CLASSP\"]=\"".anyvalue($krest,"classp",$c)."\";\r\n";    
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_DEFAULT"]=tostring(anyvalue($krest,"COLUMN_DEFAULT",$c));
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_DEFAULT\"]=\"".str_replace("\"","\\\"",anyvalue($krest,"COLUMN_DEFAULT",$c))."\";\r\n";    
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_ACTHTM"]=tostring(anyvalue($krest,"acthtml",$c));
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_ACTHTM\"]=\"".str_replace("\"","\\\"",anyvalue($krest,"acthtml",$c))."\";\r\n";    
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_ATNHTM"]=tostring(anyvalue($krest,"atnhtml",$c));
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_ATNHTM\"]=\"".str_replace("\"","\\\"",anyvalue($krest,"atnhtml",$c))."\";\r\n";    
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_JSHOW"]=tostring(anyvalue($krest,"jsshowfun",$c));
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_JSHOW\"]=\"".str_replace(huanhang(),"",str_replace("\"","\\\"",anyvalue($krest,"jsshowfun",$c)))."\";\r\n";    
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_JPOST"]=tostring(anyvalue($krest,"jspostfun",$c));
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_JPOST\"]=\"".str_replace("\"","\\\"",anyvalue($krest,"jspostfun",$c))."\";\r\n";    
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_SSHOW"]=tostring(anyvalue($krest,"sysshowfun",$c));
    if (strpos(tostring(anyvalue($krest,"sysshowfun",$c)),"unction ")>0){
        $dd=$dd.tostring(anyvalue($krest,"sysshowfun",$c))."\r\n";
    }
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_SSHOW\"]=\"".str_replace(huanhang(),"",str_replace("\"","\\\"",anyvalue($krest,"sysshowfun",$c)))."\";\r\n";
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_THCODE"]=tostring(anyvalue($krest,"thcode",$c));
    if (strpos(tostring(anyvalue($krest,"thcode",$c)),"unction ")>0){
        $dd=$dd.tostring(anyvalue($krest,"thcode",$c))."\r\n";
    }
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_THCODE\"]=\"".str_replace("\"","\\\"",anyvalue($krest,"thcode",$c))."\";\r\n";
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_TDCODE"]=tostring(anyvalue($krest,"tdcode",$c));
    if (strpos(tostring(anyvalue($krest,"tdcode",$c)),"unction ")>0){
        $dd=$dd.tostring(anyvalue($krest,"tdcode",$c))."\r\n";
    }
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_TDCODE\"]=\"".str_replace("\"","\\\"",anyvalue($krest,"tdcode",$c))."\";\r\n";
    //echo tostring(anyvalue($krest,"sysshowfun",$c));//sdfsdf
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_VALUEZERO"]=tostring(anyvalue($krest,"valuezero",$c));
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_VALUEZERO\"]=\"".str_replace("\"","\\\"",anyvalue($krest,"valuezero",$c))."\";\r\n";
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_SPOST"]=tostring(anyvalue($krest,"syspostfun",$c));
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_SPOST\"]=\"".anyvalue($krest,"syspostfun",$c)."\";\r\n";    
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_CANGE"]=tostring(anyvalue($krest,"changeable",$c));
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_CANGE\"]=\"".anyvalue($krest,"changeable",$c)."\";\r\n";       
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_DSPLD"]=tostring(anyvalue($krest,"displayed",$c));   
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_DSPLD\"]=\"".anyvalue($krest,"displayed",$c)."\";\r\n";    
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_DXTYPE"]=tostring(anyvalue($krest,"dxtype",$c));
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_DXTYPE\"]=\"".anyvalue($krest,"dxtype",$c)."\";\r\n";    
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_SQX"]=tostring(anyvalue($krest,"SQX",$c));
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_SQX\"]=\"".anyvalue($krest,"SQX",$c)."\";\r\n";
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_VQX"]=tostring(anyvalue($krest,"VQX",$c));
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_VQX\"]=\"".anyvalue($krest,"VQX",$c)."\";\r\n";
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_PARALLELTO"]=tostring(anyvalue($krest,"parallelto",$c));
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_PARALLELTO\"]=\"".anyvalue($krest,"parallelto",$c)."\";\r\n";    
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_EXPLAIN"]=tostring(anyvalue($krest,"keyexplain",$c));
    $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_EXPLAIN\"]=\"".anyvalue($krest,"keyexplain",$c)."\";\r\n";    
   //echo "ccc-".$c."---".anyvalue($krest,"COLUMN_NAME",$c).tostring(anyvalue($krest,"dxtype",$c));
    $tmpxclstxt=anyvalue($krest,"clstxt",$c);
    if (strpos($tmpxclstxt,"]")>0 and strpos($tmpxclstxt,"key")<=0 ){//key-为取表格行中值 则返回原代码
      $tmpxclstxt=str_replace("[","",$tmpxclstxt);
      $tmpxclstxt=str_replace("]","",$tmpxclstxt);
      $newonex=$tmpxclstxt;
      $newoney=anyshort($newonex,"","");
      //if ($newonex=="5Opeqq"){
        //  $newoney=$newoney."--wocao--".$_COOKIE["cid"];
      //}
      $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_CLSTXT"]=$newonex;
      $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_CLSTXT\"]=\"".$newoney."\";\r\n";    
      //echo $tmpxclstxt."---".anyshort($tmpxclstxt,"","");
    }else{
     $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_CLSTXT"]=anyvalue($krest,"clstxt",$c);
     $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_CLSTXT\"]=\"".$tmpxclstxt."\";\r\n";    
    }
    
           $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_BFIST"]=tostring(anyvalue($krest,"bfist",$c));
           $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_BFIST\"]=\"\";\r\n";    
           $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_AFTIST"]=tostring(anyvalue($krest,"aftist",$c));
           $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_AFTIST\"]=\"\";\r\n";    
           $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_BFUPD"]=tostring(anyvalue($krest,"bfupd",$c));
           $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_BFUPD\"]=\"\";\r\n";    
           $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_AFTUPD"]=tostring(anyvalue($krest,"aftupd",$c));
           $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_AFTUPD\"]=\"\";\r\n";    
           $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_BFDEL"]=tostring(anyvalue($krest,"bfdel",$c));
           $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_BFDEL\"]=\"\";\r\n";    
           $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_AFTDEL"]=tostring(anyvalue($krest,"aftdel",$c));
           $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_AFTDEL\"]=\"\";\r\n";    
          if (intval(anyvalue($krest,"PRIME",$c))==1){
                  $kyrst=SX("select bfist,aftist,bfupd,aftupd,bfdel,aftdel from coode_keydetaily where COLUMN_NAME='".anyvalue($krest,"COLUMN_NAME",$c)."' and shortid='".$tbnm."'");
                 $bfisty=tostring(anyvalue($kyrst,"bfist",0));
                 $aftisty=tostring(anyvalue($kyrst,"aftist",0));
                 $bfupdy=tostring(anyvalue($kyrst,"bfupd",0));
                 $aftupdy=tostring(anyvalue($kyrst,"aftupd",0));
                 $bfdely=tostring(anyvalue($kyrst,"bfdel",0));
                 $aftdely=tostring(anyvalue($kyrst,"aftdel",0));
                 $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_OBFIST"]=$bfisty;
                 $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_OAFTIST"]=$aftisty;
                 $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_OBFUPD"]=$bfupdy;
                 $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_OAFTUPD"]=$aftupdy;
                 $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_OBFDEL"]=$bfdely;
                 $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_OAFTDEL"]=$aftdely;
          }else{
            $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_OBFIST"]="";
            $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_OAFTIST"]="";
            $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_OBFUPD"]="";
            $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_OAFTUPD"]="";
            $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_OBFDEL"]="";
            $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_OAFTDEL"]="";
          }
    
    $kbase["COLUMN"][$c]=anyvalue($krest,"COLUMN_NAME",$c);
     $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][".$c."]=\"".anyvalue($krest,"COLUMN_NAME",$c)."\";\r\n";    
      if (strpos(anyvalue($krest,"COLUMN_TYPE",$c),"(")>0){
       $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_TPNM"]=qian(anyvalue($krest,"COLUMN_TYPE",$c),"(");
       $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_TPNM\"]=\"".qian(anyvalue($krest,"COLUMN_TYPE",$c),"(")."\";\r\n";    
       $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_TPLEN"]=qian(hou(anyvalue($krest,"COLUMN_TYPE",$c),"("),")");
       $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_TPLEN\"]=\"".qian(hou(anyvalue($krest,"COLUMN_TYPE",$c),"("),")")."\";\r\n";    
        
        if ($kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_TPLEN"]>=50 || $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_CLSTXT"]!="" || $kbase["COLUMN"][$c]=="SNO" ){
         if (strpos("x".$kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_CLSTXT"],"union-")<=0 && strpos("x".$kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_CLSTXT"],"TYPE_HEX")<=0){
          $fmfrm=$fmfrm."+".anyvalue($krest,"COLUMN_NAME",$c)."+";
         }else{
          $fmfrm=$fmfrm."*".anyvalue($krest,"COLUMN_NAME",$c); //最后++,*+合并成 +
         };
        }else{
         $fmfrm=$fmfrm."*".anyvalue($krest,"COLUMN_NAME",$c); //最后++,*+合并成 +
        };
      }else{
       $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_TPNM"]=anyvalue($krest,"COLUMN_TYPE",$c);
        $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_TPNM\"]=\"".anyvalue($krest,"COLUMN_TYPE",$c)."\";\r\n";    
       $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_TPLEN"]="0";
        $dd=$dd.$tbnm."kbase[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_TPLEN\"]=\"0\";\r\n";    
        if ( $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_CLSTXT"]!="" ){
         if (strpos("x".$kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_CLSTXT"],"union-")<=0 && strpos("x".$kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_CLSTXT"],"TYPE_HEX")<=0){
          $fmfrm=$fmfrm."+".anyvalue($krest,"COLUMN_NAME",$c)."+";
         }else{
          $fmfrm=$fmfrm."*".anyvalue($krest,"COLUMN_NAME",$c); //最后++,*+合并成 +
         };
        }else{
         $fmfrm=$fmfrm."*".anyvalue($krest,"COLUMN_NAME",$c); //最后++,*+合并成 +
        };
      };
   
  // echo "kbase-".$kbase["COLUMN"][$c];
 };
  $fmfrm=$fmfrm."+";
  $fmfrm=str_replace("*+","+",$fmfrm);
  $fmfrm=str_replace("+*","+",$fmfrm);
  $fmfrm=str_replace("++","+",$fmfrm);
  $kbase["COLUMN"]["SEQUENCE"]=$fmfrm;
  $dd=$dd.$tbnm."kbase[\"COLUMN\"][\"SEQUENCE\"]=\"".$fmfrm."\";\r\n";    
  $kbase["COLUMN"]["COUNT"]=$totkc;
  $dd=$dd.$tbnm."kbase[\"COLUMN\"][\"COLUMN_TPLEN\"]=\"".$totkc."\";\r\n";    
  $kbase["COLUMN"]["READONLY"]=$_GET['readonly'];
  $dd=$dd.$tbnm."kbase[\"COLUMN\"][\"READONLY\"]=\"".$_GET['readonly']."\";\r\n";    
  $kbase["CODE"]["JS"]=$dd;
  $kbase["TABLE"]["NAME"]=$tbnm;
  $kbase["SHORT"]["NAME"]=$stid;
  return $kbase;
}
?>