<?php
function allkeyinfo($kbase=array(array()),$dbmk,$tbnm){
//NEED FUNCTION -selecteds() @ connmysql.php;
  eval(RESFUNSET("tabbaseinfo"));
  if ($dbmk=="" or $dbmk==glb() or $dbmk=="thishostcore"){
    $conn=mysql_connect(gl(),glu(),glp());
    $krest=selectedx($conn,"information_schema","select TABLE_NAME,COLUMN_NAME,COLUMN_TYPE from COLUMNS where ',".$tbnm.",' like concat('%',TABLE_NAME,'%') and TABLE_SCHEMA='".$dbnm."'","utf8","");
  }else{
    $dinfo=array();
    $dinfo=takedbinfo($dbmk,$tbnm,$dinfo);
    $ffip=$dinfo["fip"];
    $fuser=$dinfo["fuser"];
    $fpass=$dinfo["fpass"];
    $fbase=$dinfo["fbase"];
    $conn=mysql_connect($ffip,$fuser,$fpass); 
    $krest=selectedx($conn,"information_schema","select TABLE_NAME,COLUMN_NAME,COLUMN_TYPE from COLUMNS where ',".$tbnm.",' like concat('%',TABLE_NAME,'%') and TABLE_SCHEMA='".$fbase."'","utf8","");  
  }
 //NEED FUNCTION -countresult() @ connmysql.php;
 $totkc=countresult($krest);
 $dd=$tbnm."akb=new Array();\r\n";
 $fmakeys="";
 $fmakeysb="";
  $dd=$dd.$tbnm."akb[\"COLUTB\"]=new Array();\r\n";
  $dd=$dd.$tbnm."akb[\"COLUMN\"]=new Array();\r\n";
  for ($c=0;$c<$totkc;$c++){
    $dd=$dd.$tbnm."akb[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"]=new Array();\r\n";
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_TYPE"]=anyvalue($krest,"COLUMN_TYPE",$c);
    $dd=$dd.$tbnm."akb[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_TYPE\"]=\"".anyvalue($krest,"COLUMN_TYPE",$c)."\";\r\n";
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_TPNM"]=qian(anyvalue($krest,"COLUMN_TYPE",$c),"(");
    $dd=$dd.$tbnm."akb[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_TPNM\"]=\"".qian(anyvalue($krest,"COLUMN_TYPE",$c),"(")."\";\r\n";
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_TPLEN"]=qian(hou(anyvalue($krest,"COLUMN_TYPE",$c),"("),")");
    $dd=$dd.$tbnm."akb[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_TPLEN\"]=\"".qian(hou(anyvalue($krest,"COLUMN_TPLEN",$c),"("),")")."\";\r\n";
    $kbase["COLUTB"][$c]=anyvalue($krest,"TABLE_NAME",$c);
    $dd=$dd.$tbnm."akb[\"COLUTB\"][".$c."]=\"".anyvalue($krest,"TABLE_NAME",$c)."\";\r\n";
    $kbase["COLUMN"][$c]=anyvalue($krest,"COLUMN_NAME",$c);
    $dd=$dd.$tbnm."akb[\"COLUMN\"][".$c."]=\"".anyvalue($krest,"COLUMN_NAME",$c)."\";\r\n";
    $fmakeys=$fmakeys.anyvalue($krest,"COLUMN_NAME",$c).",";
    $fmakeysb=$fmakeysb.anyvalue($krest,"TABLE_NAME",$c).".".anyvalue($krest,"COLUMN_NAME",$c).",";
 };
 $fmakeys=substr($fmakeys,0,strlen($fmakeys)-1);
 $fmakeysb=substr($fmakeysb,0,strlen($fmakeysb)-1);
 $kbase["COLUMN"]["COUNT"]=$totkc;
  $dd=$dd.$tbnm."akb[\"COLUMN\"][\"COUNT\"]=".$totkc.";\r\n";
 $kbase["COLUMN"]["ALLKEY"]=$fmakeys;
  $dd=$dd.$tbnm."akb[\"COLUMN\"][\"ALLKEY\"]=\"".$fmakeys."\";\r\n";
 $kbase["COLUMN"]["ALLTKEY"]=$fmakeysb;
  $dd=$dd.$tbnm."akb[\"COLUMN\"][\"ALLTKEY\"]=\"".$fmakeysb."\";\r\n";
 $kbase["CODE"]["JS"]=$dd;
return $kbase;
}
function thekeyinfo($kbase=array(array()),$dbmk,$tbnm,$keys){
 
//NEED FUNCTION -selecteds() @ connmysql.php;
$dd=$tbnm."kb=new Array();\r\n";
eval(RESFUNSET("tabbaseinfo"));
if ($dbmk=="" or $dbmk==glb() or $dbmk=="thishostcore"){
  $conn=mysql_connect(gl(),glu(),glp());
  if ($keys=="*"){
    $krest=selectedx($conn,"information_schema","select COLUMN_NAME,COLUMN_TYPE from COLUMNS where TABLE_SCHEMA='".$dbnm."' and TABLE_NAME='".$tbnm."' ","utf8","");
  }else{
    $krest=selectedx($conn,"information_schema","select COLUMN_NAME,COLUMN_TYPE from COLUMNS where TABLE_SCHEMA='".$dbnm."' and TABLE_NAME='".$tbnm."' and ',".$keys.",' like concat('%,',COLUMN_NAME,',%')","utf8","");
  }
}else{
    $dinfo=array();
    $dinfo=takedbinfo($dbmk,$tbnm,$dinfo);
    $ffip=$dinfo["fip"];
    $fuser=$dinfo["fuser"];
    $fpass=$dinfo["fpass"];
    $fbase=$dinfo["fbase"];
    $conn=mysql_connect($ffip,$fuser,$fpass); 
  if ($keys=="*"){
    $krest=selectedx($conn,"information_schema","select COLUMN_NAME,COLUMN_TYPE from COLUMNS where TABLE_SCHEMA='".$fbase."' and TABLE_NAME='".$tbnm."' ","utf8","");
  }else{
    $krest=selectedx($conn,"information_schema","select COLUMN_NAME,COLUMN_TYPE from COLUMNS where TABLE_SCHEMA='".$fbase."' and TABLE_NAME='".$tbnm."' and ',".$keys.",' like concat('%,',COLUMN_NAME,',%')","utf8","");
  }
}
//echo $krest;
 //NEED FUNCTION -countresult() @ connmysql.php;
 $totkc=countresult($krest);
  $dd=$dd.$tbnm."kb[\"COLUMN\"]=new Array();\r\n";
  for ($c=0;$c<$totkc;$c++){
    $dd=$dd.$tbnm."kb[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"]=new Array();\r\n";
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_TYPE"]=anyvalue($krest,"COLUMN_TYPE",$c);
    $dd=$dd.$tbnm."kb[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_TYPE\"]=\"".anyvalue($krest,"COLUMN_TYPE",$c)."\";\r\n";
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_TPNM"]=qian(anyvalue($krest,"COLUMN_TYPE",$c),"(");
    $dd=$dd.$tbnm."kb[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_TPNM\"]=\"".qian(anyvalue($krest,"COLUMN_TYPE",$c),"(")."\";\r\n";
    $kbase[anyvalue($krest,"COLUMN_NAME",$c)]["COLUMN_TPLEN"]=qian(hou(anyvalue($krest,"COLUMN_TYPE",$c),"("),")");
    $dd=$dd.$tbnm."kb[\"".anyvalue($krest,"COLUMN_NAME",$c)."\"][\"COLUMN_TPLEN\"]=\"".qian(hou(anyvalue($krest,"COLUMN_TYPE",$c),"("),")")."\";\r\n";
    $kbase["COLUMN"][$c]=anyvalue($krest,"COLUMN_NAME",$c);
    $dd=$dd.$tbnm."kb[\"COLUMN\"][\"".$c."\"]=\"".anyvalue($krest,"COLUMN_NAME",$c)."\";\r\n";
 };  
 $kbase["COLUMN"]["COUNT"]=$totkc;
  $dd=$dd.$tbnm."kb[\"COLUMN\"][\"COUNT\"]=".$totkc.";\r\n";
 $kbase["CODE"]["JS"]=$dd;
return $kbase;
}
?>