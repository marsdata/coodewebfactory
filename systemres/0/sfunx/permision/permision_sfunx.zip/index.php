<?php
function haspmtoffun($fid,$uid,$cid){
    $bwl=SX("select whitelist,blacklist from coode_funbwclist where funid='".$fid."' and comid='".$cid."'");
    $tot=countresult($bwl);
    if ($tot>0){
        $wlist=anyvalue($bwl,"whitelist",0);
        $blist=anyvalue($bwl,"blacklist",0);
        if (strpos(".".$blist,$uid)>0){
            return false;
        }
        if (strpos(".".$wlist,$uid)>0){
            return true;
        }
    }
      $frst=SX("select STATUS,valx from coode_fpmtru where funid='".$fid."' and comid='".$cid."' and clientid='".$uid."'");
      $totx=countresult($frst);
      if ($totx==0){
        return true;    
      }else{
        if (intval(anyvalue($frst,"STATUS",0))*intval(anyvalue($frst,"valx",0))==1){
            return true;
        }else{
            return false;
        }
      }
}
function haspmtofpage($pgid,$uid,$cid){
    $bwl=SX("select whitelist,blacklist from coode_pagebwclist where pagemark='".$pgid."' and comid='".$cid."'");
    $tot=countresult($bwl);
    if ($tot>0){
        $wlist=anyvalue($bwl,"whitelist",0);
        $blist=anyvalue($bwl,"blacklist",0);
        if (strpos(".".$blist,$uid)>0){
            return false;
        }
        if (strpos(".".$wlist,$uid)>0){
            return true;
        }
    }
      $prst=SX("select STATUS,valx from coode_ppmtru where pagemark='".$pgid."' and comid='".$cid."' and clientid='".$uid."'");
      $totx=countresult($prst);
      if ($totx==0){
        return true;    
      }else{
        if (intval(anyvalue($prst,"STATUS",0))*intval(anyvalue($prst,"valx",0))==1){
            return true;
        }else{
            return false;
        }
      }
}
function haspmtoftab($tbid,$uid,$cid){
    $bwl=SX("select whitelist,blacklist from coode_tabbwclist where tabname='".$tbid."' and comid='".$cid."'");
    $tot=countresult($bwl);
    if ($tot>0){
        $wlist=anyvalue($bwl,"whitelist",0);
        $blist=anyvalue($bwl,"blacklist",0);
        if (strpos(".".$blist,$uid)>0){
            return "-1";
        }
        if (strpos(".".$wlist,$uid)>0){
            return "1";
        }
    }
    return "0";
}
function makecomtabbw($tabid,$comid,$sysid){
    if ($tabid!="" and $comid!="" and $sysid!=""){
      $tbtt=UX("select tabtitle as result from coode_tablist where TABLE_NAME='".$tabid."'");
      $sqlx="tabname,pertitle,comid,sysid,starttime,endtime";
      $sqly="'".$tabid."','".$tbtt."','".$comid."','".$sysid."',now(),now()";
      $z=UX("insert into coode_tabbwclist(".$sqlx.")values(".$sqly.")");
      return true;
    }else{
      return false;
    }
}
function makecomfunbw($funid,$comid,$sysid){
    if ($funid!="" and $comid!="" and $sysid!=""){
      $funtt=UX("select funcname as result from coode_funlist where funname='".$funid."' or funname='".$funid."()'");
      $sqlx="funid,pertitle,comid,sysid,starttime,endtime";
      $sqly="'".$funid."','".$funtt."','".$comid."','".$sysid."',now(),now()";
      $z=UX("insert into coode_funbwclist(".$sqlx.")values(".$sqly.")");
      return true;
    }else{
      return false;
    }
}
function makecompagebw($pageid,$comid,$sysid){
    if ($pageid!="" and $comid!="" and $sysid!=""){
     $pagett=UX("select tinytitle as result from coode_tiny where tinymark='".$pageid."' ");
     $sqlx="pagemark,pertitle,comid,sysid,starttime,endtime";
     $sqly="'".$pageid."','".$pagett."','".$comid."','".$sysid."',now(),now()";
     $z=UX("insert into coode_pagebwclist(".$sqlx.")values(".$sqly.")");
     return true;
    }else{
     return false;
    }
}
function makecomappbw($comid){
    if ($comid!="" ){
        $z=UX("insert into coode_appstatelist(sysid,comid,pertitle,scvid,appid,starttime,endtime,CRTM,UPTM,STATUS)select sysid,'".$comid."',appname,'',appid,now(),now(),now(),now(),1 from coode_appdefault where STATUS=1 and concat('".$comid."',appid) not in(select concat(comid,appid) from coode_appstatelist)");
        return true;
    }else{
        return false;
    }
}
function maketabpmt($tabid,$sysid){
    if ($tabid!="" and $sysid!=""){
        $tbtt=UX("select tabtitle as result from coode_tablist where TABLE_NAME='".$tabid."'");
  $sqla="sysid,permid,permtitle,appid,compid,groupid,grpvalx,clientid,metcls,method,behiver,valx,dataarea";
  $sqlb="'".$sysid."','".$sysid."-".$tabid.":insert','".$tbtt."新增','','compid','groupid',1,'clientid','data','mysql','insert',1,'DA:selfitem,DA:selfpos,DA:sonpos,DA:selfandsonpos,DA:selfleaddepart,'";
  $zz=UX("insert into coode_tpmtsys(".$sqla.")values(".$sqlb.")");
  $sqla="sysid,permid,permtitle,appid,compid,groupid,grpvalx,clientid,metcls,method,behiver,valx,dataarea";
  $sqlb="'".$sysid."','".$sysid."-".$tabid.":update','".$tbtt."更改','','compid','groupid',1,'clientid','data','mysql','update',1,'DA:selfitem,DA:selfpos,DA:sonpos,DA:selfandsonpos,DA:selfleaddepart,'";
  $zz=UX("insert into coode_tpmtsys(".$sqla.")values(".$sqlb.")");
  $sqla="sysid,permid,permtitle,appid,compid,groupid,grpvalx,clientid,metcls,method,behiver,valx,dataarea";
  $sqlb="'".$sysid."','".$sysid."-".$tabid.":select','".$tbtt."选择','','compid','groupid',1,'clientid','data','mysql','select',1,'DA:selfitem,DA:selfpos,DA:sonpos,DA:selfandsonpos,DA:selfleaddepart,'";
  $zz=UX("insert into coode_tpmtsys(".$sqla.")values(".$sqlb.")");
  $sqla="sysid,permid,permtitle,appid,compid,groupid,grpvalx,clientid,metcls,method,behiver,valx,dataarea";
  $sqlb="'".$sysid."','".$sysid."-".$tabid.":delete','".$tbtt."删除','','compid','groupid',1,'clientid','data','mysql','delete',1,'DA:selfitem,DA:selfpos,DA:sonpos,DA:selfandsonpos,DA:selfleaddepart,'";
  $zz=UX("insert into coode_tpmtsys(".$sqla.")values(".$sqlb.")");
  return true;
    }else{
        return false;
    }
}
function makefunpmt($funid,$sysid){
    if ($funid!="" and $sysid!=""){
  $funtt=UX("select funcname as result from coode_funlist where funname='".$funid."' or funname='".$funid."()'");
  $sqla="funid,pertitle,comid,roleid,clientid,shortid,valx,reurl,appid,sysid,starttime,endtime";
  $sqlb="'".$funid."','".$funtt."','comid','roleid','clientid','shortid',1,'','','".$sysid."',now(),now()";
  $zz=UX("insert into coode_fpmtsys(".$sqla.")values(".$sqlb.")");
  return true;
    }else{
        return false;
    }
}
function makepagepmt($pgmk,$sysid){
    if ($pgmk!="" and $sysid!=""){
      $pagett=UX("select tinytitle as result from coode_tiny where tinymark='".$pgmk."' ");
      $sqla="pagemark,pertitle,comid,roleid,clientid,shortid,valx,reurl,appid,sysid,starttime,endtime";
      $sqlb="'".$pgmk."','".$pagett."','comid','roleid','clientid','shortid',1,'','','".$sysid."',now(),now()";
      $zz=UX("insert into coode_ppmtsys(".$sqla.")values(".$sqlb.")");
      return true;
    }else{
        return false;
    }
}
function vfresedit($restpx,$rescdx,$uidx){  
  $drst=SX("select SNO,askman,STATUS from coode_devespace  where rescode='".$rescdx."' and restype='".$restpx."' and askman!=''");
  $totd=countresult($drst);
  if ($totd==0){
    $sqlx="acccode,restype,rescode,restitle,resarea,fromip,fromhost,askman,CRTM,UPTM,OLMK,STATUS";
    $sqly="'','$restpx','$rescdx','$rescdx','".glm()."','','".$fromhost."','".$uidx."',now(),now(),'".onlymark()."',1";
    $zz=UX("insert into coode_devespace(".$sqlx.")values(".$sqly.")");
    return true;
  }else{
    $brst=SX("select SNO,askman,STATUS from coode_devespace  where rescode='".$rescdx."' and restype='".$restpx."' and acccode='' and askman!=''");
    $totb=countresult($brst);
    $aman=anyvalue($brst,"askman",0);
    $astt=anyvalue($brst,"STATUS",0);
    
    if ($aman==$uidx){
    
      if (intval($astt)==1){
        return true;
      }else{
        return false;
      }
    }else{
    
      if ($uidx!=""){
        $myext=UX("select count(*) as result from coode_devespace  where rescode='".$rescdx."' and restype='".$restpx."' and askman='".$uidx."' and acccode='".$aman."'");
        if (intval($myext)==0){
         $sqlx="acccode,restype,rescode,restitle,resarea,fromip,fromhost,askman,CRTM,UPTM,OLMK,STATUS";
         $sqly="'".$aman."','$restpx','$rescdx','$rescdx','".glm()."','','".$fromhost."','".$uidx."',now(),now(),'".onlymark()."',0";
         $zz=UX("insert into coode_devespace(".$sqlx.")values(".$sqly.")");
        }
      }      
      return false;
    }
  }
}
?>