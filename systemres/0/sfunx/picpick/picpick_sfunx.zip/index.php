<?php
function tabpicpick($tbnm,$sno,$olmk){
    $tbrst=SX("select mainsqx,olmkkey from coode_tablist where TABLE_NAME='".$tbnm."'");
    $msqx=anyvalue($tbrst,"mainsqx",0);
    $olmkk=anyvalue($tbrst,"olmkkey",0);
    if ($msqx!="" and $olmkk!=""){
      $krst=SX("select COLUMN_NAME,dxtype from coode_keydetailx where TABLE_NAME='".$tbnm."' and (dxtype='imagex' or dxtype='images' or dxtype='filex' or dxtype='files')");
      $totk=countresult($krst);
      for ($t=0;$t<$totk;$t++){
        $colnm=anyvalue($krst,"COLUMN_NAME",0);
        $zz0=UX("update ".$tbnm." set ".$colnm."='' where ".$msqx."=".$sno." or ".$olmkk."='".$olmk."'");
      }
      $prst=SX("select SNO,tbsno,tbolmk,TABLE_NAME,COLUMN_NAME,picurl from coode_itemfile where TABLE_NAME='".$tbnm."' and (tbsno=".$sno." or tbolmk='".$olmk."') order by SNO");
      $totp=countresult($prst);
      for ($z=0;$z<$totp;$z++){
        $snox=anyvalue($prst,"SNO",$z);
        $tbsno=anyvalue($prst,"tbsno",$z);
        $tbolmk=anyvalue($prst,"tbolmk",$z);
        $picurl=anyvalue($prst,"picurl",$z);
        $tbnm=anyvalue($prst,"TABLE_NAME",$z);
        $tbkey=anyvalue($prst,"COLUMN_NAME",$z);
        $dxtype=UX("select dxtype as result from coode_keydetailx where TABLE_NAME='".$tbnm."' and COLUMN_NAME='".$tbkey."'");
        switch($dxtype){
            case "imagex":
            $zz3=UX("update ".$tbnm." set ".$tbkey."='".$picurl."' where ".$msqx."=".$sno." or ".$olmkk."='".$olmk."'");
            break;
            case "images":
            $zz3=UX("update ".$tbnm." set ".$tbkey."=concat(".$tbkey.",'".$picurl.",') where ".$msqx."=".$sno." or ".$olmkk."='".$olmk."'");
            break;
            case "filex":
            $zz3=UX("update ".$tbnm." set ".$tbkey."='".$picurl."' where ".$msqx."=".$sno." or ".$olmkk."='".$olmk."'");
            break;
            case "files":
            $zz3=UX("update ".$tbnm." set ".$tbkey."=concat(".$tbkey.",'".$picurl.",') where ".$msqx."=".$sno." or ".$olmkk."='".$olmk."'");
            break;
            default:
        }
        if ($tbsno==$tbolmk){
            $tbnsno=UX("select ".$msqx." as result from ".$tbnm." where ".$olmkk."='".$olmk."'");
            $z4=UX("update coode_itemfile set tbsno=".$tbnsno." where SNO=".$snox);
        }
      }
      return true;
    }else{
      return false;
    }
}
?>