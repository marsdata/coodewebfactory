<?php
function newplot($plmk,$pltt){
$ext0=UX("select count(*) as result from coode_plotlist where plotmark='".$plmk."'");
 if (intval($ext0)==0){
  $sqlx="sysid,plotmark,markname,CRTOR,CRTM,UPTM,OLMK";
  $sqly="'0','".$plmk."','".$pltt."','"._cookie("uid")."',now(),now(),'".onlymark()."'";
  $zz=UX("insert into coode_plotlist(".$sqlx.")values(".$sqly.")");
 }
 return true;
}
function plotnextid($plmk,$pltb){
   switch($pltb){
      case "coode_plotdetail":
        return intval(UX("select myid as result from ".$pltb." where plotmark='".$plmk."' order by myid desc"))*1+1;
      break;
      case "coode_nodes":
        return intval(UX("select myid as result from ".$pltb." where treemark='".$plmk."' order by myid desc"))*1+1;
      break;
      case "target_tarorg":
        return intval(UX("select myid as result from ".$pltb." where tarmark='".$plmk."' order by myid desc"))*1+1;
      break;
      case "target_srckey":
        return intval(UX("select myid as result from ".$pltb." where srcmark='".$plmk."' order by myid desc"))*1+1;
      break;
      default:
   }
   
}
function switchplot($markid){
   $srst=SX("select evalcode,switchtitle,STATUS from coode_switchlist where switchid='".$markid."'");
   $totrst=countresult($srst);
   if (intval($totrst)>0){
    $ecode=anyvalue($srst,"evalcode",0);   
    $stitle=anyvalue($srst,"switchtitle",0);   
    $stt=anyvalue($srst,"STATUS",0); 
    $rtnstt=$stt;
    $_GET["rtnstt"]=$stt;
    if ($ecode!=""){
       $_GET["switchstatus"]=$stt;
       $switchstatus=$stt;
       eval($ecode);
    };
    if (intval($rtnstt)>=1){
      return true; 
    }else{
      return false;  
    }
   }else{
    return true;  
   }
}
?>