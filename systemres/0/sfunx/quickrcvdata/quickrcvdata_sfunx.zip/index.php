<?php
function quickrcv($stid,$sno){
    if ($stid!=""){
        $tabnm=UX("select tablename as result from coode_shortdata where shortid='".$stid."'");
        eval(CLASSX("verifystring"));
        $mkey=SX("select mainsqx,olmkkey from coode_tablist where TABLE_NAME='".$tabnm."'");
        $olmkkey=anyvalue($mkey,"olmkkey",0);
        $msno=anyvalue($mkey,"mainsqx",0);
        $vs=new verifystring();
        $ed=array();
        $idata=array();
        $idata=makeidata($stid,$idata,$sno);
        $ak=getarrkeys($idata);
        $at=stktott($stid,$ak);
        $af=getkvf($stid,$ak);
        $ed=$vs->arrverfy($ak,$at,$af,$idata,$ed);
       if (intval($ed["errstt"])==0){
           $olmkz=dftval($_POST["p_".$olmkkey.$sno],$_POST["p_".$olmkkey]);
           if (existitem($tabnm,$olmkz,$olmkkey) or existitemx($tabnm,$sno,$msno)){
            $istt=makerefresh($tabnm,$idata,$sno);
           }else{
            $istt=makeinsert($tabnm,$idata,$olmkkey);
            //echo "tab-snox.".$tabnm.$sno;
           }
          if ($istt){
            return '{"status":"1","msg":"提交成功","redirect":""}';
          }else{
            return '{"status":"0","msg":"提交信息失败:","redirect":""}';
          }
       }else{
            return '{"status":"0","msg":"验证信息失败:'.$ed["allerr"].'","redirect":""}';
       }
    }else{
        return '{"status":"0","msg":"提交失败,参数不全","redirect":""}';
    }
}
function quickdbrcv($dbnm,$stid,$sno){
    if ($stid!=""){
        $tabnm=UX("select tablename as result from coode_dbshort where shortid='".$stid."'");
        $mkey=SX("select mainsqx,olmkkey from coode_dbtablist where TABLE_NAME='".$tabnm."' and schm='".$dbnm."'");
        $olmkkey=anyvalue($mkey,"olmkkey",0);
        $msno=anyvalue($mkey,"mainsqx",0);
        eval(CLASSX("verifystring"));
        eval(RESFUNSET("tabbaseinfo"));
        $vs=new verifystring();
        $ed=array();
        $idata=array();
        $dinfo=array();
        $dinfo=getdbinfo($dbnm,$tabnm,$dinfo);
        $idata=makedbidata($stid,$idata,$dinfo["pssno"],$sno);
        $ak=getarrkeys($idata);
        $at=dbstktott($dbnm,$stid,$ak);
        $af=dbgetkvf($dbnm,$stid,$ak);
        $ed=$vs->arrverfy($ak,$at,$af,$idata,$ed);
       if (intval($ed["errstt"])==0){
           if (existdata($dbnm,$tabnm,$dinfo["pssno"],$sno)){
            $istt=makedbrefresh($dbnm,$tabnm,$idata,$dinfo["pssno"],$sno);
           }else{
            $istt=makedbinsert($dbnm,$tabnm,$idata,$dinfo["pssno"]);
           }
          if ($istt){
            return '{"status":"1","msg":"提交成功","redirect":""}';
          }else{
            return '{"status":"0","msg":"提交信息失败:","redirect":""}';
          }
       }else{
           //.$ak.'/'.$at.'/'.$af
            return '{"status":"0","msg":"验证信息失败('.$ed["errstt"].'):'.$ed["allerr"].'","redirect":""}';
       }
    }else{
        return '{"status":"0","msg":"提交失败,参数不全","redirect":""}';
    }
}
function quickrcvx($stid,$sqx){
    if ($stid!=""){
        $tabnm=UX("select tablename as result from coode_shortdata where shortid='".$stid."'");
        eval(CLASSX("verifystring"));
        $vs=new verifystring();
        $ed=array();
        $idata=array();
        $idata=makeidatax($stid,$idata,$sqx);
        $ak=getarrkeys($idata);
        $at=stktott($stid,$ak);
        $af=getkvf($stid,$ak);
        $ed=$vs->arrverfy($ak,$at,$af,$idata,$ed);
       if (intval($ed["errstt"])==0){
           $olmkz=dftval($_POST["p_OLMK".$sqx],$_POST["p_OLMK"]);
           if (existitem($tabnm,$olmkz)){
            $istt=makeupdate($tabnm,$idata,$olmkz);
           }else{
            $istt=makeinsert($tabnm,$idata);
           }
          if ($istt){
            return '{"status":"1","msg":"提交成功","redirect":""}';
          }else{
            return '{"status":"0","msg":"提交信息失败:","redirect":""}';
          }
       }else{
            return '{"status":"0","msg":"验证信息失败:'.$ed["allerr"].'","redirect":""}';
       }
    }else{
        return '{"status":"0","msg":"提交失败,参数不全","redirect":""}';
    }
}
function anyupnew($dodatastr,$oderb,$dtp,$kinfo=array(array())){
     $tbnm=qian($dodatastr,".");
     $tbks=qian(hou($dodatastr,"."),"[");
     $totkx=$kinfo["COLUMN"]["COUNT"];
     $tmpfmallk="";
     $tmpfmalltp="";
     //echo "totkx=".$totkx;
     
     for ($i=0;$i<$totkx;$i++){
          $tmpfmallk=$tmpfmallk.$kinfo["COLUMN"][$i].",";
          $tmpkx="";
          $tmpkx=$kinfo["COLUMN"][$i];
          
          $tmpfmalltp=$tmpfmalltp.$kinfo[$tmpkx]["COLUMN_TPNM"].",";
     }
//     echo "akk0=".$tmpfmallk;
     if ($totkx>0){
          $tmpfmallk=substr($tmpfmallk,0,strlen($tmpfmallk)-1);
                            
          $tmpfmalltp=substr($tmpfmalltp,0,strlen($tmpfmalltp)-1);
     }
     
     if (strpos($tbks,",")>0){
          $parttbk=explode(",",$tbks);
          $totk=count($parttbk);//为了验证有几个K,和几个V,数量应该一致
     }else{
          $totk=1;
     }
     $cdtx=qian(hou($dodatastr,"["),"]");
//echo $tbnm."__".$tbks."___".$totkx."__".$cdtx;
     $backstr=fmkeyval($cdtx,$tmpfmallk,$kinfo);
     $tbvs=qian(hou($dodatastr,"val("),")");
  // echo "fmxxx=".$fmxxx;
    if ($tbvs==""){
          $fmxxx=$backstr;
          $tbnmm=$tbnm;
      $tbkiss=$tbks;
      $wtokiss=$_GET['wtokeys'];
      $tbcdtss=$fmxxx." and (CRTOR='".$_COOKIE["uid"]."' or PTOF='GUEST' or  PTOF='".$_COOKIE["uid"]."' or  PTOF='".$_COOKIE["gid"]."'  or '".$_COOKIE["gid"]."'='system')";
      $dtpp=$dtp;
      $surll=$_GET['comeurl'];
      $page=$_GET['page'];
      $pagenum=$_GET['pagenum'];
      $odcdt=$oderb;
      $showf=$_GET['sowf']; 
      // echo $tbcdtss;
      $tbnr=anyfulltblist($stid,$fipp,$fuss,$fpss,$fbss,$tbnmm,$tbkiss,$tbcdtss,$dtpp,$surll,$odcdt);
      return $tbnr;
     }else{
       $ptvs=explode(",",$tbvs);
       $totv=count($ptvs);
       if ($totk==$totv){
            $xx=upnew($tbnm,$tbks,$tbvs,$cdtx);
            //echo "update ".$tbnm." set ".$sqla." where ".$fmxxx;
            if ($xx*1>0){
              return "{\"status\":\"1\",\"totrcd\":\"0\",\"msg\":\"".String2Hex($xx)."\"}";
            }else{
                return "{\"status\":\"-1\",\"totrcd\":\"0\",\"msg\":\"".String2Hex($xx)."\"}";
            }
       }else{     
         return "{\"status\":\"-1\",\"totrcd\":\"0\",\"msg\":\"different amount of keys and values\"}";
         }
     }
}//DESCRIB ():  END@()
function anyupvalue($dodatastr,$oderb,$dtp,$kinfo=array(array())){
     //=
     $tbnm=qian($dodatastr,".");
     $tbks=qian(hou($dodatastr,"."),"<");
     $totkx=$kinfo["COLUMN"]["COUNT"];
     $tmpfmallk="";
     $tmpfmalltp="";
     //echo "totkx=".$totkx;
     
     for ($i=0;$i<$totkx;$i++){
          $tmpfmallk=$tmpfmallk.$kinfo["COLUMN"][$i].",";
          $tmpkx="";
          $tmpkx=$kinfo["COLUMN"][$i];
          
          $tmpfmalltp=$tmpfmalltp.$kinfo[$tmpkx]["COLUMN_TPNM"].",";
     }
//     echo "akk0=".$tmpfmallk;
     if ($totkx>0){
          $tmpfmallk=substr($tmpfmallk,0,strlen($tmpfmallk)-1);
                            
          $tmpfmalltp=substr($tmpfmalltp,0,strlen($tmpfmalltp)-1);
     }
     
     if (strpos($tbks,",")>0){
          $parttbk=explode(",",$tbks);
          $totk=count($parttbk);//为了验证有几个K,和几个V,数量应该一致
     }else{
          $totk=1;
     }
     $cdtx=qian(hou($dodatastr,"<"),">");
//echo $tbnm."__".$tbks."___".$totkx."__".$cdtx;
     $fmxxx="";
     
     if (strpos("xx".$cdtx,"(")>0){
             $ptcdtx=explode("(",$cdtx);
             $totptcdt=count($ptcdtx);
             $tmpx="";
             for ($i=1;$i<$totptcdt;$i++){
                $fmtmp="";
                $tmpx=qian($ptcdtx[$i],")");
              $fmtmp="";
                    $tmpxx=str_replace("+","*",$tmpx);
                    $tmpxx=str_replace("|","*",$tmpx);
                    $pttp=explode("*",$tmpxx);
                    $totpp=count($pttp);
                    //echo "tmpxx==".$tmpxx."----------";
                    if ($totpp>1){
                      for ($k=1;$k<$totpp+1;$k++){
                         $tmpxxy="";
                         for ($m=0;$m<$k;$m++){
                              $getmkx="";
                              $tmpxxy=$tmpxxy.$pttp[$m];
                              $getmkx=substr($tmpx,strlen($tmpxxy),1);
                              $tmpxxy=$tmpxxy.$getmkx;
                         };
                         $lastmark=substr($tmpxxy,strlen($tmpxxy)-1,1);
                         $backstr="";
                         $backstr=fmkeyval($pttp[$k-1],$tmpfmallk,$kinfo);
                         $lianjie="";
                         if ($k<$totpp){
                           $lianjie=str_replace("*"," and ",$lastmark);
                           $lianjie=str_replace("+"," or ",$lianjie);
                           $lianjie=str_replace("|"," or ",$lianjie);
                           $fmtmp=$fmtmp.$backstr.$lianjie;
                         }else{
                           $fmtmp=$fmtmp.$backstr;
                         }                 
                      }//for                
                       $fmxxx=$fmxxx."(".$fmtmp.")".hou($ptcdtx[$i],")");
                }else{
                       $fmxxx=$fmxxx."(".fmkeyval($tmpx,$tmpfmallk,$kinfo).")".hou($ptcdtx[$i],")");
                   }
                  
                 
             };//for i=0
    }else{                //strpos xx () 上面是有括号的复合判断
             if (strpos($cdtx,"*")>0 or strpos($cdtx,"+")>0 ){
                 $tmpxx=str_replace("+","*",$cdtx);
                    $tmpxx=str_replace("|","*",$cdtx);
                    $pttp=explode("*",$tmpxx);
                    $totpp=count($pttp);
                    for ($k=1;$k<$totpp+1;$k++){
                         $tmpxxy="";
                         for ($m=0;$m<$k;$m++){
                              $getmkx="";
                              $tmpxxy=$tmpxxy.$pttp[$m];
                              $getmkx=substr($tmpxx,strlen($tmpxxy),1);
                              $tmpxxy=$tmpxxy.$getmkx;
                         };
                         $lastmark=substr($tmpxxy,strlen($tmpxxy)-1,1);
                         $backstr="";
                         //echo $pttm[$m]."--".$tmpfmallk.";";//-----------------------------
                         $backstr=fmkeyval($pttp[$k-1],$tmpfmallk,$kinfo);
                         $lianjie="";
                         if ($k<$totpp){
                           $lianjie=str_replace("*"," and ",$lastmark);
                           $lianjie=str_replace("+"," or ",$lianjie);
                           $lianjie=str_replace("|"," or ",$lianjie);
                           $fmtmp=$fmtmp.$backstr.$lianjie;
                         }else{
                           $fmtmp=$fmtmp.$backstr;
                         }
                    }//for
                    $fmxxx=$fmtmp;
               }else{
                    $backstr="";
                         $backstr=fmkeyval($cdtx,$tmpfmallk,$kinfo);
                    $fmxxx=$backstr;     
               }
     }
     $fmxxx=str_replace(")+(",") or (",$fmxxx);
     $fmxxx=str_replace(")*(",") and (",$fmxxx);
     $fmxxx=str_replace("'@_NOW'","now()",$fmxxx);
     $fmxxx=str_replace("'@_DATE'","date(now())",$fmxxx);
     $fmxxx=str_replace("'@_UID'","'".$_COOKIE["uid"]."'",$fmxxx);
     $fmxxx=str_replace("'@_GID'","'".$_COOKIE["gid"]."'",$fmxxx);
     $fmxxx=str_replace("'@_OMK'","'".onlymark()."'",$fmxxx);
     $fmxxx=str_replace("'@_TMK'","'".time()."'",$fmxxx);
     $tbvs=qian(hou($dodatastr,"val("),")");
     
     if ($tbvs==""){
          //获取信息用;可以展示出结果的;
     }else{
        if (strpos($tbvs,",")>0){
          $parttbv=explode(",",$tbvs);
          $totv=count($parttbv);//为了验证有几个K,和几个V,数量应该一致
        }else{
          $totv=1;
       }//更改信息用;
     }     
  // echo "fmxxx=".$fmxxx;
    if ($tbvs==""){
          $tbnmm=$tbnm;
      $tbkiss=$tbks;
      $wtokiss=$_GET['wtokeys'];
      $tbcdtss=$fmxxx." and (CRTOR='".$_COOKIE["uid"]."' or PTOF='GUEST' or  PTOF='".$_COOKIE["uid"]."' or  PTOF='".$_COOKIE["gid"]."'  or '".$_COOKIE["gid"]."'='system')";
      $dtpp=$dtp;
      $surll=$_GET['comeurl'];
      $page=$_GET['page'];
      $pagenum=$_GET['pagenum'];
      $odcdt=$oderb;
      $showf=$_GET['sowf']; 
      // echo $tbcdtss;
      $tbnr=anyfulltblist($sid,$fipp,$fuss,$fpss,$fbss,$tbnmm,$tbkiss,$tbcdtss,$dtpp,$surll,$odcdt);
      return $tbnr;
     }else{
       if ($totk==$totv){
            $sqla="";
            if ($totk>1){
              for ($o=0;$o<$totk;$o++){
                $sqla=$sqla.$parttbk[$o]."='".$parttbv[$o]."',";
              }
               $sqla=substr($sqla,0,strlen($sqla)-1);                  
            }else{
               $sqla=$tbks."='".$tbvs."'";
            }
            $bb=beafaction($tbnm,"update","before");
           $conn=mysql_connect(gl(),glu(),glp());
            $xx=updatingx($conn,glb(),"update ".$tbnm." set ".$sqla." where ".$fmxxx." and (CRTOR='".$_COOKIE["uid"]."' or PTOF='GUEST' or  PTOF='".$_COOKIE["uid"]."' or  PTOF='".$_COOKIE["gid"]."'  or '".$_COOKIE["gid"]."'='system')","utf8");
            $conn=mysql_connect(gl(),glu(),glp());
            $xx=updatingx($conn,glb(),"update ".$tbnm." set createtime=now() where ".$fmxxx." and (CRTOR='".$_COOKIE["uid"]."' or PTOF='GUEST' or '".$_COOKIE["gid"]."'='system')","utf8");
            //echo "update ".$tbnm." set ".$sqla." where ".$fmxxx;
            $aa=beafaction($tbnm,"update","after");
            return "{\"status\":\"1\",\"totrcd\":\"0\",\"msg\":\"".String2Hex("update ".$tbnm." set ".$sqla." where ".$fmxxx." and (CRTOR='".$_COOKIE["uid"]."' or PTOF='GUEST' or '".$_COOKIE["gid"]."'='system')")."\"}";
       }else{     
         return "{\"status\":\"-1\",\"totrcd\":\"0\",\"msg\":\"different amount of keys and values\"}";
         }
     }     
}//DESCRIB ():  END@()
?>