<?php
 function chasc($tabnm,$askstr,$pn){
 if ($tabnm!="" and $askstr!="" and $pn!=""){
  $srst=SZ("select typecodex,typetitlex,rescode,restitle,count(rescode) as totr,strnum,STCODE from ".$tabnm."_wrdresnmpoints where '".$askstr."' like concat('%',nmstr,'%') group by rescode order by totr desc limit 0,".$pn);
  $rtnarr=Array(Array());
  for ($j=0;$j<countresult($srst);$j++){
   $rtnarr["rescode"][$j]=anyvalue($srst,"rescode",$j);
   $rtnarr["restitle"][$j]=anyvalue($srst,"restitle",$j);
  }
  return $rtnarr;
 }else{
   $rtnarr=Array(Array());
   return $rtnarr;
 }
}
 function getsvshost($svscode){
    $bkshort=anyfunrun("anyshort",glm(),"stid=MEej1A","");
    $bkdata=json_decode($bkshort,false);
    $vls=$bkdata->vls;
    $rtnval="";
    for ($j=0;$j<count($vls);$j++){
      if ($vls[$j]->hostid==$svscode){
        $host=$rtnval=$vls[$j]->host;
        $port=$rtnval=$vls[$j]->port;
        if ($port=="" or $port=="80"){
          $rtnval=$host;
        }else{
          $rtnval=$host.":".$port;
        }
      }
    }
    return $rtnval;
  }
function qnyup($acode,$lcfile){
  $bktxt=file_get_contents("http://".glw()."localxres/funx/uploadbyqny/?apicode=".$acode."&lcfile=".$lcfile);
  return $bktxt;
}
function otspath($oriots){
  $scode=qian($oriots,"://");
  $surl=hou($oriots,"://");
  return "http://".$scode.".halo123.cn/localxres/funx/otsfile/?fname=".$surl;
}
function ebot($awx=Array(),$pgsx,$acode){
//数量只能用奇数
 $pd=Array();
 for ($ee=0;$ee<count($awx);$ee++){
  $pd["askstr".$ee]=$awx[$ee];
 }
 $urlx=combineurl("http://".glw(),"/localxres/funx/bdchat/?acode=".$acode."&tot=".count($awx)."&pgss=".$pgsx);
 $bktxt=request_post($urlx,$pd);
 $bkdata=json_decode($bktxt,false);
 $result=$bkdata->result;
 if ($result!=""){
   return $result;
 }else{
   return "";
 }
}
function searchbyai($astr,$pgsx,$ctype){
 if ($astr!=""){
  $url=combineurl("http://".glw(),"/localxres/funx/aisearch/?ctype=".$ctype."&pgss=".$pgsx);
  $pdd=Array();
  $pdd["askstr"]=$astr;
  $bktxt=request_post($url,$pdd);
  $bkdata=json_decode($bktxt,false);
  return $bkdata->rtnstr;
 }else{
  return "";
 } 
}
function getapi($acode){
  $arst=SX("select appid,apikey,apival from coode_apipool where apicode='".$acode."'");
  $aid=anyvalue($arst,"appid",0);
  $ak=anyvalue($arst,"apikey",0);
  $av=anyvalue($arst,"apival",0);
  if ($aid==""){
    return $ak.":".$av;
  }else{
    return $aid."@".$ak.":".$av;
  }
}
function instrx($ststr,$fullstr){
 $strarr=array();
 $strarr=chlength($ststr,1,"UTF-8");
 $tots=count($strarr);
 $totx=0;
 for ($i=0;$i<$tots;$i++){
   if (strpos("xx/".$fullstr,$strarr[$i])>0){
     $totx=$totx+1;
   }   
 }
 return intval($totx);
}
function AV($expx){
  //expx= tabnm@cdt=1||b=2&&c=4:::.*SNO
  $rtnav=Array(Array());
  $tabnm=qian($expx,"@");
  $cdtx=qian(hou($expx,"@"),":::");
  $cdty=str_replace("=","='",$cdtx);
  $cdty=str_replace(":",":'",$cdty);
  $cdty=str_replace("&&","'&&",$cdty);
  $cdty=str_replace("||","'||",$cdty);
  $cdty=str_replace("*","%",$cdty);
  $cdty=str_replace("||"," or ",$cdty);
  $cdty=str_replace("&&"," and ",$cdty);
  $cdty=str_replace(":"," like ",$cdty);
  $keyx=hou($expx,":::");
  $rtnav["keys"][0]=$keyx;
  $rtnav["tabname"][0]=$tabnm;
  if ($tabnm!="" and $cdtx!="" and $keyx!=""){
   if (strpos($keyx,",")){
    $ptk=explode(",",$keyx);
    $drst=SX("select ".$keyx." from ".$tabnm." where ".$cdty);
    $totd=countresult($drst);
    if ($totd>1){
    $rtnav[0][0]=9;
    $rtnav["tot"][0]=$totd;
     for ($d=0;$d<$totd;$d++){     
       for ($k=0;$k<count($ptk);$k++){
        $rtnav[$ptk[$k]][$d]=anyvalue($drst,$ptk[$k],$d);
       }
     }
    }else if ($totd==1){
       $rtnav[0][0]=3;
       $rtnav["tot"][0]=$totd;
       for ($k=0;$k<count($ptk);$k++){
        $rtnav[$ptk[$k]][$d]=anyvalue($drst,$ptk[$k],0);
       }
    }else{
     $rtnav["tot"][0]=$totd;
     $rtnav[0][0]=0;
    }
  }else{
    switch($keyx){
      case "*":
      $allkeys=UX("select allkeys as result from coode_tablist where TABLE_NAME='".$tabnm."'");
      $allkeyx=hou($allkeys,"|");
      $keyx=$allkeyx;
      $rtnav["keys"][0]=$keyx;
      $ptk=explode(",",$allkeyx);
      $drst=SX("select ".$keyx." from ".$tabnm." where ".$cdty);
      $totd=countresult($drst);
      if ($totd>1){
         $rtnav[0][0]=9;
         $rtnav["tot"][0]=$totd;
         $rtnav[0][1]=$drst;
         for ($d=0;$d<$totd;$d++){     
            for ($k=0;$k<count($ptk);$k++){
                $rtnav[$ptk[$k]][$d]=anyvalue($drst,$ptk[$k],$d);
            }
         }
      }else if ($totd==1){
         $rtnav[0][0]=3;
         $rtnav["tot"][0]=$totd;
         $fmline="";
         for ($k=0;$k<count($ptk);$k++){
           $rtnav[$ptk[$k]][$d]=anyvalue($drst,$ptk[$k],0);
           $fmline=$fmline.anyvalue($drst,$ptk[$k],0).",";
         }
        $fmline=killlaststr($fmline);
        $rtnav[0][1]=$fmline;
      }else{
       $rtnav[0][1]="";
       $rtnav["tot"][0]=$totd;
       $rtnav[0][0]=0;
      }
      break;
      case ".":
       $totd=UX("select count(*) as result from ".$tabnm." where ".$cdty);
       $rtnav["tot"][0]=$totd;
       $rtnav[0][1]=$totd;
       $rtnav[0][0]=1;
      break;
      default:
       $drst=SX("select ".$keyx." from ".$tabnm." where ".$cdty);
       $totd=countresult($drst);
       if ($totd>1){
        $rtnav["tot"][0]=$totd;
        $rtnav[0][0]=4;
        $fmline="";
        for ($d=0;$d<$totd;$d++){           
          $rtnav[$keyx][$d]=anyvalue($drst,$keyx,$d);
          $fmline=$fmline.anyvalue($drst,$keyx,$d).",";
        }
        $fmline=killlaststr($fmline);
        $rtnav[0][1]=$fmline;
       }else if ($totd==1){
        $rtnav["tot"][0]=$totd;
        $rtnav[0][1]=anyvalue($drst,$keyx,0);
        $rtnav[0][0]=1;
       }else{
        $rtnav[0][1]="";
        $rtnav["tot"][0]=$totd;
        $rtnav[0][0]=0;
       }
    }//swc
  }
 }else{//not empty
     $rtnav["tot"][0]=0;
     $rtnav[0][0]=0;
 }
 return $rtnav;
}
function KV($expx){
  $tabnm=qian($expx,"@");
  $kvx=hou($expx,"@");
         $kvy=$kvx;
         if (strpos($kvy,"&")>0){
            $ptvy=explode("&",$kvy);
            $totp=count($ptvy);
            for ($j=0;$j<$totp;$j++){
              if ($ptvy[$j]!=""){
                $fmup=$fmup.qian($ptvy[$j],"=")."='".hou($ptvy[$j],"=")."' and";
              }
            }
            $fmup=substr($fmup,0,strlen($fmup)-3);
            $oldtot=UX("select count(*) as result from ".$tabnm);
            $ktot=UX("select count(*) as result from ".$tabnm." where ".$fmup);
            if (intval($ktot)<intval($oldtot) or intval($oldtot)<100 ){
              $derst=SX("select bfdel,aftdel from coode_keydetailx where TABLE_NAME='".$tabnm."'");
              $bfdel=tostring(anyvalue($derst,"bfdel",0));
              $aftdel=tostring(anyvalue($derst,"aftdel",0));
              if ($bfdel!=""){
                eval($bfdel);
              }
              $zz=UX("delete from ".$tabnm." where ".$fmup);
              if ($aftdel!=""){
                eval($aftdel);
              }
            }
         }else{
            if ($kvy!=""){            
             $fmup=qian($kvy,"=")."='".hou($kvy,"=")."'";
             $oldtot=UX("select count(*) as result from ".$tabnm);
             $ktot=UX("select count(*) as result from ".$tabnm." where ".$fmup);
             if (intval($ktot)<intval($oldtot) or intval($oldtot)<100){
              $derst=SX("select bfdel,aftdel from coode_keydetailx where TABLE_NAME='".$tabnm."'");
              $bfdel=tostring(anyvalue($derst,"bfdel",0));
              $aftdel=tostring(anyvalue($derst,"aftdel",0));
              if ($bfdel!=""){
                eval($bfdel);
              }
               $zz=UX("delete from ".$tabnm." where ".$fmup);
              if ($aftdel!=""){
                eval($aftdel);
              }
             }             
            }         
         }
   $extx=UX("select count(*) as result from ".$tabnm." where ".$fmup);
   if (intval($extx)==0){
     return true;
   }else{
     return false;
   }
}
function UV($expx){
  $tabnm=qian($expx,"@");
  $kvx=hou($expx,"@");
  $trst=SX("select srckey,srcttk,parreskey from coode_tablist where TABLE_NAME='".$tabnm."'");
  $srck=anyvalue($trst,"srckey",0);
  $park=anyvalue($trst,"parreskey",0);
  $srcttk=anyvalue($trst,"srcttk",0);
  if ($srck!="" and $srcttk!=""){
    if (strpos($expx,$srck."=")>0 and strpos($expx,$srcttk."=")>0){
       $srcv=qian(hou($expx,$srck."="),"&");
       $srcttv=qian(hou($expx,$srcttk."="),"&");
       $kvy=str_replace($srck."=".$srcv."&","",$kvx);
       $kvy=str_replace($srck."=".$srcv."","",$kvy);
       //$kvy=str_replace($srcttk."=".$srcttv."&","",$kvy);
       //$kvy=str_replace($srcttk."=".$srcttv."","",$kvy);
        $nvx=Array(Array());
        $olmkx=onlymark();
       if (strpos($expx,$park."=")>0 and $park!=""){
        $parv=qian(hou($expx,$park."="),"&");
        $kvy=str_replace($park."=".$parv."&","",$kvy);
        $kvy=str_replace($park."=".$parv."","",$kvy);
        $nvx=AV($tabnm."@".$srck."=".$srcv."&&".$park."=".$parv.":::.");
        $extx=nvx[0][1];
        $fmk=$srck.",".$park.",";
        $fmv="'".$srcv."','".$parv."',";
        $fmcdt=$srck."='".$srcv."' and ".$park."='".$parv."'";
        $fmup="";      
       }else{
        $nvx=AV($tabnm."@".$srck."=".$srcv.":::.");
        $extx=nvx[0][1];
        $fmk=$srck.",";
        $fmv="'".$srcv."',";
        $fmcdt=$srck."='".$srcv."'";
        $fmup="";
       }
       
      if (intval($extx)==0){
          if (strpos($kvy,"&")>0){
            $ptvy=explode("&",$kvy);
            $totp=count($ptvy);
            for ($j=0;$j<$totp;$j++){
              if ($ptvy[$j]!=""){
               $fmk=$fmk.qian($ptvy[$j],"=").",";
               $fmv=$fmv."'".hou($ptvy[$j],"=")."',";              
              }
            }
           $fmk=$fmk."CRTM,UPTM,OLMK";
           $fmv=$fmv."now(),now(),'".$olmkx."'"; 
              $derst=SX("select bfist,aftist from coode_keydetailx where TABLE_NAME='".$tabnm."'");
              $bfist=tostring(anyvalue($derst,"bfist",0));
              $aftist=tostring(anyvalue($derst,"aftist",0));
              if ($bfist!=""){
                eval($bfist);
              }
           $zzz=UX("insert into ".$tabnm."(".$fmk.")values(".$fmv.")");
              if ($aftist!=""){
                eval($aftist);
              }
           $extz=UX("select count(*) as result from ".$tabnm." where OLMK='".$olmkx."'");           
           if (intval($extz)>0){
            return $olmkx;
           }else{
            return -1;
           }
          }else{
           if ($kvy!=""){
            $fmk=$fmk.qian($kvy,"=").",CRTM,UPTM,OLMK";
            $fmv=$fmv."'".hou($kvy,"=")."',now(),now(),'".$olmkx."'";
              $derst=SX("select bfist,aftist from coode_keydetailx where TABLE_NAME='".$tabnm."'");
              $bfist=tostring(anyvalue($derst,"bfist",0));
              $aftist=tostring(anyvalue($derst,"aftist",0));
              if ($bfist!=""){
                eval($bfist);
              }
            $zzz=UX("insert into ".$tabnm."(".$fmk.")values(".$fmv.")");
              if ($aftist!=""){
                eval($aftist);
              }
            $extz=UX("select count(*) as result from ".$tabnm." where OLMK='".$olmkx."'");
            if (intval($extz)>0){
             return $olmkx;
            }else{
             return -1;;
            }
           }else{
            $fmk=$fmk."CRTM,UPTM,OLMK";
            $fmv=$fmv."now(),now(),'".$olmkx."'";
              $derst=SX("select bfist,aftist from coode_keydetailx where TABLE_NAME='".$tabnm."'");
              $bfist=tostring(anyvalue($derst,"bfist",0));
              $aftist=tostring(anyvalue($derst,"aftist",0));
              if ($bfist!=""){
                eval($bfist);
              }
            $zzz=UX("insert into ".$tabnm."(".$fmk.")values(".$fmv.")");
              if ($aftist!=""){
                eval($aftist);
              }
            $extz=UX("select count(*) as result from ".$tabnm." where OLMK='".$olmkx."'");
            if (intval($extz)>0){
             return $olmkx;
            }else{
             return -1;
            }           
           }//kvy not empty
          }
        }else{
         if (strpos($kvy,"&")>0){
            $ptvy=explode("&",$kvy);
            $totp=count($ptvy);
            for ($j=0;$j<$totp;$j++){
              if ($ptvy[$j]!=""){
                $fmup=$fmup.qian($ptvy[$j],"=")."='".hou($ptvy[$j],"=")."',";
              }
            }
            $fmup=killlaststr($fmup);
              $derst=SX("select bfupd,aftupd from coode_keydetailx where TABLE_NAME='".$tabnm."'");
              $bfupd=tostring(anyvalue($derst,"bfupd",0));
              $aftupd=tostring(anyvalue($derst,"aftupd",0));
              if ($bfupd!=""){
                eval($bfupd);
              }
            $zz=UX("update ".$tabnm." set ".$fmup." where ".$fmcdt);
              if ($aftupd!=""){
                eval($aftupd);
              }
         }else{
            if ($kvy!=""){
             $fmup=qian($kvy,"=")."='".hou($kvy,"=")."'";
              $derst=SX("select bfupd,aftupd from coode_keydetailx where TABLE_NAME='".$tabnm."'");
              $bfupd=tostring(anyvalue($derst,"bfupd",0));
              $aftupd=tostring(anyvalue($derst,"aftupd",0));
              if ($bfupd!=""){
                eval($bfupd);
              }
             $zz=UX("update ".$tabnm." set ".$fmup." where ".$fmcdt);
              if ($aftupd!=""){
                eval($aftupd);
              }
            }         
         }
         $zz=UX("update ".$tabnm." set UPTM=now() where ".$fmcdt);
         $olmky=UX("select OLMK as result from ".$tabnm." where ".$fmcdt);
         return $olmky;
        }//extis zero
    }else{
     return -3;
    }
  }else{
    return -3.14;
  }
}
function takeqry($qryk){
 $fmq="";  
 if (strpos($qryk,",")>0){
  $ptq=explode(",",$qryk);
  $totpt=count($ptq);
  for ($j=0;$j<$totpt;$j++){
   if ($ptq[$j]!=""){
     $fmq=$fmq.$ptq[$j]."="._get($ptq[$j])."&";
   }
  }
  return killlaststr($fmq);
 }else{
  return $qryk."="._get($qryk);
 }
}
function takeform($fkey){
 $fmf="";  
 if (strpos($fkey,",")>0){
  $ptf=explode(",",$fkey);
  $totpt=count($ptf);
  for ($j=0;$j<$totpt;$j++){
   if ($ptf[$j]!=""){
     $fmf=$fmf.$ptf[$j]."="._post($ptf[$j])."&";
   }
  }
  return killlaststr($fmq);
 }else{
  return $fkey."="._post($fkey);
 }
}
function bdnidili($jd,$wd){
 $ak="NQFDhNsO7tHVsEGdGQb0TZYfMDTdZ5FH";
 $url="https://api.map.baidu.com/reverse_geocoding/v3/?ak=".$ak."&output=json&coordtype=wgs84ll&location=".$wd.",".$jd;
 $bktxt=file_get_contents($url);
 return $bktxt;
}
function makeinfochk($plancd,$infow,$infom){
 $url=combineurl("http://".glw(),"/localxres/funx/makeinfocheck/?plancd=".$plancd."&infow=".$infow."&infom=".$infom);
 $bktxt=file_get_contents($url);
 return $bktxt;
 $bkdata=json_decode($bktxt,false);
 if (intval($bkdata->status)>0){
  //return true;
 }else{
  //return false;
 }
}
function makercvk($kstr){
  $ptk=explode(",",$kstr);
  $totpt=count($ptk);
  for ($m=0;$m<$totpt;$m++){
    if ($ptk[$m]!=""){
      $estr='$'.$ptk[$m].'=_post("'.ptk[$m].'");';
      eval($estr);
    }
  } 
  return true;
}
function lctourl($lcpath){
  $newpath=str_replace(localroot(),"",$lcpath);
  $newurl=combineurl("http://".glw(),$newpath);
  return $newurl;
}
function urltolc($urlpath){
  $newpath=str_replace("http://".glw(),"",$lcpath);
  $newpath=combineurl(localroot(),$newpath);
  return $newpath;
}
function restourl($resexp,$hostx,$lx){
 if (strpos($resexp,"::")>0){
   $restype=qian($resexp,"::");
   $rescode=qian(hou($resexp,"::"),"@");
   $resqry=hou($resexp,"@");
   $hosty=dftval($hostx,glw());
   switch($restype){
     case "tempx":
      if (intval($lx)==0){
        return "/localxres/tempx/".qian($rescode,".")."/".hou($rescode,".").".html?".$resqry;
      }else{
        return combineurl("http://".$hosty,"/localxres/tempx/".qian($rescode,".")."/".hou($rescode,".").".html?".$resqry);
      }
     break;
     case "funx":
      if (intval($lx)==0){
        return "/localxres/funx/".$rescode."/?".$resqry;
      }else{
        return combineurl("http://".$hosty,"/localxres/funx/".$rescode."/?".$resqry);
      }
     break;
     case "pagex":
      $trst=SX("select sysid,appid,layid from coode_tiny where tinymark='".$rescode."'");
      $sysid=anyvalue($trst,"sysid",0);
      $appid=anyvalue($trst,"appid",0);
      $layid=anyvalue($trst,"layid",0);
      if (intval($lx)==0){
        return "/localxres/pagex/".$sysid."/".$appid."/".$layid."/".$rescode."/index.html?".$resqry;
      }else{
        return combineurl("http://".$hosty,"/localxres/pagex/".$sysid."/".$appid."/".$layid."/".$rescode."/index.html?".$resqry);
      }
     break;
     case "formx":
      if (intval($lx)==0){
        return "/localxres/funx/anyjsshort/?stid=".$rescode."&".$resqry;
      }else{
        return combineurl("http://".$hosty,"/localxres/funx/anyjsshort/?stid=".$rescode."&".$resqry);
      }
     break;
     default:
   }   
 }else{
   return "";
 }
}
function atv($estr){
  //(coode_plotdetail@mysno=:13).key  用=号表示等于  用: 表示like  
  $keyx=hou($estr,").");
  $strx=hou(qian($estr,")."),"(");  
  $tb=qian($strx,"@");
  $extx=hou($strx,"@");
  if ($keyx!="" and $tb!="" and $extx!=""){
    if (strpos($extx,"::")>0){
      $extx=str_replace("::","=",$extx);
      $conn=mysql_connect(gl(),glu(),glp());  
      $bkrstx=updatingx($conn,glb(),"select ".$keyx." as result from ".$tb." where ".$extx,"utf8");
    }else{
      $extq=qian($extx,":");
      $exth=hou($extx,":");
      $conn=mysql_connect(gl(),glu(),glp());  
      $bkrstx=updatingx($conn,glb(),"select ".$keyx." as result from ".$tb." where ".$extq." like '%".$exth."%'","utf8");
    }
    return $bkrstx;
  }else{
    return "";
  }
}
function atvs($estr){
  //(coode_plotdetail@mysno=:13).key  用=号表示等于  用: 表示like  
  $keyx=hou($estr,").");
  $strx=hou(qian($estr,")."),"(");  
  $tb=qian($strx,"@");
  $extx=hou($strx,"@");
  if ($keyx!="" and $tb!="" and $extx!=""){
    if (strpos($extx,"=")>0){
      $conn=mysql_connect(gl(),glu(),glp());  
      $bkrstx=selecteds($conn,glb()," select ".$keyx." from ".$tb." where ".$extx,"utf8","");      
    }else{
      $extq=qian($extx,":");
      $exth=hou($extx,":");
      $conn=mysql_connect(gl(),glu(),glp());  
      $bkrstx=selecteds($conn,glb()," select ".$keyx." from ".$tb." where ".$extq." like '%".$exth."%'","utf8","");
    }    
    $bkrstx=hou($bkrstx,"#/#");
    return str_replace("#/#",",",$bkrstx);
  }else{
    return "";
  }
}
function utv($estr){
  //(coode_plotdetail@mysno=:13).key  用=号表示等于  用: 表示like  
  $keyx=qian(hou($estr,")."),"[");
  $strx=hou(qian($estr,")."),"(");  
  $tb=qian($strx,"@");
  $extx=hou($strx,"@");
  $newv=hou($estr,"[");
  $newv=qian($newv,"]");
  if ($keyx!="" and $tb!="" and $extx!="" and $newv!=""){
    if (strpos($extx,"=")>0){
      $conn=mysql_connect(gl(),glu(),glp());  
      $bkrstx=updatingx($conn,glb(),"update ".$tb." set ".$keyx."='".$newv."' where ".$extx,"utf8");
    }else{
      $extq=qian($extx,":");
      $exth=hou($extx,":");
      $bkrstx=updatingx($conn,glb(),"update ".$tb." set ".$keyx."='".$newv."' where ".$extq." like '%".$exth."%'","utf8");
    }
    return $newv;
  }else{
    return "";
  }
}
function gettestvalue($dm,$dk,$dtitle,$dtype){
    switch($dtype){
        case "bo01":
        if (rand(0, 99)>=50){
            return "1";
        }else{
            return "0";
        }
        break;
        case "bo00":
            return "0";
        break;
        case "bo11":
            return "1";
        break;
        default:
         $tvrst=SX("select keytype,keyval from coode_testvalcool where keytype='".$dtype."' and keywords like '%".$dtitle."%' order by RAND()");
         $tot=countresult($tvrst);
         if ($tot>0){
             return tostring(anyvalue($tvrst,"keyval",0));
         }else{
             return "@NoT-".$dm."_".$dk.".".$dtitle.".".$dtype;
         }
    }
}
function getlinkvalue($dm,$sqx,$dk,$dtitle,$dtype){
    switch($dtype){
        case "bo01":
        if (rand(0, 99)>=50){
            return "1";
        }else{
            return "0";
        }
        break;
        case "bo00":
            return "0";
        break;
        case "bo11":
            return "1";
        break;
        default:
         $tvrst=SX("select rtneval from coode_askkey where datamark='".$dm."' and keyname='".$dk."'");
         $tot=countresult($tvrst);
         if ($tot>0){
             $rtneval=anyvalue($tvrst,"rtneval",0);
             if ($rtneval!="$rtnval=gettabval(\"TABLE{CDTX}[PAGE/PNUM]@KEY.SQX\");"){
                 $rtneval=str_replace("[PAGE]",$_GET["page"],$rtneval);
                 $rtneval=str_replace("[PNUM]",$_GET["pnum"],$rtneval);
                 $rtneval=str_replace("[KEY]",$dk,$rtneval);
                 $rtneval=str_replace("[SQX]",$sqx,$rtneval);
                 eval($rtneval);
                 return $rtnval;
             };
         }else{
             return "@NoT-".$dm."_".$dk.".".$dtitle.".".$dtype;
         }
    }
}
function varval($vid){
  if ($vid!=""){
    $vrst=SX("select SNO,varexpression,changeeval,lastvalue,UPTM,lastupdt,causeevent from coode_sysvariable where variableid='".$vid."'");
    $totv=countresult($vrst);
    $varvalue="";
    if ($totv>0){
        if (strpos("xd/".$vid,"datastock")>0){
          $ve=tostring(anyvalue($vrst,"varexpression",0));
          if ($ve!=""){
            $savepath=combineurl(localroot(),"/localxres/varvalx/".date("Y-m-d")."/".$vid.".txt");
            $varvalue=file_get_contents($savepath);
          }else{
            $varvalue="";
          }
        }else{
         $lv=tostring(anyvalue($vrst,"lastvalue",0));
         $uptm=anyvalue($vrst,"UPTM",0);
         $snox=anyvalue($vrst,"SNO",0);
         $lstu=anyvalue($vrst,"lastupdt",0);
         $ve=tostring(anyvalue($vrst,"varexpression",0));
         $cae=tostring(anyvalue($vrst,"causeevent",0));
          if (strpos($ve,"varvalue=")>0){
           if ($uptm!=$lstu){
              eval($ve);
           }else{
              $varvalue=$lv; 
           }
          }else{
           $varvalue=$ve;    
          }
         $ce=tostring(anyvalue($vrst,"changeeval",0));
         if ($lv!=$varvalue){
             if ($ce!=""){
               eval($ce);
             }
             $zz=UX("update coode_sysvariable set lastupdt=now(),UPTM=now(),lastvalue='".gohex($varvalue)."' where variableid='".$vid."'");
         }else{
             $zz=UX("update coode_sysvariable set lastupdt=now(),UPTM=now() where variableid='".$vid."'");
         }
         $s=setcauseplan("coode_sysvariable","causeevent",$snox,$causeevent);
        }
        return $varvalue;
    }else{
        $sqlx="variableid,varexpression,changeeval,lastvalue,lastupdt,CRTM,UPTM,CRTOR,OLMK";
        $sqly="'".$vid."','','','',now(),now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";
        $sz=UX("insert into coode_sysvariable(".$sqlx.")values(".$sqly.")");
        return "";
    }
  }else{
      return "";
  }
}
function constval($cid){
 if ($cid!=""){
   $crst=SX("select constanttype,constantvalue from coode_sysconstant where constantid='".$cid."'");
    $totc=countresult($crst);
    $contvalue="";
    if ($totc>0){
        $cv=tostring(anyvalue($crst,"constantvalue",0));
        $ct=tostring(anyvalue($crst,"constanttype",0));
        return $cv;
    }else{
        $sqlx="constantid,constanttype,constantvalue,CRTM,UPTM,CRTOR,OLMK";
        $sqly="'".$cid."','','',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";
        $sz=UX("insert into coode_sysconstant(".$sqlx.")values(".$sqly.")");
        return "";
    }
 }else{
     return "";
 }
}
function sysconfigval($sysid,$syskey){
 if ($sysid!="" and $syskey!=""){
   $crst=SX("select sysval,sysktitle from coode_sysconfig where sysid='".$sysid."' and syskey='".$syskey."'");
    $totc=countresult($crst);
    $contvalue="";
    if ($totc>0){
        $cv=tostring(anyvalue($crst,"sysval",0));
        return $cv;
    }else{
        $sqlx="sysid,sysval,CRTM,UPTM,CRTOR,OLMK";
        $sqly="'".$sysid."','".$syskey."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";
        $sz=UX("insert into coode_sysconfig(".$sqlx.")values(".$sqly.")");
        return "";
    }
 }else{
     return "";
 }
}
function istabmng($uid,$tabnm){
 if ($uid!="" and $tabnm!=""){
   $extb=UX("select count(*) as result from rberpbox_tabmanager where tablenm='".$tabnm."' and mnger='".$uid."'");
    if (intval($extb)>0){
        return true;
    }else{
        return false;
    }
 }else{
     return false;
 }
}
function clearvarlike($strx){
  if ($strx!=""){
     $zz=UX("update coode_sysvariable set varexpression='',lastvalue='' where variableid like '%".$strx."%'");    
     return true;
  }else{
     return false;
  }
}
function setvarval($vid,$val){
  if ($vid!=""){
    $kold=UX("delete from coode_sysvariable where timestampdiff(hour,UPTM,now())>=24");
    $vrst=SX("select varexpression,changeeval,lastvalue from coode_sysvariable where variableid='".$vid."'");
    $totv=countresult($vrst);
    if ($totv>0){
        $lv=tostring(anyvalue($vrst,"lastvalue",0));
        $ve=tostring(anyvalue($vrst,"varexpression",0));
        $ce=tostring(anyvalue($vrst,"changeeval",0));
        if (strpos("xd/".$vid,"datastock")>0){
          $savepath=combineurl(localroot(),"/localxres/varvalx/".date("Y-m-d")."/".$vid.".txt");
          $zzzx=overfile($savepath,$val);
          $zz=UX("update coode_sysvariable set lastupdt=now(),UPTM=now(),varexpression='".$savepath."',lastvalue='".$savepath."' where variableid='".$vid."'");
        }else{
         if (strpos($ve,"varvalue=")>0){
           return false;
         }else{
           if ($lv!=$val){
             if ($ce!=""){
              eval($ce);
             }
             $zz=UX("update coode_sysvariable set lastupdt=now(),UPTM=now(),varexpression='".gohex($val)."',lastvalue='".gohex($val)."' where variableid='".$vid."'");
           }else{
            $zz=UX("update coode_sysvariable set lastupdt=now(),UPTM=now(),varexpression='".gohex($val)."' where variableid='".$vid."'");
           }
           return true;
         }
       }
    }else{
        if (strpos("xd/".$vid,"datastock")>0){
          $savepath=combineurl(localroot(),"/localxres/varvalx/".date("Y-m-d")."/".$vid.".txt");
          $zzzx=overfile($savepath,$val);
          $saveval=$savepath;
        }else{
          $saveval=gohex($val);
        }
        $sqlx="variableid,varexpression,changeeval,lastvalue,lastupdt,CRTM,UPTM,CRTOR,OLMK";
        $sqly="'".$vid."','".$saveval."','','',now(),now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";
        $sz=UX("insert into coode_sysvariable(".$sqlx.")values(".$sqly.")");
        return true;
    }
  }else{
      return false;
  }
}
function setconstval($cid,$val){
 if ($cid!=""){
    $crst=SX("select constanttype,constantvalue from coode_sysconstant where constantid='".$cid."'");
    $totc=countresult($crst);
    $contvalue="";
    if ($totc>0){
        return false;
    }else{
        $sqlx="constantid,constanttype,constantvalue,CRTM,UPTM,CRTOR,OLMK";
        $sqly="'".$cid."','".strtype($val)."','".gohex($val)."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";
        $sz=UX("insert into coode_sysvariable(".$sqlx.")values(".$sqly.")");
        return true;
    }
 }else{
     return false;
 }
}
function setanyvalue($dbnm,$tbnm,$tbkey,$tbsno,$newval){
    eval(RESFUNSET("tabbaseinfo"));
    if ($dbnm==glb() or $dbnm==""){
       $zz=UX("update ".$tbnm." set ".$tbkey."='".$newval."' where SNO=".$tbsno);
       return true;
    }else{
       $dinfo=array();
       $dinfo=getdbinfo($dbnm,$tabnm,$dinfo);
       $fipx=$dinfo["fip"];
       $fuserx=$dinfo["fuser"];
       $fpassx=$dinfo["fpass"];
       $fbasex=$dinfo["fbase"];
       $conn=mysql_connect($fipx,$fuserx,$fpassx);
       $zz=updatings($conn,$fbasex,"update ".$tbnm." set ".$tbkey."='".$newval."' where SNO=".$tbsno,"utf8");
       return true;
    }
}
function happensth($sth,$when){
    $erst=SX("select beforeeval,aftereval,eventtitle from coode_sysevents where eventmark='".$sth."'");
    $tote=countresult($erst);
    if (intval($tote)>0){
     $be=tostring(anyvalue($erst,"beforeeval",0));
     $ae=tostring(anyvalue($erst,"aftereval",0));
    }else{
        $be="";
        $ae="";
    }
    switch($when){
        case "before":
            eval($be);
        break;
        case  "in":
        break;
        case  "after":
            eval($ae);
        break;
        default:
    }
    $eventstr=$when.".".$sth;
    $zz=UX("update coode_causeplan set STATUS=-1,UPTM=now() where causeevent like '%".$eventstr."%'");
    $sqlx="eventmark,eventprocess,eventtitle,CRTM,UPTM,OLMK,STATUS";
    $sqly="'".$sth."','".$when."','',now(),now(),'".onlymark()."',0";
    $sqlz=UX("insert into coode_syseventblog(".$sqlx.")values(".$sqly.")");
    return true;
}
function setcauseplan($tabnm,$tabkey,$tabsno,$causeevent){
    $ext0=UX("select count(*) as result from coode_causeplan where tablename='".$tabnm."' and tabkey='".$tabkey."' and tabsno='".$tabsno."'");
    if (intval($ext0)==0){
        $sqlx="tabname,tabkey,tabsno,causeevent,lastupdt,CRTM,UPTM,CRTOR,OLMK,STATUS";
        $sqly="'".$tabnm."','".$tabkey."','".$tabsno."','".$causeevent."',now(),now(),now(),'".$_COOKIE["uid"]."','".onlymark()."',0";
        $sqlz=UX("insert into coode_causeplan(".$sqlx.")values(".$sqly.")");
        return true;
    }else{
        $z=UX("update coode_causeplan set STATUS=0,lastupdt=now(),UPTM=now(),causeevent='".$causeevent."' where  tablename='".$tabnm."' and tabkey='".$tabkey."' and tabsno='".$tabsno."'");
        return true;
    }
}
function newdata($tabnm,$keyval,$olcdt){
 $fmk="";
 $fmv="";
 $fmeq="";
 $fmcdt="";
 $failx=0;
if (strpos($olcdt,"&")>0){
   $ptcdt=explode("&",$olcdt);
   for ($zz=0;$zz<count($ptcdt);$zz++){     
     $kq=qian($ptcdt[$zz],"=");
     $vh=hou($ptcdt[$zz],"=");
     if ($vh!="" and $kq!=""){
      $fmcdt=$fmcdt." ".$kq."='".$vh."' and";
      $fmk=$fmk.$kq.",";
      $fmv=$fmv."'".$vh."',";
     }else{
       $failx=$failx+1;
     }
   }
 }else{
     $kq=qian($olcdt,"=");
     $vh=hou($olcdt,"=");
     if ($vh!="" and $kq!=""){
      $fmcdt=$fmcdt." ".$kq."='".$vh."' and";
      $fmk=$fmk.$kq.",";
      $fmv=$fmv."'".$vh."',";
     }else{
      $failx=$failx+1;
     }
 }
 
 if (strpos($keyval,"&")>0){
   $ptkv=explode("&",$keyval);
   for ($zz=0;$zz<count($ptkv);$zz++){     
     $kq=qian($ptkv[$zz],"=");
     $vh=hou($ptkv[$zz],"=");
     if ($vh!="" and $kq!=""){
      $fmeq=$fmeq." ".$kq."='".$vh."',";
      $fmk=$fmk.$kq.",";
      $fmv=$fmv."'".$vh."',";
     }
   }
 }else{
     $kq=qian($keyval,"=");
     $vh=hou($keyval,"=");
     if ($vh!="" and $kq!=""){
      $fmeq=$fmeq." ".$kq."='".$vh."',";
      $fmk=$fmk.$kq.",";
      $fmv=$fmv."'".$vh."',";
     }
 }
 $fmcdt=$fmcdt." 1>0";
 $fmeq=killlaststr($fmeq);
 $extv=UX("select count(*) as result from ".$tabnm." where ".$fmcdt);
 if (intval($extv)==0){
   $otherk="";
   $otherv="";
   if (strpos("xx-,".$fmk.",,",",CRTM,")>0){
   }else{
     $otherk=$otherk."CRTM,";
     $otherv=$otherv."now(),";
   }
   if (strpos("xx-,".$fmk.",,",",UPTM,")>0){
   }else{
     $otherk=$otherk."UPTM,";
     $otherv=$otherv."now(),";
   }
   if (strpos("xx-,".$fmk.",,",",OLMK,")>0){
   }else{
     $otherk=$otherk."OLMK,";
     $otherv=$otherv."'".onlymark()."',";
   }
   if (strpos("xx-,".$fmk.",,",",CRTOR,")>0){
   }else{
     $otherk=$otherk."CRTOR,";
     $otherv=$otherv."'".$_COOKIE["uid"]."',";
   }
   if ($otherk!="" and $otherv!=""){
     $otherk=killlaststr($otherk);
     $otherv=killlaststr($otherv);
   }
   if ($failx==0){
    $nn=UX("insert into ".$tabnm."(".$fmk.$otherk.")values(".$fmv.$otherv.")");   
   }
 }else{
   if ($failx==0){
     $uu=UX("update ".$tabnm." set UPTM=now(),".$fmeq." where ".$fmcdt);
   }
 }
 if ($failx==0){
   $extv=UX("select count(*) as result from ".$tabnm." where ".$fmcdt);
 }else{
   $extv=0;
 }
 if (intval($extv)==0 and $failx==0){
   return true;  
 }else{
   return false;
 }
}
function upddata($tabnm,$keyval,$cdtx){
 $fmeq="";
 if (strpos($keyval,"&")>0){
   $ptkv=explode("&",$keyval);
   for ($zz=0;$zz<count($ptkv);$zz++){     
     $kq=qian($ptkv[$zz],"=");
     $vh=hou($ptkv[$zz],"=");
     if ($vh!="" and $kq!=""){
      $fmeq=$fmeq." ".$kq."='".$vh."',";
     }
   }
   $fmeq=killlaststr($fmeq);
 }else{
     $kq=qian($keyval,"=");
     $vh=hou($keyval,"=");
     if ($vh!="" and $kq!=""){
      $fmeq=$fmeq." ".$kq."='".$vh."'";
     }
 } 
 $extv=UX("select count(*) as result from ".$tabnm." where ".$cdtx);
 if (intval($extv)==0){
    return false;  
 }else{
    $uu=UX("update ".$tabnm." set ".$fmeq." where ".$cdtx);
    return true;
 }
}
function takedata($jsonx){
  $jdata=json_decode($jsonx,false);
  $tabnm=$jdata->tabnm;
  $parreskey=$jdata->parreskey;
  $srckey=$jdata->srckey;
  $srcttk=$jdata->srcttk;
  $parcode=$jdata->parcode;
  $rcode=$jdata->rcode;
  $rtitle=$jdata->rtitle;
  $cdtx=$srckey."=".$rcode;
  $fmcdt=$srckey."='".$rcode."'";
  if ($parcode!=""){
   $cdtx=$cdtx."&".$parreskey."=".$parcode;
   $fmcdt=$fmcdt." and ".$parreskey."='".$parcode."'";
  }
  $kx=$srcttk."=".$rtitle;
  $zz=newdata($tabnm,$kx,$cdtx);
  $vls=$jdata->vls;
  for ($j=0;$j<count($vls);$j++){
    $keymark=$vls[$j]->keymark;
    $keyval=$vls[$j]->kvalue;
    $zz=UX("update ".$tabnm." set ".$keymark."='".$keyval."' where ".$fmcdt);
  }
  return true;
}
function askaiimg($expz,$titlez,$restp,$rescd){
 $vmark=md5($expz.$titlez);
 $sizex=qian($expz,"@");
 $wx=qian($sizex,"x");
 $hx=hou($sizex,"x");
 $colorx=qian(hou($expz,"@"),"-");
 $shapex=qian(hou($expz,"-"),".");  
 $kzmx=kuozhanming($expz);
 $xingzhuang=array();
 $xingzhuang["0"]="圆形";
 $xingzhuang["1"]="高长方形";
 $xingzhuang["2"]="矮长方形";
 $xingzhuang["3"]="三角形";
 $xingzhuang["4"]="正方形";
 $xingzhuang["5"]="星形";
 $xingzhuang["6"]="";
 switch($kzmx){
  case "svg":
  if ($colorx=="000000" or $colorx==""){
   $dex="含义为".$titlex.$kzmx."图标";   
  }else{
   $dex="含义为".$titlex."的多色且宽为".$wx."，高为".$hx.$kzmx."图标";   
  }
  $dey="请返回".$dex."的SVG代码";
  break;
  case "png":
  if ($sizex=="0x0"){
   $dex="含义为".$titlex.$kzmx."图标";   
  }else{
   $dex="含义为".$titlex."宽为".$wx."px，高为".$hx."px".$kzmx."图标";   
  }
  $dey="请返回".$dex."的网络资源地址";
  break;
  case "jpg":
  if ($sizex=="0x0"){
   $dex="含义为".$titlex.$kzmx."图标";
  }else{
   $dex="含义为".$titlex."宽为".$wx."px，高为".$hx."px".$kzmx."图标";
  }
  $dey="请返回".$dex."的网络资源地址";
  break;
  case "gif":
  if ($sizex=="0x0"){
    $dex="含义为".$titlex.$kzmx."图标";
  }else{
    $dex="含义为".$titlex."宽为".$wx."px，高为".$hx."px".$kzmx."图标";
  }  
  $dey="请返回".$dex."的动图网络资源地址";
  break;
  default:
 }
 $rtntxt=file_get_contents(combineurl("http://".glw(),"/localxres/funx/getcodebyai/?askstr=".$dey));
 switch($kzmx){
  case "svg":
  
  $extz=UX("select count(*) as result from coode_askimgtask where imgvcode='".$vmark."'");
  if (intval($extz)==0){
     $svpath=combineurl(localroot(),"/localxres/".$restp."/".$rescd."/images/".$vmark.".".$kzmx);
     $sqla="imgvcode,imgtitle,askdescrib,imgsize,savepath,imgtype,imgcode,CRTM,UPTM,OLMK";
     $sqlb="'$vmark','$titlez','$dex','$sizex','$svpath','$kzmx','".gohex("<svg".str_replace(huanhang(),"",str_replace("\"","\\\"",hou($rtntxt,"<svg"))))."',now(),now(),'".onlymark()."'";
     $zz=UX("insert into coode_askimgtask(".$sqla.")values(".$sqlb.")");
     $zz=overfile($svpath,"<svg".str_replace(huanhang(),"",str_replace("\"","\\\"",hou($rtntxt,"<svg"))));
  } 
  
  break;
  case "png":  
  $extz=UX("select count(*) as result from coode_askimgtask where imgvcode='".$vmark."'");
  if (intval($extz)==0){  
     $svpath=combineurl(localroot(),"/localxres/".$restp."/".$rescd."/images/".$vmark.".".$kzmx);
     $sqla="imgvcode,imgtitle,askdescrib,imgsize,savepath,imgtype,imgcode,CRTM,UPTM,OLMK";
     $sqlb="'$vmark','$titlez','$dex','$sizex','$svpath','$kzmx','".'http'.hou($rtntxt,'http')."',now(),now(),'".onlymark()."'";
     $zz=UX("insert into coode_askimgtask(".$sqla.")values(".$sqlb.")");
     $hurl='http'.hou($rtntxt,'http');
     $dd=downanyfile($hurl,$svpath);
  } 
  break;
  case "jpg":  
  
  $extz=UX("select count(*) as result from coode_askimgtask where imgvcode='".$vmark."'");
  if (intval($extz)==0){
    $svpath=combineurl(localroot(),"/localxres/".$restp."/".$rescd."/images/".$vmark.".".$kzmx);
     $sqla="imgvcode,imgtitle,askdescrib,imgsize,savepath,imgtype,imgcode,CRTM,UPTM,OLMK";
     $sqlb="'$vmark','$titlez','$dex','$sizex','$svpath','$kzmx','".'http'.hou($rtntxt,'http')."',now(),now(),'".onlymark()."'";
     $zz=UX("insert into coode_askimgtask(".$sqla.")values(".$sqlb.")");
     $hurl='http'.hou($rtntxt,'http');
     $dd=downanyfile($hurl,$svpath);
  } 
  break;
  case "gif":
  $extz=UX("select count(*) as result from coode_askimgtask where imgvcode='".$vmark."'");
  if (intval($extz)==0){
     $svpath=combineurl(localroot(),"/localxres/".$restp."/".$rescd."/images/".$vmark.".".$kzmx);
     $sqla="imgvcode,imgtitle,askdescrib,imgsize,savepath,imgtype,imgcode,CRTM,UPTM,OLMK";
     $sqlb="'$vmark','$titlez','$dex','$sizex','$svpath','$kzmx','".'http'.hou($rtntxt,'http')."',now(),now(),'".onlymark()."'";
     $zz=UX("insert into coode_askimgtask(".$sqla.")values(".$sqlb.")");
     $hurl='http'.hou($rtntxt,'http');
     $dd=downanyfile($hurl,$svpath);
  } 
  break;
  default:
 }
 return true;
}
function jdatatotab($jsonx,$dbmark,$tabnmx,$olkeyx,$jsonkeys,$tabkeys){
 eval(RESFUNSET("tabbaseinfo"));
 if (strpos($olkeyx,",")>0){
   $ptkeyx=explode(",",$olkeyx);
   $totpt=count($ptkeyx);
 }else{
   $totpt=1;
 } 
// $ttt="--".$olkeyx."--@@@@";
 $jsondata=json_decode($jsonx,false);  
 $ttt=$ttt.$jsonx;
 $valdata=$jsondata->vls;  
 $status=$jsondata->status;  
 if (intval($status)>0 and es($dbmark)*es($tabnmx)*es($olkeyx)*es($jsonkeys)*es($tabkeys)==1) {
  for ($dd=0;$dd<count($valdata);$dd++){
   $fmcdt="1>0 ";  
   $tmpv="";
   if ($totpt>1){
    for ($pp=0;$pp<$totpt;$pp++){
     if ($ptkeyx[$pp]!=""){
        eval('$tmpv=$valdata['.$dd.']->'.$ptkeyx[$pp].';');
        $fmcdt=$fmcdt." and ".kvexc($jsonkeys,$tabkeys,$ptkeyx[$pp])."='".$tmpv."'";
     }
    }
   }else{
      eval('$tmpv=$valdata['.$dd.']->'.$olkeyx.';');
      $fmcdt=$fmcdt." and ".kvexc($jsonkeys,$tabkeys,$olkeyx)."='".$tmpv."'";
   }
   if ($dbmark=="thishostcore"){
     $dbnmx=glb();
     $dbip=gl();
     $dbuser=glu();
     $dbpass=glp();
     $dbbase=glb();
   }else{
     $dinfo=array();     
     $dinfo=takedbinfo($dbmark,$tbnmx,$dinfo);
     $dbnmx=$dinfo["dbnm"];
     $dbip=$dinfo["fip"];
     $dbuser=$dinfo["fuser"];
     $dbpass=$dinfo["fpass"];
     $dbbase=$dinfo["fbase"];
   }
   $conn=mysql_connect($dbip,$dbuser,$dbpass);
   $extdx=updatings($conn,$dbbase,"select count(*) as result from ".$tabnmx." where ".$fmcdt,"utf8");   
   //$ttt=$ttt.huanhang(). "select count(*) as result from ".$tabnmx." where ".$fmcdt;
   if (intval($extdx)==0){
     $fmkval="";
     $ptjkey=explode(",",$jsonkeys);
     $totptj=count($ptjkey);
     for ($jj=0;$jj<$totptj;$jj++){
       $tmpjkv="";
       if ($ptjkey[$jj]!=""){
          eval('$tmpjkv=$valdata['.$dd.']->'.$ptjkey[$jj].';');
          $fmkval=$fmkval."'".$tmpjkv."',";
       }
     }
     $fmkval=killlaststr($fmkval);
     $conn=mysql_connect($dbip,$dbuser,$dbpass);
     $newdd=updatings($conn,$dbbase,"insert into ".$tabnmx."(".$tabkeys.")values(".$fmkval.")","utf8");         
     $ttt=$ttt.huanhang()."insert into ".$tabnmx."(".$tabkeys.")values(".$fmkval.")";
   }else{
     $fmupd="";
     $ptjkey=explode(",",$jsonkeys);
     $totptj=count($ptjkey);
     for ($jj=0;$jj<$totptj;$jj++){
       $tmpjkv="";
       if ($ptjkey[$jj]!=""){
          eval('$tmpjkv=$valdata['.$dd.']->'.$ptjkey[$jj].';');
          $fmupd=$fmupd.$ptjkey[$jj]."='".$tmpjkv."',";
       }
     }
     $fmupd=killlaststr($fmupd);
     $conn=mysql_connect($dbip,$dbuser,$dbpass);
     $udd=updatings($conn,$dbbase,"update ".$tabnmx." set ".$fmupd." where ".$fmcdt,"utf8");
   }
 }//fordd
}//if status
 //return $ttt;
 return true;
}
function jsondatatohost($hosturlx,$dbmarkx,$tabnmx,$csql,$hostkeyx,$jsondatax,$jsonkeyx,$jsonreskeyx){
//首先从远程服务器获取表格结构
$pod=array();
$pod["dbmark"]=$dbmarkx;
$pod["tabnm"]=$tabnmx;
$pod["createsql"]=$csql;
$pod["hostkeys"]=$hostkeyx;
$pod["jsondata"]=upandeq($jsondatax);
$pod["jsonkeys"]=$jsonkeyx;
$pod["jsonreskeys"]=$jsonreskeyx;
  $extq=UX("select count(*) as result from coode_clientdataplan where dbmark='".$dbmarkx."' and dbtabnm='".$tabnmx."' and chostrole='local'");
  if (intval($extq)==0){
    $sqlx="dbmark,dbtabnm,thiskeys,reskeys,deadline,createsql,CRTM,UPTM,OLMK,chostrole";
    $sqly="'$dbmarkx','$tabnmx','$hostkeyx','$jsonreskeyx','".date("Y-m-d H:i:s")."','".$csql."',now(),now(),'".onlymark()."','local'";
    $zz=UX("insert into coode_clientdataplan(".$sqlx.")values(".$sqly.")");
  }else{
    $zz=UX("update coode_clientdataplan set thiskeys='".$hostkeyx."',reskeys='".$jsonreskeyx."',createsql='".$csql."' where dbmark='".$dbmarkx."' and dbtabnm='".$tabnmx."' and chostrole='local'");
  }
   return request_post($hosturlx,$pod);
   //return $hosturlx;
}
function hostdatadown($hostdataurlx,$dbmarkx,$tabnmx,$hearkeyx,$jsonkeyx,$jsonreskeyx){
//首先从远程服务器获取表格结构
 //$leijix='$hostdataurlx,$dbmarkx,$tabnmx,$hearkeyx,$jsonkeyx,$jsonreskeyx---';
 //$leijix=$leijix
 $rtn=jdatatotab(file_get_contents($hostdataurlx),$dbmarkx,$tabnmx,$jsonreskeyx,$jsonkeyx,$hearkeyx);
 return $rtn;
}
function getstidbyplan($hostdm,$dmark,$dtabnm,$dkeyx,$reskeyx){
 $urlx=combineurl("http://".$hostdm,"/localxres/funx/getstidbyplan/?dbmark=".$dmark."&tabnm=".$dtabnm."&dkeys=".$dkeyx."&reskeyx=".$reskeyx."&ak=".gla()."&av=".glv());
 $rtn=$urlx."@@@";
 $bktxt=file_get_contents($urlx);
 $bkdata=json_decode($bktxt,false);
 if (intval($bkdata->status)>0){
   return $bkdata->shortid;   
 }else{
   return "";
 }
}
function finishmtask($ssmarkx,$snox,$omkx){
  $zzz0=UX("update coode_multitask set STATUS=1 where OLMK='".$omkx."' or tasksno='".$snox."'");
  $zzz1=UX("update coode_multitindex set finished=finished+1 where ssmark='".$ssmarkx."'");
  return true;
}
?>