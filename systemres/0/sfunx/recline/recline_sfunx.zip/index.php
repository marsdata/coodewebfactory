<?php
function reclines($msrcid,$msrctitle,$ssrcid,$ssrctitle,$srctype,$olenx,$nlenx,$srctxt){
    if (es($msrcid)*es($msrctitle)*es($ssrcid)*es($srctype)*es($ssrctitle)*es($olenx)*es($nlenx)==1){
        $oldrst=SX("select CRTM,charaset from coode_srclines where srcmainid='".$msrcid."' and srcsubid='".$ssrcid."' order by CRTM desc");
        $oldtm=anyvalue($oldrst,"CRTM",0);
        $ochax=anyvalue($oldrst,"charaset",0);
        if ($oldtm==""){
            $oldtm=date("Y-m-d H:i:s");
        }
        $cst=recochara(tostring($srctxt));
        $dfc=difflines($ochax,$cst);
        $ptcst=explode(",",$cst);
        $totcs=count($ptcst);
        switch($srctype){
            case "tabaction":
            if ($msrcid==$msrctitle){
             $msrctitle=UX("select tabtitle as result from coode_tablist where TABLE_NAME='".$msrcid."'");    
            }
             $zzx=UX("update coode_tabtree set lines='".$nlenx."',allcharas='".$totcs."' where  tabname='".$msrcid."' and pointmark='".hou($ssrcid,".").".".qian($ssrcid,"@")."");    
            break;
            case "cls":
            if ($msrcid==$msrctitle){
             $msrctitle=UX("select funcname as result from coode_phpcls where funname='".$msrcid."' or funname='".$msrcid."()'");       
                
            }
            $zzx=UX("update coode_phpcls set lines='".$nlenx."',allcharas='".$totcs."' where  funname='".$msrcid."' or funname='".$msrcid."()'");    
            break;
            case "function":
            if ($msrcid==$msrctitle){
             $msrctitle=UX("select funcname as result from coode_funlist where funname='".$msrcid."' or funname='".$msrcid."()'");          
             
            }
            $zzx=UX("update coode_funlist set lines='".$nlenx."',allcharas='".$totcs."' where  funname='".$msrcid."' or funname='".$msrcid."()'");     
            break;
            case "template":
            if ($msrcid==$msrctitle){
                $msrctitle=UX("select unittitle as result from coode_domainunit where dumark='".$msrcid."' ");       
            }
            break;
            case "eletemp":
            if ($msrcid==$msrctitle){
                $msrctitle=UX("select evaltitle as result from coode_valeval where evalmark='".$msrcid."' ");       
            }
            break;
            case "linefacetemp":
            if ($msrcid==$msrctitle){
                $msrctitle=UX("select divtitle as result from coode_divunit where divmark='".$msrcid."' ");       
            }
            break;
            case "objfacetemp":
            if ($msrcid==$msrctitle){
                $msrctitle=UX("select divunitftitle as result from coode_divuframe where divunitfrmid='".$msrcid."' ");       
            }
            break;
            default:
            
        }
        $sqlx="srcmainid,srcmaintitle,srcsubid,srcsubtitle,srctype,prelines,newlines,preupdt,charaset,CRTM,UPTM,OLMK,CRTOR,newmaker,difflines,newcharas,killcharas,allcharas,bakver";
        $sqly="'".$msrcid."','".$msrctitle."','".$ssrcid."','".$ssrctitle."','".$srctype."','".$olenx."','".$nlenx."','".$oldtm."','".$cst."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."','".$_COOKIE["uid"]."','".intval($nlenx-$olenx)."','".qian($dfc,"/")."','".hou($dfc,"/")."','".$totcs."','".gohex($srctxt)."'";
        $zz=UX("insert into coode_srclines(".$sqlx.")values(".$sqly.")");
        $zzx=UX("update coode_srclines set vermd5=md5(charaset) where vermd5='' ");
        return true;
    }else{
        return false;
    }
}
function reclinex($msrcmark,$msrctitle,$ssrcmark,$ssrctitle,$srctype,$olenx,$nlenx,$srctxt){
    if (es($msrcmark)*es($msrctitle)*es($srctype)*es($olenx)*es($nlenx)==1){
      $oldrst=SX("select itemCTime,charaSet from iO_linesChange where srcMainMark='".$msrcmark."' order by itemCTime desc");
        $oldtm=anyvalue($oldrst,"itemCTime",0);
        $ochax=anyvalue($oldrst,"charaSet",0);
        if ($oldtm==""){
            $oldtm=date("Y-m-d H:i:s");
        }
        $cst=recochara(tostring($srctxt));
        $dfc=difflines($ochax,$cst);
        $ptcst=explode(",",$cst);
        $totcs=count($ptcst);
        switch($srctype){
            case "tabaction":
            if ($msrcmark==$msrctitle){
             $msrctitle=UX("select tabTitle as result from iO_tabList where tabRName='".$msrcmark."'");    
            }
             $zzx=UX("update iO_dtabTree set totLines='".$nlenx."',totCharas='".$totcs."' where  tabName='".$msrcmark."' and pointMark='".hou($ssrcmark,".").".".qian($ssrcmark,"@")."");    
            break;
            case "class":
            if ($msrcmark==$msrctitle){
              $msrctitle=UX("select clsTitle as result from iO_phpClass where clsMark='".$msrcmark."'");       
            }
            $zzx=UX("update iO_phpClass set totLines='".$nlenx."',totCharas='".$totcs."' where clsMark='".$msrcmark."'");
            break;
            case "function":
            if ($msrcmark==$msrctitle){
             $msrctitle=UX("select funName as result from iO_phpFunction where funMark='".$msrcmark."'");          
            }
            $zzx=UX("update iO_phpFunction set totLines='".$nlenx."',totCharas='".$totcs."' where  funMark='".$msrcmark."");     
            break;
            case "template":
            if ($msrcmark==$msrctitle){
                $msrctitle=UX("select pTempTitle as result from iO_pageTemp where pTempID='".$msrcmark."' ");       
            }
            break;
            case "eletemp":
            if ($msrcmark==$msrctitle){
                $msrctitle=UX("select evalTitle as result from iO_pointLineTemp where evalMark='".$msrcmark."' ");       
            }
            break;
            case "linefacetemp":
            if ($msrcmark==$msrctitle){
                $msrctitle=UX("select lfTitle as result from iO_lineFaceTemp where lfMark='".$msrcmark."' ");       
            }
            break;
            case "objfacetemp":
            if ($msrcmark==$msrctitle){
                $msrctitle=UX("select ofTitle as result from iO_objFaceTemp where ofMark='".$msrcmark."' ");       
            }
            break;
            default:
        }
        $sqlx="srcMainMark,srcMainTitle,srcSubMark,srcSubTitle,srcType,preLines,newLines,preUpdt,charaSet,itemCTime,itemUTime,itemOnlyMark,itemCrtor,newMaker,diffLines,newCharas,killCharas,allCharas,bakVer";
        $sqly="'".$msrcid."','".$msrctitle."','".$ssrcid."','".$ssrctitle."','".$srctype."','".$olenx."','".$nlenx."','".$oldtm."','".$cst."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."','".$_COOKIE["uid"]."','".intval($nlenx-$olenx)."','".qian($dfc,"/")."','".hou($dfc,"/")."','".$totcs."','".gohex($srctxt)."'";
        $zz=UX("insert into iO_linesChange(".$sqlx.")values(".$sqly.")");
        $zzx=UX("update iO_linesChange set vermd5=md5(charaSet) where vermd5='' ");
        return true;
    }else{
        return false;
    }
}
function recmylines($msrcid,$msrctitle,$ssrcid,$ssrctitle,$srctype,$olenx,$nlenx,$srctxt){
    if (es($msrcid)*es($msrctitle)*es($ssrcid)*es($srctype)*es($ssrctitle)*es($olenx)*es($nlenx)==1){
        $oldrst=SX("select CRTM,charaset from coode_srclines where srcmainid='".$msrcid."' and srcsubid='".$ssrcid."' order by CRTM desc");
        $oldtm=anyvalue($oldrst,"CRTM",0);
        $ochax=anyvalue($oldrst,"charaset",0);
        if ($oldtm==""){
            $oldtm=date("Y-m-d H:i:s");
        }
        switch($srctype){
            case "tabaction":
            if ($msrcid==$msrctitle){
             $msrctitle=UX("select tabtitle as result from coode_mytablist where TABLE_NAME='".$msrcid."'");    
            }
             $zzx=UX("update coode_mytabtree set lines='".$nlenx."',allcharas='".$totcs."' where  tabname='".$msrcid."' and pointmark='".hou($ssrcid,".").".".qian($ssrcid,"@")."");    
            break;
            case "cls":
            if ($msrcid==$msrctitle){
             $msrctitle=UX("select funcname as result from coode_mycls where funname='".$msrcid."' or funname='".$msrcid."()'");       
            }
            $zzx=UX("update coode_mycls set lines='".$nlenx."',allcharas='".$totcs."' where  funname='".$msrcid."' or funname='".$msrcid."()'");     
            break;
            case "function":
            if ($msrcid==$msrctitle){
             $msrctitle=UX("select funcname as result from coode_myfun where funname='".$msrcid."' or funname='".$msrcid."()'");          
            }
            $zzx=UX("update coode_myfun set lines='".$nlenx."',allcharas='".$totcs."' where  funname='".$msrcid."' or funname='".$msrcid."()'");     
            break;
            case "template":
            if ($msrcid==$msrctitle){
                $msrctitle=UX("select unittitle as result from coode_mydounit where dumark='".$msrcid."' ");       
            }
            break;
            case "eletemp":
            if ($msrcid==$msrctitle){
                $msrctitle=UX("select evaltitle as result from coode_myvaleval where evalmark='".$msrcid."' ");       
            }
            break;
            case "linefacetemp":
            if ($msrcid==$msrctitle){
                $msrctitle=UX("select divtitle as result from coode_mydivunit where divmark='".$msrcid."' ");       
            }
            break;
            case "objfacetemp":
            if ($msrcid==$msrctitle){
                $msrctitle=UX("select divunitftitle as result from coode_mydivuframe where divunitfrmid='".$msrcid."' ");       
            }
            break;
            default:
            
        }
        $cst=recochara(tostring($srctxt));
        $dfc=difflines($ochax,$cst);
        $ptcst=explode(",",$cst);
        $totcs=count($ptcst);
        $sqlx="srcmainid,srcmaintitle,srcsubid,srcsubtitle,srctype,prelines,newlines,preupdt,charaset,CRTM,UPTM,OLMK,CRTOR,newmaker,difflines,newcharas,killcharas,allcharas,bakver";
        $sqly="'".$msrcid."','".$msrctitle."','".$ssrcid."','".$ssrctitle."','".$srctype."','".$olenx."','".$nlenx."','".$oldtm."','".$cst."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."','".$_COOKIE["uid"]."','".intval($nlenx-$olenx)."','".qian($dfc,"/")."','".hou($dfc,"/")."','".$totcs."','".gohex($srctxt)."'";
        $zz=UX("insert into coode_mysrclines(".$sqlx.")values(".$sqly.")");
        $zzx=UX("update coode_mysrclines set vermd5=md5(charaset) where vermd5='' ");
        return true;
    }else{
        return false;
    }
}
function checklines($ostr,$nstrx){
    $osx=tostring($ostr);
    $nsx=tostring($nstrx);
    $opt=explode("\r\n",$osx);   
    $npt=explode("\r\n",$nsx);
    return count($opt)."/".count($npt);
}
function difflines($ocha,$ncha){
   $pto=explode(",",$ocha);
   $toto=count($pto);
   $ptn=explode(",",$ncha);
   $totn=count($ptn);
   $tmpa=0;
   $tmpk=0;
   for ($i=0;$i<$totn;$i++){
       if (strpos("xx-".$ocha,$ptn[$i])>0){
       }else{
           $tmpa=$tmpa+1;
       }
   }
   for ($i=0;$i<$toto;$i++){
       if (strpos("xx-".$ncha,$pto[$i])>0){
       }else{
           $tmpk=$tmpk+1;
       }
   }
   return $tmpa."/".$tmpk;
}
?>