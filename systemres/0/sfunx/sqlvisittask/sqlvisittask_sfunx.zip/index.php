<?php
function asynsql($dbip,$dbuser,$dbpass,$dbase,$dbport,$runsql,$rundes){
    if (es($dbip)*es($dbuser)*es($dbpass)*es($dbase)*es($runsql)==1){
        $sqlx="dbName,dbIp,dbUser,dbPass,dbPort,runSql,sqlDescrib,createTime,updateTime,crtMark,crtTitle,runTime";
        $sqly="'".$dbase."','".$dbip."','".$dbuser."','".$dbpass."','".$dbport."','".gohex($runsql)."','".$rundes."',now(),now(),'".$_COOKIE["uid"]."','',now()";
        $zx=UX("insert into iO_asynSql(".$sqlx.")values(".$sqly.")");
        return true;
    }else{
        echo "hellowocao=".$dbip.$buser.$dbpass.$dbase.$dbport.$runsql.$rundes;
        return false;
    }
}
function asynvisit($taskmark,$tasktitle,$vurl,$vtitle){
    if (es($taskmark)*es($tasktitle)*es($vurl)*es($vtitle)==1){
        $sqlx="taskMark,taskTitle,vUrl,vTitle,visited,visitTime,createTime,updateTime";
        $sqly="'".$taskmark."','".$tasktitle."','".$vurl."','".$vtitle."','0',now(),now(),now()";
        $zx=UX("insert into iO_asynRunFun(".$sqlx.")values(".$sqly.")");
        return true;
    }else{
        
        return false;
    }
}
?>