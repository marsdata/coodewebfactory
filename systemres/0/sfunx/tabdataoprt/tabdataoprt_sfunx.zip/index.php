<?php
function makefullcdt($stid){
    return "";
}
function sqlmaketab($stid,$sqlx,$dtype){
    return "";
}
function tabmake($tabnm){
  $conn=mysql_connect(gl(),glu(),glp());
  $trst=selecteds($conn,"information_schema","select TABLE_CATALOG,TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,ORDINAL_POSITION,COLUMN_DEFAULT,IS_NULLABLE,DATA_TYPE,CHARACTER_MAXIMUM_LENGTH,CHARACTER_OCTET_LENGTH,NUMERIC_PRECISION,NUMERIC_SCALE,CHARACTER_SET_NAME,COLLATION_NAME,COLUMN_TYPE,COLUMN_KEY,EXTRA,PRIVILEGES,COLUMN_COMMENT from COLUMNS where TABLE_SCHEMA='".glb()."' and TABLE_NAME='".$tabnm."'","utf8","");
  $totrst=countresult($trst);
  $btree=betrees($tabnm);
  $fmc="";
  $tbdk="X/CRTM/UPTM/CRTOR/STATUS/OLMK/VRT/STCODE/PTOF/PRIME/RIP/SNO/OPRT/";
  if ($tabnm=="coode_keydetailx" or $tabnm=="coode_keydetaily"){
     $expk="X/ORDINAL_POSITION,COLUMN_DEFAULT,IS_NULLABLE,CHARACTER_OCTET_LENGTH,NUMERIC_PRECISION,NUMERIC_SCALE,DATETIME_PRECISION,CHARACTER_SET_NAME,COLLATION_NAME,COLUMN_TYPE,COLUMN_KEY,EXTRA,PRIVILEGES,COLUMN_COMMENT";
  }else{
     $expk="";
  }
  for ($k=0;$k<$totrst;$k++){
   $sTABLE_CATALOG[$k]=anyvalue($trst,"TABLE_CATALOG",$k);
   $sTABLE_SCHEMA[$k]=anyvalue($trst,"TABLE_SCHEMA",$k);
   $sTABLE_NAME[$k]=anyvalue($trst,"TABLE_NAME",$k);
   $sCOLUMN_NAME[$k]=anyvalue($trst,"COLUMN_NAME",$k);
   $sORDINAL_POSITION[$k]=anyvalue($trst,"ORDINAL_POSITION",$k);
   $sCOLUMN_DEFAULT[$k]=anyvalue($trst,"COLUMN_DEFAULT",$k);
   $sIS_NULLABLE[$k]=anyvalue($trst,"IS_NULLABLE",$k);
   $sDATA_TYPE[$k]=anyvalue($trst,"DATA_TYPE",$k);
   $sCHARACTER_MAXIMUM_LENGTH[$k]=anyvalue($trst,"CHARACTER_MAXIMUM_LENGTH",$k);
   $sCHARACTER_OCTET_LENGTH[$k]=anyvalue($trst,"CHARACTER_OCTET_LENGTH",$k);
   $sNUMERIC_PRECISION[$k]=anyvalue($trst,"NUMERIC_PRECISION",$k);
   $sNUMERIC_SCALE[$k]=anyvalue($trst,"NUMERIC_SCALE",$k);
   $sCHARACTER_SET_NAME[$k]=anyvalue($trst,"CHARACTER_SET_NAME",$k);
   $sCOLLATION_NAME[$k]=anyvalue($trst,"COLLATION_NAME",$k);
   $sCOLUMN_TYPE[$k]=anyvalue($trst,"COLUMN_TYPE",$k);
   $sCOLUMN_KEY[$k]=anyvalue($trst,"COLUMN_KEY",$k);
   $sEXTRA[$k]=anyvalue($trst,"EXTRA",$k);
   $sPRIVILEGES[$k]=anyvalue($trst,"PRIVILEGES",$k);
   $sCOLUMN_COMMENT[$k]=anyvalue($trst,"COLUMN_COMMENT",$k);
   $somark[$k]=date('Ymdhis').getRandChar(6);
   switch($sDATA_TYPE[$k]){
    case "int":
    if ($sCOLUMN_NAME[$k]=="SNO"){
      $fmc=$fmc.$sCOLUMN_NAME[$k]." int(11) NOT NULL AUTO_INCREMENT,";
    }else{
      $fmc=$fmc.$sCOLUMN_NAME[$k]." int(11) NOT NULL,";
    }
    break;
    case "bigint":
    if ($sCOLUMN_NAME[$k]=="SNO"){
      $fmc=$fmc.$sCOLUMN_NAME[$k]." bigint(20) NOT NULL AUTO_INCREMENT,";
    }else{
      $fmc=$fmc.$sCOLUMN_NAME[$k]." bigint(20) NOT NULL,";
    }
    break;
    case "tinyint":
    if ($sCOLUMN_NAME[$k]=="SNO"){
      $fmc=$fmc.$sCOLUMN_NAME[$k]." tinyint(4) NOT NULL AUTO_INCREMENT,";
    }else{
      $fmc=$fmc.$sCOLUMN_NAME[$k]." tinyint(4) NOT NULL,";
    }
    break;
    case "decimal":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." decimal(10,2) NOT NULL,";
    break;
    case "varchar":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." varchar(".$sCHARACTER_MAXIMUM_LENGTH[$k].") NOT NULL,";
    break;
    case "text":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." text NOT NULL,";
    break;
    case "longtext":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." longtext NOT NULL,";
    break;
    case "date":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." date NOT NULL,";
    break;
    case "datetime":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." datetime NOT NULL,";
    break;    
    default:
   } 
 }
 $fmc=$fmc."PRIMARY KEY (SNO),";
 if ($btree==""){
   $fmc=killlaststr($fmc);
 }else{
   $fmc=$fmc.$btree;
 } 
 $crtsql="CREATE TABLE ".$tabnm." (".$fmc.") ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;";
 return $crtsql;
}
function tabalter($oldSql, $newSql){
    // 解析老表和新表的结构（纯字符串解析，无正则）
    $oldTable = parseCreateTableSql($oldSql);
    $newTable = parseCreateTableSql($newSql);
    // 校验表名是否一致（修改不同表无意义）
    if ($oldTable['tableName'] !== $newTable['tableName']) {
        throw new Exception("老表【{$oldTable['tableName']}】和新表【{$newTable['tableName']}】表名不一致，无法修改");
    }
    $tableName = $oldTable['tableName'];
    // 初始化操作列表
    $alterOperations = [];
    // 1. 处理【修改字段】：字段名存在但定义不同
    foreach ($newTable['fields'] as $fieldName => $newFieldDef) {
        if (isset($oldTable['fields'][$fieldName])) {
            $oldFieldDef = $oldTable['fields'][$fieldName];
            // 去除两端空格后对比（避免空格差异导致误判）
            if (trim($newFieldDef) !== trim($oldFieldDef)) {
                $alterOperations[] = "MODIFY COLUMN `{$fieldName}` {$newFieldDef}";
            }
        }
    }
    // 2. 处理【新增字段】：新表有、老表无
    $addFields = array_diff_key($newTable['fields'], $oldTable['fields']);
    foreach ($addFields as $fieldName => $fieldDef) {
        $alterOperations[] = "ADD COLUMN `{$fieldName}` {$fieldDef}";
    }
    // 3. 处理【删除字段】：老表有、新表无
    $dropFields = array_diff_key($oldTable['fields'], $newTable['fields']);
    foreach ($dropFields as $fieldName => $_) {
        $alterOperations[] = "DROP COLUMN `{$fieldName}`";
    }
    // 无修改则返回空字符串
    if (empty($alterOperations)) {
        return 'nokey';
    }
    // 拼接最终ALTER语句（单条语句合并多个操作，效率更高）
    $alterSql = "ALTER TABLE `{$tableName}` " . implode(', ', $alterOperations) . ';';
    return $alterSql;
}
/**
 * 纯字符串方式解析CREATE TABLE语句，提取表名和字段定义（无任何正则）
 * @param string $sql CREATE TABLE语句
 * @return array ['tableName' => 表名, 'fields' => [字段名=>字段完整定义]]
 * @throws Exception 解析失败抛出异常
 */
function parseCreateTableSql(string $sql): array
{
    // 预处理：移除所有换行、制表符，替换多个空格为单个（纯字符串实现，无正则）
    $sql = str_replace(["\n", "\r", "\t"], ' ', $sql);
    // 循环替换多个空格为单个，替代preg_replace('/\s+/', ' ', $sql)
    while (strpos($sql, '  ') !== false) {
        $sql = str_replace('  ', ' ', $sql);
    }
    $sql = trim($sql);
    $sqlUpper = strtoupper($sql);
    // ------------------- 步骤1：提取表名 -------------------
    // 定位 CREATE TABLE 后的表名（到第一个左括号为止）
    $createTableStr = 'CREATE TABLE ';
    $createTablePos = strpos($sqlUpper, $createTableStr);
    if ($createTablePos === false) {
        throw new Exception("不是有效的CREATE TABLE语句：{$sql}");
    }
    $tableNameStart = $createTablePos + strlen($createTableStr);
    $leftBracketPos = strpos($sql, '(', $tableNameStart);
    if ($leftBracketPos === false) {
        throw new Exception("未找到表结构的左括号，SQL格式错误：{$sql}");
    }
    // 截取表名部分并清理（去掉反引号、多余空格）
    $tableName = trim(substr($sql, $tableNameStart, $leftBracketPos - $tableNameStart));
    $tableName = str_replace('`', '', $tableName);
    if (empty($tableName)) {
        throw new Exception("无法解析出表名，SQL格式错误：{$sql}");
    }
    // ------------------- 步骤2：提取括号内的字段/约束内容 -------------------
    $rightBracketPos = strrpos($sql, ')'); // 找最后一个右括号（避免括号嵌套）
    if ($rightBracketPos === false || $rightBracketPos < $leftBracketPos) {
        throw new Exception("未找到表结构的右括号，SQL格式错误：{$sql}");
    }
    $bracketContent = trim(substr($sql, $leftBracketPos + 1, $rightBracketPos - $leftBracketPos - 1));
    if (empty($bracketContent)) {
        throw new Exception("表结构括号内无内容，SQL格式错误：{$sql}");
    }
    // ------------------- 步骤3：拆分内容为行，过滤约束，提取字段 -------------------
    $fields = [];
    // 按逗号拆分（仅拆分不在括号内的逗号，避免字段类型如decimal(10,2)内的逗号干扰）
    $lines = splitByCommaOutsideBrackets($bracketContent);
    
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line)) {
            continue;
        }
        $lineUpper = strtoupper($line);
        // 过滤约束行（主键、唯一键、索引、约束等）
        $skipKeywords = ['PRIMARY KEY', 'UNIQUE KEY', 'KEY ', 'CONSTRAINT', 'INDEX '];
        $isConstraint = false;
        foreach ($skipKeywords as $keyword) {
            if (strpos($lineUpper, $keyword) === 0) {
                $isConstraint = true;
                break;
            }
        }
        if ($isConstraint) {
            continue;
        }
        // ------------------- 提取字段名和字段定义 -------------------
        // 找到第一个空格的位置（字段名和属性的分隔）
        $firstSpacePos = strpos($line, ' ');
        if ($firstSpacePos === false) {
            continue; // 无效的字段行（无属性定义）
        }
        // 提取字段名（去掉反引号）
        $fieldName = trim(substr($line, 0, $firstSpacePos));
        $fieldName = str_replace('`', '', $fieldName);
        // 过滤无效字段名（不能以数字开头、不能为空）→ 纯字符串判断，替代preg_match
        if (empty($fieldName) || isStartWithNumber($fieldName)) {
            continue;
        }
        // 提取字段完整属性定义
        $fieldDef = trim(substr($line, $firstSpacePos));
        $fields[$fieldName] = $fieldDef;
    }
    if (empty($fields)) {
        throw new Exception("未解析到任何字段，SQL格式错误：{$sql}");
    }
    return [
        'tableName' => $tableName,
        'fields' => $fields
    ];
}
/**
 * 纯字符串判断：字符串是否以数字开头（替代preg_match('/'[0-9]/', $str)）
 * @param string $str 待判断字符串
 * @return bool true=以数字开头，false=否
 */
function isStartWithNumber(string $str): bool
{
    if (empty($str)) {
        return false;
    }
    $firstChar = $str[0];
    // 判断第一个字符是否是0-9
    return $firstChar >= '0' && $firstChar <= '9';
}
/**
 * 按括号外的逗号拆分字符串（解决decimal(10,2)等字段内逗号的问题）
 * @param string $str 待拆分的字符串
 * @return array 拆分后的行数组
 */
function splitByCommaOutsideBrackets(string $str): array
{
    $result = [];
    $current = '';
    $bracketCount = 0; // 括号嵌套计数
    for ($i = 0; $i < strlen($str); $i++) {
        $char = $str[$i];
        if ($char === '(') {
            $bracketCount++;
        } elseif ($char === ')') {
            $bracketCount--;
            if ($bracketCount < 0) {
                $bracketCount = 0; // 容错：括号不匹配时重置
            }
        } elseif ($char === ',' && $bracketCount === 0) {
            // 仅当括号计数为0时，按逗号拆分
            $result[] = $current;
            $current = '';
            continue;
        }
        $current .= $char;
    }
    // 加入最后一段内容
    if (!empty(trim($current))) {
        $result[] = $current;
    }
    return $result;
}
function cloneitem($tbs1,$tbs2,$keys,$cdts,$extk,$extkev){
if ($cdts!=""){
 if ($extk!=""){
  if (substr($extk,0,1)!=","){
   $extkk=",".$extk;
  };
  $conn=mysql_connect(gl(),glu(),glp());
  $x=updatingx($conn,glb(),"insert into ".$tbs2."(".$keys.$extkk.",CRTM,UPTM)select ".$keys.",concat(mid(".$extk.",1,length(".$extk.")-length('".$extkev."')),'".$extkev."'),now(),now() from ".$tbs1." where ".$cdts,"utf8");
  //echo "insert into ".$tbs2."(".$keys.$extkk.",CRTM,UPTM)select ".$keys.",concat(mid(".$extk.",1,length(".$extk.")-length('".$extkev."')),'".$extkev."'),now(),now() from ".$tbs1." where ".$cdts;
 }else{
  $conn=mysql_connect(gl(),glu(),glp());
  $x=updatingx($conn,glb(),"insert into ".$tbs2."(".$keys.")select ".$keys." from ".$tbs1." where ".$cdts,"utf8");
 };
};
return 1;
}
function sameitem($tbs1,$tbs2,$key1s,$key2s,$cdts){
  if ($cdts!=""){
    $ptk1=explode(",",$key1s);
    $ptk2=explode(",",$key2s);
    $totpt=count($ptk1);
    $fmkx="";
    for ($i=0;$i<$totpt;$i++){
      $fmkx=$fmkx.",".$tbs2.".".$ptk2[$i]."=".$tbs1.".".$ptk1[$i];
    };
    if ($totpt>0){
      $fmkx=substr($fmkx,1,strlen($fmkx)-1);
    };    
      $conn=mysql_connect(gl(),glu(),glp());
      $x=updatingx($conn,glb(),"update ".$tbs1.",".$tbs2." set ".$fmkx." where ".$cdts,"utf8");    
      $conn=mysql_connect(gl(),glu(),glp());
      $tb2sno=updatingx($conn,glb(),"select ".$tbs2.".SNO as result from ".$tbs1.",".$tbs2."  where ".$cdts,"utf8");    
      $conn=mysql_connect(gl(),glu(),glp());        
      $bdx=updatingx($conn,glb(),"update coode_shortaffect set UPTM=now() where tablename='".$tbs2."' and concat(',',snos,',') like '%,".$tb2sno.",%'","utf8");
  };
   return 1;
}
function exttx($tbn,$cdt){
 $conn=mysql_connect(gl(),glu(),glp());
 $exx=updatingx($conn,glb(),"select count(*) as result from ".$tbn." where ".$cdt,"utf8");
 return $exx;
}
function existstab($dbif,$tbnm){
    eval(RESFUNSET("tabbaseinfo"));
    if ( $dbif==glb()){
      $conn=mysql_connect(gl(),glu(),glp());
      $extx=updatings($conn,"information_schema","select count(*) as result from TABLES where TABLE_SCHEMA='".$dbif."' and TABLE_NAME='".$tbnm."'","utf8");
      if (intval($extx)>0){
         return true;
      }else{
         return false;
      }
    }else{
        $dbi=array();
        $dbi=getdbinfo($dbif,$tbnm,$dbi);
        $conn=mysql_connect($dbi["fip"],$dbi["fuser"],$dbi["fpass"]);
        $extx=updatings($conn,"information_schema","select count(*) as result from TABLES where TABLE_SCHEMA='".$dbif."' and TABLE_NAME='".$tbnm."'","utf8");
      if (intval($extx)>0){
         return true;
      }else{
         return false;
      } 
    }
}
function newsysres($sysid,$restype,$rescode,$restitle){
 $extr=UX("select count(*) as result from coode_sysregres where restype='".$restype."' and resmark='".$rescode."' and grpid='".$sysid."'");
 if (intval($extr)==0 and $sysid!=""){
   $sqla="grpid,restype,resmark,restitle,CRTM,UPTM,OLMK";
   $sqlb="'".$sysid."','".$restype."','".$rescode."','".$restitle."',now(),now(),'".onlymark()."'";
   $cc=UX("insert into coode_sysregres(".$sqla.")values(".$sqlb.")");   
 }
 return true;
}
function getjkval($jfx,$kx){
 $jtxt=file_get_contents($jfx);
 $jdata=json_decode($jtxt,false);
 $vls=$jdata->vls;
 $val="";
 for ($jj=0;$jj<count($vls);$jj++){
   $kmk=$vls[$jj]->keymark;
   if ($kmk==$kx){
     $val=$vls[$jj]->kvalue;
   }
 }
 return $val;
}
function takevaljson($jsonfile){
//$zz=addprcx($jsonfile);
 $jsontxt=file_get_contents($jsonfile);
 $jsondata=json_decode($jsontxt);
 $tabnm=$jsondata->tabnm;
 $crtsql=$jsondata->crtsql;
 $vls=$jsondata->vls;
 $stt=$jsondata->status;
 $tabtitle=$jsondata->tabtitle;
 $srckeyx=$jsondata->srckey;
 $parreskey=$jsondata->parreskey;
 $mainsqx=$jsondata->mainsqx;
 $fmk="";
 $fmv="";
 //echo $crtsql."--";
 if (intval($stt)>0){
  $exttab=UX("select count(*) as result from coode_tablist where TABLE_NAME='".$tabnm."'");
   if (intval($exttab)==0){
    $z0=crttab(0,$crtsql);   
    $oldcrt=tabmake($tabnm);
    $newcrt=$crtsql;
    $astr=tabalter($oldcrt,$newcrt);
    if ($astr!="nokey"){
       $conn=mysql_connect(gl(),glu(),glp());
       $nn=updatingx($conn,glb(),$astr,"utf8");
    }
     $sqlx="TABLE_NAME,tabtitle,mainsqx,srckey,srcttk,parreskey,CRTM,UPTM,OLMK";
     $sqly="'$tabnm','$tabtitle','$mainsqx','$srckeyx','$srcttk','$parreskey',now(),now(),'".onlymark()."'";
     $zz=UX("insert into coode_tablist(".$sqlx.")values(".$sqly.")");
   }else{//exttab
     $tbrst=SX("select srckey,srcttk,parreskey from coode_tablist where TABLE_NAME='".$tabnm."'");
     $srckeyy=anyvalue($tbrst,"srckey",0);
     $parkeyy=anyvalue($tbrst,"parreskey",0);
     if ($srckeyy==""){
       $zz=UX("update coode_tablist set srckey='".$srckeyx."',parreskey='".$parreskey."' where  TABLE_NAME='".$tabnm."'");
     }else{
       $srckey=dftval($srckeyx,$srckeyy);
       $parkey=dftval($parreskey,$parkeyy);
     }
     $oldcrt=tabmake($tabnm);
     $newcrt=$crtsql;
     if ($newcrt!="" and $oldcrt!=""){
       $astr=tabalter($oldcrt,$newcrt);
     }else{
       $astr="nokey";
     }
     if ($astr!="nokey"){
       $conn=mysql_connect(gl(),glu(),glp());
       $nn=updatingx($conn,glb(),$astr,"utf8");
     }
    }//exttab
    $srcval="";
    $parval="";
    $fmupdt="";
    $fmcdt="";
   if ($srckey!=""){
    for ($j=0;$j<count($vls);$j++){
     if ($vls[$j]->keymark==$srckey or $vls[$j]->keymark==$parkey){
       if ($vls[$j]->keymark==$srckey){
         $srcval=$vls[$j]->kvalue;
       }else{
         $parval=$vls[$j]->kvalue;
       }
     }else{
       $fmupdt=$fmupdt.$vls[$j]->keymark."='".str_replace("'","\'",$vls[$j]->kvalue)."',";
       $fmcdt=$fmcdt." ".$vls[$j]->keymark."='".$vls[$j]->kvalue."' and";
     }   
    }//for
     $fmupdt=killlaststr($fmupdt);
    if ($srcval==""){
      return false;
    }
    if ($parkey!=""){     
      if ($parval==""){
       return false;
      }
      $extdd=UX("select count(*) as result from ".$tabnm." where  ".$srckey."='".$srcval."' and ".$parkey."='".$parval."'");      
    }else{     
      $extdd=UX("select count(*) as result from ".$tabnm." where  ".$srckey."='".$srcval."'");
    }
    if ($extdd==0){
     for ($j=0;$j<count($vls);$j++){
      $fmk=$fmk.$vls[$j]->keymark.",";
      $fmv=$fmv."'".str_replace("'","\'",$vls[$j]->kvalue)."',";
     }
     $fmk=killlaststr($fmk);
     $fmv=killlaststr($fmv); 
     $zz=UX("insert into ".$tabnm."(".$fmk.")values(".$fmv.")");  
     //$zz=addprcx ("insert into ".$tabnm."(".$fmk.")values(".$fmv.")@tabdataoprt");
    }else{   
     if ($parkey!=""){
       $zz=UX("update ".$tabnm." set ".$fmupdt." where ".$parkey."='".$parval."' and ".$srckey."='".$srcval."'");      
     }else{
       $zz=UX("update ".$tabnm." set ".$fmupdt." where ".$srckey."='".$srcval."'");      
       //$zz1=addprcx("update ".$tabnm." set ".$fmupdt." where ".$srckey."='".$srcval."'@tabdataoprt");
     }
    }//ifextdd
    if ($parkey!=""){     
      $extd=UX("select count(*) as result from ".$tabnm." where  ".$srckey."='".$srcval."' and ".$parkey."='".$parval."'");
    }else{
      $extd=UX("select count(*) as result from ".$tabnm." where  ".$srckey."='".$srcval."'");
    }
    if (intval($extd)>0){
      return true;
    }else{
      return false;
    }
   }else{
     return false;
   }//srckey
  
 }else{//stt
   return false;
 }
}
function makevaljson($rtype,$ver,$tabnm,$tabsno){
  $tempsrd='{"status":"1","tabnm":"[tabnm]","tabtitle":"[tabtitle]","tabsno":"[tabsno]","crtsql":"[crtsql]","allkeys":"[allkeys]","parreskey":"[parreskey]","mainsqx":"[mainsqx]","srckey":"[srckey]","srcttk":"[srcttk]","rtype":"[rtype]","parcode":"[parcode]","rcode":"[rcode]","rtitle":"[rtitle]","ver":"[ver]","vls":[<data>]}';
  $keyitem='{"keymark":"[keymark]","dxtype":"[dxtype]","keytitle":"[keytitle]","kvalue":"[kvalue]"},';
  $trst=SX("select createsql,srckey,parreskey,srcttk,mainsqx,allkeys,tabtitle from coode_tablist where TABLE_NAME='".$tabnm."'");
  $tott=countresult($trst);
  if ($tott>0){
     $crtsql=anyvalue($trst,"createsql",0);
     $srckey=anyvalue($trst,"srckey",0);
     $parreskey=anyvalue($trst,"parreskey",0);
     $srcttk=anyvalue($trst,"srcttk",0);
     $mainsqx=anyvalue($trst,"mainsqx",0);
     $allks=anyvalue($trst,"allkeys",0);
     $tabtitle=anyvalue($trst,"tabtitle",0);
     $rtitle="";     
     $tempsrd=str_replace("[rtype]",$rtype,$tempsrd);
     $tempsrd=str_replace("[ver]",$ver,$tempsrd);
     $tempsrd=str_replace("[tabnm]",$tabnm,$tempsrd);
     $tempsrd=str_replace("[tabsno]",$tabsno,$tempsrd);
     $tempsrd=str_replace("[crtsql]",$crtsql,$tempsrd);
     $tempsrd=str_replace("[allkeys]",$allks,$tempsrd);
     $tempsrd=str_replace("[srckey]",$srckey,$tempsrd);
     $tempsrd=str_replace("[parreskey]",$parreskey,$tempsrd);
     $tempsrd=str_replace("[srcttk]",$srcttk,$tempsrd);
     $tempsrd=str_replace("[mainsqx]",$mainsqx,$tempsrd);
     $tempsrd=str_replace("[tabtitle]",$tabtitle,$tempsrd);
     
     $allkx=hou($allks,"|");
     $allkx=str_replace($mainsqx.",","",$allkx);
     $drst=SX("select ".$allkx." from ".$tabnm." where ".$mainsqx."=".$tabsno);
     $totd=countresult($drst);
     $kxrst=SX("select COLUMN_NAME,keytitle,dxtype from coode_keydetailx where TABLE_NAME='".$tabnm."' and COLUMN_NAME!='".$mainsqx."'");
     $totk=countresult($kxrst);
     $fmval="";
     $parval="";
     $parcode="";
     $rcode="";
     for ($j=0;$j<($totk*$totd);$j++){
       $itemx=$keyitem;
       $colnm=anyvalue($kxrst,"COLUMN_NAME",$j);
       $coltt=anyvalue($kxrst,"keytitle",$j);
       $dxtype=anyvalue($kxrst,"dxtype",$j);
       $colval=anyvalue($drst,$colnm,0);
       switch($colnm){
         case $srckey:
          $rcode=$colval;
         break;
         case $srcttk:
          $rtitle=$colval;
         break;
         case "parreskey":
          $parval=$colval;
          $parcode=$colval;
         break;
         default:
       }
       $itemx=str_replace("[keymark]",$colnm,$itemx);
       $itemx=str_replace("[dxtype]",$dxtype,$itemx);
       
       $itemx=str_replace("[keytitle]",$coltt,$itemx);
       $itemx=str_replace("[kvalue]",str_replace("\"","\\"."\"",$colval),$itemx);
       $fmval=$fmval.$itemx;
     }
     $fmval=killlaststr($fmval);
     $tempsrd=str_replace("[parcode]",$parcode,$tempsrd);
     $tempsrd=str_replace("[rcode]",$rcode,$tempsrd);
     $tempsrd=str_replace("[rtitle]",$rtitle,$tempsrd);
     $tempsrd=str_replace("<data>",$fmval,$tempsrd);
     //if ($parval==""){
     //  $datapath=combineurl(localroot(),"/localxres/tabx/".$tabnm."/data/".str_replace(".","_",$rcoce).".json");
     //}else{
     //  $datapath=combineurl(localroot(),"/localxres/tabx/".$tabnm."/data/".str_replace(".","_",$parval)."-".str_replace(".","_",$rcoce).".json");
     //}
     $datapath=combineurl(localroot(),"/localxres/datax/".$tabnm."/data/".$tabsno.".json");
     $dataurl=combineurl("http://".glw(),"/localxres/datax/".$tabnm."/data/".$tabsno.".json");
     $zzx=overfile($datapath,$tempsrd);
     return $dataurl;
  }else{
    return "";
  }
}
function bakinstall($bakmk,$tabnm,$cdt){
      $pakvx="备份数据开始";
      $prstx="aaa";           
      $nn=addprc("sfunx","tabdataoprt",74,$pakvx,$prstx);
  $kx=UX("delete from coode_datainstall where resid='".$bakmk."'");    
  $trst=SX("select createsql,keynames,keytpnms,jsontpnms,jsonconts,tabtitle,srckey,srcttk,contentkeys,mainsqx,olmkkey,md5key from coode_tablist where schm='".glb()."' and TABLE_NAME='".$tabnm."'");
  $totx=countresult($trst);
   $extdt=UX("select count(*) as result from ".$tabnm." where ".$cdt);
      $sqlxx="select count(*) as result from ".$tabnm." where ".str_replace("'","\'",$cdt);      
      $nn=addprc("sfunx","tabdataoprt",80,"sqlx",$sqlxx);
  if ($totx>0 and intval($extdt)>0){  
   switch($tabnm){
    case "coode_keydetailx":
    $zz=UX("update coode_keydetailx set sysshowfun=replace(sysshowfun,'\',\'','\' , \'') where sysshowfun like '%\',\'%'");
    $zz=UX("update coode_keydetailx set acthtml=replace(acthtml,'\',\'','\' , \'') where acthtml like '%\',\'%'");
    $zz=UX("update coode_keydetailx set atnhtml=replace(atnhtml,'\',\'','\' , \'') where atnhtml like '%\',\'%'");
    break;
    case "coode_keydetaily":    
    $zz=UX("update coode_keydetaily set sysshowfun=replace(sysshowfun,'\',\'','\' , \'') where sysshowfun like '%\',\'%'");
    $zz=UX("update coode_keydetaily set acthtml=replace(acthtml,'\',\'','\' , \'') where acthtml like '%\',\'%'");
    $zz=UX("update coode_keydetaily set atnhtml=replace(atnhtml,'\',\'','\' , \'') where atnhtml like '%\',\'%'");
    break;
    case "coode_keydetailz":
    $zz=UX("update coode_keydetailz set sysshowfun=replace(sysshowfun,'\',\'','\' , \'') where sysshowfun like '%\',\'%'");
    $zz=UX("update coode_keydetailz set acthtml=replace(acthtml,'\',\'','\' , \'') where acthtml like '%\',\'%'");
    $zz=UX("update coode_keydetailz set atnhtml=replace(atnhtml,'\',\'','\' , \'') where atnhtml like '%\',\'%'");
    break;
    case "coode_dbkeydx":
    $zz=UX("update coode_dbkeydx set sysshowfun=replace(sysshowfun,'\',\'','\' , \'') where sysshowfun like '%\',\'%'");
    $zz=UX("update coode_dbkeydx set acthtml=replace(acthtml,'\',\'','\' , \'') where acthtml like '%\',\'%'");
    $zz=UX("update coode_dbkeydx set atnhtml=replace(atnhtml,'\',\'','\' , \'') where atnhtml like '%\',\'%'");
    break;
    case "coode_dbkeydy":
    $zz=UX("update coode_dbkeydy set sysshowfun=replace(sysshowfun,'\',\'','\' , \'') where sysshowfun like '%\',\'%'");
    $zz=UX("update coode_dbkeydy set acthtml=replace(acthtml,'\',\'','\' , \'') where acthtml like '%\',\'%'");
    $zz=UX("update coode_dbkeydy set atnhtml=replace(atnhtml,'\',\'','\' , \'') where atnhtml like '%\',\'%'");
    break;
    case "coode_dbkeydz":
    $zz=UX("update coode_dbkeydz set sysshowfun=replace(sysshowfun,'\',\'','\' , \'') where sysshowfun like '%\',\'%'");
    $zz=UX("update coode_dbkeydz set acthtml=replace(acthtml,'\',\'','\' , \'') where acthtml like '%\',\'%'");
    $zz=UX("update coode_dbkeydz set atnhtml=replace(atnhtml,'\',\'','\' , \'') where atnhtml like '%\',\'%'");
    break;
    default:
   }
  
   $srck=anyvalue($trst,"srckey",0);
   $srctk=anyvalue($trst,"srcttk",0);
   $md5key=anyvalue($trst,"md5key",0);
  
   $crts=anyvalue($trst,"createsql",0);
   $mainsqx=anyvalue($trst,"mainsqx",0);
   $olmkkey=anyvalue($trst,"olmkkey",0);
   $knms=anyvalue($trst,"keynames",0);
   $ktps=anyvalue($trst,"keytpnms",0);
   $ckeys=anyvalue($trst,"contentkeys",0);  
   $ktps=str_replace("↓","'",$ktps);
   $ktps=str_replace("↑","\\"."'",$ktps);
   $jstp=anyvalue($trst,"jsontpnms",0);    
   $jstp=str_replace("↓","'",$jstp);
   $jstp=str_replace("∵","\":\"",$jstp);  
   $jscons=anyvalue($trst,"jsonconts",0);  
   $jscons=str_replace("↓","'",$jscons);
   $jscons=str_replace("∵","\":\"",$jscons);  
   if ($srck==""){
     $srck="VRT";
   }
   if ($srctk==""){
     $srctk="STCODE";
   }  
   if ($knms!="" and $ktps!="" and $jstp!=""){
        if ($mainsqx=="SNO"){
         $z=UX("insert into coode_datainstall(schm,resid,tabname,tabsno,tabolmk,conjson,datajson,datasql,crttab,tabkeys,CRTM,UPTM,CRTOR,itemcrtm,itemuptm,itemcrtor,itemprokey,itemproval,conkeys,mymd5,md5key,rescdt)select '".$dbase."','".$bakmk."','".$tabnm."',SNO,OLMK,concat('{',".$jscons.",'}'),concat('{',".$jstp.",'}'),concat('(',".$ktps.",')'),'".$crts."','".$knms."',now(),now(),'".$_COOKIE["uid"]."',CRTM,UPTM,CRTOR,'".$srck."',".$srck.",'".$ckeys."',".$md5key.",'".$md5key."','".md5($rescdt)."' from ".$tabnm." where ".$cdt);
        }else{
         $z=UX("insert into coode_datainstall(schm,resid,tabname,tabsno,tabolmk,conjson,datajson,datasql,crttab,tabkeys,CRTM,UPTM,CRTOR,itemcrtm,itemuptm,itemcrtor,itemprokey,itemproval,conkeys,mymd5,md5key,rescdt)select '".$dbase."','".$bakmk."','".$tabnm."',".$mainsqx.",".$olmkkey.",concat('{',".$jscons.",'}'),concat('{',".$jstp.",'}'),concat('(',".$ktps.",')'),'".$crts."','".$knms."',now(),now(),'".$_COOKIE["uid"]."',itemCTime,itemUTime,itemCrtID,'".$srck."',".$srck.",'".$ckeys."',".$md5key.",'".$md5key."','".md5($rescdt)."' from ".$tabnm." where ".$cdt); 
        }
        //$zzy=UX("update coode_datainstall set conjson=concat('〖',mid(conjson,3,length(conjson)-4),'〗') where mid(conjson,1,2)='{\"' and resid='".$bakmk."'");
        //$zzy=UX("update coode_datainstall set conjson=replace(conjson,'\":\"','Ｔ') where resid='".$bakmk."'");
        //$zzy=UX("update coode_datainstall set conjson=replace(conjson,'\",\"','Ｖ') where resid='".$bakmk."'");
        //$zzy=UX("update coode_datainstall set datajson=concat('〖',mid(datajson,3,length(datajson)-4),'〗') where mid(datajson,1,2)='{\"' and resid='".$bakmk."'");
        //$zzy=UX("update coode_datainstall set datajson=replace(datajson,'\":\"','Ｔ') where resid='".$bakmk."'");
        //$zzy=UX("update coode_datainstall set datajson=replace(datajson,'\",\"','Ｖ') where resid='".$bakmk."'");
        //$zzz=UX("update coode_datainstall set datasql=concat('〖',mid(datasql,3,length(datasql)-4),'〗') where mid(datasql,1,2)='(\'' and resid='".$bakmk."'");
        //$zzz=UX("update coode_datainstall set datasql=replace(replace(datasql,'".shuangyinhao()."','丷'),'\',\'','∨') where resid='".$bakmk."'");
        //$zzy=UX("update coode_datainstall set conjson=replace(conjson,'\"}〗','〗') where resid='".$bakmk."'");
        //$zzy=UX("update coode_datainstall set datajson=replace(datajson,'\"}〗','〗') where resid='".$bakmk."'");
        //$zzz=UX("update coode_datainstall set datasql=replace(datasql,'∨\')〗','∨〗') where resid='".$bakmk."'");
        //$zzz=UX("update coode_datainstall set datasql=replace(datasql,'\'','@DYH@') where resid='".$bakmk."'");
        //$zzx=UX("update coode_datainstall set conmd5=md5(conjson),crtmd5=md5(crttab),keymd5=md5(frmsql),mymd5=md5(concat(tabnam,tabolmk,datajson,datasql,crttab,frmsql,tabkeys)) where resid='".$bakmk."'");
        //$zkx=UX("update coode_datainstall set frmsql=concat('insert into ',tabname,'(',tabkeys,')values([DATA])') where resid='".$bakmk."'");
        //$zstt=UX("update coode_datainstall SET STATUS=(length(replace(datasql,'∨','@:@'))-length(replace(datasql,'∨','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),PRIME= (length(replace(datajson,'Ｖ','@:@'))-length(replace(datajson,'Ｖ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),VRT=(length(replace(datajson,'Ｔ','@:@'))-length(replace(datajson,'Ｔ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))+1) where resid='".$bakmk."'");
        $totitem=UX("select count(*) as result from coode_datainstall where resid='".$bakmk."'");
        $nn=addprc("sfunx","tabdataoprt",165,"fns","备份结束");   
        return intval($totitem);
      }else{
        $nn=addprc("sfunx","tabdataoprt",170,"err","结构不存在");      
        return 0;
      }
      
  }else{  
    $nn=addprc("sfunx","tabdataoprt",170,"err","数据结构不存在");      
    return 0;
  }
}
function repairins($cdtx){
        $zzy=UX("update coode_datainstall set conjson=concat('〖',mid(conjson,3,length(conjson)-4),'〗') where mid(conjson,1,2)='{\"' and (".$cdtx.")");
        $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\":\"','Ｔ') where ".$cdtx);
        $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\",\"','Ｖ') where ".$cdtx);
        $zzy=UX("update coode_datainstall set datajson=concat('〖',mid(datajson,3,length(datajson)-4),'〗') where mid(datajson,1,2)='{\"' where ".$cdtx);
        $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\":\"','Ｔ') where ".$cdtx);
        $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\",\"','Ｖ') where ".$cdtx);
        $zzz=UX("update coode_datainstall set datasql=concat('〖',mid(datasql,3,length(datasql)-4),'〗') where mid(datasql,1,2)='(\'' where ".$cdtx);
        $zzz=UX("update coode_datainstall set datasql=replace(replace(datasql,'".shuangyinhao()."','丷'),'\',\'','∨') where ".$cdtx);
        $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\"}〗','〗') where ".$cdtx);
        $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\"}〗','〗') where ".$cdtx);
        $zzz=UX("update coode_datainstall set datasql=replace(datasql,'∨\')〗','∨〗') where ".$cdtx);
        $zzz=UX("update coode_datainstall set datasql=replace(datasql,'\'','@DYH@') where ".$cdtx);
        $zzx=UX("update coode_datainstall set conmd5=md5(conjson),crtmd5=md5(crttab),keymd5=md5(frmsql),mymd5=md5(concat(tabnam,tabolmk,datajson,datasql,crttab,frmsql,tabkeys)) where ".$cdtx);
        $zkx=UX("update coode_datainstall set frmsql=concat('insert into ',tabname,'(',tabkeys,')values([DATA])') where ".$cdtx);
        $zstt=UX("update coode_datainstall SET STATUS=(length(replace(datasql,'∨','@:@'))-length(replace(datasql,'∨','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),PRIME= (length(replace(datajson,'Ｖ','@:@'))-length(replace(datajson,'Ｖ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),VRT=(length(replace(datajson,'Ｔ','@:@'))-length(replace(datajson,'Ｔ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))+1) where ".$cdtx);
        return true;
}
function anytabbak($tabnm){
  $trst=SX("select createsql,keynames,keytpnms,jsontpnms,jsonconts,tabtitle,srckey,srcttk,contentkeys,mainsqx,olmkkey,md5key from coode_tablist where schm='".glb()."' and TABLE_NAME='".$tabnm."'");
  $mainsqx=anyvalue($trst,"mainsqx",0);
  $olmkkey=anyvalue($trst,"olmkkey",0);
  $srck=anyvalue($trst,"srckey",0);
  $srctk=anyvalue($trst,"srcttk",0);
  $md5key=anyvalue($trst,"md5key",0);
  $kx=UX("delete from coode_datainstall where  srcid='".$tabnm."@item'");  
  if ($srck==""){
    $srck="VRT";
  }
  if ($srctk==""){
    $srctk="STCODE";
  }  
  $crts=anyvalue($trst,"createsql",0);
  $knms=anyvalue($trst,"keynames",0);
  $ktps=anyvalue($trst,"keytpnms",0);
  $crtsql=UX("select createsql as result from coode_tablist where TABLE_NAME='".$tabnm."'");
  $ckeys=anyvalue($trst,"contentkeys",0);  
  $ktps=str_replace("↓","'",$ktps);
  $ktps=str_replace("↑","\\"."'",$ktps);
  $jstp=anyvalue($trst,"jsontpnms",0);    
  $jstp=str_replace("↓","'",$jstp);
  $jstp=str_replace("∵","\":\"",$jstp);  
  $jscons=anyvalue($trst,"jsonconts",0);  
  $jscons=str_replace("↓","'",$jscons);
  $jscons=str_replace("∵","\":\"",$jscons);  
  $bakmk=$tabnm."@item";
  if ($knms!="" and $ktps!="" and $jstp!=""  ){
        if($mainsqx=="SNO"){
         $z=UX("insert into coode_datainstall(schm,srcid,tabname,tabsno,tabolmk,conjson,datajson,datasql,crttab,tabkeys,CRTM,UPTM,CRTOR,itemcrtm,itemuptm,itemcrtor,itemsrcid,itemsrcval,itemsrctt,itemsrctval,itemptof,conkeys,datamd5,md5key)select '".$dbase."','".$bakmk."','".$tabnm."',SNO,OLMK,concat('{',".$jscons.",'}'),concat('{',".$jstp.",'}'),concat('(',".$ktps.",')'),'".$crts."','".$knms."',now(),now(),'".$_COOKIE["uid"]."',CRTM,UPTM,CRTOR,'".$srck."',".$srck.",'".$srctk."',".$srctk.",PTOF,'".$ckeys."',".$md5key.",'".$md5key."' from ".$tabnm);
        }else{
         $z=UX("insert into coode_datainstall(schm,srcid,tabname,tabsno,tabolmk,conjson,datajson,datasql,crttab,tabkeys,CRTM,UPTM,CRTOR,itemcrtm,itemuptm,itemcrtor,itemsrcid,itemsrcval,itemsrctt,itemsrctval,itemptof,conkeys,datamd5)select '".$dbase."','".$bakmk."','".$tabnm."',".$mainsqx.",".$olmkkey.",concat('{',".$jscons.",'}'),concat('{',".$jstp.",'}'),concat('(',".$ktps.",')'),'".$crts."','".$knms."',now(),now(),'".$_COOKIE["uid"]."',itemCTime,itemUTime,itemCrtID,'".$srck."',".$srck.",'".$srctk."',".$srctk.",itemGrpID,'".$ckeys."',".$md5key.",'".$md5key."' from ".$tabnm);
        }
        $zzy=UX("update coode_datainstall set conjson=concat('〖',mid(conjson,3,length(conjson)-4),'〗') where mid(conjson,1,2)='{\"'");
        $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\":\"','Ｔ')");
        $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\",\"','Ｖ')");        
        $zzy=UX("update coode_datainstall set datajson=concat('〖',mid(datajson,3,length(datajson)-4),'〗') where mid(datajson,1,2)='{\"'");
        $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\":\"','Ｔ')");
        $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\",\"','Ｖ')");        
        $zzz=UX("update coode_datainstall set datasql=concat('〖',mid(datasql,3,length(datasql)-4),'〗') where mid(datasql,1,2)='(\''");
        $zzz=UX("update coode_datainstall set datasql=replace(replace(datasql,'".shuangyinhao()."','丷'),'\',\'','∨')");    
        
        $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\"}〗','〗')");        
        $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\"}〗','〗')");        
        $zzz=UX("update coode_datainstall set datasql=replace(datasql,'∨\')〗','∨〗')");    
        $zzz=UX("update coode_datainstall set datasql=replace(datasql,'\'','@DYH@')");
        $zzx=UX("update coode_datainstall set conmd5=md5(conjson),crtmd5=md5(crttab),keymd5=md5(frmsql),mymd5=md5(concat(tabname,tabolmk,datajson,datasql,crttab,frmsql,tabkeys))");    
        $zkx=UX("update coode_datainstall set frmsql=concat('insert into ',tabname,'(',tabkeys,')values([DATA])')");    
       $zstt=UX("update coode_datainstall SET STATUS=(length(replace(datasql,'∨','@:@'))-length(replace(datasql,'∨','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),PRIME= (length(replace(datajson,'Ｖ','@:@'))-length(replace(datajson,'Ｖ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),VRT=(length(replace(datajson,'Ｔ','@:@'))-length(replace(datajson,'Ｔ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))+1)");
  }
  return true;
}
function anydetailbak($tabnm,$snokey,$snoval){
  $trst=SX("select createsql,keynames,keytpnms,jsontpnms,jsonconts,tabtitle,srckey,srcttk,contentkeys,mainsqx,olmkkey,md5key from coode_tablist where schm='".glb()."' and TABLE_NAME='".$tabnm."'");
  $srck=anyvalue($trst,"srckey",0);
  $srctk=anyvalue($trst,"srcttk",0);
  $md5key=anyvalue($trst,"md5key",0);
  $kx=UX("delete from coode_datainstall where srcid='".$tabnm."@Detail' and OPRT='".$snoval."'");
  if ($srck==""){
    $srck="VRT";
  }
  if ($srctk==""){
    $srctk="STCODE";
  }  
  $mainsqx=anyvalue($trst,"mainsqx",0);
  $olmkkey=anyvalue($trst,"olmkkey",0);
  $crts=anyvalue($trst,"createsql",0);
  $knms=anyvalue($trst,"keynames",0);
  $ktps=anyvalue($trst,"keytpnms",0);
  $ckeys=anyvalue($trst,"contentkeys",0);  
  $md5key=anyvalue($trst,"md5key",0);  
  $ktps=str_replace("↓","'",$ktps);
  $ktps=str_replace("↑","\\"."'",$ktps);
  $jstp=anyvalue($trst,"jsontpnms",0);    
  $jstp=str_replace("↓","'",$jstp);
  $jstp=str_replace("∵","\":\"",$jstp);  
  $jscons=anyvalue($trst,"jsonconts",0);  
  $jscons=str_replace("↓","'",$jscons);
  $jscons=str_replace("∵","\":\"",$jscons); 
  $bakmk=$tabnm."@Detail";
  if ($knms!="" and $ktps!="" and $jstp!=""  ){
        $z=UX("insert into coode_datainstall(schm,srcid,tabname,tabsno,tabolmk,conjson,datajson,datasql,crttab,tabkeys,CRTM,UPTM,CRTOR,itemcrtm,itemuptm,itemcrtor,itemsrcid,itemsrcval,itemsrctt,itemsrctval,itemptof,conkeys,datamd5,md5key,OPRT)select '".$dbase."','".$bakmk."','".$tabnm."',SNO,OLMK,concat('{',".$jscons.",'}'),concat('{',".$jstp.",'}'),concat('(',".$ktps.",')'),'".$crts."','".$knms."',now(),now(),'".$_COOKIE["uid"]."',CRTM,UPTM,CRTOR,'".$srck."',".$srck.",'".$srctk."',".$srctk.",PTOF,'".$ckeys."',".$md5key.",'".$md5key."','".$snoval."' from ".$tabnm." where ".$snokey."=".$snoval);
        $zzy=UX("update coode_datainstall set conjson=concat('〖',mid(conjson,3,length(conjson)-4),'〗') where mid(conjson,1,2)='{\"'");
        $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\":\"','Ｔ')");
        $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\",\"','Ｖ')");        
        $zzy=UX("update coode_datainstall set datajson=concat('〖',mid(datajson,3,length(datajson)-4),'〗') where mid(datajson,1,2)='{\"'");
        $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\":\"','Ｔ')");
        $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\",\"','Ｖ')");        
        $zzz=UX("update coode_datainstall set datasql=concat('〖',mid(datasql,3,length(datasql)-4),'〗') where mid(datasql,1,2)='(\''");
        $zzz=UX("update coode_datainstall set datasql=replace(replace(datasql,'".shuangyinhao()."','丷'),'\',\'','∨')");    
        $zzy=UX("update coode_datainstall set conjson=replace(conjson,'\"}〗','〗')");        
        $zzy=UX("update coode_datainstall set datajson=replace(datajson,'\"}〗','〗')");        
        $zzz=UX("update coode_datainstall set datasql=replace(datasql,'∨\')〗','∨〗')");    
        $zzz=UX("update coode_datainstall set datasql=replace(datasql,'\'','@DYH@')");
        $zzx=UX("update coode_datainstall set conmd5=md5(conjson),crtmd5=md5(crttab),keymd5=md5(frmsql),mymd5=md5(concat(tabname,tabolmk,datajson,datasql,crttab,frmsql,tabkeys))");    
        $zkx=UX("update coode_datainstall set frmsql=concat('insert into ',tabname,'(',tabkeys,')values([DATA])')");    
       $zstt=UX("update coode_datainstall SET STATUS=(length(replace(datasql,'∨','@:@'))-length(replace(datasql,'∨','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),PRIME= (length(replace(datajson,'Ｖ','@:@'))-length(replace(datajson,'Ｖ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),VRT=(length(replace(datajson,'Ｔ','@:@'))-length(replace(datajson,'Ｔ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))+1)");
  }
  return true;
}
function srctitle($tabnm,$srcid){
    $colx=UX("select COLUMN_NAME as result from coode_keydetailx where TABLE_NAME='".$tabnm."' and classp=2");
    $srcx=UX("select COLUMN_NAME as result from coode_keydetailx where TABLE_NAME='".$tabnm."' and classp=1");
    if ($colx!="" and $srcx!=""){
        $titlex=UX("select ".$colx." as result from ".$tabnm." where ".$srcx."='".$srcid."'");
        if ($titlex!=""){
          return $titlex;
        }else{
          return "@".$srcid;  
        }
    }else{
        return $srcid;
    }
}
function srckey($tabnm){
    $colx=UX("select COLUMN_NAME as result from coode_keydetailx where TABLE_NAME='".$tabnm."' and classp=2");
    $srcx=UX("select COLUMN_NAME as result from coode_keydetailx where TABLE_NAME='".$tabnm."' and classp=1");
    return $srcx."@".$colx;
}
function newtabitem($tabnm,$srcid,$srctitle){
    $srck=srckey($tabnm);
    $srcidkey=qian($srck,"@");
    $srcttkey=hou($srck,"@");
    if ($srcidkey!="" and $srcttkey!=""){
        $sqlx=$srcidkey.",".$srcttkey;
        $sqly="'".$srcid."','".$srctitle."'";
        $zz=UX("insert into ".$tabnm."(".$sqlx.")values(".$sqly.")");
        $extx=UX("select count(*) as result from ".$tabnm." where ".$srcidkey."='".$srcid."'");
        if (intval($extx)>0){
            return true;
        }else{
            return false;
        }
    }else{
        return false;
    }
}
function tabval($tabnm,$cdtx,$odcdt,$page,$pnum,$keyx,$sqx){
      $smd5="a".substr(md5($tabnm.$cdtx.$odcdt.$page.$pnum),0,16);
      if ($_SESSION[$smd5]=="" or varval($smd5)==""){
          $allk=UX("select allkeys as result from coode_tablist where TABLE_NAME='".$tabnm."'");
          $allk=hou($allk,"|");
          if ($pnum!="" and $page!=""){
            $rst=SX("select ".$allk." from ".$tabnm." where ".$cdtx." ".$odcdt." limit ".(($page-1)*$pnum).",".$pnum);
          }else{
            $rst=SX("select ".$allk." from ".$tabnm." where ".$cdtx." ".$odcdt);  
          }
          $_SESSION[$smd5]=$rst;
          $z=setvarval($smd5,$tabnm."-".tohex($cdtx)."生效".date("Y-m-d H:i:s"));
          return anyvalue($rst,$keyx,$sqx);
      }else{
          $rst=$_SESSION[$smd5];
          return anyvalue($rst,$keyx,$sqx);
      }
}
function databak($dbase,$tbnm,$cdt){
  if ($dbase==""){
    $dbase=glb();
  }
  //想办法搞成= 确定完成的备份，不能老用IN 计算量太大容易卡死
  $k=killbak($dbase,$tbnm);
  $trst=SX("select createsql,keynames,keytpnms,jsontpnms,jsonconts,tabtitle,srckey,srcttk,contentkeys from coode_tablist where schm='".$dbase."' and TABLE_NAME='".$tbnm."'");
  $srck=anyvalue($trst,"srckey",0);
  $srctk=anyvalue($trst,"srcttk",0);
  if ($srck==""){
    $srck="VRT";
  }
  if ($srctk==""){
    $srctk="STCODE";
  }  
  $crts=anyvalue($trst,"createsql",0);
  $knms=anyvalue($trst,"keynames",0);
  $ktps=anyvalue($trst,"keytpnms",0);
  $ckeys=anyvalue($trst,"contentkeys",0);
  //concat(↓↑↓,OLMK,↓↑,↑↓,VRT,↓↑,↑↓,UPTM,↓↑,↑↓,CRTM,↓↑,↑↓,CRTOR,↓↑,↑↓,PTOF,↓↑,↑↓,schm,↓↑,↑↓,TABLE_NAME,↓↑,↑↓,createsql,↓↑,↑↓,keynames,↓↑,↑↓,keytpnms,↓↑,↑↓,jsontpnms,↓↑,↑↓,issys,↓↑,↑↓,ispmiss,↓↑,↑↓,tabtitle,↓↑,↑↓,tabcls,↓↑,↑↓,sysid,↓↑,↑↓,appid,↓↑,↑↓,usearea,↓↑,↑↓,affplot,↓↑,↑↓,STATUS,↓↑,↑↓,STCODE,↓↑,↑↓,PRIME,↓↑,↑↓,RIP,↓↑,↑↓,OPRT,↓↑↓)
  $ktps=str_replace("↓","'",$ktps);
  $ktps=str_replace("↑","\\"."'",$ktps);
  //↓"OLMK":"↓,OLMK,↓",↓,↓"VRT":"↓,VRT,↓",↓,↓"UPTM":"↓,UPTM,↓",↓,↓"CRTM":"↓,CRTM,↓",↓,↓"CRTOR":"↓,CRTOR,↓",↓,↓"PTOF":"↓,PTOF,↓",↓,↓"schm":"↓,schm,↓",↓,↓"TABLE_NAME":"↓,TABLE_NAME,↓",↓,↓"createsql":"↓,createsql,↓",↓,↓"keynames":"↓,keynames,↓",↓,↓"keytpnms":"↓,keytpnms,↓",↓,↓"jsontpnms":"↓,jsontpnms,↓",↓,↓"issys":"↓,issys,↓",↓,↓"ispmiss":"↓,ispmiss,↓",↓,↓"tabtitle":"↓,tabtitle,↓",↓,↓"tabcls":"↓,tabcls,↓",↓,↓"sysid":"↓,sysid,↓",↓,↓"appid":"↓,appid,↓",↓,↓"usearea":"↓,usearea,↓",↓,↓"affplot":"↓,affplot,↓",↓,↓"STATUS":"↓,STATUS,↓",↓,↓"STCODE":"↓,STCODE,↓",↓,↓"PRIME":"↓,PRIME,↓",↓,↓"RIP":"↓,RIP,↓",↓,↓"OPRT":"↓,OPRT,↓"↓
  $jstp=anyvalue($trst,"jsontpnms",0);
  $jstp=str_replace("↓","'",$jstp);
  $jstp=str_replace("∵","\":\"",$jstp);
  $jscons=anyvalue($trst,"jsonconts",0);  
  $jscons=str_replace("↓","'",$jscons);
  $jscons=str_replace("∵","\":\"",$jscons);
  
  if ($knms!="" and $ktps!="" and $jstp!="" and $tbnm!="" and $tbnm!="coode_databak"){
    if ($cdt!=""){
    $z=UX("insert into coode_databak(schm,tabname,tabsno,tabolmk,conjson,datajson,datasql,crttab,tabkeys,CRTM,UPTM,CRTOR,itemcrtm,itemuptm,itemcrtor,itemsrcid,itemsrcval,itemsrctt,itemsrctval,itemptof,conkeys,OPRT)select '".$dbase."','".$tbnm."',SNO,OLMK,concat('{',".$jscons.",'}'),concat('{',".$jstp.",'}'),concat('(',".$ktps.",')'),'".$crts."','".$knms."',now(),now(),'".$_COOKIE["uid"]."',CRTM,UPTM,CRTOR,'".$srck."',".$srck.",'".$srctk."',".$srctk.",PTOF,'".$ckeys."','".md5($cdt)."' from ".$tbnm." where ".$cdt); 
    }else{
    $z=UX("insert into coode_databak(schm,tabname,tabsno,tabolmk,conjson,datajson,datasql,crttab,tabkeys,CRTM,UPTM,CRTOR,itemcrtm,itemuptm,itemcrtor,itemsrcid,itemsrcval,itemsrctt,itemsrctval,itemptof,conkeys)select '".$dbase."','".$tbnm."',SNO,OLMK,concat('{',".$jscons.",'}'),concat('{',".$jstp.",'}'),concat('(',".$ktps.",')'),'".$crts."','".$knms."',now(),now(),'".$_COOKIE["uid"]."',CRTM,UPTM,CRTOR,'".$srck."',".$srck.",'".$srctk."',".$srctk.",PTOF,'".$ckeys."' from ".$tbnm);      
    }
    $zzy=UX("update coode_databak set conjson=concat('〖',mid(conjson,3,length(conjson)-4),'〗') where mid(conjson,1,2)='{\"'");
    $zzy=UX("update coode_databak set conjson=replace(conjson,'\":\"','Ｔ')");
    $zzy=UX("update coode_databak set conjson=replace(conjson,'\",\"','Ｖ')");    
    
    $zzy=UX("update coode_databak set datajson=concat('〖',mid(datajson,3,length(datajson)-4),'〗') where mid(datajson,1,2)='{\"'");
    $zzy=UX("update coode_databak set datajson=replace(datajson,'\":\"','Ｔ')");
    $zzy=UX("update coode_databak set datajson=replace(datajson,'\",\"','Ｖ')");    
    
    $zzz=UX("update coode_databak set datasql=concat('〖',mid(datasql,3,length(datasql)-4),'〗') where mid(datasql,1,2)='(\''");
    $zzz=UX("update coode_databak set datasql=replace(datasql,'\',\'','∨')");
    
    $zzy=UX("update coode_databak set conjson=replace(conjson,'\"}〗','〗')");        
    $zzy=UX("update coode_databak set datajson=replace(datajson,'\"}〗','〗')");        
    $zzz=UX("update coode_databak set datasql=replace(datasql,'∨\')〗','∨〗')");
    $zzz=UX("update coode_datainstall set datasql=replace(datasql,'\'','@DYH@')");
    $zzx=UX("update coode_databak set conmd5=md5(conjson),datamd5=md5(datasql),crtmd5=md5(crttab),keymd5=md5(frmsql),mymd5=md5(concat(tabname,tabolmk,datajson,datasql,crttab,frmsql,tabkeys))");
    
    $zkx=UX("update coode_databak set frmsql=concat('insert into ',tabname,'(',tabkeys,')values([DATA])')");
    
    $zstt=UX("update coode_databak SET STATUS=(length(replace(datasql,'∨','@:@'))-length(replace(datasql,'∨','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),PRIME= (length(replace(datajson,'Ｖ','@:@'))-length(replace(datajson,'Ｖ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))),VRT=(length(replace(datajson,'Ｔ','@:@'))-length(replace(datajson,'Ｔ','@@')))-(length(tabkeys)-length(replace(tabkeys,',',''))+1)");
    //":"= Ｔ  "," is Ｖ  datajson
    //',' is ∨     datasql
    $numx=UX("select count(*) as result from coode_databak where tabname='".$tbnm."' and OPRT='".md5($cdt)."'");
    return intval($numx);
  }else{
    return 0;
  }
}//DESCRIB ():  END@()
function TX($tsql){
    if ($tsql!=""){
     $keyx=qian(hou($tsql,"elect"),"from");
     $keyx=str_replace(" ","",$keyx);
     if (strpos($tsql,"limit")>0){
        $pnumx=hou(hou($tsql,"limit"),",");
     }else{
        $pnumx="30";
     }
     $ptkx=explode(",",$keyx);
     $totp=count($ptkx);
     $headx="";
     $bodyx="";
     for ($i=0;$i<$totp;$i++){
        $mykey[$i]=qian($ptkx[$i],"@");
        $mytit[$i]=qian(hou($ptkx[$i],"@"),"(");
        $mytype[$i]=qian(hou($ptkx[$i],"("),")");
        $headx=$headx.$mykey[$i]."#-#";
     }
     $headx=$headx."#/#";
     for ($j=0;$j<intval($pnumx);$j++){
        for ($i=0;$i<$totp;$i++){
         $bodyx=$bodyx.gettestvalue($j,$mykey[$i],$mytit[$i],$mytype[$i])."#-#";
        }
        $bodyx=$bodyx."#/#";
     }
     return $headx.$bodyx;
    }else{
     return "ERROR#/#NO SQLSTR";   
    }
}
function VX($tsql,$dmk){
    if ($tsql!=""){
     $keyx=qian(hou($tsql,"elect"),"from");
     $keyx=str_replace(" ","",$keyx);
     if (strpos($tsql,"limit")>0){
        $pnumx=hou(hou($tsql,"limit"),",");
     }else{
        $pnumx="30";
     }
     $ptkx=explode(",",$keyx);
     $totp=count($ptkx);
     $headx="";
     $bodyx="";
     for ($i=0;$i<$totp;$i++){
        $mykey[$i]=qian($ptkx[$i],"@");
        $mytit[$i]=qian(hou($ptkx[$i],"@"),"(");
        $mytype[$i]=qian(hou($ptkx[$i],"("),")");
        $headx=$headx.$mykey[$i]."#-#";
     }
     $headx=$headx."#/#";
     for ($j=0;$j<intval($pnumx);$j++){
        for ($i=0;$i<$totp;$i++){
         $bodyx=$bodyx.getlinkvalue($dmk,$j,$mykey[$i],$mytit[$i],$mytype[$i])."#-#";
        }
        $bodyx=$bodyx."#/#";
     }
     return $headx.$bodyx;
    }else{
     return "ERROR#/#NO SQLSTR";   
    }
}
function killbak($schm,$tbnm,$cdtx){  
  if ($cdtx!=""){
    $z=UX("delete from coode_databak where tabname='".$tbnm."' and schm='".$schm."' and OPRT='".md5($cdtx)."'");
  }else{
    $z=UX("delete from coode_databak where tabname='".$tbnm."' and schm='".$schm."'");
  }
  return true;
}//DESCRIB ():  END@()
?>