<?php
function maketbdata($totrst,$totk,$tbkis,$chtml,$oprtx,$obtn,$vbtn,$xbtn,$dtp,$headx,$appid,$tbnm,$sresult,$kpart,$keyinfo,$tbdatay=array(),$xid){    
  $fmjs="";
  $fmtb="";
  $fmch="";
  $fmexl="";
  $fmclsmd5="";
  $fmmd5js="";
  $fmmd5js="{";
  $fmline="";  
  $fmtbk=""; 
  eval(RESFUNSET("formvalue"));
  if ($dtp=="excel"){
      //var_dump($keyinfo);
  }
    for ($jj=1;$jj<$totrst+1;$jj++){
    $fmjs=$fmjs."{";    
    if ($dtp=="html" or $dtp=="table"){
     $fmtb=$fmtb."<tr id=\"".$xid.$sresult["SNO"][$jj]."\" rowidx=\"".($jj)."\" class=\"TABTR_CLS\" style=\"TABTR:STL\">";
    }    
    $tmp=0;
    $fmudt="";
    $demo=$chtml;        
    for ($ii=0;$ii<$totk;$ii++){
      $_GET["key".hou($kpart[$ii],".")]=$sresult[hou($kpart[$ii],".")][$jj];//所以这个GET 有顺序的，在SHORTCLS引用前 最好让他没顺序
    }
    for ($ii=0;$ii<$totk;$ii++){
      $tmpvkey="";
      $tmpatn="";
      $tmpact="";
      if (strpos("x".$exkkk.",","-".hou($kpart[$ii],".").",")>0){
        $sresult[hou($kpart[$ii],".")][$jj]="***";
      };            
       $fmjs=$fmjs."\"".hou($kpart[$ii],".")."\":\"".gojshex(str_replace("\"","\\\"",tostring($sresult[hou($kpart[$ii],".")][$jj])))."\",";
             $newonex=tostring($keyinfo[hou($kpart[$ii],".")]["COLUMN_CLSTXT"]);
                //echo "newonex-aaaa".$keyinfo[hou($kpart[$ii],".")]["COLUMN_CLSTXT"];
                
                 if (strpos($newonex,"key-")>0){
                   $hk=qian(hou($newonex,"key-"),"]");
                   $newonex=tostring($sresult[$hk][$jj]);
                 }else{
                   if (strpos($newonex,"key")>0 ){
                    $newonex=str_replace("[","",$newonex);
                    $newonex=str_replace("]","",$newonex);
                   $newonex=anyshort($newonex,"","");
                        //用该行的某个值当KEY 检索
                     $fmjs=$fmjs."\"".hou($kpart[$ii],".")."clstxt\":\"a".md5($newonex)."\",";
                     if (strpos($fmclsmd5,md5($newonex))>0){
                     }else{
                       $fmclsmd5=$fmclsmd5."/".md5($newonex);
                       $fmmd5js=$fmmd5js."\"a".md5($newonex)."\":\"".tohex($newonex)."\",";
                     }
                   };
                 };
                if ($newonex!=""){
                      $ptkk=explode(",",qian($newonex,"|"));
                      $ptvv=explode(",",hou($newonex,"|"));
                      $totpt=count($ptkk);
                    for ($zzz=0;$zzz<$totpt;$zzz++){
                         if ($ptvv[$zzz]==$sresult[hou($kpart[$ii],".")][$jj]){
                            $tmpvkey= $ptkk[$zzz];
                         }
                     }
                }
               if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_CANGE"]*1==1){
                 $rdonly="";
               }else{
                 $rdonly="readonly";
               }
      if (hou($kpart[$ii],".")=='SNO'){
         if ($dtp=="html" or $dtp=="table"){
           $fmtb=$fmtb."<td id=\"SNO".$sresult['SNO'][$jj]."\" class=\"TABTD_CLS\"   ".mkdisplay($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"])."><input type=\"checkbox\" id=\"chk".$sresult['SNO'][$jj]."\" name=\"chksno\"  lay-skin=\"primary\"  value=\"".$sresult['SNO'][$jj]."\">".$sresult['SNO'][$jj]."</td>\r\n";        
           if (intval(_get("SNO"))==intval($sresult['SNO'][$jj])){             
             $fmline=$fmline."<td id=\"SNO".$sresult['SNO'][$jj]."\" class=\"TABTD_CLS\"   ".mkdisplay($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"])."><input type=\"checkbox\" id=\"chk".$sresult['SNO'][$jj]."\" name=\"chksno\"  lay-skin=\"primary\"  value=\"".$sresult['SNO'][$jj]."\">".$sresult['SNO'][$jj]."</td>\r\n";             
           };          
         }
         if ($dtp=="imgx"){
          $demo=str_replace("[SNO]",$sresult['SNO'][$jj],$demo);
          $demo=str_replace("[key-SNO]",$sresult['SNO'][$jj],$demo);
          $demo=str_replace("[thissno]",$sresult['SNO'][$jj],$demo);
         }
          $tmp=$tmp+1;
          if (intval($sresult[hou($kpart[$ii],".")][$jj])*1>=1000000000){
            $fmexl=$fmexl.$sresult[hou($kpart[$ii],".")][$jj]."_[tab]";
          }else{
            $fmexl=$fmexl.$sresult[hou($kpart[$ii],".")][$jj]."[tab]";
          };        
      }else{
         
           if (intval($sresult[hou($kpart[$ii],".")][$jj])*1>=1000000000){
            $fmexl=$fmexl.$sresult[hou($kpart[$ii],".")][$jj]."_[tab]";
           }else{
            if ($tmpvkey!=""){
                $fmexl=$fmexl.$tmpvkey."[tab]"; 
            }else{
               $fmexl=$fmexl.$sresult[hou($kpart[$ii],".")][$jj]."[tab]";     
             }
           };
        if ($tmp>0){         
            $newonex=tostring($keyinfo[hou($kpart[$ii],".")]["COLUMN_CLSTXT"]);//这里不是多余的 如果下列判断无效就直接引用值          
          //echo "kpt".hou($kpart[$ii],".")."--".$newonex;
            $kclstxt=tostring($keyinfo[hou($kpart[$ii],".")]["COLUMN_CLSTXT"]);  
           if ($dtp=="html" or $dtp=="table" or $dtp=="imgx"){
             if (strlen($keyinfo[hou($kpart[$ii],".")]["COLUMN_ACTHTM"])>5){
               $tmpact=fmvalue($tbnm,$sresult[hou($kpart[$ii],".")][$jj],$sresult['SNO'][$jj],hou($kpart[$ii],"."),$keyinfo[hou($kpart[$ii],".")]["COLUMN_ACTHTM"],$jj,$sresult);
             }else{
               $tmpact="";
             };
             if (strlen($keyinfo[hou($kpart[$ii],".")]["COLUMN_ATNHTM"])>5){
              $tmpatn=fmvalue($tbnm,$sresult[hou($kpart[$ii],".")][$jj],$sresult['SNO'][$jj],hou($kpart[$ii],"."),$keyinfo[hou($kpart[$ii],".")]["COLUMN_ATNHTM"],$jj,$sresult);
             }else{
               $tmpatn="";
             };
             if (strlen($tmpatn)>5){
               $ckcd=$tmpatn;
             }else{
               //$ckcd=" onclick=\"qajaxp('修改记录','/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=".hou($kpart[$ii],".")."&SNO=".$sresult['SNO'][$jj]."','p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."='+getduovalue('"."p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."'));\"";
             };
             if (strlen($tmpact)>5){
               $selecthcd=$tmpact;
             }else{
               if ($rdonly==""){
                //$selecthcd=" onchange=\"qajaxp('修改记录','/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=".hou($kpart[$ii],".")."&SNO=".$sresult['SNO'][$jj]."','p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."='+$('#"."p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."').val())\"";
               }
             }
             if ($kclstxt!="" ){                
                 if (strpos($newonex,"key-")>0){
                   $hk=qian(hou($newonex,"key-"),"]");
                   $newonex=tostring($sresult[$hk][$jj]);
                 }else{
                   if (strpos($newonex,"key")>0 ){//对还有一种 [get-keysysid  这种模型 让字段值作为SHORT参数的需要计算
                    $newonex=str_replace("[","",$newonex);
                    $newonex=str_replace("]","",$newonex);
                    $newonex=str_replace("{","",$newonex);
                    $newonex=str_replace("}","",$newonex);
                      if (strpos($newonex,",")>0){
                       $ptnewo=explode(",",$newonex);
                       $totpn=count($ptnewo);
                       $fmmaq="";
                       $fmmah="";
                       for($zm=0;$zm<$totpn-1;$zm++){
                         $bknw=anyshort($ptnewo[$zm],"","");
                         $fmmaq=$fmmaq.qian($bknw,"|").",";
                         $fmmah=$fmmah.hou($bknw,"|").",";
                       }
                       $bknw=anyshort($ptnewo[$totpn-1],"","");
                       $fmmaq=$fmmaq.qian($bknw,"|");
                       $fmmah=$fmmah.hou($bknw,"|");
                       $newonex=$fmmaq."|".$fmmah;                             
                     }else{//发现有多个取值
                       $newonex=anyshort($newonex,"","");
                     }                                                            
                   };//在其他的情况就不用开率 上面已经声明了 如果有GETKEY的表格就不能用静态显示前端了
                  };                 
                 if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]=="clstxt"){
                     $fmtmpselect=formselect(qian($newonex,"|"),hou($newonex,"|"),$sresult[hou($kpart[$ii],".")][$jj],"p_".hou($kpart[$ii],".").$sresult['SNO'][$jj],$rdonly,$selecthcd);                      
                 }                 
                 if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]=="clsduo"){                               
                     $fmtmpselect="<input type=\"hidden\" id=\""."p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" value=\"".$sresult[hou($kpart[$ii],".")][$jj]."\">".formselectx(qian($newonex,"|"),hou($newonex,"|"),$sresult[hou($kpart[$ii],".")][$jj],"p_".hou($kpart[$ii],".").$sresult['SNO'][$jj],"","");
                 };       
               };//kclstxt
                $tmpvl="";
                $houduanzhanshi=qian($keyinfo[hou($kpart[$ii],".")]["COLUMN_SSHOW"],"|");
            }//html table imgx
                if ($houduanzhanshi!=""){                
                  if ($dtp=="html" or $dtp=="table" or $dtp=="imgx"){
                     $tmpvl=fmvalue($tbnm,$sresult[hou($kpart[$ii],".")][$jj],$sresult['SNO'][$jj],hou($kpart[$ii],"."),qian($keyinfo[hou($kpart[$ii],".")]["COLUMN_SSHOW"],"|"),$jj,$sresult);//先套上外壳                  
                     $tmpvl=str_replace("<selected>",$fmtmpselect,$tmpvl);
                     $fmtb=$fmtb."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\"  tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\" ".mkdisplay($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"])."  class=\"TABTD_CLS\"   knm=\"".hou($kpart[$ii],".")."\" tdata=\"".String2Hex(str_replace("\\'","\'",tostring($sresult[hou($kpart[$ii],".")][$jj])))."\" title=\"".labturns($sresult[hou($kpart[$ii],".")][$jj])."\">".$tmpvl."</td>\r\n";
                     if (intval(_get("SNO"))==intval($sresult['SNO'][$jj])){
                      $fmline=$fmline."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\"  tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\" ".mkdisplay($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"])."  class=\"TABTD_CLS\"   knm=\"".hou($kpart[$ii],".")."\" tdata=\"".String2Hex(str_replace("\\'","\'",tostring($sresult[hou($kpart[$ii],".")][$jj])))."\" title=\"".labturns($sresult[hou($kpart[$ii],".")][$jj])."\">".$tmpvl."</td>\r\n";
                      if (_get("tabkey")==hou($kpart[$ii],".")){
                        $fmtbk=$tmpvl;
                      }
                     }
                     $demo=str_replace("[".hou($kpart[$ii],".")."]",$tmpvl,$demo);
                     $demo=str_replace("[key-".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
                  }
                }else{//如果不需要套外壳直接纯值
                   if (strlen($fmtmpselect)>5){
                     if ($dtp=="html" or $dtp=="table" or $dtp=="imgx"){
                      $fmtb=$fmtb."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\"  tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\" ".mkdisplay($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"])." dxtp=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]."\"   class=\"TABTD_CLS\"   knm=\"".hou($kpart[$ii],".")."\">".$fmtmpselect."</td>\r\n";
                      if (intval(_get("SNO"))==intval($sresult['SNO'][$jj])){
                        $fmline=$fmline."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\"  tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\" ".mkdisplay($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"])." dxtp=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]."\"   class=\"TABTD_CLS\"   knm=\"".hou($kpart[$ii],".")."\">".$fmtmpselect."</td>\r\n";
                        if (_get("tabkey")==hou($kpart[$ii],".")){
                         $fmtbk=$fmtmpselect;
                        }
                       };
                      $demo=str_replace("[".hou($kpart[$ii],".")."]",$fmtmpselect,$demo);
                      $demo=str_replace("[key-".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
                     }
                   }else{
                    if (strlen($sresult[hou($kpart[$ii],".")][$jj])>33){
                      if ($dtp=="html" or $dtp=="table" or $dtp=="imgx"){
                       $fmtb=$fmtb."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\"  tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\" ".mkdisplay($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"])." dxtp=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]."\"  class=\"TABTD_CLS\"   knm=\"".hou($kpart[$ii],".")."\" tdata=\"".String2Hex(str_replace("\\'","\'",tostring($sresult[hou($kpart[$ii],".")][$jj])))."\" title=\"".labturns(tostring($sresult[hou($kpart[$ii],".")][$jj]))."\">".substr(tohex($sresult[hou($kpart[$ii],".")][$jj]),0,33)."</td>\r\n";
                       if (intval(_get("SNO"))==intval($sresult['SNO'][$jj])){
                         $fmline=$fmline."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\"  tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\" ".mkdisplay($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"])." dxtp=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]."\"  class=\"TABTD_CLS\"   knm=\"".hou($kpart[$ii],".")."\" tdata=\"".String2Hex(str_replace("\\'","\'",tostring($sresult[hou($kpart[$ii],".")][$jj])))."\" title=\"".labturns(tostring($sresult[hou($kpart[$ii],".")][$jj]))."\">".substr(tohex($sresult[hou($kpart[$ii],".")][$jj]),0,33)."</td>\r\n";
                         if (_get("tabkey")==hou($kpart[$ii],".")){
                           $fmtbk=tohex($sresult[hou($kpart[$ii],".")][$jj]);
                         };
                       };
                       $demo=str_replace("[".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
                       $demo=str_replace("[key-".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
                      }
                    }else{
                      if ($dtp=="html" or $dtp=="table" or $dtp=="imgx"){
                        if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]=="dttm" or $keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]=="date"){
                         $fmtb=$fmtb."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\" tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\" ".mkdisplay($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"])." dxtp=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]."\"  class=\"TABTD_CLS\"   knm=\"".hou($kpart[$ii],".")."\" tdata=\"".String2Hex(str_replace("\\'","\'",tostring($sresult[hou($kpart[$ii],".")][$jj])))."\"><input id=\"p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" class=\"demo-input\"  value=\"".tohex($sresult[hou($kpart[$ii],".")][$jj])."\"></td>\r\n";
                         if (intval(_get("SNO"))==intval($sresult['SNO'][$jj])){
                           $fmline=$fmline."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\" tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\" ".mkdisplay($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"])." dxtp=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]."\"  class=\"TABTD_CLS\"   knm=\"".hou($kpart[$ii],".")."\" tdata=\"".String2Hex(str_replace("\\'","\'",tostring($sresult[hou($kpart[$ii],".")][$jj])))."\"><input id=\"p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" class=\"demo-input\"  value=\"".tohex($sresult[hou($kpart[$ii],".")][$jj])."\"></td>\r\n";
                          if (_get("tabkey")==hou($kpart[$ii],".")){
                           $fmtbk=tohex($sresult[hou($kpart[$ii],".")][$jj]);
                          };
                         };
                        }else{
                         $fmtb=$fmtb."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\"  tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\" ".mkdisplay($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"])." dxtp=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]."\"   class=\"TABTD_CLS\"   knm=\"".hou($kpart[$ii],".")."\" tdata=\"".String2Hex(str_replace("\\'","\'",tostring($sresult[hou($kpart[$ii],".")][$jj])))."\" title=\"".labturns(tostring($sresult[hou($kpart[$ii],".")][$jj]))."\">".tohex($sresult[hou($kpart[$ii],".")][$jj])."</td>\r\n";
                         if ($_GET["SNO"]==$sresult['SNO'][$jj]){
                           $fmline=$fmline."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\"  tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\" ".mkdisplay($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"])." dxtp=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]."\"   class=\"TABTD_CLS\"   knm=\"".hou($kpart[$ii],".")."\" tdata=\"".String2Hex(str_replace("\\'","\'",tostring($sresult[hou($kpart[$ii],".")][$jj])))."\" title=\"".labturns(tostring($sresult[hou($kpart[$ii],".")][$jj]))."\">".tohex($sresult[hou($kpart[$ii],".")][$jj])."</td>\r\n";
                           if (_get("tabkey")==hou($kpart[$ii],".")){
                            $fmtbk=tohex($sresult[hou($kpart[$ii],".")][$jj]);
                           };
                         }
                        }                                     
                        $demo=str_replace("[".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);                      
                        $demo=str_replace("[key-".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
                      }
                    };//33
                  };//tmpselect>5
                };//show
               $fmtmpselect="";
         $fmudt=$fmudt."'&p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."='+mkstr($('#p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."').val())+";
        }else{//tmp<=0 前面没有SNO第一列
          $newonex=tostring($keyinfo[hou($kpart[$ii],".")]["COLUMN_CLSTXT"]);
           $kclstxt=tostring($keyinfo[hou($kpart[$ii],".")]["COLUMN_CLSTXT"]);
          $houtaizhanshi=qian($keyinfo[hou($kpart[$ii],".")]["COLUMN_SSHOW"],"|");
          
           if ($kclstxt!="" and (strpos($kclstxt,"|")>0 or strpos($kclstxt,"/")>0)){        
              if ($dtp=="html" or $dtp=="table" or $dtp=="imgx"){
                  if (strpos($newonex,"key-")>0){
                   $hk=qian(hou($newonex,"key-"),"]");
                   $newonex=$sresult[$hk][$jj];
                  };
                  if ($rdonly==""){
                    //$selecthcd=" onchange=\"qajaxp('修改记录','/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=".hou($kpart[$ii],".")."&SNO=".$sresult['SNO'][$jj]."','p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."='+$('#"."p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."').val())\"";
                  }
                  if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]=="clstxt"){
                      $fmtmpselect=formselect(qian($newonex,"|"),hou($newonex,"|"),$sresult[hou($kpart[$ii],".")][$jj],"p_".hou($kpart[$ii],".").$sresult['SNO'][$jj],$rdonly,$selecthcd);
                  }
                  if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]=="clsduo"){
                      $fmtmpselect="<input type=\"hidden\" id=\""."p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" value=\"".$sresult[hou($kpart[$ii],".")][$jj]."\">".formselectx(qian($newonex,"|"),hou($newonex,"|"),$sresult[hou($kpart[$ii],".")][$jj],"p_".hou($kpart[$ii],".").$sresult['SNO'][$jj],"","");
                  };
                 if ($houtaizhanshi!=""){
                    $tmpvl=fmvalue($tbnm,$sresult[hou($kpart[$ii],".")][$jj],$sresult['SNO'][$jj],hou($kpart[$ii],"."),qian($keyinfo[hou($kpart[$ii],".")]["COLUMN_SSHOW"],"|"),$jj,$sresult);
                    $tmpvl=str_replace("<selected>",$fmtmpselect,$tmpvl);
                 }else{
                    $tmpvl=$fmtmpselect;
                 }
                 $fmtb=$fmtb."<td  class=\"TABTD_CLS\"   ".$coldspl.">".$tmpvl."</td>\r\n";
                 if (intval(_get("SNO"))==intval($sresult['SNO'][$jj])){
                     $fmline=$fmline."<td  class=\"TABTD_CLS\"   ".$coldspl.">".$tmpvl."</td>\r\n";
                    if (_get("tabkey")==hou($kpart[$ii],".")){
                          $fmtbk=$tmpvl;
                    };
                 }
                 $demo=str_replace("[".hou($kpart[$ii],".")."]",$tmpvl,$demo);
                 $demo=str_replace("[key-".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
              }
           }else{
            if ($dtp=="html" or $dtp=="table" or $dtp=="imgx"){              
               if ($houtaizhanshi!=""){
                  $tmpvl=fmvalue($tbnm,$sresult[hou($kpart[$ii],".")][$jj],$sresult['SNO'][$jj],hou($kpart[$ii],"."),qian($keyinfo[hou($kpart[$ii],".")]["COLUMN_SSHOW"],"|"),$jj,$sresult);
                  $fmtb=$fmtb."<td  class=\"TABTD_CLS\"   ".mkdisplay($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"])." title=\"".labturns(tostring($sresult[hou($kpart[$ii],".")][$jj]))."\">".$tmpvl."</td>\r\n";
                  if (intval(_get("SNO"))==intval($sresult['SNO'][$jj])){
                     $fmline=$fmline."<td  class=\"TABTD_CLS\"   ".mkdisplay($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"])." title=\"".labturns(tostring($sresult[hou($kpart[$ii],".")][$jj]))."\">".$tmpvl."</td>\r\n";
                           if (_get("tabkey")==hou($kpart[$ii],".")){
                            $fmtbk=$tmpvl;
                           };
                  }
                 $demo=str_replace("[".hou($kpart[$ii],".")."]",$tmpvl,$demo);
                 $demo=str_replace("[key-".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
              }else{
               if (strlen($sresult[hou($kpart[$ii],".")][$jj])>33){
                 $fmtb=$fmtb."<td  class=\"TABTD_CLS\"   ".mkdisplay($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"])." title=\"".labturns(tostring($sresult[hou($kpart[$ii],".")][$jj]))."\">".substr($sresult[hou($kpart[$ii],".")][$jj],0,33)."</td>\r\n";
                  if (intval(_get("SNO"))==intval($sresult['SNO'][$jj])){
                     $fmline=$fmline."<td  class=\"TABTD_CLS\"   ".mkdisplay($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"])." title=\"".labturns(tostring($sresult[hou($kpart[$ii],".")][$jj]))."\">".substr($sresult[hou($kpart[$ii],".")][$jj],0,33)."</td>\r\n";
                     if (_get("tabkey")==hou($kpart[$ii],".")){
                            $fmtbk=$sresult[hou($kpart[$ii],".")][$jj];
                     };
                  }
                 $demo=str_replace("[".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
                 $demo=str_replace("[key-".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
               }else{
                 $fmtb=$fmtb."<td  class=\"TABTD_CLS\"   ".mkdisplay($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"])." title=\"".labturns(tostring($sresult[hou($kpart[$ii],".")][$jj]))."\">".$sresult[hou($kpart[$ii],".")][$jj]."</td>\r\n";
                  if (intval(_get("SNO"))==intval($sresult['SNO'][$jj])){
                     $fmline=$fmline."<td  class=\"TABTD_CLS\"   ".mkdisplay($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"])." title=\"".labturns(tostring($sresult[hou($kpart[$ii],".")][$jj]))."\">".$sresult[hou($kpart[$ii],".")][$jj]."</td>\r\n";
                     if (_get("tabkey")==hou($kpart[$ii],".")){
                            $fmtbk=$sresult[hou($kpart[$ii],".")][$jj];
                     };
                  }
                 $demo=str_replace("[".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
                 $demo=str_replace("[key-".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
               };//33
             };//houtaizhanshi    
            };//html table imgx
           };//kclstxt
        };//if tmp>0
      };//if
       if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]=="date"){
         $tmpdtx=$tmpdtx."<script>laydatex('p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."');</script>";
       };
       if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]=="dttm"){
         $tmpdtx=$tmpdtx."<script>laydttmx('p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."');</script>";
       };
    };//for    
     $fmudt=substr($fmudt,0,strlen($fmudt)-1);  
     $fmexl=$fmexl.huanhang(); 
    if (strpos(".".$dtp.$headx,"nooprt")<=0 and ($oprtx*1)==1){
      if ($dtp=="html" or $dtp=="table" or $dtp=="imgx"){
       if (strpos($tbnm,",")>0){
         $fmtb=$fmtb."<td  class=\"TABTD_CLS\"  <a href=\"javascript:void(0)\"  ".mkdisplay($obtn)." onclick=\"update('".$xid."',".$sresult["SNO"][$jj].")\" snox=\"".$sresult["SNO"][$jj]."\"><img src=\"/ORG/BRAIN/images/icon/system/detail5.svg\" style=\"width:20px;height:20px;\"></a><a href=\"javascript:void(0)\" ".mkdisplay($vbtn)." onclick=\"qajaxp('修改记录','/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=".$tbkis."&SNO=".$sresult['SNO'][$jj]."&rnd=".onlymark()."',".$fmudt.")\" snox=\"".$sresult["SNO"][$jj]."\"><img id=\"upd".$sresult["SNO"][$jj]."\"  src=\"/ORG/BRAIN/images/icon/system/tongguoqr.svg\" style=\"width:20px;height:20px\"></a><a href=\"javascript:void(0)\" ".mkdisplay($xbtn)." onclick=\"Notiflix.Confirm.Show( '删除确认', '你确定要删除该条记录吗?', '是', '否', function(){ qajaxps('删除记录','/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=-killitem&QRY=".$tbkis."&SNO=".$sresult["SNO"][$jj]."',''); } );\" ".mkdisplay($xbtn)." snox=\"".$sresult["SNO"][$jj]."\"><img  id=\"del".$sresult["SNO"][$jj]."\" src=\"/ORG/BRAIN/images/icon/system/shanchu13.svg\" style=\"width:20px;height:20px\"></a></td>\r\n";
          if (intval(_get("SNO"))==intval($sresult['SNO'][$jj])){
              $fmline=$fmline."<td  class=\"TABTD_CLS\"  <a href=\"javascript:void(0)\"  ".mkdisplay($obtn)." onclick=\"update('".$xid."',".$sresult["SNO"][$jj].")\" snox=\"".$sresult["SNO"][$jj]."\"><img src=\"/ORG/BRAIN/images/icon/system/detail5.svg\" style=\"width:20px;height:20px;\"></a><a href=\"javascript:void(0)\" ".mkdisplay($vbtn)." onclick=\"qajaxp('修改记录','/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=".$tbkis."&SNO=".$sresult['SNO'][$jj]."&rnd=".onlymark()."',".$fmudt.")\" snox=\"".$sresult["SNO"][$jj]."\"><img  id=\"upd".$sresult["SNO"][$jj]."\" src=\"/ORG/BRAIN/images/icon/system/tongguoqr.svg\" style=\"width:20px;height:20px\"></a><a href=\"javascript:void(0)\" ".mkdisplay($xbtn)." onclick=\"Notiflix.Confirm.Show( '删除确认', '你确定要删除该条记录吗?', '是', '否', function(){ qajaxps('删除记录','/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=-killitem&QRY=".$tbkis."&SNO=".$sresult["SNO"][$jj]."',''); } );\" ".mkdisplay($xbtn)." snox=\"".$sresult["SNO"][$jj]."\"><img  id=\"del".$sresult["SNO"][$jj]."\" src=\"/ORG/BRAIN/images/icon/system/shanchu13.svg\" style=\"width:20px;height:20px\"></a></td>\r\n";
          }
         $demo=str_replace("[OPRT]","<a  href=\"javascript:void(0)\"  ".mkdisplay($obtn)." onclick=\"update('".$xid."',".$sresult["SNO"][$jj].")\" snox=\"".$sresult["SNO"][$jj]."\"><img src=\"/ORG/BRAIN/images/icon/system/detail5.svg\" style=\"width:20px;height:20px;\"></a><a href=\"javascript:void(0)\" ".mkdisplay($vbtn)." onclick=\"qajaxp('修改记录','/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=".$tbkis."&SNO=".$sresult['SNO'][$jj]."&rnd=".onlymark()."',".$fmudt.")\" snox=\"".$sresult["SNO"][$jj]."\"><img id=\"upd".$sresult["SNO"][$jj]."\" src=\"/ORG/BRAIN/images/icon/system/tongguoqr.svg\" style=\"width:20px;height:20px\"></a><a href=\"javascript:void(0)\" ".mkdisplay($xbtn)." onclick=\"Notiflix.Confirm.Show( '删除确认', '你确定要删除该条记录吗?', '是', '否', function(){ qajaxps('删除记录','/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=-killitem&QRY=".$tbkis."&SNO=".$sresult["SNO"][$jj]."',''); } );\" ".mkdisplay($xbtn)." snox=\"".$sresult["SNO"][$jj]."\"><img id=\"del".$sresult["SNO"][$jj]."\" src=\"/ORG/BRAIN/images/icon/system/shanchu13.svg\" style=\"width:20px;height:20px\"></a>",$demo);
       }else{
         $fmtb=$fmtb."<td  class=\"TABTD_CLS\"  ><a  href=\"javascript:void(0)\" ".mkdisplay($obtn)." onclick=\"update('".$xid."',".$sresult["SNO"][$jj].")\" snox=\"".$sresult["SNO"][$jj]."\"><img src=\"/ORG/BRAIN/images/icon/system/detail5.svg\" style=\"width:20px;height:20px;\"></a><a href=\"javascript:void(0)\" ".mkdisplay($vbtn)." onclick=\"qajaxp('修改记录','/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=".$tbkis."&SNO=".$sresult['SNO'][$jj]."',".$fmudt.")\" snox=\"".$sresult["SNO"][$jj]."&rnd=".onlymark()."\"><img id=\"upd".$sresult["SNO"][$jj]."\" src=\"/ORG/BRAIN/images/icon/system/tongguoqr.svg\" style=\"width:20px;height:20px\"></a><a href=\"javascript:void(0)\"  onclick=\"Notiflix.Confirm.Show( '删除确认', '你确定要删除该条记录吗?', '是', '否', function(){ qajaxps('删除记录','/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=-killitem&QRY=".$tbkis."&SNO=".$sresult["SNO"][$jj]."',''); } );\" ".mkdisplay($xbtn)." snox=\"".$sresult["SNO"][$jj]."\"><img id=\"del".$sresult["SNO"][$jj]."\" src=\"/ORG/BRAIN/images/icon/system/shanchu13.svg\" style=\"width:20px;height:20px\"></a></td>\r\n";
          if (intval(_get("SNO"))==intval($sresult['SNO'][$jj])){
              $fmline=$fmline."<td  class=\"TABTD_CLS\"  ><a  href=\"javascript:void(0)\" ".mkdisplay($obtn)." onclick=\"update('".$xid."',".$sresult["SNO"][$jj].")\" snox=\"".$sresult["SNO"][$jj]."\"><img src=\"/ORG/BRAIN/images/icon/system/detail5.svg\" style=\"width:20px;height:20px;\"></a><a href=\"javascript:void(0)\" ".mkdisplay($vbtn)." onclick=\"qajaxp('修改记录','/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=".$tbkis."&SNO=".$sresult['SNO'][$jj]."&rnd=".onlymark()."',".$fmudt.")\" snox=\"".$sresult["SNO"][$jj]."\"><img id=\"upd".$sresult["SNO"][$jj]."\" src=\"/ORG/BRAIN/images/icon/system/tongguoqr.svg\" style=\"width:20px;height:20px\"></a><a href=\"javascript:void(0)\"  onclick=\"Notiflix.Confirm.Show( '删除确认', '你确定要删除该条记录吗?', '是', '否', function(){ qajaxps('删除记录','/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=-killitem&QRY=".$tbkis."&SNO=".$sresult["SNO"][$jj]."',''); } );\" ".mkdisplay($xbtn)." snox=\"".$sresult["SNO"][$jj]."\"><img id=\"del".$sresult["SNO"][$jj]."\" src=\"/ORG/BRAIN/images/icon/system/shanchu13.svg\" style=\"width:20px;height:20px\"></a></td>\r\n";
          }
         $demo=str_replace("[OPRT]","<a  href=\"javascript:void(0)\" ".mkdisplay($obtn)." onclick=\"update('".$xid."',".$sresult["SNO"][$jj].")\" snox=\"".$sresult["SNO"][$jj]."\"><img src=\"/ORG/BRAIN/images/icon/system/detail5.svg\" style=\"width:20px;height:20px;\"></a><a href=\"javascript:void(0)\" ".mkdisplay($vbtn)." onclick=\"qajaxp('修改记录','/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=".$tbkis."&SNO=".$sresult['SNO'][$jj]."&rnd=".onlymark()."',".$fmudt.")\" snox=\"".$sresult["SNO"][$jj]."\"><img id=\"upd".$sresult["SNO"][$jj]."\" src=\"/ORG/BRAIN/images/icon/system/tongguoqr.svg\" style=\"width:20px;height:20px\"></a><a href=\"javascript:void(0)\"  onclick=\"Notiflix.Confirm.Show( '删除确认', '你确定要删除该条记录吗?', '是', '否', function(){ qajaxps('删除记录','/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=-killitem&QRY=".$tbkis."&SNO=".$sresult["SNO"][$jj]."',''); } );\" ".mkdisplay($xbtn)." snox=\"".$sresult["SNO"][$jj]."\"><img id=\"del".$sresult["SNO"][$jj]."\" src=\"/ORG/BRAIN/images/icon/system/shanchu13.svg\" style=\"width:20px;height:20px\"></a>",$demo);
       };
      };
    };
    if ($dtp=="html" or $dtp=="table" ){
      $fmtb=$fmtb."</tr>\r\n";    
    }
    
    if ($totrst>0){
      $fmjs=substr($fmjs,0,strlen($fmjs)-1)."},";
      $fmjh=substr($fmjh,0,strlen($fmjh)-1)."},";
      $fmch=$fmch.$demo;
    }else{      
    };
}
     if ($fmmd5js!="{"){
        $fmmd5js=substr($fmmd5js,0,strlen($fmmd5js)-1)."}";
     }else{
        $fmmd5js="{}";
     }
  
    if (intval($totrst)<=0){
      $fmjs=$fmjs."{";
      for ($ii=0;$ii<$totk;$ii++){
       $fmjs=$fmjs."\"".hou($kpart[$ii],".")."\":\"".str_replace("\"","\\\"",tohex($sresult[hou($kpart[$ii],".")][0]))."\",";
      }
      $fmjs=substr($fmjs,0,strlen($fmjs)-1)."},";
     };  
  $x=UX("update coode_shortdata set pagedemo='".gohex("<div id=\"customPages\" class=\"customPages\"><a href=\"javascript:void(0)\" onclick=\"tochange()\"><img id=\"tcg\" src=\"/ORG/BRAIN/images/icon/system/移动.svg\" style=\"width:20px;height:20px;\"></a><a href=\"javascript:void(0);\" id=\"setwh\" style=\"display:none;\" onclick=\"setwh()\">设置</a><a href=\"javascript:void(0)\" onclick=\"window.open(location.href)\"><img src=\"/ORG/BRAIN/images/icon/system/qj37.svg\" style=\"width:20px;height:20px;\"></a><span class=\"layui-laypage-count\">共[totrst]条</span>[pageselect][shownum]<a class=\"layui-btn\" id=\"tbnm\" tbnm=\"".$tbnm."\"  onclick=\"plsc('','".$tbnm."');\">批量删除</a><a class=\"layui-btn\"  onclick=\"quanxuan();\">全选</a><a href=\"javascript:void(0)\" id=\"isu\" onclick=\"changeb()\"><img src=\"/ORG/BRAIN/images/icon/system/xg0.svg\" style=\"width:20px;height:20px;\"></a><input id=\"isupdate\" type=\"hidden\" lay-skin=\"primary\" value=\"0\"></div>")."' where shortid='".$xid."' and pagedemo=''");
  $tbdatay["fmtb"]=$fmtb;
  $tbdatay["fmjs"]=$fmjs;  
  if (_get("tabkey")!=""){
    $tbdatay["fmline"]=$fmtbk;    
  }else{
    $tbdatay["fmline"]=$fmline;    
  };
  $tbdatay["fmmd5"]=$fmmd5js;  
  $tbdatay["fmch"]=$fmch;
  $tbdatay["exl"]=$fmexl;
  $tbdatay["tmpdtx"]=$tmpdtx;
  return $tbdatay;
}
function maketbheadin($totk,$chtml,$dtp,$tbhd,$oprtx,$headx,$keyinfo=array(array()),$kpart=array(),$headtxt=array()){
 $fmch="";
 $fmtb="";
 $fmexl="";
 $fmtp="";
 $fmdft="";
 $oprty=0;
 for ($pp=0;$pp<$totk;$pp++){
    $demo=$chtml;
    $dftfun=$keyinfo[hou($kpart[$pp],".")]["COLUMN_VALUEZERO"];
    $hfun="";
    $tmppost="";
    
    if ($kpart[$pp]=="OPRT"){
        $oprty=$oprty+1;
    }
    if (strpos("x".$dftfun,"thusvalue=")>0){
      eval($dftfun);
      $fmdft=$fmdft."\"".hou($kpart[$pp],".")."\":\"".$thusvalue."\",";
    }else{
      $fmdft=$fmdft."\"".hou($kpart[$pp],".")."\":\"\",";
    };
    
    if (($tbhd*1)==0 and strpos("x".$dtp,"print")<=0){
    }else{
     if (intval($keyinfo[$kpart[$pp]]["COLUMN_DSPLD"])*1==1){
       $coldspl="";
     }else{
       $coldspl="style=\"display:none;\"";
     }
     
     if ( $keyinfo[hou($kpart[$pp],".")]["COLUMN_TITLE"]!=""){
      if (hou($kpart[$pp],".")=="SNO"){
        $fmtb=$fmtb."<th knm=\"".hou($kpart[$pp],".")."\"  ".$coldspl." class=\"HDTD_CLS\">".$keyinfo[hou($kpart[$pp],".")]["COLUMN_TITLE"]."</th>\r\n";
        $fmtp=$fmtp."<th knm=\"".hou($kpart[$pp],".")."\"  align=\"right\" width=\"50\" class=\"HDTD_CLS\">".$keyinfo[hou($kpart[$pp],".")]["COLUMN_TITLE"]."</th>\r\n";
        $fmexl=$fmexl.$keyinfo[hou($kpart[$pp],".")]["COLUMN_TITLE"]."[tab]";
        
      }else{
        $fmtb=$fmtb."<th knm=\"".hou($kpart[$pp],".")."\"  ".$coldspl." class=\"HDTD_CLS\">".$keyinfo[hou($kpart[$pp],".")]["COLUMN_TITLE"]."</th>\r\n";
        $fmtp=$fmtp."<th knm=\"".hou($kpart[$pp],".")."\"  align=\"center\" class=\"HDTD_CLS\">".$keyinfo[hou($kpart[$pp],".")]["COLUMN_TITLE"]."</th>\r\n";
        $fmexl=$fmexl.$keyinfo[hou($kpart[$pp],".")]["COLUMN_TITLE"]."[tab]";
        
      }     
     }else{
      if (hou($kpart[$pp],".")=="SNO"){
        $fmtb=$fmtb."<th knm=\"".hou($kpart[$pp],".")."\"  ".$coldspl." class=\"HDTD_CLS\">".hou($kpart[$pp],".")."</th>\r\n";
        $fmtp=$fmtp."<th knm=\"".hou($kpart[$pp],".")."\"  align=\"right\" width=\"50\">".hou($kpart[$pp],".")."</th>\r\n";
        $fmexl=$fmexl.hou($kpart[$pp],".")."[tab]";
      }else{
        $fmtb=$fmtb."<th knm=\"".hou($kpart[$pp],".")."\"  ".$coldspl." class=\"HDTD_CLS\">".hou($kpart[$pp],".")."</th>\r\n";
        $fmtp=$fmtp."<th knm=\"".hou($kpart[$pp],".")."\"  align=\"center\" >".hou($kpart[$pp],".")."</th>\r\n";
        $fmexl=$fmexl.hou($kpart[$pp],".")."[tab]";
      }
     };      
   };
 };
  $fmdft=substr($fmdft,0,strlen($fmdft)-1)."}";
  $fmexl=$fmexl.huanhang();
  if (strpos($dtp.$headx,"nooprt")>0 or ($oprtx*1)==0 or $oprty>0  ){
  }else{
    if (strpos($dtp.$headx,"theadc")>0 ){
      $fmtb=$fmtb."<th knm=\"operation\" class=\"HDTD_CLS\">操作</th>";
     }else{
      $fmtb=$fmtb."<th knm=\"operation\" class=\"HDTD_CLS\">操作</th>";
     };
  };
  $headtxt["ftb"]=$fmtb;
  $headtxt["ftp"]=$fmtp;
  $headtxt["exl"]=$fmexl;
  $headtxt["dft"]=$fmdft;
  return $headtxt;
}
function maketabvue($totk,$trdemo,$tddemo,$dtp,$tbhd,$oprtx,$keyinfo=array(array()),$kpart=array(),$headtxt=array()){
 $fmtx="";
 for ($pp=0;$pp<$totk;$pp++){
    $demo=$tddemo;
    if (($tbhd*1)==0 and strpos("x".$dtp,"print")<=0){
    }else{
      if (intval($keyinfo[$kpart[$pp]]["COLUMN_DSPLD"])*1==1){
        $coldspl="";
      }else{
        $coldspl="\"display:none;\"";
      }
      if (hou($kpart[$pp],".")=="SNO"){
          $demo=str_replace("[key]",hou($kpart[$pp],"."),$demo);
          $demo=str_replace("[dspl]",$coldspl,$demo);
          $fmtx=$fmtx.$demo;
      }else{
          $demo=str_replace("[key]",hou($kpart[$pp],"."),$demo);
          $demo=str_replace("[dspl]",$coldspl,$demo);
          $fmtx=$fmtx.$demo;
      }     
    }
 }
   $trdemo=str_replace("[inner]",$fmtx,$trdemo);
  return $trdemo;
}
function makectraw($totk,$tbnm,$dtp,$ctraw,$sresult,$keyinfo,$kpart){
 if (($ctraw*1==1)){
  $fmtb="";
  $fmtb=$fmtb."<tr rowidx=\"x\">";
  for ($pp=0;$pp<$totk;$pp++){
             if ($keyinfo[hou($kpart[$pp],".")]["COLUMN_DSPLD"]*1==1){
               $coldspl="";
             }else{
               $coldspl="style=\"display:none;\"";
             }
             if ($keyinfo[hou($kpart[$pp],".")]["COLUMN_CANGE"]*1==1){
               $rdonly="";
             }else{
               $rdonly="readonly";
             }
         if (hou($kpart[$pp],".")=="SNO"){
           $fmtb=$fmtb."<td knm=\"".hou($kpart[$pp],".")."\"  ".$coldspl.">合计</td>\r\n";
         }else{
           if ($keyinfo[hou($kpart[$pp],".")]["COLUMN_TPNM"]=="int" or $keyinfo[hou($kpart[$pp],".")]["COLUMN_TPNM"]=="decimal"){
             $fmtb=$fmtb."<td knm=\"".hou($kpart[$pp],".")."\" ".$coldspl.">".$sresult[hou($kpart[$pp],".")][$totrst+2]."</td>\r\n";
           }else{
             $fmtb=$fmtb."<td knm=\"".hou($kpart[$pp],".")."\" ".$coldspl."></td>\r\n";
           }
         };         
  };
  if ($oprtx*1==1){
    if (strpos($tbnm,",")>0){//没有太大区分
      $fmtb=$fmtb."<td knm=\"operation\">";
      if (strpos(".".$dtp,"nocreate")<=0){       
       $fmtb=$fmtb."";
      };
      $fmtb=$fmtb."</td>\r\n";
     }else{
      $fmtb=$fmtb."<td knm=\"operation\">";
      if (strpos(".".$dtp,"nocreate")<=0){
        $fmtb=$fmtb."";
      };
      $fmtb=$fmtb."</td>\r\n";
     };
   };
    $fmtb=$fmtb."</tr>"; 
  }
  return $fmtb;
}
function makeaddoprt($totk,$appid,$tbnm,$tbkis,$fmdt,$dtp,$headx,$additemx,$oprtx,$keyinfo,$kpart){
  $fmtb="";
if (strpos(".".$dtp.$headx,"noadd")<=0 and ($additemx*1)==1){  
  $fmtb=$fmtb."<tr rowidx=\"0\">";
  $fmdt="";
  $fmsdt="";
  for ($pp=0;$pp<$totk;$pp++){
          $newonex=tostring($keyinfo[hou($kpart[$pp],".")]["COLUMN_CLSTXT"]);
         if ($keyinfo[hou($kpart[$pp],".")]["COLUMN_DSPLD"]*1==1){
            $coldspl="";
         }else{
            $coldspl="style=\"display:none;\"";
         }
      if ($keyinfo[hou($kpart[$pp],".")]["COLUMN_CLSTXT"]!=""){
            $yzd=0;
         if ($keyinfo[hou($kpart[$pp],".")]["COLUMN_DXTYPE"]=="clstxt"){    
            if(strpos($newonex,"|")>0){
              $fmtb=$fmtb."<td knm=\"".hou($kpart[$pp],".")."\" ".$coldspl.">".formselect(qian($newonex,"|"),hou($newonex,"|"),"","p_".hou($kpart[$pp],".")."0",""," onchange")."</td>";
              $yzd=$yzd+1;
            }else{
               $fmtb=$fmtb."<td knm=\"".hou($kpart[$pp],".")."\" ".$coldspl."></td>";
              $yzd=$yzd+1;
            }
          }        
           if ($keyinfo[hou($kpart[$pp],".")]["COLUMN_DXTYPE"]=="clsduo"){             
             if(strpos($newonex,"|")>0){
              $fmtb=$fmtb."<td knm=\"".hou($kpart[$pp],".")."\" ".$coldspl.">".formselectx(qian($newonex,"|"),hou($newonex,"|"),"","p_".hou($kpart[$pp],".")."0","","")."</td>";
               $yzd=$yzd+1;
             }else{
               $fmtb=$fmtb."<td knm=\"".hou($kpart[$pp],".")."\" ".$coldspl."></td>";
               $yzd=$yzd+1;
             }
          };
        if ($yzd==0){
              $fmtb=$fmtb."<td knm=\"".hou($kpart[$pp],".")."\" ".$coldspl."></td>";
         };
    }else{
         $tmpdft="";
         if ($_GET["s_".hou($kpart[$pp],".")."0"]==""){        
             if (strpos("xxx".$keyinfo[hou($kpart[$pp],".")]["COLUMN_VALUEZERO"],"thusvalue=")>0){
               $x=eval($keyinfo[hou($kpart[$pp],".")]["COLUMN_VALUEZERO"]);
               $tmpdft=$thusvalue;  
             }
           if (strpos("xxx".hou($keyinfo[hou($kpart[$pp],".")]["COLUMN_DEFAULT"],"|"),"defaultv=")>0){
              $x=eval(hou($keyinfo[hou($kpart[$pp],".")]["COLUMN_DEFAULT"],"|"));
             $tmpdft=$defaultv;
           }
             
        
         }else{
             $tmpdft=$_GET["s_".hou($kpart[$pp],".")."0"];
         };
         if (strpos(",,".$keyinfo["COLUMN"]["READONLY"]."," , ",".hou($kpart[$pp],".").",")>0 or $keyinfo[hou($kpart[$pp],".")]["COLUMN_CANGE"]=="0"){
           if (hou($kpart[$pp],".")=="SNO"){
              $snodspl="style=\"display:none;\"";
           }else{
              $snodspl="";
           };
             $fmtb=$fmtb."<td knm=\"".hou($kpart[$pp],".")."\"  ".$coldspl."><input id=\"p_".hou($kpart[$pp],".")."0\" size=\"10\" readonly value=\"".$tmpdft."\" ".$snodspl." placeholder=\"".hou($kpart[$pp],".")."\"></td>";
          }else{
           if (hou($kpart[$pp],".")=="SNO"){
             $snodspl="style=\"display:none;\"";
           }else{
             $snodspl="";
           };
            $fmtb=$fmtb."<td knm=\"".hou($kpart[$pp],".")."\"  ".$coldspl."><input id=\"p_".hou($kpart[$pp],".")."0\" size=\"10\" value=\"".$tmpdft."\" ".$snodspl." placeholder=\"".hou($kpart[$pp],".")."\"></td>";
          };
       };
       $tmpdft="";
       if (hou($kpart[$pp],".")!="SNO"){
         $fmdt=$fmdt."'&p_".hou($kpart[$pp],".")."0='+$('#p_".hou($kpart[$pp],".")."0').val()+";
         $fmsdt=$fmsdt."'&s_".hou($kpart[$pp],".")."0='+$('#p_".hou($kpart[$pp],".")."0').val()+";
       };
    };
    $fmdt="'".substr($fmdt,2,strlen($fmdt)-3);
    $fmsdt=substr($fmsdt,2,strlen($fmsdt)-3);
    if (strpos(".".$dtp.$headx,"noadd")<=0 and ($additemx*1)==1 and ($oprtx*1)==1){
      if (strpos($tbnm,",")>0){
           $fmtb=$fmtb."<td knm=\"operation\">";
         if (strpos(".".$dtp.$headx,"nooprt")<=0 and ($additemx*1)==1){
           $fmtb=$fmtb."<a href=\"javascript:void(0)\" onclick=\"ajaxhtmlpost('/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&SNO=0&kies=".$tbkis."',".$fmdt.");window.location.reload();\"><img src=\"/ORG/BRAIN/images/icon/system/newitem.svg\" style=\"width:20px;height:20px\"></a>";
         }
           $fmtb=$fmtb."</th>\r\n"; 
      }else{
           $fmtb=$fmtb."<td knm=\"operation\">";
      if (strpos(".".$dtp.$headx,"nooprt")<=0 and ($additemx*1)==1){
           $fmtb=$fmtb."<a href=\"javascript:void(0)\" onclick=\"ajaxhtmlpost('/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&SNO=0&kies=".$tbkis."',".$fmdt.");window.location.reload();\"><img src=\"/ORG/BRAIN/images/icon/system/newitem.svg\" style=\"width:20px;height:20px\"></a>";
      };
           $fmtb=$fmtb."</th>\r\n";
      };
    };
    $fmtb=$fmtb."</tr>\r\n";    
 };//判断展示与否的控件
  return $fmtb;
}
function pagedemo($totye,$pg,$pgn,$allkillbtn,$totallrst,$tbnm,$sid){ 
  $chid=UX("select caseid as result from coode_shortdata where shortid='".$sid."'");
  $demorst=SX("select pagesrd,pagein,pageout from coode_casehtml where cssmark='".$chid."'");
  $pagesrd=tostring(anyvalue($demorst,"pagesrd",0));
  $pagesrd=str_replace("{","<",$pagesrd);
  $pagesrd=str_replace("}",">",$pagesrd);
  $pagein=labturn(tostring(anyvalue($demorst,"pagein",0)));
  $pagein=str_replace("{","<",$pagein);
  $pagein=str_replace("}",">",$pagein);
  $pageout=labturn(tostring(anyvalue($demorst,"pageout",0)));
  $pageout=str_replace("{","<",$pageout);
  $pageout=str_replace("}",">",$pageout);
  $nextfiv=intval($pg)+3;
  $prefiv=intval($pg)-3;  
  if ($prefiv<0){
    $startp=0;
  }else{
    $startp=$prefiv;
  }
  if ($nextfiv>$totye){
    $deliv=$totye;
  }else{
    $deliv=$nextfiv;
  }  
  $fmy="";
  $fmslct="";
  $fmslctb="";
  $xid="";
  $stid="";
  
  for ($t=0;$t<$totye;$t++){
   $fmslct=$fmslct.($t+1).",";
   $fmslctb=$fmslctb."第".($t+1)."页,";
  };
  if ($totye>0){
   $fmslct=substr($fmslct,0,strlen($fmslct)-1);
   $fmslctb=substr($fmslctb,0,strlen($fmslctb)-1);
  }; 
   $fmselect=formselect($fmslctb,$fmslct,$pg,"topage","layui-select","onchange=\"tospage(document.getElementById('topage').value);\"");
   $fmselectjs=formselect($fmslctb,$fmslct,$pg,"topage","layui-select","onchange=\"tospage(document.getElementById('topage').value);\"");
   $fmspage="显示10条/页,显示20条/页,显示25条/页,显示30条/页,显示50条/页,显示100条/页,显示150条/页,显示200条/页,显示250条/页,显示300条/页,显示500条/页,显示800条/页,显示1000条/页,显示所有";
   $fmbpage="10,20,25,30,50,100,150,200,250,300,500,800,1000,0";
   $fmpagejs=formselect($fmspage,$fmbpage,$pgn,"setpagenum","layui-select","onchange=\"setpage(document.getElementById('setpagenum').value);\"");  
   
  for ($t=$startp;$t<$deliv;$t++){
      $demoin=$pagein;
      $demoout=$pageout;
   if ($pg==($t+1)){
       $demoin=str_replace("[page]",($t+1),$demoin);
       $demoin=str_replace("[pgtt]",($t+1),$demoin);
       $fmy=$fmy.$demoin;
   }else{
       $demoout=str_replace("[page]",($t+1),$demoout);
       $demoout=str_replace("[pgtt]",($t+1),$demoout);
       $fmy=$fmy.$demoout;      
   };
  };  
  if ($pg-1<1){
    $lstpg=1;
  }else{
    $lstpg=$pg-1;
  };
  if ($pg+1>$totye){
    $nxtpg=$totye;
  }else{
    $nxtpg=$pg+1;    
  };
  if (($allkillbtn*1)==0){
    $nodspl="style=\"display:none;\"";
  }
  $srddemo=$pagesrd;
  $srddemo=str_replace("[pagetot]",$totallrst,$srddemo);
  $srddemo=str_replace("[totye]",$totye,$srddemo);
  $srddemo=str_replace("[pgselect]",$fmselect,$srddemo);
  $srddemo=str_replace("[pageinner]",$fmy,$srddemo);
  $srddemo=str_replace("[shownum]",$fmpagejs,$srddemo);
  $srddemo=str_replace("[pgnum]",$fmpagejs,$srddemo);
  $srddemo=str_replace("[lstpg]",($pg-1),$srddemo);
  $srddemo=str_replace("[nxtpg]",($pg+1),$srddemo);
  $srddemo=str_replace("[tabnm]",$tbnm,$srddemo);
  $srddemo=str_replace("[stid]",$sid,$srddemo);
  $srddemo=str_replace("[nodspl]",$nodspl,$srddemo);
 return $srddemo; 
}
function pagexyz($totye,$pg,$pgn,$allkillbtn,$totallrst,$tbnm,$sid){ 
  if (dftval($_GET["dbnm"],"")==""){
    $csid=UX("select caseid as result from coode_shortdata where shortid='".$sid."'");
  }else{
    $csid=UX("select caseid as result from coode_dbshort where shortid='".$sid."'");      
  }
  $pagesrd=getcodedemo("pgsrd",qian($csid,"."),hou($csid,"."));
  $pagesrd=str_replace("{","<",$pagesrd);
  $pagesrd=str_replace("}",">",$pagesrd);
  $pagein=getcodedemo("pgin",qian($csid,"."),hou($csid,"."));
  $pagein=str_replace("{","<",$pagein);
  $pagein=str_replace("}",">",$pagein);
  $pageout=getcodedemo("pgout",qian($csid,"."),hou($csid,"."));
  $pageout=str_replace("{","<",$pageout);
  $pageout=str_replace("}",">",$pageout);
  $nextfiv=intval($pg)+3;
  $prefiv=intval($pg)-3;  
  if ($prefiv<0){
    $startp=0;
  }else{
    $startp=$prefiv;
  }
  if ($nextfiv>$totye){
    $deliv=$totye;
  }else{
    $deliv=$nextfiv;
  }  
  $fmy="";
  $fmslct="";
  $fmslctb="";
  $xid="";
  $stid="";
  
  for ($t=0;$t<$totye;$t++){
   $fmslct=$fmslct.($t+1).",";
   $fmslctb=$fmslctb."第".($t+1)."页,";
  };
  if ($totye>0){
   $fmslct=substr($fmslct,0,strlen($fmslct)-1);
   $fmslctb=substr($fmslctb,0,strlen($fmslctb)-1);
  }; 
   $fmselect=formselect($fmslctb,$fmslct,$pg,"topage","layui-select","onchange=\"tospage(document.getElementById('topage').value);\"");
   $fmselectjs=formselect($fmslctb,$fmslct,$pg,"topage","layui-select","onchange=\"tospage(document.getElementById('topage').value);\"");
   $fmspage="显示10条/页,显示20条/页,显示25条/页,显示30条/页,显示50条/页,显示100条/页,显示150条/页,显示200条/页,显示250条/页,显示300条/页,显示500条/页,显示800条/页,显示1000条/页,显示所有";
   $fmbpage="10,20,25,30,50,100,150,200,250,300,500,800,1000,0";
   $fmpagejs=formselect($fmspage,$fmbpage,$pgn,"setpagenum","layui-select","onchange=\"setpage(document.getElementById('setpagenum').value);\"");  
   
  for ($t=$startp;$t<$deliv;$t++){
      $demoin=$pagein;
      $demoout=$pageout;
   if ($pg==($t+1)){
       $demoin=str_replace("[page]",($t+1),$demoin);
       $demoin=str_replace("[pgtt]",($t+1),$demoin);
       $fmy=$fmy.$demoin;
   }else{
       $demoout=str_replace("[page]",($t+1),$demoout);
       $demoout=str_replace("[pgtt]",($t+1),$demoout);
       $fmy=$fmy.$demoout;      
   };
  };  
  if ($pg-1<1){
    $lstpg=1;
  }else{
    $lstpg=$pg-1;
  };
  if ($pg+1>$totye){
    $nxtpg=$totye;
  }else{
    $nxtpg=$pg+1;    
  };
  if (($allkillbtn*1)==0){
    $nodspl="style=\"display:none;\"";
  }
  $srddemo=$pagesrd;
  $srddemo=str_replace("[pagetot]",$totallrst,$srddemo);
  $srddemo=str_replace("[totye]",$totye,$srddemo);
  $srddemo=str_replace("[pgselect]",$fmselect,$srddemo);
  $srddemo=str_replace("[pginner]",$fmy,$srddemo);
  $srddemo=str_replace("[pgnum]",$fmpagejs,$srddemo);
  $srddemo=str_replace("[shownum]",$fmpagejs,$srddemo);
  $srddemo=str_replace("[lstpg]",($pg-1),$srddemo);
  $srddemo=str_replace("[nxtpg]",($pg+1),$srddemo);
  $srddemo=str_replace("[tabnm]",$tbnm,$srddemo);
  $srddemo=str_replace("[stid]",$sid,$srddemo);
  $srddemo=str_replace("[nodspl]",$nodspl,$srddemo);
 return $srddemo; 
}
 function maketable($srdhtm,$tbhd,$pghtm,$trhtm,$stb=array()){//pagehtm是页码
   $fmtable="";   
   $fmhdbody="";
   $btnhtm=array();
   $dsplnone="display:none;";//如果用STYLE的话，脚本里再有 STYLE会冲突  
   $fmhdbody=$stb["tbhd"]==1?combinestr4($fmtable,"<thead>",$tbhd,"</thead>"):$fmhdbody;
   $fmhdbody=$stb["dtx"]==1?combinestr4($fmtable,"<tbody>",$trhtm,"</tbody>"):$fmhdbody;
   $fmtable=str_replace("{tbheadbody}",$fmhdbody,turnlab($srdhtm));
   $fmtable=str_replace("{pagexyz}",$pghtm,$fmtable);
   $fmtable=str_replace("[tbheadbody]",$fmtable,$srdhtm);
   $fmtable=str_replace("[pagexyz]",$pghtm,$fmtable);      
   $btnhtm["additemxdspl"]=$stb["additemx"]==0?$dsplnone:"";
   $btnhtm["newbuttondspl"]=$stb["newbutton"]==0?$dsplnone:"";
   $btnhtm["obtndspl"]=$stb["obtn"]==0?$dsplnone:"";
   $btnhtm["vbtndspl"]=$stb["vbtn"]==0?$dsplnone:"";
   $btnhtm["xbtndspl"]=$stb["xbtn"]==0?$dsplnone:"";
   $btnhtm["oprtxdspl"]=$stb["oprtx"]==0?$dsplnone:"";
   $btnhtm["topbtndspl"]=$stb["topbtn"]==0?$dsplnone:"";
   $btnhtm["bottombtndspl"]=$stb["bottombtn"]==0?$dsplnone:"";
   $btnhtm["spsdspl"]=$stb["sps"]==0?$dsplnone:""; 
   $btnhtm["allkillbtndspl"]=$stb["allkillbtn"]==0?$dsplnone:"";
   $fmtable=str_replace("{tablename}",$stb["tablename"],$fmtable);
   $fmtable=str_replace("{tablenm}",$stb["tablename"],$fmtable);
   $fmtable=str_replace("{tabnm}",$stb["tablename"],$fmtable);
   $fmtable=str_replace("{sttab}",$stb["tablename"],$fmtable);
   $fmtable=str_replace("{stid}",$stb["tablename"],$fmtable);
   $fmtable=str_replace("{shortid}",$stb["shortid"],$fmtable);
   $fmtable=str_replace("{makecdt}",$stb["makecdt"],$fmtable);
   $fmtable=str_replace("{allcdt}",$stb["allcdt"],$fmtable);
   $fmtable=str_replace("{pnum}",$stb["pnum"],$fmtable);
   $fmtable=str_replace("{page}",$stb["page"],$fmtable);   
   $fmtable=str_replace("{topbtn}",turnlab($stb["topbtn"]),$fmtable);
   $fmtable=str_replace("{diytop}",turnlab($stb["diytop"]),$fmtable);
   $fmtable=str_replace("{searchdemo}",turnlab($stb["searchdemo"]),$fmtable);
   $fmtable=str_replace("{diybottom}",turnlab($stb["diybottom"]),$fmtable);
   $fmtable=str_replace("{headx}",turnlab($stb["headx"]),$fmtable);
   $fmtable=str_replace("{diycode}",turnlab($stb["diycode"]),$fmtable);
   $fmtable=str_replace("{shorttitle}",$stb["shorttitle"],$fmtable);  
   $fmtable=str_replace("{asc}",$stb["asc"],$fmtable);  
   $fmtable=str_replace("{xkey}",$stb["xkey"],$fmtable);  
   $fmtable=str_replace("{xval}",$stb["xval"],$fmtable);  
   $fmtable=str_replace("{additemxdspl}",$btnhtm["additemxdspl"],$fmtable);  
   $fmtable=str_replace("{newbuttondspl}",$btnhtm["newbuttondspl"],$fmtable);  
   $fmtable=str_replace("{obtndspl}",$btnhtm["obtndspl"],$fmtable);  
   $fmtable=str_replace("{vbtndspl}",$btnhtm["vbtndspl"],$fmtable);  
   $fmtable=str_replace("{xbtndspl}",$btnhtm["xbtndspl"],$fmtable);  
   $fmtable=str_replace("{oprtxdspl}",$btnhtm["oprtxdspl"],$fmtable);  
   $fmtable=str_replace("{topbtndspl}",$btnhtm["topbtndspl"],$fmtable);  
   $fmtable=str_replace("{bottombtndspl}",$btnhtm["bottombtndspl"],$fmtable);  
   $fmtable=str_replace("{spsdspl}",$btnhtm["spsdspl"],$fmtable);  
   $fmtable=str_replace("{allkillbtndspl}",$btnhtm["allkillbtndspl"],$fmtable);
   $fmtable=str_replace("[tablename]",$stb["tablename"],$fmtable);
   $fmtable=str_replace("[tablenm]",$stb["tablename"],$fmtable);
   $fmtable=str_replace("[tabnm]",$stb["tablename"],$fmtable);
   $fmtable=str_replace("[sttab]",$stb["tablename"],$fmtable);
   $fmtable=str_replace("[stid]",$stb["tablename"],$fmtable);
   $fmtable=str_replace("[shortid]",$stb["shortid"],$fmtable);
   $fmtable=str_replace("[makecdt]",$stb["makecdt"],$fmtable);
   $fmtable=str_replace("[allcdt]",$stb["allcdt"],$fmtable);
   $fmtable=str_replace("[pnum]",$stb["pnum"],$fmtable);
   $fmtable=str_replace("[page]",$stb["page"],$fmtable);   
   $fmtable=str_replace("[topbtn]",$stb["topbtn"],$fmtable);
   $fmtable=str_replace("[diytop]",$stb["diytop"],$fmtable);
   $fmtable=str_replace("[searchdemo]",$stb["searchdemo"],$fmtable);
   $fmtable=str_replace("[diybottom]",$stb["diybottom"],$fmtable);
   $fmtable=str_replace("[headx]",$stb["headx"],$fmtable);
   $fmtable=str_replace("[diycode]",$stb["diycode"],$fmtable);
   $fmtable=str_replace("[shorttitle]",$stb["shorttitle"],$fmtable);  
   $fmtable=str_replace("[asc]",$stb["asc"],$fmtable);  
   $fmtable=str_replace("[xkey]",$stb["xkey"],$fmtable);  
   $fmtable=str_replace("[xval]",$stb["xval"],$fmtable);  
   $fmtable=str_replace("[additemxdspl]",$btnhtm["additemxdspl"],$fmtable);  
   $fmtable=str_replace("[newbuttondspl]",$btnhtm["newbuttondspl"],$fmtable);  
   $fmtable=str_replace("[obtndspl]",$btnhtm["obtndspl"],$fmtable);  
   $fmtable=str_replace("[vbtndspl]",$btnhtm["vbtndspl"],$fmtable);  
   $fmtable=str_replace("[xbtndspl]",$btnhtm["xbtndspl"],$fmtable);  
   $fmtable=str_replace("[oprtxdspl]",$btnhtm["oprtxdspl"],$fmtable);  
   $fmtable=str_replace("[topbtndspl]",$btnhtm["topbtndspl"],$fmtable);  
   $fmtable=str_replace("[bottombtndspl]",$btnhtm["bottombtndspl"],$fmtable);  
   $fmtable=str_replace("[spsdspl]",$btnhtm["spsdspl"],$fmtable);  
   $fmtable=str_replace("[allkillbtndspl]",$btnhtm["allkillbtndspl"],$fmtable);     
   return $fmtable;
 }
function makepagerow($pnum,$pg,$atot,$stid,$cinfo=array(),$asc,$xky,$xvy){
  if ($pnum!="" and $pnum!="un"+"defined" and $pg!="" and $pg!="un"+"defined"){    
    $radius=7;
    $pagesrdx=$cinfo["pagesrd"];    
    $pageinx=$cinfo["pagein"];
    $pageoutx=$cinfo["pageout"];
    $pageinx=str_replace("{page}",$pg,$pageinx);
    $pageinx=str_replace("{asc}",$asc,$pageinx);
    $pageinx=str_replace("{xkey}",$xky,$pageinx);
    $pageinx=str_replace("{xval}",$xvy,$pageinx);
    $pageinx=str_replace("{pgtt}","第".$pg."页",$pageinx);
    $totpage=ceil($atot/$pnum);
    $endpg=($pg*1)+$radius;
    $startpg=($pg-$radius)-($endpg-$totpage);
    if ($endpg>$totpage){
      $endpage=$totpage;
    }else{
      $endpage=$endpg;
    };
    if ($startpg<1){
      $startpage=1; 
    }else{
      $startpage=$startpg;
    };
    $fminner="";
    $fmqk="";
    $fmhv="";    
    for ($px=$startpage;$px<$endpage+1;$px++){
      if ($pg!=$px){
       $pout=$pageoutx;    
       $pout=str_replace("{page}",$px,$pout);
       $pout=str_replace("{pgtt}","第".$px."页",$pout);
       $pout=str_replace("{asc}",$asc,$pout);
       $pout=str_replace("{xkey}",$xky,$pout);
       $pout=str_replace("{xval}",$xvy,$pout);
       $fmqk=$fmqk."第".$px."页,";
       $fmhv=$fmhv.$px.",";
       $fminner=$fminner.$pout;      
      }else{
         $fminner=$fminner.$pageinx;
      };//if
    }//for
    if ($totpage>0){
      $fmqk=substr($fmqk,0,strlen($fmqk)-1);
      $fmhv=substr($fmhv,0,strlen($fmhv)-1);
    };
   $xsslt="每页显示30条,每页显示50条,每页显示100条,每页显示150条,每页显示200条,每页显示300条,显示所有记录";
   $xsslv="30,50,100,150,200,300,0";
   $fmselectjs=formselect($fmqk,$fmhv,$pg,"topage","layui-select","onchange=\"tospage($(this).value);\"");
   $fmselectpn=formselect($xsslt,$xsslv,$pg,"topn","layui-select","onchange=\"setpage($(this).value);\"");
    $pagesrdx=str_replace("{asc}",$asc,$pagesrdx);
    $pagesrdx=str_replace("{xkey}",$xky,$pagesrdx);
    $pagesrdx=str_replace("{xval}",$xvy,$pagesrdx);  
    $pagesrdx=str_replace("{pagenum}",$pnum,$pagesrdx);    
    $pagesrdx=str_replace("{prepage}",$pg,$pagesrdx);    
   $pagesrdx=str_replace("{pgselect}",$fmselectjs,$pagesrdx);
   $pagesrdx=str_replace("{pgnum}",$fmselectpn,$pagesrdx);
   $pagesrdx=str_replace("{pageend}",$totpage,$pagesrdx);
    $pagesrdx=str_replace("{pagetot}",$totpage,$pagesrdx);
   $pagesrdx=str_replace("{pett}","尾页",$pagesrdx);
   $pagesrdx=str_replace("{pageinner}",$fminner,$pagesrdx);
  }else{
   $pagesrdx="";
  }      
  return $pagesrdx;
}//fun
 function maketbhead($skeyx,$kxif=array(array()),$cxif=array(),$stxy=array()){
     $headstr=$cxif["casehead"];   
     $shokx=$skeyx;
     $srst=array(array());
     $partkx=explode(",",$shokx);
     $totptkx=count($partkx);
     $trtr=$cxif["inline"];
     $fmtd="";
     for ($mx=0;$mx<$totptkx;$mx++){
       $tdvl=$kxif[$partkx[$mx]]["COLUMN_TITLE"]==""?$partkx[$mx]:$kxif[$partkx[$mx]]["COLUMN_TITLE"];
       $tdxx=array();
       $tdxx=formtrow($tdxx,$partkx[$mx],$tdvl,"-1","-1",$kxif,$stxy,-1,$srst);
       $maketdv=exchangeunit($tdxx,$cxif["casehead"]);
       $fmtd=$fmtd.$maketdv;
     }  
    $trtr=str_replace("[inline]",$fmtd,$trtr);
   return $trtr;
 }
 function makedetail($srdhtm,$tbhd,$pghtm,$trhtm,$stb=array(),$std=array()){
   $fmtable="";   
   $btnhtm=array();
   $dsplnone="display:none;";//如果用STYLE的话，脚本里再有 STYLE会冲突          
   $fmtable=str_replace("{srdinner}",$trhtm,$srdhtm);
   $fmtable=str_replace("{expunit}",$tbhd,$fmtable);
   //$fmtable=str_replace("[pagehtm]",$pghtm,$fmtable);      
   $btnhtm["additemxdspl"]=$stb["additemx"]==0?$dsplnone:"";
   $btnhtm["newbuttondspl"]=$stb["newbutton"]==0?$dsplnone:"";
   $btnhtm["obtndspl"]=$stb["obtn"]==0?$dsplnone:"";
   $btnhtm["vbtndspl"]=$stb["vbtn"]==0?$dsplnone:"";
   $btnhtm["xbtndspl"]=$stb["xbtn"]==0?$dsplnone:"";
   $btnhtm["oprtxdspl"]=$stb["oprtx"]==0?$dsplnone:"";
   $btnhtm["topbtndspl"]=$stb["topbtn"]==0?$dsplnone:"";
   $btnhtm["bottombtndspl"]=$stb["bottombtn"]==0?$dsplnone:"";
   $btnhtm["spsdspl"]=$stb["sps"]==0?$dsplnone:""; 
   $btnhtm["allkillbtndspl"]=$stb["allkillbtn"]==0?$dsplnone:"";
   $btnhtm["sbtndspl"]=$std["sbtn"]==0?$dsplnone:"";
   $btnhtm["rbtndspl"]=$std["rbtn"]==0?$dsplnone:"";
   $btnhtm["dtshowdspl"]=$std["dtshow"]==0?$dsplnone:""; 
   $btnhtm["isexpdspl"]=$std["isexpdspl"]==0?$dsplnone:"";   
   $fmtable=str_replace("{tablename}",$stb["tablename"],$fmtable);
   $fmtable=str_replace("{shortid}",$stb["shortid"],$fmtable);
   $fmtable=str_replace("{makecdt}",$stb["makecdt"],$fmtable);
   $fmtable=str_replace("{allcdt}",$stb["allcdt"],$fmtable);
   $fmtable=str_replace("{shorttitle}",$stb["shorttitle"],$fmtable);  
   $fmtable=str_replace("{asc}",$stb["asc"],$fmtable);  
   $fmtable=str_replace("{xkey}",$stb["xkey"],$fmtable);  
   $fmtable=str_replace("{xval}",$stb["xval"],$fmtable);  
   $fmtable=str_replace("{diybutton}",$std["diybutton"],$fmtable);
   $fmtable=str_replace("{diytop}",$std["diytop"],$fmtable);
   $fmtable=str_replace("{bottombutton}",$std["bottombutton"],$fmtable);  
   $fmtable=str_replace("{diybottom}",$std["diybottom"],$fmtable);  
   $fmtable=str_replace("{diyshow}",$std["diyshow"],$fmtable);  
   $fmtable=str_replace("{expunit}",$std["expunit"],$fmtable);  
   $fmtable=str_replace("{additemxdspl}",$btnhtm["additemxdspl"],$fmtable);  
   $fmtable=str_replace("{newbuttondspl}",$btnhtm["newbuttondspl"],$fmtable);  
   $fmtable=str_replace("{obtndspl}",$btnhtm["obtndspl"],$fmtable);  
   $fmtable=str_replace("{vbtndspl}",$btnhtm["vbtndspl"],$fmtable);  
   $fmtable=str_replace("{xbtndspl}",$btnhtm["xbtndspl"],$fmtable);  
   $fmtable=str_replace("{oprtxdspl}",$btnhtm["oprtxdspl"],$fmtable);  
   $fmtable=str_replace("{topbtndspl}",$btnhtm["topbtndspl"],$fmtable);  
   $fmtable=str_replace("{bottombtndspl}",$btnhtm["bottombtndspl"],$fmtable);  
   $fmtable=str_replace("{spsdspl}",$btnhtm["spsdspl"],$fmtable);  
   $fmtable=str_replace("{allkillbtndspl}",$btnhtm["allkillbtndspl"],$fmtable);     
   $fmtable=str_replace("{sbtndspl}",$btnhtm["sbtndspl"],$fmtable);  
   $fmtable=str_replace("{rbtndspl}",$btnhtm["rbtndspl"],$fmtable);  
   $fmtable=str_replace("{dtshowdspl}",$btnhtm["dtshowdspl"],$fmtable);  
   $fmtable=str_replace("{isexpdspl}",$btnhtm["isexpdspl"],$fmtable);     
   return $fmtable;
 }
 function casecss($caseid,$stcss=array()){
  $conn=mysql_connect(gl(),glu(),glp());
  $contrst=selecteds($conn,glb(),"select jsfiley,cssfiley,scripty,styley from coode_domainunit where dumark='".$caseid."'","utf8","");  
  $stcss["caseid"]=$caseid;
  $stcss["jsfiles"]=tostring(anyvalue($contrst,"jsfiles",0));
  $stcss["cssfiles"]=tostring(anyvalue($contrst,"cssfiles",0));
  $stcss["scriptx"]=tostring(anyvalue($contrst,"scriptx",0));
  $stcss["stylex"]=tostring(anyvalue($contrst,"stylex",0));
  return $stcss;
}
function dbshortcss($dbmk,$shortid,$stcss=array()){
  $contrst=SX("select jsfiles,cssfiles,scriptx,stylex,scriptext,styleext,diytop,diybottom,diybutton,diyshow,bottombutton,expunit,sbtn,rbtn,dtshow,isexp from coode_shortcss where shortid='".$shortid."' and catalog='".$dbmk."'");  
  $stcss["shortid"]=$shortid;
  $stcss["jsfiles"]=tostring(anyvalue($contrst,"jsfiles",0));
  $stcss["cssfiles"]=tostring(anyvalue($contrst,"cssfiles",0));
  $stcss["scriptx"]=tostring(anyvalue($contrst,"scriptx",0));
  $stcss["stylex"]=tostring(anyvalue($contrst,"stylex",0));
  $stcss["scriptext"]=tostring(anyvalue($contrst,"scriptext",0));
  $stcss["styleext"]=tostring(anyvalue($contrst,"styleext",0));
  $stcss["diybutton"]=instance(tostring(anyvalue($contrst,"diybutton",0)));
  $stcss["diytop"]=instance(tostring(anyvalue($contrst,"diytop",0)));
  $stcss["diybottom"]=instance(tostring(anyvalue($contrst,"diybottom",0)));
  $stcss["diyshow"]=instance(tostring(anyvalue($contrst,"diyshow",0)));
  $stcss["bottombutton"]=instance(tostring(anyvalue($contrst,"bottombutton",0)));
  $stcss["expunit"]=instance(tostring(anyvalue($contrst,"expunit",0)));
  $stcss["sbtn"]=intval(tostring(anyvalue($contrst,"sbtn",0)))*1;
  $stcss["rbtn"]=intval(tostring(anyvalue($contrst,"rbtn",0)))*1;
  $stcss["dtshow"]=intval(tostring(anyvalue($contrst,"dtshow",0)))*1;
  $stcss["isexp"]=intval(tostring(anyvalue($contrst,"isexp",0)))*1;    
  return $stcss;
}
function shortcss($shortid,$stcss=array()){
  $conn=mysql_connect(gl(),glu(),glp());
  $contrst=selecteds($conn,glb(),"select jsfiles,cssfiles,scriptx,stylex,scriptext,styleext,diytop,diybottom,diybutton,diyshow,bottombutton,expunit,sbtn,rbtn,dtshow,isexp from coode_shortcss where shortid='".$shortid."'","utf8","");  
  $stcss["shortid"]=$shortid;
  $stcss["jsfiles"]=tostring(anyvalue($contrst,"jsfiles",0));
  $stcss["cssfiles"]=tostring(anyvalue($contrst,"cssfiles",0));
  $stcss["scriptx"]=tostring(anyvalue($contrst,"scriptx",0));
  $stcss["stylex"]=tostring(anyvalue($contrst,"stylex",0));
  $stcss["scriptext"]=tostring(anyvalue($contrst,"scriptext",0));
  $stcss["styleext"]=tostring(anyvalue($contrst,"styleext",0));
  $stcss["diybutton"]=instance(tostring(anyvalue($contrst,"diybutton",0)));
  $stcss["diytop"]=instance(tostring(anyvalue($contrst,"diytop",0)));
  $stcss["diybottom"]=instance(tostring(anyvalue($contrst,"diybottom",0)));
  $stcss["diyshow"]=instance(tostring(anyvalue($contrst,"diyshow",0)));
  $stcss["bottombutton"]=instance(tostring(anyvalue($contrst,"bottombutton",0)));
  $stcss["expunit"]=instance(tostring(anyvalue($contrst,"expunit",0)));
  $stcss["sbtn"]=intval(tostring(anyvalue($contrst,"sbtn",0)))*1;
  $stcss["rbtn"]=intval(tostring(anyvalue($contrst,"rbtn",0)))*1;
  $stcss["dtshow"]=intval(tostring(anyvalue($contrst,"dtshow",0)))*1;
  $stcss["isexp"]=intval(tostring(anyvalue($contrst,"isexp",0)))*1;    
  return $stcss;
}
function pagecss($pageid,$stcss=array()){
  $conn=mysql_connect(gl(),glu(),glp());
  $contrst=selecteds($conn,glb(),"select jsfiles,cssfiles,scriptx,stylex from coode_compage where pageid='".$pageid."'","utf8","");  
  $stcss["pageid"]=$pageid;
  $stcss["jsfiles"]=tostring(anyvalue($contrst,"jsfiles",0));
  $stcss["cssfiles"]=tostring(anyvalue($contrst,"cssfiles",0));
  $stcss["scriptx"]=tostring(anyvalue($contrst,"scriptx",0));
  $stcss["stylex"]=tostring(anyvalue($contrst,"stylex",0));
  return $stcss;
}
 function caseinfo($caseid,$kcs=array()){
$conn=mysql_connect(gl(),glu(),glp());   
$contrst=selectedx($conn,glb(),"select SNO,cssfiles,jsfiles,stylex,scriptx,pagesrd,pagein,pageout,casevarchar,casethead,casephp,casetext,caseclstxt,caseclsduo,casedate,casedttm,caseint,casesrd,caserow,casedecimal,caseimage,caseimgx,casefile,caseduofile,casecheck,caseinline from coode_caseform where cfid='".$caseid."'","utf8","");//比较公私分离是否成功,展示比较用hcss2   
$kcs["caseid"]=$caseid;
   $kcs["cssfiles"]=tostring(anyvalue($contrst,"cssfiles",0));
   $kcs["jsfiles"]=tostring(anyvalue($contrst,"jsfiles",0));
   $kcs["stylex"]=tostring(anyvalue($contrst,"stylex",0));
   $kcs["scriptx"]=tostring(anyvalue($contrst,"scriptx",0));
$kcs["casehead"]=instance(tostring(anyvalue($contrst,"casethead",0)));
$kcs["varchar"]=instance(tostring(anyvalue($contrst,"casevarchar",0)));
$kcs["text"]=instance(tostring(anyvalue($contrst,"casetext",0)));
$kcs["tarea"]=instance(tostring(anyvalue($contrst,"casetext",0)));
$kcs["clstxt"]=instance(tostring(anyvalue($contrst,"caseclstxt",0)));
$kcs["clsduo"]=instance(tostring(anyvalue($contrst,"caseclsduo",0)));
$kcs["date"]=instance(tostring(anyvalue($contrst,"casedate",0)));
$kcs["dttm"]=instance(tostring(anyvalue($contrst,"casedttm",0)));
$kcs["int"]=instance(tostring(anyvalue($contrst,"caseint",0)));
$kcs["decimal"]=instance(tostring(anyvalue($contrst,"casedecimal",0)));
$kcs["image"]=instance(tostring(anyvalue($contrst,"caseimage",0)));
$kcs["imgx"]=instance(tostring(anyvalue($contrst,"caseimgx",0)));
$kcs["filex"]=instance(tostring(anyvalue($contrst,"casefile",0)));
$kcs["duofile"]=instance(tostring(anyvalue($contrst,"caseduofile",0)));
$kcs["check"]=instance(tostring(anyvalue($contrst,"casecheck",0)));
$kcs["inline"]=instance(tostring(anyvalue($contrst,"caseinline",0)));
$kcs["row"]=instance(tostring(anyvalue($contrst,"caserow",0)));     
$kcs["srd"]=instance(tostring(anyvalue($contrst,"casesrd",0)));  
$kcs["inline"]=instance(tostring(anyvalue($contrst,"caseinline",0)));
$kcs["pagesrd"]=instance(tostring(anyvalue($contrst,"pagesrd",0)));
$kcs["pagein"]=instance(tostring(anyvalue($contrst,"pagein",0)));  
$kcs["pageout"]=instance(tostring(anyvalue($contrst,"pageout",0)));
$kcs["php"]=tostring(anyvalue($contrst,"casephp",0));
return $kcs;
}
function htmlcss($cssmk,$chcss=array()){
      $conn=mysql_connect(gl(),glu(),glp()); 
      $mkrst=selecteds($conn,glb(),"select casesurd,casehtml from coode_casehtml where cssmark='".$cssmk."'","utf8","");
      $chcss["csurd"]=instance(tostring(anyvalue($mkrst,"casesurd",0)));
      $chcss["chtml"]=instance(tostring(anyvalue($mkrst,"casehtml",0)));
      $chcss["jsfiles"]=tostring(anyvalue($mkrst,"jsfiles",0));
      $chcss["cssfiles"]=tostring(anyvalue($mkrst,"cssfiles",0));
      $chcss["scriptx"]=tostring(anyvalue($mkrst,"scriptx",0));
      $chcss["stylex"]=tostring(anyvalue($mkrst,"stylex",0));
   return $chcss;
}
?>