<?php
function anytab($shortid,$page,$pnum,$allsc,$xk,$xv,$itab=array()){
   $pgnum=$pnum;
    if ($pgnum!=""){
      $pgnum=$pgnum*1;
    };
    if ($page!=""){
      $page=$page*1;
    }
   if ($shortid!=""){//想办法把下面独立出来，如果有制定KEYS借用某SHORT页要可以实现，这样就能任意表查询了
     $_POST[combinestr2($shortid,"_stylex")]="";
     $_POST[combinestr2($shortid,"_scriptx")]="";
     $_POST[combinestr2($shortid,"_cssfiles")]="";
     $_POST[combinestr2($shortid,"_jsfiles")]=""; 
     $sbase=shortinfo($shortid,$sbase);    
     $caseid=$sbase["caseid"];
    if ($caseid!=""){
        $cscs=casecss($caseid,$cscs);
        $ncss=combinecss($shortid,$cscs);
        $scss=shortcss($shortid,$scss);
        $ncss=combinecss($shortid,$scss);          
        $ccs["varchar"]=getcodedemo("varchar",qian($caseid,"."),hou($caseid,"."));
        $ccs["chtml"]=getcodedemo("chtml",qian($caseid,"."),hou($caseid,"."));
        $ccs["text"]=getcodedemo("text",qian($caseid,"."),hou($caseid,"."));
        $ccs["tarea"]=getcodedemo("tarea",qian($caseid,"."),hou($caseid,"."));
        $ccs["clstxt"]=getcodedemo("clstxt",qian($caseid,"."),hou($caseid,"."));
        $ccs["clsduo"]=getcodedemo("clsduo",qian($caseid,"."),hou($caseid,"."));
        $ccs["date"]=getcodedemo("date",qian($caseid,"."),hou($caseid,"."));
        $ccs["dttm"]=getcodedemo("dttm",qian($caseid,"."),hou($caseid,"."));
        $ccs["int"]=getcodedemo("int",qian($caseid,"."),hou($caseid,"."));
        $ccs["decimal"]=getcodedemo("decimal",qian($caseid,"."),hou($caseid,"."));
        $ccs["image"]=getcodedemo("image",qian($caseid,"."),hou($caseid,"."));
        $ccs["imgx"]=getcodedemo("imgx",qian($caseid,"."),hou($caseid,"."));
        $ccs["filex"]=getcodedemo("filex",qian($caseid,"."),hou($caseid,"."));
        $ccs["duofile"]=getcodedemo("duofile",qian($caseid,"."),hou($caseid,"."));
        $ccs["check"]=getcodedemo("check",qian($caseid,"."),hou($caseid,"."));
        $ccs["checkduo"]=getcodedemo("checkduo",qian($caseid,"."),hou($caseid,"."));
        $ccs["srd"]=getcodedemo("srd",qian($caseid,"."),hou($caseid,"."));
        $ccs["content"]=getcodedemo("content",qian($caseid,"."),hou($caseid,"."));
        $ccs["searchdemo"]=getcodedemo("searchdemo",qian($caseid,"."),hou($caseid,"."));
        $ccs["tabtr"]=getcodedemo("tabtr",qian($caseid,"."),hou($caseid,"."));
        $ccs["tabtd"]=getcodedemo("tabtd",qian($caseid,"."),hou($caseid,"."));
        $ccs["tabhdtr"]=getcodedemo("tabhdtr",qian($caseid,"."),hou($caseid,"."));
        $ccs["tabhdtd"]=getcodedemo("tabhdtd",qian($caseid,"."),hou($caseid,"."));
        $ccs["pgsrd"]=getcodedemo("pgsrd",qian($caseid,"."),hou($caseid,"."));
        $ccs["pgin"]=getcodedemo("pgin",qian($caseid,"."),hou($caseid,"."));
        $ccs["pgout"]=getcodedemo("pgouyt",qian($caseid,"."),hou($caseid,"."));
        $ccs["pgfirst"]=getcodedemo("pgfirst",qian($caseid,"."),hou($caseid,"."));
        $ccs["pglast"]=getcodedemo("pglast",qian($caseid,"."),hou($caseid,"."));
        $ccs["pgslcls"]=getcodedemo("pgslcls",qian($caseid,"."),hou($caseid,"."));
        $csurd=getcodedemo("srd",qian($caseid,"."),hou($caseid,"."));
        $chtml=getcodedemo("chtml",qian($caseid,"."),hou($caseid,"."));
      //之后加上denycdt      
     $mkcdt=comcdt($pgnum,$page,$sbase["showkeys"],$sbase["cdt"],$sbase["orddt"],$allsc,$xk,$xv);     
     $gkinfo=thekeyfun($gkinfo,glb(),$sbase["tablename"],$sbase["showkeys"]);    
     if (combinestr3($allsc,$xk,$xv)==""){
       $alltot=UX(combinestr2("select count(*) as result from ",$sbase["tablename"]))*1;
       $cdtstr="";
     }else{
       if (strpos($mkcdt,"limit ")>0){
         $nolmt=qian($mkcdt," limit ");
         $alltot=UX(combinestr4("select count(*) as result from ",$sbase["tablename"]," where ",$nolmt))*1;
         $cdtstr=$nolmt;
       }else{
         $alltot=UX(combinestr4("select count(*) as result from ",$sbase["tablename"]," where ",$mkcdt))*1;
         $cdtstr=$mkcdt;
       }
     }
      //echo "pgnum-".$pgnum."xx".$page;
     $pghtml=makepagerow($pgnum,$page,$alltot,$shortid,$ccs,$allsc,$xk,$xv);
     $conn=mysql_connect(gl(),glu(),glp()); 
     $sqlx= "";
      if (str_replace(" ","",combinestr3($allsc,$xk,$xv))!=""){//limit 条件
        $sqlx=combinestr6("select ",$sbase["showkeys"]," from ",$sbase["tablename"]," where ",$mkcdt);        
      }else{
        $sqlx=combinestr6("select ",$sbase["showkeys"]," from ",$sbase["tablename"]," ",$mkcdt);        
      }   
      
      $dtrst=selecteds($conn,glb(),$sqlx ,"utf8","");
      //echo "select ".$sbase["showkeys"]." from ".$sbase["tablename"];
     $totrcd=countresult($dtrst);
    if ($totrcd>0){
      $arraydata=array();
      $arraydata=arrdata($arraydata,$dtrst);     
      $arraydata=arrdefault($sbase["showkeys"],$gkinfo,$arraydata);
   // FUN:$funvalue="";      
     $shoks=$sbase["showkeys"];
     $partk=explode(",",$shoks);
     $totptk=count($partk);         
     $tablehd=maketbhead($shoks,$gkinfo,$ccs,$sbase);      
     //之后加上denykey
     $binfo=array();
     $fmhtmlx="";
     $sbase["makecdt"]=$mkcdt;
     $sbase["pnum"]=$pgnum;
     $sbase["page"]=$page;     
     $sbase["asc"]=$allsc;    
     $sbase["xkey"]=$xk;    
     $sbase["xval"]=$xv;    
     
    $fmch="";         
    $fmextscript="";
    for ($ti=1;$ti<($totrcd+1);$ti++){      
      $fmtrinner="";
      $fmtrouter=turnlab($ccs["tabtr"]);
      $demo=turnlab($chtml);
       for ($tj=0;$tj<$totptk;$tj++){ 
          $tdxtp=$gkinfo[$partk[$tj]]["COLUMN_DXTYPE"];         
          $binfo=formtrow($binfo,$partk[$tj],$arraydata[$partk[$tj]][$ti],$arraydata["SNO"][$ti],$arraydata["OLMK"][$ti],$gkinfo,$sbase,$ti,$arraydata);
          $tdcode=turnlab($ccs["tabtd"]);
          $tdinner=exchangeunit($binfo,$ccs[$tdxtp]);
          $tdcode=exchangeunit($binfo,$tdcode);
          $comux=str_replace("{inner}",$tdinner,$tdcode);
          $comux=str_replace("[inner]",$tdinner,$tdcode);
         if ($ccs[$tdxtp."SCRIPT"]!=""){
           $tmpscript=exchangeunit($binfo,$ccs[$tdxtp."SCRIPT"]);
           $fmextscript=combinestr3($fmextscript,$tmpscript,huanhang());
         }else{
           $tmpscript="";
         }
          if ($chtml!=""){
           $demo=str_replace("{SNO}",$arraydata['SNO'][$ti],$demo);
           $demo=str_replace("{key-SNO}",$arraydata['SNO'][$ti],$demo);
           $demo=str_replace("{thissno}",$arraydata['SNO'][$ti],$demo);
           $demo=str_replace("[SNO}",$arraydata['SNO'][$ti],$demo);
           $demo=str_replace("[key-SNO]",$arraydata['SNO'][$ti],$demo);
           $demo=str_replace("[thissno]",$arraydata['SNO'][$ti],$demo);
           $demo=str_replace(combinestr3("{",$partk[$tj],"}"),$binfo["value"],$demo);
           $demo=str_replace(combinestr3("[",$partk[$tj],"]"),$binfo["value"],$demo);
           $demo=str_replace(combinestr3("{key-",$partk[$tj],"}"),tostring($arraydata[$partk[$tj]][$ti]),$demo);
           $demo=str_replace(combinestr3("[key-",$partk[$tj],"]"),tostring($arraydata[$partk[$tj]][$ti]),$demo);
          }
          $fmtrinner=combinestr2($fmtrinner,$comux);
         
       };//有空加OPRT
        if ($totptk>0){
          if ($chtml!=""){
           $fmch=combinestr2($fmch,$demo);          
          }
          if (strpos($fmtrouter,"{inner}")>0){
           $fmhtmlx=combinestr2($fmhtmlx,str_replace("{inner}",$fmtrinner,$fmtrouter));
          }else{
           $fmhtmlx=combinestr2($fmhtmlx,str_replace("[inner]",$fmtrinner,$fmtrouter));
          }
        };      
    };//有必要的时候加上统计行 
     $onlyrow=$fmhtmlx;
      if ($sbase["ctraw"]==1){
       $fmtrinner="";
       $fmtrouter=turnlab($ccs["tabtr"]);
       $demo=turnlab($chtml);
       for ($tj=0;$tj<$totptk;$tj++){              
         $tdxtp="decimal";         
         $binfo=formtrow($binfo,$partk[$tj],$arraydata[$partk[$tj]][$totrcd+2],$arraydata["SNO"][$totrcd+2],$arraydata["OLMK"][$totrcd+2],$gkinfo,$sbase,$totrcd+2,$arraydata);
         $comux=exchangeunit($binfo,$ccs[$tdxtp]);
          if ($chtml!=""){
            $demo=str_replace("{SNO}","本页合计",$demo);
            $demo=str_replace("[SNO]","本页合计",$demo);
            $demo=str_replace("{key-SNO}","本页合计",$demo);
            $demo=str_replace("[key-SNO]","本页合计",$demo);
            $demo=str_replace("{thissno}","本页合计",$demo);
            $demo=str_replace("[thissno]","本页合计",$demo);
            $demo=str_replace(combinestr3("{",$partk[$tj],"}"),tostring($arraydata[$partk[$tj]][$totrcd+2]),$demo);
            $demo=str_replace(combinestr3("{key-",$partk[$tj],"}"),tostring($arraydata[$partk[$tj]][$totrcd+2]),$demo);
            $demo=str_replace(combinestr3("[",$partk[$tj],"]"),tostring($arraydata[$partk[$tj]][$totrcd+2]),$demo);
            $demo=str_replace(combinestr3("[key-",$partk[$tj],"]"),tostring($arraydata[$partk[$tj]][$totrcd+2]),$demo);
          }
          $fmtrinner=combinestr2($fmtrinner,$comux);
        };//
        if (strpos($fmtrouter,"{inner}")>0){
           $fmhtmlx=combinestr2($fmhtmlx,str_replace("{inner}",$fmtrinner,$fmtrouter));
        }else{
           $fmhtmlx=combinestr2($fmhtmlx,str_replace("[inner]",$fmtrinner,$fmtrouter));
        }
        if ($chtml!=""){
          $fmch=combinestr2($fmch,$demo);
        }
      };//ctraw   
     if ($totrcd>0){
       $csurd=str_replace("{inner}",$fmch,$csurd);
       $csurd=str_replace("[inner]",$fmch,$csurd);
     };
      //maketable前把SBASE里的各种DIY 解析了
     $sbase["diycode"]=fmvalue($sbase["tablename"],"","0","",tostring(anyvalue($strst,"diycode",0)),0,$arraydata);
     $sbase["headx"]=fmvalue($sbase["tablename"],"","0","",tostring(anyvalue($strst,"headx",0)),0,$arraydata);
     $sbase["diytop"]=fmvalue($sbase["tablename"],"","0","",tostring(anyvalue($strst,"diytop",0)),0,$arraydata);
     $sbase["diybottom"]=fmvalue($sbase["tablename"],"","0","",tostring(anyvalue($strst,"diybottom",0)),0,$arraydata);
     $sbase["searchdemo"]=getcodedemo("searchdemo",qian($caseid,"."),hou($caseid,"."));
     $tablehtml=maketable($ccs["srd"],$tablehd,$pghtml,$fmhtmlx,$sbase);
     $fmextscript=combinestr3("<script>",$fmextscript,"</script>");
     $itab["stylex"]=$_POST[$shortid."_stylex"];
     $itab["scriptx"]=combinestr2($_POST[$shortid."_scriptx"],$fmextscript);
     $itab["cssfiles"]=$_POST[$shortid."_cssfiles"];
     $itab["jsfiles"]=$_POST[$shortid."_jsfiles"]; 
     $itab["title"]=$sbase["shorttitle"];           
     $itab["tablename"]=$sbase["tablename"];
     $itab["showkeys"]=$sbase["showkeys"];
     $itab["headbody"]=combinestr2($tablehd,$fmhtmlx);
     $itab["pagexyz"]=$pghtml;
     $itab["allsearch"]=$allsc;
     $itab["xkey"]=$xk;
     $itab["xval"]=$xv;
     $itab["pagenum"]=$pgnum;
     $itab["page"]=$page;     
     $itab["sql"]=$sqlx;
     $itab["cdtstr"]=$cdtstr;
     $itab["tabcode"]=$tablehtml;      
     $itab["rank"]=$onlyrow;
     $itab["demo"]=$csurd;
     $itab["units"]=$fmch;
     $itab["text"]=$dtrst;
     }else{
     $itab["stylex"]=$_POST[$shortid."_stylex"];
     $itab["scriptx"]=$_POST[$shortid."_scriptx"];
     $itab["cssfiles"]=$_POST[$shortid."_cssfiles"];
     $itab["jsfiles"]=$_POST[$shortid."_jsfiles"]; 
     $itab["title"]=$sbase["shorttitle"];           
     $itab["tablename"]=$sbase["tablename"];
     $itab["showkeys"]=$sbase["showkeys"];
     $itab["headbody"]="";
     $itab["pagexyz"]="";
     $itab["allsearch"]=$allsc;
     $itab["xkey"]=$xk;
     $itab["xval"]=$xv;
     $itab["pagenum"]=$pgnum;
     $itab["page"]=$page;     
     $itab["sql"]=$sqlx;
     $itab["cdtstr"]=$cdtstr;
     $itab["tabcode"]="";      
     $itab["rank"]="";
     $itab["demo"]="";
     $itab["units"]="";
     $itab["text"]="";
     };//totrcd>0
     return $itab;
    }else{//caseid 必须有模板ID才行，不然啥也没有
     return $itab;
    };
   }else{
     //shortid!=""  
     return $itab;
   };  
 }
?>