<?php
function getuinfo($uid,$uinfo=array()){
    $urst=SX("select realname,headpic,pid,business,posids,comid,grpcid,depart,dpmore,subpho,vxpic,email,mobile,vxuid,nickname,croom from coode_userlist where userid='".$uid."'");
    if (countresult($urst)>0){
        $uinfo["realname"]=anyvalue($urst,"realname",0);
        $uinfo["headpic"]=anyvalue($urst,"headpic",0);
        $uinfo["pid"]=anyvalue($urst,"pid",0);
        $uinfo["business"]=anyvalue($urst,"business",0);
        $uinfo["posids"]=anyvalue($urst,"posids",0);
        $uinfo["comid"]=anyvalue($urst,"comid",0);
        $uinfo["grpcid"]=anyvalue($urst,"grpcid",0);
        $uinfo["depart"]=anyvalue($urst,"depart",0);
        $uinfo["dpmore"]=anyvalue($urst,"dpmore",0);
        $uinfo["subpho"]=anyvalue($urst,"subpho",0);
        $uinfo["vxpic"]=anyvalue($urst,"vxpic",0);
        $uinfo["email"]=anyvalue($urst,"email",0);
        $uinfo["mobile"]=anyvalue($urst,"mobile",0);
        $uinfo["vxuid"]=anyvalue($urst,"vxuid",0);
        $uinfo["croom"]=anyvalue($urst,"croom",0);
        $uinfo["nickname"]=anyvalue($urst,"nickname",0);
        $uinfo["uid"]=$uid;
    }else{
        $uinfo["uid"]=$uid;
    }
    return $uinfo;
}
function newrole($rcode,$rtitle,$wid,$crt){
  return UV("coode_role@roleid=$rcode&roletitle=$rtitle&wrdid=$wid&CRTOR=$crt");
}
function newuser($uid,$pass,$cid,$rnm,$rids,$posids,$crt){
 $enpass=makepass($uid,$pass);
 return UV("coode_userlist@userid=$uid&passwd=$enpass&realname=$rnm&posids=$posids&wrdid=$cid&roleids=$rids&CRTOR=$crt");
}

?>