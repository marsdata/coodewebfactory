kbase=new Array();
kbase["COLUMN"]=new Array();
kbase["COLUMN"]["SEQUENCE"]="+";
kbase["COLUMN"]["COLUMN_TPLEN"]="0";
kbase["COLUMN"]["READONLY"]="";
versioninfo="updatetime:2023-03-30 14:38:42";