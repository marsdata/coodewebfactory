kbase=new Array();
kbase["COLUMN"]=new Array();
kbase["COLUMN"]["SEQUENCE"]="+";
kbase["COLUMN"]["COLUMN_TPLEN"]="0";
kbase["COLUMN"]["READONLY"]="";
versioninfo="updatetime:2024-06-28 10:42:17";