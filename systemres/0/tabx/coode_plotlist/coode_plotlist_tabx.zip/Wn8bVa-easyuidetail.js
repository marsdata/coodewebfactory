














obj={        edit:function (id) {
                var ID;
                $("#addBox").dialog({
                        closed:false
                })
               $.ajax({
                       url:'/DNA/EXF/anyfuns.php?fid=easyuidetail&stid=Wn8bVa&id='+id+'&dbnm='+dftval(GetRequest().dbnm,"")+'&laydb='+dftval(GetRequest().laydb,""),
                       type:'post',
                       dataType:'json',
                       success:function (res) {
                               if(res){
                                       var data=res.rows;
                                       $.each(data,function (index) {
                                               ID=intval(data[index].id);
                                               if(id==ID){                                                       
                                                              $("#p_SNO").val(data[index].id);$("#p_layoutid").val(data[index].layoutid);$("#p_levelcount").val(data[index].levelcount);$("#p_totpoint").val(data[index].totpoint);$("#p_markname").val(data[index].markname);$("#p_formcode").val(data[index].formcode);$("#p_plotmark").val(data[index].plotmark);$("#p_CRTM").val(data[index].CRTM);$("#p_CRTOR").val(data[index].CRTOR);$("#p_OLMK").val(data[index].OLMK);$("#p_PTOF").val(data[index].PTOF);$("#p_plotcls").val(data[index].plotcls);$("#p_sysid").val(data[index].sysid);$("#p_appid").val(data[index].appid);$("#p_withfont").val(data[index].withfont);                                                       
                                               }
                                       })
                               }
                       },
                       error:function () {
                               $.messager.show({
                                       title:'提示',
                                       msg:'更新失败'
                               })
                       }
               })
        },
       sum:function () {
                $("#addform").form('submit',{
                        url:"/DNA/EXF/anyfuns.php?fid=easyuircv&stid=Wn8bVa&id="+dftval(GetRequest().SNO,"0")+"&dbnm="+dftval(GetRequest().dbnm,"")+'&laydb='+dftval(GetRequest().laydb,""),
                        onSubmit:function () {
                                return $(this).form('validate')
                        },
                        success:function (data) {
                                layoutid0=$("#p_layoutid").val();levelcount0=$("#p_levelcount").val();totpoint0=$("#p_totpoint").val();markname0=$("#p_markname").val();formcode0=$("#p_formcode").val();plotmark0=$("#p_plotmark").val();CRTM0=$("#p_CRTM").val();CRTOR0=$("#p_CRTOR").val();OLMK0=$("#p_OLMK").val();PTOF0=$("#p_PTOF").val();plotcls0=$("#p_plotcls").val();sysid0=$("#p_sysid").val();appid0=$("#p_appid").val();withfont0=$("#p_withfont").val();
                                $("#table").datagrid('insertRow',{
                                        index:0,
                                        row: {
                                                layoutid:layoutid0,levelcount:levelcount0,totpoint:totpoint0,markname:markname0,formcode:formcode0,plotmark:plotmark0,CRTM:CRTM0,CRTOR:CRTOR0,OLMK:OLMK0,PTOF:PTOF0,plotcls:plotcls0,sysid:sysid0,appid:appid0,withfont:withfont0,
                                        }
                                });
                                $("#addBox").dialog({
                                        closed: true
                                });
                                $.messager.show({
                                        title:'提示',
                                        msg:'信息保存成功'
                                });
                                window.location.reload();
                        }
                })
        },
        delOne:function (id) {                
                $.messager.confirm('提示信息','是否删除所选择记录',function (flg) {
                        if(flg){
                                $.ajax({
                                        type:'post',
                                        url:'/DNA/EXF/anyfuns.php?fid=easyuidel&tabname=coode_plotlist&dbnm='+dftval(GetRequest().dbnm,"")+'&laydb='+dftval(GetRequest().laydb,""),
                                        data:{
                                                ID:id
                                        },
                                        beforesend:function () {
                                                $("#table").datagrid('loading');
                                        },
                                        success:function (data) {
                                                if(data){
                                                        $("#table").datagrid("loaded");
                                                        $("#table").datagrid("load");
                                                        $("#table").datagrid("unselectRow");
                                                        $.messager.show({
                                                                title:'提示信息',
                                                                msg:"信息删除成功"
                                                        })
                                                }
                                                else{
                                                        $.messager.show({
                                                                title:'警示信息',
                                                                msg:"信息删除失败"
                                                        })
                                                }
                                        }
                                })
                        }
                })
        }
}
prehref=location.href;
        if (prehref.indexOf("pnum:")>0){
         pn=intval(qian(hou(prehref,"pnum:"),"-"));
        }else if (prehref.indexOf("pnum=")>0){
         pn=intval(qian(hou(prehref,"pnum="),"&"));
        }else{
         pn=10;
        }
        $("#table").datagrid({
        title:"数据列表",
        iconCls:"icon-left02",
        url:'/DNA/EXF/anyfuns.php?fid=easyuilist&stid=Wn8bVa&dbnm='+dftval(GetRequest().dbnm,"")+'&laydb='+dftval(GetRequest().laydb,""),
        fitColumns:true,
        striped:true,
        pagination:true,
        pageSize:pn,
        width:'100%',
        rownumbers:true,
        pageList:[pn,pn*2],
        pageNumber:1,
        nowrap:true,
        height:'auto',
        sortName:'id',
        checkOnSelect:false,
        sortOrder:'asc',
        toolbar: '#tabelBut',
        columns:[[
                {
                        checkbox:true,
                        field:'no',
                        width:100,
                        align:'center'
                },
                {field:'id',title:'编号',width:100,align:'center'},{field:'layoutid',title:'渲染ID',width:100,align:'center'},{field:'levelcount',title:'层数',width:100,align:'center'},{field:'totpoint',title:'首层数量',width:100,align:'center'},{field:'markname',title:'标记名称',width:100,align:'center'},{field:'formcode',title:'表单代码',width:100,align:'center'},{field:'plotmark',title:'节点标记',width:100,align:'center'},{field:'CRTM',title:'创建时刻',width:100,align:'center'},{field:'CRTOR',title:'创建人',width:100,align:'center'},{field:'OLMK',title:'唯一标记',width:100,align:'center'},{field:'PTOF',title:'编辑选项',width:100,align:'center'},{field:'plotcls',title:'节点分类',width:100,align:'center'},{field:'sysid',title:'系统ID',width:100,align:'center'},{field:'appid',title:'应用id',width:100,align:'center'},{field:'withfont',title:'字体文件地址',width:100,align:'center'},            
                {
                        field:"opr",
                        title:'操作',
                        width:100,
                        align:'center',
                        formatter:function (val,row) {
                                e = '<a  id="add" data-id="98" class=" operA"  onclick="goitem(\'' + row.id + '\')">编辑</a> ';                                
                                d = '<a  id="add" data-id="98" class=" operA01"  onclick="obj.delOne(\'' + row.id + '\')">删除</a> ';
                                return e+d;
                        }
                }
        ]]
})
$("#addBox").dialog({
        title:"信息内容",
        width:500,
        height:300,
        closed: true,
        modal:true,
        shadow:true
})
$("#lookTail").dialog({
        title:"信息内容",
        width:650,
        height:410,
        closed: true,
        modal:true,
        shadow:true
})