obj={        edit:function (id) {
                var ID;
                $("#addBox").dialog({
                        closed:false
                })
               $.ajax({
                       url:'/DNA/EXF/anyfuns.php?fid=easyuidetail&stid=1fzJeo&id='+id,
                       type:'post',
                       dataType:'json',
                       success:function (res) {
                               if(res){
                                       var data=res.rows;
                                       $.each(data,function (index) {
                                               ID=intval(data[index].id);
                                               if(id==ID){                                                       
                                                              $("#p_SNO").val(data[index].id);$("#p_svgmark").val(data[index].svgmark);$("#p_svgtitle").val(data[index].svgtitle);$("#p_svgindex").val(data[index].svgindex);$("#p_OLMK").val(data[index].OLMK);                                                       
                                               }
                                       })
                               }
                       },
                       error:function () {
                               $.messager.show({
                                       title:'提示',
                                       msg:'更新失败'
                               })
                       }
               })
        },
        delOne:function (id) {                
                $.messager.confirm('提示信息','是否删除所选择记录',function (flg) {
                        if(flg){
                                $.ajax({
                                        type:'post',
                                        url:'/DNA/EXF/anyfuns.php?fid=easyuidel&tabname=coode_tinyimg',
                                        data:{
                                                ID:id
                                        },
                                        beforesend:function () {
                                                $("#table").datagrid('loading');
                                        },
                                        success:function (data) {
                                                if(data){
                                                        $("#table").datagrid("loaded");
                                                        $("#table").datagrid("load");
                                                        $("#table").datagrid("unselectRow");
                                                        $.messager.show({
                                                                title:'提示信息',
                                                                msg:"信息删除成功"
                                                        })
                                                }
                                                else{
                                                        $.messager.show({
                                                                title:'警示信息',
                                                                msg:"信息删除失败"
                                                        })
                                                }
                                        }
                                })
                        }
                })
        }
}
prehref=location.href;
        if (prehref.indexOf("pnum:")>0){
         pn=intval(qian(hou(prehref,"pnum:"),"-"));
        }else if (prehref.indexOf("pnum=")>0){
         pn=intval(qian(hou(prehref,"pnum="),"&"));
        }else{
         pn=10;
        }
        $("#table").datagrid({
        title:"数据列表",
        iconCls:"icon-left02",
        url:'/DNA/EXF/anyfuns.php?fid=easyuilist&stid=1fzJeo',
        fitColumns:true,
        striped:true,
        pagination:true,
        pageSize:pn,
        width:'100%',
        rownumbers:true,
        pageList:[pn,pn*2],
        pageNumber:1,
        nowrap:true,
        height:'auto',
        sortName:'id',
        checkOnSelect:false,
        sortOrder:'asc',
        toolbar: '#tabelBut',
        columns:[[
                {
                        checkbox:true,
                        field:'no',
                        width:100,
                        align:'center'
                },
                {field:'id',title:'编号',width:100,align:'center'},{field:'svgmark',title:'小图标记',width:100,align:'center'},{field:'svgtitle',title:'小图标题',width:100,align:'center'},{field:'svgindex',title:'小图索引',width:100,align:'center'},{field:'OLMK',title:'唯一标记',width:100,align:'center'},            
                {
                        field:"opr",
                        title:'操作',
                        width:100,
                        align:'center',
                        formatter:function (val,row) {
                                e = '<a  id="add" data-id="98" class=" operA"  onclick="obj.edit(\'' + row.id + '\')">编辑</a> ';                                
                                d = '<a  id="add" data-id="98" class=" operA01"  onclick="obj.delOne(\'' + row.id + '\')">删除</a> ';
                                return e+d;
                        }
                }
        ]]
})
$("#addBox").dialog({
        title:"信息内容",
        width:500,
        height:300,
        closed: true,
        modal:true,
        shadow:true
})
$("#lookTail").dialog({
        title:"信息内容",
        width:650,
        height:410,
        closed: true,
        modal:true,
        shadow:true
})