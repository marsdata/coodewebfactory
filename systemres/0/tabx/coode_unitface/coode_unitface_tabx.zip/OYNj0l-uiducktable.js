function remotedata(dataurl){
 uiduck.setOptions({
 templateId: "table",
 url: { url: dataurl, type: "POST", key: "sublives" },
 loading: { icon: "uiduck-loading-6" },
 page: true,
 pageOptions: { limit: 5, limits: ["5", "10", "15", "20", "25"] },
 fieldOptions: [
 {
 index: true,
 title: "序号"
 },
 {
 key: "SNO",
 title: "数据编号"
 },{
 key: "sysid",
 title: "系统编码"
 },{
 key: "headx",
 title: "头像"
 },{
 key: "remotestock",
 title: "远程存储"
 },{
 key: "stockplace",
 title: "本地存储"
 },{
 key: "OLMK",
 title: "数据唯标"
 },{
 key: "OPRT",
 title: "操作"
 },{
 key: "faceid",
 title: "样式编码"
 },{
 key: "facetitle",
 title: "样式标题"
 },{
 key: "dumark",
 title: "模板编码"
 },{
 key: "dutitle",
 title: "模板标题"
 }]
 });
 //setTimeout("hidemoretab()", 3000 );
 } function changertheme(dataurl,tmnm) {
 $("#ud-top").css("display", "none");
 if (tmnm==""){
  var arr = ["uiduck-table", "uiduck-dark", "uiduck-led", "uiduck-pink", "uiduck-coffee", "uiduck-blue", "uiduck-purple", "uiduck-white"];
  var theme = arr[Math.floor((Math.random() * arr.length))];
 }else{
  var theme = tmnm;
 }
 uiduck.setOptions({
 templateId: "table",
 url: { url: dataurl, type: "POST", key: "sublives" },
 style: { tbClass: theme },
 rightTool: { templateId: "barDemo", title: "数据操作", width: "100px" },
 loading: { icon: "uiduck-loading-6" },
 page: true,
 fieldOptions: [
 {
 index: true,
 title: "序号"
 },
 {
 key: "SNO",
 title: "数据编号"
 },{
 key: "sysid",
 title: "系统编码"
 },{
 key: "headx",
 title: "头像"
 },{
 key: "remotestock",
 title: "远程存储"
 },{
 key: "stockplace",
 title: "本地存储"
 },{
 key: "OLMK",
 title: "数据唯标"
 },{
 key: "OPRT",
 title: "操作"
 },{
 key: "faceid",
 title: "样式编码"
 },{
 key: "facetitle",
 title: "样式标题"
 },{
 key: "dumark",
 title: "模板编码"
 },{
 key: "dutitle",
 title: "模板标题"
 }]
 });
  //setTimeout("hidemoretab()", 3000 );
} function changeltheme(datax,tmnm) {
 $("#ud-top").css("display", "none");
 if (tmnm==""){
  var arr = ["uiduck-table", "uiduck-dark", "uiduck-led", "uiduck-pink", "uiduck-coffee", "uiduck-blue", "uiduck-purple", "uiduck-white"];
  var theme = arr[Math.floor((Math.random() * arr.length))];
 }else{
  var theme = tmnm;
 }
      $("#ud-top").css("display", "none");
      uiduck.setOptions({
         templateId: "table",
         style: { tbClass: theme },
         topBar: { templateId: "search", kwLight: true },
         rightTool: { templateId: "barDemo", title: "数据操作", width: "100px" },
         loading: { icon: "uiduck-loading-6", time: 1000 },
         page: true,
         fieldOptions: [
 {
 index: true,
 title: "序号"
 },
 {
 key: "SNO",
 title: "数据编号"
 },{
 key: "sysid",
 title: "系统编码"
 },{
 key: "headx",
 title: "头像"
 },{
 key: "remotestock",
 title: "远程存储"
 },{
 key: "stockplace",
 title: "本地存储"
 },{
 key: "OLMK",
 title: "数据唯标"
 },{
 key: "OPRT",
 title: "操作"
 },{
 key: "faceid",
 title: "样式编码"
 },{
 key: "facetitle",
 title: "样式标题"
 },{
 key: "dumark",
 title: "模板编码"
 },{
 key: "dutitle",
 title: "模板标题"
 }]
 });
  var data=datax;
  uiduck.setData(data, false);
  //setTimeout("hidemoretab()", 3000 );
} function localdata(datax) {
      $("#ud-top").css("display", "none");
      uiduck.setOptions({
         templateId: "table",
         style: { tbClass: "uiduck-table" },
         topBar: { templateId: "search", kwLight: true },
         rightTool: { templateId: "barDemo", title: "操作", width: "100px" },
         loading: { icon: "uiduck-loading-6", time: 1000 },
         page: true,
         fieldOptions: [
 {
 index: true,
 title: "序号"
 },
 {
 key: "SNO",
 title: "数据编号"
 },{
 key: "sysid",
 title: "系统编码"
 },{
 key: "headx",
 title: "头像"
 },{
 key: "remotestock",
 title: "远程存储"
 },{
 key: "stockplace",
 title: "本地存储"
 },{
 key: "OLMK",
 title: "数据唯标"
 },{
 key: "OPRT",
 title: "操作"
 },{
 key: "faceid",
 title: "样式编码"
 },{
 key: "facetitle",
 title: "样式标题"
 },{
 key: "dumark",
 title: "模板编码"
 },{
 key: "dutitle",
 title: "模板标题"
 }]
 });
      var data=datax;
      uiduck.setData(data, false);
   }sd=shortdata($("#table").attr("shortid"),"","","");
 x=localdata(sd.vls);
 setTimeout("hidemoretab()", 3000 );