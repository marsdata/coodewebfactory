ccode=new Array();
ccode["chtml"]="";
ccode["varchar"]="[thisvalue]";
ccode["srd"]="[diytop][searchdemo]{div name=\"tabdiv\" style=\"[scroll];margin-left:5%;width:90%;height:2000px;padding:0px\"}{form name=\"tabform\"  pssno=\"[pssno]\" pskey=\"[pskey]\" pstitle=\"[pstitle]\" pshead=\"[pshead]\" class=\"layui-form\" onsubmit=\"return changesmt();\"  action=\"#\"}{table  name=\"tabunit\" shortid=\"[shortid]\" class=\"layui-table\"  style=\"TAB_STL\"  tbname=\"[tabnm]\" tbkies=\"[tabkeys]\"   totrcd=\"[totrcd]\"  pnum=\"[pnum]\" }[tbheadbody]{/table}{/form}{/div}{div id=\"pageskin\" }[tabpage]{/div}[diybottom]";
ccode["tabdemo"]="{table  name=\"tabunit\" class=\"layui-table\"  style=\"TAB_STL\"  tbname=\"[tabnm]\" tbkies=\"[tabkeys]\"   totrcd=\"[totrcd]\"  pnum=\"[pnum]\" }[tbheadbody]{/table}";
ccode["text"]="[thisvalue]";
ccode["richtext"]="";
ccode["code"]="";
ccode["select"]="function mkaselect($colname,$snox,$clstxt,$acthtm,$thusvalue,$arraydata,jsondata,$ti){  $clstxt=tostring($clstxt);  if ($clstxt!=\"\"){      if (strpos($clstxt,\"key-\")==1){          $hk=qian(hou($clstxt,\"key-\"),\"]\");          $clstxt=tostring($arraydata[$hk][$ti]);      }else{          if (strpos($clstxt,\"key\")==1 ){              kclstxtx=\"\";            if ($sresult[$colname+\"clstxt\"][$ti].indexOf(\"|\")<=0){               eval(\"kclstxtx=jsondata.md5txt.\"+$arraydata[$colname+\"clstxt\"][$ti]+\";\");               $clstxt=tostring(kclstxtx);            }else{               $clstxt=$sresult[$colname+\"clstxt\"][$ti];               }                               }else{                        $clstxt=$clstxt;         };      };          $fmselect=formselect(qian($clstxt,\"|\"),hou($clstxt,\"|\"),$thusvalue,\"p_\"+$colname+$snox,\"\",$acthtm);    return $fmselect;  }else{   return \"\";  }}";
function mkaselect($colname,$snox,$clstxt,$acthtm,$thusvalue,$arraydata,jsondata,$ti){
  $clstxt=tostring($clstxt);
  if ($clstxt!=""){
      if (strpos($clstxt,"key-")==1){
          $hk=qian(hou($clstxt,"key-"),"]");
          $clstxt=tostring($arraydata[$hk][$ti]);
      }else{
          if (strpos($clstxt,"key")==1 ){ 
             kclstxtx="";
            if ($sresult[$colname+"clstxt"][$ti].indexOf("|")<=0){
               eval("kclstxtx=jsondata.md5txt."+$arraydata[$colname+"clstxt"][$ti]+";");
               $clstxt=tostring(kclstxtx);
            }else{
               $clstxt=$sresult[$colname+"clstxt"][$ti];   
            }                     
          }else{            
            $clstxt=$clstxt;
         };
      };      
    $fmselect=formselect(qian($clstxt,"|"),hou($clstxt,"|"),$thusvalue,"p_"+$colname+$snox,"",$acthtm);
    return $fmselect;
  }else{
   return "";
  }
}
ccode["multiselect"]="function mkbselect($colname,$snox,$clstxt,$thusvalue,$arraydata,jsondata,$ti){$clstxt=tostring($clstxt);  if ($clstxt!=\"\"){      $newonex=tostring($clstxt);      if (strpos($newonex,\"key-\")==1){          $hk=qian(hou($newonex,\"key-\"),\"]\");          $newonex=tostring($arraydata[$hk][$ti]);      }else{          if (strpos($newonex,\"key\")==1 ){              kclstxtx=\"\";            if ($sresult[$colname+\"clstxt\"][$ti].indexOf(\"|\")<=0){               eval(\"kclstxtx=jsondata.md5txt.\"+$arraydata[$colname+\"clstxt\"][$ti]+\";\");               $newonex=tostring(kclstxtx);            }else{               $newonex=$sresult[$colname+\"clstxt\"][$ti];               }                               };      };    $inputdemo=\"<input type='hidden' id='p_[key0]' value='\"+$thusvalue+\"'>\";    $fmselect=formselectx(qian($newonex,\"|\"),hou($newonex,\"|\"),$thusvalue,\"p_\"+$colname+$snox,\"p_\"+$colname+$snox,\"\");    return $inputdemo+$fmselect;  }else{   return \"\";  }}";
function mkbselect($colname,$snox,$clstxt,$thusvalue,$arraydata,jsondata,$ti){
$clstxt=tostring($clstxt);
  if ($clstxt!=""){
      $newonex=tostring($clstxt);
      if (strpos($newonex,"key-")==1){
          $hk=qian(hou($newonex,"key-"),"]");
          $newonex=tostring($arraydata[$hk][$ti]);
      }else{
          if (strpos($newonex,"key")==1 ){ 
             kclstxtx="";
            if ($sresult[$colname+"clstxt"][$ti].indexOf("|")<=0){
               eval("kclstxtx=jsondata.md5txt."+$arraydata[$colname+"clstxt"][$ti]+";");
               $newonex=tostring(kclstxtx);
            }else{
               $newonex=$sresult[$colname+"clstxt"][$ti];   
            }                     
          };
      };
    $inputdemo="<input type='hidden' id='p_[key0]' value='"+$thusvalue+"'>";
    $fmselect=formselectx(qian($newonex,"|"),hou($newonex,"|"),$thusvalue,"p_"+$colname+$snox,"p_"+$colname+$snox,"");
    return $inputdemo+$fmselect;
  }else{
   return "";
  }
}
ccode["date"]="{input id=\"p_[key][thissno]\" class=\"demo-input\"  value=\"[thisvalue]\"}";
ccode["datetime"]="{input id=\"p_[key][thissno]\" class=\"demo-input\"  value=\"[thisvalue]\"}";
ccode["int"]="[thisvalue]";
ccode["tinyint"]="";
ccode["decimal1"]="";
ccode["decimal2"]="";
ccode["decimal3"]="";
ccode["decimal4"]="";
ccode["imagex"]="";
ccode["images"]="";
ccode["filex"]="function showonfile($colname,$snox,$ktitle,$dtype,$clstxt,$thusvalue){      $rtnstr=combinestr2(\"<a href='\",$thisvalue);     $rtnstr=combinestr2($rtnstr,\"' target='about_blank'>下载</a>\");     return $rtnstr;  }";
function showonfile($colname,$snox,$ktitle,$dtype,$clstxt,$thusvalue){ 
     $rtnstr=combinestr2("<a href='",$thisvalue);
     $rtnstr=combinestr2($rtnstr,"' target='about_blank'>下载</a>");
     return $rtnstr;  
}
ccode["files"]="";
ccode["check"]="[thisvalue]";
ccode["multicheck"]="";
ccode["datasnoth"]="";
ccode["oprtbtnth"]="";
ccode["varcharth"]="";
ccode["textth"]="";
ccode["richtextth"]="";
ccode["codeth"]="";
ccode["selectth"]="";
ccode["multiselectth"]="";
ccode["dateth"]="";
ccode["datetimeth"]="";
ccode["intth"]="";
ccode["tinyintth"]="";
ccode["decimal1th"]="";
ccode["decimal2th"]="";
ccode["decimal3th"]="";
ccode["decimal4th"]="";
ccode["imagexth"]="";
ccode["imagesth"]="";
ccode["filexth"]="";
ccode["filesth"]="";
ccode["checkth"]="";
ccode["multicheckth"]="";
ccode["datasnotd"]="";
ccode["oprtbtntd"]="";
ccode["varchartd"]="";
ccode["texttd"]="";
ccode["richtexttd"]="";
ccode["codetd"]="";
ccode["selecttd"]="";
ccode["multiselecttd"]="";
ccode["datetd"]="";
ccode["datetimetd"]="";
ccode["inttd"]="";
ccode["tinyinttd"]="";
ccode["decimal1td"]="";
ccode["decimal2td"]="";
ccode["decimal3td"]="";
ccode["decimal4td"]="";
ccode["imagextd"]="";
ccode["imagestd"]="";
ccode["filextd"]="";
ccode["filestd"]="";
ccode["checktd"]="";
ccode["multichecktd"]="";
ccode["oprt"]="function oprteval(){     $(\"form[name='tabform']\").html(bktable);     $('.loadingBox').attr('data-show', 0);    newtdlisten();    listenclsduo();     layrender();     layui.use(['form'], function(){     form =layui.form;     form.on('select(brickType)', function(data){      ocg=$(this).parent().parent().prev().attr(\"onchange\");     nv=$(this).attr(\"lay-value\");     if (ocg!=undefined  &&  nv!=undefined){      if (ocg!=\"\"){        ocg=ocg.replace(/\<thisnewvalue\>/g,nv);        eval(ocg);        form.render();       };     };   });  });     a=$(\"th\");    b=$(\"td\");    for (z=0;z<a.length;z++){     $(a[z]).width($(b[z]).width());    }  }";
function oprteval(){
     $("form[name='tabform']").html(bktable);
     $('.loadingBox').attr('data-show', 0);
    newtdlisten();
    listenclsduo();
     layrender();
     layui.use(['form'], function(){
     form =layui.form;
     form.on('select(brickType)', function(data){ 
     ocg=$(this).parent().parent().prev().attr("onchange");
     nv=$(this).attr("lay-value");
     if (ocg!=undefined  &&  nv!=undefined){
      if (ocg!=""){
        ocg=ocg.replace(/\<thisnewvalue\>/g,nv);
        eval(ocg);
        form.render(); 
      };
     };
   });
  }); 
    a=$("th");
    b=$("td");
    for (z=0;z<a.length;z++){
     $(a[z]).width($(b[z]).width());
    }
  }
ccode["tabtr"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
ccode["tabtd"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
ccode["tabhdtr"]="{tr}[inner]{/tr}";
ccode["tabhdtd"]="{th id=\"tabhd[key]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" rdol=\"[readonly]\" style=\"[dspl]\"}[inner]{/th}";
ccode["content"]="{div class=\"oldTable\" style=\"overflow: auto; height: auto; magin-top: -8px;\" id=\"htmllist\"}[shortdata]{/div}[diyright][controler]";
ccode["pgsrd"]="{div id=\"customPages\" class=\"customPages\"}{a href=\"javascript:void(0)\"  onclick=\"window.open(location.href.replace('&refresh=',''))\"}{img id=\"tcg\" src=\"/localxres/iconsetx/pagecontrol/移动.svg\" style=\"width:20px;height:20px;\"}{/a}{a href=\"javascript:void(0)\" onclick=\"window.open(location.href.replace('&refresh=','')+'&refresh=1')\"}{img src=\"/localxres/iconsetx/pagecontrol/qj37.svg\" style=\"width:20px;height:20px;\"}{/a}{span class=\"layui-laypage-count\"}共[totrst]条{/span}{span class=\"layui-laypage-count\"}共[totpage]页{/span}{span class=\"layui-laypage-limits\"}[pgselect]{/span}{span class=\"layui-laypage-limits\"}[pgnum]{/span}{div class=\"layui-box layui-laypage layui-laypage-default\" id=\"layui-laypage-1\"}{a href=\"javascript:void(0);\" class=\"layui-laypage-prev\"  onclick=\"tospage([prepg])\"}上一页{/a}{a href=\"javascript:void(0);\" class=\"layui-laypage-first\" onclick=\"tospage(1)\"}首页{/a}  [pageinner]{a href=\"javascript:void(0);\"  class=\"layui-laypage-last\" onclick=\"tospage([totye])\"}尾页{/a}{a href=\"javascript:void(0);\" class=\"layui-laypage-next\" onclick=\"tospage([nxtpg])\"}下一页{/a}{a class=\"layui-btn\" id=\"tbnm\" tbnm=\"coode_keydetailx\" style=\";\"  onclick=\"plsc('','[tabname]');\"}批量删除{/a}{a class=\"layui-btn\"  onclick=\"quanxuan();\"}全选{/a}{/div}{/div}";
ccode["pgin"]="{span class=\"layui-laypage-curr\"}{em class=\"layui-laypage-em\"}{/em}{em}[pgtt]{/em}{/span}";
ccode["pgout"]="{a href=\"javascript:void(0);\" onclick=\"tospage([page])\"}[pgtt]{/a}";
ccode["searchdemo"]="{div class=\"loadingBox\" data-show=\"1\"}{div class=\"loadingMain\"}{div class=\"loadingCenter\"}{div class=\"loadingIcon\"}{span}{/span}{/div}{p}信息加载中,请等待{/p}{/div}{/div}{/div}  {div class=\"pagestorage\" style=\"display:none;\"}{div id=\"[shortid]storage\"}{/div}{/div}  {div class=\"console\"}        {div class=\"layui-form-item\"  style=\"margin-left:5px;margin-top:15px\"}        {div class=\"layui-input-block\" }         {span style=\"left:5px;\"}{button class=\"layui-btn\" lay-submit lay-filter=\"submitBut\" onclick=\"allsearch('[shortid]');\"}检索{/button}{a class=\"layui-btn\" style=\"[additemxdspl];\" onclick=\"update('[addpage]',0)\"}新增{/a}{a class=\"layui-btn\" onclick=\"deliv('[shortid]',0)\"}打印页面{/a}{a class=\"layui-btn\" onclick=\"downv('[shortid]',0)\"}下载数据{/a}{span id=\"xzdz\"}{/span}         {span style=\"margin-left:0px\"} {div class=\"layui-input-inline\" style=\"margin-left:50px\" }         {input type=\"text\" id=\"searchkey\" name=\"searchkey\" required lay-verify=\"required\" placeholder=\"输入关键词\" style=\"margin-top:5px\" autocomplete=\"off\" class=\"layui-input\"}        {/div}{href=\"javascript:void(0);\" onclick=\"localitem()\"}{img src=\"/ORG/BRAIN/images/icon/system/wdwp.svg\" style=\"width:30px;height:30px;\"}{/a}{a href=\"javascript:void(0);\" onclick=\"window.location.reload()\"}{img src=\"/ORG/BRAIN/images/icon/system/renew.svg\" style=\"width:40px;height:40px;\"}{/a}{a href=\"javascript:void(0);\" onclick=\"window.history.go(-1);\"}{img src=\"/ORG/BRAIN/images/icon/system/return.svg\" style=\"width:40px;height:40px;\"}{/a}{/span}    {/div}     {/div}";
ccode["chtmlSCRIPT"]="";
ccode["varcharSCRIPT"]="";
ccode["contentSCRIPT"]="";
ccode["searchdemoSCRIPT"]="";
ccode["srdSCRIPT"]="";
ccode["textSCRIPT"]="";
ccode["richtextSCRIPT"]="";
ccode["codeSCRIPT"]="";
ccode["selectSCRIPT"]="";
ccode["multiselectSCRIPT"]="";
ccode["dateSCRIPT"]="";
ccode["datetimeSCRIPT"]="";
ccode["intSCRIPT"]="";
ccode["tinyintSCRIPT"]="";
ccode["decimal1SCRIPT"]="";
ccode["decimal2SCRIPT"]="";
ccode["decimal3SCRIPT"]="";
ccode["decimal4SCRIPT"]="";
ccode["imagexSCRIPT"]="";
ccode["imagesSCRIPT"]="";
ccode["pgsrdSCRIPT"]="";
ccode["pginSCRIPT"]="";
ccode["pgoutSCRIPT"]="";
ccode["filexSCRIPT"]="";
ccode["filesSCRIPT"]="";
ccode["checkSCRIPT"]="";
ccode["multicheckSCRIPT"]="";
ccode["tabtrSCRIPT"]="";
ccode["tabtdSCRIPT"]="";
ccode["tabhdtrSCRIPT"]="";
ccode["tabhdtdSCRIPT"]="";
ccode["oprtSCRIPT"]="";
ccode["chtmlFUNCTION"]="";
ccode["varcharFUNCTION"]="";
ccode["textFUNCTION"]="";
ccode["richtextFUNCTION"]="";
ccode["codeFUNCTION"]="";
ccode["selectFUNCTION"]="";
ccode["multiselectFUNCTION"]="$(\".p_[key][thissno]\").fSelect();";
ccode["dateFUNCTION"]="laydatex('p_[key][thissno]');";
ccode["datetimeFUNCTION"]="laydttmx('p_[key][thissno]');";
ccode["intFUNCTION"]="";
ccode["tinyintFUNCTION"]="";
ccode["decimal1FUNCTION"]="";
ccode["decimal2FUNCTION"]="";
ccode["decimal3FUNCTION"]="";
ccode["decimal4FUNCTION"]="";
ccode["imagexFUNCTION"]="";
ccode["imagesFUNCTION"]="";
ccode["pgsrdFUNCTION"]="";
ccode["pginFUNCTION"]="";
ccode["pgoutFUNCTION"]="";
ccode["filexFUNCTION"]="";
ccode["filesFUNCTION"]="";
ccode["checkFUNCTION"]="";
ccode["multicheckFUNCTION"]="";
ccode["oprtFUNCTION"]="";
ccode["contentFUNCTION"]="";
ccode["searchdemoFUNCTION"]="";
ccode["srdFUNCTION"]="";
