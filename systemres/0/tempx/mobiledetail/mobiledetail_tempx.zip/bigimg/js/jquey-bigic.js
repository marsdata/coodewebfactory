/**
 * jQuery Plugin bigic v1.0.0
/*
*/
(function ($) {
    $.fn.bigic = function () {

        /*
         * 鏋勯€犲嚱鏁� @Bigic
         * 瀹氫箟鍩虹鍙橀噺锛屽垵濮嬪寲瀵硅薄浜嬩欢
         */
        function Bigic($obj){
            this.$win = $(window);
            this.$obj = $obj;
            this.$popup,
            this.$img,
            this.nWinWid = 0;
            this.nWinHei = 0;
            this.nImgWid = 0;
            this.nImgHei = 0;
            this.nImgRate = 0;
            this.sImgStatus;
            this.sImgSrc,
            this.bMoveX = true,
            this.bMoveY = true;

            this.init();
        }

        /*
         * 鍒濆鍖� 缁戝畾鍩虹浜嬩欢
         */
        Bigic.prototype.init = function(){
            var oThis = this,
                timer = null;

            // 涓哄浘鐗囩粦瀹氱偣鍑讳簨浠�
            this.$obj.off('.bigic').on('click.bigic', function(){
                var sTagName = this.tagName.toLowerCase();
                if(sTagName == 'img'){
                    // 鏇存柊鍩虹鍙橀噺
                    oThis.sImgSrc = this.getAttribute('src');
                    oThis.sImgStatus = 'min';
                    // 鏄剧ず寮圭獥
                    oThis.show();
                }else{
                    alert('闈濱MG鏍囩');
                }
            });

            // 娴忚鍣ㄧ缉鏀�
            this.$win.off('.bigic').on('resize.bigic', function(){
                clearTimeout(timer);
                timer = setTimeout(function(){
                    oThis.zoom();
                }, 30);
            });
        }

        /*
         * 寮圭獥鍒濆鍖�
         */
        Bigic.prototype.show = function(){
            var oThis = this,
                oImg = new Image();

            oThis.popup();   // 鏄剧ず寮圭獥

            // 鍥剧墖鍔犺浇
            oImg.onload = function(){
                oThis.nImgWid = this.width;
                oThis.nImgHei = this.height;
                oThis.nImgRate = oThis.nImgWid/oThis.nImgHei;

                $('#LoadingBigic').remove();
                oThis.$popup.append('<img id="imgBigic" class="img-bigic" src="'+ oThis.sImgSrc +'" />');
                oThis.$img = $('#imgBigic');
                
                oThis.zoom();
            }
            oImg.src = oThis.sImgSrc;
        }

        /*
         * 寮圭獥鏄剧ず 鍙婄浉鍏虫帶浠朵簨浠剁粦瀹�
         */
        Bigic.prototype.popup = function(){
            var sHtml = '',
                oThis = this;
            // 鐢熸垚HTML 閫変腑DOM鑺傜偣
            sHtml += '<div id="popupBigic" class="popup-bigic" style="width:'+ this.nWinWid +'px;height:'+ this.nWinHei +'px;">' 
                  +     '<div class="option-bigic">'
                  +         '<span id="changeBigic" class="change-bigic min-bigic" state-bigic="min">鏀惧ぇ</span>'
                  +         '<span id="closeBigic" class="close-bigic">鍏抽棴</span>'
                  +     '</div>'
                  +     '<img id="LoadingBigic" class="loading-bigic" src="preloader.gif" />'
                  +  '</div>';
            $('body').append(sHtml);
            oThis.$popup = $('#popupBigic');
            
            // 浜嬩欢缁戝畾 - 鍏抽棴寮圭獥
            $('#closeBigic').off().on('click',function(){
                oThis.$popup.remove();
            });

            // 浜嬩欢缁戝畾 - 鍒囨崲灏哄
            $('#changeBigic').off().on('click',function(){
                if(!document.getElementById('imgBigic')) return;
                if($(this).hasClass('min-bigic')){
                    oThis.sImgStatus = 'max';
                    $(this).removeClass('min-bigic').addClass('max-bigic').html('缂╁皬');
                }else{
                    oThis.sImgStatus = 'min';
                    $(this).removeClass('max-bigic').addClass('min-bigic').html('鏀惧ぇ');;
                }
                oThis.zoom();
            });
        }

        /*
         * 鍥剧墖鏀惧ぇ缂╁皬鎺у埗鍑芥暟
         */
        Bigic.prototype.zoom = function(){
            var nWid = 0,cnHei = 0,
                nLeft = 0, nTop = 0,
                nMal = 0, nMat = 0;

            // 寮圭獥鏈墦寮€ 鎴� 闈瀒mg 杩斿洖
            if(!document.getElementById('popupBigic') || !this.nImgWid) return;

            this.nWinWid = this.$win.width();
            this.nWinHei = this.$win.height();
            this.bMoveX = true;
            this.bMoveY = true;

            // 鏄剧ず闅愯棌鏀惧ぇ缂╁皬鎸夐挳
            if(this.nImgWid > this.nWinWid || this.nImgHei > this.nWinHei){
                $('#changeBigic')[0].style.display = 'inline-block';
            }else{
                $('#changeBigic')[0].style.display = 'none';
            }

            if(this.sImgStatus == 'min'){
                nWid = this.nImgWid > this.nWinWid ? this.nWinWid : this.nImgWid;
                nHei = nWid / this.nImgRate;

                if(nHei > this.nWinHei) nHei = this.nWinHei;
                nWid = nHei*this.nImgRate;

                this.$img.css({'width': nWid +'px', 'height': nHei +'px', 'left': '50%', 'top': '50%', 'margin-top': -nHei/2+'px', 'margin-left': -nWid/2+'px'});
                this.$popup.css({'width': this.nWinWid +'px', 'height': this.nWinHei+'px'});
                this.move(false);
            }else{
                if(this.nImgWid < this.nWinWid){
                    nLeft = '50%'
                    nMal = this.nImgWid / 2;
                    this.bMoveX = false;
                }
                if(this.nImgHei < this.nWinHei){
                    nTop = '50%'
                    nMat = this.nImgHei / 2;
                    this.bMoveY = false;
                }
                this.$img.css({'width': this.nImgWid +'px', 'height': this.nImgHei+'px', 'left': nLeft, 'top': nTop, 'margin-top': -nMat +'px', 'margin-left': -nMal +'px'});
                this.$popup.css({'width': this.nWinWid +'px', 'height': this.nWinHei+'px'});
                this.move(true);
            }
        }

        /*
         * 鍥剧墖绉诲姩浜嬩欢
         */
        Bigic.prototype.move = function(bln){
            var _x, _y, _winW, _winH,
                _move = false,
                _boxW = this.nImgWid,
                _boxH = this.nImgHei,
                oThis = this;

                if(!oThis.$img) return;
                // 瑙ｉ櫎缁戝畾
                if(!bln){
                    oThis.$img.off('.bigic');
                    $(document).off('.bigic');
                    return;
                }

                // 寮圭獥绉诲姩
                oThis.$img.off('.bigic').on({
                    'click.bigic': function(e){
                            e.preventDefault();
                        },
                    'mousedown.bigic': function(e){
                            e.preventDefault();
                            _move=true;
                            _x=e.pageX-parseInt(oThis.$img.css("left"));
                            _y=e.pageY-parseInt(oThis.$img.css("top"));
                            _winW = oThis.nWinWid;
                            _winH = oThis.nWinHei;
                            oThis.$img.css('cursor','move');
                        }
                });
                $(document).off('.bigic').on({
                    'mousemove.bigic': function(e){
                            e.preventDefault();
                            if(_move){
                                var x=e.pageX-_x;
                                var y=e.pageY-_y;
                                if(x > 0) x = 0;
                                if(y > 0) y = 0;
                                if(_winW && x < _winW-_boxW) x = _winW - _boxW;
                                if(_winH && y < _winH-_boxH) y = _winH - _boxH;
                                if(oThis.bMoveX) oThis.$img[0].style.left = x +'px';
                                if(oThis.bMoveY) oThis.$img[0].style.top = y +'px';
                            }
                        },
                    'mouseup.bigic': function(){
                            _move=false;
                            oThis.$img.css('cursor','default');
                        }
                });
        }
        
        /*
         * 瀹炰緥鍖�
         */
        new Bigic($(this));
    };
})(jQuery);