<?php
<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $valstr=dftval($_GET["valstr"],"");
$restype=qian($valstr,"@");
$resmark=hou($valstr,"@");
$datatype=dftval($_GET["datatype"],"");
$method=$restype;
 $demo='{"status":"1","totrcd":"[totrcd]","vls":[<data>]}';
 $item='{"purl":"[purl]","ptitle":"[ptitle]"},'; 
 $fma="";
$a=time();
switch($restype){
   case "data":
   $outpath=combineurl(localroot(),"/seeds/datas/");
   $tturl=combineurl(localroot(),"/seeds/datas/".$resmark."/");
   $frst=SX("select tabtitle,olmkkey from coode_tablist where TABLE_NAME='".$resmark."'");
   $totf=countresult($frst);
   if (intval($totf)>0){
     $ftitle=anyvalue($frst,"tabtitle",0);
     $olmkkey=anyvalue($frst,"olmkkey",0);
     $drst=SX("select SNO,schm,itemcrtm,itemuptm,itemptof,itemsrcid,itemsrctt,tabsno,tabolmk,conjson,datajson,tabkeys from coode_datainstall where srcid='".$resmark.".Detail'");
     $totd=countresult($drst);
     for ($m=0;$m<$totd;$m++){
        $snox=anyvalue($drst,"SNO",$m);
        $schmx=anyvalue($drst,"schm",$m);
        $itemcrtm=anyvalue($drst,"itemcrtm",$m);
        $itemuptm=anyvalue($drst,"itemuptm",$m);
        $itemptof=anyvalue($drst,"itemptof",$m);
        $itemsrctt=anyvalue($drst,"itemsrctt",$m);
        $tabsno=anyvalue($drst,"tabsno",$m);
        $tabolmk=anyvalue($drst,"tabolmk",$m);
        $conjson=anyvalue($drst,"conjson",$m);
        $datajson=anyvalue($drst,"datajson",$m);
        $tabkeys=anyvalue($drst,"tabkeys",$m);
        $itemx=$item;
        $urlx="/DNA/EXF/anyfuns.php?fid=saverestab&resmark=".$resmark."_data"."&tabnm=".$resmark."&pkey=".$olmkkey."&olmk=".$tabolmk."&itemsno=".$tabsno;
        $titlex="备份写出资源".$resmark."_data表格的编号为".$tabsno."数据";
        $itemx=str_replace("[purl]",$urlx,$itemx);
        $itemx=str_replace("[ptitle]",$titlex,$itemx);
        $fma=$fma.$itemx;
        $tmptot=$tmptot+1;     
     }
     
    }else{
     echo makereturnjson("0","生成节点为".$resmark."的种子失败",($b-$a));
    }
   break;
 
   default:
}
    if ($tmptot>0){
      $fma=killlaststr($fma);
    }
if ($datatype==""){
   $demo=str_replace("<data>",$fma,$demo);
   $demo=str_replace("[totrcd]",$tmptot,$demo);
   echo $demo;
}else{
  header("location:/units/multicmdrun/index.html?method=datatofile&valstr=".$restype."@".$resmark."&scd=500");
}
     session_write_close();
?>
?>