<?php
class absorbhtml{
   public function tempdft(){
    $dft='{!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"}
{html xmlns="http://www.w3.org/1999/xhtml"}
{head}
{meta http-equiv="Content-Type" content="text/html; charset=utf-8" /}
{title}{!--thistitle--}{/title}
{!--thesecomCSSFILES--}
{!--thesecomJSFILES--}
{!--shortJSFILES--}
{!--shortCSSFILES--}
{!--thiscomSTYLE--}
{!--shortSTYLE--}
{/head}
{body}
  {!--thiscomHTML--}
  {!--thiscomSCRIPT--}
  {!--shortSCRIPT--}
{/body}
{/html}
 ';
 return $dft;
}
  public function splithtml($htmlx){
   if ($htmlx!=""){
    $htmlx=str_replace(tabstr(),"  ",$htmlx);
    $codex["jsfilex"]="";
    $codex["jsfiley"]="";
    $codex["jsfilez"]="";
    $codex["cssfilex"]="";
    $codex["stylex"]="";
    $codex["stylez"]="";
    $codex["scriptx"]="";
    $codex["scriptz"]="";
    $codex["scripty"]="";
    $codex["htmlx"]="";
    $codex["bodyx"]="";
    $codex["srd"]=$this->tempdft();
    $bodyq="";
    $bodyh="";
    $bodyz="";
    if (strpos($htmlx,"<body")>0){
     $bodyq=qian($htmlx,"<body");
     $bodyz=hou($htmlx,"<body");
     $bodyz=hou($bodyz,">");
     $bodyz=qian($bodyz,"</body>");
     $bodyz=qian($bodyz,"</BODY>");
    }else if(strpos($htmlx,"<BODY")>0){
      $bodyq=qian($htmlx,"<BODY");
      $bodyz=hou($htmlx,"<BODY");
      $bodyz=hou($bodyz,">");
      $bodyz=qian($bodyz,"</body>");
      $bodyz=qian($bodyz,"</BODY>");
    }else{
      $bodyq="";
    }
    
    if (strpos($htmlx,"</body>")>0){
     $bodyh=hou($htmlx,"</body>");
    }else if(strpos($htmlx,"</BODY>")>0){
      $bodyh=hou($htmlx,"</BODY>");
    }else{
      $bodyh="";
    }
    if ($bodyq!="" and $bodyz!="" and $bodyh!=""){
      //确保每个部分都不缺失再进行
      $ptstl=explode("<style",$bodyq);
      $totpt=count($ptstl);
      for ($i=1;$i<$totpt;$i++){
          if (strpos($ptstl[$i],"<STYLE")>0){
           $ptstl[$i]=qian($ptstl[$i],"<STYLE");
          }
          $stlxyz="<style".$ptstl[$i];          
          $stlxyz=qian($stlxyz,"</style>");
          $stlxyz=qian($stlxyz,"</STYLE>");
          $stlxyz=$stlxyz."</style>";
          $codex["stylex"]=$codex["stylex"].$stlxyz."\r\n";
      }//FOR
      $ptstl=explode("<STYLE",$bodyq);
      $totpt=count($ptstl);
      for ($i=1;$i<$totpt;$i++){
          if (strpos($ptstl[$i],"<style")>0){
           $ptstl[$i]=qian($ptstl[$i],"<style");
          }
          $stlxyz="<STYLE".$ptstl[$i];          
          $stlxyz=qian($stlxyz,"</style>");
          $stlxyz=qian($stlxyz,"</STYLE>");
          $stlxyz=$stlxyz."</STYLE>";
          $codex["stylex"]=$codex["stylex"].$stlxyz."\r\n";
      }//FOR
      $ptscpt=explode("<script",$bodyq);
      $totpt=count($ptscpt);
      for ($i=1;$i<$totpt;$i++){
        if (strpos($ptscpt[$i],"src")>0 ){  
         if (strpos($ptscpt[$i],"\"")>0){           
          $surl=qian(hou($ptscpt[$i],"src=\""),"\"");
         }else{           
          $surl=qian(hou($ptscpt[$i],"src='"),"'");
         }
         $codex["jsfilex"]=$codex["jsfilex"].qian($surl,"?").";";
        }else if (strpos($ptscpt[$i],"SRC")>0 ){         
           if (strpos($ptscpt[$i],"\"")>0){           
            $surl=qian(hou($ptscpt[$i],"SRC=\""),"\"");
           }else{           
            $surl=qian(hou($ptscpt[$i],"SRC='"),"'");
           }
           $codex["jsfilex"]=$codex["jsfilex"].qian($surl,"?").";";
        }        
      }//FOR
      $ptscpt=explode("<SCRIPT",$bodyq);
      $totpt=count($ptscpt);
      for ($i=1;$i<$totpt;$i++){
        if (strpos($ptscpt[$i],"src")>0 ){      
         if (strpos($ptscpt[$i],"\"")>0){           
          $surl=qian(hou($ptscpt[$i],"src=\""),"\"");
         }else{           
          $surl=qian(hou($ptscpt[$i],"src='"),"'");
         }
         $codex["jsfilex"]=$codex["jsfilex"].qian($surl,"?").";";
        }else if (strpos($ptscpt[$i],"SRC")>0 ){
         
           if (strpos($ptscpt[$i],"\"")>0){           
            $surl=qian(hou($ptscpt[$i],"SRC=\""),"\"");
           }else{           
            $surl=qian(hou($ptscpt[$i],"SRC='"),"'");
           }
           $codex["jsfilex"]=$codex["jsfilex"].qian($surl,"?").";";
        }                
      }//FOR
      
      $ptscpt=explode("<link",$bodyq);
      $totpt=count($ptscpt);
      for ($i=1;$i<$totpt;$i++){
        if (strpos($ptscpt[$i],"href")>0){
         $surl=qian($ptscpt[$i],">");         
         if (strpos($surl,"\"")>0){
           $surl=hou($surl,"href");
           $surl=hou($surl,"\"");
           $surl=qian($surl,"\"");
         }else{
           $surl=hou($surl,"href");
           $surl=hou($surl,"'");
           $surl=qian($surl,"'");
         }
        }else if (strpos($ptscpt[$i],"HREF")>0){
         $surl=qian($ptscpt[$i],">");         
         if (strpos($surl,"\"")>0){
           $surl=hou($surl,"HREF");
           $surl=hou($surl,"\"");
           $surl=qian($surl,"\"");
         }else{
           $surl=hou($surl,"HREF");
           $surl=hou($surl,"'");
           $surl=qian($surl,"'");
         }//SURL
        }//SRC
        $codex["cssfilex"]=$codex["cssfilex"].qian($surl,"?").";";
      }//FOR
      $ptscpt=explode("<LINK",$bodyq);
      $totpt=count($ptscpt);
      for ($i=1;$i<$totpt;$i++){
        if (strpos($ptscpt[$i],"href")>0){
         $surl=qian($ptscpt[$i],">");         
         if (strpos($surl,"\"")>0){
           $surl=hou($surl,"href");
           $surl=hou($surl,"\"");
           $surl=qian($surl,"\"");
         }else{
           $surl=hou($surl,"href");
           $surl=hou($surl,"'");
           $surl=qian($surl,"'");
         }
        }else if (strpos($ptscpt[$i],"HREF")>0){
         $surl=qian($ptscpt[$i],">");         
         if (strpos($surl,"\"")>0){
           $surl=hou($surl,"HREF");
           $surl=hou($surl,"\"");
           $surl=qian($surl,"\"");
         }else{
           $surl=hou($surl,"HREF");
           $surl=hou($surl,"'");
           $surl=qian($surl,"'");
         }//SURL
        }//SRC
        $codex["cssfilex"]=$codex["cssfilex"].qian($surl,"?").";";
      }//FOR
      //-----------------------------------------------------------------------
      $ptstl=explode("<style",$bodyz);
      $totpt=count($ptstl);
      for ($i=1;$i<$totpt;$i++){
          if (strpos($ptstl[$i],"<STYLE")>0){
           $ptstl[$i]=qian($ptstl[$i],"<STYLE");
          }
          $stlxyz="<style".$ptstl[$i];          
          $stlxyz=qian($stlxyz,"</style>");
          $stlxyz=qian($stlxyz,"</STYLE>");
          $stlxxx=$stlxyz;
          $stlxyz=$stlxyz."</style>";
          $codex["stylez"]=$codex["stylez"].$stlxyz."\r\n";
          if (strpos($bodyz,$stlxxx."</style>")>0){
            $bodyz=str_replace($stlxxx."</style>","",$bodyz);
          }
          if (strpos($bodyz,$stlxxx."</STYLE>")>0){
            $bodyz=str_replace($stlxxx."</STYLE>","",$bodyz);
          }
      }//FOR
      $ptstl=explode("<STYLE",$bodyz);
      $totpt=count($ptstl);
      for ($i=1;$i<$totpt;$i++){
          if (strpos($ptstl[$i],"<style")>0){
           $ptstl[$i]=qian($ptstl[$i],"<style");
          }
          $stlxyz="<STYLE".$ptstl[$i];          
          $stlxyz=qian($stlxyz,"</style>");
          $stlxyz=qian($stlxyz,"</STYLE>");
          $stlxxx=$stlxyz;
          $stlxyz=$stlxyz."</STYLE>";
          $codex["stylez"]=$codex["stylez"].$stlxyz."\r\n";
          if (strpos($bodyz,$stlxxx."</style>")>0){
            $bodyz=str_replace($stlxxx."</style>","",$bodyz);
          }
          if (strpos($bodyz,$stlxxx."</STYLE>")>0){
            $bodyz=str_replace($stlxxx."</STYLE>","",$bodyz);
          }
      }//FOR
      $ptscpt=explode("<script",$bodyz);
      $totpt=count($ptscpt);
      for ($i=1;$i<$totpt;$i++){
         $scrxxx="<script".$ptscpt[$i];
         $scrxxx=qian($scrxxx,"</script>");
         $scrxxx=qian($scrxxx,"</SCRIPT>");
         if (strpos($bodyz,$scrxxx."</script>")>0){
           $bodyz=str_replace($scrxxx."</script>","",$bodyz);
           $codex["scriptz"]=$codex["scriptz"].$scrxxx."</script>"."\r\n";
         }
         if (strpos($bodyz,$scrxxx."</SCRIPT>")>0){
          $bodyz=str_replace($scrxxx."</SCRIPT>","",$bodyz);
          $codex["scriptz"]=$codex["scriptz"].$scrxxx."</SCRIPT>"."\r\n";
         }
        if (strpos($ptscpt[$i],"src")>0 ){
         $surl=qian($ptscpt[$i],"</script>");
         $surl=qian($surl,"</SCRIPT>");
         $surl=hou($surl,"src");
         if (strpos($surl,"\"")>0){           
           $surl=hou($surl,"\"");
           $surl=qian($surl,"\"");
         }else{           
           $surl=hou($surl,"'");
           $surl=qian($surl,"'");
         }
         $codex["jsfilez"]=$codex["jsfilez"].qian($surl,"?").";";
        }else if (strpos($ptscpt[$i],"SRC")>0 ){
          $surl=qian($ptscpt[$i],"</script>");
          $surl=qian($surl,"</SCRIPT>");
          $surl=hou($surl,"SRC");
         if (strpos($surl,"\"")>0){
           $surl=hou($surl,"\"");
           $surl=qian($surl,"\"");
         }else{
           $surl=hou($surl,"'");
           $surl=qian($surl,"'");
         }//SURL
         $codex["jsfilez"]=$codex["jsfilez"].qian($surl,"?").";";
        }
        
      }//FOR
      $ptscpt=explode("<SCRIPT",$bodyz);
      $totpt=count($ptscpt);
         $scrxxx="<SCRIPT".$ptscpt[$i];
         $scrxxx=qian($scrxxx,"</script>");
         $scrxxx=qian($scrxxx,"</SCRIPT>");
         if (strpos($bodyz,$scrxxx."</script>")>0){
           $bodyz=str_replace($scrxxx."</script>","",$bodyz);
           $codex["scriptz"]=$codex["scriptz"].$scrxxx."</script>"."\r\n";
         }
         if (strpos($bodyz,$scrxxx."</SCRIPT>")>0){
          $bodyz=str_replace($scrxxx."</SCRIPT>","",$bodyz);
          $codex["scriptz"]=$codex["scriptz"].$scrxxx."</SCRIPT>"."\r\n";
         }
      for ($i=1;$i<$totpt;$i++){
        if (strpos($ptscpt[$i],"src")>0 ){
         $surl=qian($ptscpt[$i],"</script>");
         $surl=qian($surl,"</SCRIPT>");
         $surl=hou($surl,"src");
         if (strpos($surl,"\"")>0){           
           $surl=hou($surl,"\"");
           $surl=qian($surl,"\"");
         }else{           
           $surl=hou($surl,"'");
           $surl=qian($surl,"'");
         }
         $codex["jsfilez"]=$codex["jsfilez"].qian($surl,"?").";";
        }else if (strpos($ptscpt[$i],"SRC")>0 ){
         $surl=qian($ptscpt[$i],"</script>");
         $surl=qian($surl,"</SCRIPT>");
         $surl=hou($surl,"SRC");
         if (strpos($surl,"\"")>0){           
           $surl=hou($surl,"\"");
           $surl=qian($surl,"\"");
         }else{           
           $surl=hou($surl,"'");
           $surl=qian($surl,"'");
         }//SURL
         $codex["jsfilez"]=$codex["jsfilez"].qian($surl,"?").";";
        }else{
          if (strpos($ptscpt[$i],"<script")>0){
           $ptscpt[$i]=qian($ptscpt[$i],"<script");
          }
          $scrxyz="<SCRIPT".$ptscpt[$i];          
          $scrxyz=qian($scrxyz,"</script>");
          $scrxyz=qian($scrxyz,"</SCRIPT>");
          $scrxyz=$scrxyz."</SCRIPT>";
          $codex["scriptz"]=$codex["scriptz"].$scrxyz."\r\n";
        }//SRC//SRC
        
      }//FOR
      $bodyz=str_replace("<","{",$bodyz);
      $bodyz=str_replace(">","}",$bodyz);
      $codex["htmlx"]=$bodyz;
      //-----------------------------------------------------------------------
     
      $ptscpt=explode("<script",$bodyh);
      $totpt=count($ptscpt);
      for ($i=1;$i<$totpt;$i++){
        if (strpos($ptscpt[$i],"src")>0 ){
         $surl=qian($ptscpt[$i],"</script>");
         $surl=qian($surl,"</SCRIPT>");
         $surl=hou($surl,"src");
         if (strpos($surl,"\"")>0){           
           $surl=hou($surl,"\"");
           $surl=qian($surl,"\"");
         }else{           
           $surl=hou($surl,"'");
           $surl=qian($surl,"'");
         }
         $codex["jsfiley"]=$codex["jsfiley"].qian($surl,"?").";";
        }else if (strpos($ptscpt[$i],"SRC")>0 ){
         $surl=qian($ptscpt[$i],"</script>");
         $surl=qian($surl,"</SCRIPT>");
         $surl=hou($surl,"SRC");
         if (strpos($surl,"\"")>0){           
           $surl=hou($surl,"\"");
           $surl=qian($surl,"\"");
         }else{           
           $surl=hou($surl,"'");
           $surl=qian($surl,"'");
         }//SURL
         $codex["jsfiley"]=$codex["jsfiley"].qian($surl,"?").";";
        }else{
          if (strpos($ptscpt[$i],"<SCRIPT")>0){
           $ptscpt[$i]=qian($ptscpt[$i],"<SCRIPT");
          }
          $scrxyz="<script".$ptscpt[$i];          
          $scrxyz=qian($scrxyz,"</script>");
          $scrxyz=qian($scrxyz,"</SCRIPT>");
          $scrxyz=$scrxyz."</script>";
          $codex["scripty"]=$codex["scripty"].$scrxyz."\r\n";
        }//SRC
        
      }//FOR
      $ptscpt=explode("<SCRIPT",$bodyh);
      $totpt=count($ptscpt);
      for ($i=1;$i<$totpt;$i++){
        if (strpos($ptscpt[$i],"src")>0 ){
         $surl=qian($ptscpt[$i],"</script>");
         $surl=qian($surl,"</SCRIPT>");
         $surl=hou($surl,"src");
         if (strpos($surl,"\"")>0){           
           $surl=hou($surl,"\"");
           $surl=qian($surl,"\"");
         }else{           
           $surl=hou($surl,"'");
           $surl=qian($surl,"'");
         }
         $codex["jsfiley"]=$codex["jsfiley"].qian($surl,"?").";";
        }else if (strpos($ptscpt[$i],"SRC")>0){
         $surl=qian($ptscpt[$i],"</script>");
         $surl=qian($surl,"</SCRIPT>");
         $surl=hou($surl,"SRC");
         if (strpos($surl,"\"")>0){           
           $surl=hou($surl,"\"");
           $surl=qian($surl,"\"");
         }else{           
           $surl=hou($surl,"'");
           $surl=qian($surl,"'");
         }//SURL
         $codex["jsfiley"]=$codex["jsfiley"].qian($surl,"?").";";
        }else{
          if (strpos($ptscpt[$i],"<script")>0){
           $ptscpt[$i]=qian($ptscpt[$i],"<script");
          }
          $scrxyz="<SCRIPT".$ptscpt[$i];          
          $scrxyz=qian($scrxyz,"</script>");
          $scrxyz=qian($scrxyz,"</SCRIPT>");
          $scrxyz=$scrxyz."</SCRIPT>";
          $codex["scripty"]=$codex["scripty"].$scrxyz."\r\n";
        }//SRC//SRC        
      }//FOR  
      $codex["body"]=labturn($bodyz);
    }//IF BODY
   }//HTMLX
   return $codex;
  }//FUN
  public function tinytounit($sysid,$appid,$layid,$dm,$mk,$tiny,$shortid,$htmlc,$outurl){
     $hcode=array();
     $hcode=$this->splithtml($hcode,$htmlc);
     $cssfiles=$hcode["cssfilex"];
     $jsfiles=$hcode["jsfilex"].$hcode["jsfilez"].$hcode["jsfiley"];
     $stylex=$hcode["stylex"].$hcode["stylez"].$hcode["scriptx"];
     $scriptx=$hcode["scriptz"].$hcode["scripty"];
     $htmlcode=$hcode["htmlx"];
     $democode=$hcode["demox"];     
     $ext0=UX("select count(*) as result from coode_unittiny where dumark='".$dm.".".$mk."' and tinyid='".$tiny."'");
     if (intval($ext0)==0){
      $sqlx="sysid,appid,layid,shortid,tinyid,domainmark,unitmark,dumark,outurl,cssfilex,stylex,jsfilex,scriptx,pagesurround,templatecode,CRTM,UPTM,CRTOR,RIP";
      $sqly="'".$sysid."','".$appid."','".$layid."','".$shortid."','".$tiny."','".$dm."','".$mk."','".$dm.".".$mk."','".$outurl."','".$cssfiles."','".gohex($stylex)."','".$jsfiles."','".gohex($scriptx)."','".gohex($democode)."','".gohex($htmlcode)."',now(),now(),'".$_COOKIE["uid"]."','".getip()."'";
      $sqlz=UX("insert into coode_unittiny(".$sqlx.")values(".$sqly.")");
     }else{
      $sqlx="sysid='".$sysid."',appid='".$appid."',layid='".$layid."',shortid='".$shortid."',domainmark='".$dm."',unitmark='".$mk."',dumark='".$dm.".".$mk."',outurl='".$outurl."',cssfilex='".$cssfiles."',stylex='".gohex($stylex)."',jsfilex='".$jsfiles."',scriptx='".gohex($scriptx)."',pagesurround='".gohex($democode)."',templatecode='".gohex($htmlcode)."',UPTM=now() ";
      $z=UX("update coode_unittiny set ".$sqlx." where tinyid='".$tiny."' and dumark='".$dm.".".$mk."'");
     }
     return true;
  }
}//CLS
?>