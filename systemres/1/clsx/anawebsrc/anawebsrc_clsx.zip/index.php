<?php
class anawebsrc{
public function tempdefault(){
 $dft='{!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"}
{html xmlns="http://www.w3.org/1999/xhtml"}
{!--本页面由酷德数据工厂合成，此页面若含有您所开发资源，请申诉，版权申诉地址 http(s)://'.glw().'SYS/1/userrequest/ --}
{!--本页面由酷德数据工厂合成，此页面若含有错误，请提交工单，工单提交地址 http(s)://'.glw().'SYS/1/userrequest/finderr.html --}
{!--本页面由酷德数据工厂合成，您想参与修改与编辑请访问该地址申请 http(s)://'.glw().'SYS/1/userrequest/finderr.html --}
{!--本页面由酷德数据工厂合成，查看页面资源归属请访问 http(s)://'.glw().'SYS/1/userrequest/finderr.html --}
{head}
{meta http-equiv="Content-Type" content="text/html; charset=utf-8" /}
{title}{!--thistitle--}{/title}
{!--thesecomCSSFILES--}
{!--thesecomJSFILES--}
{!--shortJSFILES--}
{!--shortCSSFILES--}
{!--thiscomSTYLE--}
{!--shortSTYLE--}
{/head}
{body}
  {!--thiscomHTML--}
  {!--thiscomSCRIPT--}
  {!--shortSCRIPT--}
{/body}
{/html}
 ';
 return $dft;
}
public function mbltmpdft(){
 $dft='{!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"}
{html}
{!--本页面由酷德数据工厂合成，此页面若含有您所开发资源，请申诉，版权申诉地址 http(s)://'.glw().'SYS/1/userrequest/ --}
{!--本页面由酷德数据工厂合成，此页面若含有错误，请提交工单，工单提交地址 http(s)://'.glw().'SYS/1/userrequest/finderr.html --}
{!--本页面由酷德数据工厂合成，您想参与修改与编辑请访问该地址申请 http(s)://'.glw().'SYS/1/userrequest/finderr.html --}
{!--本页面由酷德数据工厂合成，查看页面资源归属请访问 http(s)://'.glw().'SYS/1/userrequest/finderr.html --}
{head}
{meta charset="utf-8"}
{meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" /}
{meta name="format-detection" content="telephone=no,email=no,date=no,address=no"}
{title}{!--thistitle--}{/title}
{!--thesecomCSSFILES--}
{!--thesecomJSFILES--}
{!--shortJSFILES--}
{!--shortCSSFILES--}
{!--thiscomSTYLE--}
{!--shortSTYLE--}
{/head}
{body}
  {!--thiscomHTML--}
  {!--thiscomSCRIPT--}
  {!--shortSCRIPT--}
{/body}
{/html}
 ';
 return $dft;
}
  public function absorbjsfs($codes,$jfx=array(array()),$partx){
   $lei=$jfx["tot"]["lei"];
   $ptsc0=explode("<script",$codes);
   if ($ptsc0[0]!=$codes){
     $tot0=count($ptsc0);
     for ($i=1;$i<$tot0;$i++){
       $tempsc=qian($ptsc0[$i],">");
       if (strpos($tempsc,"src")>0){
        $jsitem=hou($tempsc,"src");
        $jsitem=hou($jsitem,"=");        
        if (strpos("xx".$jsitem,'"')>0){
         $jsitem=hou($jsitem,'"');
         $jsitem=qian($jsitem,'"');
        }else{
         $jsitem=hou($jsitem,"'");
         $jsitem=qian($jsitem,"'");
        }
        $jfx[$lei]["file"]=$jsitem;
        $jfx[$lei]["part"]=$partx;
        $lei=$lei+1;
       }else if(strpos($tempsc,"SRC")>0){
        $jsitem=hou($tempsc,"SRC");
        $jsitem=hou($jsitem,"=");        
        if (strpos("xx".$jsitem,'"')>0){
         $jsitem=hou($jsitem,'"');
         $jsitem=qian($jsitem,'"');
        }else{
         $jsitem=hou($jsitem,"'");
         $jsitem=qian($jsitem,"'");
        }
        $jfx[$lei]["file"]=$jsitem;
        $jfx[$lei]["part"]=$partx;
        $lei=$lei+1;
       } //if src    
     }//for
   }//ifpt0
   $ptsc1=explode("<SCRIPT",$codes);
   if ($ptsc1[0]!=$codes){
    $tot1=count($ptsc1);
     for ($j=1;$j<$tot1;$j++){
       $tempsc=qian($ptsc0[$i],">");
       if (strpos($tempsc,"src")>0){
        $jsitem=hou($tempsc,"src");
        $jsitem=hou($jsitem,"=");        
        if (strpos("xx".$jsitem,'"')>0){
         $jsitem=hou($jsitem,'"');
         $jsitem=qian($jsitem,'"');
        }else{
         $jsitem=hou($jsitem,"'");
         $jsitem=qian($jsitem,"'");
        }
        $jfx[$lei]["file"]=$jsitem;
        $jfx[$lei]["part"]=$partx;
        $lei=$lei+1;
       }else if(strpos($tempsc,"SRC")>0){
        $jsitem=hou($tempsc,"SRC");
        $jsitem=hou($jsitem,"=");        
        if (strpos("xx".$jsitem,'"')>0){
         $jsitem=hou($jsitem,'"');
         $jsitem=qian($jsitem,'"');
        }else{
         $jsitem=hou($jsitem,"'");
         $jsitem=qian($jsitem,"'");
        }
        $jfx[$lei]["file"]=$jsitem;
        $jfx[$lei]["part"]=$partx;        
        $lei=$lei+1;
       }
     }
   }//ifpt1
   $ptsc2=explode("<Script",$codes);
   if ($ptsc2[0]!=$codes){
    $tot2=count($ptsc2);
     for ($k=1;$k<$tot2;$k++){
       $tempsc=qian($ptsc0[$i],">");
       if (strpos($tempsc,"src")>0){
        $jsitem=hou($tempsc,"src");
        $jsitem=hou($jsitem,"=");        
        if (strpos("xx".$jsitem,'"')>0){
         $jsitem=hou($jsitem,'"');
         $jsitem=qian($jsitem,'"');
        }else{
         $jsitem=hou($jsitem,"'");
         $jsitem=qian($jsitem,"'");
        }
        $jfx[$lei]["file"]=$jsitem;
        $jfx[$lei]["part"]=$partx;
        $lei=$lei+1;
       }else if(strpos($tempsc,"SRC")>0){
        $jsitem=hou($tempsc,"SRC");
        $jsitem=hou($jsitem,"=");        
        if (strpos("xx".$jsitem,'"')>0){
         $jsitem=hou($jsitem,'"');
         $jsitem=qian($jsitem,'"');
        }else{
         $jsitem=hou($jsitem,"'");
         $jsitem=qian($jsitem,"'");
        }
        $jfx[$lei]["file"]=$jsitem;
        $jfx[$lei]["part"]=$partx;
        $lei=$lei+1;
       }
     }//for
   }//ifpt2
   $jfx["tot"]["lei"]=$lei;
   return $jfx;
  }//fun
  public function absorbcssfs($codes,$cfx=array(array()),$partx){
    $lei=$cfx["tot"]["lei"];
   $ptsc0=explode("<link",$codes);
   if ($ptsc0[0]!=$codes){
     $tot0=count($ptsc0);
     for ($i=1;$i<$tot0;$i++){
       $tempsc=qian($ptsc0[$i],">");
       if (strpos($tempsc,"href")>0){
        $jsitem=hou($tempsc,"href");
        $jsitem=hou($jsitem,"=");        
        if (strpos("xx".$jsitem,'"')>0){
         $jsitem=hou($jsitem,'"');
         $jsitem=qian($jsitem,'"');
        }else{
         $jsitem=hou($jsitem,"'");
         $jsitem=qian($jsitem,"'");
        }
        $cfx[$lei]["file"]=$jsitem;
        $cfx[$lei]["part"]=$partx;
        $lei=$lei+1;
       }else if(strpos($tempsc,"HREF")>0){
        $jsitem=hou($tempsc,"HREF");
        $jsitem=hou($jsitem,"=");        
        if (strpos("xx".$jsitem,'"')>0){
         $jsitem=hou($jsitem,'"');
         $jsitem=qian($jsitem,'"');
        }else{
         $jsitem=hou($jsitem,"'");
         $jsitem=qian($jsitem,"'");
        }
        $cfx[$lei]["file"]=$jsitem;
        $cfx[$lei]["part"]=$partx;
        $lei=$lei+1;
       } //if src    
     }//for
   }//ifpt0
   $ptsc1=explode("<LINK",$codes);
   if ($ptsc1[0]!=$codes){
    $tot1=count($ptsc1);
     for ($j=1;$j<$tot1;$j++){
       $tempsc=qian($ptsc0[$i],">");
       if (strpos($tempsc,"href")>0){
        $jsitem=hou($tempsc,"href");
        $jsitem=hou($jsitem,"=");        
        if (strpos("xx".$jsitem,'"')>0){
         $jsitem=hou($jsitem,'"');
         $jsitem=qian($jsitem,'"');
        }else{
         $jsitem=hou($jsitem,"'");
         $jsitem=qian($jsitem,"'");
        }
        $cfx[$lei]["file"]=$jsitem;
        $cfx[$lei]["part"]=$partx;
        $lei=$lei+1;
       }else if(strpos($tempsc,"HREF")>0){
        $jsitem=hou($tempsc,"HREF");
        $jsitem=hou($jsitem,"=");        
        if (strpos("xx".$jsitem,'"')>0){
         $jsitem=hou($jsitem,'"');
         $jsitem=qian($jsitem,'"');
        }else{
         $jsitem=hou($jsitem,"'");
         $jsitem=qian($jsitem,"'");
        }
        $cfx[$lei]["file"]=$jsitem;
        $cfx[$lei]["part"]=$partx;        
        $lei=$lei+1;
       }
     }
   }//ifpt1
   $ptsc2=explode("<Link",$codes);
   if ($ptsc2[0]!=$codes){
    $tot2=count($ptsc2);
     for ($k=1;$k<$tot2;$k++){
       $tempsc=qian($ptsc0[$i],">");
       if (strpos($tempsc,"href")>0){
        $jsitem=hou($tempsc,"href");
        $jsitem=hou($jsitem,"=");        
        if (strpos("xx".$jsitem,'"')>0){
         $jsitem=hou($jsitem,'"');
         $jsitem=qian($jsitem,'"');
        }else{
         $jsitem=hou($jsitem,"'");
         $jsitem=qian($jsitem,"'");
        }
        $cfx[$lei]["file"]=$jsitem;
        $cfx[$lei]["part"]=$partx;
        $lei=$lei+1;
       }else if(strpos($tempsc,"HREF")>0){
        $jsitem=hou($tempsc,"HREF");
        $jsitem=hou($jsitem,"=");        
        if (strpos("xx".$jsitem,'"')>0){
         $jsitem=hou($jsitem,'"');
         $jsitem=qian($jsitem,'"');
        }else{
         $jsitem=hou($jsitem,"'");
         $jsitem=qian($jsitem,"'");
        }
        $cfx[$lei]["file"]=$jsitem;
        $cfx[$lei]["part"]=$partx;
        $lei=$lei+1;
       }
     }//for
   }//ifpt2
   $cfx["tot"]["lei"]=$lei;
   return $cfx;
  }
  public function absorbscripts($codes,$scx=array(array()),$partx){
    $lei=$scx["tot"]["lei"];
     $ptsc0=explode("<script",$codes);
     if ($ptsc0[0]!=$codes){
       $tot0=count($ptsc0);
       for($i=1;$i<$tot0;$i++){
         $tempsc=hou($ptsc0[$i],">");
         if (strpos($tempsc,"</script")>0){
          $tmpin=qian($tempsc,"</script");
          
         }else if (strpos($tempsc,"</SCRIPT")>0){
          $tmpin=qian($tempsc,"</SCRIPT");
          
         }else if (strpos($tempsc,"</Script")>0){
          $tmpin=qian($tempsc,"</Script");
          
         }//if
         if (str_replace(" ","",$tmpin)!=""){
          $scx[$lei]["script"]="<script>".$tmpin."</script>";
          $scx[$lei]["part"]=$partx;
         }
        }//for
     }
     $ptsc1=explode("<SCRIPT",$codes);
     if ($ptsc1[0]!=$codes){
        $tot1=count($ptsc1);
        for($j=1;$j<$tot1;$j++){
         $tempsc=hou($ptsc1[$j],">");
         if (strpos($tempsc,"</script")>0){
          $tmpin=qian($tempsc,"</script");
          
         }else if (strpos($tempsc,"</SCRIPT")>0){
          $tmpin=qian($tempsc,"</SCRIPT");
          
         }else if (strpos($tempsc,"</Script")>0){
          $tmpin=qian($tempsc,"</Script");
          
         }//if
         if (str_replace(" ","",$tmpin)!=""){
          $scx[$lei]["script"]="<script>".$tmpin."</script>";
          $scx[$lei]["part"]=$partx;
         }
        }//for
     }
     $ptsc2=explode("<Script",$codes);
     if ($ptsc2[0]!=$codes){
        $tot2=count($ptsc2);        
        for($k=1;$k<$tot2;$k++){
         $tempsc=hou($ptsc2[$k],">");
         if (strpos($tempsc,"</script")>0){
          $tmpin=qian($tempsc,"</script");
          
         }else if (strpos($tempsc,"</SCRIPT")>0){
          $tmpin=qian($tempsc,"</SCRIPT");
          
         }else if (strpos($tempsc,"</Script")>0){
          $tmpin=qian($tempsc,"</Script");
          
         }//if
         if (str_replace(" ","",$tmpin)!=""){
          $scx[$lei]["script"]="<script>".$tmpin."</script>";
          $scx[$lei]["part"]=$partx;
         }
        }//for
     }//ifpt2
     $scx["tot"]["lei"]=$lei;
     return $scx;
  }
  public function absorbstyles($codes,$stlx=array(array()),$partx){
    $lei=$stlx["tot"]["lei"];
    $ptsc0=explode("<style",$codes);
     if ($ptsc0[0]!=$codes){
       $tot0=count($ptsc0);
       for($i=1;$i<$tot0;$i++){
         $tempsc=hou($ptsc0[$i],">");
         if (strpos($tempsc,"</style")>0){
          $tmpin=qian($tempsc,"</style");
          
         }else if (strpos($tempsc,"</STYLE")>0){
          $tmpin=qian($tempsc,"</STYLE");
          
         }else if (strpos($tempsc,"</Style")>0){
          $tmpin=qian($tempsc,"</Style");
          
         }//if
         if (str_replace(" ","",$tmpin)!=""){
          $stlx[$lei]["style"]="<style>".$tmpin."</style>";
          $stlx[$lei]["part"]=$partx;
         }
        }//for
     }
     $ptsc1=explode("<STYLE",$codes);
     if ($ptsc1[0]!=$codes){
        $tot1=count($ptsc1);
        for($j=1;$j<$tot1;$j++){
         $tempsc=hou($ptsc1[$j],">");
         if (strpos($tempsc,"</style")>0){
          $tmpin=qian($tempsc,"</style");
          
         }else if (strpos($tempsc,"</STYLE")>0){
          $tmpin=qian($tempsc,"</STYLE");
          
         }else if (strpos($tempsc,"</Style")>0){
          $tmpin=qian($tempsc,"</Style");
          
         }//if
         if (str_replace(" ","",$tmpin)!=""){
          $stlx[$lei]["style"]="<style>".$tmpin."</style>";
          $stlx[$lei]["part"]=$partx;
         }
        }//for
     }
     $ptsc2=explode("<Style",$codes);
     if ($ptsc2[0]!=$codes){
        $tot2=count($ptsc2);        
        for($k=1;$k<$tot2;$k++){
         $tempsc=hou($ptsc2[$k],">");
         if (strpos($tempsc,"</style")>0){
          $tmpin=qian($tempsc,"</style");
          
         }else if (strpos($tempsc,"</STYLE")>0){
          $tmpin=qian($tempsc,"</STYLE");
          
         }else if (strpos($tempsc,"</Style")>0){
          $tmpin=qian($tempsc,"</Style");
          
         }//if
         if (str_replace(" ","",$tmpin)!=""){
          $stlx[$lei]["style"]="<style>".$tmpin."</style>";
          $stlx[$lei]["part"]=$partx;
         }
        }//for
     }//ifpt2
     $stlx["tot"]["lei"]=$lei;
     return $stlx;
  }
  public function absorbhtml($domain,$lcurl,$faceid,$hcode=array()){
    $htmlcode=file_get_contents($lcurl);
    $htmlcode=str_replace(tabstr()," ",$htmlcode);
    if (strpos($htmlcode,"<body")>0){
      $bdq=qian($htmlcode,"<body");
      if (strpos($htmlcode,"</body>")>0){
        $bdz=qian(hou(hou($htmlcode,"<body"),">"),"</body>");
        $bdh=hou($htmlcode,"</body>");
      }else if(strpos($htmlcode,"</BODY>")>0){
        $bdz=qian(hou(hou($htmlcode,"<body"),">"),"</BODY>");
        $bdh=hou($htmlcode,"</BODY>");
      }else if(strpos($htmlcode,"</Body>")>0){
        $bdz=qian(hou(hou($htmlcode,"<body"),">"),"</Body>");
        $bdh=hou($htmlcode,"</Body>");
      }
    }else  if (strpos($htmlcode,"<BODY")>0){
      $bdq=qian($htmlcode,"<BODY");
      if (strpos($htmlcode,"</body>")>0){
        $bdz=qian(hou(hou($htmlcode,"<BODY"),">"),"</body>");
        $bdh=hou($htmlcode,"</body>");
      }else if(strpos($htmlcode,"</BODY>")>0){
        $bdz=qian(hou(hou($htmlcode,"<BODY"),">"),"</BODY>");
        $bdh=hou($htmlcode,"</BODY>");
      }else if(strpos($htmlcode,"</Body>")>0){
        $bdz=qian(hou(hou($htmlcode,"<BODY"),">"),"</Body>");
        $bdh=hou($htmlcode,"</Body>");
      }
    }else  if (strpos($htmlcode,"<Body")>0){
      $bdq=qian($htmlcode,"<Body");
      if (strpos($htmlcode,"</body>")>0){
        $bdz=qian(hou(hou($htmlcode,"<Body"),">"),"</body>");
        $bdh=hou($htmlcode,"</body>");
      }else if(strpos($htmlcode,"</BODY>")>0){
        $bdz=qian(hou(hou($htmlcode,"<Body"),">"),"</BODY>");
        $bdh=hou($htmlcode,"</BODY>");
      }else if(strpos($htmlcode,"</Body>")>0){
        $bdz=qian(hou(hou($htmlcode,"<Body"),">"),"</Body>");
        $bdh=hou($htmlcode,"</Body>");
      }
    }
    $jsfiles=array(array());
    $jsfiles["tot"]["lei"]=0;
    $jsfiles=$this->absorbjsfs($bdq,$jsfiles,"top");
    $jsfiles=$this->absorbjsfs($bdz,$jsfiles,"body");
    $jsfiles=$this->absorbjsfs($bdh,$jsfiles,"foot");
    $cssfiles=array(array());
    $cssfiles["tot"]["lei"]=0;
    $cssfiles=$this->absorbcssfs($bdq,$cssfiles,"top");
    $cssfiles=$this->absorbcssfs($bdz,$cssfiles,"body");
    $cssfiles=$this->absorbcssfs($bdh,$cssfiles,"foot");
    $styles=array(array());
    $styles["tot"]["lei"]=0;
    $styles=$this->absorbstyles($bdq,$styles,"top");
    $styles=$this->absorbstyles($bdq,$styles,"body");
    $styles=$this->absorbstyles($bdq,$styles,"foot");
    $scripts=array(array());
    $scripts["tot"]["lei"]=0;
    $scripts=$this->absorbscripts($bdq,$scripts,"top");
    $scripts=$this->absorbscripts($bdq,$scripts,"body");
    $scripts=$this->absorbscripts($bdq,$scripts,"foot");
    $imgtops=array();
    $imgtops=absorbpics($bdq,$imgtops);
    $imgbodys=array();
    $imgbodys=absorbpics($bdz,$imgbodys);
    $imgfoots=array();
    $imgfoots=absorbpics($bdh,$imgfoots);
    
   if ($faceid!=""){
    $jfiles="";
    for ($m=0;$m<$jsfiles["tot"]["lei"];$m++){
      if ($jsfiles[$m]["part"]=="top"){
       if (strpos("x".$jsfiles[$m]["file"],"//")<=0 and substr($jsfiles[$m]["file"],0,1)!="/"){
        $jfiles=$jfiles."/MYFACE/".$faceid."/".$jsfiles[$m]["file"].";";
       }
      }
    }
    $cfiles="";
    for ($n=0;$n<$cssfiles["tot"]["lei"];$n++){
      if ($cssfiles[$n]["part"]!="body"){
       if (strpos("x".$cssfiles[$n]["file"],"//")<=0 and substr($cssfiles[$n]["file"],0,1)!="/"){
        $cfiles=$cfiles."/MYFACE/".$faceid."/".$cssfiles[$n]["file"].";";
       }
      }
    }
    $jfiles=killlaststr($jfiles);
    $cfiles=killlaststr($cfiles);
    $stls="";
    for ($n=0;$n<$styles["tot"]["lei"];$n++){
      if ($styles[$n]["part"]!="body"){       
        $stls=$stls.$styles[$n]["style"];
      }
    }
    $scps="";
    for ($m=0;$m<$jsfiles["tot"]["lei"];$m++){
      if ($jsfiles[$m]["part"]=="foot"){
      if (strpos("x".$jsfiles[$m]["file"],"//")<=0 and substr($jsfiles[$m]["file"],0,1)!="/"){
        $scps=$scps."<script src=\"/MYFACE/".$faceid."/".$jsfiles[$m]["file"]."\"></script>";
       }
      }
    }//for
    for ($n=0;$n<$scripts["tot"]["lei"];$n++){
      if ($scripts[$n]["part"]!="body"){
        $scps=$scps.$scripts[$n]["script"];
      }
    }
    $bodyx=str_replace("{","｛",$bdz);
    $bodyx=str_replace("}","｝",$bodyx);
    $bodyx=str_replace("<","{",$bodyx);
    $bodyx=str_replace(">","}",$bodyx);
    if (strpos($bdq,"title")>0){
      $title=hou(hou($bdq,"title"),">");      
      $title=qian($title,"<");        
    }else if(strpos($bdq,"TITLE")>0){
      $title=hou(hou($bdq,"TITLE"),">");
      $title=qian($title,"<");
    }
    $title=str_replace(" ","",$title);
    $fname=urlfname($lcurl);
    $mark=qian($fname,".");
    $bodyx=str_replace('img/',$faceid."/img/",$bodyx);
    $bodyx=str_replace('imgs/',$faceid."/imgs/",$bodyx);
    $bodyx=str_replace('images/',$faceid."/images/",$bodyx);
    $bodyx=str_replace('js/',$faceid."/js/",$bodyx);
    $bodyx=str_replace('css/',$faceid."/css/",$bodyx);
    $bodyx=str_replace('./js/',$faceid."/js/",$bodyx);
    $bodyx=str_replace('./css/',$faceid."/css/",$bodyx);
    $hcode["tempcode"]=$bodyx;
    $hcode["cssfiles"]=$cfiles;
    $hcode["jsfiles"]=$jfiles;
    $hcode["styles"]=$stls;    
    $hcode["scripts"]=$scps;
    $hcode["title"]=$title;
    if ($domain==""){
     $domain=getRandChar(8);
    }
    $hcode["outpath"]="/myunits/".$domain."/".$fname;
    $pp=UX("update coode_myfacelist set facetitle='".$title."' where faceid='".$faceid."'");
    $extd=UX("select count(*) as result from coode_mydonunit where domainmark='".$domain."' and unitmark='".$mark."'");
    $exte=UX("select count(*) as result from coode_domainunit where domainmark='".$domain."' and unitmark='".$mark."'");
    $srdcode=$this->tempdefault();
    if (intval($extd)+intval($exte)==0){
      $sqlx="unittitle,domainmark,unitmark,dumark,outurl,cssfilex,jsfilex,stylex,scriptx,templatecode,pagesurround,CRTM,UPTM,OLMK,CRTOR";
      $sqly="'".$title."','".$domain."','".$mark."','".$domain.".".$mark."','/myunits/".$domain."/".$fname."','".$cfiles."','".$jfiles."','".gohex($stls)."','".gohex($scps)."','".gohex($bodyx)."','".gohex($srdcode)."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."'";
      $zX=UX("insert into coode_mydonunit(".$sqlx.")values(".$sqly.")");
    }else{
      $yz=UX("update coode_mydonunit set dumark='".$domain.".".$mark."',cssfilex='".$cfiles."',jsfilex='".$jfiles."',stylex='".gohex($stls)."',scriptx='".gohex($scps)."',templatecode='".gohex($bodyx)."',pagesurround='".gohex($srdcode)."' where domainmark='".$domain."' and unitmark='".$mark."'");
    }
  }//faceid!=""
    return $hcode;
  }//FUNHTML
    public function absorbtounit($domain,$mark,$faceurl,$ucls,$hcode=array()){
    $faceid=urlfname($faceurl);
    $lcurl=combineurl(localroot(),$faceurl."/index.html");
    $htmlcode=file_get_contents($lcurl);
    $htmlcode=str_replace(tabstr()," ",$htmlcode);
    if (strpos($htmlcode,"<body")>0){
      $bdq=qian($htmlcode,"<body");
      if (strpos($htmlcode,"</body>")>0){
        $bdz=qian(hou(hou($htmlcode,"<body"),">"),"</body>");
        $bdh=hou($htmlcode,"</body>");
      }else if(strpos($htmlcode,"</BODY>")>0){
        $bdz=qian(hou(hou($htmlcode,"<body"),">"),"</BODY>");
        $bdh=hou($htmlcode,"</BODY>");
      }else if(strpos($htmlcode,"</Body>")>0){
        $bdz=qian(hou(hou($htmlcode,"<body"),">"),"</Body>");
        $bdh=hou($htmlcode,"</Body>");
      }
    }else  if (strpos($htmlcode,"<BODY")>0){
      $bdq=qian($htmlcode,"<BODY");
      if (strpos($htmlcode,"</body>")>0){
        $bdz=qian(hou(hou($htmlcode,"<BODY"),">"),"</body>");
        $bdh=hou($htmlcode,"</body>");
      }else if(strpos($htmlcode,"</BODY>")>0){
        $bdz=qian(hou(hou($htmlcode,"<BODY"),">"),"</BODY>");
        $bdh=hou($htmlcode,"</BODY>");
      }else if(strpos($htmlcode,"</Body>")>0){
        $bdz=qian(hou(hou($htmlcode,"<BODY"),">"),"</Body>");
        $bdh=hou($htmlcode,"</Body>");
      }
    }else  if (strpos($htmlcode,"<Body")>0){
      $bdq=qian($htmlcode,"<Body");
      if (strpos($htmlcode,"</body>")>0){
        $bdz=qian(hou(hou($htmlcode,"<Body"),">"),"</body>");
        $bdh=hou($htmlcode,"</body>");
      }else if(strpos($htmlcode,"</BODY>")>0){
        $bdz=qian(hou(hou($htmlcode,"<Body"),">"),"</BODY>");
        $bdh=hou($htmlcode,"</BODY>");
      }else if(strpos($htmlcode,"</Body>")>0){
        $bdz=qian(hou(hou($htmlcode,"<Body"),">"),"</Body>");
        $bdh=hou($htmlcode,"</Body>");
      }
    }
    $jsfiles=array(array());
    $jsfiles["tot"]["lei"]=0;
    $jsfiles=$this->absorbjsfs($bdq,$jsfiles,"top");
    $jsfiles=$this->absorbjsfs($bdz,$jsfiles,"body");
    $jsfiles=$this->absorbjsfs($bdh,$jsfiles,"foot");
    $cssfiles=array(array());
    $cssfiles["tot"]["lei"]=0;
    $cssfiles=$this->absorbcssfs($bdq,$cssfiles,"top");
    $cssfiles=$this->absorbcssfs($bdz,$cssfiles,"body");
    $cssfiles=$this->absorbcssfs($bdh,$cssfiles,"foot");
    $styles=array(array());
    $styles["tot"]["lei"]=0;
    $styles=$this->absorbstyles($bdq,$styles,"top");
    $styles=$this->absorbstyles($bdq,$styles,"body");
    $styles=$this->absorbstyles($bdq,$styles,"foot");
    $scripts=array(array());
    $scripts["tot"]["lei"]=0;
    $scripts=$this->absorbscripts($bdq,$scripts,"top");
    $scripts=$this->absorbscripts($bdq,$scripts,"body");
    $scripts=$this->absorbscripts($bdq,$scripts,"foot");
    $imgtops=array();
    $imgtops=absorbpics($bdq,$imgtops);
    $imgbodys=array();
    $imgbodys=absorbpics($bdz,$imgbodys);
    $imgfoots=array();
    $imgfoots=absorbpics($bdh,$imgfoots);
    
   if ($faceid!=""){
    $jfiles="";
    for ($m=0;$m<$jsfiles["tot"]["lei"];$m++){
      if ($jsfiles[$m]["part"]=="top"){
       if (strpos("x".$jsfiles[$m]["file"],"//")<=0 and substr($jsfiles[$m]["file"],0,1)!="/"){
        $jfiles=$jfiles."/FACE/".$faceid."/".$jsfiles[$m]["file"].";";
       }
      }
    }
    $cfiles="";
    for ($n=0;$n<$cssfiles["tot"]["lei"];$n++){
      if ($cssfiles[$n]["part"]!="body"){
       if (strpos("x".$cssfiles[$n]["file"],"//")<=0 and substr($cssfiles[$n]["file"],0,1)!="/"){
        $cfiles=$cfiles."/FACE/".$faceid."/".$cssfiles[$n]["file"].";";
       }
      }
    }
    $jfiles=killlaststr($jfiles);
    $cfiles=killlaststr($cfiles);
    $stls="";
    for ($n=0;$n<$styles["tot"]["lei"];$n++){
      if ($styles[$n]["part"]!="body"){       
        $stls=$stls.$styles[$n]["style"];
      }
    }
    $scps="";
    for ($m=0;$m<$jsfiles["tot"]["lei"];$m++){
      if ($jsfiles[$m]["part"]=="foot"){
      if (strpos("x".$jsfiles[$m]["file"],"//")<=0 and substr($jsfiles[$m]["file"],0,1)!="/"){
        $scps=$scps."<script src=\"/FACE/".$faceid."/".$jsfiles[$m]["file"]."\"></script>";
       }
      }
    }//for
    for ($n=0;$n<$scripts["tot"]["lei"];$n++){
      if ($scripts[$n]["part"]!="body"){
        $scps=$scps.$scripts[$n]["script"];
      }
    }
    $bodyx=str_replace("{","｛",$bdz);
    $bodyx=str_replace("}","｝",$bodyx);
    $bodyx=str_replace("<","{",$bodyx);
    $bodyx=str_replace(">","}",$bodyx);
    if (strpos($bdq,"title")>0){
      $title=hou(hou($bdq,"title"),">");      
      $title=qian($title,"<");        
    }else if(strpos($bdq,"TITLE")>0){
      $title=hou(hou($bdq,"TITLE"),">");
      $title=qian($title,"<");
    }
    $title=str_replace(" ","",$title);
    $fname=urlfname($lcurl);    
   $bodyx=str_replace('img/',$faceid."/img/",$bodyx);
   $bodyx=str_replace('imgs/',$faceid."/imgs/",$bodyx);
   $bodyx=str_replace('images/',$faceid."/images/",$bodyx);
    $bodyx=str_replace('js/',$faceid."/js/",$bodyx);
    $bodyx=str_replace('css/',$faceid."/css/",$bodyx);
    $bodyx=str_replace('./js/',$faceid."/js/",$bodyx);
    $bodyx=str_replace('./css/',$faceid."/css/",$bodyx);
    
    $hcode["tempcode"]=$bodyx;
    $hcode["cssfiles"]=$cfiles;
    $hcode["jsfiles"]=$jfiles;
    $hcode["styles"]=$stls;
    $hcode["scripts"]=$scps;
    $hcode["title"]=$title;
    if ($domain==""){
     $domain=getRandChar(8);
    }
    $hcode["outpath"]="/units/".$domain."/".$mark.".html";
    $pp=UX("update coode_facelist set facetitle='".$title."' where faceid='".$faceid."'");
    $extd=UX("select count(*) as result from coode_mydonunit where domainmark='".$domain."' and unitmark='".$mark."'");
    $exte=UX("select count(*) as result from coode_domainunit where domainmark='".$domain."' and unitmark='".$mark."'");
    if (substr($ucls,0,1)=="M"){
     $srdcode=$this->mbltmpdft();
    }else{
     $srdcode=$this->tempdefault();
    }
    //if (intval($extd)+intval($exte)==0){
    //  $sqlx="unittitle,domainmark,unitmark,dumark,outurl,cssfilex,jsfilex,stylex,scriptx,templatecode,pagesurround,CRTM,UPTM,OLMK,CRTOR";
    //  $sqly="'".$title."','".$domain."','".$mark."','".$domain.".".$mark."','/units/".$domain."/".$fname."','".$cfiles."','".$jfiles."','".gohex($stls)."','".gohex($scps)."','".gohex($bodyx)."','".gohex($srdcode)."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."'";
    //  $zX=UX("insert into coode_domainunit(".$sqlx.")values(".$sqly.")");
    //}else{
    //  $yz=UX("update coode_domainunit set dumark='".$domain.".".$mark."',cssfilex='".$cfiles."',jsfilex='".$jfiles."',stylex='".gohex($stls)."',scriptx='".gohex($scps)."',templatecode='".gohex($bodyx)."',pagesurround='".gohex($srdcode)."' where domainmark='".$domain."' and unitmark='".$mark."'");
    //}
  }//faceid!=""
    return $hcode;
  }//FUNHTML
}//CLS
?>