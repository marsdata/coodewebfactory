<?php
class formpost{
public function fmpost($garr=array(array()),$gsno,$gtnm,$gkies){
 $pdata=thekeyfun($pdata,glb(),$gtnm,str_replace('SNO,','',$gkies));
 $alldata=thekeyfun($alldata,glb(),$gtnm,"*");
 $fmsqlk="";
 $fmsqlv="";
 $totrcv=0;
 $rcvkey="";
 if ($gsno==""){
   $gsno="0";
 };
 $fmextk="";
 $fmextv="";  
 $tbrst=SX("select mainsqx,olmkkey from coode_tablist where TABLE_NAME='".$gtnm."'");
 $prisno=anyvalue($tbrst,"mainsqx",0);
 $priolmk=anyvalue($tbrst,"olmkkey",0);
 for ($p=0;$p<$alldata['COLUMN']['COUNT'];$p++){
   if ($alldata["COLUMN"][$p]==$prisno){
     }else{
    if(strpos("xxx,".$gkies.",",",".$alldata["COLUMN"][$p].",")>0){
      }else{
       $fmextk=$fmextk.$alldata["COLUMN"][$p].",";
     $tmpextdft="";
     $defaultv="";
     $tmpextdft=$alldata[$alldata["COLUMN"][$p]]["COLUMN_DEFAULT"];
      if (strpos($tmpextdft,'defaultv')>0){
           eval($tmpextdft);           
      }
       if ($alldata["COLUMN"][$p]==$priolmk){
         if ($defaultv==""){
           $defaultv=onlymark();
         }
         $_GET["tmpolmk"]=$defaultv;
       }
       $fmextv=$fmextv."'".tohex(correctv($alldata[$alldata["COLUMN"][$p]]["COLUMN_TPNM"],$alldata[$alldata["COLUMN"][$p]]["COLUMN_TPLEN"],$defaultv))."',";
       $defaultv="";
       $tmppost="";
    };//不存在 POST KEY
   };//if SNO
 };//for  
 if ($alldata['COLUMN']['COUNT']>0){
   $fmextk=substr($fmextk,0,strlen($fmextk)-1);
   $fmextv=substr($fmextv,0,strlen($fmextv)-1);
 };
 
 for ($p=0;$p<$pdata['COLUMN']['COUNT'];$p++){
  $tmppost="";
  $tmppost=unstrs($_POST["p_".$pdata["COLUMN"][$p].$gsno]);
  
  if ($tmppost=="now()" or $tmppost=="NOW()" ){
    $tmppost=date("Y-m-d H:i:s");
  };
  if ($tmppost=="date(now())" or $tmppost=="DATE(NOW())" or $tmppost=="DATE(now())" or $tmppost=="date(NOW())" ){
    $tmppost=date("Y-m-d");
  }
   $tmppost=str_replace("，",",",$tmppost);
//   echo "p_".$pdata["COLUMN"][$p].$gsno."---tmppost=".$tmppost."---".$_POST["p_".$pdata["COLUMN"][$p].$gsno];
  $pdata[$pdata["COLUMN"][$p]]["post"]=$tmppost;//单单数据本身不用加工,准备入库的形式要加工
  $pdata[$pdata["COLUMN"][$p]]["type"]="varchar(255)";//默认都弄成VARCHAR255
  if (strtotime($tmppost)!=""){
     $pdata[$pdata["COLUMN"][$p]]["type"]="datetime";//判断数据类型
  }else{
    if (($tmppost*1)>0 or $tmppost=="0"){
       if (strpos($tmppost,".")>0){//如果有小数点则看看小数点长度
         if (intval(hou($tmppost,"."))*1>0){
          $xsdcd=strlen(hou($tmppost,"."));
          $pdata[$pdata["COLUMN"][$p]]["type"]="decimal(10,".$xsdcd.")";//判断数据类型
         }else{
          $pdata[$pdata["COLUMN"][$p]]["type"]="int(11)";//判断数据类型
         }
        }else{
         $pdata[$pdata["COLUMN"][$p]]["type"]="int(11)";//判断数据类型
        };
    }else{//如果字符串小于230 则都弄成varchar230
      if (strlen($tmppost)<230){
       $pdata[$pdata["COLUMN"][$p]]["type"]="varchar(255)";//判断数据类型
       }else{
       $pdata[$pdata["COLUMN"][$p]]["type"]="text";//判断数据类型
       };
    };//if
   };//if
   //获取字段FUN COLUMN_SPOST 此处tmppost 已经获取并解码了
   if ($gsno*1==0){  //这是准备INSERT的了
    if ($pdata["COLUMN"][$p]==$prisno){
    }else{
     $fmsqlk=$fmsqlk.$pdata["COLUMN"][$p].",";
     $rcvkey=$rcvkey.$pdata["COLUMN"][$p].",";
     $pdata["RECEIVE"][$totrcv]=$pdata["COLUMN"][$p];
     if ($tmppost==""){
       if (strpos("~~~".$tmpfun,"|")>0){
          if (hou("~~~".$tmpfun,"|")!=""){
           eval(hou("~~~".$tmpfun,"|"));
          };
       }else{           
           $tmpfun=tostring($pdata[$pdata["COLUMN"][$p]]["COLUMN_DEFAULT"]);
                if (strpos("~~~".$tmpfun,"defaultv")>0){
                  eval($tmpfun);
                  $tmppost=$defaultv;
                };
       };
     };//如果没有赋值的情况下取此值
     // echo "dxtype--".$alldata[$alldata["COLUMN"][$p]]["COLUMN_DXTYPE"];
      if ($pdata[$pdata["COLUMN"][$p]]["COLUMN_DXTYPE"]=="imagex" or $pdata[$pdata["COLUMN"][$p]]["COLUMN_DXTYPE"]=="images" or $pdata[$pdata["COLUMN"][$p]]["COLUMN_DXTYPE"]=="filex" or $pdata[$alldata["COLUMN"][$p]]["COLUMN_DXTYPE"]=="files"){  
        $tmpomk=dftval($_POST["p_".$priolmk."0"],$_POST["p_".$priolmk]);        
        if ($tmpomk!=""){
            $conn=mysql_connect(gl(),glu(),glp());
            $imrst=selectedx($conn,glb(),"select picurl from coode_itemfile where TABLE_NAME='".$gtnm."' and COLUMN_NAME='".$pdata["COLUMN"][$p]."' and tbsno='".$tmpomk."'","utf8","");
            $newrst=str_replace("#/#",",",hou($imrst,"#/#"));
            
          if ($pdata[$pdata["COLUMN"][$p]]["COLUMN_DXTYPE"]=="imagex" or $pdata[$pdata["COLUMN"][$p]]["COLUMN_DXTYPE"]=="filex"){
             $newrst=anyvalue($imrst,"picurl",0);
          }
            
        }else{//tmpomk
        };
        $tmppost=$newrst;
      };
        if ($alldata["COLUMN"][$p]==$priolmk){
         if ($tmppost==""){
          $tmppost=onlymark();
         }
         $_GET["tmpolmk"]=$tmppost;
        }
        if (strlen($tmppost)>200 or strpos($tmppost,huanhang())>0 ){        
                 $fmsqlv=$fmsqlv.gohex($tmppost)."',";
        }else{
                 if ((str_replace(" ","",$tmppost)=="" or str_replace(" ","",$tmppost)==".") and strlen($tmppost)>0 ){
                   $fmsqlv=$fmsqlv."'',";
                 }else{
                   $fmsqlv=$fmsqlv."'".str_replace(huanhang(),mrmn(),str_replace("'","\'",$tmppost))."',";
                 }
        };                        
     $conn=mysql_connect(gl(),glu(),glp());
     if ($pdata[$pdata["COLUMN"][$p]]["COLUMN_BFIST"]!=""){
       $pdata[$pdata["COLUMN"][$p]]["bfinsert"]=$pdata[$pdata["COLUMN"][$p]]["COLUMN_BFIST"];
     }else{
       $pdata[$pdata["COLUMN"][$p]]["bfinsert"]="";
     };
     $pdata[$pdata["COLUMN"][$p]]["obfinsert"]=$pdata[$pdata["COLUMN"][$p]]["COLUMN_OBFIST"];
     $conn=mysql_connect(gl(),glu(),glp());
     if ($pdata[$pdata["COLUMN"][$p]]["COLUMN_AFTIST"]!=""){
       $pdata[$pdata["COLUMN"][$p]]["aftinsert"]=$pdata[$pdata["COLUMN"][$p]]["COLUMN_AFTIST"];
     }else{
      $pdata[$pdata["COLUMN"][$p]]["aftinsert"]="";
     };
     $pdata[$pdata["COLUMN"][$p]]["oaftinsert"]=$pdata[$pdata["COLUMN"][$p]]["COLUMN_OAFTIST"];
     $totrcv= $totrcv+1;     
    };
   }else{
    //一下是修改
       if ($pdata[$pdata["COLUMN"][$p]]["COLUMN_DXTYPE"]=="imagex" or $pdata[$pdata["COLUMN"][$p]]["COLUMN_DXTYPE"]=="images" or $pdata[$pdata["COLUMN"][$p]]["COLUMN_DXTYPE"]=="filex" or $pdata[$pdata["COLUMN"][$p]]["COLUMN_DXTYPE"]=="files"){  
            $conn=mysql_connect(gl(),glu(),glp());
            $imrst=selectedx($conn,glb(),"select picurl from coode_itemfile where TABLE_NAME='".$gtnm."' and COLUMN_NAME='".$pdata["COLUMN"][$p]."' and (tbsno='".$_GET["SNO"]."' or tbolmk='".$_POST["p_OLMK".$_GET["SNO"]]."')","utf8",""); 
        if (countresult($imrst)>0){
            $newrst=str_replace("#/#",".",hou($imrst,"#/#"));
          if ($pdata[$pdata["COLUMN"][$p]]["COLUMN_DXTYPE"]=="imagex" or $pdata[$pdata["COLUMN"][$p]]["COLUMN_DXTYPE"]=="filex" ){//
             $ptnew=explode(";",$newrst);
             $totpn=count($ptnew);
             $newrst=$ptnew[$totpn-2];
          }          
           $tmppost=$newrst;
        }else{
          $tmppost="";
        }
       };         
    if (strpos("x".unstrs($_POST["p_".$pdata["COLUMN"][$p].$gsno]),"un"."defined")>0 or $tmppost==""){
    // echo "---".qian($tmpfun,"|")."col-".$pdata["COLUMN"][$p]."--=".unstrs($_POST["p_".$pdata["COLUMN"][$p].$gsno]."tmpopost-".$alldata[$alldata["COLUMN"][$p]]["COLUMN_DXTYPE"]);
    }else{
     //echo "_".$pdata["COLUMN"][$p]."_".qian($tmpfun,"|");
     $rcvkey=$rcvkey.$pdata["COLUMN"][$p].",";
     $pdata["RECEIVE"][$totrcv]=$pdata["COLUMN"][$p];
     $conn=mysql_connect(gl(),glu(),glp());
     if ($pdata[$pdata["COLUMN"][$p]]["COLUMN_BFUPD"]!=""){
       $pdata[$pdata["COLUMN"][$p]]["bfupdate"]=$pdata[$pdata["COLUMN"][$p]]["COLUMN_BFUPD"];
     }else{
       $pdata[$pdata["COLUMN"][$p]]["bfupdate"]="";
     };
     $pdata[$pdata["COLUMN"][$p]]["obfupdate"]=$pdata[$pdata["COLUMN"][$p]]["COLUMN_OBFUPD"];
     $conn=mysql_connect(gl(),glu(),glp());
     if ($pdata[$pdata["COLUMN"][$p]]["COLUMN_AFTUPD"]!=""){
       $pdata[$pdata["COLUMN"][$p]]["aftupdate"]=$pdata[$pdata["COLUMN"][$p]]["COLUMN_AFTUPD"];
      }else{
       $pdata[$pdata["COLUMN"][$p]]["aftupdate"]="";
     };
     $pdata[$pdata["COLUMN"][$p]]["oaftupdate"]=$pdata[$pdata["COLUMN"][$p]]["COLUMN_OAFTUPD"];
     $totrcv= $totrcv+1;      
     if (strlen($tmppost)>200 or strpos($tmppost,huanhang())>0 ){       
       $fmsqlk=$fmsqlk.$pdata["COLUMN"][$p]."='".gohex($tmppost)."',";
     }else{
       if ((str_replace(" ","",$tmppost)=="" or str_replace(" ","",$tmppost)==".") and strlen($tmppost)>0 ){
         $fmsqlk=$fmsqlk.$pdata["COLUMN"][$p]."='',";
       }else{
         $fmsqlk=$fmsqlk.$pdata["COLUMN"][$p]."='".str_replace(huanhang(),mrmn(),str_replace("'","\'",$tmppost))."',";
       }
     };
    };  
    
   };//if
 };//for
 if ($rcvkey!=""){
  $fmsqlk=substr($fmsqlk,0,strlen($fmsqlk)-1);
  $fmsqlv=substr($fmsqlv,0,strlen($fmsqlv)-1);
  $rcvkey=substr($rcvkey,0,strlen($rcvkey)-1);
  $pdata['COLUMN']['rcvkey']=$rcvkey;
  if (($gsno*1)==0){
    if ($fmextk==""){
      $pdata['COLUMN']['sqlstr']="insert into ".$gtnm."(".$fmsqlk.")values(".$fmsqlv.")";
    }else{
      $pdata['COLUMN']['sqlstr']="insert into ".$gtnm."(".$fmsqlk.",".$fmextk.")values(".$fmsqlv.",".$fmextv.")";
    }
     $conn=mysql_connect(gl(),glu(),glp());
     if ($pdata[$prisno]["COLUMN_AFTIST"]!=""){
       $pdata["TABLE"]["aftinsert"]=$pdata[$prisno]["COLUMN_AFTIST"];
     }else{
      $pdata["TABLE"]["aftinsert"]="";
     };
     $pdata["TABLE"]["oaftinsert"]=$pdata[$prisno]["COLUMN_OAFTIST"];
     $conn=mysql_connect(gl(),glu(),glp());
       if ($pdata[$prisno]["COLUMN_BFIST"]!=""){
        $pdata["TABLE"]["bfinsert"]=$pdata[$prisno]["COLUMN_BFIST"];
       }else{
        $pdata["TABLE"]["bfinsert"]="";
       }
    $pdata["TABLE"]["sqlaction"]="insert";
  }else{
     $pdata['COLUMN']['sqlstr']="update ".$gtnm." set ".$fmsqlk." where ".$prisno."='".$gsno."'";
     $conn=mysql_connect(gl(),glu(),glp());
     if ($pdata[$prisno]["COLUMN_AFTUPD"]!=""){
        $pdata["TABLE"]["aftupdate"]=$pdata[$prisno]["COLUMN_AFTUPD"];
      }else{
        $pdata["TABLE"]["aftupdate"]="";
      };
      $pdata["TABLE"]["oaftupdate"]=$pdata[$prisno]["COLUMN_OAFTUPD"];
     $conn=mysql_connect(gl(),glu(),glp());
     if ($pdata[$prisno]["COLUMN_BFUPD"]!=""){
       $pdata["TABLE"]["bfupdate"]=$pdata[$prisno]["COLUMN_BFUPD"];
     }else{
      $pdata["TABLE"]["bfupdate"]="";
     };
     $pdata["TABLE"]["obfupdate"]=$pdata[$prisno]["COLUMN_OBFUPD"];
    $pdata["TABLE"]["sqlaction"]="update";
  };
 };
 $pdata["TABLE"]["totrcv"]=$totrcv;
 //echo $pdata['COLUMN']['sqlstr'];
 $garr=$pdata;
 return $garr;
 }
}//class
?>