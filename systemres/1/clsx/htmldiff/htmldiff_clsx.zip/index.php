<?php
class htmldiff{
  public function hdiff($ohtxt,$nhtxt,$mdcset=array(array())){
  $pdata["oldcode"]=$ohtxt;
  $pdata["newcode"]=$nhtxt;
  $cdcenter=hostaddr("coode");
  $rtntxt=request_post("http://".$cdcenter."/localxres/funx/coodediff/?codetype=html",$pdata);
  eval('$rtnt='.$rtntxt.';');
  return $rtnt; 
 }//fun
}//class
?>