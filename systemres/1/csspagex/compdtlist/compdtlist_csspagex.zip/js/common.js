; $(function () {
  "use strict";
  var swiper = new Swiper('.swiper-container-index', {
    pagination: {
      el: '.swiper-pagination-index',
      clickable: true,
    },
  });

  var swiper2 = new Swiper('.swiper-container-cases', {
    cssMode: true,
    slidesPerView: 4,
    spaceBetween: 20,
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    }
  });

  var swiper3 = new Swiper('.swiper-container-honnor', {
    cssMode: true,
    slidesPerView: 4,
    spaceBetween: 20,
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    }
  });

  var swiper4 = new Swiper('.swiper-container-ser', {
    slidesPerView: 5,
    spaceBetween: 20
  });
  // 选项卡
  $('.tabbox').each(function () {
    var that = $(this);
    var tablink = that.find('.titlelink a');
    var tbody = that.find('.probox');
    tablink.hover(function () {
      $(this).addClass('active').siblings().removeClass('active');
      var id = $(this).index();
      tbody.removeClass('current');
      tbody.eq(id).addClass('current');
    })
  })

  var imgMagnifier = $('.imgMagnifier');
  imgMagnifier.click(function () {
    var imgsrc = $(this).attr('src');
    var el = "<div class='magnifier'><div class='centerbox'><span class='closelayer'>×</span><div><img src='" + imgsrc + "'/></div></div></div>";
    $('body').append(el);
  })
  $('body').on('click', '.magnifier', function () {
    $('.magnifier').remove();
  })
  $('body').on('click', '.closelayer', function () {
    $('.magnifier').remove();
  })
  $('body').on('click', '.centerbox', function () {
    return false;
  })

  $(document).ready(function () {}).keydown(
    function (e) {
      if (e.which === 27) {
        $('.magnifier').remove();
      }
    });

  $('.caigou').click(function () {
    var title = $(this).attr('data-title');
    var layerbox = `
          <div class="layerboxCG">
              <div class='inner'>
                  <div class="centerinner">
                      <div class="title"><span>产品采购</span><small class="closely">×</small></div>
                      <div class="info">温度仪表</div>
                      <div class="formbox">
                            <div class="fli"><span>* 数量</span><input type="number" class="proNumber" value="1" min="1" max="9999"  placeholder="请输入您的采购数量"></div>
                            <div class="fli"><span>* 姓名</span><input type="text" class="proUser" placeholder="请输入您的姓名"></div>
                            <div class="fli"><span>* 电话</span><input type="text" class="proTel" placeholder="请输入您的电话"></div>
                      </div>
                      <div class="btngroup"><button class="sentBtn">提交</button><button class="reset">重置</button></div>
                  </div>
              </div>
          </div>
        `;
    $('body').append(layerbox);
  })
  // 删除
  $('body').on('click', '.closely', function () {
    $('.layerboxCG').remove();
  })
  $('body').on('click', '.centerinner', function () {
    return false;
  })

  $(document).ready(function () { }).keydown(
    function (e) {
      if (e.which === 27) {
        $('.layerboxCG').remove();
      }
    });

  $('body').on('click', '.sentBtn', function () {
    var data = {
      proNumber: $.trim($('.proNumber').val()),
      proUser: $.trim($('.proUser').val()),
      proTel: $.trim($('.proTel').val())
    };
    if (data.proNumber > 99999) {
      $(".proNumber").val(999);
      return false;
    }
    if (data.proNumber < 0) {
      $(".proNumber").val(1);
      return false;
    }
    if (!data.proUser || data.proUser.length>5) {
      alert('请输入您的姓名,且姓名长度不能超过五个字');
      $('.proUser').val(" ")
      return false;
    }
    if (!data.proTel) {
      alert('请输入您的电话');
      return false;
    } else {
      if (!(/^1[3456789]\d{9}$/.test(data.proTel))) {
        alert("手机号码有误，请重填");
        $('.proUser').val(" ")
        return false;
      }
    }
    // 执行ajax请求


    // 执行ajax请求
  })

  $('body').on('click', '.reset', function () {
    resetform();
  })
  function resetform() {
    $('.proNumber').val(1);
    $('.proUser').val("");
    $('.proTel').val("");
  }
})