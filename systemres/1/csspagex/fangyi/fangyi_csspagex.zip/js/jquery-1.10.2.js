
/*当前为字节跳动cdn公共库提供的jQuery-1.10.2*/
document.write("<script src='https://s1.pstatp.com/cdn/expire-1-M/jquery/1.10.2/jquery.min.js'><\/script>");
