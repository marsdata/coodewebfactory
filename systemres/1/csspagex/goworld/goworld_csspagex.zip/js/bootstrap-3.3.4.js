
/*当前为百度cdn公共库提供的bootstrap-3.3.4*/
document.write("<script src='https://apps.bdimg.com/libs/bootstrap/3.3.4/js/bootstrap.min.js'><\/script>");
