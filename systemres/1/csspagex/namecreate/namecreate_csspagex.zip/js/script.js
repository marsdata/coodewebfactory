function fly(){
		const	form = document.querySelector('form'), 
					msgBox= form.querySelector('textArea')
		const inputs = form.querySelectorAll('input')
    const btn= document.querySelector('#send');
		const thanks =document.querySelector('#thanks');
    const plane= document.querySelector('.svg-container')
	  btn.addEventListener('mouseup', (e)=>e.preventDefault())
		btn.addEventListener('mouseup', animatePlane)
		btn.addEventListener('mouseup', thankYouMessage)
		function thankYouMessage(){

			var tl = new TimelineMax({onComplete:clearMessage});
        tl.to('#thanks', .3, {scaleY:1, ease:Power2.easeIn})
				
		}
	function clearMessage(){
		//clears inputs
		const clearedInputs= inputs.forEach(input=>{
			input.value =""
		})
		//clears textarea
		msgBox.value=''
		//removes thankyou msg
		setTimeout(()=>{
			var tl = new TimelineMax()
			tl.to('#thanks', .3, {scaleY:0, ease:Power2.easeIn})
		},2000)
	}
    function animatePlane(){
        var tl = new TimelineMax({onComplete:remove});
        tl.fromTo('.svg-container', .2, 
					{
					xPercent:0,
					rotation:0,
					},
					{
						xPercent:100,
						ease:Power0.easeNone
						
					}			 
				 )
				.to('.svg-container', .5, {
							xPercent:200,
							rotation:-360,
							scale:.8,
						ease:Power0.easeNone,
						transformOrigin: "center -100%",
					})
				.to('.svg-container', .4, {
					x:800, 
					y:-300,
					scale:2.5,
					ease:Power0.easeNone,
				})
            
    }
    function remove(){
        var tl = new TimelineMax()
			//	plane.style.transform= `translate3d(-100vw, 0,0)`
				tl.fromTo('.svg-container', 1, 
									{x:-700, rotation:60}, 
									{transform:`translate3d(0, 0,0)`, ease:Power4.easeOut})
					
		}
}
window.onload = fly()