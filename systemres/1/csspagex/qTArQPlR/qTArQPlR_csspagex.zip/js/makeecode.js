function tempunit(mk,parmk){
    switch(mk){
        case "O":
        //O1
        dcode=spacex(parmk.length*2)+spacex(2)+'<div id="[parmk]O1" class="[parmk]O1class" [parmk]O1hcode style="width:100%;height:100%;[parmk]O1style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'[parmk]O1INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(2)+'</div>'+huanhang();
        dcode=dcode.replace(/\[parmk\]/g,parmk);
         return dcode;
        break;
        case "A":
        //Asrd,A1,A2A3Srd,A2,A3
        dcode=spacex(parmk.length*2)+spacex(2)+'<div id="[parmk]ASrd" class="[parmk]ASrdclass" [parmk]ASrdhcode style="width:100%;height:100%;[parmk]ASrdstyle">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]A1" class="[parmk]A1class" [parmk]A1hcode style="width:100%;[parmk]A1style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]A1INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]A2A3Srd" class="[parmk]A2A3Srdclass" [parmk]A2A3Srdhcode style="width:100%;[parmk]A2A3Srdstyle">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'<div id="[parmk]A2" class="[parmk]A2class" [parmk]A2hcode style="width:50%;float:left;[parmk]A2style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(14)+'[parmk]A2INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'<div id="[parmk]A3" class="[parmk]A3class" [parmk]A3hcode style="width:50%;float:left;[parmk]A3style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(14)+'[parmk]A3INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(2)+'</div>'+huanhang();
        dcode=dcode.replace(/\[parmk\]/g,parmk);
         return dcode;
        break;
        case "V":
        //VSrd,V1V2Srd,V1,v2,v3
        dcode=spacex(parmk.length*2)+spacex(2)+'<div id="[parmk]VSrd" class="[parmk]VSrdclass" [parmk]VSrdhcode style="width:100%;height:100%;[parmk]VSrdstyle">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]V1V2Srd" class="[parmk]V1V2Srdclass" [parmk]V1V2Srdhcode style="width:100%;[parmk]V1V2Srdstyle">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'<div id="[parmk]V1" class="[parmk]V1class" [parmk]V1hcode style="width:50%;float:left;[parmk]V1style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(14)+'[parmk]V1INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'<div id="[parmk]V2" class="[parmk]V2class" [parmk]V2hcode style="width:50%;float:left;[parmk]V2style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(14)+'[parmk]V2INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]V3" class="[parmk]V3class" [parmk]V3hcode style="width:100%;[parmk]V3style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]V3INNER</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode.replace(/\[parmk\]/g,parmk);
         return dcode;
        break;
        case "C":
        //Csrd,C1C2Srd,C1,C2,C3C4Srd,C3,C4
        dcode=spacex(parmk.length*2)+spacex(2)+'<div id="[parmk]CSrd" class="[parmk]CSrdclass" [parmk]CSrdhcode style="width:100%;height:100%;[parmk]CSrdstyle">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]C1C2Srd" class="[parmk]C1C2srdclass" [parmk]C1C2srdhcode style="width:100%;height:50%;[parmk]C1C2Srdstyle">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'<div id="[parmk]C1" class="[parmk]C1class" [parmk]C1hcode style="width:50%;height:100%;float:left;[parmk]C1style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(14)+'[parmk]C1INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'<div id="[parmk]C2" class="[parmk]C2class" [parmk]C2hcode style="width:50%;height:100%;float:left;[parmk]C2style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(14)+'[parmk]C2INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]C3C4Srd" class="[parmk]C3C4Srdclass" [parmk]C3C4Srdhcode style="width:100%;[parmk]C3C4Srdstyle">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'<div id="[parmk]C3" class="[parmk]C3class" [parmk]C3hcode style="width:50%;height:100%;float:left;[parmk]C3style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(14)+'[parmk]C3INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'<div id="[parmk]C4" class="[parmk]C4class" [parmk]C4hcode style="width:50%;height:100%;float:left;[parmk]C4style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(14)+'[parmk]C4INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(2)+'</div>'+huanhang();
        dcode=dcode.replace(/\[parmk\]/g,parmk);
               return dcode;
        break;
        case "H":
        //HSrd,H1,H2
        dcode=spacex(parmk.length*2)+spacex(2)+'<div id="[parmk]HSrd" class="[parmk]HSrdclass" [parmk]HSrdhcode style="width:100%;height:100%;[parmk]HSrdstyle">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]H1" class="[parmk]H1class" [parmk]H1hcode style="width:100%;[parmk]H1style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]H1INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]H2" class="[parmk]H2class" [parmk]H2hcode style="width:100%;[parmk]H2style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]H2INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(2)+'</div>'+huanhang();
        dcode=dcode.replace(/\[parmk\]/g,parmk);
         return dcode;
        break;
        case "N":
        //NSrd,N1,N2
        dcode=spacex(parmk.length*2)+spacex(2)+'<div id="[parmk]NSrd" class="[parmk]NSrdclass" [parmk]NSrdhcode style="width:100%;height:100%;[parmk]NSrdstyle">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]N1" class="[parmk]N1class" [parmk]N1hcode style="width:50%;height:100%;float:left;[parmk]N1style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]N1INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]N2" class="[parmk]N2class" [parmk]N2hcode style="width:50%;height:100%;float:left;[parmk]N2style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]N2INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(2)+'</div>'+huanhang();
        dcode=dcode.replace(/\[parmk\]/g,parmk);
        return dcode;
        break;
        case "M":
        //MSrd,M1,M2,M3
        dcode=spacex(parmk.length*2)+spacex(2)+'<div id="[parmk]MSrd" class="[parmk]MSrdclass" [parmk]MSrdhcode style="width:100%;height:100%;[parmk]MSrdstyle">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]M1" class="[parmk]M1class" [parmk]M1hcode style="width:33.33%;height:100%;float:left;[parmk]M1style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]M1INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]M2" class="[parmk]M2class" [parmk]M2hcode style="width:33.33%;height:100%;float:left;[parmk]M2style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]M2INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]M3" class="[parmk]M3class" [parmk]M3hcode style="width:33.33%;height:100%;float:left;[parmk]M3style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]M3INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(2)+'</div>'+huanhang();
        dcode=dcode.replace(/\[parmk\]/g,parmk);
         return dcode;
        break;
        case "W":
        //WSrd,W1,W2,W3,W4
        dcode=spacex(parmk.length*2)+spacex(2)+'<div id="[parmk]WSrd" class="[parmk]WSrdclass" [parmk]WSrdhcode style="width:100%;height:100%;[parmk]WSrdstyle">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]W1" class="[parmk]W1class" [parmk]W1hcode style="width:25%;height:100%;float:left;[parmk]W1style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]W1INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]W2" class="[parmk]W2class" [parmk]W2hcode style="width:25%;height:100%;float:left;[parmk]W2style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]W2INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]W3" class="[parmk]W3class" [parmk]W3hcode style="width:25%;height:100%;float:left;[parmk]W3style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]W3INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]W4" class="[parmk]W4class" [parmk]W4hcode style="width:25%;height:100%;float:left;[parmk]W4style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]W4INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(2)+'</div>'+huanhang();
        dcode=dcode.replace(/\[parmk\]/g,parmk);
         return dcode;
        break;
        case "E":
        //ESrd,E1,E2,E3
        dcode=spacex(parmk.length*2)+spacex(2)+'<div id="[parmk]ESrd" class="[parmk]ESrdclass" [parmk]ESrdhcode style="width:100%;height:100%;[parmk]ESrdstyle">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]E1" class="[parmk]E1class" [parmk]E1hcode style="width:100%;[parmk]E1style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]E1INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]E2" class="[parmk]E2class" [parmk]E2hcode style="width:100%;[parmk]E2style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]E2INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]E3" class="[parmk]E3class" [parmk]E3hcode style="width:100%;[parmk]E3style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]E3INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(2)+'</div>'+huanhang();
        dcode=dcode.replace(/\[parmk\]/g,parmk);
               return dcode;
        break;
        case "F":
        //FSrd,F1,F2,F3,F4
        dcode=spacex(parmk.length*2)+spacex(2)+'<div id="[parmk]FSrd" class="[parmk]FSrdclass" [parmk]FSrdhcode style="width:100%;height:100%;[parmk]FSrdstyle">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]F1" class="[parmk]F1class" [parmk]F1hcode style="width:100%;[parmk]F1style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]F1INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]F2" class="[parmk]F2class" [parmk]F2hcode style="width:100%;[parmk]F2style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]F2INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]F3" class="[parmk]F3class" [parmk]F3hcode style="width:100%;[parmk]F3style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]F3INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'<div id="[parmk]F4" class="[parmk]F4class" [parmk]F4hcode style="width:100%;[parmk]F4style">'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(10)+'[parmk]F4INNER'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(6)+'</div>'+huanhang();
        dcode=dcode+spacex(parmk.length*2)+spacex(2)+'</div>'+huanhang();
        dcode=dcode.replace(/\[parmk\]/g,parmk);
               return dcode;
        break;
        default:
    }
}
function comcode(expx,parmk){
    if (expx.indexOf("=")>0){
        mkx=qian(expx,"=");
        mvy=hou(expx,"=");
        leftx="";
        switch(mkx){
            case "A":
            if (mvy.length==3){
                leftx=tempunit("A",parmk);
                leftx=leftx.replace(parmk+"A1INNER",tempunit(mvy[0],parmk+"A1"));
                leftx=leftx.replace(parmk+"A2INNER",tempunit(mvy[1],parmk+"A2"));
                leftx=leftx.replace(parmk+"A3INNER",tempunit(mvy[2],parmk+"A3"));
                return leftx;
            }else{
                leftx=tempunit("A",parmk);
                return leftx;
            }
            break;
            case "V":
            if (mvy.length==3){
                leftx=tempunit("V",parmk);
                leftx=leftx.replace(parmk+"V1INNER",tempunit(mvy[0],parmk+"V1"));
                leftx=leftx.replace(parmk+"V2INNER",tempunit(mvy[1],parmk+"V2"));
                leftx=leftx.replace(parmk+"V3INNER",tempunit(mvy[2],parmk+"V3"));
                return leftx;
            }else{
                leftx=tempunit("V",parmk);
                return leftx;
            }
            break;
            case "C":
            if (mvy.length==4){
                leftx=tempunit("C",parmk);
                leftx=leftx.replace(parmk+"C1INNER",tempunit(mvy[0],parmk+"C1"));
                leftx=leftx.replace(parmk+"C2INNER",tempunit(mvy[1],parmk+"C2"));
                leftx=leftx.replace(parmk+"C3INNER",tempunit(mvy[2],parmk+"C3"));
                leftx=leftx.replace(parmk+"C4INNER",tempunit(mvy[3],parmk+"C4"));
                return leftx;
            }else{
                leftx=tempunit("C",parmk);
                return leftx;
            }
            break;
            case "H":
            if (mvy.length==2){
                leftx=tempunit("H",parmk);
                leftx=leftx.replace(parmk+"H1INNER",tempunit(mvy[0],parmk+"H1"));
                leftx=leftx.replace(parmk+"H2INNER",tempunit(mvy[1],parmk+"H2"));
                return leftx;
            }else{
                leftx=tempunit("H",parmk);
                return leftx;
            }
            break;
            case "N":
            if (mvy.length==2){
                leftx=tempunit("N",parmk);
                leftx=leftx.replace(parmk+"N1INNER",tempunit(mvy[0],parmk+"N1"));
                leftx=leftx.replace(parmk+"N2INNER",tempunit(mvy[1],parmk+"N2"));
                return leftx;
            }else{
                leftx=tempunit("N",parmk);
                return leftx;
            }
            break;
            case "M":
            if (mvy.length==3){
                leftx=tempunit("M",parmk);
                leftx=leftx.replace(parmk+"M1INNER",tempunit(mvy[0],parmk+"M1"));
                leftx=leftx.replace(parmk+"M2INNER",tempunit(mvy[1],parmk+"M2"));
                leftx=leftx.replace(parmk+"M3INNER",tempunit(mvy[2],"M3"));
                return leftx;
            }else{
                leftx=tempunit("M",parmk);
                return leftx;
            }
            break;
            case "W":
            if (mvy.length==4){
                leftx=tempunit("W",parmk);
                leftx=leftx.replace(parmk+"W1INNER",tempunit(mvy[0],parmk+"W1"));
                leftx=leftx.replace(parmk+"W2INNER",tempunit(mvy[1],parmk+"W2"));
                leftx=leftx.replace(parmk+"W3INNER",tempunit(mvy[2],parmk+"W3"));
                leftx=leftx.replace(parmk+"W4INNER",tempunit(mvy[3],parmk+"W4"));
                return leftx;
            }else{
                leftx=tempunit("W",parmk);
                return leftx;
            }
            break;
            case "E":
            if (mvy.length==3){
                leftx=tempunit("E",parmk);
                leftx=leftx.replace(parmk+"E1INNER",tempunit(mvy[0],parmk+"E1"));
                leftx=leftx.replace(parmk+"E2INNER",tempunit(mvy[1],parmk+"E2"));
                leftx=leftx.replace(parmk+"E3INNER",tempunit(mvy[2],parmk+"E3"));
                return leftx;
            }else{
                leftx=tempunit("E",parmk);
                return leftx;
            }
            break;
            case "F":
            if (mvy.length==4){
                leftx=tempunit("F",parmk);
                leftx=leftx.replace(parmk+"F1INNER",tempunit(mvy[0],parmk+"F1"));
                leftx=leftx.replace(parmk+"F2INNER",tempunit(mvy[1],parmk+"F2"));
                leftx=leftx.replace(parmk+"F3INNER",tempunit(mvy[2],parmk+"F3"));
                leftx=leftx.replace(parmk+"F4INNER",tempunit(mvy[3],parmk+"F4"));
                return leftx;
            }else{
                leftx=tempunit("F",parmk);
                return leftx;
            }
            break;
            default:
        }
    }else{
        return "";
    }
}
function tempele(mk,parmk){
    fme="";
    switch(mk){
        case "O":
        //O1
        fme=parmk+"O1,";
        return fme;
        break;
        case "A":
        fme=parmk+"A1,"+parmk+"A2,"+parmk+"A3,";
        return fme;
        break;
        case "V":
        //VSrd,V1V2Srd,V1,v2,v3
        fme=parmk+"V1,"+parmk+"V2,"+parmk+"V3,";
        return fme;
        break;
        case "C":
        fme=parmk+"C1,"+parmk+"C2,"+parmk+"C3,"+parmk+"C4,";
         return fme;
        break;
        case "H":
        //HSrd,H1,H2
        fme=parmk+"H1,"+parmk+"H2,";
        return fme;
        break;
        case "N":
        //NSrd,N1,N2
        fme=parmk+"N1,"+parmk+"N2,";
        return fme;
        break;
        case "M":
        //MSrd,M1,M2,M3
        fme=parmk+"M1,"+parmk+"M2,"+parmk+"M3,";
        return fme;
        break;
        case "W":
        //WSrd,W1,W2,W3,W4
        fme=parmk+"W1,"+parmk+"W2,"+parmk+"W3,"+parmk+"W4,";
         return fme;
        break;
        case "E":
        //ESrd,E1,E2,E3
        fme=parmk+"E1,"+parmk+"E2,"+parmk+"E3,";
        return fme;
        break;
        case "F":
        //FSrd,F1,F2,F3,F4
        fme=parmk+"F1,"+parmk+"F2,"+parmk+"F3,"+parmk+"F4,";
        return fme;
        break;
        default:
        fme=parmk+mk+"x,";
        return fme;
    }
}
function comeles(expx,parmk){
    if (expx.indexOf("=")>0){
        mkx=qian(expx,"=");
        mvy=hou(expx,"=");
        leftx="";
        fma="";
        fmb="";
        switch(mkx){
            case "A":
            if (mvy.length==3){
                fma="A1,A2,A3";
                fmb=fmb+tempele(mvy[0],parmk+"A1");
                fmb=fmb+tempele(mvy[1],parmk+"A2");
                fmb=fmb+tempele(mvy[2],parmk+"A3");
            }else{
                fma="A1,A2,A3";
                fmb="";
            }
            break;
            case "V":
            if (mvy.length==3){
                fma="V1,V2,V3";
                fmb=fmb+tempele(mvy[0],parmk+"V1");
                fmb=fmb+tempele(mvy[1],parmk+"V2");
                fmb=fmb+tempele(mvy[2],parmk+"V3");
            }else{
                fma="V1,V2,V3";
                fmb="";
            }
            break;
            case "C":
            if (mvy.length==4){
                fma="C1,C2,C3,C4";
                fmb=fmb+tempele(mvy[0],parmk+"C1");
                fmb=fmb+tempele(mvy[1],parmk+"C2");
                fmb=fmb+tempele(mvy[2],parmk+"C3");
                fmb=fmb+tempele(mvy[3],parmk+"C4");
            }else{
                fma="C1,C2,C3,C4";
                fmb="";
            }
            break;
            case "H":
            if (mvy.length==2){
                fma="H1,H2";
                fmb=fmb+tempele(mvy[0],parmk+"H1");
                fmb=fmb+tempele(mvy[1],parmk+"H2");
            }else{
                fma="H1,H2";
                fmb="";
            }
            break;
            case "N":
            if (mvy.length==2){
                fma="N1,N2";
                fmb=fmb+tempele(mvy[0],parmk+"N1");
                fmb=fmb+tempele(mvy[1],parmk+"N2");
            }else{
                fma="N1,N2";
                fmb="";
            }
            break;
            case "M":
            if (mvy.length==3){
                fma="N1,N2";
                fmb=fmb+tempele(mvy[0],parmk+"M1");
                fmb=fmb+tempele(mvy[1],parmk+"M2");
            }else{
                fma="M1,M2";
                fmb="";
            }
            break;
            case "W":
            if (mvy.length==4){
                fma="W1,W2,W3,W4";
                fmb=fmb+tempele(mvy[0],parmk+"W1");
                fmb=fmb+tempele(mvy[1],parmk+"W2");
                fmb=fmb+tempele(mvy[2],parmk+"W3");
                fmb=fmb+tempele(mvy[3],parmk+"W4");
                
            }else{
                fma="W1,W2,W3,W4";
                fmb="";
            }
            break;
            case "E":
            if (mvy.length==3){
                fma="E1,E2,E3";
                fmb=fmb+tempele(mvy[0],parmk+"E1");
                fmb=fmb+tempele(mvy[1],parmk+"E2");
                fmb=fmb+tempele(mvy[2],parmk+"E3");

            }else{
                fma="E1,E2,E3";
                fmb="";
            }
            break;
            case "F":
            if (mvy.length==4){
                fma="F1,F2,F3,F4";
                fmb=fmb+tempele(mvy[0],parmk+"F1");
                fmb=fmb+tempele(mvy[1],parmk+"F2");
                fmb=fmb+tempele(mvy[2],parmk+"F3");
                fmb=fmb+tempele(mvy[3],parmk+"F4");
            }else{
                fma="F1,F2,F3,F4";
                fmb="";
            }
            break;
            default:
                fma=mkx;
                fmb="";
        }
        return parmk+"@"+fma+"/"+fmb;
    }else{
        return "";
    }
}
 function formimgcode(mksno,w,h,idx,clsx){
     if (intval(w)>0 && intval(h)>0){
      if (intval(mksno)>0 ){
          return '<img id="'+idx+'" class="'+clsx+'" src="/localxres/funx/anyimg/?SNO='+mksno+'" style="width:'+w+'px;height:'+h+'px;">';
      }else{
          return '<img id="'+idx+'" class="'+clsx+'" src="/localxres/funx/anyimg/?mark='+mksno+'" style="width:'+w+'px;height:'+h+'px;">';
      }
     }else{
         return "";
     }
  }
  function fmduoselect(fk,fv,pv,fid,fcls,fcdes){
 if (fk.indexOf("/")>0){
 ptfk=fk.split("/");
 }else{
 ptfk=fk.split(",");
 };
 if (fv.indexOf("/")>0){
 ptfv=fv.split("/");
 }else{
 ptfv=fv.split(",");
 };
 if (ptfk.length<=15){
 var fm="";
 if (ptfk.length>0){
 for (fi=0;fi<ptfk.length;fi++){
   if (("-"+pv).indexOf(ptfv[fi])>0){
   fm=fm+"<label><input type=\"checkbox\" name=\""+fid+"\" class=\""+fcls+"\" "+fcdes+" value=\""+ptfv[fi]+"\" checked>"+ptfk[fi]+"</label>";
   }else{
   fm=fm+"<label><input type=\"checkbox\" name=\""+fid+"\" class=\""+fcls+"\" "+fcdes+" value=\""+ptfv[fi]+"\">"+ptfk[fi]+"</label>";
   };
 };
  };
 return fm;

 }else{

 };
}
 function formselect($opname,$opvalue,$prevalue,$selectselfname,$selectselfclass,$htmcod){
//layui 专用单选，带样式
 tmpvx="";
 smd5=$opname+$opvalue+$prevalue+$selectselfname+$selectselfclass+$htmcod;
 smd5="a"+smd5.MD5();
 eval('tmpvx=sessionStorage.'+smd5+';');
 if (tmpvx!="" && tmpvx!=undefined){
     //console.log("rtn.".smd5);
   return tmpvx;
 }else{
     
  $partopname=explode(",",$opname);
  $partopvalue=explode(",",$opvalue);
  $totopnm=countx($partopname);
  $totopvl=countx($partopvalue);
  $sfxz=0;
  $formselects="";
  $onlyone="";
  //console.log("tottopnm"+$totopnm+"--"+$totopvl);
  if ($totopnm==$totopvl){
    if ($htmcod.indexOf("nchange")>0){
       $lf=" lay-filter=\"brickType\" ";
     }else{
       $lf="";
     }
     $formselects=$formselects+"<SELECT id=\""+$selectselfname+"\" name=\""+$selectselfname+"\" "+$htmcod+$lf+" lay-search class=\""+$selectselfclass+"\" >\r\n";
      $formselects=$formselects+"<option value=\".\" >无选项</option>\r\n";   

   for ($tempk=0;$tempk<=$totopnm-1;$tempk++){
       if ($partopvalue[$tempk]!="" && $partopname[$tempk]!=""){
        if ($partopvalue[$tempk]==$prevalue || $partopname[$tempk]==$prevalue) {
         $sfxz=$sfxz+1;  
         $formselects=$formselects+"<option value=\""+$partopvalue[$tempk]+"\" selected>"+$partopname[$tempk]+"</option>\r\n";
         $onlyone=$partopname[$tempk];
        }else{
         $formselects=$formselects+"<option value=\""+$partopvalue[$tempk]+"\" >"+$partopname[$tempk]+"</option>\r\n";   
        };
       }
   };
   if ($prevalue!="" && $sfxz==0){
       $formselects=$formselects+"<option value=\""+$prevalue+"\" selected>"+$prevalue+"</option>\r\n";   
   }
   $formselects=$formselects+"</SELECT>\r\n";
 };  
  eval('sessionStorage.'+smd5+'=$formselects;');
  return $formselects;  
 }
}
 function formselectonly($opname,$opvalue,$prevalue,$selectselfname,$selectselfclass,$htmcod){
 tmpvx="";
 smd5=$opname+$opvalue+$prevalue+$selectselfname+$selectselfclass+$htmcod;
 smd5="a"+smd5.MD5();
 eval('tmpvx=sessionStorage.'+smd5+';');
 if (tmpvx!="" && tmpvx!=undefined){
   return tmpvx;
 }else{
  $partopname=explode(",",$opname);
  $partopvalue=explode(",",$opvalue);
  $totopnm=countx($partopname);
  $totopvl=countx($partopvalue);
  $sfxz=0;
  $formselects="";
  $onlyone="";
  if ($totopnm==$totopvl){
     if ($htmcod.indexOf("nchange")>0){
       $lf=" lay-filter=\"brickType\" ";
     }else{
       $lf="";
     }
     $formselects=$formselects+"<SELECT id=\""+$selectselfname+"\" name=\""+$selectselfname+"\" "+$htmcod+$lf+" lay-search readonly class=\""+$selectselfclass+"\" >\r\n";
    for ($tempk=0;$tempk<=$totopnm-1;$tempk++){
       if ($partopvalue[$tempk]==$prevalue || $partopname[$tempk]==$prevalue) {
         $sfxz=$sfxz+1;  
         $formselects=$formselects+"<option value=\""+$partopvalue[$tempk]+"\" selected>"+$partopname[$tempk]+"</option>\r\n";
         $onlyone=$partopname[$tempk];
        };
    };
    //如果未发现CLSTXT则直接引用下面的值  这还是LAYUI单选，禁止选其他项目
    if ($prevalue!="" && $sfxz==0){
       $formselects=$formselects+"<option value=\""+$prevalue+"\" selected>"+$prevalue+"</option>\r\n";   
    }
    $formselects=$formselects+"</SELECT>\r\n";
  };  
  eval('sessionStorage.'+smd5+'=$formselects;');
  return $formselects;  
 }
}
function formselecty($opname,$opvalue,$prevalue,$selectselfname,$selectselfclass,$htmcod){
//layui的多选
 tmpvx="";
 smd5=$opname+$opvalue+$prevalue+$selectselfname+$selectselfclass+$htmcod;
 smd5="a"+smd5.MD5();
 eval('tmpvx=sessionStorage.'+smd5+';');
 if (tmpvx!="" && tmpvx!=undefined){
   return tmpvx;
 }else{
   $partopname=explode(",",$opname);
   $partopvalue=explode(",",$opvalue);
   $totopnm=countx($partopname);
   $totopvl=countx($partopvalue);
   $sfxz=0;
   $formselects="";
   $onlyone="";  
  if ($totopnm==$totopvl){
     $formselects=$formselects+"<select id=\""+$selectselfname+"\" name=\""+$selectselfname+"\" "+$htmcod+"  multiple lay-search lay-case class=\""+$selectselfclass+"\" >\r\n";
     $formselects=$formselects+"<option value=\".\" >[exp]</option>\r\n";   
   for ($tempk=0;$tempk<=$totopnm-1;$tempk++){
    if ($partopvalue[$tempk]==$prevalue || $partopname[$tempk]==$prevalue) {
      $sfxz=$sfxz+1;  
      $formselects=$formselects+"<option value=\""+$partopvalue[$tempk]+"\" selected>"+$partopname[$tempk]+"</option>\r\n";
      $onlyone=$partopname[$tempk];
    }else{
         $formselects=$formselects+"<option value=\""+$partopvalue[$tempk]+"\" >"+$partopname[$tempk]+"</option>\r\n";   
    };//if
   };//for
   if ($prevalue!="" && $sfxz==0){
       $formselects=$formselects+"<option value=\""+$prevalue+"\" selected >"+$prevalue+"</option>\r\n";   
   }
    $formselects=$formselects+"</select>\r\n";  
  };
  eval('sessionStorage.'+smd5+'=$formselects;');
  return $formselects;
 }
}
function formselectyonly($opname,$opvalue,$prevalue,$selectselfname,$selectselfclass,$htmcod){
 tmpvx="";
 smd5=$opname+$opvalue+$prevalue+$selectselfname+$selectselfclass+$htmcod;
 smd5="a"+smd5.MD5();
 eval('tmpvx=sessionStorage.'+smd5+';');
 if (tmpvx!="" && tmpvx!=undefined){
   return tmpvx;
 }else{
   $partopname=explode(",",$opname);
   $partopvalue=explode(",",$opvalue);
   $totopnm=countx($partopname);
   $totopvl=countx($partopvalue);
   $sfxz=0;
   $formselects="";
   $onlyone="";  
  if ($totopnm==$totopvl){
     $formselects=$formselects+"<select id=\""+$selectselfname+"\" name=\""+$selectselfname+"\" "+$htmcod+"  multiple lay-search lay-case class=\""+$selectselfclass+"\" >\r\n";
     
   for ($tempk=0;$tempk<=$totopnm-1;$tempk++){
    if ($partopvalue[$tempk]==$prevalue || $partopname[$tempk]==$prevalue) {
      $sfxz=$sfxz+1;  
      $formselects=$formselects+"<option value=\""+$partopvalue[$tempk]+"\" selected>"+$partopname[$tempk]+"</option>\r\n";
      $onlyone=$partopname[$tempk];
    };//if
   };//for
   //只有一个值，禁止选其他的
   if ($prevalue!="" && $sfxz==0){
       $formselects=$formselects+"<option value=\""+$prevalue+"\" selected >"+$prevalue+"</option>\r\n";   
   }
    $formselects=$formselects+"</select>\r\n";  
  };
  eval('sessionStorage.'+smd5+'=$formselects;');
  return $formselects;
 }
}
function makeclssrditem(srdcode,itemcode,clstxtx){
    clstt=qian(clstxtx,"|");
    clsmk=hou(clstxtx,"|");
    pttt=clstt.split(",");
    ptmk=clsmk.split(",");
    totpt=pttt.length;
    fmit="";
    if (totpt==ptmk.length){
     for (i=0;i<totpt;i++){
        itemx=itemcode;
        itemx=itemx.replace(/\[srctitle\]/g,pttt[i]);
        itemx=itemx.replace(/\[srcid\]/g,ptmk[i]);
        fmit=fmit+itemx;
     }
     srdcode=srdcode.replace("\[inner\]",fmit)
     return srdcode;
    }else{
        return "";
    }
}
function listenclsduo(){
  $(".fs-option").click(function(){
  var xx=$("dd");
  totdd=xx.length;
  for (k=0;k<totdd;k++){
  tmpvvv=$(xx[k]).attr("lay-value");
  if (tmpvvv.indexOf("--")>0){
   $(xx[k]).parent().parent().hide();
  };
  };
  	var tmpcss=$(this).attr("class");
   tmpab=$(this).attr("data-value");
   tmpaq=qian(tmpab,"--");
   tmpav=hou(tmpab,"--");
   var slctx=$(".selected");
		 totx=slctx.length;
		 tmpz="";
		 stktmpvx=new Array();
		 //console.log("totx-"+totx);
		  for (i=0;i<totx;i++){
     tmpvx="";
     tmpq="";
     tmpv="";
    tmpvx=$(slctx[i]).attr("data-value");
    stktmpvx[i]=tmpvx;
    tmpq=qian(tmpvx,"--");
    tmpv=hou(tmpvx,"--");
    if (tmpaq==tmpq){
	    eval(tmpq+"='';");
    }
		  };
		  for (j=0;j<totx;j++){
		  tmpz="";
    tmpvx=stktmpvx[j];
    tmpq=qian(tmpvx,"--");
    tmpv=hou(tmpvx,"--");
    if (tmpq==tmpaq){
     eval(tmpq+"="+tmpq+"+'"+tmpv+",';");
     eval("tmpz="+tmpq+';');
	   $("#"+tmpq).val(onlyone(tmpz,","));
    }
		  };
	 var tmpcss=$(this).attr("class");
  tmpvb=$(this).attr("data-value");
  tmpbq=qian(tmpvb,"--");
  tmpbv=hou(tmpvb,"--");
	 if (tmpcss.indexOf("selected")>0){
  eval(tmpbq+"="+tmpbq+".replace('"+tmpbv+",','');");
  eval(tmpbq+"="+tmpbq+".replace('"+tmpbv+",','');");
  eval("tmpz="+tmpbq);
  $("#"+tmpbq).val(onlyone(tmpz,","));
   }else{
  eval("tpof=typeof("+tmpbq+");");
  if (tpof=="object"){
   eval(tmpbq+"='';");
  }
  eval(tmpbq+"="+tmpbq+"+'"+tmpbv+",';");
  eval("tmpz="+tmpbq+";");
  $("#"+tmpbq).val(onlyone(tmpz,","));
  };
   });
   
}
function formselectx($opname,$opvalue,$prevalue,$selectselfname,$selectselfclass,$htmcod){
 //复核选项，专门给特定layui 里多选用的
 tmpvx="";
 smd5=$opname+$opvalue+$prevalue+$selectselfname+$selectselfclass+$htmcod;
 smd5="a"+smd5.MD5();
eval('tmpvx=sessionStorage.'+smd5+';');
if (tmpvx!="" && tmpvx!=undefined){
  return tmpvx;
 }else{
 $partopname=explode(",","无选项,"+$opname);
 $partopvalue=explode(",",".,"+$opvalue);
 $totopnm=countx($partopname);
 $totopvl=countx($partopvalue);
 $sfxz=0;
 $formselects="\r\n";
 if ($totopnm==$totopvl){
   $formselects=$formselects+"<select  name=\"sl"+$selectselfname+"\"  "+$htmcod+" class=\""+$selectselfname+"\" lay-ignore=\"1\"  style=\"float:right;width:0px;height:0px;\" multiple=\"multiple\">\r\n";
   $formselects=$formselects+"<optgroup label=\""+$selectselfname+"\"  >\r\n";
   for ($tempk=0;$tempk<=$totopnm-1;$tempk++){
  if (strpos("xx-"+$prevalue+",",$partopvalue[$tempk]+",")>0){
  $sfxz=$sfxz+1;  
  $formselects=$formselects+"<option value=\""+$selectselfname+"--"+$partopvalue[$tempk]+"\" selected >"+$partopname[$tempk]+"</option>\r\n";
  }else{
  $formselects=$formselects+"<option value=\""+$selectselfname+"--"+$partopvalue[$tempk]+"\"  >"+$partopname[$tempk]+"</option>\r\n";
  };
   };
  $formselects=$formselects+"</optgroup>\r\n</select>\r\n";
 }; 
  eval('sessionStorage.'+smd5+'=$formselects;');
  return $formselects;
 }
}
function refreshselectx(xsrd,xid,xval,ytid,ykey){
    if (ytid!="" && xsrd!="" && xid!="" && xval!="" && ykey!=""){
        bktxt=ajaxhtmlpost("/localxres/funx/anyshort/?stid="+ytid+"&"+ykey+"="+xval,"");
        slq=qian(bktxt,"|");
        slh=hou(bktxt,"|");
        xhtml=formselect(slq,slh,"",xid,"","");
        $("#"+xsrd).html(xhtml);
        return xhtml;
    }else{
        return "";
    }
}
function refreshselect(elsrd,elid,sval,xtid,xkey,ocgz,eesrd,eeid){
    if (xtid!="" && elsrd!="" && elid!="" && sval!="" && xkey!=""){
        bktxt=ajaxhtmlpost("/localxres/funx/anyshort/?stid="+xtid+"&"+xkey+"="+sval,"");
        slq=qian(bktxt,"|");
        slh=hou(bktxt,"|");
        ocga="";
        if (ocgz!="" && ocgz.indexOf("@")>0 && eesrd!="" && eeid!=""){
            skey=qian(ocgz,"@");
            sstid=hou(ocgz,"@");
            ocga="onchange=\"refreshselectx('"+eesrd+"','"+eeid+"',$(this).val(),'"+sstid+"','"+skey+"')\"";
        }
        shtml=formselect(slq,slh,"",elid,"",ocga);
        $("#"+elsrd).html(shtml);
    }else{
        return "";
    }
}//选择触发下一选择，联动
function formselectz(srdid,exid,stid,prev,ocgx,esrd,eid){
    if (stid!="" && exid!=""){
        bktxt=ajaxhtmlpost("/localxres/funx/anyshort/?stid="+stid,"");
        slq=qian(bktxt,"|");
        slh=hou(bktxt,"|");
        ocgy="";
        if (ocgx!="" && ocgx.indexOf("@")>0 && esrd!="" && eid!=""){
            skey=qian(ocgx,"@");
            sstid=hou(ocgx,"@");
            ocgy="onchange=\"refreshselect('"+esrd+"','"+eid+"',$(this).val(),'"+sstid+"','"+skey+"','','')\"";
        }
        shtml=formselect(slq,slh,prev,exid,"",ocgy);
        if (srdid!=""){
          $("#"+srdid).html(shtml);
        }
        return shtml;
    }else{
        return prev;
    }
}//触发选择
function fmselect(fk,fv,pv,fid,fcls,fdes,stlx){
    //普通选择
 if (fk.indexOf("/")>0){
   ptfk=fk.split("/");
 }else{
   ptfk=fk.split(",");
 };
 if (fv.indexOf("/")>0){
   ptfv=fv.split("/");
 }else{
   ptfv=fv.split(",");
 };
 
   fm="";
   fm="<select id=\""+fid+"\" name=\""+fid+"\"  class=\""+fcls+"\" "+fdes+"  style=\""+stlx+"\">";
 if (ptfk.length>0){
     if (pv=="" || pv=="."){
       fm=fm+"<option value=\".\" selected>无选项</option>";
     }else{
       fm=fm+"<option value=\".\">无选项</option>";  
     }
  for (fi=0;fi<ptfk.length;fi++){
      if (pv==ptfv[fi] || pv==ptfk[fi]){
       fm=fm+"<option value=\""+ptfv[fi]+"\" selected >"+ptfk[fi]+"</option>";
      }else{
       fm=fm+"<option value=\""+ptfv[fi]+"\">"+ptfk[fi]+"</option>";
      };//if pv
    };//if fi
  };//if ptfk
  return fm+"</select>";
}//fun
function shortselect(stidx,eidx,pvx,tpx,clsx){
tmpvx="";
 smd5=stidx+eidx+pvx;
 smd5="a"+smd5.MD5();
eval('tmpvx=sessionStorage.'+smd5+';');
 if (tmpvx!="" && tmpvx!=undefined){
         return tmpvx;
 }else{
    if (stidx!="" && eidx!=""){
        bktxt=ajaxhtmlpost("/localxres/funx/anyshort/?stid="+stidx,"");
        slq=qian(bktxt,"|");
        slh=hou(bktxt,"|");
        xhtml=fmselect(slq,slh,dftval(pvx,""),eidx,dftval(clsx,""),"",dftval(tpx,""));
        eval('sessionStorage.'+smd5+'=\''+xhtml+'\';');
        return xhtml;
    }else{
        return "";
    }
 }
}
function shortcheck(stidx,eidx,pvx,tpx,clsx){
tmpvx="";
 smd5=stidx+eidx+pvx;
 smd5="a"+smd5.MD5();
eval('tmpvx=sessionStorage.'+smd5+';');
 if (tmpvx!="" && tmpvx!=undefined){
         return tmpvx;
 }else{
    if (stidx!="" && eidx!=""){
        bktxt=ajaxhtmlpost("/localxres/funx/anyshort/?stid="+stidx,"");
        slq=qian(bktxt,"|");
        slh=hou(bktxt,"|");
        xhtml=fmcheckx(slq,slh,dftval(pvx,""),eidx,dftval(clsx,""),"",dftval(tpx,""));
        eval('sessionStorage.'+smd5+'=\''+xhtml+'\';');
        return xhtml;
    }else{
        return "";
    }
 }
}
function fmcheckx(fk,fv,pv,fid,fcls,fdes,fcdes){
fm="";
 if (fk.indexOf("/")>0){
  ptfk=fk.split("/");
 }else{
  ptfk=fk.split(",");
 };
 if (fv.indexOf("/")>0){
  ptfv=fv.split("/");
 }else{
  ptfv=fv.split(",");
 };
 if (ptfk.length==1 ){
   fm=fm+"<label><input type=\"radio\" id=\""+fid+"\" name=\""+fid+"\" class=\""+fcls+"\" "+fcdes+" value=\""+fv+"\" checked>"+fk+"</label>";  
   return fm;
 }else{
 for (fi=0;fi<ptfk.length;fi++){
   if (pv==ptfv[fi] || pv==ptfk[fi]){
   fm=fm+"<label><input type=\"radio\" name=\""+fid+"\" class=\""+fcls+"\" "+fcdes+" value=\""+ptfv[fi]+"\" checked>"+ptfk[fi]+"</label>";
   }else{
  if (ptfv[fi]!="" && ptfv[fi]!=undefined && ptfk[fi]!="" && ptfk[fi]!=undefined){
   fm=fm+"<label><input type=\"radio\" name=\""+fid+"\" class=\""+fcls+"\" "+fcdes+" value=\""+ptfv[fi]+"\">"+ptfk[fi]+"</label>";
  }
   };
 };//for
 return fm;
 };//length
}//fun
function fmipt(slc,pv,fid,fcls,fdes){
 var fmx="";
 if (slc==""){
  fmx="<input id=\""+fid+"\" class=\""+fcls+"\" value=\""+pv+"\" "+fdes+">"; 
 }else{
  fmx=fmselect(qian(slc,"|"),hou(slc,"|"),pv,fid,fcls,fdes.replace("size=",""));
 };
 return fmx;
}

function formcheckx($opname,$opvalue,$prevalue,$srdcode,$actcode,$comcode){
 fm="";
 fk=$opname;
 fv=$opvalue;
 if (fk.indexOf("/")>0){
   ptfk=fk.split("/");
 }else{
   ptfk=fk.split(",");
 };
 if (fv.indexOf("/")>0){
   ptfv=fv.split("/");
 }else{
   ptfv=fv.split(",");
 };
 $prevaluex="@@-"+$prevalue;
 if (ptfk.length>1){
   for (iz=0;iz<ptfk.length;iz++){
     if ($prevaluex.indexOf(ptfv[iz])>0){
         item=$actcode;
         item=item.replace(/\[value\]/g,ptfv[iz]);
         item=item.replace(/\[title\]/g,ptfk[iz]);
         fm=fm+item;
     }else{
         item=$comcode;
         item=item.replace(/\[value\]/g,ptfv[iz]);
         item=item.replace(/\[title\]/g,ptfk[iz]);
         fm=fm+item;
     }
   }
  }
 $srdcode=$srdcode.replace("\[inner\]",fm);
 return turnlab($srdcode);
}