<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    $fid=dftval($_GET["fid"],"");
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $unitid=$_GET["unitid"];
$tinyid=$_GET["tinyid"];
if (strpos($unitid,".")>0){
 $domain=qian($unitid,".");
 $mark=hou($unitid,".");
 $tmpback="";
 if ($tinyid=="" or $tinyid=="un"."defined"){
   $trst=SX("select pTempTitle,frmType,outUrl,caseCode,cssFileX,styleX,scriptX,jsFileX,cssFileY,jsFileY,styleY,scriptY,tempCode,pageSrd from iO_pageTemp where unitGrpMark='".$domain."' and unitDivMark='".$mark."'");
 }else{
   $trst=SX("select sysID,appID,pTempTitle,frmType,outUrl,caseCode,cssFileX,styleX,scriptX,jsFileX,cssFileY,jsFileY,styleY,scriptY,tempCode,pageSrd from iO_psysTiny where unitGrpMark='".$domain."' and unitDivMark='".$mark."' and tinyID='".$tinyid."'");
 }
 $sysid=anyvalue($trst,"sysID",0);
 $tmpback=$tmpback."\"sysid\":\"".$sysid."\",";
 $appid=anyvalue($trst,"appID",0);
 $tmpback=$tmpback."\"appid\":\"".$appid."\",";
 $unittitle=anyvalue($trst,"pTempTitle",0);
 $tmpback=$tmpback."\"unittitle\":\"".$unittitle."\",";
 $unitclass=anyvalue($trst,"frmType",0);
 $tmpback=$tmpback."\"unitclass\":\"".$unitclass."\",";
 $unitdescrib="";
 $tmpback=$tmpback."\"unitdescrib\":\"".$unitdescrib."\",";
 $outurl=anyvalue($trst,"outUrl",0);
 $tmpback=$tmpback."\"outurl\":\"".$outurl."\",";
 $industry="";
 $tmpback=$tmpback."\"industry\":\"".$industry."\",";
 $business="";
 $tmpback=$tmpback."\"business\":\"".$business."\",";
 $matter="";
 $tmpback=$tmpback."\"matter\":\"".$matter."\",";
 $casecode=anyvalue($trst,"caseCode",0);
 $tmpback=$tmpback."\"casecode\":\"".$casecode."\",";
 $cssfilex=anyvalue($trst,"cssFileX",0);
 $tmpback=$tmpback."\"cssfilex\":\"".$cssfilex."\",";
 $stylex=anyvalue($trst,"styleX",0);
 $tmpback=$tmpback."\"stylex\":\"".$stylex."\",";
 $scriptx=anyvalue($trst,"scriptX",0);
 $tmpback=$tmpback."\"scriptx\":\"".$scriptx."\",";
 $jsfilex=anyvalue($trst,"jsFileX",0);
 $tmpback=$tmpback."\"jsfilex\":\"".$jsfilex."\",";
 $cssfiley=anyvalue($trst,"cssFileY",0);
 $tmpback=$tmpback."\"cssfiley\":\"".$cssfiley."\",";
 $jsfiley=anyvalue($trst,"jsFileY",0);
 $tmpback=$tmpback."\"jsfiley\":\"".$jsfiley."\",";
 $styley=anyvalue($trst,"styleY",0);
 $tmpback=$tmpback."\"styley\":\"".$styley."\",";
 $scripty=anyvalue($trst,"scriptY",0); 
 $tmpback=$tmpback."\"scripty\":\"".$scripty."\",";
 $templatecode=anyvalue($trst,"tempCode",0);
 $tmpback=$tmpback."\"templatecode\":\"".$templatecode."\",";
 $demoresult="";
 $tmpback=$tmpback."\"demoresult\":\"".$demoresult."\",";
 $pagesurround=anyvalue($trst,"pageSrd",0);
 $tmpback=$tmpback."\"pagesurround\":\"".$pagesurround."\",";
 echo "{\"status\":\"1\",\"msg\":\"@succ\",".killlaststr($tmpback)."}";
}else{
 echo "{\"status\":\"0\",\"msg\":\"@fail\"}";
}
    $zz=UX("update coode_datafun set UPTM=now(),CRTM=now(), resulttxt='".str_replace("\'","\\\'",$outtxt)."' where dfunmark='".$fid."'");
    $outdatapath=combineurl(localroot(),"/localxres/dfunx/".$fid."/data.json");
    $ofx=overfile($outdatapath,$outtxt);
    echo $outtxt;
    session_write_close();
?>