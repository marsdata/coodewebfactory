<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    $fid=dftval($_GET["fid"],"");
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sysid=dftval($_GET["sysid"],"");
$srst=SX("select sysid,sysname from coode_sysinformation where sysid='".$sysid."'");
$tots=countresult($srst);
$temptotl=0;
$temptott=0;
if (intval($tots)>0){
$sysname=anyvalue($srst,"sysname",0);
$itemsrd='{
 name: \'[appname]\',
 itemStyle: {
 color: \'#[appcolor]\'
 },
 children: [<laydata>]
 },';
 
 $laysrdno='
 {
 name: \'[laytitle]\',
 value: 1,
 itemStyle: {
 color: \'#[laycolor]\'
 }
 },';
 
 $laysrd='{
 name: \'[laytitle]\',
 itemStyle: {
 color: \'#[laycolor]\'
 },
 children: [<tinydata>]
 },';
 
 $tinyitem='{
 name: \'[tinytitle]\',
 value: 1,
 itemStyle: {
 color: \'#[tinycolor]\'
 }
 },';
 
 $fmallapp="";
 $apprst=SX("select appid,appname,colora from coode_appdefault where sysid='".$sysid."'");
 $totapp=countresult($apprst);
 for ($a=0;$a<$totapp;$a++){
  $itemsrdx=$itemsrd;
  $itemsrdx=str_replace("[appname]",anyvalue($apprst,"appname",$a),$itemsrdx);
  $itemsrdx=str_replace("[appcolor]",anyvalue($apprst,"colora",$a),$itemsrdx);
  $layrst=SX("select layid,laytitle,colorb from coode_applay where sysid='".$sysid."' and appid='".anyvalue($apprst,"appid",$a)."'");
  $totlay=countresult($layrst);
  $fmlays="";
  $temptotl=$temptotl+$totlay;
  for ($b=0;$b<$totlay;$b++){
     $layid=anyvalue($layrst,"layid",$b);
     $laytitle=anyvalue($layrst,"laytitle",$b);
     $laycolor=anyvalue($layrst,"colorb",$b);
     $tnrst=SX("select tinymark,tinytitle,colorb from coode_tiny where sysid='".$sysid."' and appid='".anyvalue($apprst,"appid",$a)."' and layid='".$layid."'");
     $tottn=countresult($tnrst);
     $temptott=$temptott+$tottn;
     if (intval($tottn)>0){
       $fmtinys="";
       for ($c=0;$c<$tottn;$c++){
         $tinyitemx=$tinyitem;
         $tinyitemx=str_replace("[tinytitle]",anyvalue($tnrst,"tinytitle",$c),$tinyitemx);
         $tinyitemx=str_replace("[tinycolor]",anyvalue($tnrst,"colorb",$c),$tinyitemx);
         $fmtinys=$fmtinys.$tinyitemx;
       }
       $laysrdx=$laysrd;
       $fmtinys=killlaststr($fmtinys);
       $laysrdx=str_replace("<tinydata>",$fmtinys,$laysrdx);
     }else{
       $laysrdx=$laysrdno;
     }
     $laysrdx=str_replace("[laytitle]",$laytitle,$laysrdx);
     $laysrdx=str_replace("[laycolor]",$laycolor,$laysrdx);
     $fmlays=$fmlays.$laysrdx;
  }//for totlay
   if ($totlay>0){
     $fmlays=killlaststr($fmlays);
   }
   $itemsrdx=str_replace("<laydata>",$fmlays,$itemsrdx);
   $fmallapp=$fmallapp.$itemsrdx;
 }//for totapp
 $fmallapp=killlaststr($fmallapp);
 $describ="系统包含".$totapp."个应用,".$temptotl."个输出点,".$temptott."个页面";
$outtxt='{"status":"1","sysname":"'.$sysname.'","describ":"'.$describ.'","data":['.$fmallapp.']}';
}else{
 $outtxt=makereturnjson("0","失败，未发现系统","");
}
    $zz=UX("update coode_datafun set UPTM=now(),CRTM=now(), resulttxt='".str_replace("\'","\\\'",$outtxt)."' where dfunmark='".$fid."'");
    $outdatapath=combineurl(localroot(),"/localxres/dfunx/".$fid."/data.json");
    $ofx=overfile($outdatapath,$outtxt);
    echo $outtxt;
    session_write_close();
?>