<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    $fid=dftval($_GET["fid"],"");
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $domain=$_POST["domain"];
$mark=$_POST["mark"];
$amd5="a".md5($domain.$mark);
$z=setvarval($amd5,"");
$utitle=$_POST["unittitle"];
$uclass=$_POST["unitclass"];
$udescrib=$_POST["unitdescrib"];
$stylex=unstrs($_POST["stylex"]);
$scriptx=unstrs($_POST["scriptx"]);
$casecode=unstrs($_POST["casecode"]);
$casedemo=$casecode;
$tmpcode=unstrs($_POST["tmpcode"]);
$otmpcode=$tmpcode;
$srdcode=unstrs($_POST["srdcode"]);
$srddemo=$srdcode;
$jsfiles=unstrs($_POST["jsfiles"]);
$cssfiles=unstrs($_POST["cssfiles"]);
$outurl=$_POST["outurl"];
$alljsfiles=$jsfiles;
$allcssfiles=$cssfiles;
$allstylex=$stylex;
$allscriptx=$scriptx;
$ptjsfiles=explode(";",$jsfiles);
$totptj=count($ptjsfiles);
$fmface="";
for ($m=0;$m<$totptj;$m++){
  
  if (strpos($ptjsfiles[$m],"FACE/")>0){
    $tmpface=qian(hou($ptjsfiles[$m],"FACE/"),"/");
    if (strpos($fmface,$tmpface)>0){      
    }else{
      $fmface=$fmface.$tmpface.";";
    }
  }
  
}
$ptcssfiles=explode(";",$cssfiles);
$totptc=count($ptcssfiles);
$otherface=absorbface($tmpcode).absorbface($stylex).absorbface($scriptx);
$otherface=str_replace(",",";",$otherface);
if ($otherface!=""){
  $fmface=$fmface.$otherface;
}
$fmface=onlyone($fmface);
$ptface=explode(";",$fmface);
$totface=count($ptface);
if($outurl!=""){
 $ptout=explode("/",$outurl);
 $totpto=count($ptout);
 $fmpto="";
 for ($z=0;$z<($totpto-1);$z++){
  $fmpto=$fmpto.$ptout[$z]."/";
 }
}
eval(CLASSX("coodetemplate"));
$ct=new coodetemplate();
$newtempc=$tmpcode;
$leiia=0;
 $extnext=2; 
 while($extnext>1 and $leijia<10){
  $ptcode=explode("{!--TEMP.",$tmpcode);
  $leijia++;
  $totpt=count($ptcode);
  if ($totpt==1){
   $totpt=0;
  }
  $extnext=$totpt;
   if ($clone!=""){
    for ($i=1;$i<$totpt;$i++){   
        $partkey[$i]=qian($ptcode[$i],"=");
        $partval[$i]=qian(hou($ptcode[$i],"="),"--}");
        $newtempc=str_replace("{!--TEMP.".$partkey[$i]."=".$partval[$i]."--}","{--TEMP.".$partkey[$i]."=".$domain.".".hou($partval[$i],".")."--}",$newtempc);    
    }  
   }
 for ($i=1;$i<$totpt;$i++){
   $partkey[$i]=qian($ptcode[$i],"=");
   $partval[$i]=qian(hou($ptcode[$i],"="),"--}");
   $dmx=qian($partval[$i],".");
   $mkx=hou($partval[$i],".");
   if (strpos($mkx,"@")>0){
     $mky=qian($mkx,"@");
     $mkv=hou($mkx,"@");
   }else{
     $mky=$mkx;
     $mkv="";
   }   
   $tmprst=SX("select sysid,appid,cssfilex,jsfilex,stylex,scriptx,templatecode,unitclass,unittitle from coode_domainunit where domainmark='".$dmx."' and unitmark='".$mkx."'");
   if (countresult($tmprst)==0 and strpos($tmprst,"报错")<=0 and $dmx!="" and $mkx!=""){
     //如果引用下级不存在，则创建下级的空数据
       $sqlx="sysid,appid,domainmark,unitmark,CRTM,UPTM,CRTOR,OLMK,templatecode,pagesurround";
       $sqly="'".$sysid."','".$appid."','".$dmk."','".$mky."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."','','.gohex(tempdefault()).'";
       $z=UX("insert into coode_domainunit(".$sqlx.")values(".$sqly.")");
     
       $tmpcssfilex="";
       $tmpjsfilex="";
       $tmpstylex="";
       $tmpscriptx="";
       $unitclass="";
       $unittitle="";
       $tmpcodex="";
       $sid=$sysid;
       $aid=$appid;       
       $totptj=0;
       $fmclojsf="";
       $fmclocssf="";
       $tmpcode=str_replace("{!--TEMP.".$partkey[$i]."=".$partval[$i]."--}","{!--TMP.".$partkey[$i]."=".$partval[$i]."--}",$tmpcode);
    }else{
     //若存在下级则引用过来，以备合成
     $tmpcssfilex=tostring(anyvalue($tmprst,"cssfilex",0));
     $tmpjsfilex=tostring(anyvalue($tmprst,"jsfilex",0));
     $tmpstylex=tostring(anyvalue($tmprst,"stylex",0));
     $tmpscriptx=tostring(anyvalue($tmprst,"scriptx",0));
     $unitclass=tostring(anyvalue($tmprst,"unitclass",0));
     $unittitle=tostring(anyvalue($tmprst,"unittitle",0));
     $tmpcodex=tostring(anyvalue($tmprst,"templatecode",0));
     $casecodey=tostring(anyvalue($tmprst,"casecode",0));
     $sid=tostring(anyvalue($tmprst,"sysid",0));
     $aid=tostring(anyvalue($tmprst,"appid",0));
     $ptjsfiles=explode(";",$tmpjsfilex);
     $totptj=count($ptjsfiles);
     $fmclojsf="";
     $fmclocssf="";
    $ptcssfiles=explode(";",$tmpcssfilex);
    $totptc=count($ptcssfiles);    
    
   
   //下级向上合成
       $tmpcode=str_replace("{!--TEMP.".$partkey[$i]."=".$partval[$i]."--}",$tmpcodex,$tmpcode);
       $alljsfiles=$alljsfiles.$tmpjsfilex;
       $allcssfiles=$allcssfiles.$tmpcssfilex;
       $cloalljsfiles=$cloalljsfiles.$fmclojsf;
       $cloallcssfiles=$cloalljsfiles.$fmclocssf;
       $allstylex=$allstylex.$tmpstylex;
       $allscriptx=$allscriptx.$tmpscriptx;
    }//if counttmp 引用下级存不存在
   }//if i
  } // while
   $pagehtml=str_replace("<!--thesecomCSSFILES-->",formcss(onlyone($allcssfiles)),$pagehtml);
   $pagehtml=str_replace("<!--thesecomJSFILES-->",formjs(onlyone($alljsfiles)),$pagehtml);
   $pagehtml=str_replace("<!--thiscomSTYLE-->",$allstylex,$pagehtml);
   $pagehtml=str_replace("<!--thiscomSCRIPT-->",$allscriptx,$pagehtml);
   $pagehtml=str_replace("<!--thiscomHTML-->",turnlab($tmpcode),$pagehtml);
   $pagehtml=str_replace("<!--thistitle-->",$utitle,$pagehtml);
    if (strpos($outurl,".html")>0 or strpos($outurl,".php")>0){     
       $outx=combineurl(localroot(),$outurl);            
       $odata=gohex(file_get_contents($outx));
       $srclenx= checklines($odata,gohex($pagehtml));
       $olenx=qian($srclenx,"/");
       $nlenx=hou($srclenx,"/");
       $kx=reclines($domain.".".$mark,$domain.".".$mark,$domain.".".$mark,$domain.".".$mark,"template",$olenx,$nlenx,$pagehtml);       
       if (strpos($outurl,".php")>0){
         $outfun=constval("funtemp");
         $outfun=str_replace("[funname]","tempshow",$outfun);
         $outfun=str_replace("[qrystr]","dumark=".$domain.".".$mark,$outfun);
         $outfun='<?php'.huanhang().$outfun.'?>';         
         overfile($outx,$outfun);          
       }else{
         overfile($outx,str_replace("/FACE/","",$pagehtml)); 
       }
    }  
   //-表iO_pageTemp的字段为sNo,srcArea,unitGrpMark,unitDivMark,pTempID,pTempTitle,frmType,funType,outUrl,colorA,colorB,caseCode,cssFileX,styleX,jsFileX,scriptX,cssFileY,styleY,jsFileY,scriptY,pageSrd,tempCode,srcHeadCode,srcHeadImg,itemCTime,itemUTime,itemPUTime,itemPVerMd5,itemVerMd5,itemCrtID,itemCtPos,itemCrtComID,itemAccMark,itemAccCode,itemAffTable,itemCgAffairs,itemOnlyMark,itemOprt
  $srcArea=dftval($_POST["srcArea"],"localarea");
  $unitGrpMark=dftval($_POST["unitGrpMark"],$domain);
  $unitDivMark=dftval($_POST["unitDivMark"],$mark);
  $pTempID=dftval($_POST["pTempID"],$domain.".".$mark);
  $pTempTitle=dftval($_POST["pTempTitle"],$utitle);
  $frmType=dftval($_POST["frmType"],$uclass);
  $funType=dftval($_POST["funType"],"");
  $outUrl=dftval($_POST["outUrl"],$outurl);
  $colorA=dftval($_POST["colorA"],"");
  $colorB=dftval($_POST["colorB"],"");
  $caseCode=dftval($_POST["caseCode"],gohex($casecode));
  $cssFileX=dftval($_POST["cssFileX"],$cssfiles);
  $styleX=dftval($_POST["styleX"],$stylex);
  $jsFileX=dftval($_POST["jsFileX"],$jsfiles);
  $scriptX=dftval($_POST["scriptX"],$scriptx);
  $cssFileY=dftval($_POST["cssFileY"],$allcssfiles);
  $styleY=dftval($_POST["styleY"],$allstylex);
  $jsFileY=dftval($_POST["jsFileY"],$alljsfiles);
  $scriptY=dftval($_POST["scriptY"],$allscriptx);  
  $tempCode=dftval($_POST["tempCode"],gohex(turnlab($otmpcode)));
  $srcHeadCode=dftval($_POST["srcHeadCode"],"");
  $srcHeadImg=dftval($_POST["srcHeadImg"],"");
  $itemCTime=dftval($_POST["itemCTime"],date("Y-m-d H:i:s"));
  $itemUTime=dftval($_POST["itemUTime"],date("Y-m-d H:i:s"));
  $itemPUTime=dftval($_POST["itemPUTime"],date("Y-m-d H:i:s"));
  $itemPVerMd5=dftval($_POST["itemPVerMd5"],"");
  $itemVerMd5=dftval($_POST["itemVerMd5"],"");
  $itemCrtID=dftval($_POST["itemCrtID"],$_COOKIE["uid"]);
  $itemCtPos=dftval($_POST["itemCtPos"],"");
  $itemCrtComID=dftval($_POST["itemCrtComID"],$_COOKIE["cid"]);
  $itemAccMark=dftval($_POST["itemAccMark"],"");
  $itemAccCode=dftval($_POST["itemAccCode"],"");
  $itemAffTable=dftval($_POST["itemAffTable"],"");
  $itemCgAffairs=dftval($_POST["itemCgAffairs"],"");
  $itemOnlyMark=dftval($_POST["itemOnlyMark"],onlymark());
  $itemOprt=dftval($_POST["itemOprt"],"");
  $ext0=UX("select count(*) as result from iO_pageTemp where unitGrpMark='".$domain."' and unitDivMark='".$mark."' and  srcArea='localarea'");
  if (intval($ext0)>0){
    $sqlx="itemUTime=now(),pTempTitle='".$utitle."',frmType='".$uclass."',cssFileX='".onlyone($cssfiles)."',jsFileX='".onlyone($jsfiles)."',styleX='".gohex($stylex)."',scriptX='".gohex($scriptx)."',caseCode='".gohex($casedemo)."',tempCode='".gohex($otmpcode)."',cssFileY='".onlyone($allcssfiles)."',jsFileY='".onlyone($alljsfiles)."',styleY='".gohex($allstylex)."',scriptY='".gohex($allscriptx)."',outUrl='".$outurl."'";
    $z=UX("update iO_pageTemp set ".$sqlx." where unitGrpMark='".$domain."' and unitDivMark='".$mark."' and  srcArea='localarea'");
  }else{
    $sqlx="srcArea,unitGrpMark,unitDivMark,pTempID,pTempTitle,frmType,funType,outUrl,colorA,colorB,caseCode,cssFileX,styleX,jsFileX,scriptX,cssFileY,styleY,jsFileY,scriptY,tempCode,srcHeadCode,srcHeadImg,itemCTime,itemUTime,itemPUTime,itemPVerMd5,itemVerMd5,itemCrtID,itemCtPos,itemCrtComID,itemAccMark,itemAccCode,itemAffTable,itemCgAffairs,itemOnlyMark,itemOprt";
    $sqly="'$srcArea','$unitGrpMark','$unitDivMark','$pTempID','$pTempTitle','$frmType','$funType','$outUrl','$colorA','$colorB','$caseCode','$cssFileX','$styleX','$jsFileX','$scriptX','$cssFileY','$styleY','$jsFileY','$scriptY','$tempCode','$srcHeadCode','$srcHeadImg','$itemCTime','$itemUTime','$itemPUTime','$itemPVerMd5','$itemVerMd5','$itemCrtID','$itemCtPos','$itemCrtComID','$itemAccMark','$itemAccCode','$itemAffTable','$itemCgAffairs','$itemOnlyMark','$itemOprt'";
    $zz=UX("insert into iO_pageTemp($sqlx)values($sqly)");
   }
 $outtxt=makereturnjson("1","成功","");
    $zz=UX("update coode_datafun set UPTM=now(),CRTM=now(), resulttxt='".str_replace("\'","\\\'",$outtxt)."' where dfunmark='".$fid."'");
    $outdatapath=combineurl(localroot(),"/localxres/dfunx/".$fid."/data.json");
    $ofx=overfile($outdatapath,$outtxt);
    echo $outtxt;
    session_write_close();
?>