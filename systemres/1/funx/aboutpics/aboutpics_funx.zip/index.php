<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $jd=$_GET["jd"];
 $wd=$_GET["wd"];
 $ulat="0";
 $ulon="0";
 if (intval($jd)>0 and intval($wd)>0){
  eval(CLASSX("excoor"));
  $ec=new excoor(); 
  $newx=$ec->txtobaidu($jd,$wd);
  $ulon=qian($newx,",");
  $ulat=hou($newx,",");
}
 $ca=$_GET["clssa"];
 $cb=$_GET["clssb"];
 $demo='{"imgurl":"[imgurl]","smallurl":"[smallurl]","imgtitle":"[imgtitle]","clssa":"[clssa]","clssb":"[clssb]","blon":"[blon]","blat":"[blat]","CRTM":"[CRTM]","catcher":"[catcher]","cathead":"[cathead]","CRTOR":"[CRTOR]","location":"[jingdu],[weidu]"},';
 if ($ca!="" and $cb!="" and $ca!="un"."defined" and $cb!="un"."defined"){
  $picrst=SX("select imgurl,smallurl,imgtitle,clssa,clssb,blon,blat,CRTM,catcher,cathead,CRTOR from rberpbox_anycapture where  clssa like '%".$ca."%' and clssb like '%".$cb."%'");
  if (countresult($picrst)>0){
    $fmdm="";
    for ($i=0;$i<countresult($picrst);$i++){
     $demox=$demo;
     $demox=str_replace("[imgurl]",anyvalue($picrst,"imgurl",$i),$demox);
     $demox=str_replace("[smallurl]",anyvalue($picrst,"mallurl",$i),$demox);
     $demox=str_replace("[imgtitle]",anyvalue($picrst,"imgtitle",$i),$demox);
     $demox=str_replace("[clssa]",anyvalue($picrst,"clssa",$i),$demox);
     $demox=str_replace("[clssb]",anyvalue($picrst,"clssb",$i),$demox);
     $demox=str_replace("[blon]",anyvalue($picrst,"blon",$i),$demox);
     $demox=str_replace("[jingdu]",anyvalue($picrst,"blon",$i),$demox);
     $demox=str_replace("[blat]",anyvalue($picrst,"blat",$i),$demox);
     $demox=str_replace("[weidu]",anyvalue($picrst,"blat",$i),$demox);
     $demox=str_replace("[CRTM]",anyvalue($picrst,"CRTM",$i),$demox);
     $demox=str_replace("[catcher]",anyvalue($picrst,"catcher",$i),$demox);
     $demox=str_replace("[cathead]",anyvalue($picrst,"cathead",$i),$demox);
     $demox=str_replace("[CRTOR]",anyvalue($picrst,"CRTOR",$i),$demox);
     $fmdm=$fmdm.$demox;
    }
    $fmdm=killlaststr($fmdm);
    $datax="[".$fmdm."]";
  }else{
    $datax="[]";
  }
  echo '{"status":"1","msg":"成功","redirect":"","ulat":"'.$ulat.'","ulon":"'.$ulon.'","clssa":"'.$ca.'","clssb":"'.$cb.'","totrcd":"'.countresult($picrst).'","vls":'.$datax.'}';
 }else{
  echo '{"status":"0","msg":"参数不足","redirect":""}';
 }
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>