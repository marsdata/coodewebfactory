<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     eval(RESFUNSET("tabbaseinfo"));
$tskcode=_get("tskcode");
$tsrst=SX("select waytitle,abmethod,dtodmk,dtodtab,abaskeys from coode_absorbtab where waycode='".$tskcode."'");
$wtitle=anyvalue($tsrst,"waytitle",0);
$abmtd=anyvalue($tsrst,"abmethod",0);
$dmk=anyvalue($tsrst,"dtodmk",0);
$dtb=anyvalue($tsrst,"dtodtab",0);
$tabk=anyvalue($tsrst,"abaskeys",0);
$dinfo=array();
$dinfo=takedbinfo($dmk,$dtb,$dinfo);
$anartn="";
$abrst=SX("select abtitle,abeval,abaskeys from coode_absorbmtd where abmethod='".$abmtd."'");
$atitle=anyvalue($abrst,"abtitle",0);
$abeval=tostring(anyvalue($abrst,"abeval",0));
$evkeys=anyvalue($abrst,"abaskeys",0);
$ocode=unstrs(_post("ocode"));
if ($abeval!=""){
  eval($abeval);
}
$ptdata=explode("@/@",$anartn);
$totpt=count($ptdata);
for ($tt=0;$tt<$totpt;$tt++){
 $tmpdata=$ptdata[$tt];
  if ($tmpdata!=""){
   $tmpvalx=str_replace("@-@","','",$tmpdata);
   $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
   $uz=updatingx($conn,$dinfo["fbase"],"insert into ".$dtb."(".$tabk.",CRTM,UPTM,OLMK,CRTOR)values('".$tmpvalx."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."')","utf8");
  }
}
echo '{"status":"1","msg":"吸收成功","rtntxt":"'.$anartn.'"}';
     session_write_close();
?>