<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $namex="files";
$gml=localroot();
 $sqlx="restype,resmark,restitle,savepath,bodyurl,CRTM,UPTM,OLMK,STATUS";
 $sqly="'[restype]','[resmark]','[restitle]','[savepath]','[bodyurl]',now(),now(),'".onlymark()."',1";
 $mypath="/absorbseeds/";
 $mytitle="hellowocao";
if ($mytitle!="" and $mypath!=""){
 $tmpnm=$_FILES[$namex]["tmp_name"];
 $fnm=$_FILES[$namex]["name"];
 
 $tmptp=$_FILES[$namex]["type"];
 $tmperr=$_FILES[$namex]["error"];
 
 if (count($fnm)==1){
    $yy=createdir(combineurl(localroot(),$mypath));
    $rpt=combineurl(localroot(),$mypath);  
    $fpn=$rpt.$fnm[0];
    $restype=qian($fnm[0],"-");
    $fext=hou($fnm,".");
    $resmark=qian(hou($fnm[0],"-"),".");
    $hosturl=combineurl("http://".glw(),str_replace($gml,"",$fpn));
    move_uploaded_file($tmpnm[0], $fpn);
    $unzippath=$mypath."/".$restype."s/".$resmark;
    $cc=unzip($fpn,combineurl(localroot(),$unzippath));
    $indexfile=combineurl(localroot(),$unzippath."/index.json");
    $indextxt=file_get_contents($indexfile);
    $ijson=json_decode($indextxt,false);
    $restitle=$ijson->restitle;
    $sqlz=$sqly;
    $sqlz=str_replace("[restype]",$restype,$sqlz);
    $sqlz=str_replace("[resmark]",$resmark,$sqlz);
    $sqlz=str_replace("[restitle]",$restitle,$sqlz);
    $sqlz=str_replace("[savepath]",$fpn,$sqlz);
    $sqlz=str_replace("[bodyurl]",$unzippath,$sqlz);
    $zz=UX("insert into coode_abseeds(".$sqlx.")values(".$sqlz.")");
   
    echo '{"status":"1","msg":"上传单文件成功","redirect":""}';
  }else{  
        
    for ($p=0;$p<count($fnm);$p++){     
       $fnmx=$fnm[$p];     
       $tmpnmx=$tmpnm[$p];
       $fextx=hou($fnmx,".");
       $tmptpx=$tmptp[$p];
       $tmperrx=$tmperr[$p];    
       $yy=createdir(combineurl(localroot(),$mypath));
       $rpt=combineurl(localroot(),$mypath);  
       $fpn=$rpt.$fnmx;
       $restype=qian($fnmx,"-");
       $resmark=qian(hou($fnmx,"-"),".");
       $hosturl=combineurl("http://".glw(),str_replace($gml,"",$fpn));
       move_uploaded_file($tmpnmx, $fpn);                 
       $unzippath=$mypath."/".$restype."s/".$resmark;
       $cc=unzip($fpn,combineurl(localroot(),$unzippath));
       $indexfile=combineurl(localroot(),$unzippath."/index.json");
       $indextxt=file_get_contents($indexfile);
       $ijson=json_decode($indextxt,false);
       $restitle=$ijson->restitle;
       $sqlz=$sqly;
       $sqlz=str_replace("[restype]",$restype,$sqlz);
       $sqlz=str_replace("[resmark]",$resmark,$sqlz);
       $sqlz=str_replace("[restitle]",$restitle,$sqlz);
       $sqlz=str_replace("[savepath]",$fpn,$sqlz);
       $sqlz=str_replace("[bodyurl]",$unzippath,$sqlz);
       $zz=UX("insert into coode_abseeds(".$sqlx.")values(".$sqlz.")");
     
    }//for
    echo '{"status":"1","msg":"上传多文件成功","redirect":""}';
   }  
  }else{
   echo '{"status":"0","msg":"参数不全","redirect":""}';
  }
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>