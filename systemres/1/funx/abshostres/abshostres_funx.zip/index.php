<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $rescode=_get("rescode");
$restitle=_get("restitle");
$restype=_get("restype");
$resver=_get("resver");
$sysid=_get("sysid");
$extx=UX("select count(*) as result from coode_hostregres where restype='".$restype."' and resmark='".$rescode."'");
if (intval($extx)==0){
  $sqlx="host,grpid,restype,restitle,resmark,hostver,CRTM,UPTM,OLMK";
  $sqly="'".getsvshost($sysid)."','".$sysid."','".$restype."','".$restitle."','".$rescode."','".$resver."',now(),now(),'".onlymark()."'";
  $zzz=UX("insert into coode_hostregres(".$sqlx.")values(".$sqly.")");
    echo makereturnjson("1","成功","");
}else{
  $zz=UX("update coode_hostregres set hostver='".$resver."',UPTM=now() where restype='".$restype."' and resmark='".$rescode."'");
  echo makereturnjson("1","成功","");
}
     session_write_close();
?>