<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $clientcode=_get("clientcode");
$fromhost=_post("fromhost");
$restype=_post("restype");
$rescode=_post("rescode");
$sysid=_post("sysid");
$resver=_post("resver");
//该方法要异步执行,资源机构归属表,判断是否归属该机构，如果归属用归属的版本；如果非该机构则，依据不同客户端存储
$sqlx="sysid,clientcode,clienthost,restype,rescode,resver,CRTM,UPTM,OLMK";
$sqly="'".$sysid."','$clientcode','".$fromhost."','$restype','$rescode','$resver',now(),now(),'".onlymark()."'";
$zz=UX("insert into coode_clientres(".$sqlx.")values(".$sqly.")");
//执行异步同步的时候查看是否是母服务器资源，
     session_write_close();
?>