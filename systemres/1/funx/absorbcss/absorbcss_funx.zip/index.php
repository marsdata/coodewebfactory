<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
        $ptcssa=explode("}",$gtcsstxt);
          $totptc=count($ptcssa);
         for ($b=0;$b<$totptc-1;$b++){
           $tmptou=str_replace("\r\n","@/@",qian($ptcssa[$b],"{"));
           $tmptou=hou($tmptou,"@/@");
           $tmpshen=hou($ptcssa[$b],"{");
           $ptpic=explode("url(",$tmpshen);
            $totpic=count($ptpic);
           if ($totpic>0){
             for ($p=1;$p<$totpic;$p++){
                $temppic=str_replace("\"","",qian($ptpic[$p],")"));
                if (strpos($temppic,"/")>0){
                   $tmppicnm=laststr($temppic,"/");
                }else{
                   $tmppicnm=$temppic;
                };
                $bburl=str_replace(laststr($struc["cssurl"][$i],"/"),"",$struc["cssurl"][$i]);//用css获取相对地址,不是弄错了
��if (strpos($temppic,"ttp://")>0 or strpos($temppic,"ttps://")>0){
                 $tempurl=$temppic; //这里确定好 CSS的实际相对地址 css文件是相对他自己这个文件位置而言
��}else{
�� $tempurl=$bburl.$temppic; //这里确定好 CSS的实际相对地址 css文件是相对他自己这个文件位置而言
��};               
               $struc["imgurl"][$struc["num"]["totimgurl"]]=$tempurl;
               $struc["imglc"][$struc["num"]["totimgurl"]]=str_replace($baseurl,$baselc."FACE/".$mkid."/",$tempurl);//$baselc."FACE/".$mkid."/images/".$tmppicnm;
               $struc["imgmyurl"][$struc["num"]["totimgurl"]]=str_replace($baselc,"http://".glw(),$struc["imglc"][$struc["num"]["totimgurl"]]);                
               $struc["num"]["totimgurl"]=$struc["num"]["totimgurl"]+1;
              $tmpshen=str_replace($temppic,"../images/".$tmppicnm,$tmpshen);
             };//forpp
           };//totpic if
               if (strpos("x".$tmptou,".")>0){ //说明是类,非PUB 多定义一个MKID的伪公类
                 $tmptou=str_replace(".",".".$mkid,$tmptou);
                 $fmcsstxt=$fmcsstxt.$tmptou."{".$tmpshen."}\r\n";
                 $struc["pvtcssnm"][$struc["pvtcss"]["tot"]]=$tmptou;//
                 $struc["pvtcsstxt"][$struc["pvtcss"]["tot"]]=$tmpshen;//
                 $struc["pvtcssfrom"][$struc["pvtcss"]["tot"]]="http://[siteurl]FACE/".$mkid."/css/".$mkid.laststr($struc["csslc"][$i],"/");//
                $struc["pvtcss"]["tot"]=$struc["pvtcss"]["tot"]+1;                 
               }else{
                 $fmpubtxt=$fmpubtxt.$tmptou."{".$tmpshen."}\r\n";
                 $tmptou="#".$mkid.$struc["pubcss"]["tot"]." ".$tmptou;
                 $fmcsstxt=$fmcsstxt.$tmptou."{".$tmpshen."}\r\n";
                 $struc["pubcssnm"][$struc["pubcss"]["tot"]]=$tmptou;//
                 $struc["pubcsstxt"][$struc["pubcss"]["tot"]]=$tmpshen;//
                 $struc["pubcssfrom"][$struc["pubcss"]["tot"]]="http://[siteurl]FACE/".$mkid."/css/pub.css";//
                 $struc["pubcss"]["tot"]=$struc["pubcss"]["tot"]+1;
               };//tmptou
           //寻找 url();图片
        };//for//bb
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>