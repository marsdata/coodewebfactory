<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $smark=dftval(_get("smark"),"");
$dlx=array();
if ($smark!=""){
 $hupath=combineurl("http://".glw(),"/localxres/iconsetx/".$smark."/");
 $lcpath=combineurl(localroot(),"/localxres/iconsetx/".$smark."/");
 $urlp="/localxres/iconsetx/".$smark."/";
 $dlx=get_file_list(combineurl(localroot(),"/localxres/iconsetx/".$smark."/"));
 for ($k=0;$k<count($dlx);$k++){
  $tmpdir=$dlx[$k];  
  if ($tmpdir!=""){
   if (strpos($tmpdir,"-")>0){
     $icls=qian($tmpdir,"-");
   }else{
     $icls="";
   }
    $extx=UX("select count(*) as result from coode_icons where setmark='".$smark."' and imghsturl='".$urlp.$tmpdir."'");
    if (intval($extx)==0){    
      $sqla="setmark,imgmark,imgcls,imgtitle,stockplace,imgtype,imglcurl,imgrmturl,imghsturl,CRTM,UPTM,OLMK";
      $sqlb="'".$smark."','".qian($tmpdir,".")."','".$icls."','$tmpdir','".$urlp."','".kuozhanming($tmpdir)."','".$lcpath.$tmpdir."','".$hupath.$tmpdir."','".$urlp.$tmpdir."',now(),now(),'".onlymark()."'";
      $zz=UX("insert into coode_icons(".$sqla.")values(".$sqlb.")");          
    }else{
     $zz=UX("update coode_icons set imgcls='".$icls."',UPTM=now(),imglcurl='".$lcpath.$tmpdir."',imgrmturl='".$hupath.$tmpdir."' where setmark='".$smark."' and imghsturl='".$urlp.$tmpdir."'");
   }
  }//if tmpdir
 }//fork
 $zzk=UX("delete from coode_icons where timestampdiff(minute,UPTM,now())>5 and setmark='".$smark."'");
 echo makereturnjson("1","吸收成功","");
}else{
 echo makereturnjson("0","吸收失败-参数不全","");
}
     session_write_close();
?>