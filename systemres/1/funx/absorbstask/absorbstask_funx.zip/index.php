<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
         $tsid=_get("tsid");
    $tstt=_get("tstt");
    $zxxx=_get("zxxx");
    $adddemo=_post("adddemo");
    $exc=_post("exc");    
    $sqlx="planid,STCODE,evalid,scanurl,CRTM,UPTM,CRTOR,OLMK";    
    $adddemo=str_replace("::","=",$adddemo);
    $adddemo=str_replace("]","?",$adddemo);
    $adddemo=str_replace("[","&",$adddemo);    
    $ptexc=explode(",",$exc);
    $totpt=count($ptexc);
    $starti=0;
    $endi=0;
    $starti1=0;
    $endi1=0;
    $starti2=0;
    $endi1=0;
    $startj=0;
    $endj=0;
    $startk=0;
    $endk=0;
    $startd="";
    $endd="";
    for ($i=0;$i<$totpt;$i++){
       $mark=qian($ptexc[$i],"@");
       switch ($mark){
        case "d":
        $startd=qian(hou($ptexc[$i],"@"),"to");
        $endd=hou($ptexc[$i],"to");
        break;
        case "i":
        $starti=intval(qian(hou($ptexc[$i],"@"),"to"));
        $endi=intval(hou($ptexc[$i],"to"));
        break;
        case "i1":
        $starti1=intval(qian(hou($ptexc[$i],"@"),"to"));
        $endi1=intval(hou($ptexc[$i],"to"));
        break;
        case "i2":
        $starti2=intval(qian(hou($ptexc[$i],"@"),"to"));
        $endi2=intval(hou($ptexc[$i],"to"));
        break;
        case "j":
        $startj=intval(qian(hou($ptexc[$i],"@"),"to"));
        $endj=hou($ptexc[$i],"to");
        break;
        case "k":
        $startk=intval(qian(hou($ptexc[$i],"@"),"to"));
        $endk=intval(hou($ptexc[$i],"to"));
        break;
        default:
       }
    }
   
    if ($starti1<>$endi1){
      for ($i=$srarti1;i<$endi1;$i++){      
       $adddemo=str_replace("{i1}",$i,$adddemo);//这种描述不对 必须跟i一起变动才行
      }
    }
    if ($starti2<>$endi2){
      for ($i=$srarti2;i<$endi2;$i++){      
       $adddemo=str_replace("{i2}",$i,$adddemo);//这种描述不对 必须跟i一起变动才行
      }
    }
    if ($startd<>$endd){
      for ($i=0;$i<intval((strtotime($endd)-strtotime($startd))/86400);$i++){              
        $address=$adddemo;
        $address=str_replace("{d}",date('Y-m-d',strtotime($startd." +".$i." day")),$address);//这种描述不对 必须跟i一起变动才行        
        $sqly="'".$tsid."','".$tstt."','".$zxxx."','".$address."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";    
        $sqlz="insert into scan_history(".$sqlx.")values(".$sqly.")";
        $Z=UX($sqlz);
      }
    }
    if ($starti!=$endi){
      for ($i=$starti;$i<$endi;$i++){      
        if ($startj<>$endj){
          for ($j=$startj;$j<$endj;$j++){
            if ($startk!=$endk){
               for ($k=$startk;$k<$endk;$i++){
                 $address=$adddemo;
                 $address=str_replace("{k}",$k,$address);         
                 $address=str_replace("{j}",$j,$address);         
                 $address=str_replace("{i}",$i,$address);         
                 $sqly="'".$tsid."','".$tstt."','".$zxxx."','".$address."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";    
                 $sqlz="insert into scan_history(".$sqlx.")values(".$sqly.")";
                 $zz=UX($sqlz);
               }//fork
            }else{
                 $address=$adddemo;
                 $address=str_replace("{j}",$j,$address);         
                 $address=str_replace("{i}",$i,$address);         
                 $sqly="'".$tsid."','".$tstt."','".$zxxx."','".$address."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";    
                 $sqlz="insert into scan_history(".$sqlx.")values(".$sqly.")";
                 $zz=UX($sqlz);
            }//if
          }//forj
         }else{//ifj
                $address=$adddemo;
                $address=str_replace("{i}",$i,$address);         
                $sqly="'".$tsid."','".$tstt."','".$zxxx."','".$address."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";    
                $sqlz="insert into scan_history(".$sqlx.")values(".$sqly.")";
                $zz=UX($sqlz);
         }//ifj
       }//fori     
   }else{//ifi
                $address=$adddemo;
                $sqly="'".$tsid."','".$tstt."','".$zxxx."','".$address."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";    
                $sqlz="insert into scan_history(".$sqlx.")values(".$sqly.")";
                $zz=UX($sqlz);
   }//ifi
    echo "1";
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>