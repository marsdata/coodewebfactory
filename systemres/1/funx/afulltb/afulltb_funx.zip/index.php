<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     // anyfulltblist($souf,$ffrm,$ffdt,$fps,$fbs,$tbnm,$tbkis,$tbcdtn,$dtp,$surl,$odcdt){
//加上souf 如果有条件搜索的时候可以用到
 $fmkeyn="";
 $appid=$_GET["appid"];
 eval(RESFUNSET("keyinfo"));
 if ($ffdt!=""){
  $tdtq=qian($ffdt,"|");
  $tdth=hou($ffdt,"|");
  $tdptq=explode(",",$tdtq);
  $tott=count($tdptq);
  $tdpth=explode(",",$tdth);
  $tmptbmid="";
  for ($m=0;$m<$tott;$m++){
   $zhuanhuan[$tdptq[$m]]=$tdpth[$m];  //FFDT用来形成定制式ITEM 列
  };
 };
 
  $xid="";
    if (strpos($dtp,"sid:")>0){
    $xid=qian(hou($dtp,"sid:"),"/");
  };
  if ($stid==""){
    $stid=$_GET["stid"];
    $xid=qian($stid,"-");
  };
  $_GET["tmpshortid"]=$xid;
  $appid=$_GET["appid"];
  $conn=mysql_connect(gl(),glu(),glp());
  $extp=updatings($conn,glb(),"select ispmiss as result from coode_tablist where TABLE_NAME='".$tbnm."'","utf8");
  $conn=mysql_connect(gl(),glu(),glp());
  $kdts=selecteds($conn,glb(),"select keyx,dataarea from coode_pmiss where appid='".$appid."' and compid='".$_COOKIE["cid"]."' and groupid='".$_COOKIE["cid"]."/".$_COOKIE["gid"]."' and clientid='".$_COOKIE["uid"]."' and method='".$tbnm."' and behiver='view' and valx=1","utf8","");
  $exkkk=anyvalue($kdts,"keyx",0);
  $dtar=anyvalue($kdts,"dataarea",0);
  if (strpos($dtar,",")>0){
   $ptdta=explode(",",$dtar);
   $totpd=count($ptdta);
   $tmpzs=1;
   $fmzone="";
  }else{
    $totpd=0;
  }
  for ($j=0;$j<$totpd;$j++){
    if ($ptdta[$j]!=""){
      if (strpos($ptdta[$j],"-")>0){
        $tmpzs=$tmpzs*(hou($ptdta[$j],"-")*1);
        $fmzone=$fmzone." or (PRIME/".hou($ptdta[$j],"-").")=CEILING(PRIME/".hou($ptdta[$j],"-").")";
      }else{
        $fmzone=$fmzone." or PTOF='".$ptdta[$j]."' ";
      };
    };
  };
  if ($totpd>0 and $extp*1==1){
      $fmzone=" and (".substr($fmzone,3,strlen($fmzone)-1).")";       
  }else{
      $fmzone="";
  }
  //echo "fbs-".$fbs."--fpb--".$fpb;
  
 if ($fip==""){
  $fip=gl();
 };
 if ($fus==""){
  $fus=glu();
 };
 
 if ($fbs==""){
  $fbs=glb();
}else{
   if ($fps==""){
     $cmk=$fbs;
   }
   $fbs=glb();
 };
  
 if ($fps==""){
  $fps=glp();
 };
  
  if ($cmk!=""){
    $conn=mysql_connect(gl(),glu(),glp());
    $mkrst=selecteds($conn,glb(),"select casesurd,casehtml from coode_casehtml where cssmark='".$cmk."'","utf8","");
   // echo "select casesurd,casehtml from coode_casehtml where cssmark='".$fbs."'";
    $csurd=tostring(anyvalue($mkrst,"casesurd",0));
    $chtml=tostring(anyvalue($mkrst,"casehtml",0));
    //echo $chtml;
  };
  $fmch="";
  $demo="";
 $fmkeyn=$fmkeyn."&tbnm=".$tbnm."&tbkeys=".$tbkis."&tbcdtn=".$tbcdtn."&datatype=".$dtp."&comeurl=".$surl."&odcdt=".$odcdt;
 if (strpos($tbcdtn,"=")>0 or strpos($tbcdtn,">")>0 or strpos($tbcdtn,"<")>0  or strpos($tbcdtn,"null")>0 or strpos($tbcdtn,"like")>0){
    $tmpcdts=$tbcdtn;
  }else{
    if ($tbcdtn!="" and str_replace(" ","",$tbcdtn)!=""){
     $tmpcdts=Hex2String($tbcdtn);
    }else{
     $tmpcdts="";
    };
  };
  
$conn=mysql_connect(gl(),glu(),glp());
$strst=selecteds($conn,glb(),"select diycode,diytop,diybottom,addpage,addtitle,shorttitle,updatepage,allkillbtn,detailpage,additemx,newbutton,topbtn,bottombtn,ctraw,obtn,vbtn,xbtn,oprtx,headx,tbhd,dtx from coode_shortdata where shortid='".$xid."'","utf8","");
  
$diycode=tostring(anyvalue($strst,"diycode",0));
  $addpage=tostring(anyvalue($strst,"addpage",0));
  $addtitle=tostring(anyvalue($strst,"addtitle",0));
  $shorttitle=tostring(anyvalue($strst,"shorttitle",0));
  $updatepage=tostring(anyvalue($strst,"updatepage",0));
  $detailpage=tostring(anyvalue($strst,"detailpage",0));
  $additemx=anyvalue($strst,"additemx",0);
  $newbutton=anyvalue($strst,"newbutton",0);
  $obtn=anyvalue($strst,"obtn",0);
  $vbtn=anyvalue($strst,"vbtn",0);
  $xbtn=anyvalue($strst,"xbtn",0);
  $oprtx=anyvalue($strst,"oprtx",0);
  $headx=anyvalue($strst,"headx",0);
  $diytop=tostring(anyvalue($strst,"diytop",0));
  $diybottom=tostring(anyvalue($strst,"diybottom",0));
  $topbtn=tostring(anyvalue($strst,"topbtn",0));
  $bottombtn=tostring(anyvalue($strst,"bottombtn",0));
  $tbhd=tostring(anyvalue($strst,"tbhd",0));
  $dtx=tostring(anyvalue($strst,"dtx",0));
  $ctraw=tostring(anyvalue($strst,"ctraw",0));
  $allkillbtn=tostring(anyvalue($strst,"allkillbtn",0));
  
  $gsqc=$_GET["sqc"];
  if ($diycode!=""){
     if (strpos($diycode,",")>0){
       $ptdiy=explode(",",$diycode);
       $totptd=count($ptdiy);
       $fmx="";
       $fmxy="";
       for ($p=0;$p<$totptd;$p++){
         $ttx=qian($ptdiy[$p],":");
         $uux=hou($ptdiy[$p],":");
         if (strpos($uux,")")>0){
           $fmx=$fmx."<a class=\"layui-btn\" onclick=\"".$uux."\">".$ttx."</a>";
           if (($gsqc*1)==$p){
             $fmxy=$fmxy."<li><a  onclick=\"".$uux."\" class=\"current\">".$ttx."</a></li>";
           }else{
              $fmxy=$fmxy."<li><a  onclick=\"".$uux."\">".$ttx."</a></li>";
           };
         }else{
           $fmx=$fmx."<a class=\"layui-btn\" onclick=\"intourl('".$uux."')\">".$ttx."</a>";
           if (($gsqc*1)==1){
             $fmxy=$fmxy."<li><a  onclick=\"intourl('".$uux."')\" class=\"current\">".$ttx."</a></li>";
           }else{
              $fmxy=$fmxy."<li><a  onclick=\"intourl('".$uux."')\">".$ttx."</a></li>";
           };
         };
       };//for
      }else{
         $ttx=qian($diycode,":");
         $uux=hou($diycode,":");
         if (strpos($uux,")")>0){
           $fmx=$fmx."<a class=\"layui-btn\" onclick=\"".$uux."\">".$ttx."</a>";
           if (($gsqc*1)==1){
            $fmxy=$fmxy."<li><a  onclick=\"".$uux."\">".$ttx."</a></li>";
           }
         }else{
           $fmx=$fmx."<a class=\"layui-btn\" onclick=\"intourl('".$uux."')\">".$ttx."</a>";
           if (($gsqc*1)==1){
            $fmxy=$fmxy."<li><a  onclick=\"intourl('".$uux."')\">".$ttx."</a></li>";
           };
         };   
     };
    $dbtn="<div class=\"lift-nav\"><ul class=\"lift\">".$fmxy."</ul></div>";
  };
  
  
    
if (strpos($tbnm,",")>0 and strpos($tbkis,",")<=0){
 $ncdts=fmcdt($tbnm,$tbkis);
 $gkinfo=allkeyinfo($gkinfo,glb(),$tbnm);
 $tbkis=$gkinfo["COLUMN"]["ALLKEY"];
 $tbtkis=$gkinfo["COLUMN"]["ALLTKEY"];
 $ntbkis=makekey($tbtkis);
 $tbkis=$ntbkis;
 $tbcdts=$ncdts;
  if (strpos($tbnm,",")>0){
   $tbnm=substr($tbnm,0,strlen($tbnm)-1);
  };
 //排除SNO ,然后 去重; 加一个 t1.c=t2.c and t2.c=t3.c /如果成功匹配的话,如果,不成功则使用ALLKEY
}else{
 if ($tbkis=="*" or $tbkis==""){
  $gkinfo=allkeyinfo($gkinfo,glb(),$tbnm);
  $tbkis=$gkinfo["COLUMN"]["ALLKEY"];
 };
};
 $conn=mysql_connect($fip,$fus,$fps);
 $cdtstr=fmquery($cdtstr,$tbnm,$tbkis);
//  $tbcdts=$cdtstr["COLUMN"]["querystr"];
  if ($tbcdts=="" and $tmpcdts==""){
   $tbcdts=" 1>0 ";
  }else{
   if ($tbcdts!="" and $tmpcdts!=""){
     $tbcdts=$tbcdts." and ".$tmpcdts;
   }else{
     $tbcdts=$tbcdts." ".$tmpcdts;
   };
  };
 if ($tbkis==""){
  $tbkis="SNO";
 };
 $tbqrys=$cdtstr["COLUMN"]["querykey"];
// echo "select ".$tbkis." from ".$tbnm." where ".$tbcdts.$ordercdt;
 //-------------------------------------------------------------------------------
 
 $stbkis="";
  if ($ffdt!="" and $ffrm==""){
    $wtokis=$ffdt;
  //  echo "wtkis========".$wtokis."tbkis--------".$tbkis;
  };
 if (strpos($tbkis,",")>0){
   $kppart=explode(",",$tbkis);
   $totkp=count($kppart);
   for ($k=0;$k<$totkp;$k++){
    if (strpos("_".$wtokis,$kppart[$k].",")>0){
    }else{
       $stbkis=$stbkis.$kppart[$k].",";
    };
   };
  }else{//不大于零 且=* 或空 不正常的情况下找
   if ($tbkis=="*" or $tbkis==""){
    $alif=allkeyinfo($alif,glb(),$tbnm);
    $kppart=explode(",",$alif["COLUMN"]["ALLKEY"]);
    $totkp=count($kppart);
    for ($k=0;$k<$totkp;$k++){
     if (strpos("_".$wtokis,$kppart[$k].",")>0){
     }else{
        $stbkis=$stbkis.$kppart[$k].",";
     };//if
    };//for  
   };//if
  };//if
  $totk=0;
//echo "stbkis---------".$stbkis;
 if ($stbkis!=""){//基本这里结合上面成功的
   $stbkis=substr($stbkis.",",0,strlen($stbkis)-1);
   $kpart=explode(",",$stbkis);
   $totk=count($kpart);
 }else{
  $ncdts=fmcdt($tbnm,$tbkis);
  $gkinfo=allkeyinfo($gkinfo,glb(),$tbnm);
  $tbkis=$gkinfo["COLUMN"]["ALLKEY"];
  $tbtkis=$gkinfo["COLUMN"]["ALLTKEY"];
  $ntbkis=makekey($tbtkis);
  $tbkis=$ntbkis;
  $tbcdts=$ncdts;
  //if ($tbkis!="")
  //排除SNO ,然后 去重; 加一个 t1.c=t2.c and t2.c=t3.c /如果成功匹配的话,如果,不成功则使用ALLKEY
  $kpart=explode(",",$tbkis);
  $totk=count($kpart);
  $stbkis=$tbkis;
  if (strpos($tbnm,",")>0){
   $tbnm=substr($tbnm,0,strlen($tbnm)-1);
  };
   //这里的判断基本上用不上
 };
  
 if ($stbkis==""){
  $stbkis="SNO";
 };
  
 $conn=mysql_connect($fip,$fus,$fps);
  
 if (str_replace(" ","",str_replace("1>0","",$tbcdt))!=""){
   $tbcdt=str_replace("1>0","",$tbcdt);
 };
  
//--------------------------------------------------
//echo $ffrm."----".$ffdt;
if (strpos("xx".$odcdt,"order by")>0){
    $ordercdt=$odcdt;
}else{
  if (strlen($odcdt)>10){
    $ordercdt=Hex2String($odcdt);
  }else{
    $ordercdt="";  
  }
};
  
  
if ($exkkk!=""){
  if (substr($exkkk,strlen($exkkk)-1)==","){
    $extkkk=substr($exkkk,0,strlen($exkkk)-2);
  }else{    
  };
  $stbkis=$extkkk;
}else{
};
$flrst=selecteds($conn,glb(),"select ".$stbkis." from ".$tbnm." where ".$tbcdts.$fmzone.$ordercdt,"utf8","");
//echo $odcdt;fullselect
//echo "select ".$stbkis." from ".$tbnm." where ".$tbcdts.$ordercdt;
//  echo "flrst".$flrst;
 $totrst=countresult($flrst);
 $kpart=explode(",",$stbkis);
 $totk=count($kpart);
 $sresult=arrdata($sresult,$flrst);
 $keyinfo=thekeyfun($keyinfo,glb(),$tbnm,$stbkis);
 $fmcantc="";
 $fmktps="";
//CLASSP,JSHOW,JPOST
  for ($p=0;$p<$keyinfo["COLUMN"]["COUNT"];$p++){
     $jjshow=$keyinfo[$keyinfo["COLUMN"][$p]]["COLUMN_JSHOW"];
     $jjpost=$keyinfo[$keyinfo["COLUMN"][$p]]["COLUMN_JPOST"];
    //echo $keyinfo[$keyinfo["COLUMN"][$p]]["COLUMN_SSHOW"]."-------".$keyinfo["COLUMN"][$p];
     if (strpos($jjshow,"{")>0 || strpos($jjshow,"=")>0  || strpos($jjshow,"\"")>0){
      $jjshow="dTYPE_HEX-".String2Hex($jjshow);
     };
     if (strpos($jjpost,"{")>0 || strpos($jjpost,"=")>0  || strpos($jjpost,"\"")>0){
      $jjpost="dTYPE_HEX-".String2Hex($jjpost);
      };
     $fmktps=$fmktps."{\"keyname\":\"".$keyinfo["COLUMN"][$p]."\",\"datatype\":\"".$keyinfo[$keyinfo["COLUMN"][$p]]["COLUMN_TPNM"]."\",\"typelen\":\"".$keyinfo[$keyinfo["COLUMN"][$p]]["COLUMN_TPLEN"]."\",\"typetitle\":\"".$keyinfo[$keyinfo["COLUMN"][$p]]["COLUMN_TITLE"]."\",\"changeable\":\"".$keyinfo[$keyinfo["COLUMN"][$p]]["COLUMN_CANGE"]."\",\"clstxt\":\"".$keyinfo[$keyinfo["COLUMN"][$p]]["COLUMN_CLSTXT"]."\",\"jshow\":\"".$jjshow."\",\"jpost\":\"".$jjpost."\",\"classp\":\"".$keyinfo[$keyinfo["COLUMN"][$p]]["COLUMN_CLSSSP"]."\"},";
     if ($keyinfo[$keyinfo["COLUMN"][$p]]["COLUMN_CANGE"]=="0"){
     $fmcantc=$fmcantc.$keyinfo["COLUMN"][$p].",";
    };
  };
  if($keyinfo["COLUMN"]["COUNT"]>0){
     $fmktps="[".substr($fmktps,0,strlen($fmktps)-1)."]";
  };
  
 $fmjs="";
 $fmjh="";
 $fmexl="select ".$stbkis." from ".$tbnm." where ".$tbcdts.$fmzone.$ordercdt."
";
 $fmdft="{";
 $fmtb="";
 $fmtp="";
 $tmpdtx="";
 $fmjs="{\"tbname\":\"".$tbnm."\",\"cantkies\":\"".$fmcantc."\",\"keys\":\"".$tbkis."\",\"ktps\":".$fmktps.",\"totrcd\":\"".$totrst."\",\"sqlstr\":\"".String2Hex("select ".$tbkis." from ".$tbnm." where ".$tbcdts.$ordercdt)."\",\"vls\":[";
  $fmjh="{\"tbname\":\"".$tbnm."\",\"cantkies\":\"".$fmcantc."\",\"keys\":\"".$tbkis."\",\"ktps\":".$fmktps.",\"totrcd\":\"".$totrst."\",\"sqlstr\":\"".String2Hex("select ".$tbkis." from ".$tbnm." where ".$tbcdts.$ordercdt)."\",\"vls\":[";
  if ($keyinfo["COLUMN"]["COUNT"]>10){
     $scolx="overflow-x:scroll;overflow-y:hidden;width:100%;padding-bottom:500px;margin-bottom:50px;";
  }else{
  };
 $fmtb="<div id=\"scol".$tbnm."\"  style=\"".$scolx.";margin-left:5%;width:90%\"><form id=\"".$xid."update\" urlmark=\"[urlmark]\" class=\"layui-form\" onsubmit=\"return changesmt();\" action=\"".$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']."\"><table  id=\"anytable".$tbnm."\" class=\"layui-table\"  name=\"anytable\" tbname=\"".$tbnm."\" tbkies=\"".$tbkis."\" cantkies=\"".$fmcantc."\" totrcd=\"".$totrst."\" ><!--".$souf."_".$fip."_".$fus."_".$fps."_".$fbs."_".$tbnm."_".$tbkis."_".$tbcdtn."_".$dtp."_".$surl."_".$odcdt."__select ".$tbkis." from ".$tbnm." where ".$tbcdts.$ordercdt."-->";
 $fmtp="<div style=\"width:100%\"><p style=\"text-align:center;font-size:18px;font-weight:bold;width:auto;\">[tabletitle]</p></div><div style=\"width:100%\"><table  id=\"anytable".$tbnm."\"  border=\"1px\" cellspacing=\"0px\" cellpadding=\"3px\" name=\"anytable\" tbname=\"".$tbnm."\" tbkies=\"".$tbkis."\" cantkies=\"".$fmcantc."\" totrcd=\"".$totrst."\" ><!--".$souf."_".$fip."_".$fus."_".$fps."_".$fbs."_".$tbnm."_".$tbkis."_".$tbcdtn."_".$dtp."_".$surl."_".$odcdt."__select ".$tbkis." from ".$tbnm." where ".$tbcdts.$ordercdt."-->";
 $fmtb=$fmtb."<thead><tr rowidx=\"head\">";
 $fmtp=$fmtp."<thead><tr rowidx=\"head\" style=\"font-weight:bold;\">";
  $fmch="";
 for ($pp=0;$pp<$totk;$pp++){
    $demo=$chtml;
    $dftfun=$keyinfo[hou($kpart[$pp],".")]["COLUMN_SSHOW"];
    $hfun="";
    $tmppost="";
    if (strpos("x".$dftfun,"|")>0){
      $hfun=hou("x".$dftfun,"|");
      eval($hfun);
      $fmdft=$fmdft."\"".hou($kpart[$pp],".")."\":\"".$thusvalue."\",";
    }else{
      $fmdft=$fmdft."\"".hou($kpart[$pp],".")."\":\"\",";
    };
   if (($tbhd*1)==0 and strpos("x".$dtp,"print")<=0){
   }else{
     if ($keyinfo[hou($kpart[$pp],".")]["COLUMN_DSPLD"]*1==1){
       $coldspl="";
     }else{
       $coldspl="style=\"display:none;\"";
     }
    if ( $keyinfo[hou($kpart[$pp],".")]["COLUMN_TITLE"]!=""){//strpos($dtp,"theadc")>0 and
      if (hou($kpart[$pp],".")=="SNO"){
        $fmtb=$fmtb."<th knm=\"".hou($kpart[$pp],".")."\"  ".$coldspl.">".$keyinfo[hou($kpart[$pp],".")]["COLUMN_TITLE"]."</th>\r\n";
        $fmtp=$fmtp."<th knm=\"".hou($kpart[$pp],".")."\"  align=\"right\" width=\"50\">".$keyinfo[hou($kpart[$pp],".")]["COLUMN_TITLE"]."</th>\r\n";
        $fmexl=$fmexl.$keyinfo[hou($kpart[$pp],".")]["COLUMN_TITLE"]."[tab]";
      }else{
        $fmtb=$fmtb."<th knm=\"".hou($kpart[$pp],".")."\"  ".$coldspl.">".$keyinfo[hou($kpart[$pp],".")]["COLUMN_TITLE"]."</th>\r\n";
        $fmtp=$fmtp."<th knm=\"".hou($kpart[$pp],".")."\"  align=\"center\">".$keyinfo[hou($kpart[$pp],".")]["COLUMN_TITLE"]."</th>\r\n";
        $fmexl=$fmexl.$keyinfo[hou($kpart[$pp],".")]["COLUMN_TITLE"]."[tab]";
      }     
    }else{
      if (hou($kpart[$pp],".")=="SNO"){
        $fmtb=$fmtb."<th knm=\"".hou($kpart[$pp],".")."\"  ".$coldspl.">".hou($kpart[$pp],".")."</th>\r\n";
        $fmtp=$fmtp."<th knm=\"".hou($kpart[$pp],".")."\"  align=\"right\" width=\"50\">".hou($kpart[$pp],".")."</th>\r\n";
        $fmexl=$fmexl.hou($kpart[$pp],".")."[tab]";
      }else{
        $fmtb=$fmtb."<th knm=\"".hou($kpart[$pp],".")."\"  ".$coldspl.">".hou($kpart[$pp],".")."</th>\r\n";
        $fmtp=$fmtp."<th knm=\"".hou($kpart[$pp],".")."\"  align=\"center\" >".hou($kpart[$pp],".")."</th>\r\n";
        $fmexl=$fmexl.hou($kpart[$pp],".")."[tab]";
      }
    };
   };
 };
  $fmdft=substr($fmdft,0,strlen($fmdft)-1)."}";
  $fmexl=$fmexl."
";
  if (strpos($dtp.$headx,"nooprt")>0 or ($oprtx*1)==0 ){
  }else{
    if (strpos($dtp.$headx,"theadc")>0 ){
      $fmtb=$fmtb."<th knm=\"operation\">操作</th>";
     }else{
      $fmtb=$fmtb."<th knm=\"operation\">操作</th>";//OPRT
     };
  };
$fmtb=$fmtb."</tr></thead><tbody>";
$fmtp=$fmtp."</tr></thead><tbody>";
//echo "totk=".$totk;
  
//echo "totrst---".$totrst;
  
  for ($jj=1;$jj<$totrst+1;$jj++){//arr里的TOT比这个多1所以在这里得加一
    $demo=$chtml;
    $fmjs=$fmjs."{";
    $fmjh=$fmjh."{";
    $fmtb=$fmtb."<tr rowidx=\"".($jj)."\">";
    $fmtp=$fmtp."<tr rowidx=\"".($jj)."\" border=\"1\">";
    $tmp=0;
    $fmudt="";
    $tmpnewrow="";
    
    for ($ii=0;$ii<$totk;$ii++){
      if (strpos("x".$exkkk.",","-".hou($kpart[$ii],".").",")>0){
        $sresult[hou($kpart[$ii],".")][$jj]="***";
      };
     $fmjs=$fmjs."\"".hou($kpart[$ii],".")."\":\"".str_replace("\"","\\"."\"",tohex($sresult[hou($kpart[$ii],".")][$jj]))."\",";//anyvalue($flrst,hou($kpart[$ii],"."),$jj)
//      echo "<!-- xxx -->";
      $tmpnewrow=$ffrm;  //<div>[bianhao]</div>,fddt--SNO|bianhao
      if (hou($kpart[$ii],".")=='SNO'){
           if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"]*1==1){
            $coldspl="";
          }else{
            $coldspl="style=\"display:none;\"";
          }
         $fmtb=$fmtb."<td id=\"SNO".$sresult['SNO'][$jj]."\" ".$coldspl." class=\"SNO\"><input type=\"checkbox\" id=\"chk".$sresult['SNO'][$jj]."\" lay-skin=\"primary\" name=\"chksno\" onclick=\"choosek(this);\" knm=\"".hou($kpart[$ii],".")."\" value=\"".$sresult['SNO'][$jj]."\">".$sresult['SNO'][$jj]."</td>\r\n";
         $fmtp=$fmtp."<td id=\"SNO".$sresult['SNO'][$jj]."\"  align=\"right\">".$sresult['SNO'][$jj]."</td>\r\n";
         $fmjh=$fmjh."\"".hou($kpart[$ii],".")."\":\"".str_replace("\"","\\"."\"",$sresult[hou($kpart[$ii],".")][$jj])."\",";
         $demo=str_replace("[SNO]",$sresult['SNO'][$jj],$demo);
         $demo=str_replace("[key-SNO]",$sresult['SNO'][$jj],$demo);
         $demo=str_replace("[thissno]",$sresult['SNO'][$jj],$demo);
         $tmp=$tmp+1;
         $tmpnewrow=str_replace($sresult['SNO'][$jj],"[".$zhuanhuan["SNO"]."]",$tmpnewrow);  //SNO 换成 [SNO-FUN]<>
        
           if ($sresult[hou($kpart[$ii],".")][$jj]*1>=1000000000){//如果数字超过位数加下划线，防止变成科学计数法
             $fmexl=$fmexl.$sresult[hou($kpart[$ii],".")][$jj]."_[tab]";
           }else{
             $fmexl=$fmexl.$sresult[hou($kpart[$ii],".")][$jj]."[tab]";
           };
        
      }else{//not sno
           if ($sresult[hou($kpart[$ii],".")][$jj]*1>=1000000000){//如果数字超过位数加下划线，防止变成科学计数法
            $fmexl=$fmexl.$sresult[hou($kpart[$ii],".")][$jj]."_[tab]";
           }else{
            $fmexl=$fmexl.$sresult[hou($kpart[$ii],".")][$jj]."[tab]";
           };
        if ($tmp>0){
              if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_CANGE"]*1==1 and strpos("xx".$dtp,"print")<=0){                
               $rdonly="";
             }else{
               $rdonly="readonly";
             }
            $kclstxt=tostring($keyinfo[hou($kpart[$ii],".")]["COLUMN_CLSTXT"]);
            if ($kclstxt!="" ){                
                $newonex=tostring($keyinfo[hou($kpart[$ii],".")]["COLUMN_CLSTXT"]);              
               if (strpos($newonex,"key-")>0){
                 $hk=qian(hou($newonex,"key-"),"]");
                 $newonex=$sresult[$hk][$jj];
               };
               
                  //如果fmvalue(数据库里的不存在则使用以下
                  if (strlen($keyinfo[hou($kpart[$ii],".")]["COLUMN_ACTHTM"])>5){
                    $tmpact=fmvalue($tbnm,$sresult[hou($kpart[$ii],".")][$jj],$sresult['SNO'][$jj],hou($kpart[$ii],"."),$keyinfo[hou($kpart[$ii],".")]["COLUMN_ACTHTM"],$jj,$sresult);
                  };                                    
                  if (strlen($tmpact)>5){
                      $selecthcd=$tmpact;
                  }else{
                    if ($rdonly==""){
                      $selecthcd=" onchange=\"qajaxp('修改记录','//".$surl."/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=".hou($kpart[$ii],".")."&SNO=".$sresult['SNO'][$jj]."','p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."='+$('#"."p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."').val());\"";
                    }else{
                    }
                  };
                  if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]=="clstxt"){
                      $fmtmpselect=formselect(qian($newonex,"|"),hou($newonex,"|"),$sresult[hou($kpart[$ii],".")][$jj],"p_".hou($kpart[$ii],".").$sresult['SNO'][$jj],$rdonly,$selecthcd);                      
                  }
                  if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]=="clsduo"){
                   // $newselectx=formselectx($keykx[$cdkx],$keyvx[$cdkx],$valuexyz,$cdky,"","");
                    $fmtmpselect="<input type=\"hidden\" id=\""."p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" value=\"".$sresult[hou($kpart[$ii],".")][$jj]."\">".formselectx(qian($newonex,"|"),hou($newonex,"|"),$sresult[hou($kpart[$ii],".")][$jj],"p_".hou($kpart[$ii],".").$sresult['SNO'][$jj],"","");
                    //$fmtmpselect="<input id=\""."p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" type=\"hidden\">".formselectx(qian($newonex,"/"),hou($newonex,"/"),$sresult[hou($kpart[$ii],".")][$jj],"p_".hou($kpart[$ii],".").$sresult['SNO'][$jj],"","");
                  };
                  
                  if ($ffrm!=""){
                     if (strpos($keyinfo[hou($kpart[$ii],".")]["COLUMN_CLSTXT"],"]")>0){
                       $clsparkey=hou($keyinfo[hou($kpart[$ii],".")]["COLUMN_CLSTXT"],"]");
                     }else{
                       $clsparkey="";
                     };          
                   $tmpnewrow=str_replace($fmtmpselect,"[".$zhuanhuan[hou($kpart[$ii],".")]."]",$tmpnewrow);
                  };
               
                
             };//clstxt!==""
          //在  tmp>0之下
          
             if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"]*1==1){
               $coldspl="";
             }else{
               $coldspl="style=\"display:none;\"";
             }
                $tmpvl="";
               // echo "表述前".hou($kpart[$ii],".");
                if (qian($keyinfo[hou($kpart[$ii],".")]["COLUMN_SSHOW"],"|")!=""){//再有表述的前提下 有外壳包裹
                 // echo "有表述".qian($keyinfo[hou($kpart[$ii],".")]["COLUMN_SSHOW"],"|");
                  $tmpvl=fmvalue($tbnm,$sresult[hou($kpart[$ii],".")][$jj],$sresult['SNO'][$jj],hou($kpart[$ii],"."),qian($keyinfo[hou($kpart[$ii],".")]["COLUMN_SSHOW"],"|"),$jj,$sresult);
                  $tmpvl=str_replace("[selectx]",$fmtmpselect,$tmpvl);
                  
                    $fmtb=$fmtb."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\" ".$coldspl." tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\" class=\"td".hou($kpart[$ii],".")."\" knm=\"".hou($kpart[$ii],".")."\" tdata=\"".String2Hex(str_replace("\\'","\'",$sresult[hou($kpart[$ii],".")][$jj]))."\">".$tmpvl."</td>\r\n";
                    $fmtp=$fmtp."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\"  tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\" style=\"align:center;border:1;\" knm=\"".hou($kpart[$ii],".")."\" tdata=\"".String2Hex(str_replace("\\'","\'",$sresult[hou($kpart[$ii],".")][$jj]))."\">".tohex($sresult[hou($kpart[$ii],".")][$jj])."</td>\r\n";
                    $fmjh=$fmjh."\"".hou($kpart[$ii],".")."\":\"".str_replace("\"","\\"."\"",$tmpvl)."\",";
                    $demo=str_replace("[".hou($kpart[$ii],".")."]",$tmpvl,$demo);
                    $demo=str_replace("[key-".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
                    if ($ffrm!=""){
                     $tmpnewrow=str_replace($tmpvl,"[".$zhuanhuan[hou($kpart[$ii],".")]."]",$tmpnewrow);
                    };
                }else{
                  if ($ffrm!=""){
                    $tmpnewrow=str_replace(tohex($sresult[hou($kpart[$ii],".")][$jj]),"[".$zhuanhuan[hou($kpart[$ii],".")]."]",$tmpnewrow);
                   };
                 if(strlen($fmtmpselect)>5){
                   $fmtb=$fmtb."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\" tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\" ".$coldspl." class=\"td".hou($kpart[$ii],".")."\" knm=\"".hou($kpart[$ii],".")."\">".$fmtmpselect."</td>\r\n";
                   $fmtp=$fmtp."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\" tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\"  style=\"align:center;border:1;\" knm=\"".hou($kpart[$ii],".")."\">".$fmtmpselect."</td>\r\n";
                   $fmjh=$fmjh."\"".hou($kpart[$ii],".")."\":\"".str_replace("\"","\\"."\"",$fmtmpselect)."\",";
                   $demo=str_replace("[".hou($kpart[$ii],".")."]",$fmtmpselect,$demo);
                   $demo=str_replace("[key-".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
                  }else{
                   if (strlen($sresult[hou($kpart[$ii],".")][$jj])>33){
                     $fmtb=$fmtb."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\"  tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\" ".$coldspl." class=\"td".hou($kpart[$ii],".")."\" knm=\"".hou($kpart[$ii],".")."\" tdata=\"".String2Hex(str_replace("\\'","\'",$sresult[hou($kpart[$ii],".")][$jj]))."\">".substr(tohex($sresult[hou($kpart[$ii],".")][$jj]),0,33)."</td>\r\n";
                     $fmtp=$fmtp."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\"  tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\"  style=\"align:center;border:1;\" knm=\"".hou($kpart[$ii],".")."\" tdata=\"".String2Hex(str_replace("\\'","\'",$sresult[hou($kpart[$ii],".")][$jj]))."\">".substr(tohex($sresult[hou($kpart[$ii],".")][$jj]),0,33)."</td>\r\n";
                     $fmjh=$fmjh."\"".hou($kpart[$ii],".")."\":\"".str_replace("\"","\\"."\"",substr(tohex($sresult[hou($kpart[$ii],".")][$jj]),0,33))."\",";
                     $demo=str_replace("[".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
                     $demo=str_replace("[key-".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
                    }else{
                    //echo "deadkey-".hou($kpart[$ii],".");
                     if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]=="dttm" or $keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]=="date"){
                       $fmtb=$fmtb."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\" tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\" ".$coldspl." class=\"td".hou($kpart[$ii],".")."\" knm=\"".hou($kpart[$ii],".")."\" tdata=\"".String2Hex(str_replace("\\'","\'",$sresult[hou($kpart[$ii],".")][$jj]))."\"><input id=\"p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" class=\"demo-input\"  value=\"".tohex($sresult[hou($kpart[$ii],".")][$jj])."\"></td>\r\n";
                       $fmtp=$fmtp."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\" tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\"  style=\"align:center;border:1;\" knm=\"".hou($kpart[$ii],".")."\" tdata=\"".String2Hex(str_replace("\\'","\'",$sresult[hou($kpart[$ii],".")][$jj]))."\">".$sresult[hou($kpart[$ii],".")][$jj]."</td>\r\n";
                     }else{
                       $fmtb=$fmtb."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\" tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\" ".$coldspl." class=\"td".hou($kpart[$ii],".")."\" knm=\"".hou($kpart[$ii],".")."\" tdata=\"".String2Hex(str_replace("\\'","\'",$sresult[hou($kpart[$ii],".")][$jj]))."\">".tohex($sresult[hou($kpart[$ii],".")][$jj])."</td>\r\n";
                       $fmtp=$fmtp."<td id=\"".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" snoid=\"".$sresult['SNO'][$jj]."\" tpnm=\"".$keyinfo[hou($kpart[$ii],".")]["COLUMN_TPNM"]."\"  style=\"align:center;border:1;\" knm=\"".hou($kpart[$ii],".")."\" tdata=\"".String2Hex(str_replace("\\'","\'",$sresult[hou($kpart[$ii],".")][$jj]))."\">".tohex($sresult[hou($kpart[$ii],".")][$jj])."</td>\r\n";
                     }
                      $fmjh=$fmjh."\"".hou($kpart[$ii],".")."\":\"".str_replace("\"","\\"."\"",tohex($sresult[hou($kpart[$ii],".")][$jj]))."\",";
                      $demo=str_replace("[".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
                     $demo=str_replace("[key-".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
                    };//rst-len>100
                  };
                };//sshow
             $fmtmpselect="";
           $fmudt=$fmudt."'&p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."='+mkstr($('#p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."').val())+";
        }else{//不大于零的时候说明 没有SNO的存在,就用不咯SSNOid
              if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_CANGE"]*1==1){
               $rdonly="";
             }else{
               $rdonly="readonly";
             }
              if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_DSPLD"]*1==1){
               $coldspl="";
             }else{
               $coldspl="style=\"display:none;\"";
             }
            $kclstxt=$keyinfo[hou($kpart[$ii],".")]["COLUMN_CLSTXT"];
            if ($ffrm!=""){
               $tmpnewrow=str_replace(tohex($sresult[hou($kpart[$ii],".")][$jj]),"[".$zhuanhuan[hou($kpart[$ii],".")]."]",$tmpnewrow);
              };
           if ($kclstxt!="" and (strpos($kclstxt,"|")>0 or strpos($kclstxt,"/")>0)){
            // echo "<!-- test kclstxt!= kpart -->";
             $newonex=tostring($keyinfo[hou($kpart[$ii],".")]["COLUMN_CLSTXT"]);
                if (strpos($newonex,"key-")>0){
                 $hk=qian(hou($newonex,"key-"),"]");
                 $newonex=$sresult[$hk][$jj];
               };
                  if ($rdonly==""){
                    $selecthcd=" onchange=\"qajaxp('修改记录','//".$surl."/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=".hou($kpart[$ii],".")."&SNO=".$sresult['SNO'][$jj]."','p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."='+$('#"."p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."').val())\"";
                  }
                  if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]=="clstxt"){
                      $fmtmpselect=formselect(qian($newonex,"|"),hou($newonex,"|"),$sresult[hou($kpart[$ii],".")][$jj],"p_".hou($kpart[$ii],".").$sresult['SNO'][$jj],$rdonly,$selecthcd);                      
                  }
                  if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]=="clsduo"){
                   // $newselectx=formselectx($keykx[$cdkx],$keyvx[$cdkx],$valuexyz,$cdky,"","");
                    $fmtmpselect="<input type=\"hidden\" id=\""."p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" value=\"".$sresult[hou($kpart[$ii],".")][$jj]."\">".formselectx(qian($newonex,"|"),hou($newonex,"|"),$sresult[hou($kpart[$ii],".")][$jj],"p_".hou($kpart[$ii],".").$sresult['SNO'][$jj],"","");
                    //$fmtmpselect="<input id=\""."p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."\" type=\"hidden\">".formselectx(qian($newonex,"/"),hou($newonex,"/"),$sresult[hou($kpart[$ii],".")][$jj],"p_".hou($kpart[$ii],".").$sresult['SNO'][$jj],"","");
                  };
                  $fmtb=$fmtb."<td class=\"td".hou($kpart[$ii],".")."\">".$fmtmpselect."</td>\r\n";
                  $fmtp=$fmtp."<td class=\"td".hou($kpart[$ii],".")."\" style=\"align:center;border:1;\">".$fmtmpselect."</td>\r\n";
                 $fmjh=$fmjh."\"".hou($kpart[$ii],".")."\":\"".str_replace("\"","\\"."\"",$fmtmpselect)."\",";
                 $demo=str_replace("[".hou($kpart[$ii],".")."]",$fmtmpselect,$demo);
                 $demo=str_replace("[key-".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
               
           }else{
           //  echo "<!-- test kpart -->";
             $houtaizhanshi=qian($keyinfo[hou($kpart[$ii],".")]["COLUMN_SSHOW"],"|");
            if ($houtaizhanshi!=""){//再有表述的前提下
                 // echo "有表述".qian($keyinfo[hou($kpart[$ii],".")]["COLUMN_SSHOW"],"|");
                  $tmpvl=fmvalue($tbnm,$sresult[hou($kpart[$ii],".")][$jj],$sresult['SNO'][$jj],hou($kpart[$ii],"."),qian($keyinfo[hou($kpart[$ii],".")]["COLUMN_SSHOW"],"|"),$jj,$sresult);
                 $fmtb=$fmtb."<td class=\"td".hou($kpart[$ii],".")."\" ".$coldspl.">".$tmpvl."</td>\r\n";
                 $fmtp=$fmtp."<td class=\"td".hou($kpart[$ii],".")."\" style=\"align:center;border:1;\">".$tmpvl."</td>\r\n";
                 $fmjh=$fmjh."\"".hou($kpart[$ii],".")."\":\"".str_replace("\"","\\"."\"",$tmpvl)."\",";
                 $demo=str_replace("[".hou($kpart[$ii],".")."]",$tmpvl,$demo);
                 $demo=str_replace("[key-".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
            }else{
               if (strlen($sresult[hou($kpart[$ii],".")][$jj])>33){
                 $fmtb=$fmtb."<td class=\"td".hou($kpart[$ii],".")."\" ".$coldspl.">".substr($sresult[hou($kpart[$ii],".")][$jj],0,33)."</td>\r\n";
                 $fmtp=$fmtp."<td class=\"td".hou($kpart[$ii],".")."\" style=\"align:center;border:1;\">".substr($sresult[hou($kpart[$ii],".")][$jj],0,33)."</td>\r\n";
                 $fmjh=$fmjh."\"".hou($kpart[$ii],".")."\":\"".str_replace("\"","\\"."\"",substr($sresult[hou($kpart[$ii],".")][$jj],0,33))."\",";
                 $demo=str_replace("[".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
                 $demo=str_replace("[key-".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
               }else{
                 $fmtb=$fmtb."<td class=\"td".hou($kpart[$ii],".")."\" ".$coldspl.">".$sresult[hou($kpart[$ii],".")][$jj]."</td>\r\n";
                 $fmtp=$fmtp."<td class=\"td".hou($kpart[$ii],".")."\" style=\"align:center;border:1;\">".$sresult[hou($kpart[$ii],".")][$jj]."</td>\r\n";
                 $fmjh=$fmjh."\"".hou($kpart[$ii],".")."\":\"".str_replace("\"","\\"."\"",$sresult[hou($kpart[$ii],".")][$jj])."\",";
                 $demo=str_replace("[".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
                 $demo=str_replace("[key-".hou($kpart[$ii],".")."]",$sresult[hou($kpart[$ii],".")][$jj],$demo);
               };
            }
             
             
           };
        };//if
      };//if
       if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]=="date"){
         $tmpdtx=$tmpdtx."<script>laydatex('p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."');</script>";
       };
       if ($keyinfo[hou($kpart[$ii],".")]["COLUMN_DXTYPE"]=="dttm"){
         $tmpdtx=$tmpdtx."<script>laydttmx('p_".hou($kpart[$ii],".").$sresult['SNO'][$jj]."');</script>";
       };
    };//for  key
  //  echo "**********totrst***********".$totrst;
    $fmudt=substr($fmudt,0,strlen($fmudt)-1);
    if (strpos(".".$dtp.$headx,"nooprt")<=0 and ($oprtx*1)>0){
     if (strpos($tbnm,",")>0){
       //onclick=\"qajaxps('修改记录','http://".$surl."/config/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=".$tbkis."&QRY=".$tbkis."&SNO=".$sresult[$tbkis][$jj]."',".$fmudt.")\"
        $odspl="";
        $vdspl="";
        $xdspl="";
        if ($obtn*1==0){
          $odspl="style=\"display:none;\"";
        }
        if ($vbtn*1==0){
          $vdspl="style=\"display:none;\"";
        }
        if ($xbtn*1==0){
          $xdspl="style=\"display:none;\"";
        }
      $fmtb=$fmtb."<td class=\"tdoperate\"><a href=\"javascript:void(0)\"  onclick=\"update('".$xid."',".$sresult["SNO"][$jj].")\" ".$odspl." snox=\"".$sresult["SNO"][$jj]."\"><img src=\"/ORG/BRAIN/images/icon/system/detail5.svg\" style=\"width:20px;height:20px;\"></a><a href=\"javascript:void(0)\" ".$vdspl." onclick=\"qajaxp('修改记录','http://".$surl."/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=".$tbkis."&QRY=".$tbkis."&SNO=".$sresult[$tbkis][$jj]."',".$fmudt.")\" ".$xdspl." snox=\"".$sresult["SNO"][$jj]."\"><img src=\"/ORG/BRAIN/images/icon/system/tongguoqr.svg\" style=\"width:20px;height:20px\"></a><a href=\"javascript:void(0)\" ".$xdspl." onclick=\"Notiflix.Confirm.Show( '删除确认', '你确定要删除该条记录吗?', '是', '否', function(){ qajaxps('删除记录','//".$surl."/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=-killitem&QRY=".$tbkis."&SNO=".$sresult["SNO"][$jj]."',''); } );\" snox=\"".$sresult["SNO"][$jj]."\"><img src=\"/ORG/BRAIN/images/icon/system/shanchu13.svg\" style=\"width:20px;height:20px\"></a><a href=\"javascript:void(0)\"  onclick=\"newwin('查看数据评论','/SPEC/EDITOR/anyjsshort.php?stid=0Ak5hM-sfile:anyjsshort.php-pnum:30-&tbnm=".$tbnm."&tbsno=".$sresult["SNO"][$jj]."')\"><img src=\"/ORG/BRAIN/images/icon/system/liuyan0.svg\" style=\"width:20px;height:20px\"></a><a href=\"javascript:void(0)\"  onclick=\"newwin('查看数据工单','/SPEC/EDITOR/anyjsshort.php?stid=aneVcy-sfile:anyjsshort.php-pnum:30-&tbnm=".$tbnm."&tbsno=".$sresult["SNO"][$jj]."&prob=problem')\"><img src=\"/ORG/BRAIN/images/icon/system/probm.svg\" style=\"width:20px;height:20px\"></a></td>\r\n";
      
       $demo=str_replace("[OPRT]","<a   href=\"javascript:void(0)\"  onclick=\"update('".$xid."',".$sresult["SNO"][$jj].")\" ".$odspl." snox=\"".$sresult["SNO"][$jj]."\"><img src=\"/ORG/BRAIN/images/icon/system/detail5.svg\" style=\"width:20px;height:20px;\"></a><a href=\"javascript:void(0)\" ".$vdspl." onclick=\"qajaxp('修改记录','http://".$surl."/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=".$tbkis."&QRY=".$tbkis."&SNO=".$sresult[$tbkis][$jj]."',".$fmudt.")\" ".$xdspl." snox=\"".$sresult["SNO"][$jj]."\"><img src=\"/ORG/BRAIN/images/icon/system/tongguoqr.svg\" style=\"width:20px;height:20px\"></a><a href=\"javascript:void(0)\" ".$xdspl."  onclick=\"Notiflix.Confirm.Show( '删除确认', '你确定要删除该条记录吗?', '是', '否', function(){ qajaxps('删除记录','//".$surl."/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=-killitem&QRY=".$tbkis."&SNO=".$sresult["SNO"][$jj]."',''); } );\" snox=\"".$sresult["SNO"][$jj]."\"><img src=\"/ORG/BRAIN/images/icon/system/shanchu13.svg\" style=\"width:20px;height:20px\"></a><a href=\"javascript:void(0)\"  onclick=\"newwin('查看数据评论','/SPEC/EDITOR/anyjsshort.php?stid=0Ak5hM-sfile:anyjsshort.php-pnum:30-&tbnm=".$tbnm."&tbsno=".$sresult["SNO"][$jj]."')\"><img src=\"/ORG/BRAIN/images/icon/system/liuyan0.svg\" style=\"width:20px;height:20px\"></a><a href=\"javascript:void(0)\"  onclick=\"newwin('查看数据工单','/SPEC/EDITOR/anyjsshort.php?stid=aneVcy-sfile:anyjsshort.php-pnum:30-&tbnm=".$tbnm."&tbsno=".$sresult["SNO"][$jj]."&prob=problem')\"><img src=\"/ORG/BRAIN/images/icon/system/probm.svg\" style=\"width:20px;height:20px\"></a>",$demo);
       
     }else{
        $odspl="";
        $vdspl="";
        $xdspl="";
        if ($obtn*1==0){
          $odspl="style=\"display:none;\"";
        }
        if ($vbtn*1==0){
          $vdspl="style=\"display:none;\"";
        }
        if ($xbtn*1==0){
          $xdspl="style=\"display:none;\"";
        }
       //onclick=\"qajaxps('修改记录','http://".$surl."/config/anyrcv.php?tbnm=".$tbnm."&kies=".$tbkis."&SNO=".$sresult['SNO'][$jj]."',".$fmudt.")\"
      $fmtb=$fmtb."<td class=\"tdoperate\"><a href=\"javascript:void(0)\"  onclick=\"update('".$xid."',".$sresult["SNO"][$jj].")\" ".$odspl." snox=\"".$sresult["SNO"][$jj]."\"><img src=\"/ORG/BRAIN/images/icon/system/detail5.svg\" style=\"width:20px;height:20px;\"></a><a href=\"javascript:void(0)\" ".$vdspl." onclick=\"qajaxp('修改记录','http://".$surl."/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=".$tbkis."&SNO=".$sresult['SNO'][$jj]."',".$fmudt.")\" ><img src=\"/ORG/BRAIN/images/icon/system/tongguoqr.svg\" style=\"width:20px;height:20px\"></a><a href=\"javascript:void(0)\" ".$xdspl." onclick=\"Notiflix.Confirm.Show( '删除确认', '你确定要删除该条记录吗?', '是', '否', function(){ qajaxps('删除记录','//".$surl."/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=-killitem&QRY=".$tbkis."&SNO=".$sresult["SNO"][$jj]."',''); } );\" snox=\"".$sresult["SNO"][$jj]."\"><img src=\"/ORG/BRAIN/images/icon/system/shanchu13.svg\" style=\"width:20px;height:20px\"></a><a href=\"javascript:void(0)\"  onclick=\"newwin('查看数据评论','/SPEC/EDITOR/anyjsshort.php?stid=0Ak5hM-sfile:anyjsshort.php-pnum:30-&tbnm=".$tbnm."&tbsno=".$sresult["SNO"][$jj]."')\"><img src=\"/ORG/BRAIN/images/icon/system/liuyan0.svg\" style=\"width:20px;height:20px\"></a><a href=\"javascript:void(0)\"  onclick=\"newwin('查看数据工单','/SPEC/EDITOR/anyjsshort.php?stid=aneVcy-sfile:anyjsshort.php-pnum:30-&tbnm=".$tbnm."&tbsno=".$sresult["SNO"][$jj]."&prob=problem')\"><img src=\"/ORG/BRAIN/images/icon/system/probm.svg\" style=\"width:20px;height:20px\"></a></td>\r\n";       
       $demo=str_replace("[OPRT]","<a href=\"javascript:void(0)\"  onclick=\"update('".$xid."',".$sresult["SNO"][$jj].")\" ".$odspl." snox=\"".$sresult["SNO"][$jj]."\"><img src=\"/ORG/BRAIN/images/icon/system/detail5.svg\" style=\"width:20px;height:20px;\"></a><a href=\"javascript:void(0)\" ".$vdspl." onclick=\"qajaxp('修改记录','http://".$surl."/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=".$tbkis."&SNO=".$sresult['SNO'][$jj]."',".$fmudt.")\" ><img src=\"/ORG/BRAIN/images/icon/system/tongguoqr.svg\" style=\"width:20px;height:20px\"></a><a href=\"javascript:void(0)\" ".$xdspl." onclick=\"Notiflix.Confirm.Show( '删除确认', '你确定要删除该条记录吗?', '是', '否', function(){ qajaxps('删除记录','//".$surl."/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&kies=-killitem&QRY=".$tbkis."&SNO=".$sresult["SNO"][$jj]."',''); } );\" snox=\"".$sresult["SNO"][$jj]."\"><img src=\"/ORG/BRAIN/images/icon/system/shanchu13.svg\" style=\"width:20px;height:20px\"></a><a href=\"javascript:void(0)\"  onclick=\"newwin('查看数据评论','/SPEC/EDITOR/anyjsshort.php?stid=0Ak5hM-sfile:anyjsshort.php-pnum:30-&tbnm=".$tbnm."&tbsno=".$sresult["SNO"][$jj]."')\"><img src=\"/ORG/BRAIN/images/icon/system/liuyan0.svg\" style=\"width:20px;height:20px\"></a><a href=\"javascript:void(0)\"  onclick=\"newwin('查看数据工单','/SPEC/EDITOR/anyjsshort.php?stid=aneVcy-sfile:anyjsshort.php-pnum:30-&tbnm=".$tbnm."&tbsno=".$sresult["SNO"][$jj]."&prob=problem')\"><img src=\"/ORG/BRAIN/images/icon/system/probm.svg\" style=\"width:20px;height:20px\"></a>",$demo);
     };
    };
    $fmtb=$fmtb."</tr>\r\n";
    
    if ($totrst>0){
      $fmjs=substr($fmjs,0,strlen($fmjs)-1)."},";
      $fmjh=substr($fmjh,0,strlen($fmjh)-1)."},";
      $fmexl=$fmexl."
";
      //echo $demo."----dddddd---".$totrst;
      $fmch=$fmch.$demo;
    }else{
    };//
    
  };//for j
  
  
    if (($ctraw*1==1)){
//-0-------------------------------统计行------------
  $fmtb=$fmtb."<tr rowidx=\"x\">";
  $fmtp=$fmtp."<tr rowidx=\"x\">";
  $fmdt="";
  $fmsdt="";
  for ($pp=0;$pp<$totk;$pp++){
             if ($keyinfo[hou($kpart[$pp],".")]["COLUMN_DSPLD"]*1==1){
               $coldspl="";
             }else{
               $coldspl="style=\"display:none;\"";
             }
         if (hou($kpart[$pp],".")=="SNO"){
           $fmtb=$fmtb."<td knm=\"".hou($kpart[$pp],".")."\" ".$coldspl.">合计</td>\r\n";
           $fmtp=$fmtp."<td knm=\"".hou($kpart[$pp],".")."\" ".$coldspl." style=\"align:right;width:50px;\">合计</td>\r\n";
         }else{
           if ($keyinfo[hou($kpart[$pp],".")]["COLUMN_TPNM"]=="int" or $keyinfo[hou($kpart[$pp],".")]["COLUMN_TPNM"]=="decimal"){
             $fmtb=$fmtb."<td knm=\"".hou($kpart[$pp],".")."\" ".$coldspl.">".$sresult[hou($kpart[$pp],".")][$totrst+2]."</td>\r\n";
             $fmtp=$fmtp."<td knm=\"".hou($kpart[$pp],".")."\"  style=\"align:center;border:1;\">".$sresult[hou($kpart[$pp],".")][$totrst+2]."</td>\r\n";
           }else{
             $fmtb=$fmtb."<td knm=\"".hou($kpart[$pp],".")."\" ".$coldspl.">&nbsp;</td>\r\n";
             $fmtp=$fmtp."<td knm=\"".hou($kpart[$pp],".")."\" style=\"align:center;border:1;\">&nbsp;</td>\r\n";
           }
         };
  };
  if (($oprtx*1)==1){
    if (strpos($tbnm,",")>0){//没有太大区分
     $fmtb=$fmtb."<td knm=\"operation\">";
     if (strpos(".".$dtp,"nocreate")<=0){       
      $fmtb=$fmtb."";
     };
     $fmtb=$fmtb."</td>\r\n";
    }else{
     $fmtb=$fmtb."<td knm=\"operation\">";
     if (strpos(".".$dtp,"nocreate")<=0){
       $fmtb=$fmtb."";
     };
     $fmtb=$fmtb."</td>\r\n";
    };
  };
  $fmtb=$fmtb."</tr>";//统计行也要有操作lie
  $fmtp=$fmtp."</tr>";//统计行也要有操作lie
  
  //-----------------------------------------------  fm统计出
  //$fmch=$fmch.$demo;
};
  
  
if (strpos(".".$dtp.$headx,"noadd")<=0 and ($additemx*1)==1){
//-0-------------------------------------------
  $fmtb=$fmtb."<tr rowidx=\"0\">";
  $fmdt="";
  $fmsdt="";
  for ($pp=0;$pp<$totk;$pp++){
   $newonex=tostring($keyinfo[hou($kpart[$pp],".")]["COLUMN_CLSTXT"]);
             if ($keyinfo[hou($kpart[$pp],".")]["COLUMN_DSPLD"]*1==1){
               $coldspl="";
             }else{
               $coldspl="style=\"display:none;\"";
             }
   if ($newonex!=""){
          //if (strpos($newonex,"key-")>0){
         //        $hk=qian(hou($newonex,"key-"),"]");
         //        $newonex=$sresult[$hk][$jj];
         //};
         $yzd=0;
         if ($keyinfo[hou($kpart[$pp],".")]["COLUMN_DXTYPE"]=="clstxt"){             
            if (strpos($newonex,"|")>0){
              $fmtb=$fmtb."<td knm=\"".hou($kpart[$pp],".")."\" ".$coldspl.">".formselect(qian($newonex,"|"),hou($newonex,"|"),"","p_".hou($kpart[$pp],".")."0",""," onchange")."</td>";
              $yzd=$yzd+1;
            }else{
              $fmtb=$fmtb."<td knm=\"".hou($kpart[$pp],".")."\" ".$coldspl."></td>";
              $yzd=$yzd+1;
            }
          }
     
           if ($keyinfo[hou($kpart[$pp],".")]["COLUMN_DXTYPE"]=="clsduo"){
             if (strpos($newonex,"|")>0){
               $fmtb=$fmtb."<td knm=\"".hou($kpart[$pp],".")."\" ".$coldspl.">".formselectx(qian($newonex,"|"),hou($newonex,"|"),"","p_".hou($kpart[$pp],".")."0","","")."</td>";
               $yzd=$yzd+1;
             }else{
               $fmtb=$fmtb."<td knm=\"".hou($kpart[$pp],".")."\" ".$coldspl."></td>";
               $yzd=$yzd+1;
             }
          };
        if ($yzd==0){
          $fmtb=$fmtb."<td knm=\"".hou($kpart[$pp],".")."\" ".$coldspl."></td>";
        }
    }else{
       $tmpdft="";
       if ($_GET["s_".hou($kpart[$pp],".")."0"]==""){
         if (hou($keyinfo[hou($kpart[$pp],".")]["COLUMN_SSHOW"],"|")!=""){
           $x=eval(hou($keyinfo[hou($kpart[$pp],".")]["COLUMN_SSHOW"],"|"));
           $tmpdft=$thusvalue;
         };
       }else{
         $tmpdft=$_GET["s_".hou($kpart[$pp],".")."0"];
       };
         if (hou($kpart[$pp],".")=="SNO"){
           $snodspl="style=\"display:none;\"";
         }else{
           $snodspl="";
         };
     
         $fmtb=$fmtb."<td knm=\"".hou($kpart[$pp],".")."\" ".$coldspl."><input id=\"p_".hou($kpart[$pp],".")."0\" size=\"10\" value=\"".$tmpdft."\" ".$snodspl."   placeholder=\"".hou($kpart[$pp],".")."\"  ></td>\r\n";//$keyinfo[hou($kpart[$pp],".")]["COLUMN_TITLE"]
     };
   $tmpdft="";
    if (hou($kpart[$pp],".")!="SNO"){
     $fmdt=$fmdt."'&p_".hou($kpart[$pp],".")."0='+$('#p_".hou($kpart[$pp],".")."0').val()+";
     $fmsdt=$fmsdt."'&s_".hou($kpart[$pp],".")."0='+$('#p_".hou($kpart[$pp],".")."0').val()+";
    };
  };
   $fmdt="'".substr($fmdt,2,strlen($fmdt)-3);
   $fmsdt=substr($fmsdt,2,strlen($fmsdt)-3);
  if (strpos(".".$dtp.$headx,"nooprt")<=0 and ($additemx*1)==1 and ($oprtx*1)==1){
    if (strpos($tbnm,",")>0){//没有太大区分
     $fmtb=$fmtb."<td knm=\"operation\">";
     if (strpos(".".$dtp,"nocreate")<=0){       
      $fmtb=$fmtb."<a href=\"javascript:void(0)\" onclick=\"qajaxps('新建','//".$surl."/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&SNO=0&kies=".$tbkis."',".$fmdt.");\"><img src=\"/ORG/BRAIN/images/icon/system/newitem.svg\" style=\"width:20px;height:20px\"></a>";
     };
     $fmtb=$fmtb."</th>\r\n";//"<button class=\"search\"  onclick=\"search('搜索','?".$fmsdt."+'".$fmkeyn."&search=1','');\">搜索</button>
    }else{
     $fmtb=$fmtb."<td knm=\"operation\">";
     if (strpos(".".$dtp,"nocreate")<=0){
       $fmtb=$fmtb."<a href=\"javascript:void(0)\" onclick=\"qajaxps('新建','//".$surl."/DNA/EXF/anyrcv.php?appid=".$appid."&tbnm=".$tbnm."&SNO=0&kies=".$tbkis."',".$fmdt.");\"><img src=\"/ORG/BRAIN/images/icon/system/newitem.svg\" style=\"width:20px;height:20px\"></a>";
     };
     $fmtb=$fmtb."</th>\r\n";//<button class=\"search\"  onclick=\"search('搜索','?".$fmsdt."+'".$fmkeyn."&search=1','');\">搜索</button>
    };
  };
  $fmtb=$fmtb."</tr>";
  $tmptbmid=$tmptbmid.$tmpnewrow;
  //-----------------------------------------------  
  //$fmch=$fmch.$demo;
};
  
  
   if ($totrst>0){
    $fmjs=substr($fmjs,0,strlen($fmjs)-1)."]}";
     $fmjh=substr($fmjh,0,strlen($fmjh)-1)."]}";
   }else{
    $fmjs=$fmjs.$fmdft."]}";
     $fmjh=$fmjh.$fmdft."]}";
   };
 $fmtp=$fmtp."</tbody></table></div>";
 $fmtb=$fmtb."</tbody></table></form></div>\r\n";
  //<form class="layui-form" action="">
  $oritb=$fmtb;
  $xid="";
  $stid="";
    if (strpos($dtp,"sid:")>0){
    $stid=qian(hou($dtp,"sid:"),"/")."-sfile:".$sowf."-pnum:".$pgn."-";
    $xid=qian(hou($dtp,"sid:"),"/");
  };
  if ($stid==""){
    $stid=$_GET["stid"];
    $xid=qian($stid,"-");
  };//
  $fmsc='<div class="console">
    <div class="layui-form-item">
      <div class="layui-input-inline">
        <input type="text" id="searchkey" name="searchkey" required lay-verify="required" placeholder="输入关键词" autocomplete="off" class="layui-input">
      </div>
      <button class="layui-btn" lay-submit lay-filter="submitBut" onclick="topage(\'\',\''.$sowf.'?stid='.$stid.'&pnum=\'+document.getElementById(\'searchkey\').value+\'&page=@@@\');">检索</button><a class="layui-btn" onclick="supersearch(\''.$xid.'\',0)">超级检索</a>
      <a class="layui-btn" style="[nbdspl]" onclick="update(\'[addpage]\',0)">[xzjl]</a><a class="layui-btn" onclick="deliv(\''.$xid.'\',0)">打印页面</a>[diybutton]<a class="layui-btn" onclick="downv(\''.$xid.'\',0)">下载数据</a><span id="xzdz"></span>&nbsp;&nbsp;&nbsp;<a href="javascript:void(0);" onclick="newwin(\'工单列表\',\'/DNA/EXF/anyfun.php?fid=getpurlbystid&sid='.qian($stid,"-").'\')"><img src="/ORG/BRAIN/images/icon/system/probm.svg" style="width:40px;height:40px;"></a>&nbsp;<a href="javascript:void(0);" onclick="newwin(\'使用说明\',\'/SPEC/EDITOR/anyjsshort.php?stid=7nf2NL-sfile:anyjsshort.php-pnum:30-&sid='.qian($stid,"-").'\')"><img src="/ORG/BRAIN/images/icon/system/detail2.svg" style="width:40px;height:40px;"></a>&nbsp;<a href="javascript:void(0);" onclick="newwin(\'查看评论\',\'/DNA/EXF/anyfun.php?fid=getcurlbystid&stid='.$stid.'\')"><img src="/ORG/BRAIN/images/icon/system/liuyan1.svg" style="width:40px;height:40px;"></a>&nbsp;<a href="javascript:void(0);" onclick="window.location.reload()"><img src="/ORG/BRAIN/images/icon/system/renew.svg" style="width:40px;height:40px;"></a>&nbsp;<a href="javascript:void(0);" onclick="window.history.go(-1);"><img src="/ORG/BRAIN/images/icon/system/return.svg" style="width:40px;height:40px;"></a>
    </div>
</div>';
  //aneVcy
  if ($addpage!=""){
    $nhtxt=$addpage;
      $ptnhtxt=explode("[get-",$nhtxt);
   $totpt=count($ptnhtxt);
   for ($f=0;$f<$totpt;$f++){
      $tmpok=qian($ptnhtxt[$f],"]");
      $nhtxt=str_replace("[get-".$tmpok."]",$_GET[$tmpok],$nhtxt);
     //$arrdt[[$tmpok][$dn]
   };
 if (strpos($nhtxt,"{atv-")>0){
   $ptatv=explode("{atv-",$nhtxt);
   $totatv=count($ptatv);
   for ($g=0;$g<$totatv;$g++){
      $tmpatv=qian($ptatv[$g],"}");
      $nhtxt=str_replace("{atv-".$tmpatv."}",atv($tmpatv),$nhtxt);
     //$arrdt[[$tmpok][$dn]
   };
  };
  if (strpos($nhtxt,"{utv-")>0){
   $ptutv=explode("{utv-",$nhtxt);
   $totutv=count($ptutv);
   for ($h=0;$h<$totutv;$h++){
      $tmputv=qian($ptutv[$h],"}");
      $nhtxt=str_replace("{utv-".$tmputv."}",utv($tmputv),$nhtxt);
     //$arrdt[[$tmpok][$dn]
   };
  };
     $nhtxt=str_replace("[shortid]",$xid,$nhtxt);    
      $nhtxt=str_replace("[tablename]",$tbnm,$nhtxt);
    $addpage=$nhtxt;
  }
  
  if ($fmx!=""){
    $nhtxt=$fmx;
      $ptnhtxt=explode("[get-",$nhtxt);
   $totpt=count($ptnhtxt);
   for ($f=0;$f<$totpt;$f++){
      $tmpok=qian($ptnhtxt[$f],"]");
      $nhtxt=str_replace("[get-".$tmpok."]",$_GET[$tmpok],$nhtxt);
     //$arrdt[[$tmpok][$dn]
   };
 if (strpos($nhtxt,"{atv-")>0){
   $ptatv=explode("{atv-",$nhtxt);
   $totatv=count($ptatv);
   for ($g=0;$g<$totatv;$g++){
      $tmpatv=qian($ptatv[$g],"}");
      $nhtxt=str_replace("{atv-".$tmpatv."}",atv($tmpatv),$nhtxt);
     //$arrdt[[$tmpok][$dn]
   };
  };
  if (strpos($nhtxt,"{utv-")>0){
   $ptutv=explode("{utv-",$nhtxt);
   $totutv=count($ptutv);
   for ($h=0;$h<$totutv;$h++){
      $tmputv=qian($ptutv[$h],"}");
      $nhtxt=str_replace("{utv-".$tmputv."}",utv($tmputv),$nhtxt);
     //$arrdt[[$tmpok][$dn]
   };
  };
      $nhtxt=str_replace("[shortid]",$xid,$nhtxt);
      $nhtxt=str_replace("[tablename]",$tbnm,$nhtxt);
    $fmx=$nhtxt;
  }
    if ($dbtn!=""){
    $nhtxt=$dbtn;
      $ptnhtxt=explode("[get-",$nhtxt);
   $totpt=count($ptnhtxt);
   for ($f=0;$f<$totpt;$f++){
      $tmpok=qian($ptnhtxt[$f],"]");
      $nhtxt=str_replace("[get-".$tmpok."]",$_GET[$tmpok],$nhtxt);
     //$arrdt[[$tmpok][$dn]
   };
 if (strpos($nhtxt,"{atv-")>0){
   $ptatv=explode("{atv-",$nhtxt);
   $totatv=count($ptatv);
   for ($g=0;$g<$totatv;$g++){
      $tmpatv=qian($ptatv[$g],"}");
      $nhtxt=str_replace("{atv-".$tmpatv."}",atv($tmpatv),$nhtxt);
     //$arrdt[[$tmpok][$dn]
   };
  };
  if (strpos($nhtxt,"{utv-")>0){
   $ptutv=explode("{utv-",$nhtxt);
   $totutv=count($ptutv);
   for ($h=0;$h<$totutv;$h++){
      $tmputv=qian($ptutv[$h],"}");
      $nhtxt=str_replace("{utv-".$tmputv."}",utv($tmputv),$nhtxt);
     //$arrdt[[$tmpok][$dn]
   };
  };
      $nhtxt=str_replace("[shortid]",$xid,$nhtxt);
      $nhtxt=str_replace("[tablename]",$tbnm,$nhtxt);
    $dbtn=$nhtxt;
  }
    $fmsc=str_replace("[diybutton]","",$fmsc);
    if ($addtitle!=""){
      $fmsc=str_replace("[xzjl]",$addtitle,$fmsc);
    }else{
      $fmsc=str_replace("[xzjl]","新增记录",$fmsc);
    }
   if ($addpage!=""){
     $fmsc=str_replace("[addpage]",$addpage,$fmsc);
   }else{
     $fmsc=str_replace("[addpage]",$xid,$fmsc);
   }
   if (($newbutton*1)==1){
     $fmsc=str_replace("[nbdspl]","",$fmsc);
   }else{
     $fmsc=str_replace("[nbdspl]","display:none;",$fmsc);
   };
  if (($allkillbtn*1)==1){
    $allkh="";
  }else{
    $allkh="style=\"display:none;\"";
  }
  if (($topbtn*1)==1){
    $fmtb=$fmsc.$fmtb."<div id=\"customPages\" class=\"customPages\"><span class=\"layui-laypage-count\">共".$totrst."条</span>&nbsp;&nbsp;&nbsp;<a class=\"layui-btn\" id=\"tbnm\" tbnm=\"".$tbnm."\" ".$allkh." onclick=\"plsc('".$surl."','".$tbnm."');\">批量删除</a>&nbsp;&nbsp;&nbsp;<a class=\"layui-btn\"  onclick=\"quanxuan();\">全选</a>&nbsp;&nbsp;&nbsp;<a href=\"javascript:void(0)\" id=\"isu\" onclick=\"changeb()\"><img src=\"/ORG/BRAIN/images/icon/system/xg0.svg\" style=\"width:20px;height:20px;\"></a><input id=\"isupdate\" type=\"hidden\" lay-skin=\"primary\" value=\"0\"></div> ";
  }else{
    $fmtb=$fmtb."<div id=\"customPages\" class=\"customPages\"><span class=\"layui-laypage-count\">共".$totrst."条</span>&nbsp;&nbsp;&nbsp;<a class=\"layui-btn\" id=\"tbnm\" tbnm=\"".$tbnm."\" ".$allkh." onclick=\"plsc('".$surl."','".$tbnm."');\">批量删除</a>&nbsp;&nbsp;&nbsp;<a class=\"layui-btn\"  onclick=\"quanxuan();\">全选</a>&nbsp;&nbsp;&nbsp;<a href=\"javascript:void(0)\" id=\"isu\" onclick=\"changeb()\"><img src=\"/ORG/BRAIN/images/icon/system/xg0.svg\" style=\"width:20px;height:20px;\"></a><input id=\"isupdate\" type=\"hidden\" lay-skin=\"primary\" value=\"0\"></div> ";
  }
  $fmscript="<script>";
 
//createsmtb
 $fmscript=$fmscript."</script>\r\n";
//echo "dtpx=".$dtp;
//echo "fmexl=".$fmexl;
//echo "fmjhhhhhhhhhhhhhhhhhh-".$fmjh;
  if ($diybottom!=""){
    
        $nhtxt=$diybottom;
      $ptnhtxt=explode("[get-",$nhtxt);
   $totpt=count($ptnhtxt);
   for ($f=0;$f<$totpt;$f++){
      $tmpok=qian($ptnhtxt[$f],"]");
      $nhtxt=str_replace("[get-".$tmpok."]",$_GET[$tmpok],$nhtxt);
     //$arrdt[[$tmpok][$dn]
   };
 if (strpos($nhtxt,"{atv-")>0){
   $ptatv=explode("{atv-",$nhtxt);
   $totatv=count($ptatv);
   for ($g=0;$g<$totatv;$g++){
      $tmpatv=qian($ptatv[$g],"}");
      $nhtxt=str_replace("{atv-".$tmpatv."}",atv($tmpatv),$nhtxt);
     //$arrdt[[$tmpok][$dn]
   };
  };
  if (strpos($nhtxt,"{utv-")>0){
   $ptutv=explode("{utv-",$nhtxt);
   $totutv=count($ptutv);
   for ($h=0;$h<$totutv;$h++){
      $tmputv=qian($ptutv[$h],"}");
      $nhtxt=str_replace("{utv-".$tmputv."}",utv($tmputv),$nhtxt);
     //$arrdt[[$tmpok][$dn]
   };
  };
     $nhtxt=str_replace("[shortid]",$xid,$nhtxt);    
      $nhtxt=str_replace("[tablename]",$tbnm,$nhtxt);
    $diybottom=$nhtxt;
  }
$btmsrd=$diybottom;
    
  
 $csurd=str_replace("[inner]",$fmch,$csurd);
 // echo $fmch."@@@@@@@@@@";
 if (strpos(".".$dtp,'json')>0){
  return $fmjs;
 };
 if (strpos(".".$dtp,'jshtm')>0){
  return $fmjh;
 };
  if (($dtx*1)==0 and $dtx!=""){
    $fmtb="";
  };
 if (strpos(".".$dtp,'html')>0 or $dtp==" "){
   if (($bottombtn*1)==1){
     if ($diytop!=""){
       return $dbtn.$diytop.$fmtb.$btmsrd.$tmpdtx.$fmscript;
     }else{
       return $dbtn.$fmtb.$btmsrd.$tmpdtx.$fmscript;
     }
   }else{
     if ($diytop!=""){
       return $dbtn.$diytop.$fmtb.$tmpdtx.$fmscript;
     }else{
       return $dbtn.$fmtb.$tmpdtx.$fmscript;
     }
   }
 };
  if (strpos(".".$dtp,'table')>0 or $dtp==" "){
  return $oritb;
 };
 if (strpos(".".$dtp,'imgx')>0 or $dtp==" "){
  return $csurd.$tmpdtx.$fmscript;
 };
 if (strpos(".".$dtp,'excel')>0 ){
  return $fmexl;
 }
 if (strpos(".".$dtp,'print')>0 ){
  return $fmtp;
 }
 if (strpos(".".$dtp,'diy')>0){
  return $tmptbmid;
 };
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>