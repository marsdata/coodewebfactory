<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $enkeys=dftval($_GET["enkeys"],"");
$dey=$enkeys."这是MYSQL数据库表中的字段名,根据整体,建议一下该表格的中英文名称，不是字段名称，仅表格，格式为 englishtabname@chinesetabname";
$rtntxt=file_get_contents(combineurl("http://".glw(),"/localxres/funx/getcodebyai/?askstr=".$dey));
if ($rtntxt!="NoCode."){
 $rtntxt=str_replace(huanhang(),"",$rtntxt);
 echo $rtntxt;
}else{
 echo "";
}//nocode
 
     session_write_close();
?>