<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $enkeys=dftval($_GET["enkeys"],"");
$ptenk=explode(",",$enkeys);
$totc=count($ptenk);
$dey=$enkeys."这是MYSQL数据库表中的字段名,根据整体,还原一下他们的中文名称,回复格式为 englishcolname:chinesename;";
$rtntxt=file_get_contents(combineurl("http://".glw(),"/localxres/funx/getcodebyai/?askstr=".$dey));
$fmkeys="";
if ($rtntxt!="NoCode." ){
 if (strpos($rtntxt,";")>0 ){
   $newrtntxt=str_replace(huanhang(),"",$rtntxt);   
   $ptnew=explode(";",$newrtntxt);
   $totpt=count($ptnew);
   for ($pp=0;$pp<$totpt;$pp++){
    $tmpstr=str_replace(" ","",$ptnew[$pp]);
     if ($tmpstr!=""){
      $tmpkey=$ptenk[$pp];
      if (strpos($tmpstr,":")>0){      
        $fmkeys=$fmkeys.qian($ptnew[$pp],":")."@".hou($tmpstr,":")."/";            
      }else{
        $fmkeys=$fmkeys.$tmpkey."@".$tmpstr."/";
      }      
     }
    }//forpp   
    $fmkeys=killlaststr($fmkeys);
  }else{
    $fmkeys="";
  }//rtntxt
 }else{
  $fmkeys="";
 }//nocode
 echo $fmkeys;
     session_write_close();
?>