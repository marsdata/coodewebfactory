<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $chkeys=dftval($_GET["chkeys"],"");
$ptchk=explode(",",$chkeys);
$totc=count($ptchk);
$dey="将".$chkeys."这几个词变成mysql数据库表的字段，如何用英文命名这些字段";
$rtntxt=file_get_contents(combineurl("http://".glw(),"/localxres/funx/getcodebyai/?askstr=".$dey));
$fmkeys="";
if ($rtntxt!="NoCode."){
 $pttxt=explode(huanhang(),$rtntxt); 
 $totp=count($pttxt);
 if (strpos($rtntxt,",")>0 and $totp<$totc){
   $newrtntxt=str_replace(huanhang(),"",$rtntxt);   
   $ptnew=explode(",",$newrtntxt);
   $totpt=count($ptnew);
   for ($pp=0;$pp<$totpt;$pp++){
    $tmpstr=$ptnew[$pp];
    if (strpos($tmpstr,"_")>0){
      $tmpstr=str_replace(" ","",$tmpstr);
    }else{
      $tmpstr=str_replace(" ","_",$tmpstr);
    }
     if (strpos($tmpstr,".")>0){
      if (strpos($tmpstr,":")>0){
        $fmkeys=$fmkeys.qian(hou($ptnew[$pp],"."),":")."@".strtolower(hou($tmpstr,":"))."/";
      }else{
        $fmkeys=$fmkeys.hou($ptnew[$pp],".")."@".strtolower(hou($tmpstr,"."))."/";
      }
     }else{
        $fmkeys=$fmkeys.str_replace("_"," ",$tmpstr)."@".strtolower($tmpstr)."/";
     }
    }//forpp   
 }else{
  for ($pp=0;$pp<$totp;$pp++){
    $tmpstr=str_replace(" ","",$pttxt[$pp]);    
    if (strpos($tmpstr,".")>0){
     if (strpos($tmpstr,":")>0){
       $fmkeys=$fmkeys.qian(hou($pttxt[$pp],"."),":")."@".strtolower(hou($tmpstr,":"))."/";
     }else{
       $fmkeys=$fmkeys.hou($pttxt[$pp],".")."@".strtolower(hou($tmpstr,"."))."/";
     }
    }
   }//forpp
  }//rtndouhao
  $fmkeys=killlaststr($fmkeys);
  $ptkx=explode("/",$fmkeys);
  $totk=count($ptkx);
  if ($totk==$totc){
    echo $fmkeys;
  }else{
   $fmkeys="";
   for ($kk=0;$kk<$totc;$kk++){
    $tmpchk=$ptchk[$kk];
    $chlen=chlength($tmpchk,1,"UTF-8");
    if ($chlen<=3){
      $fmkeys=$fmkeys.chitopy($tmpchk)."@".chitopy($tmpchk)."_".strtolower(getRandChar(3))."/";
    }else{
      $fmkeys=$fmkeys.chitopy($tmpchk)."@".chitopyx($tmpchk)."_".strtolower(getRandChar(3))."/";
    }
   }
   $fmkeys=killlaststr($fmkeys);
   echo $fmkeys;
  }
}else{
  for ($kk=0;$kk<$totc;$kk++){
    $tmpchk=$ptchk[$kk];
    $chlen=chlength($tmpchk,1,"UTF-8");
    if ($chlen<=3){
      $fmkeys=$fmkeys.chitopy($tmpchk)."@".chitopy($tmpchk)."_".strtolower(getRandChar(3))."/";
    }else{
      $fmkeys=$fmkeys.chitopy($tmpchk)."@".chitopyx($tmpchk)."_".strtolower(getRandChar(3))."/";
    }
  }
  $fmkeys=killlaststr($fmkeys);
  echo $fmkeys;
}
     session_write_close();
?>