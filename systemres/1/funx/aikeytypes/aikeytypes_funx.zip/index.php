<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $chkeyx=dftval($_GET["chkeyx"],"");
$dey="这个字段名为".$chkeyx."在MYSQL中应该采用什么字段类型，回复格式为:datatype(length)";
$rtntxt=file_get_contents(combineurl("http://".glw(),"/localxres/funx/getcodebyai/?askstr=".$dey));
$fmkeys="";
if ($rtntxt!="NoCode."){
  $newrtntxt=str_replace(huanhang(),"",$rtntxt);     
  if (strpos($rtntxt,",")>0 ){
     $newrtntxt=qian($newrtntxt,",");
  }
  echo $newrtntxt;
}
     session_write_close();
?>