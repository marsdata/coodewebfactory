<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $expx=dftval($_GET["expx"],"");
$titlex=dftval($_GET["titlex"],"");
$datatype=dftval($_GET["datatype"],"");
 $sizex=qian($expx,"@");
 $wx=qian($sizex,"x");
 $hx=hou($sizex,"x");
 $colorx=qian(hou($expx,"@"),"-");
 $shapex=qian(hou($expx,"-"),".");  
//$expx=30x30@red-0.svg
$kzmx=kuozhanming($expx);
$xingzhuang=array();
$xingzhuang["0"]="圆形";
$xingzhuang["1"]="高长方形";
$xingzhuang["2"]="矮长方形";
$xingzhuang["3"]="三角形";
$xingzhuang["4"]="正方形";
$xingzhuang["5"]="星形";
$xingzhuang["6"]="";
switch($kzmx){
  case "svg":
  if ($colorx=="000000" or $colorx==""){
   $dex="含义为".$titlex.$kzmx."图标";   
  }else{
   $dex="含义为".$titlex."的多色且宽为".$wx."，高为".$hx.$kzmx."图标";   
  }
  $dey="请返回".$dex."的SVG代码";
  break;
  case "png":
  if ($sizex=="0x0"){
   $dex="含义为".$titlex.$kzmx."图标";   
  }else{
   $dex="含义为".$titlex."宽为".$wx."px，高为".$hx."px".$kzmx."图标";   
  }
  $dey="请返回".$dex."的网络资源地址";
  break;
  case "jpg":
  if ($sizex=="0x0"){
   $dex="含义为".$titlex.$kzmx."图标";
  }else{
   $dex="含义为".$titlex."宽为".$wx."px，高为".$hx."px".$kzmx."图标";
  }
  $dey="请返回".$dex."的网络资源地址";
  break;
  case "gif":
  if ($sizex=="0x0"){
    $dex="含义为".$titlex.$kzmx."图标";
  }else{
    $dex="含义为".$titlex."宽为".$wx."px，高为".$hx."px".$kzmx."图标";
  }  
  $dey="请返回".$dex."的动图网络资源地址";
  break;
  default:
}
$rtntxt=file_get_contents(combineurl("http://".glw(),"/localxres/funx/getcodebyai/?askstr=".$dey));
switch($kzmx){
  case "svg":
  if ($datatype=="json"){
    echo '{"status":"1","sizex":"'.$sizex.'","titlex":"'.$titlex.'","colorx":"'.$colorx.'","shapex":"'.$xingzhuang[$shapex].'","describx":"'.$dex.'","data":"'."<svg".str_replace(huanhang(),"",str_replace("\"","\\\"",hou($rtntxt,"<svg"))).'"}';
  }else{
    echo "<svg".str_replace(huanhang(),"",str_replace("\"","\\\"",hou($rtntxt,"<svg")));
  } 
  break;
  case "png":  
  if ($datatype=="json"){
    echo '{"status":"1","sizex":"'.$sizex.'","titlex":"'.$titlex.'","colorx":"'.$colorx.'","shapex":"'.$xingzhuang[$shapex].'","describx":"'.$dex.'","data":"'."http".hou($rtntxt,"http").'"}';
  }else{
    echo "http".hou($rtntxt,"http");
  }
  break;
  case "jpg":  
  if ($datatype=="json"){
    echo '{"status":"1","sizex":"'.$sizex.'","titlex":"'.$titlex.'","colorx":"'.$colorx.'","shapex":"'.$xingzhuang[$shapex].'","describx":"'.$dex.'","data":"'."http".hou($rtntxt,"http").'"}';
  }else{
    echo "http".hou($rtntxt,"http");
  }
  break;
  case "gif":
  if ($datatype=="json"){
    echo '{"status":"1","sizex":"'.$sizex.'","titlex":"'.$titlex.'","colorx":"'.$colorx.'","shapex":"'.$xingzhuang[$shapex].'","describx":"'.$dex.'","data":"'."http".hou($rtntxt,"http").'"}';
  }else{
    echo "http".hou($rtntxt,"http");
  }
  break;
  default:
}
     session_write_close();
?>