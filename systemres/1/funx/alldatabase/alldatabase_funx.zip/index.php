<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $itemdemo='{"dbname":"[dbname]","dbtitle":"[dbtitle]"},';
$sysdbrst=SX("select dbname,dbtitle from coode_dblist");
$tots=countresult($sysdbrst);
$tmp0="";
$tmp1="";
for ($j=0;$j<$tots;$j++){
 $dbname=anyvalue($sysdbrst,"dbname",$j);
 $dbtitle=anyvalue($sysdbrst,"dbtitle",$j);
 $item=$itemdemo;
 $item=str_replace("[dbname]",$dbname,$item);
 $item=str_replace("[dbtitle]",$dbtitle,$item);
 $tmp0=$tmp0.$item;
}
$mydbrst=SX("select dbname,dbtitle from coode_mydblist where CRTOR='".$_COOKIE["uid"]."'");
$totb=countresult($mydbrst);
for ($j=0;$j<$totb;$j++){
 $dbname=anyvalue($mydbrst,"dbname",$j);
 $dbtitle=anyvalue($mydbrst,"dbtitle",$j);
 $item=$itemdemo;
 $item=str_replace("[dbname]",$dbname,$item);
 $item=str_replace("[dbtitle]",$dbtitle,$item);
 $tmp1=$tmp1.$item;
}
$tmp0=killlaststr($tmp0);
$tmp1=killlaststr($tmp1);
echo '{"sysdb":['.$tmp0.'],"mydb":['.$tmp1.']}';
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>