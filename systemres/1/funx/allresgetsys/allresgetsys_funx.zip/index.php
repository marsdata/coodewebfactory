<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $b=time();
$bb1=UX("update coode_sysregres,coode_funlist set coode_sysregres.grpid=coode_funlist.sysid where coode_sysregres.resmark=coode_funlist.funname");
$bb2=UX("update coode_sysregres,coode_domainunit set  coode_sysregres.grpid=coode_domainunit.sysid where  coode_sysregres.resmark=coode_domainunit.dumark");
$bb3=UX("update coode_sysregres,coode_tablist set coode_sysregres.grpid=coode_tablist.sysid where coode_sysregres.resmark=coode_tablist.TABLE_NAME");
$bb4=UX("update coode_sysregres,coode_plotlist set coode_sysregres.grpid=coode_plotlist.sysid where coode_sysregres.resmark=coode_plotlist.plotmark");
$bb5=UX("update coode_sysregres,coode_phpcls set coode_sysregres.grpid=coode_phpcls.sysid where coode_sysregres.resmark=coode_phpcls.funname");
$bb6=UX("update coode_sysregres,coode_shortdata set coode_sysregres.grpid=coode_shortdata.sysid where coode_sysregres.resmark=coode_shortdata.shortid");
$bb7=UX("update coode_sysregres,coode_tiny set coode_sysregres.grpid,coode_tiny.sysid where  coode_sysregres.resmark=coode_tiny.tinymark");
$bb8=UX("update coode_sysregres,coode_dataspace set coode_sysregres.grpid=coode_dataspace.sysid where coode_sysregres.resmark=coode_dataspace.datamark");
$bb9=UX("update coode_sysregres,coode_funsetfile set coode_sysregres.grpid=coode_funsetfile.sysid where coode_sysregres.resmark=coode_funsetfile.setmark");
$bb10=UX("update coode_sysregres,coode_datafun set coode_sysregres.grpid=coode_datafun.sysid where coode_sysregres.resmark=coode_datafun.dfunmark");
$bb11=UX("update coode_sysregres,coode_multifunlist set coode_sysregres.grpid=coode_multifunlist.sysid where coode_sysregres.resmark=coode_multifunlist.funname");
$bb12=UX("update coode_sysregres,coode_affairfunlist set coode_sysregres.grpid=coode_affairfunlist.sysid where coode_sysregres.resmark=coode_affairfunlist.funname");
$bb13=UX("update coode_sysregres,coode_cdtrdr set coode_sysregres.grpid=coode_cdtrdr.sysid where coode_sysregres.resmark=concat(coode_cdtrdr.cdtmark,coode_cdtval)");
$bb14=UX("update coode_sysregres,coode_parardr set coode_sysregres.grpid=coode_parardr.sysid where coode_sysregres.resmark=coode_parardr.paramark");
$bb15=UX("update coode_sysregres,coode_sysconstant set coode_sysregres.grpid=coode_sysconstant.sysid where coode_sysregres.resmark=coode_sysconstant.constantid");
$bb16=UX("update coode_sysregres,coode_sysconfig set  coode_sysregres.grpid,coode_sysconfig.sysid where  coode_sysregres.resmark=coode_sysconfig.syskey");
$bb17=UX("update coode_sysregres,coode_para set coode_sysregres.grpid=coode_para.sysid where coode_sysregres.resmark=coode_para.paramark");
$bb18=UX("update coode_sysregres,coode_iconset set coode_sysregres.grpid=coode_iconset.sysid where coode_sysregres.resmark=coode_iconset.setmark");
$bb19=UX("update coode_sysregres,coode_sysinformation set coode_sysregres.grpid=coode_sysinformation.sysid where coode_sysregres.resmark=coode_sysinformation.sysid");
$bb20=UX("update coode_sysregres,coode_appdefault set coode_sysregres.grpid=coode_appdefault.sysid where coode_sysregres.resmark=coode_appdefault.appid");
$bb21=UX("update coode_sysregres,coode_applay set coode_sysregres.grpid=coode_applay.sysid where coode_sysregres.resmark=coode_applay.layid");
//$bb22=UX("update coode_sysregres,coode_facelist set coode_sysregres.grpid=coode_facelist.sysid where  coode_sysregres.resmark=coode_facelist.faceid");
$bb23=UX("update coode_sysregres,coode_para set coode_sysregres.grpid=coode_para.sysid where coode_sysregres.resmark=coode_para.paramark");
$bb24=UX("update coode_sysregres,coode_affairfunlist set coode_sysregres.grpid=coode_affairfunlist.sysid where coode_sysregres.resmark=coode_affairfunlist.funname");
$a=time();
echo makereturnjson("1","成功".($b-$a)."秒","");
     session_write_close();
?>