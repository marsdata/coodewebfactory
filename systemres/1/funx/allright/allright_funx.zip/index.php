<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $a=time();
if ($_COOKIE["uid"]!=""){
   $srst=SX("select restypecode,relyotherres from coode_sysrestypedefine");
   $totx=countresult($srst);
   for ($ii=0;$ii<$totx;$ii++){
      $rlot=anyvalue($srst,"relyotherres",$ii);
      if (strpos($rlot,",")>1){
        $ptot=explode(",",$rlot);
        for ($jj=0;$jj<count($ptot);$jj++){
          $zzz=UX("update ".$ptot[$jj]." set CRTOR='".$_COOKIE["uid"]."'");
        }
      }else{
        $zzz=UX("update ".qian($rlot,".")." set CRTOR='".$_COOKIE["uid"]."'");
      }
   }
   $zz1=UX("update coode_role set CRTOR='".$_COOKIE["uid"]."'");
   $zz2=UX("update coode_userlist set CRTOR='".$_COOKIE["uid"]."'");
   $kk=UX("delete from coode_devespace where askman='".$_COOKIE["uid"]."'");
   $newr=UX("insert into coode_devespace(restype,rescode,restitle,askman,CRTM,UPTM,OLMK,STATUS)select restype,resmark,restitle,'".$_COOKIE["uid"]."',now(),now(),md5(RAND()*100),1 from coode_sysregres group by concat(restype,resmark)");
   $nn=anyfunrun("retabsno","","tabnm=coode_devespace","");
   $b=time();
   echo makereturnjson("1","获取全部开发权限成功-耗时".($b-$a)."秒","");
}else{
  echo makereturnjson("0","获取全部开发权限失败","");
}
     session_write_close();
?>