<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     eval(RESFUNSET("resrelyrp"));
$khis=UX("delete from coode_pagevisit where timestampdiff(hour,visittime,now())>24*7");
$hrst=SX("select SNO,pageurl,visitfunurl from coode_pagevisit where STATUS=0 order by visittime limit 0,50 ");
$toth=countresult($hrst);
for ($jj=0;$jj<$toth;$jj++){
  $snox=anyvalue($hrst,"SNO",$jj);
  $pu=anyvalue($hrst,"pageurl",$jj);
  $fv=anyvalue($hrst,"visitfunurl",$jj);
  $uu=hou($pu,"localxres/");  
  $ptu=explode("/",$uu);
  $ptype=$ptu[0];
  $pcode=$ptu[1];
  $prestype="";
  $prescode="";
  $oprtx="";
  if ($pu!=""){
   switch($ptype){
    case "pagex":
    $prestype="pagex";
    $prescode=$ptu[4];
    break;
    case "tempx":
    $prestype="tempx";
    $prescode=$pcode.".".qian(hou($pu,$pcode."/"),".html");
    break;
    case "funx":    
      switch($pcode){
        case "anyjsshort":
         $prestype="formx";
         $prescode=qian(qian(hou($pu,"stid="),"&"),"-");
        break;
        case "anyshortnew":
         $prestype="formx";
         $prescode=qian(qian(hou($pu,"stid="),"&"),"-");
        break;
        default:        
      }
    break;
    default:    
   }  
  }
  if ($fv!=""){
   $vv=hou($fv,"localxres/");
   $ptv=explode("/",$vv);  
   $ftype=$ptv[0];
   $fcode=$ptv[1];
   switch($ftype){
    case "funx":
      switch($fcode){
        case "anytiny":
         $tinyx=qian(hou($fv,"tiny="),"&");
         $oprtx="pagex@".$tinyx;
        break;
        default:        
         $oprtx="";
      }
    break;
    case "tempx":
     $oprtx="tempx@".$fcode.".".qian($ptv[2],".html");
    break;
    case "pagex":
     $oprtx="pagex@".$ptv[4];
    break;
    default:
   }
  }
  $bb=addsrctores($ftype,$fcode,$prestype,$prescode);
  if ($oprtx!=""){
     $relytp=qian($oprtx,"@");
     $relycd=hou($oprtx,"@");
     //$zz=addsrctores($relytp,$relycd,$prestype,$prescode);
  }
  $funtitle=UX("select restitle as result from coode_sysregres where restype='".$ftype."' and resmark='".$fcode."'");
  $pagetitle=UX("select restitle as result from coode_sysregres where restype='".$prestype."' and resmark='".$prescode."'");
  $zz=UX("update coode_pagevisit set UPTM=now(),STATUS=1,pagetype='".$ptype."',restype='".$prestype."',restitle='".$pagetitle."',rescode='".$prescode."',funsettype='".$ftype."',funid='".$fcode."',funtitle='".$funtitle."',oprtrescode='".$oprtx."',UPTM=now() where SNO=".$snox);  
}
$leftx=UX("select count(*) as result from coode_pagevisit where STATUS=0 ");
echo makereturnjson("1","操作正常，剩余".intval($leftx),"");
     session_write_close();
?>