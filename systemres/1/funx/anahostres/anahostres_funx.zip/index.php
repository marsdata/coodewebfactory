<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
        //该方法要异步执行,资源机构归属表,判断是否归属该机构，如果归属用归属的版本；如果非该机构则，依据不同客户端存储
$crst=SX("select SNO,sysid,restype,clientcode,clienthost,rescode,resver from coode_clientres where STATUS=0 limit 0,1");
$snox=anyvalue($crst,"SNO",0);
$restype=anyvalue($crst,"restype",0);
$sysid=anyvalue($crst,"sysid",0);
$clientcode=anyvalue($crst,"clientcode",0);
$clienthost=anyvalue($crst,"clienthost",0);
$rescode=anyvalue($crst,"rescode",0);
$resver=anyvalue($crst,"resver",0);
   //执行异步同步的时候查看是否是母服务器资源，
$xtrst=SX("select SNO,clientcode from coode_sysdefine where sysid='".$sysid."'");
$xtsno=anyvalue($xtrst,"SNO",0);
$xtcode=anyvalue($xtrst,"clientcode",0);
$extthis=UX("select count(*) as result from coode_syshostres where  clientcode='".$clientcode."' and rescode='".$rescode."'");
if (intval($extthis)==0){
  $sqla="clientcode,rescode,restype,vermd5,restitle,CRTM,UPTM,OLMK";
  $sqlb="'".$clientcode."','".$rescode."','".$restype."','".$resver."','',now(),now(),'".onlymark()."'";
  $cc=UX("insert into coode_syshostres(".$sqla.")values(".$sqlb.")");
}else{
  $ccc=UX("update coode_syshostres set vermd5='".$resver."',UPTM=now() where  clientcode='".$clientcode."' and rescode='".$rescode."'");
}
if ($xtcode==$clientcode){
    //如果是母机资源则用母机目录 
    //也要看下是否与老版本是否一致，如果一直则不用操作
    $xrst=SX("select vermd5,restitle from coode_syshostres where clientcode='".$clientcode."' and rescode='".$rescode."'");
     $vmd5=anyvalue($xrst,"vermd5",0);
     $rtitle=anyvalue($xrst,"restitle",0);
    if ($vmd5==$resver){
       //不需要任何操作
       $ccc=UX("update coode_syshostres set mtver='".$resver."',vermd5='".$resver."',UPTM=now() where  clientcode='".$clientcode."' and rescode='".$rescode."'");   
    }else{
     //先克隆到本地再上传到七牛云 
     $rmtpath=combineurl("http://".$clienthost,"/localxres/".$restype."/".$rescode."/".$rescode."_".$restype.".zip");
     $thispath=combineurl(localroot(),"/columnx/".$clientcode."/".$restype."/".$rescode."/".$rescode."_".$restype.".zip");
     $kd=downanyfile($rmtpath,$thispath);
     if (file_exists($thispath)){
      $qndm=sysconfigval(gln(),"cloudstockhost");
      $qtxt=qnyup(garea(),$thispath);
      $qdata=json_decode($qtxt,false);
        if (intval($qdata->status)==1){
         $kf=unlink($thispath);
         $cldurl=combineurl($qndm,"/columnx/".$clientcode."/".$restype."/".$rescode."/".$rescode."_".$restype.".zip");
        }
     }
     $ccc=UX("update coode_syshostres set mtver='".$resver."',vermd5='".$resver."',UPTM=now() where  clientcode='".$clientcode."' and rescode='".$rescode."'");   
    }//ver        
}else{
     //先找到系统的母鸡资源，还有一种可能就是子机先来访问发现没有母鸡资源
    $xrst=SX("select vermd5,restitle from coode_syshostres where clientcode='".$xtcode."' and rescode='".$rescode."'");
      $vmd5=anyvalue($xrst,"vermd5",0);
      $rtitle=anyvalue($xrst,"restitle",0);
      if ($vmd5==$resver){
        $ccc=UX("update coode_syshostres set mtver='".$resver."',vermd5='".$resver."',UPTM=now() where  clientcode='".$clientcode."' and rescode='".$rescode."'");   
        //不需要任何操作    
      }else{
        $rmtpath=combineurl("http://".$clienthost,"/localxres/".$restype."/".$rescode."/".$rescode."_".$restype.".zip");
        $thispath=combineurl(localroot(),"/columnx/".$clientcode."/".$restype."/".$rescode."/".$rescode."_".$restype.".zip");
        //先克隆到本地再上传到七牛云 
        $cldurl="";
        $kd=downanyfile($rmtpath,$thispath);
        if (file_exists($thispath)){
          $qndm=sysconfigval(gln(),"cloudstockhost");
          $qtxt=qnyup(garea(),$thispath);
          $qdata=json_decode($qtxt,false);
          if (intval($qdata->status)==1){
             $kf=unlink($thispath);
             $cldurl=combineurl($qndm,"/columnx/".$clientcode."/".$restype."/".$rescode."/".$rescode."_".$restype.".zip");
          }
        }
        $ccc=UX("update coode_syshostres set cloudpath='".$cldurl."',mtver='".$vmd5."',UPTM=now() where  clientcode='".$clientcode."' and rescode='".$rescode."'");   
      }
      //vmd5        
      //如果不是母鸡资源看看版本号是否与母机一直，如果一致则使用母鸡版本，不用操作
      //先克隆到本地再上传到七牛云 
}    
//xtcode
$zz=UX("update coode_clientres set STATUS=1 where SNO=".$snox);
     session_write_close();
?>