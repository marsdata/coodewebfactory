<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $downmark=_get("downmark");
$htmlcode=_post("htmlcode");
$cssfiles=_post("cssfiles");
$ptcss=explode(",",$cssfiles);
$totpt=count($ptcss);
for ($z=0;$z<$totpt;$z++){
}
$ptbd=explode("<",$htmlcode);
$totpt=count($ptbd);
for ($m=0;$m<$totpt;$m++){
      $tagx=qian($tmpppt," ");
      $tmpppt=qian($ptbd[$m],">");
      if (strpos($tmpppt,"class=")>0){
       $tmpcls=qian(hou($tmpppt,"class=\""),"\"");
      }else{
       $tmpcls="";
      };
      if (strpos($tmpppt,"src=")>0){
       $tmpurl=qian(hou($tmpppt,"src=\""),"\"");
      };
      if (strpos($tmpppt,"href=")>0){
       $tmpurl=qian(hou($tmpppt,"href=\""),"\"");
      };
      if (strpos($tmpppt,"onclick=")>0){
       $tmpclick=qian(hou($tmpppt,"onclick=\""),"\"");
      }else{
       $tmpclick="";
      };
      if (strpos($tmpppt,"id=")>0){
       $tmpid=qian(hou($tmpppt,"id=\""),"\"");
      }else{
       $tmpid="";
      };
      if (strpos($tmpppt,"name=")>0){
       $tmpname=qian(hou($tmpppt,"name=\""),"\"");
      }else{
       $tmpname="";
      };
      if (strpos($ptbd[$m],">")>0){
       $tmptxt=str_replace(" ","",str_replace("\r\n","",hou($ptbd[$m],">")));
      }else{
       $tmptxt="";
      };
      switch ($tagx){
       case "input":
       break;
       case "table":
       break;
       case "button":
       break;
       case "div":
       break;
       case "select":
       break;
       default:
      }
};
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>