<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $grpmark=dftval($_GET["grpmark"],"");
$fromhost=dftval($_GET["fromhost"],"");
$dtype=dftval($_GET["dtype"],"");
$dt=dftval(unstrs($_POST["dt"]),"");
$rmturl=dftval(unstrs($_POST["rmturl"]),"");
$today=date("Y-m-d");
$exty=UX("select count(*) as result from coode_todaygrp where grpmark='".$grpmark."'");
if (intval($exty)==0){
  $sqla="grpmark,grptitle,CRTM,UPTM,OLMK";
  $sqlb="'$grpmark','$grpmark',now(),now(),'".onlymark()."'";
  $bz=UX("insert into coode_todaygrp(".$sqla.")values(".$sqlb.")");
}
switch($dtype){
 case "html":
 $sqlx="tempmark,temptitle,tempdate,grpmark,filefromurl,filehosturl,filelocalurl,filename,filetype,fromhost,CRTM,UPTM,OLMK";
 $sqly="'[olmk]','','".$today."','".$grpmark."','[rmturl]','[hosturl]','[localurl]','[filename]','[filetype]','[fromhost]',now(),now(),'".onlymark()."'";
 if ($dt!=""){
 }else{
   $dt=file_get_contents($rmturl);
 }
   $todaypath=combineurl(localroot(),"/todayfiles/".$today."/".$grpmark."/");
   $pta=explode("src=\"",$dt);
   $totpta=count($pta);
   for ($i=0;$i<$totpta;$i++){
     $urlx=qian($pta[$i],"\"");
     $urlx=qian($urlx,"?");
     $fnm=urlfname($urlx);
     $ftype=kuozhanming($urlx);
     if ($ftype=="jpg" or $ftype=="png" or $ftype=="gif" or $ftype=="svg" or $ftype=="js" or $ftype=="css" or $ftype=="mp3"  or $ftype=="mp4"){
       $extx=UX("select count(*) as result from coode_todayfiles where tempdate='".$today."' and filermturl='".$urlx."'");
       if (intval($extx)==0){
         $sqlz=$sqly;
         $sqlz=str_replace("[rmturl]",$urlx,$sqlz);
         $sqlz=str_replace("[fromhost]",$fromhost,$sqlz);
         $sqlz=str_replace("[hosturl]",$hosturl,$sqlz);
         $sqlz=str_replace("[olmk]",getRandChar(8),$sqlz);
         $sqlz=str_replace("[filename]",$fnm,$sqlz);
         $sqlz=str_replace("[filetype]",$ftype,$sqlz);
         $lcpath=$todaypath.$fnm;
         $hosturl="http://".str_replace(localroot(),glw(),$lcpath);
         $sqlz=str_replace("[localurl]",$lcpath,$sqlz);
         $sqlz=str_replace("[hosturl]",$hosturl,$sqlz);
         $zz=UX("insert into coode_todayfiles(".$sqlx.")values(".$sqlz.")");
       }
     }
     
   }
   $ptb=explode("src='",$dt);
   $totptb=count($ptb);
   for ($j=0;$j<$totptb;$j++){
     $urlx=qian($ptb[$i],"'");
     $urlx=qian($urlx,"?");
     $fnm=urlfname($urlx);
     $ftype=kuozhanming($urlx);
     if ($ftype=="jpg" or $ftype=="png" or $ftype=="gif" or $ftype=="svg" or $ftype=="js" or $ftype=="css" or $ftype=="mp3"  or $ftype=="mp4"){
       $extx=UX("select count(*) as result from coode_todayfiles where tempdate='".$today."' and filermturl='".$urlx."'");
       if (intval($extx)==0){
         $sqlz=$sqly;
         $sqlz=str_replace("[rmturl]",$urlx,$sqlz);
         $sqlz=str_replace("[fromhost]",$fromhost,$sqlz);         
         $sqlz=str_replace("[olmk]",getRandChar(8),$sqlz);
         $sqlz=str_replace("[filename]",$fnm,$sqlz);
         $sqlz=str_replace("[filetype]",$ftype,$sqlz);
         $lcpath=$todaypath.$fnm;
         $hosturl="http://".str_replace(localroot(),glw(),$lcpath);
         $sqlz=str_replace("[hosturl]",$hosturl,$sqlz);
         $sqlz=str_replace("[localurl]",$lcpath,$sqlz);
         $zz=UX("insert into coode_todayfiles(".$sqlx.")values(".$sqlz.")");
       }
     }
   }
 break;
 case "row":
 $sqlx="tempmark,temptitle,tempdate,grpmark,filefromurl,filehosturl,filelocalurl,filename,filetype,fromhost,CRTM,UPTM,OLMK";
 $sqly="'".getRandChar(8)."','','".$today."','".$grpmark."','[rmturl]','[hosturl]','[localurl]','[filename]','[filetype]','[fromhost]',now(),now(),'".onlymark()."'";
 if ($dt!=""){
 }else{
   $dt=file_get_contents($rmturl);
 }
    $todaypath=combineurl(localroot(),"/todayfiles/".$today."/".$grpmark."/");
   $pta=explode("\r\n",$dt);
   $totpta=count($pta);
   for ($i=0;$i<$totpta;$i++){
     $urlx=$pta[$i];
     $urlx=qian($urlx,"?");
     $fnm=urlfname($urlx);
     $ftype=kuozhanming($urlx);
     if ($ftype=="jpg" or $ftype=="png" or $ftype=="gif" or $ftype=="svg" or $ftype=="js" or $ftype=="css" or $ftype=="mp3"  or $ftype=="mp4"){
       $extx=UX("select count(*) as result from coode_todayfiles where tempdate='".$today."' and filermturl='".$urlx."'");
       if (intval($extx)==0){
         $sqlz=$sqly;
         $sqlz=str_replace("[rmturl]",$urlx,$sqlz);
         $sqlz=str_replace("[fromhost]",$fromhost,$sqlz);
         $sqlz=str_replace("[filename]",$fnm,$sqlz);
         $sqlz=str_replace("[filetype]",$ftype,$sqlz);
         $lcpath=$todaypath.$fnm;
         $sqlz=str_replace("[localurl]",$lcpath,$sqlz);
         $zz=UX("insert into coode_todayfiles(".$sqlx.")values(".$sqlz.")");
       }
     }
     
   }
 break;
 default:
}
echo makereturnjson("1","成功","");
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>