<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $demotree='[<allunit>]';
$unit='{
        "id":[id],
        "lowercase":"[lc]",
        "uppercase":"[uc]",
        "data":[<data>]
    },';
     $itemy='{"id":"[idx]",
            "tabsno":"[tabsno]",
            "tabmark":"[tabmark]",
            "tabtitle":"[tabtitle]",
            "tabtype":"[tabtype]",
            "tabcls":"[tabcls]",
            "tabdbase":"[tabdbase]",
            "totrcd":"[totrcd]",
            "oprt":"[oprt]",
            "tabdes":"[tabdes]"
               },';
$fmunit="";
$extcore=UX("select count(*) as result from coode_dblist where dbmark='thishostcore'");
if (intval($extcore)==0){
  $sqla="dbname,dbtitle,dbowner,dbtype,dbip,dbus,dbps,OLMK,CRTM,UPTM";
  $sqlb="'".glb()."','本机本库核心数据库','coodework','MYSQL','localhost','".glu()."','".glp()."','".onlymark()."',now(),now()";
  $ab=UX("insert into coode_dblist(".$sqla.")values(".$sqlb.")");
}else{
  $kk=UX("update coode_dblist set dbname='".glb()."',dbip='".gl()."',dbus='".glu()."',dbps='".glp()."' where dbmark='thishostcore'");
  $zz=UX("update coode_dbtablist set schm='".glb()."' where catalog='thishostcore' and schm!='".glb()."'");
}
$dbmark=dftval($_GET["dbmark"],"thishostcore");
$tbmk=dftval($_GET["tbmk"],"");
$tbtt=dftval($_GET["tbtt"],"");
$dbrst=SX("select SNO,dbname,dbtitle,dbowner,dbtype,dbip,dbus,dbps,OLMK from coode_dblist where dbmark='".$dbmark."'");
$totx=countresult($dbrst);
$fmxyz="";
if (intval($totx)>0){
   $snox=anyvalue($dbrst,"SNO",0);
   $dbname=anyvalue($dbrst,"dbname",0);
   $dbtitle=anyvalue($dbrst,"dbtitle",0);
   $dbowner=anyvalue($dbrst,"dbowner",0);
   $dbtype=anyvalue($dbrst,"dbtype",0);
   $dbip=anyvalue($dbrst,"dbip",0);
   $dbus=anyvalue($dbrst,"dbus",0);
   $dbps=anyvalue($dbrst,"dbps",0);
   $olmk=anyvalue($dbrst,"OLMK",0);
   if ($dbtype=="MYSQL"){
      $conn=mysql_connect($dbip,$dbus,$dbps);
      $tabrst=selecteds($conn,"information_schema","select TABLE_NAME,TABLE_TYPE,TABLE_SCHEMA from TABLES where TABLE_SCHEMA!='information_schema'","utf8","");
      $tott=countresult($tabrst);
      for ($j=0;$j<$tott;$j++){       
       $tabnmx=anyvalue($tabrst,"TABLE_NAME",$j);
       $dbnmx=anyvalue($tabrst,"TABLE_SCHEMA",$j);
        $extz=UX("select count(*) as result from coode_dbtablist where catalog='".$dbmark."' and TABLE_NAME='".$tabnmx."' and schm='".$dbnmx."'");
        if (intval($extz)==0){
         $sqlx="catalog,schm,TABLE_NAME,fip,fuser,fpass,fbase,OLMK,CRTM,UPTM,CRTOR";         
         $sqly="'".$dbmark."','".$dbname."','".$tabnmx."','".$dbip."','".$dbus."','".$dbps."','".$dbname."','".onlymark()."',now(),now(),'".$_COOKIE["uid"]."'";
         $zs=UX("insert into coode_dbtablist(".$sqlx.")values(".$sqly.")");
        }
        if ($dbmark=="thishostcore"){
           $extb=UX("select count(*) as result from coode_tablist where TABLE_NAME='".$tabnmx."' and schm='".$dbnmx."'");
           if (intval($extb)==0){
             $sqla="schm,TABLE_NAME,tabtype,OLMK,CRTM,UPTM,CRTOR";         
             $sqlb="'".$dbname."','".$tabnmx."','1','".onlymark()."',now(),now(),'".$_COOKIE["uid"]."'";
             $cc=UX("insert into coode_tablist(".$sqla.")values(".$sqlb.")");
           }
        }
      }//for
      $zz=UX("update coode_tablist,coode_dbtablist set coode_dbtablist.tabtitle=coode_tablist.tabtitle,coode_dbtablist.tabtype=coode_tablist.tabtype,coode_dbtablist.tabcls=coode_tablist.tabcls,coode_dbtablist.beforeview=coode_tablist.beforeview where coode_tablist.TABLE_NAME=coode_dbtablist.TABLE_NAME and coode_dbtablist.catalog='thishostcore'");
      $dd=UX("update coode_keydetailx,coode_dbkeydx set coode_dbkeydx.keytitle=coode_keydetailx.keytitle,coode_dbkeydx.valuezero=coode_keydetailx.valuezero,coode_dbkeydx.keyexplain=coode_keydetailx.keyexplain,coode_dbkeydx.jsshowfun=coode_keydetailx.jsshowfun,coode_dbkeydx.sysshowfun=coode_keydetailx.sysshowfun,coode_dbkeydx.jspostfun=coode_keydetailx.jspostfun,coode_dbkeydx.syspostfun=coode_keydetailx.syspostfun,coode_dbkeydx.changeable=coode_keydetailx.changeable,coode_dbkeydx.displayed=coode_keydetailx.displayed,coode_dbkeydx.dxtype=coode_keydetailx.dxtype where coode_dbkeydx.TABLE_NAME=coode_keydetailx.TABLE_NAME and  coode_dbkeydx.TABLE_CATALOG='thishostcore'");
      $dbtabrst=SX("select SNO,schm,TABLE_NAME,tabtitle,tabtype,tabcls,totrcd from coode_dbtablist where catalog='".$dbmark."' and schm='".$dbname."' and TABLE_NAME like '%".$tbmk."%' and tabtitle like '%".$tbtt."%' order by TABLE_NAME");
      $totd=countresult($dbtabrst);
      $tempc="@";
      $leijia=0;
      $fmxyz="";
      for ($k=0;$k<$totd;$k++){
        $snoy=anyvalue($dbtabrst,"SNO",$k);
        $tabnmy=anyvalue($dbtabrst,"TABLE_NAME",$k);        
        $tabtty=anyvalue($dbtabrst,"tabtitle",$k);
        $tabtype=anyvalue($dbtabrst,"tabtype",$k);
        $tabcls=anyvalue($dbtabrst,"tabcls",$k);
        $totrcd=anyvalue($dbtabrst,"totrcd",$k);
        $schm=anyvalue($dbtabrst,"schm",$k);
        $firstlc=strtolower(substr($tabnmy,0,1));
        $firstuc=strtoupper(substr($tabnmy,0,1));
        if ($firstuc!=$tempc){
          $fmxyz=killlaststr($fmxyz);
          $fmunit=str_replace("<data>",$fmxyz,$fmunit);
          $tempc=$firstuc;
          $leijia=0;
          $unitx=$unit;
          $unitx=str_replace("[id]",(ord($firstuc)-65),$unitx);
          $unitx=str_replace("[lc]",$firstlc,$unitx);
          $unitx=str_replace("[uc]",$firstuc,$unitx);
          $fmunit=$fmunit.$unitx;
          $fmxyz="";
        }else{
          $leijia=$leijia+1;
        }
        $itemx=$itemy;
        $itemx=str_replace("[idx]",($snoy+100),$itemx);
        $itemx=str_replace("[tabsno]",$snoy,$itemx);
        $itemx=str_replace("[tabmark]",$tabnmy,$itemx);
        $itemx=str_replace("[tabtitle]",$tabtty,$itemx);
        $itemx=str_replace("[tabtype]",$tabtype,$itemx);
        $itemx=str_replace("[tabcls]",$tabcls,$itemx);
        $itemx=str_replace("[totrcd]",$totrcd,$itemx);
        $itemx=str_replace("[tabdbase]",$schm,$itemx);
        $itemx=str_replace("[tabdes]","",$itemx);
        $itemx=str_replace("[oprt]","查看",$itemx);
        $fmxyz=$fmxyz.$itemx;
      }      
      $fmxyz=killlaststr($fmxyz);
      $fmunit=str_replace("<data>",$fmxyz,$fmunit);
      $demotree=str_replace("<allunit>",$fmunit,$demotree);
      $zz=UX("update coode_dbtablist,coode_tablist set coode_dbtablist.tabtitle=coode_tablist.tabtitle where coode_dbtablist.fip='localhost' and coode_dbtablist.schm='".glb()."' and coode_dbtablist.TABLE_NAME=coode_tablist.TABLE_NAME");
      echo $demotree;
   }else{
     echo makereturnjson("0","数据库类别不对","");
   }
}else{
    echo makereturnjson("0","不存在","");
}
     session_write_close();
?>