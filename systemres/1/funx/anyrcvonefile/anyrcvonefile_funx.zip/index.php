<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
       $filepath=dftval($_GET["filepath"],"");  
  if (substr($filepath,0,1)!="/"){
    $filepath="/".$filepath;
  }
  if (strpos("xxx-".$filepath,localroot())>0){
    $fullpath=$filepath;
  }else{
    $fullpath=combineurl(localroot(),$filepath);
  }
  $shortpath=str_replace(localroot(),"",$fullpath);
  $shortpath=combineurl("/",$shortpath);
  $fkey="uploadfile";
  $tmpnm=$_FILES[$fkey]["tmp_name"];
  $fnm=$_FILES[$fkey]["name"];
  $fext=kuozhanming($fnm);
  $tmptp=$_FILES[$fkey]["type"];
  $tmperr=$_FILES[$fkey]["error"];
  $newpath=combineurl(localroot(),$shortpath);
  $yy=createdir($newpath);  
  $newfpt=combineurl($newpath,$fnm);  
  move_uploaded_file($tmpnm, $newfpt);  
  $filetype=kuozhanming($newfpt);   
   if ($filetype!="" and $filepath!=""){
    $extf=UX("select count(*) as result from coode_filelist where filename='".$fnm."' and filetype='".$filetype."' and lcpath='".$fullpath."'");
    if (intval($extf)==0){
     $sqlx="filename,filetype,scantime,createtime,updtime,lcpath,filelcurl,fileurl,CRTM,UPTM,OLMK";
     $sqly="'$fnm','$filetype',now(),now(),now(),'".$fullpath."','".$newfpt."','".combineurl($shortpath,$fnm)."',now(),now(),'".onlymark()."'";
     $zz=UX("insert into coode_filelist(".$sqlx.")values(".$sqly.")");
    }else{
     $zzx=UX("update coode_filelist set scantime=now(),UPTM=now() where filename='".$fnm."' and filetype='".$filetype."' and lcpath='".$fullpath."'");
    }
    $zzv=UX("update coode_filelist set typeimg=concat('/localxres/iconsetx/filetypexcool/',filetype,'.png')");
    $zzv1=UX("update coode_filelist set typeimg=fileurl where filetype='jpg' or filetype='jpeg' or filetype='png'  or filetype='gif'  or filetype='svg'");
    echo makereturnjson("1","上传成功","");
   }else{
    echo makereturnjson("0","参数不全","");
   }
  
     session_write_close();
?>