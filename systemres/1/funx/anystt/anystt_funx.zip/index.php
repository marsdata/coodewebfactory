<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tablenm=$_GET["tablenm"];
$sno=$_GET["sno"];
$keyx=$_GET["keyx"];
$prisno=UX("select mainsqx as result from coode_tablist where TABLE_NAME='".$tablenm."'");
$xy=UX("update ".$tablenm." set ".$keyx."=abs(".$keyx."-1) where ".$prisno."=".$sno);
switch ($tablenm){
case "coode_shortdata":
 $snox=$sno;
 $conn=mysql_connect(gl(),glu(),glp()); 
 $zk=UX("update coode_shortdata set OPRT='3.14' where ".$prisno."=".$sno);
 
break;
case "coode_keydetailx":
 $snox=$sno; 
 $tbnm=UX("select TABLE_NAME as result from coode_keydetailx where SNO=".$snox); 
 $zk=UX("update coode_tablist set OPRT='3.14' where TABLE_NAME='".$tbnm."'");
 $zz=file_get_contents(combineurl("http://".glw(),"/localxres/funx/tabcol/?tablename=".$tbnm."&cid=".$_COOKIE["cid"]."&uid=".$_COOKIE["uid"]));
break;
case "coode_keydetailz":
 $snox=$sno; 
 $stidx=UX("select shortid as result from coode_keydetailz where SNO=".$snox); 
 $zk=UX("update coode_shortdata set OPRT='3.14' where shortid='".$stidx."'");
break;
case "coode_keydetaily":  
 $snox=$sno;
 $stidx=UX("select shortid as result from coode_keydetaily where SNO=".$snox); 
 $zk=UX("update coode_shortdata set OPRT='3.14' where shortid='".$stidx."'");
 $qc=file_get_contents("http://".glw()."localxres/funx/shortcol/?shortid=".$stidx."&cid=".$_COOKIE["cid"]."&uid=".$_COOKIE["uid"]);
 $zzx=file_get_contents(combineurl("http://".glw(),"/localxres/funx/shortdft/?shortid=".$stidx."&cid=".$_COOKIE["cid"]."&uid=".$_COOKIE["uid"]));
break;
default:
 $xy=UX("update ".$tablenm." set OPRT='3.14' where ".$prisno."=".$sno);
}
$nex=UX("select  ".$keyx." as result from ".$tablenm."  where ".$prisno."=".$sno);
$ksfun=UX("select sysshowfun as result from coode_keydetailx where TABLE_NAME='".$tablenm."' and COLUMN_NAME='".$keyx."' and TABLE_SCHEMA='".glb()."'");
$kstxt=tostring($ksfun);
$c0=qian(hou("-".$kstxt,"CASE=0::"),"E@CS");
$c0=str_replace("[thistable]",$tablenm,$c0);
$c0=str_replace("[thiskey]",$keyx,$c0);
$c0=str_replace("[thissno]",$sno,$c0);
$c0=str_replace("{","<",$c0);
$c0=str_replace("}",">",$c0);
$c1=qian(hou("-".$kstxt,"CASE=1::"),"E@CS");
$c1=str_replace("[thistable]",$tablenm,$c1);
$c1=str_replace("[thiskey]",$keyx,$c1);
$c1=str_replace("[thissno]",$sno,$c1);
$c1=str_replace("{","<",$c1);
$c1=str_replace("}",">",$c1);
if ($nex*1==1){
 echo $c1; 
}else{
 echo $c0; 
}
     session_write_close();
?>