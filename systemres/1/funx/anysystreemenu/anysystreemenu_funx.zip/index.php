<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $sysid=$_GET["sysid"];
$sysrst=SX("select sysname,faceimg from coode_sysinformation where sysid='".$sysid."'");
$stitle=anyvalue($sysrst,"sysname",0);
$fimg=anyvalue($sysrst,"faceimg",0);
$appdemo='{ "F_ModuleId": "[myid]", "F_ParentId": "[parid]", "F_EnCode": "SysManage", "F_FullName": "[mytitle]", "F_Icon": "fa fa-desktop", "F_UrlAddress": "/default", "F_Target": "expand", "F_IsMenu": 0, "F_AllowExpand": 1, "F_IsPublic": 0, "F_AllowEdit": null, "F_AllowDelete": null, "F_SortCode": 1, "F_DeleteMark": 0, "F_EnabledMark": 1, "F_Description": null, "F_CreateDate": null, "F_CreateUserId": null, "F_CreateUserName": null, "F_ModifyDate": "[UPTM]", "F_ModifyUserId": "System", "F_ModifyUserName": "[CRTOR]" },';
$laydemo='{ "F_ModuleId": "[myid]", "F_ParentId": "[parid]", "F_EnCode": "OrganizeManage", "F_FullName": "[mytitle]", "F_Icon": "fa fa-desktop", "F_UrlAddress": "[myurl]", "F_Target": "iframe", "F_IsMenu": 0, "F_AllowExpand": 1, "F_IsPublic": 0, "F_AllowEdit": null, "F_AllowDelete": null, "F_SortCode": 1, "F_DeleteMark": 0, "F_EnabledMark": 1, "F_Description": null, "F_CreateDate": null, "F_CreateUserId": null, "F_CreateUserName": null, "F_ModifyDate": "[UPTM]", "F_ModifyUserId": "System", "F_ModifyUserName": "[CRTOR]" },'; 
  $apprst=SX("select appid,appname,UPTM,CRTOR from coode_appdefault where sysid='".$sysid."' and STATUS=1 order by PTOF");
  $totapp=countresult($apprst);
  $fmmenux="";
  $leiid=0;
  $parid="";  
  for ($j=0;$j<$totapp;$j++){
     $appid=anyvalue($apprst,"appid",$j);
     $appnm=anyvalue($apprst,"appname",$j);
     $appuptm=anyvalue($apprst,"UPTM",$j);
     $appcrtor=anyvalue($apprst,"CRTOR",$j);     
     $layprst=SX("select layid,laytitle,UPTM,CRTOR from coode_applay where sysid='".$sysid."' and appid='".$appid."' and STATUS=1 order by PTOF");
     $totla=countresult($layprst);     
     if ($totla>0){
      $leiid=$leiid+1;
      $parid=$leiid;
      $ademo=$appdemo;      
      $ademo=str_replace("[myid]",$leiid,$ademo);
      $ademo=str_replace("[parid]","0",$ademo);
      $ademo=str_replace("[mytitle]",$appnm,$ademo);
      $ademo=str_replace("[UPTM]",$appuptm,$ademo);
      $ademo=str_replace("[CRTOR]",$appcrtor,$ademo);
      $fmmenux=$fmmenux.$ademo;
      for ($k=0;$k<$totla;$k++){
        $ldemo=$laydemo;
        $leiid=$leiid+1;
        $layid=anyvalue($layprst,"layid",$k);
        $urlx="/localxres/funx/anylay/?layid=".$layid;
        $permtitle=anyvalue($layprst,"laytitle",$k);        
        $uptm=anyvalue($layprst,"UPTM",$k);
        $crtor=anyvalue($layprst,"CRTOR",$k);
        $ldemo=str_replace("[myid]",$leiid,$ldemo);
        $ldemo=str_replace("[myurl]",$urlx,$ldemo);
        $ldemo=str_replace("[parid]",$parid,$ldemo);
        $ldemo=str_replace("[mytitle]",$permtitle,$ldemo);
        $ldemo=str_replace("[UPTM]",$uptm,$ldemo);
        $ldemo=str_replace("[CRTOR]",$crtor,$ldemo);
        $fmmenux=$fmmenux.$ldemo;
      }//for
     }//if totla
  }//for totapp 
 echo '{"status":"1","msg":"成功","systitle":"'.$stitle.'","faceimg":"'.$fimg.'","vls":['.$fmmenux.']}';
       session_write_close();
?>