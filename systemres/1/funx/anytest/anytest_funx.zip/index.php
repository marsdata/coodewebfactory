<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
             
      $snox=dftval($_POST["SNO"],$_GET["SNO"]);
$rstx=SX("select grpid,resmark,restitle,restype from coode_sysregres where SNO=".$snox);
$rescode=anyvalue($rstx,"resmark",0);
$grpid=anyvalue($rstx,"grpid",0);
$restitle=anyvalue($rstx,"restitle",0);
$restype=anyvalue($rstx,"restype",0);
switch($restype){
  case "funx":
  $zz=UX("delete from coode_funlist where (funname='".$rescode."' or funname='".$rescode."()') and sysid='".$grpid."'");
  break;
  case "tabx":  
  break;
  case "tempx":
    
  break;
  case "clsx":
  $zz=UX("delete from coode_phpcls where (funname='".$rescode."' or funname='".$rescode."()')  and sysid='".$grpid."'");
  break;
  case "formx":
  $zz=UX("delete from coode_shortdata where shortid='".$rescode."' and sysid='".$grpid."'");
  break;
  case "sfunx":
  $zz=UX("delete from coode_funsetfile where setmark='".$rescode."' and sysid='".$grpid."'");
  break;
  case "dfunx":
  $kk=UX("delete from coode_datafun where dfunmark='".$rescode."' and sysid='".$grpid."'");
  
  break;
  case "mfunx":
  $kk=UX("delete from coode_multifunlist where funname='".$rescode."' and sysid='".$grpid."'");
  
  break;
  case "pagex":
  $kk=UX("delete from coode_tiny where tinymark='".$rescode."' and sysid='".$grpid."'");
  break;
  case "cdtrdrx":  
  $kk=UX("delete from coode_cdtrdr where cdtmark='".qian($rescode,".")."' and cdtval='".hou($rescode,".")."' and sysid='".$grpid."'");
  break;
  case "parardrx":
  $kk=UX("delete from coode_parardr where paramark='".$rescode."' and sysid='".$grpid."'");
  break;
  case "constx":
    $kk=UX("delete from coode_sysconstant where constantid='".$rescode."' and sysid='".$grpid."'");
  break;
  case "configx":
  $kk=UX("delete from coode_sysconfig where syskey='".$rescode."' and sysid='".$grpid."'");
  break;
  case "groupx":  
  
  break;
  case "plotx":  
  
  break;
  case "dataspacex":
  
  break;
  case "sysx":
  $kk=UX("delete from coode_sysinformation where sysid='".$rescode."' and sysid='".$grpid."'");
  break;
  case "appx":
  $kk=UX("delete from coode_appdefault where appid='".$rescode."' and sysid='".$grpid."'");
  break;
  case "layx":
  $kk=UX("delete from coode_applay where layid='".$rescode."' and sysid='".$grpid."'");
  break;
  case "csspagex":
  $kk=UX("delete from coode_facelist where faceid='".$rescode."' and sysid='".$grpid."'");
  break;
  case "iconsetx":  
  
  break;
  case "databasex":  
  $kk=UX("delete from coode_dblist where dbmark='".$rescode."' and sysid='".$grpid."'");
  default:
}
echo "---DD";
       session_write_close();
?>