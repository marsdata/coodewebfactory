<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $restype=_get("restype");
$rescode=_get("rescode");
$host=_get("host");
if ($host==""){
  $dm="";
}else{
  $dm=combineurl("http://",$host);
}
$v=_get("v");
if ($v=="1"){
 switch($restype){
  case "funx":
  header("location:".$dm."/localxres/funx/".$rescode."/");
  break;
  case "tabx":  
  header("location:".$dm."/localxres/funx/anyjsshort/?stid=2qPIqS-sfile:anyjsshort.php-&pnum=150:".$rescode."&page=1:TABLE_NAME&rdr=1&rnd=".onlymark());
  break;
  case "tempx":
  header("location:".$dm."/localxres/tempx/".qian($rescode,".")."/".hou($rescode,".").".html");
  break;
  case "clsx":
  header("location:".$dm."/localxres/tempx/htmleditor/index.html?clsid=".$rescode);
  break;
  case "formx":
  header("location:".$dm."/localxres/funx/anyjsshort/?stid=".$rescode."&pnum=30");
  break;
  case "sfunx":
  $snox=UX("select SNO as result from coode_funsetfile where setname='".$rescode."'");  
  header("location:".$dm."/localxres/tempx/htmleditor/index.html?funid=coode_funsetfile@SNO:".$snox.".funbody");
  break;
  case "dfunx":
  $snox=UX("select SNO as result from coode_datafun where dfunmark='".$rescode."'");  
  header("location:".$dm."/localxres/tempx/htmleditor/index.html?funid=coode_datafun@SNO:".$snox.".dfuneval");
  break;
  case "mfunx":
  $snox=UX("select SNO as result from coode_multifunlist where funname='".$rescode."'");  
  header("location:".$dm."/localxres/tempx/htmleditor/index.html?funid=coode_multifunlist@SNO:".$snox.".funfull");
  break;
  case "pagex":
  header("location:".$dm."/localxres/funx/anytiny/?tiny=".$rescode);
  break;
  case "cdtrdrx":  
  header("location:".$dm."/localxres/funx/anyjsshort/?stid=sxIBUb-pnum:30&cdtmark=".qian($rescode,"."));
  break;
  case "parardrx":
  header("location:".$dm."/localxres/funx/anyjsshort/?stid=zJocDJ-pnum:30&tinymark=".qian($rescode,"."));  
  break;
  case "constx":
  header("location:".$dm."/localxres/funx/anyjsshort/?stid=gxLSRV-pnum:30");
  break;
  case "configx":
  header("location:/localxres/funx/anyjsshort/?stid=6C02fY-pnum:30-");
  break;
  case "groupx":  
  header("location:".$dm."/localxres/funx/anyjsshort/?stid=Q8Cfee-pnum:30&plotmark=".$rescode);
  break;
  case "plotx":  
  header("location:".$dm."/localxres/funx/anyjsshort/?stid=layplot&plmk=".$rescode."&parid=-1");
  break;
  case "dataspacex":
  header("location:".$dm."/localxres/funx/anyjsshort/?stid=NlULLd-pnum:30");
  break;
  case "sysx":
  header("location:".$dm."/localxres/funx/anysys/?sysid=".$rescode);
  break;
  case "appx":
  header("location:".$dm."/localxres/funx/anysys/?appid=".$rescode);
  break;
  case "layx":
  header("location:".$dm."/localxres/funx/anysys/?layid=".$rescode);
  break;
  case "csspagex":
  header("location:".$dm."/localxres/csspagex/".$rescode."/index.html");
  break;
  case "iconsetx":  
  header("location:".$dm."/localxres/funx/anyjsshort/?stid=yqGqy6&pnum=999&page=1&setmark=".$rescode);
  break;
  case "databasex":  
  header("location:".$dm."/localxres/funx/anyjsshort/?stid=GgPB35-pnum:30");
  default:
 }
}else{
 $resrst=SX("select SNO,grpid from coode_sysregres where restype='".$restype."' and resmark='".$rescode."'");
 $totres=countresult($resrst);
 if ($totres>0){
  $sysid=anyvalue($resrst,"grpid",0);
  header("location:/systemres/".$sysid."/".$restype."/".qian($rescode,".")."/".qian($rescode,".")."_".$restype.".zip");
 }else{
  $visiturl="/localxres/csspagex/404/black/failure.html";
  header("location:".$visiturl);
 }
}
       session_write_close();
?>