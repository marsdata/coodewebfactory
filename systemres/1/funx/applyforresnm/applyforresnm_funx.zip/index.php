<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $askman=dftval($_POST["askman"],"");
$resname=dftval($_POST["resname"],"");
$rescode=dftval($_POST["rescode"],"");
$restype=dftval($_POST["restype"],"");
$resdes=dftval($_POST["resdes"],"");
$accesscode=dftval($_POST["accesscode"],"");
$fromhost=dftval($_POST["fromhost"],"");
$canshu="";
//$canshu=$askman."--".$resname."--".$rescode."--".$restype."--".$resdes."--".$fromhost."--";
if (es($askman)*es($resname)*es($rescode)*es($restype)*es($fromhost)==1){
 $ext0=UX("select count(*) as result from coode_namespace where restype='".$restype."' and rescode='".$rescode."'");
 if (intval($ext0)==0){
  $sqlx="restype,rescode,restitle,askman,fromhost,acccode,CRTM,UPTM,OLMK";
  $sqly="'$restype','$rescode','$resname','$askman','$fromhost','".$accesscode."',now(),now(),'".onlymark()."'";
  $zz=UX("insert into coode_namespace(".$sqlx.")values(".$sqly.")");  
  echo makereturnjson("1","成功","");
 }else{
   $askman=UX("select askman as result from coode_namespace where restype='".$restype."' and rescode='".$rescode."'");
   echo makereturnjson("-1","失败,已存在",$askman);
 }
}else{
 echo makereturnjson("0","失败,参数不全",$canshu);
}
     session_write_close();
?>