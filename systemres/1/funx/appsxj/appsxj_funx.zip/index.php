<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $keyx="appname,sysid,appid,appcls,orgcls,faceimg,appdescrib,appdetail,lastupdt,localsysid,inurl,outurl,plotid,plotnm,tables,files,rootpath,VRT,CRTM,UPTM,STATUS,CRTOR,PTOF,OLMK";
$olmk=$_GET["olmk"];
$conn=mysql_connect(gl(),glu(),glp());
$yx=updatingx($conn,glb(),"insert into coode_appmarket(".$keyx.")select ".$keyx." from coode_appdefault where appcls='market' and OLMK not in(select OLMK from coode_appmarket)","utf8");
$conn=mysql_connect(gl(),glu(),glp());
$xy=updatingx($conn,glb(),"update coode_appdefault set STATUS=ABS(STATUS*1-1) where OLMK='".$olmk."' and appcls='market'","utf8");
$conn=mysql_connect(gl(),glu(),glp());
$zz=updatingx($conn,glb(),"update coode_appdefault,coode_appmarket set coode_appmarket.STATUS=coode_appdefault.STATUS where coode_appdefault.OLMK=coode_appmarket.OLMK and coode_appmarket.OLMK='".$olmk."'","utf8");
$rstt=UX("select STATUS as result from coode_appdefault where OLMK='".$olmk."'");
$htmla="<div class=\"layui-unselect layui-form-checkbox layui-form-checked\" lay-skin=\"\" onclick=\"F('appsxj','olmk=".$olmk."','','STATUS".$rsno."','refresh');\"><span>上架</span><i class=\"layui-icon\"></i></div>";
$htmlb="<div class=\"layui-unselect layui-form-checkbox\" lay-skin=\"\" onclick=\"F('appsxj','olmk=".$olmk."','','STATUS".$rsno."','refresh');\"><span>上架</span><i class=\"layui-icon\"></i></div>";
if ($rstt*1==0){
 $conn=mysql_connect(gl(),glu(),glp());
 $xxx=updatingx($conn,glb(),"delete from coode_appmarket where OLMK='".$olmk."'","utf8");
    echo $htmlb;
}else{
    echo $htmla;    
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>