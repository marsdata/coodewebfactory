<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $cp=_get("cp");
$day=_get("day");
$yltype=_get("yltype");
$demo='{"status":"1","title":"[titlex]","data":[<data>]}';
$item='{"datex":"[datex]","dayx":"[dayx]"},';
switch($cp){
  case "tc":
 $tabnm="tcai_pl5";
 $ytab="ticai_yilou";
 $cpmc="体彩排列三";
 $pp=0;
  break;
  case "p5":
 $tabnm="tcai_pl5";
 $ytab="tcp5_yilou";
 $cpmc="体彩后排3";
 $pp=2;
  break;
  case "fc":
  $tabnm="fcai_3d";
  $ytab="fucai_yilou";
  $cpmc="福彩3D";
  $pp=0;
  break;
  case "7xc":
 $tabnm="tcai_qxc";
 $ytab="qxcc_yilou";
 $cpmc="七星彩C区";
 $pp=0;
  break;
  case "7xd":
 $tabnm="tcai_qxc";
 $ytab="qxcd_yilou";
 $cpmc="七星彩D区";
 $pp=2;
  break;
  case "7xe":
 $tabnm="tcai_qxc";
 $ytab="qxce_yilou";
 $cpmc="七星彩E区";
 $pp=4;
  break;
  default:
}
$dtarrx=Array();
$dtarry=Array();
$jgarr=Array();
$titlex=$cpmc.$yltype."统计";
if ($yltype=="rrl"){
 if ($cp=="tc"){
  $cprst=SX("select SNO,pdate from ".$tabnm." where pa=2 and pb=0 and timestampdiff(day,pdate,now())<=".dftval(_get("day"),1200)." order by pdate");  
 }else{
  $cprst=SX("select SNO,pdate from ".$tabnm." where kjd=2 and kje=0 and timestampdiff(day,pdate,now())<=".dftval(_get("day"),1200)." order by pdate");
 }
 $titlex=$cpmc."热热冷胆组统计";
}else if ($yltype=="rld"){
 if ($cp=="tc"){
  $cprst=SX("select SNO,pdate from ".$tabnm." where pa=1 and pb=1 and timestampdiff(day,pdate,now())<=".dftval(_get("day"),200)." order by pdate");  
 }else{
  $cprst=SX("select SNO,pdate from ".$tabnm." where kjd=1 and kje=1 and timestampdiff(day,pdate,now())<=".dftval(_get("day"),200)." order by pdate");
 }
 $titlex=$cpmc."热冷胆组统计";
}else if ($yltype=="lrd"){
 $cprst=SX("select SNO,pdate from ".$tabnm." where PRIME=1 and timestampdiff(day,pdate,now())<=".dftval(_get("day"),200)." order by pdate");
 $titlex=$cpmc."冷热胆组统计";
}else if ($yltype=="bbb"){
 $cprst=SX("select SNO,pdate from ".$tabnm." where substr(kjnum,1+".$pp.",1)=substr(kjnum,2+".$pp.",1) and substr(kjnum,2+".$pp.",1)=substr(kjnum,3+".$pp.",1)  order by pdate");
 $titlex=$cpmc."豹子统计";
}else if (strpos("//".$yltype,"x")>0){    
    $typex=str_replace("x","%",$yltype);
    $cprst=SX("select SNO,pdate from ".$tabnm." where substr(kjnum,1+".$pp.",3) like '".$typex."'  order by pdate");   
   $typepos=strpos($yltype,"x");
  switch(typepos){
    case 0:
    break;
    case 1:
    break;
    case 2:
    break;
    default:
  }
}else if (strpos("//".$yltype,"ss")>0){    
   $numm=str_replace("ss","",$yltype);
   switch($cp){
    case "7xc":
    break;
    case "7xd":
    break;
    case "7xe":
    break;
    case "p5":
    $cprst=SX("select SNO,pdate from ".$tabnm." where (kjc='".$numm."' or kjd='".$numm."' or kje='".$numm."') and timestampdiff(day,pdate,now())<=".dftval(_get("day"),300)."  order by pdate");   
    break;
    default:
    $cprst=SX("select SNO,pdate from ".$tabnm." where (kja='".$numm."' or kjb='".$numm."' or kjc='".$numm."') and timestampdiff(day,pdate,now())<=".dftval(_get("day"),300)."  order by pdate");   
   }
   
}else if (strpos("//".$yltype,"i")>0 or strpos("//".$yltype,"o")>0){    
    $typex=str_replace("i","1",$yltype);
    $typex=str_replace("o","0",$typex);
    switch($cp){
      case "fc":
        $cprst=SX("select SNO,pdate from ".$tabnm." where gdm='".$typex."' and timestampdiff(day,pdate,now())<=".dftval(_get("day"),500)."  order by pdate");   
      break;
      case "tc":
       $cprst=SX("select SNO,pdate from ".$tabnm." where gdmc='".$typex."' and timestampdiff(day,pdate,now())<=".dftval(_get("day"),500)."  order by pdate");   
      break;
      case "p5":
      $cprst=SX("select SNO,pdate from ".$tabnm." where gdmd='".$typex."' and timestampdiff(day,pdate,now())<=".dftval(_get("day"),500)."  order by pdate");   
      break;
      default:
      
    }
}else if (strpos("//".$yltype,"cc")>0 ){    
    $typex=str_replace("cc","",$yltype);
    
    switch($cp){
      case "fc":
        $cprst=SX("select SNO,pdate from ".$tabnm." where ing".$typex."=0 and timestampdiff(day,pdate,now())<=".dftval(_get("day"),500)."  order by pdate");   
      break;
      case "tc":
       $cprst=SX("select SNO,pdate from ".$tabnm." where ingc".$typex."=0 and timestampdiff(day,pdate,now())<=".dftval(_get("day"),500)."  order by pdate");   
      break;
      case "p5":
      $cprst=SX("select SNO,pdate from ".$tabnm." where ingd".$typex."=0 and timestampdiff(day,pdate,now())<=".dftval(_get("day"),500)."  order by pdate");   
      break;
      default:
      
    }
}else if (strpos("//".$yltype,"g")>0){    
    $typex=str_replace("g","%",$yltype);
    switch($cp){
      case "fc":
        $cprst=SX("select SNO,pdate from ".$tabnm." where gdm like '".$typex."' and timestampdiff(day,pdate,now())<=".dftval(_get("day"),500)."  order by pdate");   
      break;
      case "tc":
       $cprst=SX("select SNO,pdate from ".$tabnm." where gdmc like '".$typex."' and timestampdiff(day,pdate,now())<=".dftval(_get("day"),500)."  order by pdate");   
      break;
      case "p5":
      $cprst=SX("select SNO,pdate from ".$tabnm." where gdmd like '".$typex."' and timestampdiff(day,pdate,now())<=".dftval(_get("day"),500)."  order by pdate");   
      break;
      default:
      
    }
    
}else{
  switch($yltype){
   case "zzg":
    $cprst=SX("select SNO,pdate from ".$tabnm." where substr(kjnum,3+".$pp.",1)=substr(sqkj,3+".$pp.",1)  order by pdate");   
   break;
   case "zsz":
    $cprst=SX("select SNO,pdate from ".$tabnm." where substr(kjnum,2+".$pp.",1)=substr(sqkj,2+".$pp.",1)  order by pdate");   
   break;
   case "bzz":
    $cprst=SX("select SNO,pdate from ".$tabnm." where substr(kjnum,1+".$pp.",1)=substr(sqkj,1+".$pp.",1)  order by pdate");   
   break;
   default:
    $typepos=strpos($yltype,"zz");
    switch(typepos){
     case 0:
     $gg=substr($yltype,2,1);
     $cprst=SX("select SNO,pdate from ".$tabnm." where substr(kjnum,3+".$pp.",1)=substr(sqkj,3+".$pp.",1) and substr(kjnum,3,1)='".$gg."'  order by pdate");   
     break;
     case 1:
     $bb=substr($yltype,0,1);
     $cprst=SX("select SNO,pdate from ".$tabnm." where substr(kjnum,1+".$pp.",1)=substr(sqkj,1+".$pp.",1) and substr(kjnum,1,1)='".$bb."'  order by pdate");        
     break;
     default:    
     $ss=substr($yltype,1,1);
     $cprst=SX("select SNO,pdate from ".$tabnm." where substr(kjnum,2+".$pp.",1)=substr(sqkj,2+".$pp.",1) and substr(kjnum,2,1)='".$ss."' order by pdate");        
    } 
  }
}
 $totc=countresult($cprst);
 for ($j=0;$j<$totc;$j++){
  $dtarrx[$j]=strtotime(anyvalue($cprst,"pdate",$j));
  $dtarry[$j]=anyvalue($cprst,"pdate",$j);
 }
 $jgarr=arrtojg($dtarrx);
 $fmitem="";
 for ($j=0;$j<count($jgarr);$j++){
   $itemx=$item;
   $itemx=str_replace("[datex]",$dtarry[$j+1],$itemx);
   $itemx=str_replace("[dayx]",$jgarr[$j]/86400,$itemx);
   $fmitem=$fmitem.$itemx;
 }
 $fmitem=killlaststr($fmitem);
 $dqyl=UX("select ylday as result from ".$ytab." where yltype='".$yltype."'");
 $demo=str_replace("<data>",$fmitem,$demo);
 $demo=str_replace("[titlex]",$titlex."@遗:".$dqyl,$demo);
 echo $demo;
     session_write_close();
?>