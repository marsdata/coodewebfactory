<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $commark=_get("commark");
$askkey=_get("askkey");
$fmcdt="";
$srd='{"status":"1","msg":"成功",<data>}';
$item='{"clstitle":"[clstitle]","clskey":"[clskey]","headicon":"[headicon]","images":"[images]","atccode":"[atccode]","atctitle":"[atctitle]","atcsentence":"[atcsentence]","atcdescrib":"[atcdescrib]","crtm":"[crtm]"},';
$fmx="";
if (strpos($askkey,",")>0){
 $ptkey=explode(",",$askkey);
 $totpt=count($ptkey);
 for ($jj=0;$jj<$totpt;$jj++){
  if ($ptkey[$jj]!=""){    
    $drst=SX("select clskey,clstitle,headicon,images,atccode,atctitle,atcsentence,atcdescrib,CRTM from comx_article where commark='".$commark."' and clskey='".$ptkey[$jj]."'");  
    $totd=countresult($drst);
    $fmx=$fmx.'"'.$ptkey[$jj].'":[';
    for ($kk=0;$kk<$totd;$kk++){
     $itemx=$item;
     $clskey=anyvalue($drst,"clskey",$kk);
     $clstitle=anyvalue($drst,"clstitle",$kk);
     $headicon=anyvalue($drst,"headicon",$kk);
     $images=anyvalue($drst,"images",$kk);
     $atccode=anyvalue($drst,"atccode",$kk);
     $atctitle=anyvalue($drst,"atctitle",$kk);
     $atcsentence=anyvalue($drst,"atcsentence",$kk);
     $atcdescrib=anyvalue($drst,"atcdescrib",$kk);
     $crtmx=anyvalue($drst,"CRTM",$kk);
     $itemx=str_replace("[clskey]",$clskey,$itemx);
     $itemx=str_replace("[clstitle]",$clstitle,$itemx);
     $itemx=str_replace("[headicon]",$headicon,$itemx);
     $itemx=str_replace("[images]",$images,$itemx);
     $itemx=str_replace("[atccode]",$atccode,$itemx);
     $itemx=str_replace("[atctitle]",$atctitle,$itemx);
     $itemx=str_replace("[atcsentence]",$atcsentence,$itemx);
     $itemx=str_replace("[atcdescrib]",$atcdescrib,$itemx);
     $itemx=str_replace("[crtm]",$crtmx,$itemx);
     $fmx=$fmx.$itemx;
    }//forkk
    $fmx=$fmx."],";
  }// pt jj
 }//for
 $srd=str_replace("<data>",$fmx,$srd); 
}else{
    $drst=SX("select clskey,clstitle,headicon,images,atccode,atctitle,atcsentence,atcdescrib,CRTM from comx_article where commark='".$commark."' and clskey='".$askkey."'");  
    $totd=countresult($drst);
    $fmx=$fmx.'"'.$askkey.'":[';
    for ($kk=0;$kk<$totd;$kk++){
     $itemx=$item;
     $clskey=anyvalue($drst,"clskey",$kk);
     $clstitle=anyvalue($drst,"clstitle",$kk);
     $headicon=anyvalue($drst,"headicon",$kk);
     $images=anyvalue($drst,"images",$kk);
     $atccode=anyvalue($drst,"atccode",$kk);
     $atctitle=anyvalue($drst,"atctitle",$kk);
     $atcsentence=anyvalue($drst,"atcsentence",$kk);
     $atcdescrib=anyvalue($drst,"atcdescrib",$kk);
     $crtmx=anyvalue($drst,"CRTM",$kk);
     $itemx=str_replace("[clskey]",$clskey,$itemx);
     $itemx=str_replace("[clstitle]",$clstitle,$itemx);
     $itemx=str_replace("[headicon]",$headicon,$itemx);
     $itemx=str_replace("[images]",$images,$itemx);
     $itemx=str_replace("[atccode]",$atccode,$itemx);
     $itemx=str_replace("[atctitle]",$atctitle,$itemx);
     $itemx=str_replace("[atcsentence]",$atcsentence,$itemx);
     $itemx=str_replace("[atcdescrib]",$atcdescrib,$itemx);
     $itemx=str_replace("[crtm]",$crtmx,$itemx);
     $fmx=$fmx.$itemx;
    }//forkk
    $fmx=$fmx."]";
 $srd=str_replace("<data>",$fmx,$srd);
}
echo $srd;
     session_write_close();
?>