<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $cpid=_get("cpid");
$cprst=SX("select companyname,aboutus,contactus,friendlink,comemail,lawmanpx,lawmanptel,comlogo from comx_baseinfo where companymark='".$cpid."'");
$totcp=countresult($cprst);
if (intval($totcp)>0){
 $compnm=anyvalue($cprst,"companyname",0);
 $aboutus=anyvalue($cprst,"aboutus",0);
 $contactus=anyvalue($cprst,"contactus",0);
 $friendlink=anyvalue($cprst,"friendlink",0);
 $comemail=anyvalue($cprst,"comemail",0);
 $lmanpx=anyvalue($cprst,"lawmanpx",0);
 $lmantel=anyvalue($cprst,"lawmanptel",0);
 $comlogo=anyvalue($cprst,"comlogo",0);
 echo '{"status":"1","msg":"成功","comname":"'.$compnm.'","aboutus":"'.$aboutus.'","contactus":"'.$contactus.'","friendlink":"'.$friendlink.'","comemail":"'.$comemail.'","lmanpx":"'.$lmanpx.'","lmantel":"'.$lmantel.'","comlogo":"'.$comlogo.'"}';
}else{
 echo '{"status":"0","msg":"失败","comname":"'.$compnm.'","aboutus":"'.$aboutus.'","contactus":"'.$contactus.'","friendlink":"'.$friendlink.'","comemail":"'.$comemail.'","lmanpx":"'.$lmanpx.'","lmantel":"'.$lmantel.'","comlogo":"'.$comlogo.'"}'; 
}
     session_write_close();
?>