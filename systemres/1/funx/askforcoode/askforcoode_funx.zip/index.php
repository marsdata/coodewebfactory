<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $hdomain=_get("hdomain");
$sitecode=_get("hostcode");
$sitename=_get("hostname");
$fromhost=$hdomain;
$ak=md5($hdomain);
$av=getRandChar(8);
$rv=getRandChar(11);
$kk=UX("delete from coode_scvuser where hostdomain='".$fromhost."' and hostcode='".date("Y-m-d")."'");
$extu=UX("select count(*) as result from coode_scvuser where hostdomain='".$fromhost."'");
if (intval($extu)==0 ){
  $sqlx="hostdomain,apikey,apival,rcode,lastvisit,hostcode,hosttitle,CRTM,UPTM,hostrolex,OLMK";
  $sqly="'$fromhost','$ak','$av','$rv',now(),'".date("Y-m-d")."','$sitename',now(),now(),'commonuser','".onlymark()."'";
  $zz=UX("insert into coode_scvuser(".$sqlx.")values(".$sqly.")");
  echo '{"status":"1","msg":"成功","rcode":"'.$rv.'","vcode":"'.$av.'","kcode":"'.$ak.'","redirect":""}';
}else{
  echo makereturnjson("0","获取失败","");
}
       session_write_close();
?>