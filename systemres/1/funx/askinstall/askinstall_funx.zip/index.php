<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $ssmark=$_GET["ssmark"];
if ($ssmark!=""){
 $kk=UX("delete from coode_syshostinstall where timestampdiff(minute,CRTM,now())>120");
 $sqlx="sysid,ssmark,fromhost,restype,resmark,restitle,issys,CRTM,UPTM,OLMK";
 $sqly="grpid,'".$ssmark."','".killlaststr(glw())."',restype,resmark,restitle,issys,now(),now(),md5(RAND())";
 $zz=UX("insert into coode_syshostinstall(".$sqlx.")select ".$sqly." from coode_sysregres where grpid='0' or grpid='1' and concat('".$ssmark."',grpid,restype,resmark) not in(select concat(ssmark,sysid,restype,resmark) from coode_syshostinstall)");
 $bktxt=anyfunrun("anyshort","","stid=rihWUj&pnum=9000&page=1&ssmark=".$ssmark,"");
 echo $bktxt;
}else{
 echo makereturnjson("0","参数不全","");
}
       session_write_close();
?>