<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $askstid=dftval($_GET["astid"],"");
$askpnum=dftval($_GET["askpnum"],"99999");
$askpage=dftval($_GET["askpage"],"1");
$asktitle=dftval($_POST["asktitle"],"");
$askcdt=dftval($_POST["cdt"],"");
$askocdt=dftval($_POST["ocdt"],"");
$asktab=dftval($_POST["asktab"],"");
$askkeys=dftval($_POST["askkeys"],"");
$exts=UX("select count(*) as result from coode_shortdata where shortid='".$askstid."'");
if (intval($exts)==0){
  $sqlx="shortid,shorttitle,tablename,showkeys,cdt,orddt,dttp,CRTM,UPTM,OLMK,CRTOR";
  $sqly="'$askstid','$asktitle','$asktab','$askkeys','$askcdt','$askocdt','json',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."'";
  $szz=UX("insert into coode_shortdata(".$sqlx.")values(".$sqly.")");  
}
echo anyshort($askstid,$askpage,$askpnum);
     session_write_close();
?>