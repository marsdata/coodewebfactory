<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $funid=$_GET["funid"];
$frst=SX("select vermd5,funcname,funkey,funfull from coode_funlist where funname='".$funid."' or funname='".$funid."()'");
$totf=countresult($frst);
if ($totf>0){
 $fmfx="/,";
 $vmd5=anyvalue($frst,"vermd5",0);
 $fcname=anyvalue($frst,"funcname",0);
 $fkey=anyvalue($frst,"funkey",0);
 $funfull=tostring(anyvalue($frst,"funfull",0));
 $ptfx=explode("=",$funfull);
 for ($p=1;$p<count($ptfx);$p++){
     if (strpos($ptfx[$p],"(")>0){
      $tmpfnm=qian($ptfx[$p],"(");
      $tmpfnm=str_replace(" ","",$tmpfnm);
      $tmpfnm=str_replace(huanhang(),"",$tmpfnm);
      $fmfx=$fmfx.$tmpfnm.",";
     }
 }
 $fmfnm="";
 $fmcls="";
 $fmtab="";
 $crst=SX("select areatype,funname,funcname,funtype,areaname,relyfuns from coode_funcool where '".str_replace("'","\'",$funfull)."' like concat('%',funname,'%') and funtype!='page'");
 $totc=countresult($crst);
 for ($ff=0;$ff<$totc;$ff++){
  $atype=anyvalue($crst,"areatype",$ff);
  $fname=anyvalue($crst,"funname",$ff);
  $fcname=anyvalue($crst,"funcname",$ff);
  $ftype=anyvalue($crst,"funtype",$ff);
  $aname=anyvalue($crst,"areaname",$ff);
  $relyfuns=anyvalue($crst,"relyfuns",$ff);
  if ($relyfuns!=""){
      $fmfnm=$fmfnm.$fname.",".$relyfuns.",";
  }else{
      $fmfnm=$fmfnm.$fname.",";
  }
  switch($atype){
      case "clsx":
   $fmcls=$fmcls.$aname.",";
      break;
      default:
  }
 }
 $fmfnm=onlyone(killlaststr($fmfnm));
 $fmcls=onlyone(killlaststr($fmcls));
 $trst=SX("select SNO,TABLE_NAME from coode_tablist where '".str_replace("'","\'",$funfull)."' like concat('%\"',TABLE_NAME,'\"%')");
 $tott=countresult($trst);
 for ($t=0;$t<$tott;$t++){
      $tbnm=anyvalue($trst,"TABLE_NAME",$t);
      $fmtab=$fmtab.$tbnm.",";
 }
 $fmtab=onlyone(killlaststr($fmtab));
 $zz=UX("update coode_funlist set STATUS=1,afftabs='".$fmtab."',afffuns='".$fmfnm."',affclss='".$fmcls."' where funname='".$funid."' or funname='".$funid."()'");
 $zz=UX("update coode_funlist set isdb=1  where afffuns like '%SX%' or  afffuns like '%UX%' or  afffuns like '%selecteds%' or  afffuns like '%updatings%' or  afffuns like '%selectedx%' or  afffuns like '%updatingx%' or  afffuns like '%selected%' or  afffuns like '%updating%'");
 echo makereturnjson("1","审计成功","");
}else{
 echo makereturnjson("0","审计失败，不存在该函数","");
}
       session_write_close();
?>