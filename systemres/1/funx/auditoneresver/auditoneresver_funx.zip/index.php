<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $rescode=dftval($_GET["rescode"],"");
$restype=dftval($_GET["restype"],"");
$fromsno=dftval($_GET["fromsno"],"");
switch($restype){
  case "tab":
  $subver=SX("select vermd5 from coode_keydetailx where TABLE_NAME='".$rescode."'");
  $z=UX("update coode_tablist set VRT=md5(concat(schm,tabtitle,imghead,allkeys,createsql,srckey,srcttk,tabtype,tabcls,sysid,mainsqx,subsqx,olmkkey,'".$subver."')) where TABLE_NAME='".$rescode."'");
  $b=UX("update coode_tablist,coode_sysresname set coode_sysresname.resmd5=coode_tablist.VRT where coode_sysresname.restype='tab' and coode_sysresname.rescode=coode_tablist.TABLE_NAME and coode_sysresname.rescode='".$rescode."'");
  break;
  case "short":
  $zz=UX("update coode_shortcss set VRT=md5(concat(describ,tablename,units,jsfiles,cssfiles,scriptx,stylex,scriptext,styleext,heightx,widthx,fixed,diytop,bottombutton,diybottom,sbtn,rbtn,dtshow,isexp)) where shortid like '%".$rescode."%'");
  $subver0=SX("select vermd5 from coode_keydetaily where shortid='".$rescode."'");
  $subver1=UX("select VRT as result from coode_shortcss where shortid='".$rescode."'");
  $subver2=UX("select VRT as result from coode_shortcss where shortid='".$rescode."'DETAIL");
  $z=UX("update coode_shortdata set vermd5=md5(concat(shorttitle,sysid,caseid,detailid,tablename,allkeys,showkeys,skeys,hdata,cdt,orddt,dttp,'".$subver0.$subver1.$subver2."')) where shortid='".$rescode."'");
  $b=UX("update coode_shortdata,coode_sysresname set coode_sysresname.resmd5=coode_shortdata.vermd5 where coode_sysresname.restype='short' and coode_sysresname.rescode=coode_shortdata.shortid and coode_sysresname.rescode='".$rescode."'");
  break;
  case "temp":
  $cc=UX("update coode_codedemo set VRT=md5(concat(keytype,keydemo)) where dumark='".$rescode."'");
  $subver=SX("select VRT from coode_codedemo where dumark='".$rescode."'");
  $dd=UX("update coode_makedujsfile set vermd5=md5(evalcode) where dumark='".$rescode."'");
  $dv=UX("select vermd5 as result from coode_makedujsfile  where dumark='".$rescode."'");
  $ee=UX("update coode_makeformact set VRT=md5(evalcode) where dumark='".$rescode."'");
  $ev=UX("select VRT as result from coode_makeformact  where dumark='".$rescode."'");
  $z=UX("update coode_domainunit set subvermd5=md5('".$subver.$dv.$ev."') where dumark='".$rescode."'");
  $z=UX("update coode_domainunit set vermd5=md5(concat(outurl,pagehtml,'".$subver.$dv.$ev."')) where dumark='".$rescode."'");
  $b=UX("update coode_domainunit,coode_sysresname set coode_sysresname.resmd5=coode_domainunit.vermd5 where coode_sysresname.restype='temp' and coode_sysresname.rescode=coode_domainunit.dumark  and coode_sysresname.rescode='".$rescode."'");
  break;
  case "dspc":
  $cc=UX("update coode_dspckey set VRT=md5(concat(keymark,keytitle,keylen,sqx,keytype,dxtype,keydescrib)) where datamark='".$rescode."'");
  $subver=SX("select VRT from coode_dspckey where datamark='".$rescode."'");
  $z=UX("update coode_dataspace set VRT=md5(concat(datatitle,'".$subver."')),keyfrmver=md5('".$subver."') where datamark='".$rescode."'");
  $zb=UX("update coode_dataspace,coode_sysresname set coode_sysresname.resmd5=coode_dataspace.vermd5 where coode_sysresname.restype='dspc' and coode_sysresname.rescode=coode_dataspace.datamark  and coode_sysresname.rescode='".$rescode."'");
  break;
  case "menu":
  $subver=SX("select vermd5 from coode_plotdetail where plotmark='".$rescode."'");
  $z=UX("update coode_plotlist set vermd5=md5(concat(markname,'".$subver."')) where plotmark='".$rescode."'");
  $zb=UX("update coode_plotlist,coode_sysresname set coode_sysresname.resmd5=coode_plotlist.vermd5 where coode_sysresname.restype='menu' and coode_sysresname.rescode=coode_plotlist.plotmark  and coode_sysresname.rescode='".$rescode."'");
  break;
  case "sys":
  $subver=SX("select resmd5 from coode_sysresname where sysid='".$rescode."'");
  $z=UX("update coode_sysinformation set vermd5=md5('".$subver."') where sysid='".$rescode."'");  
  break;  
  default:
  switch($restype){
    case "fun":
     $funver=UX("update coode_sysresname,coode_funlist set coode_sysresname.resmd5=coode_funlist.vermd5 where coode_sysresname.rescode=coode_funlist.funname and coode_sysresname.restype='fun' and coode_sysresname.rescode='".$rescode."'");
    break;
    case "cls":
     $clsver=UX("update coode_sysresname,coode_phpcls set coode_sysresname.resmd5=coode_phpcls.vermd5 where coode_sysresname.rescode=coode_phpcls.funname and coode_sysresname.restype='cls' and coode_sysresname.rescode='".$rescode."'");
    break;
    case "dfun":
    $aa=UX("update coode_datafun set VRT=md5(dftitle,dfuneval) where dfunmark='".$rescode."'");
    $dfver=UX("update coode_sysresname,coode_datafun set coode_sysresname.resmd5=coode_datafun.VRT where coode_sysresname.rescode=coode_datafun.dfunmark and coode_sysresname.restype='dfun' and coode_sysresname.rescode='".$rescode."'")
    break;
    case "afun":
    $aa=UX("update coode_affairfunlist set vermd5=md5(funcname,funfull) where funname='".$rescode."'");
    $paraver=UX("update coode_sysresname,coode_affairfunlist set coode_sysresname.resmd5=coode_affairfunlist.vermd5 where coode_sysresname.rescode=coode_affairfunlist.funname and coode_sysresname.restype='afun' and coode_sysresname.rescode='".$rescode."'");
    break;
    case "mfun":
    $aa=UX("update coode_multifunlist set vermd5=md5(funcname,funfull) where funname='".$rescode."'");
    $paraver=UX("update coode_sysresname,coode_multifunlist set coode_sysresname.resmd5=coode_multifunlist.vermd5 where coode_sysresname.rescode=coode_multifunlist.funname and coode_sysresname.restype='mfun' and coode_sysresname.rescode='".$rescode."'");
    break;
    case "sfun":
    $aa=UX("update coode_funsetfile set vermd5=md5(setcname,funbody) where setname='".$rescode."'");
    $paraver=UX("update coode_sysresname,coode_funsetfile set coode_sysresname.resmd5=coode_funsetfile.vermd5 where coode_sysresname.rescode=coode_funsetfile.setname and coode_sysresname.restype='sfun' and coode_sysresname.rescode='".$rescode."'");
    break;
    case "config":
    $cc=UX("update coode_sysconfig set VRT=md5(syskey,sysktitle,sysval) where syskey='".$rescode."'");
    $cfgver=UX("update coode_sysresname,coode_sysconfig set coode_sysresname.resmd5=coode_sysconfig.VRT where coode_sysresname.rescode=coode_sysconfig.syskey and coode_sysresname.restype='config' and coode_sysresname.rescode='".$rescode."'");
    break;
    case "const":
    $cc=UX("update coode_sysconstant set VRT=md5(constantid,constanttitle,constanttype,constantvalue,constvar) where constantid='".$rescode."'");
    $cfgver=UX("update coode_sysresname,coode_sysconstant set coode_sysresname.resmd5=coode_sysconstant.VRT where coode_sysresname.rescode=coode_sysconstant.constantid and coode_sysresname.restype='const' and coode_sysresname.rescode='".$rescode."'");
    break;
    case "parardr":
    $aa=UX("update coode_parardr set VRT=md5(paratitle,rdrpath,rdrcode) where paramark='".$rescode."'");
    $paraver=UX("update coode_sysresname,coode_parardr set coode_sysresname.resmd5=coode_parardr.VRT where coode_sysresname.rescode=coode_parardr.paramark and coode_sysresname.restype='parardr' and coode_sysresname.rescode='".$rescode."'");
    break;
    case "cdtrdr":
    $aa=UX("update coode_cdtrdr set VRT=md5(rdrpath,rdrcode) where cdtmark='".$rescode."'");
    $cdtver=UX("update coode_sysresname,coode_cdtrdr set coode_sysresname.resmd5=coode_cdtrdr.VRT where coode_sysresname.rescode=coode_cdtrdr.cdtmark and coode_sysresname.restype='cdtrdr' and coode_sysresname.rescode='".$rescode."'");
    break;
  }
}
$qq=UX("update coode_sysresname set STATUS=1 where SNO=".$fromsno);
echo makereturnjson("1","成功","");
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>