<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     function addsrctopage($tnmk,$restype,$rescode){
 $extr=UX("select count(*) as result from coode_resrelyext where restype='".$pagex."' and rescode='".$tnmk."' and relyrestp='".$restype."' and relyrescd='".$rescode."'");
 if (intval($extr)==0){
  $sqlx="restype,rescode,relyrestp,relyrescd,CRTM,UPTM,OLMK";
  $sqly="'pagex','".$tnmk."','$restype','$rescode',now(),now(),'".onlymark()."'";
  $zz=UX("insert into coode_resrelyext(".$sqlx.")values(".$sqly.")");
 }else{
  $extr=UX("update coode_resrelyext set UPTM=now() where restype='".$pagex."' and rescode='".$tnmk."' and relyrestp='".$restype."' and relyrescd='".$rescode."'");
 }
}
  $tinymk=$_GET["tiny"]; 
  $longrst=SX("select tinymark,shortid,tabname,tempid,longexp,laypath from coode_tiny where tinymark='".$tinymk."'");
  $totlong=countresult($longrst);
  $stid=anyvalue($longrst,"shortid",0);  
  $tabnm=anyvalue($longrst,"tabname",0);  
  $tempid=anyvalue($longrst,"tempid",0);  
  $lexp=tostring(anyvalue($longrst,"longexp",0));
  $laypath=anyvalue($longrst,"laypath",0);
  if ($totlong>0){
    $prst=SX("select relyrestp,relyrescd,relyrestitle from coode_resrelyext where restype='pagex' and rescode='".$tinymk."'");
    $totp=countresult($prst);
    for ($p=0;$p<$totp;$p++){
      $relyrestp=anyvalue($prst,"relyrestp",$p);
      $relyrescd=anyvalue($prst,"relyrescd",$p);
      $relyrestitle=anyvalue($prst,"relyrestitle",$p);
      $zzx=addsrctopage($tinymk,$relyrestp,$relyrescd);  
    }
    if ($stid!=""){
     $zz0=addsrctopage($tinymk,"formx",$stid);
     $prst=SX("select relyrestp,relyrescd,relyrestitle from coode_resrelyext where restype='formx' and rescode='".$stid."'");
     $totp=countresult($prst);
     for ($p=0;$p<$totp;$p++){
       $relyrestp=anyvalue($prst,"relyrestp",$p);
       $relyrescd=anyvalue($prst,"relyrescd",$p);
       $relyrestitle=anyvalue($prst,"relyrestitle",$p);
       $zzx=addsrctopage($tinymk,$relyrestp,$relyrescd);  
     }
    }
    if ($tabnm!=""){
     $zz0=addsrctopage($tinymk,"tabx",$tabnm);
     $prst=SX("select relyrestp,relyrescd,relyrestitle from coode_resrelyext where restype='tabx' and rescode='".$tabnm."'");
     $totp=countresult($prst);
     for ($p=0;$p<$totp;$p++){
       $relyrestp=anyvalue($prst,"relyrestp",$p);
       $relyrescd=anyvalue($prst,"relyrescd",$p);
       $relyrestitle=anyvalue($prst,"relyrestitle",$p);
       $zzx=addsrctopage($tinymk,$relyrestp,$relyrescd);  
     }
   }
   if ($tmpid!=""){
     $zz0=addsrctopage($tinymk,"tempx",$tempid);
     $prst=SX("select relyrestp,relyrescd,relyrestitle from coode_resrelyext where restype='tempx' and rescode='".$tempid."'");
     $totp=countresult($prst);
     for ($p=0;$p<$totp;$p++){
       $relyrestp=anyvalue($prst,"relyrestp",$p);
       $relyrescd=anyvalue($prst,"relyrescd",$p);
       $relyrestitle=anyvalue($prst,"relyrestitle",$p);
       $zzx=addsrctopage($tinymk,$relyrestp,$relyrescd);  
     }
   }
   echo makereturnjson("1","审计成功","");
 }else{
   echo makereturnjson("0","审计失败","");
 }
     session_write_close();
?>