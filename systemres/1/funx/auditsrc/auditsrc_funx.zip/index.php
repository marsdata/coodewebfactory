<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $tinymk=$_GET["tinymark"];
 $stid=$_GET["stid"];
 
  $longrst=SX("select tinymark,imghead,longexp,clssa,clssb,sysid,appid from coode_tiny where tinymark='".$tinymk."'");
  $sysid=anyvalue($longrst,"sysid",0);
  $appid=anyvalue($longrst,"appid",0);
  $lexp=tostring(anyvalue($longrst,"longexp",0));
  $clsa=anyvalue($longrst,"clssa",0);
  $clsb=anyvalue($longrst,"clssb",0);
  $pmk=$tinymk;
  $plink=tostring(anyvalue($longrst,"longexp",0));
  $url=$lexp;  
  $shortid="";  
  $tablenm="";
 
 if (strpos($lexp,"stid=")>0 or $stid!=""){ 
     if ($stid==""){
       $shortid=qian(qian(hou($lexp,"stid="),"&"),"-");
     }else{
       $shortid=$stid;
       $lexp="/SPEC/EDITOR/anyjsshort.php?stid=".$shortid."-pnum:30-";
     };
     $sxy=SX("select tablename,lang,caseid,sysid,appid from coode_shortdata where shortid='".$shortid."'");
     $tablenm=anyvalue($sxy,"tablename",0);
     $pageid=anyvalue($sxy,"lang",0);
     $caseid=anyvalue($sxy,"caseid",0);
     if ($stid!=""){//如果直接为short审计则直接引用short里的sysid
      $sysid=anyvalue($sxy,"sysid",0);
      $appid=anyvalue($sxy,"appid",0);
     }
   
   
    $fpath=combineurl(localroot(),urltopath($lexp));  
    $sqla="sysid,appid,classa,classb,pagemark,sourceid,sourcecls,OLMK,CRTM,UPTM,CRTOR,PTOF";
    $sqlb="'".$sysid."','".$appid."','".$clsa."','".$clsb."','".$tinymk."','".$plink."','file','".onlymark()."',now(),now(),'".$_COOKIE["uid"]."','".$plink."'";
    $xz=UX("insert into coode_pagesrc(".$sqla.")values(".$sqlb.")");
    $zx=UX("update coode_pageidx set pagelink='".$plink."' where pagemark='".$pmk."'");
 
     $cssunits=UX("select units as result from coode_shortcss where shortid='".$shortid."'");
     $pageunits=UX("select units as result from coode_compage where pageid='".$pageid."'");
     $caseunits=UX("select units as result from coode_caseform where cfid='".$caseid."'");
     $fmu=onlyone($cssunits.$pageunits.$caseunits);
     $x=UX("update coode_tiny set units='".$fmu."',sysid='".$sysid."',appid='".$appid."' where tinymark='".$tinymk."'");
     $tmphtml=file_get_contents(combineurl("http://".glw(),$lexp."&template=1"));
     $indexpath=combineurl(localroot(),"/DEVELOPING/".$sysid."/".$appid."/shortid/".$shortid);
     is_dir($indexpath) OR mkdir($indexpath, 0777, true); 
     $indexispath=combineurl(localroot(),"/DEVELOPING/".$sysid."/".$appid."/shortid/".$shortid."/install");
     is_dir($indexispath) OR mkdir($indexispath, 0777, true); 
     $indexjspath=combineurl(localroot(),"/DEVELOPING/".$sysid."/".$appid."/shortid/".$shortid."/js");
     is_dir($indexjspath) OR mkdir($indexjspath, 0777, true); 
     $indexcsspath=combineurl(localroot(),"/DEVELOPING/".$sysid."/".$appid."/shortid/".$shortid."/css");
     is_dir($indexcsspath) OR mkdir($indexcsspath, 0777, true); 
     $indeximagespath=combineurl(localroot(),"/DEVELOPING/".$sysid."/".$appid."/shortid/".$shortid."/images");
     is_dir($indeximagespath) OR mkdir($indeximagespath, 0777, true);      
     $z=anyfunrun("superdown","","units=".$fmu."&srcpath=".$indexpath,"");
 }else{
    $tmphtml=file_get_contents(combineurl("http://".glw(),$lexp));
    $ptunits=explode("/FACE/",$tmphtml);    
    $totpt=count($ptunits);
    $fmu="";
    for ($j=1;$j<$totpt;$j++){
      $fmu=$fmu.qian($ptunits[$j],"/").",";
    }; 
     $x=UX("update coode_tiny set units='".onlyone($fmu)."' where tinymark='".$tinymk."'");
     $indexpath=combineurl(localroot(),"/DEVELOPING/".$sysid."/".$appid."/pagemark/".$tinymk);     
     is_dir($indexpath) OR mkdir($indexpath, 0777, true); 
     $indexispath=combineurl(localroot(),"/DEVELOPING/".$sysid."/".$appid."/pagemark/".$tinymk."/install");
     is_dir($indexispath) OR mkdir($indexispath, 0777, true); 
     $indexjspath=combineurl(localroot(),"/DEVELOPING/".$sysid."/".$appid."/pagemark/".$tinymk."/js");
     is_dir($indexjspath) OR mkdir($indexjspath, 0777, true); 
     $indexcsspath=combineurl(localroot(),"/DEVELOPING/".$sysid."/".$appid."/pagemark/".$tinymk."/css");
     is_dir($indexcsspath) OR mkdir($indexcsspath, 0777, true); 
     $indeximagespath=combineurl(localroot(),"/DEVELOPING/".$sysid."/".$appid."/pagemark/".$tinymk."/images");
     is_dir($indeximagespath) OR mkdir($indeximagespath, 0777, true); 
     $z=anyfunrun("superdown","","units=".$fmu."&srcpath=".$indexpath,"");
     //覆盖前要完成资源替换  
 }
   $srddemo='configdata={"tablist":[demotab],"funlist":[demofunlist],"clslist":[democlslist],"datalist":[demodata]}';
   //js,log,funandcls,php,tabcrt,tabdata
   $fmcdt="";
   $fmfcdt="";
   $fmccdt="";
   $fmtablist="";
   $fmfunlist="";
   $fmclslist="";
   $fmdatalist="";
   
   $trst=SX("select TABLE_NAME,createsql,tabtitle from coode_tablist where TABLE_NAME='".$tablenm."'");
   $tott=countresult($trst);
   for ($i=0;$i<$tott;$i++){
     $froot=combineurl($indexispath,"/tabcrt/".anyvalue($trst,"TABLE_NAME",$i).".txt");
     $z=overfile($froot,anyvalue($trst,"createsql",$i)); 
     $fmtablist=$fmtablist."{\"tabtitle\":\"".anyvalue($trst,"tabtitle",$i)."\",\"tabname\":\"".anyvalue($trst,"TABLE_NAME",$i)."\"},";
     $fmcdt=$fmcdt." srcid='".anyvalue($trst,"TABLE_NAME",$i)."' or ";
    }
 if ($pmk==""){
   $pmk=$shortid."list";
 }
 if ($tmphtml!="" and $sysid!="" and $appid!=""){
     $sqla="permid,permtitle,appid,compid,groupid,grpvalx,clientid,metcls,method,behiver,keyx,valx,dataarea,sysid,STATUS,CRTM,UPTM";
     $sqlb="'".$pmk."','".$pmk."页面访问','".$appid."','".$_COOKIE["cid"]."','groupid',1,'clientid','page','visit','','','DA:selfitem,DA:selfpos,DA:sonpos,DA:selfandsonpos,DA:selfleaddepart,','".$sysid."',1,now(),now()";
     $x=UX("insert into coode_ppmtsys(".$sqla.")values(".$sqlb.")");
    $tmd5=md5($tmphtml);
    $mimgs=absorburls($tmphtml,$mimgs);
     for ($k=0;$k<count($mimgs);$k++){
       $tmpimg=saveimgto($mimgs[$k],combineurl(localroot(),$lexp),$indeximagespath);
       $tmphtml=str_replace($mimgs[$k],$tmpimg,$tmphtml);
     }
   $afuns=absorbfuns($tmphtml,$afuns);
   for ($i=0;$i<count($afuns);$i++){
    $ptfuna=funabout($afuns[$i],$ptfuna);
    $fmfcdt=$fmfcdt." funname='".$afuns[$i]."' or  funname='".$afuns[$i]."()' ";
    $x=regsrc($sysid,$appid,$pmk,$lexp,$clsa,$clsb,"fun",$afuns[$i]);
    for ($j=0;$j<count($ptfuna["fun"]);$j++){
     $y=regsrc($sysid,$appid,$pmk,$lexp,$clsa,$clsb,"fun",$ptfuna["fun"][$j]);
     $fmfcdt=$fmfcdt." funname='".$ptfuna["fun"][$j]."' or  funname='".$ptfuna["fun"][$j]."()' ";
    }
    for ($j=0;$j<count($ptfuna["cls"]);$j++){
     $y=regsrc($sysid,$appid,$pmk,$lexp,$clsa,$clsb,"cls",$ptfuna["cls"][$j]);
     $fmccdt=$fmccdt." funname='".$ptfuna["cls"][$j]."' or  funname='".$ptfuna["cls"][$j]."()' ";
    }
    for ($j=0;$j<count($ptfuna["tab"]);$j++){
     $y=regsrc($sysid,$appid,$pmk,$lexp,$clsa,$clsb,"tab",$ptfuna["tab"][$j]);
     $fmcdt=$fmcdt." srcid='".$ptfuna["tab"][$j]."' or ";
     $fmtablist=$fmtablist."{\"tabtitle\":\"".$ptfuna["tab"][$j]."\",\"tabname\":\"".$ptfuna["tab"][$j]."\"},";
    }
  }
  if ($tablenm!=""){   
   $pttaba=tababout($tablenm,$pttaba);
    $x=regsrc($sysid,$appid,$pmk,$lexp,$clsa,$clsb,"tab",$tablenm);
    for ($j=0;$j<count($pttaba["fun"]);$j++){
     $y=regsrc($sysid,$appid,$pmk,$lexp,$clsa,$clsb,"fun",$pttaba["fun"][$j]);
     $fmfcdt=$fmfcdt." funname='".$pttaba["fun"][$j]."' or  funname='".$pttaba["fun"][$j]."()' ";
    }
    for ($j=0;$j<count($pttaba["cls"]);$j++){
     $y=regsrc($sysid,$appid,$pmk,$lexp,$clsa,$clsb,"cls",$pttaba["cls"][$j]);
     $fmccdt=$fmccdt." funname='".$pttaba["cls"][$j]."' or  funname='".$pttaba["cls"][$j]."()' ";
    }
    for ($j=0;$j<count($pttaba["tab"]);$j++){
     $y=regsrc($sysid,$appid,$pmk,$lexp,$clsa,$clsb,"tab",$pttaba["tab"][$j]);
     $fmcdt=$fmcdt." srcid='".$pttaba["tab"][$j]."' or ";
     $fmtablist=$fmtablist."{\"tabtitle\":\"".$pttaba["tab"][$j]."\",\"tabname\":\"".$pttaba["tab"][$j]."\"},";
    }
   }
  }
  eval(CLASSX("htmlchange"));
  $hx=new htmlchange();  
  $hy=$hx->fmframe($hy,$tmphtml,combineurl(localroot(),$lexp));
    if (intval($hy["num"]["totimgurl"])>0){
        for ($j=0;$j<intval($hy["num"]["totimgurl"]);$j++){
          $x=regfile($sysid,$appid,$clsa,$clsb,$pmk,$lexp,$hy["imgurl"][$j],$hy["imgmyurl"][$j],$hy["imglc"][$j]);          
            if ($x=="1"){                                      
             if (substr($hy["imgurl"][$j],0,2)=="//" or strpos(hy["imgurl"][$j],"://")>0){               
                GrabImage($hy["imgurl"][$j], combineurl($indeximagespath,excurl($hy["imgurl"][$j])));
             }else{
               if (substr($hy["imgurl"][$j],0,1)=="/"){
                copy_filetodir(combineurl(localroot(),$hy["imgurl"][$j]),$indeximagespath);                
               }else{
                copy_filetodir(connurl($fpath,$hy["imgurl"][$j]),$indeximagespath);                
               }
               if (combineurl($indeximagespath,urlfname($hy["imgurl"][$j]))<>combineurl($indeximagespath,excurl($hy["imgurl"][$j])) ){
                rename(combineurl($indeximagespath,urlfname($hy["imgurl"][$j])), combineurl($indeximagespath,excurl($hy["imgurl"][$j])));
               }
             }             
             $tmphtml=str_replace($hy["imgmyurl"][$j],"images/".excurl($hy["imgurl"][$j]),$tmphtml);
            }else{
              $tmphtml=str_replace($hy["imgmyurl"][$j],"images/".excurl($hy["imgurl"][$j]),$tmphtml);
            }
        }
    }
 
    if (intval($hy["num"]["totscpurl"])>0){    
        for ($j=0;$j<intval($hy["num"]["totscpurl"]);$j++){    
        $x=regfile($sysid,$appid,$clsa,$clsb,$pmk,$lexp,$hy["jsurl"][$j],$hy["jsmyurl"][$j],$hy["jslc"][$j]);
            if ($x=="1"){             
             if (substr($hy["jsurl"][$j],0,2)=="//"  or strpos(hy["jsurl"][$j],"://")>0){
                $xyz=overfile(combineurl($indexjspath,excurl($hy["jsurl"][$j])),file_get_contents(combineurl("http://".glw(),$hy["jsurl"][$j])));
             }else{
               if (substr($hy["jsurl"][$j],0,1)=="/"){
                copy_filetodir(combineurl(localroot(),$hy["jsurl"][$j]),$indexjspath);
               }else{
                 copy_filetodir(connurl($fpath,$hy["jsurl"][$j]),$indexjspath);
               }
              rename(combineurl($indexjspath,urlfname($hy["jsurl"][$j])), combineurl($indexjspath,excurl($hy["jsurl"][$j])));
             }
             $svpath=combineurl($indexjspath,excurl($hy["jsurl"][$j]));
             $gtpath=str_replace(localroot(),"http://".glw(),$svpath);
             $gjstxt=file_get_contents($gtpath);
             $mimgs=absorbpics($gjstxt,$mimgs);
             for ($k=0;$k<count($mimgs);$k++){
               $tmpimg=saveimgto($mimgs[$k],combineurl(localroot(),$lexp),$indeximagespath);
               $gjstxt=str_replace($mimgs[$k],$tmpimg,$gjstxt);
             }
             $xyz=overfile($svpath,$gjstxt);             
            
             $tmphtml=str_replace($hy["jsmyurl"][$j],"js/".excurl($hy["jsurl"][$j]),$tmphtml);
            $afuns=absorbfuns(file_get_contents(combineurl("http://".glw(),$hy["jsurl"][$j])),$afuns);
            
             for ($o=0;$o<count($afuns);$o++){
               $ptfuna=funabout($afuns[$o],$ptfuna);
               $x=regsrc($sysid,$appid,$pmk,$lexp,$clsa,$clsb,"fun",$afuns[$o]);
               $fmfcdt=$fmfcdt." funname='".$afuns[$o]."' or  funname='".$afuns[$o]."()' ";
               for ($r=0;$r<count($ptfuna["fun"]);$r++){
                 $y=regsrc($sysid,$appid,$pmk,$lexp,$clsa,$clsb,"fun",$ptfuna["fun"][$r]);
                 $fmfcdt=$fmfcdt." funname='".$ptfuna["fun"][$r]."' or  funname='".$ptfuna["fun"][$r]."()' ";
               }
               for ($r=0;$r<count($ptfuna["cls"]);$r++){
                $y=regsrc($sysid,$appid,$pmk,$lexp,$clsa,$clsb,"cls",$ptfuna["cls"][$r]); 
                $fmccdt=$fmccdt." funname='".$ptfuna["cls"][$r]."' or  funname='".$ptfuna["cls"][$r]."()' ";
               }
               for ($r=0;$r<count($ptfuna["tab"]);$r++){
                $y=regsrc($sysid,$appid,$pmk,$lexp,$clsa,$clsb,"tab",$ptfuna["tab"][$r]);
                $fmcdt=$fmcdt." srcid='".$ptfuna["tab"][$r]."' or ";
                $fmtablist=$fmtablist."{\"tabtitle\":\"".$ptfuna["tab"][$r]."\",\"tabname\":\"".$ptfuna["tab"][$r]."\"},";
               }
             }
            }else{
              $tmphtml=str_replace($hy["jsmyurl"][$j],"js/".excurl($hy["jsurl"][$j]),$tmphtml);
            }
        }
    }
    if (intval($hy["num"]["totcssurl"])>0){
        for ($j=0;$j<intval($hy["num"]["totcssurl"]);$j++){
        $x=regfile($sysid,$appid,$clsa,$clsb,$pmk,$lexp,$hy["cssurl"][$j],$hy["cssmyurl"][$j],$hy["csslc"][$j]);
            if ($x=="1"){             
             if (substr($hy["cssurl"][$j],0,2)=="//"  or strpos(hy["cssurl"][$j],"://")>0){
                $xyz=overfile(combineurl($indexcsspath,excurl($hy["cssurl"][$j])),file_get_contents(combineurl("http://".glw(),$hy["cssurl"][$j])));
             }else{
               if (substr($hy["cssurl"][$j],0,1)=="/"){
                 copy_filetodir(combineurl(localroot(),$hy["cssurl"][$j]),$indexcsspath);
               }else{
                 copy_filetodir(connurl($fpath,$hy["cssurl"][$j]),$indexcsspath);
               }
               rename(combineurl($indexcsspath,urlfname($hy["cssurl"][$j])), combineurl($indexcsspath,excurl($hy["cssurl"][$j])));
             }             
              $tmphtml=str_replace($hy["cssmyurl"][$j],"css/".excurl($hy["cssurl"][$j]),$tmphtml);              
              $e1css=excssfile($e1css,file_get_contents(combineurl("http://".glw(),$hy["cssurl"][$j])),combineurl("http://".glw(),$hy["cssurl"][$j]),$indexcsspath);
              for ($p0=0;$p0<$e1css["count"]["srcnum"];$p0++){
                  $n0=regfile($sysid,$appid,$clsa,$clsb,$pmk,$e1css["srcpar"][$p0],$e1css["srcurl"][$p0],$e1css["srcmyurl"][$p0],$e1css["srclc"][$p0]);
              }
              for ($p=0;$p<$e1css["count"]["cssnum"];$p++){
                $n0=regfile($sysid,$appid,$clsa,$clsb,$pmk,$e1css["csspar"][$p],$e1css["cssurl"][$p],$e1css["cssmyurl"][$p],$e1css["csslc"][$p]);
                $e2css=excssfile($e2css,file_get_contents($e1css["cssurl"][$p]),$e1css["cssurl"][$p],$indexcsspath);
                for ($p0=0;$p0<$e2css["count"]["srcnum"];$p0++){
                  $n0=regfile($sysid,$appid,$clsa,$clsb,$pmk,$e2css["srcpar"][$p0],$e2css["srcurl"][$p0],$e2css["srcmyurl"][$p0],$e2css["srclc"][$p0]);
                }
                for ($p0=0;$p0<$e2css["count"]["cssnum"];$p0++){
                  $n1=regfile($sysid,$appid,$clsa,$clsb,$pmk,$e2css["csspar"][$p0],$e2css["cssurl"][$p0],$e2css["cssmyurl"][$p0],$e2css["csslc"][$p0]);
                  $e3css=excssfile($e3css,file_get_contents($e2css["cssurl"][$p0]),$e2css["cssurl"][$p0],$indexcsspath);
                  for ($p1=0;$p1<$e3css["count"]["srcnum"];$p1++){
                    $n0=regfile($sysid,$appid,$clsa,$clsb,$pmk,$e2css["srcpar"][$p1],$e2css["srcurl"][$p1],$e2css["srcmyurl"][$p1],$e2css["srclc"][$p1]);
                  }
                  for ($p1=0;$p1<$e3css["count"]["cssnum"];$p1++){
                    $n2=regfile($sysid,$appid,$clsa,$clsb,$pmk,$e3css["csspar"][$p1],$e2css["cssurl"][$p1],$e3css["cssmyurl"][$p1],$e3css["csslc"][$p1]);  
                  }
                }
              }
            }else{
              $tmphtml=str_replace($hy["cssmyurl"][$j],"css/".excurl($hy["cssurl"][$j]),$tmphtml);
            }
        }
    }
    $y=UX("update coode_tiny set PRIME=0,auditmd5='".$tmd5."',UPTM=now() where tinymark='".$tinymk."' ");
    $y=UX("update coode_shortdata set PRIME=0,UPTM=now() where shortid='".$shortid."' ");
    $z=relinksrc($tinymk,$lexp,$sysid,$appid);
    $tmphtml=str_replace("[tablename]",$tablenm,$tmphtml);
    if (strpos($lexp,"anyshortnew.php")>0 or strpos($lexp,"anytablenew.php")>0){      
      $x=overfile(combineurl($indexpath,"detail.html"),$tmphtml);
    }else{
      $x=overfile(combineurl($indexpath,"index.html"),$tmphtml);
    }
    //--------------------------------------------------------------
   // copy_dir(localroot()."DEVELOPING/x/install",localroot()."DEVELOPING/".$sysid."/install");
 $fmcdt=substr($fmcdt,0,strlen($fmcdt)-3);
 $fmfcdt=substr($fmfcdt,0,strlen($fmfcdt)-3);
 $fmccdt=substr($fmccdt,0,strlen($fmccdt)-3);
$fmtablist=killlaststr($fmtablist);
$frst=SX("select funname,funcname,funfull from coode_funlist where ".$fmfcdt);
$totf=countresult($frst);
for ($i=0;$i<$totf;$i++){
  $froot=combineurl($indexispath,"/funandcls/".str_replace("()","",anyvalue($frst,"funname",$i)).".txt");
  $z=overfile($froot,anyvalue($frst,"funfull",$i)); 
  $fmfunlist=$fmfunlist."{\"funtitle\":\"".anyvalue($frst,"funcname",$i)."\",\"funname\":\"".str_replace("()","",anyvalue($frst,"funname",$i))."\"},";
}
$fmfunlist=killlaststr($fmfunlist);
$frst=SX("select funname,funcname,funfull from coode_phpcls where ".$fmccdt);
$totf=countresult($frst);
for ($i=0;$i<$totf;$i++){
  $froot=combineurl($indexispath,"/funandcls/".str_replace("()","",anyvalue($frst,"funname",$i)).".txt");
  $z=overfile($froot,anyvalue($frst,"funfull",$i)); 
  $fmclslist=$fmclslist."{\"funtitle\":\"".anyvalue($frst,"funcname",$i)."\",\"funname\":\"".str_replace("()","",anyvalue($frst,"funname",$i))."\"},";
}
$fmclslist=killlaststr($fmclslist);
$drst=SX("select datasql,tabname,frmsql,tabolmk,mymd5 from coode_datainstall where ".$fmcdt);
$totd=countresult($drst);
for ($i=0;$i<$totd;$i++){
  $froot=combineurl($indexispath,"/tabdata/".str_replace("()","",anyvalue($drst,"tabolmk",$i)).".txt");
  $z=overfile($froot,anyvalue($drst,"frmsql",$i)."@@@@".anyvalue($drst,"datasql",$i)); 
  $fmdatalist=$fmdatalist."{\"tabolmk\":\"".anyvalue($drst,"tabolmk",$i)."@".anyvalue($drst,"tabname",$i)."\",\"mymd5\":\"".anyvalue($drst,"mymd5",$i)."\"},";
}
$fmdatalist=killlaststr($fmdatalist);
$srddemo=str_replace("demotab",$fmtablist,$srddemo);
$srddemo=str_replace("demofunlist",$fmfunlist,$srddemo);
$srddemo=str_replace("democlslist",$fmclslist,$srddemo);
$srddemo=str_replace("demodata",$fmdatalist,$srddemo);
 $froot=combineurl($indexispath,"/config.js");
 $z=overfile($froot,$srddemo); 
 echo "1";
  
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>