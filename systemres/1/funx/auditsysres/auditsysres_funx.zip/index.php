<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sysid=dftval($_GET["sysid"],"");
//表格及相关，函数，类，引用模板，
//短地址，系统结构，数据请求，变量，常量，参数，
//小数据空间，引用节点；资源地址及资源值；
//变成版本后，提交给母机；其他机可以根据索引进行还原。索引变成具体数据值；
$systitle=UX("select sysname as result from coode_sysinformation where sysid='".$sysid."'");
$sqlx="sysid,restype,rescode,restitle,CRTM,UPTM,OLMK";
//表格审计
$z=UX("insert into coode_sysresname(".$sqlx.",OPRT)select sysid,'tabx',tabname,tinytitle,now(),now(),md5(RAND()*100000),'pagex' from coode_tiny where sysid='".$sysid."' and tabname!='' and concat(sysid,'tab',tabname) not in (select concat(sysid,restype,rescode) from  coode_sysresname)");
$k=UX("delete from coode_sysresname where sysid='".$sysid."' and restype='tabx' and OPRT='pagex' and rescode not in(select tabname from coode_tiny)");
$z=UX("insert into coode_sysresname(".$sqlx.",OPRT)select sysid,'tabx',TABLE_NAME,tabtitle,now(),now(),md5(RAND()*100000),'tabx' from coode_tablist where sysid='".$sysid."' and concat(sysid,'tabx',TABLE_NAME) not in (select concat(sysid,restype,rescode) from  coode_sysresname)");
$k=UX("delete from coode_sysresname where sysid='".$sysid."' and restype='tabx' and OPRT='tabx' and rescode not in(select TABLE_NAME from coode_tablist)");
//模板审计
$z=UX("insert into coode_sysresname(".$sqlx.",OPRT)select sysid,'tempx',tempid,tinytitle,now(),now(),md5(RAND()*100000),'pagex' from coode_tiny where sysid='".$sysid."' and tempid!='' and concat(sysid,'tempx',tempid) not in (select concat(sysid,restype,rescode) from  coode_sysresname)");
$k=UX("delete from coode_sysresname where sysid='".$sysid."' and restype='tempx' and OPRT='pagex' and rescode not in(select tempid from coode_tiny)");
$z=UX("insert into coode_sysresname(".$sqlx.",OPRT)select sysid,'tempx',dumark,unittitle,now(),now(),md5(RAND()*100000),'tempx' from coode_domainunit where sysid='".$sysid."' and concat(sysid,'tempx',dumark) not in (select concat(sysid,restype,rescode) from  coode_sysresname)");
$k=UX("delete from coode_sysresname where sysid='".$sysid."' and restype='tabx' and OPRT='tempx' and rescode not in(select dumark from coode_domainunit)");
//表单审计
$z=UX("insert into coode_sysresname(".$sqlx.")select sysid,'formx',shortid,tinytitle,now(),now(),md5(RAND()*100000) from coode_tiny where sysid='".$sysid."' and shortid!='' and concat(sysid,'formx',shortid) not in (select concat(sysid,restype,rescode) from  coode_sysresname)");
$k=UX("delete from coode_sysresname where sysid='".$sysid."' and restype='formx' and rescode not in(select shortid from coode_tiny)");
//函数审计
$z=UX("insert into coode_sysresname(".$sqlx.")select '".$sysid."','funx',funname,funcname,now(),now(),md5(RAND()*100000) from coode_funlist where concat('@,',sysid,',') like '%,".$sysid.",%' and concat('".$sysid."','funx',funname) not in (select concat(sysid,restype,rescode) from  coode_sysresname)");
$k=UX("delete from coode_sysresname where sysid='".$sysid."' and restype='funx' and rescode not in(select funname from coode_funlist)");
//分步函数、事务函数、函数集
//类审计
$z=UX("insert into coode_sysresname(".$sqlx.")select sysid,'clsx',funname,funcname,now(),now(),md5(RAND()*100000) from coode_phpcls where sysid='".$sysid."' and concat(sysid,'clsx',funname) not in (select concat(sysid,restype,rescode) from  coode_sysresname)");
$k=UX("delete from coode_sysresname where sysid='".$sysid."' and restype='clsx' and rescode not in(select funname from coode_phpcls)");
//地址审计
$z=UX("insert into coode_sysresname(".$sqlx.")select sysid,'pagex',tinyid,tinytitle,now(),now(),md5(RAND()*100000) from coode_tiny where sysid='".$sysid."' and concat(sysid,'pagex',tinyid) not in (select concat(sysid,restype,rescode) from  coode_sysresname)");
$k=UX("delete from coode_sysresname where sysid='".$sysid."' and restype='pagex' and rescode not in(select tinyid from coode_tiny)");
//静态变量审计，动态变量为临时使用，不固定不长久
$z=UX("insert into coode_sysresname(".$sqlx.")select sysid,'constx',constantid,constanttitle,now(),now(),md5(RAND()*100000) from coode_sysconstant where sysid='".$sysid."' and concat(sysid,'constx',constantid) not in (select concat(sysid,restype,rescode) from  coode_sysresname)");
$k=UX("delete from coode_sysresname where sysid='".$sysid."' and restype='constx' and rescode not in(select constantid from coode_sysconstant)");
//系统参数审计
$z=UX("insert into coode_sysresname(".$sqlx.")select sysid,'configx',syskey,sysktitle,now(),now(),md5(RAND()*100000) from coode_sysconfig where sysid='".$sysid."' and concat(sysid,'configx',syskey) not in (select concat(sysid,restype,rescode) from  coode_sysresname)");
$k=UX("delete from coode_sysresname where sysid='".$sysid."' and restype='configx' and rescode not in(select syskey from coode_sysconfig)");
//小数据空间
$z=UX("insert into coode_sysresname(".$sqlx.")select sysid,'dataspacex',datamark,datatitle,now(),now(),md5(RAND()*100000) from coode_dataspace where sysid='".$sysid."' and concat(sysid,'dataspacex',datamark) not in (select concat(sysid,restype,rescode) from  coode_sysresname)");
$k=UX("delete from coode_sysresname where sysid='".$sysid."' and restype='dataspacex' and rescode not in(select datamark from coode_dataspace)");
//数据方法
$z=UX("insert into coode_sysresname(".$sqlx.")select sysid,'dfunx',dfunmark,dftitle,now(),now(),md5(RAND()*100000) from coode_datafun where sysid='".$sysid."' and concat(sysid,'dfunx',dfunmark) not in (select concat(sysid,restype,rescode) from  coode_sysresname)");
$k=UX("delete from coode_sysresname where sysid='".$sysid."' and restype='dfunx' and rescode not in(select dfunmark from coode_datafun)");
//分布函数
$z=UX("insert into coode_sysresname(".$sqlx.")select sysid,'mfunx',funname,funcname,now(),now(),md5(RAND()*100000) from coode_multifunlist where sysid='".$sysid."' and concat(sysid,'mfunx',funname) not in (select concat(sysid,restype,rescode) from  coode_sysresname)");
$k=UX("delete from coode_sysresname where sysid='".$sysid."' and restype='mfunx' and rescode not in(select funname from coode_multifunlist)");
//事务函数
$z=UX("insert into coode_sysresname(".$sqlx.")select sysid,'afunx',funname,funcname,now(),now(),md5(RAND()*100000) from coode_affairfunlist where sysid='".$sysid."' and concat(sysid,'afunx',funname) not in (select concat(sysid,restype,rescode) from  coode_sysresname)");
$k=UX("delete from coode_sysresname where sysid='".$sysid."' and restype='afunx' and rescode not in(select funname from coode_affairfunlist)");
//资源函数集合--这个下载各个单独资源的时候要单独备份
$z=UX("insert into coode_sysresname(".$sqlx.")select sysid,'sfunx',setname,setcname,now(),now(),md5(RAND()*100000) from coode_funsetfile where concat('/,',sysid,',') like '%,".$sysid."%' and concat(sysid,'sfunx',setname) not in (select concat(sysid,restype,rescode) from  coode_sysresname)");
$k=UX("delete from coode_sysresname where concat('/,',sysid,',') like '%,".$sysid.",%' and restype='sfunx' and rescode not in(select setname from coode_funsetfile)");
//条件跳转
$z=UX("insert into coode_sysresname(".$sqlx.")select sysid,'cdtrdrx',concat(cdtmark,'@',cdtval),rdrpath,now(),now(),md5(RAND()*100000) from coode_cdtrdr where sysid='".$sysid."' and concat(sysid,'cdtrdrx',concat(cdtmark,'@',cdtval)) not in (select concat(sysid,restype,rescode) from  coode_sysresname)");
$k=UX("delete from coode_sysresname where sysid='".$sysid."' and restype='cdtrdrx' and rescode not in(select concat(cdtmark,'@',cdtval) from coode_cdtrdr)");
//参数跳转
$z=UX("insert into coode_sysresname(".$sqlx.")select sysid,'parardrx',paramark,paratitle,now(),now(),md5(RAND()*100000) from coode_parardr where sysid='".$sysid."' and concat(sysid,'parardrx',paramark) not in (select concat(sysid,restype,rescode) from  coode_sysresname)");
$k=UX("delete from coode_sysresname where sysid='".$sysid."' and restype='parardrx' and rescode not in(select paramark from coode_parardr)");
//菜单
$z=UX("insert into coode_sysresname(".$sqlx.")select sysid,'plotx',plotmark,plottitle,now(),now(),md5(RAND()*100000) from coode_plotlist where sysid='".$sysid."' and concat(sysid,'plotx',plotmark) not in (select concat(sysid,restype,rescode) from  coode_sysresname)");
$k=UX("delete from coode_sysresname where sysid='".$sysid."' and restype='plotx' and rescode not in(select plotmark from coode_plotlist)");
//除此以外还有表格内数据，表格函数模板等资源附带的文件，要过问
//远程机想克隆此完整系统则需要清空以前的，模板和短地址的目录要生成.zip的包
$resrst=SX("select restype,rescode,restitle from coode_sysresname where sysid='".$sysid."'");
$frmmd5=md5($resrst);
$totr=countresult($resrst);
$fromhost=$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"];
$itemx='{"restype":"[restype]","rescode":"[rescode]","restitle":"[restitle]"},';
$fmitem="";
$demosrd='{"fromhost":"'.$fromhost.'","sysid":"'.$sysid.'","systitle":"'.$systitle.'","frmver":"'.$frmmd5.'","resitem":[<data>]}';
$ext0=UX("select count(*) as result from coode_clientsysverlist where sysid='".$sysid."' and sysfrmver='".$frmmd5."' and sysvermd5=''");
if (intval($ext0)==0){
  $rmark=getRandChar(8);
  $kk=UX("delete from coode_clientsysverlist where sysvermd5='' and sysid='".$sysid."'");
  $sqlx="fromhost,sysid,systitle,sysfrmver,rndmark,restime,CRTM,UPTM,OLMK";
  $sqly="'".$fromhost."','".$sysid."','".$systitle."','".$frmmd5."','".$rmark."',now(),now(),now(),'".onlymark()."'";
  $zz=UX("insert into coode_clientsysverlist(".$sqlx.")values(".$sqly.")");
}
$sqla="sysid,fromhost,restype,rescode,restitle,sysfrmver,sysrndmark,restime,CRTM,UPTM,OLMK";
for ($j=0;$j<$totr;$j++){
   $itemy=$itemx;
   $rtype=anyvalue($resrst,"restype",$j);
   $rcode=anyvalue($resrst,"rescode",$j);
   $rtitle=anyvalue($resrst,"restitle",$j);
   $itemy=str_replace("[restype]",$rtype,$itemy);
   $itemy=str_replace("[rescode]",$rcode,$itemy);
   $itemy=str_replace("[restitle]",$rtitle,$itemy);
   if (intval($ext0)==0){
     $sqlb="'".$sysid."','".$fromhost."','".$rtype."','".$rcode."','".$rtitle."','".$frmmd5."','".$rmark."',now(),now(),now(),'".onlymark()."'";
     $zzx=UX("insert into coode_clientsysresver(".$sqla.")values(".$sqlb.")");
     $fmitem=$fmitem.$itemy;
    }
}
$fmitem=killlaststr($fmitem);
$demosrd=str_replace("<data>",$fmitem,$demosrd);
$demostr=gohex($demosrd);
echo makereturnjson("1","审计成功","");
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>