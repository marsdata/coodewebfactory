<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sysid=dftval($_GET["sysid"],"");
//除了TAB,SHORT,TEMP其他资源都可以计算版本号，这几个需要分布函数来解决,小数据空间
$sametitle0=UX("update coode_sysresname,coode_tablist set coode_sysresname.restitle=coode_tablist.tabtitle where coode_sysresname.rescode=coode_tablist.TABLE_NAME and coode_sysresname.restype='tab' and coode_sysresname.restitle=''");
$sametitle1=UX("update coode_sysresname,coode_shortdata set coode_sysresname.restitle=coode_shortdata.shorttitle where coode_sysresname.rescode=coode_shortdata.shortid and coode_sysresname.restype='short' and coode_sysresname.restitle=''");
$funver=UX("update coode_sysresname,coode_funlist set coode_sysresname.resmd5=coode_funlist.vermd5 where coode_sysresname.rescode=coode_funlist.funname and coode_sysresname.restype='fun'");
$clsver=UX("update coode_sysresname,coode_phpcls set coode_sysresname.resmd5=coode_phpcls.vermd5 where coode_sysresname.rescode=coode_phpcls.funname and coode_sysresname.restype='cls'");
//系统参数
$cc=UX("update coode_sysconfig set VRT=md5(syskey,sysktitle,sysval) where sysid='".$sysid."'");
$cfgver=UX("update coode_sysresname,coode_sysconfig set coode_sysresname.resmd5=coode_sysconfig.VRT where coode_sysresname.rescode=coode_sysconfig.syskey and coode_sysresname.restype='config'");
//系统静态变量
$cc=UX("update coode_sysconstant set VRT=md5(constantid,constanttitle,constanttype,constantvalue,constvar) where sysid='".$sysid."'");
$cfgver=UX("update coode_sysresname,coode_sysconstant set coode_sysresname.resmd5=coode_sysconstant.VRT where coode_sysresname.rescode=coode_sysconstant.constantid and coode_sysresname.restype='const'");
//条件跳转
$aa=UX("update coode_cdtrdr set VRT=md5(rdrpath,rdrcode) where sysid='".$sysid."'");
$cdtver=UX("update coode_sysresname,coode_cdtrdr set coode_sysresname.resmd5=coode_cdtrdr.VRT where coode_sysresname.rescode=coode_cdtrdr.cdtmark and coode_sysresname.restype='cdtrdr'");
//参数跳转
$aa=UX("update coode_parardr set VRT=md5(paratitle,rdrpath,rdrcode) where sysid='".$sysid."'");
$paraver=UX("update coode_sysresname,coode_parardr set coode_sysresname.resmd5=coode_parardr.VRT where coode_sysresname.rescode=coode_parardr.paramark and coode_sysresname.restype='parardr'");
//数据函数
$aa=UX("update coode_datafun set VRT=md5(dftitle,dfuneval) where sysid='".$sysid."'");
$dfver=UX("update coode_sysresname,coode_datafun set coode_sysresname.resmd5=coode_datafun.VRT where coode_sysresname.rescode=coode_datafun.dfunmark and coode_sysresname.restype='dfun'");
//分布函数
$aa=UX("update coode_multifunlist set vermd5=md5(funcname,funfull) where sysid='".$sysid."'");
$paraver=UX("update coode_sysresname,coode_multifunlist set coode_sysresname.resmd5=coode_multifunlist.vermd5 where coode_sysresname.rescode=coode_multifunlist.funname and coode_sysresname.restype='mfun'");
//事务性函数
$aa=UX("update coode_affairfunlist set vermd5=md5(funcname,funfull) where sysid='".$sysid."'");
$paraver=UX("update coode_sysresname,coode_affairfunlist set coode_sysresname.resmd5=coode_affairfunlist.vermd5 where coode_sysresname.rescode=coode_affairfunlist.funname and coode_sysresname.restype='afun'");
//函数集合
$aa=UX("update coode_funsetfile set vermd5=md5(setcname,funbody) where concat('/,',sysid,',') like '%".$sysid."%'");
$paraver=UX("update coode_sysresname,coode_funsetfile set coode_sysresname.resmd5=coode_funsetfile.vermd5 where coode_sysresname.rescode=coode_funsetfile.setname and coode_sysresname.restype='sfun'");
echo makereturnjson("1","非表格计算版本成功","");
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>