<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $temptype=dftval($_GET["temptype"],"");
$tempmark=dftval($_GET["tempmark"],"");
$tinyid=dftval($_GET["tinyid"],"");
switch($temptype){
  case "face":
   //eval(CLASSX("anawebsrc"));
   //$aw=new anawebsrc();
   //$hcd=array();
   //$hcd=$aw->absorbtounit($tempmark,"index","/FACE/".$tempmark,"",$hcd);
   //$cfiles=$hcd["cssfiles"];
   //$ptc=explode(";",$cfiles);
   //$totc=count($ptc);   
   //for ($n=0;$n<$totc;$n++){
   //     $cpath=combineurl(localroot(),$ptc[$n]);
   //  $fxname=urlfname($cpath);
   //}
   //$jfiles=$hcd["jsfiles"];
   //$ptj=explode(";",$jfiles);
   //$totj=count($ptj);
   //for ($n=0;$n<$totj;$n++){
   //     $jpath=combineurl(localroot(),$ptj[$n]);
   //  $fxname=urlfname($jpath);
   // }  
  $zk=anyfunrun("foldertree","","ddd=/FACE/".$tempmark,"");
  $sqlx="temptype,tempmark,tinymark,sysid,appid,layid,restype,rmark,rtitle,reslocalurl,resrmturl,jsondata,CRTM,UPTM,OLMK,myid,parid";
  $sqly="'face','$tempmark','','','','',filetype,filename,filetitle,filepath,'','',now(),now(),RAND()*10000,myid,parid";
  $zx=UX("insert into coode_resjarset(".$sqlx.")select ".$sqly." from coode_foldertree where parfolder='/FACE/".$tempmark."' and concat('".$temptype.$tempmark.$tinyid."',myid) not in(select concat(temptype,tempmark,tinymark,myid) from coode_resjarset)");  
  $zz=UX("update coode_resjarset set rtitle='模板内依赖文件' where temptype='face' and tempmark='".$tempmark."' and myid=1");
  $z1z=UX("update coode_resjarset set restype='folder' where temptype='face' and tempmark='".$tempmark."' and rmark!='' and restype=''");
  $z2z=UX("update coode_resjarset set rtitle='目录' where temptype='face' and tempmark='".$tempmark."' and rtitle='' and restype='folder'");
  $z2z=UX("update coode_resjarset set rtitle='文件' where temptype='face' and tempmark='".$tempmark."' and rtitle='' and restype!='folder'");
  $km=newtempres($temptype,$tempmark,"temp",'askrequest','方法请求','',$sysid,$appid,$layid,$tinyid,'-1','55');
  $km=newtempres($temptype,$tempmark,"temp",'constval','常量定义','',$sysid,$appid,$layid,$tinyid,'-1','66');
  $km=newtempres($temptype,$tempmark,"temp",'fun','方法定义','',$sysid,$appid,$layid,$tinyid,'-1','77');
  $km=newtempres($temptype,$tempmark,"temp",'tab','关联表格','',$sysid,$appid,$layid,$tinyid,'-1','88');
  $km=newtempres($temptype,$tempmark,"temp",'json','JSON数据','',$sysid,$appid,$layid,$tinyid,'-1','99');
  $b0=UX("update coode_resjarset set resrmturl=reslocalurl where  temptype='temp' and tempmark='".$tempmark."' and resrmturl=''");
  $b1=UX("update coode_resjarset set resrmturl=replace(resrmturl,'".killlaststr(localroot())."','') where  temptype='temp' and tempmark='".$tempmark."'");  
  echo makereturnjson("1","成功","");
  break;
  case "temp":
  $tfolder=qian($tempmark,".");
  $zk=anyfunrun("foldertree","","ddd=/units/".$tfolder,"");
  $sqlx="temptype,tempmark,tinymark,sysid,appid,layid,restype,rmark,rtitle,reslocalurl,resrmturl,jsondata,CRTM,UPTM,OLMK,myid,parid";
  $sqly="'temp','$tempmark','','','','',filetype,filename,filetitle,filepath,'','',now(),now(),RAND()*10000,myid,parid";
  $zx=UX("insert into coode_resjarset(".$sqlx.")select ".$sqly." from coode_foldertree where parfolder='/units/".$tfolder."' and concat('".$temptype.$tempmark.$tinyid."',myid) not in(select concat(temptype,tempmark,tinymark,myid) from coode_resjarset)");  
  $zz=UX("update coode_resjarset set rtitle='模板内依赖文件' where temptype='temp' and tempmark='".$tempmark."' and myid=1");
  $z1z=UX("update coode_resjarset set restype='folder' where temptype='temp' and tempmark='".$tempmark."' and rmark!='' and restype=''");
  $z2z=UX("update coode_resjarset set rtitle='目录' where temptype='temp' and tempmark='".$tempmark."' and rtitle='' and restype='folder'");
  $z2z=UX("update coode_resjarset set rtitle='文件' where temptype='temp' and tempmark='".$tempmark."' and rtitle='' and restype!='folder'");
  $km=newtempres($temptype,$tempmark,"temp",'askrequest','方法请求','',$sysid,$appid,$layid,$tinyid,'-1','55');
  $km=newtempres($temptype,$tempmark,"temp",'constval','常量定义','',$sysid,$appid,$layid,$tinyid,'-1','66');
  $km=newtempres($temptype,$tempmark,"temp",'fun','方法定义','',$sysid,$appid,$layid,$tinyid,'-1','77');
  $km=newtempres($temptype,$tempmark,"temp",'tab','关联表格','',$sysid,$appid,$layid,$tinyid,'-1','88');
  $km=newtempres($temptype,$tempmark,"temp",'json','JSON数据','',$sysid,$appid,$layid,$tinyid,'-1','99');
  $b0=UX("update coode_resjarset set resrmturl=reslocalurl where  temptype='temp' and tempmark='".$tempmark."' and resrmturl=''");
  $b1=UX("update coode_resjarset set resrmturl=replace(resrmturl,'".killlaststr(localroot())."','') where  temptype='temp' and tempmark='".$tempmark."'");
  echo makereturnjson("1","成功","");
  break;
  case "tiny":
  $tfolder=qian($tempmark,".");
  $trst=SX("select sysid,appid,layid from coode_tiny where tinymark='".$tinyid."'");
   $sysid=anyvalue($trst,"sysid",0);
   $appid=anyvalue($trst,"appid",0);
   $layid=anyvalue($trst,"layid",0);
   $tpath="/SYS/".$sysid."/".$appid."/".$layid."/".$tinymark;
  $zk=anyfunrun("foldertree","","ddd=".$tpath,"");
  $sqlx="temptype,tempmark,tinymark,sysid,appid,layid,restype,rmark,rtitle,reslocalurl,resrmturl,jsondata,CRTM,UPTM,OLMK,myid,parid";
  $sqly="'temp','$tempmark','".$tinyid."','','','',filetype,filename,filetitle,filepath,'','',now(),now(),RAND()*10000,myid,parid";
  $zx=UX("insert into coode_resjarset(".$sqlx.")select ".$sqly." from coode_foldertree where parfolder='".$tpath."' and concat('".$temptype.$tempmark.$tinyid."',myid) not in(select concat(temptype,tempmark,tinymark,myid) from coode_resjarset)");  
  $zz=UX("update coode_resjarset set rtitle='模板内依赖文件' where temptype='temp' and tempmark='".$tempmark."' and tinymark='".$tinyid."' and myid=1");
  $z1z=UX("update coode_resjarset set restype='folder' where temptype='temp' and tempmark='".$tempmark."' and tinymark='".$tinyid."' and rmark!='' and restype=''");
  $z2z=UX("update coode_resjarset set rtitle='目录' where temptype='temp' and tempmark='".$tempmark."' and tinymark='".$tinyid."' and rtitle='' and restype='folder'");
  $z2z=UX("update coode_resjarset set rtitle='文件' where temptype='temp' and tempmark='".$tempmark."' and tinymark='".$tinyid."' and rtitle='' and restype!='folder'");
  $km=newtempres($temptype,$tempmark,"temp",'askrequest','方法请求','',$sysid,$appid,$layid,$tinyid,'-1','55');
  $km=newtempres($temptype,$tempmark,"temp",'constval','常量定义','',$sysid,$appid,$layid,$tinyid,'-1','66');
  $km=newtempres($temptype,$tempmark,"temp",'fun','方法定义','',$sysid,$appid,$layid,$tinyid,'-1','77');
  $km=newtempres($temptype,$tempmark,"temp",'tab','关联表格','',$sysid,$appid,$layid,$tinyid,'-1','88');
  $km=newtempres($temptype,$tempmark,"temp",'json','JSON数据','',$sysid,$appid,$layid,$tinyid,'-1','99');
    $b0=UX("update coode_resjarset set resrmturl=reslocalurl where  temptype='temp' and tempmark='".$tempmark."' and tinymark='".$tinyid."'  and resrmturl=''");
  $b1=UX("update coode_resjarset set resrmturl=replace(resrmturl,'".killlaststr(localroot())."','') where  temptype='temp' and tempmark='".$tempmark."'and tinymark='".$tinyid."' ");
  echo makereturnjson("1","成功","");
  break;
  default:
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>