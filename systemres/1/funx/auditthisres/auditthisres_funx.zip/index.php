<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     eval(RESFUNSET("resrelyrp"));
eval(RESFUNSET("tabbaseinfo"));
$restype=dftval($_GET["restype"],"");
$rescode=dftval($_GET["rescode"],"");
$olmkx=dftval($_GET["olmkx"],"");
$a=time();
switch($restype){
  case "funx":
  $frst=SX("select SNO,funfull from coode_funlist where funname='".$rescode."'");
  $datax=anyvalue($frst,"funfull",0);
  $datay=tostring($datax);
  $pteqx=explode("=",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"(");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  
  $pteqx=explode("->",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"(");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  
  $pteqx=explode("CLASSX\"",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"\"");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  $pteqx=explode("RESFUNSET\"",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"\"");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  break;
  case "tabx":
  $strst=SX("select shortid,shorttitle from coode_shortdata where tablename='".$rescode."'");
  $totst=countresult($strst);
  for ($j=0;$j<$totst;$j++){
     $newrls=addsrctores("formx",anyvalue($strst,"shortid",$j),$restype,$rescode);
  }
  $ainfo=array();
  $ainfo=getdbact(glb(),$rescode,$ainfo);
  
  $pteqx=explode("=",$ainfo["bfist"]);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"(");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }  
  $pteqx=explode("=",$ainfo["aftist"]);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"(");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }  
  $pteqx=explode("=",$ainfo["bfupd"]);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"(");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  $pteqx=explode("=",$ainfo["aftupd"]);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"(");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  $pteqx=explode("=",$ainfo["bfdel"]);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"(");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  $pteqx=explode("=",$ainfo["aftdel"]);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"(");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  break;
  case "tempx":
  $rlfc=UX("select relyface as result from coode_domainunit where dumark='".$rescode."'");
  //分析script中的脚本
  if ($rlfc!=""){
    if (strpos($rlfc,";")>0){
      $ptrl=explode(";",$rlfc);
      $totrl=count($ptrl);
      for ($k=0;$k<$totrl;$k++){
        $newrls=addsrctores("csspagex",$ptrl[$k],$restype,$rescode);
      }
    }else{
      $newrls=addsrctores("csspagex",$rlfc,$restype,$rescode);
    }
  }
  break;
  case "clsx":
  $frst=SX("select SNO,funfull from coode_phpcls where funname='".$rescode."'");
  $datax=anyvalue($frst,"funfull",0);
  $datay=tostring($datax);
  $pteqx=explode("=",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"(");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  $pteqx=explode("->",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"(");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  
  $pteqx=explode("CLASSX\"",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"\"");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  $pteqx=explode("RESFUNSET\"",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"\"");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  break;
  case "formx":
  $tbrst=SX("select tablename,caseid,detailid from coode_shortdata where shortid='".$rescode."'");
  //分析script中的脚本 和 关联的tempx
  $tbnmx=anyvalue($tbrst,"tablename",0);
  $caseid=anyvalue($tbrst,"caseid",0);
  $detailid=anyvalue($tbrst,"detailid",0);
  $newrls=addsrctores("tabx",$tbnmx,$restype,$rescode);
  $newrls=addsrctores("tempx",$caseid,$restype,$rescode);
  $newrls=addsrctores("tempx",$detailid,$restype,$rescode);
  break;
  case "sfunx":
  $frst=SX("select SNO,funbody from coode_funsetfile where setname='".$rescode."'");
  $datax=anyvalue($frst,"funbody",0);
  $datay=tostring($datax);
  $pteqx=explode("=",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"(");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  break;
  case "dfunx":
  $frst=SX("select SNO,dfuneval from coode_datafun where dfunmark='".$rescode."'");
  $datax=anyvalue($frst,"dfuneval",0);
  $datay=tostring($datax);
  $pteqx=explode("=",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"(");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
 
  $pteqx=explode("->",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"(");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  
  $pteqx=explode("CLASSX\"",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"\"");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  $pteqx=explode("RESFUNSET\"",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"\"");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  break;
  case "mfunx":
  $frst=SX("select SNO,funfull from coode_multifunlist where funname='".$rescode."'");
  $datax=anyvalue($frst,"funfull",0);
  $datay=tostring($datax);
  $pteqx=explode("=",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"(");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  $pteqx=explode("->",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"(");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  
  $pteqx=explode("CLASSX\"",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"\"");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  $pteqx=explode("RESFUNSET\"",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"\"");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  break;
  case "afunx":
  $frst=SX("select SNO,funfull from coode_affairfunlist where funname='".$rescode."'");
  $datax=anyvalue($frst,"funfull",0);
  $datay=tostring($datax);
  $pteqx=explode("=",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"(");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  
  $pteqx=explode("->",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"(");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  
  $pteqx=explode("CLASSX\"",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"\"");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  $pteqx=explode("RESFUNSET\"",$datay);
  $totpt=count($pteqx);
  for ($jj=0;$jj<$totpt;$jj++){
    $tempx=qian($pteqx[$jj],"\"");
    $jfunx=judgefun($tempx);
    if ($jfunx!=""){
     $newrls=addsrctores(qian($jfunx,"@"),hou($jfunx,"@"),$restype,$rescode);
    }
  }
  break;
  case "pagex":
  $tnrst=SX("select shortid,tabname,tempid from coode_tiny where tinymark='".$rescode."'");
  $shortid=anyvalue($tnrst,"shortid",0);
  $tabname=anyvalue($tnrst,"tabname",0);
  $tempid=anyvalue($tnrst,"tempid",0);
  if ($shortid!=""){
   $newrls=addsrctores("formx",$shortid,$restype,$rescode);
  }
  if ($tabname!=""){
   $newrls=addsrctores("tabx",$tabname,$restype,$rescode);
  }
  if ($tempid!=""){
   $newrls=addsrctores("tempx",$tempid,$restype,$rescode);
  }
  break;
  case "cdtrdrx":
  break;
  case "parardrx":
  break;
  case "constx":
  break;
  case "configx":
  break;
  case "groupx":
  break;
  case "plotx":
  break;
  case "dataspacex":
  break;
  case "sysx":
  $newrls=addsrctores("sysx",$rescode,$restype,$rescode);
  //肯定用的CLASS,SFUN,要加上，TAB FUNX 有些不常用的就不加上
  $ocrst=SX("select SNO,plotmark,markname from coode_grouplist where sysid='".$rescode."'");
  $totoc=countresult($ocrst);
  for ($k=0;$k<$totoc;$k++){
   $newrls=addsrctores("groupx",anyvalue($ocrst,"plotmark",$k),$restype,$rescode);
  }
  $dsrst=SX("select SNO,datamark,datatitle from coode_dataspace where sysid='".$rescode."'");
  $totds=countresult($dsrst);
  for ($k=0;$k<$totds;$k++){
   $newrls=addsrctores("dataspacex",anyvalue($dsrst,"datamark",$k),$restype,$rescode);
  }
  $plrst=SX("select SNO,funname,funcname from coode_phpcls where sysid='".$rescode."'");
  $totpl=countresult($plrst);
  for ($k=0;$k<$totpl;$k++){
   $newrls=addsrctores("clsx",anyvalue($plrst,"funname",$k),$restype,$rescode);
  }
  $fxrst=SX("select SNO,funname,funcname from coode_funlist where sysid='".$rescode."'");
  $totpl=countresult($fxrst);
  for ($k=0;$k<$totpl;$k++){
   $newrls=addsrctores("funx",anyvalue($fxrst,"funname",$k),$restype,$rescode);
  }
  $fxrst=SX("select SNO,funname,funcname from coode_multifunlist where sysid='".$rescode."'");
  $totpl=countresult($fxrst);
  for ($k=0;$k<$totpl;$k++){
   $newrls=addsrctores("mfunx",anyvalue($fxrst,"funname",$k),$restype,$rescode);
  }
  $fxrst=SX("select SNO,funname,funcname from coode_affairfunlist where sysid='".$rescode."'");
  $totpl=countresult($fxrst);
  for ($k=0;$k<$totpl;$k++){
   $newrls=addsrctores("afunx",anyvalue($fxrst,"funname",$k),$restype,$rescode);
  }
  $fxrst=SX("select SNO,dfunmark,dftitle from coode_datafun where sysid='".$rescode."'");
  $totpl=countresult($fxrst);
  for ($k=0;$k<$totpl;$k++){
   $newrls=addsrctores("dfunx",anyvalue($fxrst,"dfunmark",$k),$restype,$rescode);
  }
  $plrst=SX("select SNO,setmark,settitle from coode_funsetfile where sysid='".$rescode."'");
  $totpl=countresult($plrst);
  for ($k=0;$k<$totpl;$k++){
   $newrls=addsrctores("sfunx",anyvalue($plrst,"setmark",$k),$restype,$rescode);
  }
  $plrst=SX("select SNO,plotmark,markname from coode_plotlist where sysid='".$rescode."'");
  $totpl=countresult($plrst);
  for ($k=0;$k<$totpl;$k++){
   $newrls=addsrctores("plotx",anyvalue($plrst,"plotmark",$k),$restype,$rescode);
  }
  $crrst=SX("select SNO,cdtmark,cdtval from coode_cdtrdr where sysid='".$rescode."'");
  $totcr=countresult($crrst);
  for ($k=0;$k<$totcr;$k++){
   $newrls=addsrctores("cdtrdrx",anyvalue($crrst,"cdtmark",$k).".".anyvalue($crrst,"cdtval",$k),$restype,$rescode);
  }
  $prrst=SX("select SNO,paramark,paratitle from coode_parardr where sysid='".$rescode."'");
  $totpr=countresult($prrst);
  for ($k=0;$k<$totpr;$k++){
   $newrls=addsrctores("parardrx",anyvalue($prrst,"paramark",$k),$restype,$rescode);
  }
  $crst=SX("select SNO,syskey from coode_sysconfig where sysid='".$rescode."'");
  $totc=countresult($crst);
  for ($k=0;$k<$totc;$k++){
   $newrls=addsrctores("configx",anyvalue($crst,"syskey",$k),$restype,$rescode);
  }
  $crst=SX("select SNO,constantid from coode_sysconstant where sysid='".$rescode."'");
  $totc=countresult($crst);
  for ($k=0;$k<$totc;$k++){
   $newrls=addsrctores("constx",anyvalue($crst,"constantid",$k),$restype,$rescode);
  }
  //页面也可以确定归属
  $tnrst=SX("select tinymark,shortid,tabname,tempid,appid,layid from coode_tiny where sysid='".$rescode."'");
  $tottn=countresult($tnrst);
  for ($p=0;$p<$tottn;$p++){
   $tinymark=anyvalue($tnrst,"tinymark",$p);
   $shortid=anyvalue($tnrst,"shortid",$p);
   $tabname=anyvalue($tnrst,"tabname",$p);
   $tempid=anyvalue($tnrst,"tempid",$p);
   $appid=anyvalue($tnrst,"appid",$p);
   $layid=anyvalue($tnrst,"layid",$p);
   if ($tinymark!=""){
    $newrls=addsrctores("pagex",$tinymark,$restype,$rescode);
   }
   if ($shortid!=""){
    $newrls=addsrctores("formx",$shortid,$restype,$rescode);
   }
   if ($tabname!=""){
    $newrls=addsrctores("tabx",$tabname,$restype,$rescode);
   }
   if ($tempid!=""){
    $newrls=addsrctores("tempx",$tempid,$restype,$rescode);
   }
   if ($appid!=""){
    $newrls=addsrctores("appx",$appid,$restype,$rescode);
   }
   if ($layid!=""){
    $newrls=addsrctores("layx",$layid,$restype,$rescode);
   }
  }
  break;
  case "appx":
  $tnrst=SX("select tinymark,shortid,tabname,tempid,layid from coode_tiny where appid='".$rescode."'");
  $tottn=countresult($tnrst);
  for ($p=0;$p<$tottn;$p++){
   $tinymark=anyvalue($tnrst,"tinymark",$p);
   $shortid=anyvalue($tnrst,"shortid",$p);
   $tabname=anyvalue($tnrst,"tabname",$p);
   $tempid=anyvalue($tnrst,"tempid",$p);
   $layid=anyvalue($tnrst,"layid",$p);
   if ($tinymark!=""){
    $newrls=addsrctores("pagex",$tinymark,$restype,$rescode);
   }
   if ($shortid!=""){
    $newrls=addsrctores("formx",$shortid,$restype,$rescode);
   }
   if ($tabname!=""){
    $newrls=addsrctores("tabx",$tabname,$restype,$rescode);
   }
   if ($tempid!=""){
    $newrls=addsrctores("tempx",$tempid,$restype,$rescode);
   }
   if ($layid!=""){
    $newrls=addsrctores("layx",$layid,$restype,$rescode);
   }
  }
  break;
  case "layx":
  $tnrst=SX("select tinymark,shortid,tabname,tempid from coode_tiny where layid='".$rescode."'");
  $tottn=countresult($tnrst);
  for ($p=0;$p<$tottn;$p++){
   $tinymark=anyvalue($tnrst,"tinymark",$p);
   $shortid=anyvalue($tnrst,"shortid",$p);
   $tabname=anyvalue($tnrst,"tabname",$p);
   $tempid=anyvalue($tnrst,"tempid",$p);
   if ($tinymark!=""){
    $newrls=addsrctores("pagex",$tinymark,$restype,$rescode);
   }
   if ($shortid!=""){
    $newrls=addsrctores("formx",$shortid,$restype,$rescode);
   }
   if ($tabname!=""){
    $newrls=addsrctores("tabx",$tabname,$restype,$rescode);
   }
   if ($tempid!=""){
    $newrls=addsrctores("tempx",$tempid,$restype,$rescode);
   }
  }
  break;
  case "csspagex":
  break;
  case "iconsetx":
  break;
  case "databasex":
  break;
  default:
}
$b=time();
$zzz=UX("update coode_multitask set STATUS=1 where OLMK='".$olmkx."'");
if ($_GET["ssmark"]!=""){
  $zzz=UX("update coode_multitindex set finished=finished+1 where ssmark='".$_GET["ssmark"]."'");
}
echo makereturnjson("1","生成成功，耗时：".($b-$a)."秒","");
     session_write_close();
?>