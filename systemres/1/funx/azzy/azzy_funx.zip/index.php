<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
         $restype=_get("restype");
    $rescode=_get("rescode");    
  
     $zz=copy_underdir($newpath,$tarpath);
     switch($restype){
       case "pagex":
         $jsonf0=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-resdata.json");
         $uu=takevaljson($jsonf0);
         $jsonf1=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-pagedata.json");
         $uu=takevaljson($jsonf1);
         $jsonf2=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-app.json");
         $uu=takevaljson($jsonf2);
         $jsonf3=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-lay.json");
         $uu=takevaljson($jsonf3);
         $jsonf4=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-temp.json");
         $uu=takevaljson($jsonf4);
       break;
       case "tabx":
       $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $vls=$relydata->vls;
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$jsonf.".json"); 
         $uu=takevaljson($jsonf);
       }
       break;
       case "formx":
       $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $vls=$relydata->vls;
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$jsonf.".json"); 
         $uu=takevaljson($jsonf);
       }
       break;
       case "plotx":
       $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $vls=$relydata->vls;
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$jsonf.".json"); 
         $uu=takevaljson($jsonf);
       }
       break;
       case "groupx":
       $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $vls=$relydata->vls;
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$jsonf.".json"); 
         $uu=takevaljson($jsonf);
       }
       break;
       case "dataspacex":
       $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $vls=$relydata->vls;
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$jsonf.".json"); 
         $uu=takevaljson($jsonf);
       }
       break;
       default:
         $jsonf=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-resdata.json");
         $uu=takevaljson($jsonf);
     }
     if ($restype=="tempx" or $restype=="pagex"){
       $localcss=combineurl(localroot(),"/remotexres/receive/csspagex/");       
       $zz1=copy_underdir($tarpath,$localcss);
       $zxc=deletefiles($localcss,0);
       if ($restype=="pagex"){
         $myurl=combineurl("http://".glw(),"/remotexres/receive/funx/maketinytounit/?tinyid=".$rescode."&newdo=tempx");
         $zz=file_get_contents($myurl);         
       }
     }
     $err="";      
  echo makereturnjson("1","成功安装。".$err,"");
     session_write_close();
?>