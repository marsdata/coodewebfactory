<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     eval(RESFUNSET("tabdataoprt"));
$restype=dftval($_GET["restype"],"");
$resmark=dftval($_GET["resmark"],"");
$rescode=$resmark;
$crtor=dftval($_GET["crtor"],"");
$clientcode=dftval($_GET["clientcode"],"");
$restitle=dftval($_POST["restitle"],"");
$fromhost=dftval($_POST["fromhost"],"");
$hostcode=dftval($_POST["hostcode"],"");
$resurl=dftval($_POST["resurl"],"");
$resver=md5_file($resurl);
$restext=dftval($_POST["restext"],"");
  $aa=createdir(combineurl(localroot(),"/remotexres/respool/".$restype."/".str_replace(".","_",$rescode)."/".$clientcode."/"));
  $resspath=combineurl(localroot(),"/remotexres/respool/".$restype."/".str_replace(".","_",$rescode)."/".$clientcode."/".str_replace(".","_",$rescode)."_".$restype.".zip");  
  $cldurl=combineurl("http://".glw(),"/remotexres/respool/".$restype."/".str_replace(".","_",$rescode)."/".$clientcode."/".str_replace(".","_",$rescode)."_".$restype.".zip");
  $kd=downanyfile($resurl,$resspath);
  if (file_exists($resspath)){
     $qndm=sysconfigval(gln(),"cloudstockhost");
     $qtxt=qnyup(garea(),$resspath);
     $qdata=json_decode($qtxt,false);
     if (intval($qdata->status)==1){
       $kf=unlink($resspath);
       $cldurl=combineurl($qndm,"/remotexres/respool/".$restype."/".str_replace(".","_",$rescode)."/".$clientcode."/".str_replace(".","_",$rescode)."_".$restype.".zip");
     }
   $extx=UX("select count(*) as result from coode_respool where restype='".$restype."' and resmark='".$resmark."' and clientcode='".$clientcode."'");
   if (intval($extx)==0){
    $sqlx="fromhost,clientcode,restype,resmark,vermd5,restitle,pushtime,restext,resurl,thishostpath,thishosturl,CRTM,UPTM,OLMK,CRTOR,PRIME";
    $sqly="'".$fromhost."','".$clientcode."','".$restype."','".$resmark."','".$resver."','".$restitle."',now(),'".$restext."','".$resurl."','".$resspath."','".$cldurl."',now(),now(),'".onlymark()."','".$crtor."',1";
    $zz=UX("insert into coode_respool(".$sqlx.")values(".$sqly.")");   
   }else{
    $zz=UX("update coode_respool set vermd5='".$resmd5."',UPTM=now(),STATUS=1 where restype='".$restype."' and resmark='".$resmark."' and clientcode='".$clientcode."'");
   }   
   //$hostx=hou($fromhost,"://");
   //$zz=anyfunrun("updatefromhost","","fromhost=".$hostx."&restype=".$restype."&rescode=".$resmark,"");
   //上报后不要更新等待查看人预览之后手动更新
   //判断自己是否是区域母站,这个会导致同步更新失败
   //如果是则上传继续上传申请；这是为了防止总站宕机；如果总站宕机，通过其他站点通知各个分站；如果服务器宕机则升级申请失败，状态不变
   
   echo makereturnjson("1","新备份成功",""); 
  }else{
    echo makereturnjson("0","下载失败",""); 
  }
     session_write_close();
?>