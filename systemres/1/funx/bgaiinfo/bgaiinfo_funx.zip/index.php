<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snox=_get("SNO");
$aww=Array();
$erst=SX("select SNO,gname from io_superpeople where SNO=".$snox);
$gname=anyvalue($erst,"gname",0);
$aww[0]="介绍一下周易64卦中的“".$gname."”对应道德经中那几句";
$bktxt=ebot($aww,onlymark(),"bd18841880246");
$zz=UX("update io_superpeople set adescrib='".gohex(str_replace(";",huanhang(),$bktxt))."',STATUS=1,UPTM=now() where SNO=".$snox);
echo makereturnjson("1","获取成功-",$bktxt);
     session_write_close();
?>