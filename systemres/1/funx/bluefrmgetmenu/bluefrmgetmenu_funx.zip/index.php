<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $menumark=dftval($_GET["menumark"],"");
$itemdemo='{isexpand: "false", text: "", children: [<itemitem>]},';
$itemitem='{ "url":"[url]", text: "[title]" },';
$srddemo='var indexdata =[<inner>];';
$fmall="";
if ($menumark!=""){
 $mrst=SX("select myid,mymark from coode_plotdetail where plotmark='".$menumark."' and parid=-1");
 $totm=countresult($mrst);
 for ($m=0;$m<$totm;$m++){
  $ademo=$itemdemo;
  $myid=anyvalue($mrst,"myid",$m);
  $nrst=SX("select myid,mymark,myurl,mytitle from coode_plotdetail where plotmark='".$menumark."' and parid=".$myid);
  $totn=countresult($nrst);
  $fmitem="";
  for ($n=0;$n<$totn;$n++){
    $url=anyvalue($nrst,"myurl",$n);
    $title=anyvalue($nrst,"mytitle",$n);
    $bdemo=$itemitem;
    $bdemo=str_replace("[title]",$title,$bdemo);
    $bdemo=str_replace("[url]",$url,$bdemo);
    $fmitem=$fmitem.$bdemo;
  }//for n
   $fmitem=killlaststr($fmitem);
   $ademo=str_replace("<itemitem>",$fmitem,$ademo);
   $fmall=$fmall.$ademo;
 }//for m
   $fmall=killlaststr($fmall);
   $srddemo=str_replace("<inner>",$fmall,$srddemo);
   $outurl1=combineurl(localroot(),"/FACE/bluefrm/".$menumark.".js");
   $outurl2=combineurl(localroot(),"/units/erpbluefrm/bluefrm/".$menumark.".js");
   overfile($outurl1,$srddemo);
   overfile($outurl2,$srddemo);
   echo $srddemo;
}else{
  $srddemo=str_replace("<inner>","",$srddemo);
  echo $srddemo;
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>