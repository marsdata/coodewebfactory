<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $botcode=_get("botcode");
$btabnm=$botcode."_chara";
$tabsno=_get("tabsno");
$trst=SX("select SNO,dbip,dbuser,dbpass,dbbase,dbtab,reskey,resttk,restitle from aibot_botlist where botcode='".$botcode."'");
$totx=countresult($trst);
  $srck=anyvalue($trst,"reskey",0);
  $srct=anyvalue($trst,"resttk",0);  
  $rxtitle=anyvalue($trst,"restitle",0);  
  $dbip=anyvalue($trst,"dbip",0);  
  $dbuser=anyvalue($trst,"dbuser",0);
  $dbpass=anyvalue($trst,"dbpass",0);
  $dbbase=anyvalue($trst,"dbbase",0);
  $dbtab=anyvalue($trst,"dbtab",0);
$aa=time();
if ($totx>0){
  $typetitle=$rxtitle;
  $conn=mysql_connect($dbip,$dbuser,$dbpass);  
  $drst=selecteds($conn,$dbbase,"select ".$srck.",".$srct." from ".$dbtab." where SNO=".$tabsno,"utf8","");
  $totd=countresult($drst);
  if ($totd>0){    
    $rcode=anyvalue($drst,$srck,0);
    $rtitle=anyvalue($drst,$srct,0);
    $rtitle=str_replace(" ","",$rtitle);
    $ttarr=mb_str_split($rtitle,1,"UTF-8");    
    $tota=count($ttarr);
    $ctabnm=$botcode."_wrdresnmpoints".intval($tabsno/10000);
    $csql=constval("respoints");
    $csql=str_replace("[restab]",$ctabnm,$csql);
    $zz0=crttab(1,$csql);
    for ($a=0;$a<$tota-1;$a++){     
     if ($ttarr[$a]!=""){      
       $sqlx="strnum,typecodex,typetitlex,rescode,restitle,nmstr,SQX,CRTM,UPTM,OLMK,STCODE";
       $sqly="'".$tota."','$botcode','$typetitle','$rcode','$rtitle','".$ttarr[$a].$ttarr[$a+1]."','$a',now(),now(),'".onlymark()."','".$dbtab."'";
       $zz=UZ("insert into ".$ctabnm."(".$sqlx.")values(".$sqly.")");           
     }
    }//for tota
    $bb=time();  
    $conn=mysql_connect($dbip,$dbuser,$dbpass);
    $zzz=updatings($conn,$dbbase,"update ".$dbtab." set STATUS=1 where SNO=".$tabsno,"utf8");
    $conn=mysql_connect($dbip,$dbuser,$dbpass);
    $totx=updatings($conn,$dbbase,"select count(*) as result from ".$dbtab." where STATUS=0","utf8");
    $zzz1=UX("update aibot_botlist set STCODE='".$totx."' where botcode='".$botcode."'");
    echo makereturnjson("1","合成成功，耗时：".($bb-$aa)."秒","");            
  }else{
    echo makereturnjson("0","合成失败",""); 
  }//iftotd
}else{
  echo makereturnjson("0","合成失败","");
}
       session_write_close();
?>