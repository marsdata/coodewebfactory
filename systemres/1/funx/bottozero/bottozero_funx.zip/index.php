<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $botcode=_get("botcode");
$trst=SX("select SNO,dbip,dbuser,dbpass,dbbase,dbtab,reskey,resttk,restitle from aibot_botlist where botcode='".$botcode."'");
   $srck=anyvalue($trst,"reskey",0);
   $srct=anyvalue($trst,"resttk",0);   
   $rxtitle=anyvalue($trst,"restitle",0);   
   $dbip=anyvalue($trst,"dbip",0);   
   $dbuser=anyvalue($trst,"dbuser",0);
   $dbpass=anyvalue($trst,"dbpass",0);
   $dbbase=anyvalue($trst,"dbbase",0);
   $dbtab=anyvalue($trst,"dbtab",0);
$conn=mysql_connect($dbip,$dbuser,$dbpass);   
$zz=updatings($conn,$dbbase,"update ".$dbtab." set STATUS=0","utf8");
$conn=mysql_connect($dbip,$dbuser,$dbpass);   
$totx=updatings($conn,$dbbase,"select count(*) as result from ".$dbtab." where STATUS=0","utf8");
$zz=UX("update aibot_botlist set STCODE=".$totx." where botcode='".$botcode."'");
echo makereturnjson("1","归零成功","");
     session_write_close();
?>