<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       function changename($oldname, $newname)
{
    // 校验1：原文件/目录是否存在（文件/目录均适用）
    if (!file_exists($oldname)) {
        return false;
    }
    // 校验2：新名称路径是否已存在（避免覆盖，保证重命名唯一性）
    if (file_exists($newname)) {
        return false;
    }
    // 核心重命名：PHP内置rename()函数，原生支持文件/目录重命名，跨平台兼容
    return rename($oldname, $newname);
}
$oname=$_GET["oldname"];
$nname=$_GET["newname"];
$lcpath=$_GET["lcpath"];
if (changename(combineurl($lcpath,$oname),combineurl($lcpath,$nname))){
  echo makereturnjson("1","修改成功","");
}else{
  echo makereturnjson("0","修改失败","/localxres/funx/visitpath/?path=".$lcpath);
}
       session_write_close();
?>