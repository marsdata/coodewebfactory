<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $surl=qian(dftval(_post("surl"),""),"?");
$vip=dftval(_post("vip"),"");
$parax=dftval(_post("parax"),"");
$woailiaolan=dftval(_post("woailiaolan"),"");
$wrdid=dftval(_post("wrdid"),"/remotexres/w7x");
$kzm=kuozhanming($surl);
if ($kzm=="php"){
 if ($parax!=""){
   $nurl=$surl."?".str_replace("@:@","&",$parax);
 }else{
   $nurl=$surl;
 }
}else{
 $nurl=$surl;
}
$frst=SX("select SNO,vermd5,cloudpath,filename,filetype,mdftime,STCODE from hjyc_foldertree where idxpath='".$nurl."' and STATUS=1");
$totf=countresult($frst);
if (intval($totf)>0){
  $stcode=anyvalue($frst,"STCODE",0);
  $mdftime=anyvalue($frst,"mdftime",0);
  $filename=anyvalue($frst,"filename",0);
  $filetype=anyvalue($frst,"filetype",0);
  $vermd5=anyvalue($frst,"vermd5",0);
  $cloudpath=anyvalue($frst,"cloudpath",0);
  $rtntxt='{"status":"1","filename":"'.$filename.'","filetype":"'.$filetype.'","msg":"'.$stcode.'","mdftime":"'.$mdftime.'","vermd5":"'.$vermd5.'","url":"'.$cloudpath.'","github":""}';
  $sqlx="askip,askpath,wrdid,asktime,rtntxt,CRTM,UPTM,OLMK,RIP";
  $sqly="'".$vip."','".$nurl."','".$wrdid."',now(),'".gohex($rtntxt)."',now(),now(),'".onlymark()."','".getip()."'";
  $zz=UX("insert into hjyc_askblog(".$sqlx.")values(".$sqly.")");
  echo $rtntxt;
}else{
  $sqla="vermd5,cloudpath,idxpath,filename,filetype,mdftime,filepath,STCODE,CRTM,UPTM,OLMK,CRTOR";
  $sqlb="'newone','".$surl."','".$nurl."','".urlfname($surl)."','".kuozhanming($surl)."',now(),'".$surl."','',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."'";
  $extf=UX("select count(*) as result from hjyc_foldertree where idxpath='".$nurl."'");
  if (intval($extf)==0){
    $zb=UX("insert into hjyc_foldertree(".$sqla.")values(".$sqlb.")");
  }
  $sqlx="askip,askpath,wrdid,asktime,rtntxt,CRTM,UPTM,OLMK,RIP";
  $sqly="'".$vip."','".$nurl."','".$wrdid."',now(),'404',now(),now(),'".onlymark()."','".getip()."'";
  $zz=UX("insert into hjyc_askblog(".$sqlx.")values(".$sqly.")");
  echo '{"status":"0","filename":"","filetype":"","msg":"404","mdftime":"","vermd5":"","url":"","github":""}';
}
     session_write_close();
?>