<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sno=$_GET["SNO"];
$durst=SX("select domainmark,unitmark,sysid,appid,unittitle,unitclass,cssfilex,jsfilex,stylex,scriptx,casecode,templatecode,pagesurround from coode_domainunit where SNO=".$sno);
$dmn=anyvalue($durst,"domainmark",0);
$ccd=tostring(anyvalue($durst,"casecode",0));
$clmk=getRandChar(3);
$newmk=$clmk.$dmn;
$ccd=str_replace($dmn,$newmk,$ccd);
$umk=anyvalue($durst,"unitmark",0);
$ndumk=$newmk.".".$umk;
$sqlx="sysid,appid,unittitle,unitclass,cssfilex,jsfilex,stylex,scriptx,templatecode,pagesurround";
$zb=UX("insert into coode_mydonunit(domainmark,unitmark,".$sqlx.",CRTM,UPTM,CRTOR,OLMK,casecode)select '".$newmk."','".$umk."',".$sqlx.",now(),now(),'"._cookie("uid")."','".onlymark()."','".gohex($ccd)."' from coode_domainunit where SNO=".$sno);
$sqly="domainmark,unitmark,sysid,appid,unittitle,unitclass,cssfilex,jsfilex,stylex,scriptx,casecode,templatecode,pagesurround,CRTM,UPTM,CRTOR,OLMK";
$zc=UX("insert into coode_domainunit(".$sqly.",dumark)select ".$sqly.",'".$ndumk."' from coode_mydonunit where domainmark='".$newmk."' and unitmark='".$umk."'");
$sqlz="sysid,appid,keytype,keydemo,CRTM,UPTM,OLMK";
$sqlb="dumark,domain,mark,sysid,appid,keytype,keydemo,CRTM,UPTM,OLMK";
$zd=UX("insert into coode_mycodedemo(dumark,domain,mark,".$sqlz.")select '".$ndumk."','".$newmk."','".$umk."',".$sqlz." from coode_codedemo where domain='".$dmn."' and mark='".$umk."'");
$ze=UX("insert into coode_codedemo(".$sqlb.")select ".$sqlb." from coode_mycodedemo where dumark='".$ndumk."'");
echo '{"status":"1","msg":"克隆成功","redirect":""}';
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>