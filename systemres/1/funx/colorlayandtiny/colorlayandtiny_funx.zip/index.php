<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sysid=_get("sysid");
$a=time();
$arst=SX("select SNO,appid from coode_appdefault where sysid='".$sysid."'");
$tota=countresult($arst);
for ($c=0;$c<$tota;$c++){
  $snox=anyvalue($arst,"SNO",$c);
  $appid=anyvalue($arst,"appid",$c);
  $cla=UX("select colora as result from coode_colordefine group by colora order by RAND()");  
  $zz=UX("update coode_appdefault set colora='".$cla."' where SNO=".$snox);
  $zzz=UX("update coode_applay set colora='".$cla."' where appid='".$appid."' and sysid='".$sysid."'");
}
$layrst=SX("select SNO,layid,colora from coode_applay where sysid='".$sysid."'");
$totlay=countresult($layrst);
for ($a=0;$a<$totlay;$a++){
  $snox=anyvalue($layrst,"SNO",$a);
  $layid=anyvalue($layrst,"layid",$a);
  $colora=anyvalue($layrst,"colora",$a);
  $clb=UX("select colorb as result from coode_colordefine where colora='".$colora."' order by RAND()");
   $ZZ=UX("update coode_applay set colorb='".$clb."' where SNO=".$snox);
   $ZZ=UX("update coode_tiny set colora='".$colora."' where layid='".$layid."' and sysid='".$sysid."'");
}
$tnrst=SX("select SNO,tinymark,colora from coode_tiny where sysid='".$sysid."'");
$tottn=countresult($tnrst);
for ($a=0;$a<$tottn;$a++){
  $snox=anyvalue($tnrst,"SNO",$a);  
  $colora=anyvalue($tnrst,"colora",$a);
  $clb=UX("select colorb as result from coode_colordefine where colora='".$colora."' order by RAND()");
  $ZZ=UX("update coode_tiny set colorb='".$clb."' where SNO=".$snox);
}
$b=time();
echo makereturnjson("1","成功",($b-$a));
     session_write_close();
?>