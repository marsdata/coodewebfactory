<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $pagemark=$_GET["pagemark"];
$srccls=$_GET["srccls"];
$srcstr=str_replace("()","",$_GET["srcstr"]);
//$conn=mysql_connect(gl(),glu(),glp());
if ($srccls!="pagesno"){
 $exts=intval(UX("select count(*) as result from coode_pagesrc where sourceid='".$srcstr."' and pagemark='".$pagemark."' and sourcecls='".$srccls."'"));
}else{
 $exts=0;
}
if ($exts*1==0){
  switch($srccls){
  case "fun":
  $extfs=intval(UX("select count(*) as result from coode_funlist where funname='".$srcstr."()' and date(now())<>date(CRTM) "))*1;
    if ($extfs==1 ){//存在历史方法
      $nx=UX("insert into coode_pagesrc(pagemark,sourceid,sourcecls,sysid,appid,classa,classb,CRTM,UPTM,CRTOR,RIP,OLMK,PRIME)select pagemark,'".$srcstr."','".$srccls."',sysid,appid,classa,classb,now(),now(),'".$_COOKIE["uid"]."','".getip()."','".onlymark()."',100 from coode_pageidx where pagemark='".$pagemark."' "); 
      $uxx=UX("update coode_pagesrc,coode_funlist set coode_pagesrc.starttime=coode_funlist.CRTM,coode_pagesrc.endtime=coode_funlist.UPTM where concat(coode_pagesrc.sourceid,'()')=coode_funlist.funname and coode_pagesrc.sourceid='".$srcstr."'");
    }else{
      $nx=UX("insert into coode_pagesrc(pagemark,sourceid,sourcecls,sysid,appid,classa,classb,CRTM,UPTM,CRTOR,RIP,OLMK,PRIME,starttime,endtime)select pagemark,'".$srcstr."','".$srccls."',sysid,appid,classa,classb,now(),now(),'".$_COOKIE["uid"]."','".getip()."','".onlymark()."',50,now(),now() from coode_pageidx where pagemark='".$pagemark."' "); 
    };
    $XX=UX("insert into coode_pagedevelop(partmark,sysid,appid,classa,classb,newaction,newstr,newtime,accstate,pagetxt,CRTM,UPTM,CRTOR,OLMK,RIP)select pagemark,sysid,appid,classa,classb,'COMBINEFUN-".$srcstr."','关联函数".$srcstr."',now(),1,'',now(),now(),'".$_COOKIE["uid"]."',RAND()*100000000,'".getip()."' from coode_pageidx where pagemark='".$pagemark."'");
  break;
  case "table":
  $actx=array();
  $actx[0]="bfist";
  $actx[1]="aftist";
  $actx[2]="bfupd";
  $actx[3]="aftupd";
  $actx[4]="bfdel";
  $actx[5]="aftdel";
  $nx=UX("insert into coode_pagesrc(pagemark,sourceid,sourcecls,sysid,appid,classa,classb,CRTM,UPTM,CRTOR,RIP,OLMK,PRIME)select pagemark,'".$srcstr."','".$srccls."',sysid,appid,classa,classb,now(),now(),'".$_COOKIE["uid"]."','".getip()."','".onlymark()."',100 from coode_pageidx where pagemark='".$pagemark."' "); 
  $uxx=UX("update coode_pagesrc,coode_tablist set coode_pagesrc.starttime=coode_tablist.CRTM,coode_pagesrc.endtime=coode_tablist.UPTM where coode_pagesrc.sourceid=coode_tablist.TABLE_NAME and coode_pagesrc.sourceid='".$srcstr."'");
  $XX=UX("insert into coode_pagedevelop(partmark,sysid,appid,classa,classb,newaction,newstr,newtime,accstate,pagetxt,CRTM,UPTM,CRTOR,OLMK,RIP)select pagemark,sysid,appid,classa,classb,'COMBINETABLE-".$srcstr."','关联表格".$srcstr."',now(),1,'',now(),now(),'".$_COOKIE["uid"]."',RAND()*100000000,'".getip()."' from coode_pageidx where pagemark='".$pagemark."'");
   for ($a=0;$a<6;$a++){
    $nx=UX("insert into coode_pagesrc(pagemark,sourceid,sourcecls,sysid,appid,classa,classb,CRTM,UPTM,CRTOR,RIP,OLMK,PRIME,starttime,endtime)select pagemark,'".$actx[$a]."@".$srcstr.".SNO','function',sysid,appid,classa,classb,now(),now(),'".$_COOKIE["uid"]."','".getip()."','".onlymark()."',100,now(),now() from coode_pageidx where pagemark='".$pagemark."' "); 
    $uxx=UX("update coode_pagesrc,coode_tablist set coode_pagesrc.starttime=coode_tablist.CRTM,coode_pagesrc.endtime=coode_tablist.UPTM where coode_pagesrc.sourceid=coode_tablist.TABLE_NAME and coode_pagesrc.sourceid='".$actx[$a]."@".$srcstr.".SNO'");
    $XX=UX("insert into coode_pagedevelop(partmark,sysid,appid,classa,classb,newaction,newstr,newtime,accstate,pagetxt,CRTM,UPTM,CRTOR,OLMK,RIP)select pagemark,sysid,appid,classa,classb,'COMBINETABFUN-".$actx[$a]."@".$srcstr."','关联表格的响应方法".$actx[$a]."@".$srcstr."',now(),1,'',now(),now(),'".$_COOKIE["uid"]."',RAND()*100000000,'".getip()."' from coode_pageidx where pagemark='".$pagemark."'");
   }
  break;
  case "short":
  $nx=UX("insert into coode_pagesrc(pagemark,sourceid,sourcecls,sysid,appid,classa,classb,CRTM,UPTM,CRTOR,RIP,OLMK,PRIME)select pagemark,'".$srcstr."','".$srccls."',sysid,appid,classa,classb,now(),now(),'".$_COOKIE["uid"]."','".getip()."','".onlymark()."',100 from coode_pageidx where pagemark='".$pagemark."' "); 
  $uxx=UX("update coode_pagesrc,coode_tablist set coode_pagesrc.starttime=coode_shortdata.CRTM,coode_pagesrc.endtime=coode_shortdata.UPTM where coode_pagesrc.sourceid=coode_shortdata.shortid and coode_pagesrc.sourceid='".$srcstr."'");
  $XX=UX("insert into coode_pagedevelop(partmark,sysid,appid,classa,classb,newaction,newstr,newtime,accstate,pagetxt,CRTM,UPTM,CRTOR,OLMK,RIP)select pagemark,sysid,appid,classa,classb,'COMBINESHORT-".$srcstr."','关联短数据".$srcstr."',now(),1,'',now(),now(),'".$_COOKIE["uid"]."',RAND()*100000000,'".getip()."' from coode_pageidx where pagemark='".$pagemark."'");
  break;
  case "pagesno":
  $nx=UX("insert into coode_pagesrc(pagemark,sourceid,sourcecls,sysid,appid,classa,classb,CRTM,UPTM,CRTOR,RIP,OLMK,PRIME)select pagemark,'".$srcstr."','".$srccls."',sysid,appid,classa,classb,now(),now(),'".$_COOKIE["uid"]."','".getip()."','".onlymark()."',100 from coode_pageidx where pagemark='".$pagemark."' "); 
  $uxx=UX("update coode_pagesrc,coode_compage set coode_pagesrc.starttime=coode_compage.CRTM,coode_pagesrc.endtime=coode_compage.UPTM where coode_pagesrc.sourceid=coode_compage.SNO and coode_pagesrc.sourceid='".$srcstr."'");
  $XX=UX("insert into coode_pagedevelop(partmark,sysid,appid,classa,classb,newaction,newstr,newtime,accstate,pagetxt,CRTM,UPTM,CRTOR,OLMK,RIP)select pagemark,sysid,appid,classa,classb,'COMBINEPSNO-".$srcstr."','关联静态页ID".$srcstr."',now(),1,'',now(),now(),'".$_COOKIE["uid"]."',RAND()*100000000,'".getip()."' from coode_pageidx where pagemark='".$pagemark."'");
  $pagerst=SX("select pageid,pagemark,outpath from coode_compage where SNO=".$srcstr);
  $totp=countresult($pagerst);
  if ($pagerst>0){
    $outpath=anyvalue($pagerst,"outpath",0);
    $pmark=anyvalue($pagerst,"pagemark",0);
    $pmid=anyvalue($pagerst,"pageid",0);
    $nx=UX("insert into coode_pagesrc(pagemark,sourceid,sourcecls,sysid,appid,classa,classb,CRTM,UPTM,CRTOR,RIP,OLMK,PRIME)select pagemark,'".$outpath."','html',sysid,appid,classa,classb,now(),now(),'".$_COOKIE["uid"]."','".getip()."','".onlymark()."',100 from coode_pageidx where pagemark='".$pagemark."' "); 
    $uxx=UX("update coode_pagesrc,coode_compage set coode_pagesrc.starttime=coode_compage.CRTM,coode_pagesrc.endtime=coode_compage.UPTM where coode_pagesrc.sourceid=coode_compage.outpath and coode_pagesrc.sourceid='".$outpath."'");
    $XX=UX("insert into coode_pagedevelop(partmark,sysid,appid,classa,classb,newaction,newstr,newtime,accstate,pagetxt,CRTM,UPTM,CRTOR,OLMK,RIP)select pagemark,sysid,appid,classa,classb,'COMBINEHTML-".$outpath."','关联静态页:".$pmark."-".$pmid."',now(),1,'',now(),now(),'".$_COOKIE["uid"]."',RAND()*100000000,'".getip()."' from coode_pageidx where pagemark='".$pagemark."'");
    if ($outpath!=""){
      if (file_exists($outpath)){
        eval(CLASSX("htmlchange"));
        $hc=new htmlchange();
        $hstrc=$hc->fmframe($hstrc,file_get_contents($outpath),"LOVE");
        for ($i=0;$i<$hstrc["num"]["totscpurl"];$i++){
         $nx=UX("insert into coode_pagesrc(pagemark,sourceid,sourcecls,sysid,appid,classa,classb,CRTM,UPTM,CRTOR,RIP,OLMK,PRIME,STCODE)select pagemark,'".$hstrc["jsurl"][$i]."','.js',sysid,appid,classa,classb,now(),now(),'".$_COOKIE["uid"]."','".getip()."','".onlymark()."',100,'".$outpath."' from coode_pageidx where pagemark='".$pagemark."' "); 
         $XX=UX("insert into coode_pagedevelop(partmark,sysid,appid,classa,classb,newaction,newstr,newtime,accstate,pagetxt,CRTM,UPTM,CRTOR,OLMK,RIP)select pagemark,sysid,appid,classa,classb,'COMBINEJS-".$hstrc["jsurl"][$i]."','关联静态页的js文件".$hstrc["jsurl"][$i]."',now(),1,'',now(),now(),'".$_COOKIE["uid"]."',RAND()*100000000,'".getip()."' from coode_pageidx where pagemark='".$pagemark."'");
        }
        for ($i=0;$i<$hstrc["num"]["totcssurl"];$i++){
         $nx=UX("insert into coode_pagesrc(pagemark,sourceid,sourcecls,sysid,appid,classa,classb,CRTM,UPTM,CRTOR,RIP,OLMK,PRIME,STCODE)select pagemark,'".$hstrc["cssurl"][$i]."','.css',sysid,appid,classa,classb,now(),now(),'".$_COOKIE["uid"]."','".getip()."','".onlymark()."',100,'".$outpath."' from coode_pageidx where pagemark='".$pagemark."' "); 
         $XX=UX("insert into coode_pagedevelop(partmark,sysid,appid,classa,classb,newaction,newstr,newtime,accstate,pagetxt,CRTM,UPTM,CRTOR,OLMK,RIP)select pagemark,sysid,appid,classa,classb,'COMBINEJS-".$hstrc["cssurl"][$i]."','关联静态页的css文件".$hstrc["cssurl"][$i]."',now(),1,'',now(),now(),'".$_COOKIE["uid"]."',RAND()*100000000,'".getip()."' from coode_pageidx where pagemark='".$pagemark."'");
        }
        for ($i=0;$i<$hstrc["num"]["totimgurl"];$i++){        
         $preurl=$struc["imgurl"][$i];
         $parurl=$struc["imglc"][$i];
         if (isx1($parurl,"PARURL-")){
          $paru=hou($parurl,"PARURL-");
         }else{
          $paru=$outpath;
         };
         $nx=UX("insert into coode_pagesrc(pagemark,sourceid,sourcecls,sysid,appid,classa,classb,CRTM,UPTM,CRTOR,RIP,OLMK,PRIME,STCODE)select pagemark,'".$preurl."','.img',sysid,appid,classa,classb,now(),now(),'".$_COOKIE["uid"]."','".getip()."','".onlymark()."',100,'".$paru."' from coode_pageidx where pagemark='".$pagemark."' "); 
         $XX=UX("insert into coode_pagedevelop(partmark,sysid,appid,classa,classb,newaction,newstr,newtime,accstate,pagetxt,CRTM,UPTM,CRTOR,OLMK,RIP)select pagemark,sysid,appid,classa,classb,'COMBINEIMG-".$preurl."','关联静态页涉及的图像文件".$preurl."',now(),1,'',now(),now(),'".$_COOKIE["uid"]."',RAND()*100000000,'".getip()."' from coode_pageidx where pagemark='".$pagemark."'");
        }
      }
    }
  }    
  break;
  default:  
  }
  $xyz=UX("update coode_pagesrc,coode_tiny set coode_pagesrc.pagetitle=coode_tiny.tinytitle where coode_pagesrc.pagemark=coode_tiny.tinymark");
  $xyz=UX("update coode_pagesrc,coode_funlist set coode_pagesrc.sourcetitle=coode_funlist.funcname where (concat(coode_pagesrc.sourceid,'()')=coode_funlist.funname or coode_pagesrc.sourceid=coode_funlist.funname) and coode_pagesrc.sourcecls='fun'");
  $xyz=UX("update coode_pagesrc,coode_tablist set coode_pagesrc.sourcetitle=coode_tablist.tabtitle where  coode_pagesrc.sourceid=coode_tablist.TABLE_NAME and coode_pagesrc.sourcecls='table'");
  echo "1";
}else{
  echo "0";
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>