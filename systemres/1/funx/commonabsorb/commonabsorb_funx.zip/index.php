<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tbnm=$_GET["tbnm"];
$edittxt=$_POST["edittxt"];
eval(CLASSX("webmark"));
$wm=new webmark();
$vm=$wm->marks($vm,$edittxt,"/");
$tbtt=$vm["tabletitle"];
$splstr=$vm["splitstr"];
$cdata=unstrs($_POST["cdata"]);
if ($splstr==""){
  $cdata=str_replace(huanhang(),";",$cdata);
  $cdata=str_replace(tabstr(),",",$cdata);
  if (strpos($cdata,";")>0){
   $first=qian($cdata);
   $ptpk=explode(",",$first);
   $totpk=count($ptpk);
   $ptpp=explode(";",$first);
   $totpp=count($ptpp)-1;
  }else{
   $first=$cdata;
   $ptpk=explode(",",$first);
   $totpk=count($ptpk);
   $totpp=0;
  }
  if ($totpp>0){
   eval(CLASSX("hugedata"));
   $hd=new hugedata();
   $dd=$hd -> hugeoperate($dd,$cdata);
  }
  $bfirst=str_replace(",","",$first);
  $fmknm="";
  $fmktt="";
  $fmktp="";
  $fmklen="";
  $fmkstt="";
   eval(CLASSX("pinyin"));
   $py=new pinyin();
   $cfirst=strtoupper($py->utf8_to($bfirst,false));
   if (strtoupper($bfirst)==$cfirst){//是纯英文 不带点
     for ($i=0;$i<$totpk;$i++){
        if (isen($ptpk[$i])){
         $fmknm=$fmknm.$ptpk[$i].",";         
        }else{
         $fmknm=$fmknm.getRandChar(5).",";         
        }
        $fmkstt=$fmkstt."1,";
        $fmktt=$fmktt."".",";      
      }   
    if ($totpp>0){
       for ($i=0;$i<$totpk;$i++){     
         $fmktp=$fmktp.$dd["typename"][$i].",";      
         $fmklen=$fmklen.str_replace(")","",str_replace("(","",$dd["typelen"][$i])).",";      
       }      
    }else{
       for ($i=0;$i<$totpk;$i++){     
         $fmktp=$fmktp."varchar,";      
         $fmklen=$fmklen."255,";      
       }
    }
  }else{//是中文或杂文进一步判断
     for ($i=0;$i<$totpk;$i++){
      if (ischi($ptpk[$i])==1){
       $fmknm=$fmknm.$py->utf8_to($ptpk[$i],false).",";
      }else{
       $fmknm=$fmknm.getRandChar(5).",";
      }
      $fmktt=$fmktt.$ptpk[$i].",";      
    }  
    if ($totpp>0){
       for ($i=0;$i<$totpk;$i++){     
         $fmktp=$fmktp.$dd["typename"][$i].",";      
         $fmklen=$fmklen.str_replace(")","",str_replace("(","",$dd["typelen"][$i])).",";      
       }      
    }else{
       for ($i=0;$i<$totpk;$i++){     
         $fmktp=$fmktp."varchar,";      
         $fmklen=$fmklen."255,";      
       }
    }
  }//中文
}else{
 //tabletitle:/splitstr:/keyleft:/keyright:/colleft:/colright:/titleleft:/titleright:/lenleft:/lenright:/typeleft:/typeright:/
  $ptcd=explode($splstr,$cdata);
  $totpt=count($ptcd);
  for ($i=1;$i<$totpt;$i++){    
   if (strpos($ptcd[$i],$vm["titleleft"])>0){
     $kt=qian(hou($ptcd[$i],$vm["titleleft"]),$vm["titleright"]);
   }else{
     $kt="";
   }
   if (strpos($ptcd[$i],$vm["keyleft"])>0){
     $df=qian(hou($ptcd[$i],$vm["keyleft"]),$vm["keyright"]);
   }else{
    if (strpos($ptcd[$i],$vm["colleft"])>0){
     $df=qian(hou($ptcd[$i],$vm["colleft"]),$vm["colright"]);
    }else{
      $df="";
    }
   }
   if (strpos($ptcd[$i],$vm["lenleft"])>0){
     $dl=qian(hou($ptcd[$i],$vm["lenleft"]),$vm["lenright"]);
   }else{
     $dl="100";
   }
   if (strpos($ptcd[$i],$vm["typeleft"])>0){
     $tp=qian(hou($ptcd[$i],$vm["typeleft"]),$vm["typeright"]);
   }else{
     $tp="varchar";
   }
   if ($df!=""){
     $fmknm=$fmknm.$df.",";
     $fmktt=$fmktt.$kt.",";
     $fmktp=$fmktp.$tp.",";
     $fmklen=$fmklen.$dl.",";
   }
  }//for
}
echo "tbnm=".$tbnm."&tbtt=".$tbtt."&fmknm=".$fmknm."&fmktt=".$fmktt."&fmktp=".$fmktp."&fmklen=".$fmklen."&fmkstt=".$fmkstt;
//echo anyfunrun("rcvtborg",_get("appid"),"","tbnm=".$tbnm."&tbtt=".$tbtt."&fmknm=".$fmknm."&fmktt=".$fmktt."&fmktp=".$fmktp."&fmklen=".$fmklen."&fmkstt=".$fmkstt);
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>