<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $firsttt="表格";
$firsturl="totb()";
$secondtt="表单";
$secondurl="uptb()";
$thirdtt="响应";
$thirdurl="toxy()";
$fourthtt="展示";
$fourthurl="tozs()";
$rtn='<div>
    <svg width="0" height="0">
        <defs>
            <filter id="goo">
                <feGaussianBlur in="SourceGraphic" stdDeviation="10" result="blur"></feGaussianBlur>
                <feColorMatrix in="blur" mode="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 19 -9" result="goo"></feColorMatrix>
                <feComposite in="SourceGraphic" in2="goo" operator="atop"></feComposite>
            </filter>
        </defs>
    </svg>
    <div class="aside-nav bounceInUp animated" id="aside-nav">
        <center><label for="" class="aside-menu" title="按住拖动">●</label><>/center>
        <a href="javascript:void(0);" title="'.$firsttt.'" onclick="'.$firsturl.'" class="menu-item menu-first">'.$firsttt.'</a>
        <a href="javascript:void(0);" title="'.$secondtt.'" onclick="'.$secondurl.'" class="menu-item menu-second">'.$secondtt.'</a>
        <a href="javascript:void(0);" title="'.$thirdtt.'" onclick="'.$thirdurl.'" class="menu-item menu-third">'.$thirdtt.'</a>
        <a href="javascript:void(0);" title="'.$fourthtt.'" onclick="'.$fourthurl.'" class="menu-item menu-line menu-fourth">'.$fourthtt.'</a> 
    </div>
</div>';
echo $rtn;
     session_write_close();
?>