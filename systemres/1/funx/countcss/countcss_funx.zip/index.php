<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tempid=$_GET["tempid"];
$a=time();
$kkk=UX("update coode_domainunit set STATUS=1 where dumark='".$tempid."'");
$trst=SX("select sysid,unittitle,relyface,cssfilex,jsfilex  from coode_domainunit where dumark='".$tempid."'");
 $sysid=anyvalue($trst,"sysid",0);
 $utitle=anyvalue($trst,"unittitle",0);
 $rface=anyvalue($trst,"relyface",0);
 $cfiles=anyvalue($trst,"cssfilex",0);
 $jfiles=anyvalue($trst,"jsfilex",0);
 $fmfxid="";
 if (strpos($cfiles,";")>0){
   $ptcss=explode(";",$cfiles);
   for ($jj=0;$jj<count($ptcss);$jj++){
    if (strpos($ptcss[$jj],"csspagex/")>0){
     $fxid=hou(qian($ptcss[$jj],"/css"),"csspagex/");
     $fmfxid=$fmfxid.$fxid.";";
    }   
   }
 }else{
   if (strpos($cfilex,"csspagex/")>0){
     $fxid=hou(qian($cfilex,"/css"),"csspagex/");
     $fmfxid=$fmfxid.$fxid.";";
   }
 }
 if (strpos($jfiles,";")>0){
   $ptjs=explode(";",$jfiles);
   for ($jj=0;$jj<count($ptjs);$jj++){
    if (strpos($ptjs[$jj],"csspagex/")>0){
     $fxid=hou(qian($ptjs[$jj],"/js"),"csspagex/");
     $fmfxid=$fmfxid.$fxid.";";
    }   
   }
 }else{
   if (strpos($cfilex,"csspagex/")>0){
     $fxid=hou(qian($cfilex,"/css"),"csspagex/");
     $fmfxid=$fmfxid.$fxid.";";
   }
 }
 $nn=UX("update coode_domainunit set relyface='".killlaststr($fmfxid)."' where dumark='".$tempid."'");
 $extx=UX("select count(*) as result from coode_facelist where ';;".$fmfxid.";' like concat('%;',faceid,';%')");
if ($extx>=1){
  $zz1=UX("update coode_facelist set sysid='".$sysid."',PRIME=PRIME+1 where ';;".$fmfxid.";' like concat('%;',faceid,';%')");  
  $zz2=UX("update coode_facelist set facetitle='".$utitle."' where ';;".$fmfxid.";' like concat('%;',faceid,';%') and (facetitle='' or facetitle like '/localxres/%')");  
  $b=time();
  echo makereturnjson("1","分析成功--耗时".($b-$a)."秒","");
}else{
  $b=time();
  echo makereturnjson("1","分析成功--耗时".($b-$a)."秒,不存在","");
}
 
     session_write_close();
?>