<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $srctype=$_GET["srctype"];
$srcid=$_GET["srcid"];
$lang=$_GET["lang"];
$srctitle=$_GET["srctitle"];
$pub=$_GET["pub"];
$msgx="";
if ($srctype!="" and $srcid!="" and $srctitle!=""){
  switch($srctype){
    case "tab":
    if ($pub=="1"){
      $sqlx="imghead,TABLE_NAME,tabtitle,OLMK,CRTOR,CRTM,UPTM";
      $sqly="'','".$srcid."','".$srctitle."','".onlymark()."','".$_COOKIE["uid"]."',now(),now()";
      $sqlz=UX("insert into coode_tablist(".$sqlx.")values(".$sqly.")");      
      $msgx="创建公共表格(".$lang.")";
    }else{
      $sqlx="imghead,TABLE_NAME,tabtitle,OLMK,CRTOR,CRTM,UPTM";
      $sqly="'','".$srcid."','".$srctitle."','".onlymark()."','".$_COOKIE["uid"]."',now(),now()";
      $sqlz=UX("insert into coode_mytablist(".$sqlx.")values(".$sqly.")");
      $msgx="创建个人表格(".$lang.")";
    }
    $conn=mysql_connect(gl(),glu(),glp());
    $zz=updatingx($conn,glb(),"create table ".$srcid." like coode_frmdefault","utf8");
    break;
    case "fun":
    if ($pub=="1"){
     $sqlx="funname,funcname,OLMK,CRTOR,CRTM,UPTM";
     $sqly="'".$srcid."','".$srctitle."','".onlymark()."','".$_COOKIE["uid"]."',now(),now()";
     $sz=UX("insert into coode_funlist(".$sqlx.")values(".$sqly.")");
     $msgx="创建公共函数(".$lang.")";
    }else{
     $sqlx="funname,funcname,OLMK,CRTOR,CRTM,UPTM";
     $sqly="'".$srcid."','".$srctitle."','".onlymark()."','".$_COOKIE["uid"]."',now(),now()";
     $sz=UX("insert into coode_myfun(".$sqlx.")values(".$sqly.")");
     $msgx="创建个人函数(".$lang.")";
    }
    break;
    case "cls":
    if ($pub=="1"){
     $sqlx="funname,funcname,OLMK,CRTOR,CRTM,UPTM";
     $sqly="'".$srcid."','".$srctitle."','".onlymark()."','".$_COOKIE["uid"]."',now(),now()";
     $sz=UX("insert into coode_phpcls(".$sqlx.")values(".$sqly.")");
     $msgx="创建公共模块(".$lang.")";
    }else{
     $sqlx="funname,funcname,OLMK,CRTOR,CRTM,UPTM";
     $sqly="'".$srcid."','".$srctitle."','".onlymark()."','".$_COOKIE["uid"]."',now(),now()";
     $sz=UX("insert into coode_mycls(".$sqlx.")values(".$sqly.")");
     $msgx="创建个人模块(".$lang.")";
    }
    break;
    case "sys":
    if ($pub=="1"){
      $sqlx="sysid,sysname,OLMK,CRTOR,CRTM,UPTM";
      $sqly="'".$srcid."','".$srctitle."','".onlymark()."','".$_COOKIE["uid"]."',now(),now()";
      $sz=UX("insert into coode_sysinformation(".$sqlx.")values(".$sqly.")");
      $msgx="创建公共系统名称(".$lang.")";
    }else{
      $sqlx="sysid,sysname,OLMK,CRTOR,CRTM,UPTM";
      $sqly="'".$srcid."','".$srctitle."','".onlymark()."','".$_COOKIE["uid"]."',now(),now()";
      $sz=UX("insert into coode_mysysi(".$sqlx.")values(".$sqly.")");
      $msgx="创建个人系统名称(".$lang.")";
    }
    break;
    case "app":
    if ($pub=="1"){
      $sqlx="appid,appname,OLMK,CRTOR,CRTM,UPTM";
      $sqly="'".$srcid."','".$srctitle."','".onlymark()."','".$_COOKIE["uid"]."',now(),now()";
      $sz=UX("insert into coode_appdefault(".$sqlx.")values(".$sqly.")");
      $msgx="创建公共应用名称(".$lang.")";
    }else{
      $sqlx="appid,appname,OLMK,CRTOR,CRTM,UPTM";
      $sqly="'".$srcid."','".$srctitle."','".onlymark()."','".$_COOKIE["uid"]."',now(),now()";
      $sz=UX("insert into coode_myappd(".$sqlx.")values(".$sqly.")");
      $msgx="创建个人应用名称(".$lang.")";
    }
    break;
    case "lay":
    if ($pub=="1"){
      $sqlx="layid,laytitle,OLMK,CRTOR,CRTM,UPTM";
      $sqly="'".$srcid."','".$srctitle."','".onlymark()."','".$_COOKIE["uid"]."',now(),now()";
      $sz=UX("insert into coode_applay(".$sqlx.")values(".$sqly.")");
      $msgx="创建公共输出名称(".$lang.")";
    }else{
      $sqlx="appid,appname,OLMK,CRTOR,CRTM,UPTM";
      $sqly="'".$srcid."','".$srctitle."','".onlymark()."','".$_COOKIE["uid"]."',now(),now()";
      $sz=UX("insert into coode_myalay(".$sqlx.")values(".$sqly.")");
      $msgx="创建个人输出名称(".$lang.")";
    }
    break;
    case "plot":
    if ($pub=="1"){
      $sqlx="plotmark,markname,OLMK,CRTOR,CRTM,UPTM";
      $sqly="'".$srcid."','".$srctitle."','".onlymark()."','".$_COOKIE["uid"]."',now(),now()";
      $sz=UX("insert into coode_plotlist(".$sqlx.")values(".$sqly.")");
      $msgx="创建公共节点名称(".$lang.")";
    }else{
      $sqlx="plotmark,markname,OLMK,CRTOR,CRTM,UPTM";
      $sqly="'".$srcid."','".$srctitle."','".onlymark()."','".$_COOKIE["uid"]."',now(),now()";
      $sz=UX("insert into coode_myplot(".$sqlx.")values(".$sqly.")");
      $msgx="创建个人节点名称(".$lang.")";
    }
    break;
    case "tiny":
    if ($pub=="1"){
      $sqlx="tinymark,tinytitle,OLMK,CRTOR,CRTM,UPTM";
      $sqly="'".$srcid."','".$srctitle."','".onlymark()."','".$_COOKIE["uid"]."',now(),now()";
      $sz=UX("insert into coode_tiny(".$sqlx.")values(".$sqly.")");
      $msgx="创建公共短地址(".$lang.")";
    }else{
      $sqlx="tinymark,tinytitle,OLMK,CRTOR,CRTM,UPTM";
      $sqly="'".$srcid."','".$srctitle."','".onlymark()."','".$_COOKIE["uid"]."',now(),now()";
      $sz=UX("insert into coode_tiny(".$sqlx.")values(".$sqly.")");
      $msgx="创建个人短地址(".$lang.")";
    }
    break;
    default:
  }
  echo makereturnjson("1",$msgx."成功","");
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>