<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     eval(RESFUNSET("tabbaseinfo"));
$vbtitle=dftval(_post("vbtitle"),"");
$vbcode=dftval(_post("vbcode"),"");
$iconcode=dftval(_post("iconcode"),"");
$icontitle=dftval(_post("icontitle"),"");
$oneyuannum=dftval(_post("oynum"),"");
$qz=$vbcode;
$btab=array();
$bust="_catbank";
$btab[0]=$bust;
$bwt="_catwtfood";
$btab[1]=$bwt;
$btt="_catfood";
$btab[2]=$btt;
$bwdt="_catwithdrawal";
$btab[3]=$bwdt;
$bcgt="_catcharge";
$btab[4]=$bcgt;
$totb=5;
if ($vbcode!="" and $vbtitle!="" and $iconcode!="" and $icontitle!="" and $oneyuannum!=""){
 $extr=UX("select count(*) as result from visualbank_vbanklist where vbankmark='".$vbcode."'");
 if (intval($extr)==0){
   $sqlx="vbankmark,vbankname,vbankdescrib,bankusertab,bankwaittab,banktradetab,bankwithdtab,bankchagtab,percoinval,perrmbcoins,coinname,bankselfaccount,CRTM,UPTM,OLMK";
   $sqly="'$vbcode','$vbtitle','','$qz.$bust','$qz.$bwt','$qz.$btt','$qz.$bwdt','$qz.$bcgt','".(1/$oneyuannum)."','".$oneyuannum."','".$icontitle."','".$iconcode."',now(),now(),'".onlymark()."'";
   $zz=UX("insert into visualbank_vbanklist(".$sqlx.")values(".$sqly.")");  
 }
 for ($j=0;$j<$totb;$j++){
   if (extdbtab(gl(),glu(),glp(),glb(),$vbcode.$btab[$j])==false){
   }else{
     $conn=mysql_connect(gl(),glu(),glp());
     $bb=updatingx($conn,glb(),"CREATE TABLE ".$vbcode.$btab[$j]." LIKE visualbank".$btab[$j],"utf8");
   }
  }
  echo makereturnjson("1","创建成功","");
 }else{
  echo makereturnjson("0","参数不全","");
 }
     session_write_close();
?>