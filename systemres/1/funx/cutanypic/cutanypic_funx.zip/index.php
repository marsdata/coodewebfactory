<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
       if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
 }
   $purl=$_GET["purl"];
   $yx=$_GET["yx"];
   $yy=$_GET["yy"];
   $mbx=$_GET["mbx"];
   $mby=$_GET["mby"];
   $getyw=$_GET["getyw"];
   $getyh=$_GET["getyh"];
   $tow=$_GET["tow"];
   $toh=$_GET["toh"];
   $nurl=combineurl($gml,$purl);
     $img_info = getimagesize($nurl);
     $ow=$img_info[0];
     $oh=$img_info[1];     
     if (strpos($getyw,"px")>0){
       $gyw=intval(str_replace("","px",$getyw));
     }else{
       $gyw=$ow*floatval($getyw);
     }
    
     if (strpos($getyh,"px")>0){
      $gyh=intval(str_replace("","px",$getyh));
     }else{
      $gyh=$oh*floatval($getyh);
     }
     if ($tow=="sametoaftoriw"){
       $neww=$gyw;
     }else{
       $neww=intval($tow);
     }
     if ($toh=="sametoaftorih"){
       $newh=$gyh;
     }else{
       $newh=intval($toh);
     }
     if (strpos($yx,"px")>0){
      $yxz=intval(str_replace("","px",$yx));
     }else{
       $yxz=floatval($yx)*$ow;
     }
     if (strpos($yy,"px")>0){
      $yyz=intval(str_replace("","px",$yy));
     }else{
       $yyz=floatval($yy)*$ow;
     }
     if (strpos($mbx,"px")>0){
       $mbxz=intval(str_replace("","px",$mbx));
     }else{
       $mbxz=floatval($mbx)*$neww;
     }
     if (strpos($mby,"px")>0){
       $mbyz=intval(str_replace("","px",$mby));
     }else{
       $mbyz=floatval($mby)*$newh;
     }
   $x=compressed_image($nurl,$yxz,$yyz,$mbxz,$mbyz,$neww,$newh,$gyw,$gyh,100);
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>