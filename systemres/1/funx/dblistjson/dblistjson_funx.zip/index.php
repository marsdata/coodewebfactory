<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $listdemo='[{
      "id": 1,
      "title": "本",
      "subs": [<data1>]
   },
   {
      "id": 3,
      "title": "远",
      "subs": [<data2>]
   }
]';
$fmx="";
$fmy="";
$item='{"id": [idx],"title": "[title]"},';
$lcrst=SX("select SNO,dbname,dbmark from coode_dblist where dbip='localhost' and dbtype='MYSQL'");
$totlc=countresult($lcrst);
for ($j=0;$j<$totlc;$j++){
  $snox=(anyvalue($lcrst,"SNO",$k)+100);
  $dbnm=anyvalue($lcrst,"dbname",$j);
  $dbmark=anyvalue($lcrst,"dbmark",$j);
  $itemx=$item;
  $itemx=str_replace("[idx]",$snox,$itemx);
  $itemx=str_replace("[title]",$dbnm."@".$dbmark,$itemx);
  $fmx=$fmx.$itemx;
}
$fmx=killlaststr($fmx);
$lcrst=SX("select SNO,dbname,dbmark from coode_dblist where dbip!='localhost' and dbtype='MYSQL'");
$totlc=countresult($lcrst);
for ($k=0;$k<$totlc;$k++){
  $snox=(anyvalue($lcrst,"SNO",$k)+100);
  $dbnm=anyvalue($lcrst,"dbname",$k);
  $dbmark=anyvalue($lcrst,"dbmark",$k);
  $itemy=$item;
  $itemy=str_replace("[idx]",$snox,$itemy);
  $itemy=str_replace("[title]",$dbnm."@".$dbmark,$itemy);
  $fmy=$fmy.$itemy;
}
$fmy=killlaststr($fmy);
$listdemo=str_replace("<data1>",$fmx,$listdemo);
$listdemo=str_replace("<data2>",$fmy,$listdemo);
echo $listdemo;
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>