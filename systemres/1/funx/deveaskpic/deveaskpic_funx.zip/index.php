<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $evtcode=$_GET["evtcode"];
$pictype=$_GET["pictype"];
$mdf16=$_GET["mdf16"];
 //$b64data=hou(str_replace(" ","+",$_POST["b64data"]),"data:");
 $b64data=str_replace(" ","+",$_POST["b64data"]);
 $path=combineurl(localroot(),"columnx/deveask/".date("Y-m-d")."/");
 is_dir($path) OR mkdir($path, 0777, true);    
 $fpath=b64tofile($b64data,$path,"");
 $furl=str_replace(localroot(),"",$fpath);
 $furl=combineurl("/",$furl);
 $sqlx="taskcode,picurl,piclocal,pictype,picmd5,CRTM,UPTM,OLMK";
 $sqly="'".$evtcode."','".$furl."','".$fpath."','".$pictype."','".$mdf16."',now(),now(),'".onlymark()."'";
 $zz=UX("insert into coode_deveaskpics(".$sqlx.")values(".$sqly.")");
 echo '{"status":"1","msg":"提交成功","redirect":""}';
     session_write_close();
?>