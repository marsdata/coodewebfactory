<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $evtcode=$_GET["evtcode"];
$pictype=$_GET["pictype"];
$ext=0;
$picd=unstrs(_post("picd"));
 $ptd=explode(":@:",$picd);
 
 $totpt=count($ptd);
 for ($p=0;$p<$totpt-1;$p++){
   if ($ptd[$p]!="" and $ptd[$p+1]!=""){
      $tsno=qian(hou($ptd[$p],"["),"]");
      $pmd5=qian(hou($ptd[$p],"--"),".");
      $pdes=qian($ptd[$p+1],"[");      
      $zz=UX("update coode_deveaskpics set UPTM=now(),picsno='".$tsno."',picdescrib='".gohex($pdes)."' where picmd5='".$pmd5."'");
   }
 }
 
switch($pictype){
  case "kfsq":
  $rdru="/localxres/pagex/1/humanmachine/wTiayipl/AuVdwF/index.html?rnd=".onlymark();
  break;
  default:
}
 echo '{"status":"1","msg":"提交成功","redirect":"'.$rdru.'"}';
     session_write_close();
?>