<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snox=_get("SNO");
$crst=SX("select restype,rescode,restitle,downurl,vermd5 from coode_cssthis where SNO=".$snox);
$totc=countresult($crst);
if ($totc>0){
  $restype=anyvalue($crst,"restype",0);
  $rescode=anyvalue($crst,"rescode",0);
  $restitle=anyvalue($crst,"restitle",0);
  $vermd5=anyvalue($crst,"vermd5",0);
  $downurl=anyvalue($crst,"downurl",0);
  $savepath=combineurl(localroot(),"/localxres/seedx/".$restype."/".str_replace(".","_",$rescode)."/".str_replace(".","_",$rescode).$vermd5."_".$restype.".zip");
  $zippath=combineurl(localroot(),"/localxres/seedx/".$restype."/".str_replace(".","_",$rescode)."/".$vermd5."/");
  if ($restype=="pagex"){
    $localcss=combineurl(localroot(),"/localxres/".$restype."/seedx/".qian($rescode,".")."/");
  }else{
    $localcss=combineurl(localroot(),"/localxres/".$restype."/".qian($rescode,".")."/");
  }
  if (downanyfile($downurl,$savepath)){
      $zz=unzip($savepath,$zippath);
      $zz1=copy_underdir($zippath,$localcss);
  }else{
      $err="下载资源失败；";
      $tarpath="";
  }
  switch($restype){
    case "csspagex":
    $kvx="facetitle=".$restitle;
    $faceurl="/localxres/csspagex/".$rescode."/index.html";
    $kvx=$kvx."&faceurl=".$faceurl;
    $ox="faceid=".$rescode;
    $nd=newdata("coode_facelist",$kvx,$ox);
    break;
    case "tempx":
    $durl=combineurl(localroot(),"/localxres/".$restype."/".qian($rescode,".")."/".str_replace(".","_",$rescode)."-resdata.json");
    $rdata=file_get_contents($durl);
    $zz=takedata($rdata);
    break;
    case "pagex":
    $durl=combineurl(localroot(),"/localxres/".$restype."/seedx/".$rescode."/".str_replace(".","_",$rescode)."-resdata.json");
    $rdata=file_get_contents($durl);
    $zz=takedata($rdata);
    $nn=anyfunrun("maketinyshow","","tinyid=".$rescode,"");
    break;
    default:
  }
  $zzz=UX("update coode_cssthis set isin=1 where SNO=".$snox);
  echo makereturnjson("1","下载".$restitle."成功","");
}else{
  echo makereturnjson("0","不存在资源","");
}
     session_write_close();
?>