<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snox=_get("SNO");
$rcrst=SX("select SNO,fromhost,pushmark,resid,sysid,restype,vermd5,STATUS from coode_rcvres where SNO='".$snox."'");
$totrc=countresult($rcrst);
if ($totrc>0){  
  $fromhost=anyvalue($rcrst,"fromhost",0);
  $pushmark=anyvalue($rcrst,"pushmark",0);  
  $rcode=anyvalue($rcrst,"resid",0);
  $rtype=anyvalue($rcrst,"restype",0);
  $vmd5=anyvalue($rcrst,"vermd5",0);
  $sysid=anyvalue($rcrst,"sysid",0);
  $stt=anyvalue($rcrst,"STATUS",0);
  echo anyfunrun("installpod","","cloud=".$stt."&sysid=".$sysid."&fromhost=".$fromhost."&restype=".$rtype."&rescode=".$rcode,"");
}else{
  echo makereturnjson("0","不存在资源","");
}
     session_write_close();
?>