<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $furl=$_GET["url"];
$markid=$_GET["markid"];
$fname=$_GET["fname"];
$postdata["s"]="";
$pturl=explode("/",$furl);
$totpt=count($pturl);
$fnm=$pturl[$totpt-1];
if (strpos($fnm,"?")>0){
 $fnm=qian($fnm,"?");
};
$fdm=qian(hou($furl,'//'),'/');
$domain=str_replace(".","_",qian(hou($furl,"//"),"/"));
$urlpath=str_replace($fnm,"",$furl);
$fmnm=str_replace('/','_',hou($furl,$fdm.'/'));
$fmnm=str_replace('.','@',$fmnm);
$fmnm=str_replace('?','-',$fmnm);
$fmnm=str_replace('=','_',$fmnm);
//看网页名称有用
$lcpt=$gml.'FACE/'.$markid;
$lcjs=$gml.'FACE/'.$markid.'/js';
$lccss=$gml.'FACE/'.$markid.'/css';
$lcimg=$gml.'FACE/'.$markid.'/images';
is_dir($lcpt) OR mkdir($lcpt, 0777, true);
is_dir($lcjs) OR mkdir($lcjs, 0777, true);
is_dir($lccss) OR mkdir($lccss, 0777, true);
is_dir($lcimg) OR mkdir($lcimg, 0777, true);
if ($_POST["cdata"]!=""){
  $curldata=unstrs($_POST["cdata"]);
}else{
  $curldata=file_get_contents($furl);
}
//echo $curldata;
if ($curldata!=""){
  $conn=mysql_connect(gl(),glu(),glp());
  $xx=updatings($conn,glb(),"insert into coode_sitefile(outpath,updateurl,CRTM,UPTM,OLMK,CRTOR,filetype)values('".$furl."','/FACE/".$markid."/".$fname.".html',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."',2)","utf8");
 //echo $curldata;
  if (substr($gml,-1)!="/"){
    $gml=$gml."/";
  }
  $strux=fmframe($strux,$curldata,$urlpath,$gml,$markid,$fname,"");
  echo "<a  style=\"color:#fff;\" href=\"http://".glw()."FACE/".$markid."/".$fname.".html\" target=\"about_blank\">下载完成点击预览</a>";
}
//echo $struc["html"]["struc"];

function newtg($tmm,$strun){
$ptp=explode(".",$tmm);
 switch (count($ptp)){
        case 2:
   $tmp0=explode(")0,",$strun);
   $rchd=hou($tmp0[$ptp[0]],"(");
   $ttag=qian($rchd,"(");
   return $ttag;
        break;
        case 3:
   $tmp0=explode(")0,",$strun);
   $tmp1=explode(")1,",hou($tmp0[$ptp[0]],"("));
   $rchd=hou($tmp1[$ptp[1]],"(");
   $ttag=qian($rchd,"(");
   return $ttag;
        break;
        case 4:
   $tmp0=explode(")0,",$strun);
   $tmp1=explode(")1,",hou($tmp0[$ptp[0]],"("));
   $tmp2=explode(")2,",hou($tmp1[$ptp[1]],"("));
   $rchd=hou($tmp2[$ptp[2]],"(");

   $ttag=qian($rchd,"(");
   return $ttag;
        break;
        case 5:
   $tmp0=explode(")0,",$strun);
   $tmp1=explode(")1,",hou("x".$tmp0[$ptp[0]],"("));
   $tmp2=explode(")2,",hou("x".$tmp1[$ptp[1]],"("));
   $tmp3=explode(")3,",hou($tmp2[$ptp[2]],"("));
   $rchd=hou("x".$tmp3[$ptp[3]],"(");
   $ttag=qian($rchd,"(");
   return $ttag;
        break;
        case 6:
   $tmp0=explode(")0,",$strun);
   $tmp1=explode(")1,",hou($tmp0[$ptp[0]],"("));
   $tmp2=explode(")2,",hou($tmp1[$ptp[1]],"("));
   $tmp3=explode(")3,",hou($tmp2[$ptp[2]],"("));
   $tmp4=explode(")4,",hou($tmp3[$ptp[3]],"("));
   $rchd=hou($tmp4[$ptp[4]],"(");
   $ttag=qian($rchd,"(");
   return $ttag;
        break;
        case 7:
   $tmp0=explode(")0,",$strun);
   $tmp1=explode(")1,",hou($tmp0[$ptp[0]],"("));
   $tmp2=explode(")2,",hou($tmp1[$ptp[1]],"("));
   $tmp3=explode(")3,",hou($tmp2[$ptp[2]],"("));
   $tmp4=explode(")4,",hou($tmp3[$ptp[3]],"("));
   $tmp5=explode(")5,",hou($tmp4[$ptp[4]],"("));
   $rchd=hou($tmp5[$ptp[5]],"(");
   $ttag=qian($rchd,"(");
   return $ttag;
        break;
        case 8:
   $tmp0=explode(")0,",$strun);
   $tmp1=explode(")1,",hou($tmp0[$ptp[0]],"("));
   $tmp2=explode(")2,",hou($tmp1[$ptp[1]],"("));
   $tmp3=explode(")3,",hou($tmp2[$ptp[2]],"("));
   $tmp4=explode(")4,",hou($tmp3[$ptp[3]],"("));
   $tmp5=explode(")5,",hou($tmp4[$ptp[4]],"("));
   $tmp6=explode(")6,",hou($tmp5[$ptp[5]],"("));
   $rchd=hou($tmp6[$ptp[6]],"(");
   $ttag=qian($rchd,"(");
   return $ttag;
        break;
        case 9:
   $tmp0=explode(")0,",$strun);
   $tmp1=explode(")1,",hou($tmp0[$ptp[0]],"("));
   $tmp2=explode(")2,",hou($tmp1[$ptp[1]],"("));
   $tmp3=explode(")3,",hou($tmp2[$ptp[2]],"("));
   $tmp4=explode(")4,",hou($tmp3[$ptp[3]],"("));
   $tmp5=explode(")5,",hou($tmp4[$ptp[4]],"("));
   $tmp6=explode(")6,",hou($tmp5[$ptp[5]],"("));
   $tmp7=explode(")7,",hou($tmp6[$ptp[6]],"("));
   $rchd=hou($tmp7[$ptp[7]],"(");
   $ttag=qian($rchd,"(");
   return $ttag;
        break;
        case 10:
   $tmp0=explode(")0,",$strun);
   $tmp1=explode(")1,",hou($tmp0[$ptp[0]],"("));
   $tmp2=explode(")2,",hou($tmp1[$ptp[1]],"("));
   $tmp3=explode(")3,",hou($tmp2[$ptp[2]],"("));
   $tmp4=explode(")4,",hou($tmp3[$ptp[3]],"("));
   $tmp5=explode(")5,",hou($tmp4[$ptp[4]],"("));
   $tmp6=explode(")6,",hou($tmp5[$ptp[5]],"("));
   $tmp7=explode(")7,",hou($tmp6[$ptp[6]],"("));
   $tmp8=explode(")8,",hou($tmp7[$ptp[7]],"("));
   $rchd=hou($tmp8[$ptp[8]],"(");
   $ttag=qian($rchd,"(");
   return $ttag;
        break;
        case 11:
   $tmp0=explode(")0,",$strun);
   $tmp1=explode(")1,",hou($tmp0[$ptp[0]],"("));
   $tmp2=explode(")2,",hou($tmp1[$ptp[1]],"("));
   $tmp3=explode(")3,",hou($tmp2[$ptp[2]],"("));
   $tmp4=explode(")4,",hou($tmp3[$ptp[3]],"("));
   $tmp5=explode(")5,",hou($tmp4[$ptp[4]],"("));
   $tmp6=explode(")6,",hou($tmp5[$ptp[5]],"("));
   $tmp7=explode(")7,",hou($tmp6[$ptp[6]],"("));
   $tmp8=explode(")8,",hou($tmp7[$ptp[7]],"("));
   $tmp9=explode(")9,",hou($tmp8[$ptp[8]],"("));
   $rchd=hou($tmp9[$ptp[9]],"(");
   $ttag=qian($rchd,"(");
   return $ttag;
        break;
        case 12:
   $tmp0=explode(")0,",$strun);
   $tmp1=explode(")1,",hou($tmp0[$ptp[0]],"("));
   $tmp2=explode(")2,",hou($tmp1[$ptp[1]],"("));
   $tmp3=explode(")3,",hou($tmp2[$ptp[2]],"("));
   $tmp4=explode(")4,",hou($tmp3[$ptp[3]],"("));
   $tmp5=explode(")5,",hou($tmp4[$ptp[4]],"("));
   $tmp6=explode(")6,",hou($tmp5[$ptp[5]],"("));
   $tmp7=explode(")7,",hou($tmp6[$ptp[6]],"("));
   $tmp8=explode(")8,",hou($tmp7[$ptp[7]],"("));
   $tmp9=explode(")9,",hou($tmp8[$ptp[8]],"("));
   $tmp10=explode(")10,",hou($tmp9[$ptp[9]],"("));
   $rchd=hou($tmp10[$ptp[10]],"(");
   $ttag=qian($rchd,"(");
   return $ttag;
        break;
 };
}
function newv($tmark,$tmvv,$ttag,$tps,$mkid){
   switch ($tmark){
    case "[myid]":
    $conn=mysql_connect(gl(),glu(),glp());   
    $x=updatings($conn,glb(),"update coode_htmltag set myid='".$tmvv."',tagname='".$ttag."' where mysno='".$tps."' and filemark='".$mkid."'");
    break;
    case "[myname]":
    $conn=mysql_connect(gl(),glu(),glp());   
    $x=updatings($conn,glb(),"update coode_htmltag set myname='".$tmvv."',tagname='".$ttag."' where mysno='".$tps."' and filemark='".$mkid."'");
    break;
    case "[mytxt]":
    $conn=mysql_connect(gl(),glu(),glp());   
    $x=updatings($conn,glb(),"update coode_htmltag set mytxt='".$tmvv."',tagname='".$ttag."' where mysno='".$tps."' and filemark='".$mkid."'");
    break;
    case "[myurl]":
    $conn=mysql_connect(gl(),glu(),glp());   
    $x=updatings($conn,glb(),"update coode_htmltag set myurl='".$tmvv."',tagname='".$ttag."' where mysno='".$tps."' and filemark='".$mkid."'");
    break;
    case "[myclick]":
    $conn=mysql_connect(gl(),glu(),glp());   
    $x=updatings($conn,glb(),"update coode_htmltag set myclick='".$tmvv."',tagname='".$ttag."' where mysno='".$tps."' and filemark='".$mkid."'");
    break;
    case "[myvalue]":
    $conn=mysql_connect(gl(),glu(),glp());   
    $x=updatings($conn,glb(),"update coode_htmltag set myvalue='".$tmvv."',tagname='".$ttag."' where mysno='".$tps."' and filemark='".$mkid."'");
    break;
    case "[myclass]":
    $conn=mysql_connect(gl(),glu(),glp());   
    $x=updatings($conn,glb(),"update coode_htmltag set myclass='".$tmvv."',tagname='".$ttag."' where mysno='".$tps."' and filemark='".$mkid."'");
    break;
    case "[mystyle]":
    $conn=mysql_connect(gl(),glu(),glp());   
    $x=updatings($conn,glb(),"update coode_htmltag set mystyle='".$tmvv."',tagname='".$ttag."' where mysno='".$tps."' and filemark='".$mkid."'");
    break;
    case "[mytype]":
    $conn=mysql_connect(gl(),glu(),glp());   
    $x=updatings($conn,glb(),"update coode_htmltag set mytype='".$tmvv."',tagname='".$ttag."' where mysno='".$tps."' and filemark='".$mkid."'");
    break;
   }
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>