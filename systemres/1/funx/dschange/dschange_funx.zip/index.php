<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $datamark=dftval($_GET["datamark"],"");
$datatitle=dftval($_GET["datatitle"],"");
$lenx=dftval($_GET["lenx"],"");
$oldrst=SX("select SNO,keymark,keytype,keylen,dxtype,keytitle from coode_dspckey where datamark='".$datamark."'");
$totold=countresult($oldrst);
for ($m=0;$m<$totold;$m++){
 $keyid=anyvalue($oldrst,"keymark",$m);
 $keydatatype[$keyid]=anyvalue($oldrst,"keytype",$m);
 $keydxtype[$keyid]=anyvalue($oldrst,"dxtype",$m);
 $keylenx[$keyid]=anyvalue($oldrst,"keylen",$m);
 $keytitle[$keyid]=anyvalue($oldrst,"keytitle",$m);
 $oldkeyids=$oldkeyids.$keyid.",";
}
if (intval($totold)==0){
   $sqla="datamark,datatitle,CRTM,UPTM,OLMK,STATUS";
   $sqlb="'".str_replace(" ","",$datamark)."','".str_replace(" ","",$datatitle)."',now(),now(),'".onlymark()."',1";
   $qq=UX("insert into coode_dataspace(".$sqla.")values(".$sqlb.")");   
}
$tmpj=0;
$prekeys="";
$oldkeyids="xx,".$oldkeyids;
for ($i=0;$i<intval($lenx);$i++){
 $colid=dftval(str_replace(" ","",$_POST["colid".$i]),"");
 $coltitle=dftval(str_replace(" ","",$_POST["coltitle".$i]),"");
 $collen=dftval(str_replace(" ","",$_POST["collen".$i]),"");
 $coldes=dftval(str_replace(" ","",$_POST["coldes".$i]),"");
 $coldatatype=dftval(str_replace(" ","",$_POST["coldatatype".$i]),"");
 $coldxtype=dftval(str_replace(" ","",$_POST["coldxtype".$i]),"");
 $tbnmx=$tabmark;
 $cname=$colid;
 $prekeys=$prekeys.$colid.",";
 if (strpos($oldkeyids,",".$colid.",")>0){
   $zz=UX("update coode_dspckey set UPTM=now(),sqx='".($i+1)."' where datamark='".$datamark."' and keymark='".$colid."'");
   $zz1=UX("update coode_dspckeyx set UPTM=now(),sqx='".($i+1)."' where datamark='".$datamark."' and keymark='".$colid."'");
    if (intval($collen)!=intval($keylenx[$colid]) or $coldatatype!=$keydatatype[$colid]){
      switch ($coldxtype){
       case "int":
        $yy=UX("update coode_dspckey set UPTM=now(),keytitle='".$coltitle."',keylen=11,sqx='".$i."',keytype='int',dxtype='int' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(),keytitle='".$coltitle."',keylen=11,sqx='".$i."',keytype='int',dxtype='int' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "tinyint":        
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen=4,sqx='".$i."',keytype='tinyint',dxtype='tinyint' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen=4,sqx='".$i."',keytype='tinyint',dxtype='tinyint' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "varchar20":
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='20',sqx='".$i."',keytype='varchar',dxtype='varchar255' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='20',sqx='".$i."',keytype='varchar',dxtype='varchar255' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "varchar50":
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='50',sqx='".$i."',keytype='varchar',dxtype='varchar255' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='50',sqx='".$i."',keytype='varchar',dxtype='varchar255' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "varchar100":
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='100',sqx='".$i."',keytype='varchar',dxtype='varchar255' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='100',sqx='".$i."',keytype='varchar',dxtype='varchar255' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "varchar255":
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='255',sqx='".$i."',keytype='varchar',dxtype='varchar255' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='255',sqx='".$i."',keytype='varchar',dxtype='varchar255' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "varchar1024":
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='1024',sqx='".$i."',keytype='varchar',dxtype='varchar255' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='1024',sqx='".$i."',keytype='varchar',dxtype='varchar255' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "decimal1":
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='10.1',sqx='".$i."',keytype='decimal',dxtype='decimal1' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='10.1',sqx='".$i."',keytype='decimal',dxtype='decimal1' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "decimal2":
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='10.2',sqx='".$i."',keytype='decimal',dxtype='decimal2' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='10.2',sqx='".$i."',keytype='decimal',dxtype='decimal2' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "decimal3":
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='10.3',sqx='".$i."',keytype='decimal',dxtype='decimal3' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='10.3',sqx='".$i."',keytype='decimal',dxtype='decimal3' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "decimal4":
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='10.4',sqx='".$i."',keytype='decimal',dxtype='decimal4' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='10.4',sqx='".$i."',keytype='decimal',dxtype='decimal4' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "date":
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='0',sqx='".$i."',keytype='date',dxtype='date' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='0',sqx='".$i."',keytype='date',dxtype='date' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "datetime":
       $$yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='0',sqx='".$i."',keytype='datetime',dxtype='datetime' where datamark='".$datamark."' and keymark='".$colid."'");
       $$yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='0',sqx='".$i."',keytype='datetime',dxtype='datetime' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "text":
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='65535',sqx='".$i."',keytype='text',dxtype='text' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='65535',sqx='".$i."',keytype='text',dxtype='text' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "select":
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='1024',sqx='".$i."',keytype='varchar',dxtype='select' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='1024',sqx='".$i."',keytype='varchar',dxtype='select' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "multiselect":
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='1024',sqx='".$i."',keytype='varchar',dxtype='multiselect' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='1024',sqx='".$i."',keytype='varchar',dxtype='multiselect' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "checkbox":
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='1024',sqx='".$i."',keytype='varchar',dxtype='checkbox' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='1024',sqx='".$i."',keytype='varchar',dxtype='checkbox' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "multicheckbox":
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='1024',sqx='".$i."',keytype='varchar',dxtype='multicheckbox' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='1024',sqx='".$i."',keytype='varchar',dxtype='multicheckbox' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "imagex":
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='1024',sqx='".$i."',keytype='varchar',dxtype='imagex' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='1024',sqx='".$i."',keytype='varchar',dxtype='imagex' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "images":
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='1024',sqx='".$i."',keytype='varchar',dxtype='images' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='1024',sqx='".$i."',keytype='varchar',dxtype='images' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "filex":
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='1024',sqx='".$i."',keytype='varchar',dxtype='filex' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='1024',sqx='".$i."',keytype='varchar',dxtype='filex' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       case "files":
        $yy=UX("update coode_dspckey set UPTM=now(), keytitle='".$coltitle."',keylen='1024',sqx='".$i."',keytype='varchar',dxtype='files' where datamark='".$datamark."' and keymark='".$colid."'");
        $yy=UX("update coode_dspckeyx set UPTM=now(), keytitle='".$coltitle."',keylen='1024',sqx='".$i."',keytype='varchar',dxtype='files' where datamark='".$datamark."' and keymark='".$colid."'");
       break;
       default:
    }//swc
   }else{          
   }//if change
  }else{
     $coid[$tmpj]=$colid;
     $cott[$tmpj]=$coltitle;
     
     $codes[$tmpj]=$coldes;
     
     $codxtp[$tmpj]=$coldxtype;     
     $sqlx="keytype,keylen,keytitle,keydescrib,dxtype";
     if ($colid!=""){
       switch($coldxtype){
         case "tinyint":
         $collen="4";
         $coldatatype="tinyint";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "int":
         $collen="11";
         $coldatatype="int";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "varchar20":
         $collen="20";
         $coldatatype="varchar";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "varchar50":
         $collen="50";
         $coldatatype="varchar";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "varchar100":
         $collen="100";
         $coldatatype="varchar";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "varchar255":
         $collen="255";
         $coldatatype="varchar";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "varchar1024":
         $collen="1024";
         $coldatatype="varchar";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "decimal1":
         $collen="10.1";
         $coldatatype="decimal";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "decimal2":
         $collen="10.2";
         $coldatatype="decimal";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "decimal3":
         $collen="10.3";
         $coldatatype="decimal";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "decimal4":
         $collen="10.4";
         $coldatatype="decimal";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "date":
         $collen="0";
         $coldatatype="date";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "datetime":
         $collen="0";
         $coldatatype="datetime";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "select":
         $collen="1024";
         $coldatatype="varchar";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "multiselect":
         $collen="1024";
         $coldatatype="varchar";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "checkbox":
         $collen="1024";
         $coldatatype="varchar";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "multicheckbox":
         $collen="1024";
         $coldatatype="varchar";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "imagex":
         $collen="1024";
         $coldatatype="varchar";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "images":
         $collen="1024";
         $coldatatype="varchar";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "filex":
         $collen="1024";
         $coldatatype="varchar";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         case "files":
         $collen="1024";
         $coldatatype="varchar";
         $codtp[$tmpj]=$coldatatype;
         $colen[$tmpj]=$collen;    
         break;
         default:
       }
       $zz=UX("insert into coode_dspckey(datamark,keymark,".$sqlx.",CRTM,UPTM,sqx)values('".$datamark."','".$colid."','".$coldatatype."','".$collen."','".$coltitle."','".$coldes."','".$coldxtype."',now(),now(),'".$i."')");
     }
     $tmpj=$tmpj+1;  
  }//in
}//for
 $darst=SX("select datasno,datamark from coode_dspcvindex where datamark='".$datamark."'");
 for ($m=0;$m<countresult($darst);$m++){
    $dsn=anyvalue($darst,"datasno",$m);
    $tt=UX("insert into coode_dspcval(datamark,datasno,keymark,keytitle,keytype,keylen,CRTM,UPTM,OLMK)select datamark,'".($dsn)."',keymark,keytitle,keytype,keylen,now(),now(),RAND()*1000000 from coode_dspckey where datamark='".$datamark."' and concat(datamark,'".$dsn."',keymark) not in(select concat(datamark,datasno,keymark) from coode_dspcval)");  
 }
   $xx=UX("update coode_dspcvindex set STATUS=0 where datamark='".$datamark."'");
   $KX=UX("delete from coode_dspckey where timestampdiff(second,UPTM,now())>15 and datamark='".$datamark."'");
   $bb=UX("delete from coode_dspcval where datamark='".$datamark."' and keymark not in(select keymark from coode_dspckey where datamark='".$datamark."')");
   $sqlx="domainmark,datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib,CRTM,UPTM,CRTOR,OLMK";
   $zz=UX("insert into coode_dspckeyx(".$sqlx.")select ".$sqlx." from coode_dspckey where datamark='".$datamark."' and concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckeyx where datamark='".$datamark."')");
   $bb=UX("delete from coode_dspckeyx where concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey)");
   $dsid=$datamark;
   $extz=UX("select count(*) as result from coode_dspcvindex where datasno=0");
   if (intval($extz)==0){
     $dorst=SX("select keymark,keytitle,keytype from coode_dspckeyx where datamark='".$dsid."'");
     $totdo=countresult($dorst);
     $fmx="";
     $fmy="";
     $fmup="";
     for ($o=0;$o<$totdo;$o++){
       $colid=anyvalue($dorst,"keymark",$o);
       $coltt=anyvalue($dorst,"keytitle",$o);
       $coltp=anyvalue($dorst,"keytype",$o);
       $pdata=dftval(unstrs($_POST["p_".$colid.$snox]),"");
       $fmx=$fmx.$colid.",";
       $fmy=$fmy.$pdata.",";
       $fmup=$fmup.$colid."='".$pdata."',";
     }
     $fmx=killlaststr($fmx);
     $fmy=killlaststr($fmy);
     $fmy=str_replace(",","@-@",$fmy);
     $fmup=killlaststr($fmup);   
     $zz=UX("insert into coode_dspcvindex(datamark,datasno,keymks,valmd5,keyvals,CRTM,UPTM,CRTOR,OLMK)values('".$dsid."','0','".$fmx."','".md5(fmy)."','".$fmy."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."')");
     $tt=UX("insert into coode_dspcval(datamark,datasno,keymark,keytitle,keytype,keylen,CRTM,UPTM,OLMK)select datamark,'0',keymark,keytitle,keytype,keylen,now(),now(),RAND()*1000000 from coode_dspckey where datamark='".$dsid."'");
   }else{
     $dorst=SX("select keymark,keytitle,keytype from coode_dspckeyx where datamark='".$dsid."'");
     $totdo=countresult($dorst);
     $fmx="";
     $fmy="";
     for ($o=0;$o<$totdo;$o++){
       $dx=UX("update coode_dspcval set UPTM=now() where datamark='".$dsid."' and datasno='0' and keymark='".$colid."'");    
     }
   }
   $bb=UX("delete from coode_dspcval where datamark='".$dsid."' and datasno='0' and timestampdiff(second,UPTM,now())>30");
   echo makereturnjson("1","修改成功","");
     session_write_close();
?>