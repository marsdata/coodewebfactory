<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $dumark=_get("dumark");
$rst=SX("select cssfilex,stylex,jsfilex,scriptx from coode_domainunit where dumark='".$dumark."'");
$cssfilex=anyvalue($rst,"cssfilex",0);
$stylex=tostring(anyvalue($rst,"stylex",0));
$jsfilex=anyvalue($rst,"jsfilex",0);
$scriptx=tostring(anyvalue($rst,"scriptx",0));
$alltxt="---".$cssfilex.$stylex.$jsfilex.$scriptx;
if (strpos($alltxt,"/localxres/csspagex/")>0){
 $ptpt=explode("/localxres/csspagex/",$alltxt);
 $totpt=count($ptpt);
 for ($j=1;$j<$totpt;$j++){
  $exto=UX("select count(*) as result from coode_unitface where faceid='".$ptpt[$j]."' and dumark='".$dumark."'");
  if (intval($exto)==0){
    $sqlx="faceid,dumark,CRTM,UPTM,OLMK";
    $tmpfc=qian($ptpt[$j],"/");
    $sqly="'".$tmpfc."','".$dumark."',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_unitface(".$sqlx.")values(".$sqly.")");
  }
 }
}
$zzz=UX("update coode_domainunit set STATUS=1,UPTM=now() where dumark='".$dumark."'");
echo makereturnjson("1","吸收成功","");
     session_write_close();
?>