<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $page=$_POST["page"];
$rows=$_POST["rows"];
$datatype=$_GET["datatype"];
$qrykey=dftval($_GET["qrykey"],"");
if ($rows=="NaN" or $rows==""){
 $rows="30";
}
if ($page==""){
 $page="1";
}
$sort=$_POST["sort"];
$order=$_POST["order"];
$stid=$_GET["stid"];
eval(RESFUNSET("tabbaseinfo"));
eval(RESFUNSET("keyinfo"));
eval(RESFUNSET("keyfunbase"));
if (dftval($_GET["dbnm"],"")==""){
  if (dftval($_GET["laydb"],"")==""){
   $strst=SX("select tablename,showkeys,cdt,orddt,sysid from coode_shortdata where shortid='".$stid."' ");
   $tbnm=anyvalue($strst,"tablename",0);
   $dinfo=array();
   $dinfo=getdbinfo("",$tbnm,$dinfo);   
   if ($dinfo["pssno"]!=""){
    $pssno=$dinfo["pssno"];
   }
  }else{
   $strst=SX("select tablename,showkeys,cdt,orddt,sysid from coode_dbshort where shortid='".$stid."' ");
   $tbnm=anyvalue($strst,"tablename",0);  
   $dinfo=array();
   $dinfo=getdbinfo(dftval($_GET["laydb"],""),$tbnm,$dinfo);   
   if ($dinfo["pssno"]!=""){
    $pssno=$dinfo["pssno"];
   }
  }
}else{
  if (dftval($_GET["laydb"],"")==""){
   $strst=SX("select tablename,showkeys,cdt,orddt,sysid from coode_dbshort where shortid='".$stid."' ");
   $tbnm=anyvalue($strst,"tablename",0);  
   $dinfo=array();
   $dinfo=getdbinfo(dftval($_GET["dbnm"],""),$tbnm,$dinfo);
   if ($dinfo["pssno"]!=""){
    $pssno=$dinfo["pssno"];
   }
  }else{
   $strst=SX("select tablename,showkeys,cdt,orddt,sysid from coode_dbshort where shortid='".$stid."' ");
   $tbnm=anyvalue($strst,"tablename",0);  
   $dinfo=array();
   $dinfo=getdbinfo(dftval($_GET["dbnm"],""),$tbnm,$dinfo);
   if ($dinfo["pssno"]!=""){
    $pssno=$dinfo["pssno"];
   }
   $dinfo=getdbinfo(dftval($_GET["laydb"],""),$tbnm,$dinfo);
  }
}
$sysid=anyvalue($strst,"sysid",0);
$appid=anyvalue($strst,"appid",0);
$cdt=anyvalue($strst,"cdt",0);
if ($cdt!=""){
  $cdt="(".$cdt.")";
}
$orddt=anyvalue($strst,"orddt",0);
$tbcdtss=str_replace("[uid]",$_COOKIE["uid"],$cdt);
        $tbcdtss=str_replace("[cid]",$_COOKIE["cid"],$tbcdtss);
        $tbcdtss=str_replace("[grpcid]",$_COOKIE["grpcid"],$tbcdtss);
        $tbcdtss=str_replace("[posids]",$_COOKIE["posids"],$tbcdtss);
        $tbcdtss=str_replace("[depart]",$_COOKIE["depart"],$tbcdtss);
        $tbcdtss=str_replace("[dpts]",$_COOKIE["dpts"],$tbcdtss);
          $tbcdtss=str_replace("[date]",date("Y-m-d"),$tbcdtss);
          $tbcdtss=str_replace("[now]",date("Y-m-d H:i:s"),$tbcdtss);
        $ptnhtxt=explode("[get-",$tbcdtss);
        $totpt=count($ptnhtxt);
        for ($f=0;$f<$totpt;$f++){
          $tmpok=qian($ptnhtxt[$f],"]");
          $tbcdtss=str_replace("[get-".$tmpok."]",$_GET[$tmpok],$tbcdtss);     
        };         
        $ptnhtxt=explode("[post-",$tbcdtss);
        $totpt=count($ptnhtxt);
        for ($f=0;$f<$totpt;$f++){
          $tmpok=qian($ptnhtxt[$f],"]");
          $tbcdtss=str_replace("[post-".$tmpok."]",$_POST[$tmpok],$tbcdtss);     
        };
        $ptnhtxt=explode("[cookie-",$tbcdtss);
        $totpt=count($ptnhtxt);
        for ($f=0;$f<$totpt;$f++){
          $tmpok=qian($ptnhtxt[$f],"]");
          $tbcdtss=str_replace("[cookie-".$tmpok."]",$_COOKIE[$tmpok],$tbcdtss);     
        };
          $tbcdtss=str_replace("[anymark]",date("YmdHis").getRandChar(6),$tbcdtss); 
          if (str_replace(" ","",$tbcdtss)!=""){
            $fmcdt=" where ".$tbcdtss;            
          }else{
            $fmcdt=" where 1>0 ";
          }
$sokeys=tostring(anyvalue($strst,"showkeys",0));
$ptsk=explode(",",$sokeys);
$cx="";
$dx="";
if ($qrykey!=""){
 $ptqk=explode(",",$qrykey);
 $totq=count($ptqk);
 for ($m=0;$m<$totq;$m++){
   $qqq=$ptqk[$m];
   if ($qqq!="" and strpos("x".$sokeys,$qqq)>0){
     if (dftval($_GET[$qqq],"")!=""){
       $dx=$dx." and ".$qqq."='".dftval($_GET[$qqq],"")."'";
     }else{
       if (dftval($_GET[$qqq],"")=="."){  
         $dx=$dx." and ".$qqq."=''";
       }//if
     }//if
   }//if
 }//for
}//if
for ($n=0;$n<count($ptsk);$n++){
  if ($_POST[$ptsk[$n]."start"]=="" or $_POST[$ptsk[$n]."end"]==""){
   if ($_POST[$ptsk[$n]]!="" and $_POST[$ptsk[$n]]!="."){
    $cx=$cx." and ".$ptsk[$n]." like '%".$_POST[$ptsk[$n]]."%'";
   }
  }else{
   if (isdate($_POST[$ptsk[$n]."start"]) and isdate($_POST[$ptsk[$n]."end"])){
     $cx=$cx." and (timestampdiff(second,'".$_POST[$ptsk[$n]."start"]."',".$ptsk[$n].")>=0 and timestampdiff(second,".$ptsk[$n].",'".$_POST[$ptsk[$n]."end"]."')>=0)";
   }else{
    $cx=$cx." and (".$ptsk[$n].">='".$_POST[$ptsk[$n]."start"]."' and ".$ptsk[$n]."<='".$_POST[$ptsk[$n]."end"]."')";
   }
  }
}
if ($dx!=""){
  $dx="(".substr($dx,4,strlen($dx)-4).")";
}
if ($cx!=""){
  $cx="(".substr($cx,4,strlen($cx)-4).")";
}
$pcdt=" limit ".(($page-1)*$rows).",".$rows;
if ($cx!=""){
 $fmcdt=$fmcdt." and ".$cx;
}
if ($dx!=""){
 $fmcdt=$fmcdt." and ".$dx;
}
if ($orddt!=""){
    $fmcdt=$fmcdt." ".$orddt;
 }
$kb=array();
$kb=thekeyfun($kb,glb(),$tbnm,$sokeys);
if (dftval($_GET["dbnm"],"")==""){
 if (dftval($_GET["laydb"],"")==""){
  $totrcd=UX("select count(*) as result from ".$tbnm." ".$fmcdt);
  $tabrst=SX("select ".$sokeys." from ".$tbnm.$fmcdt." ".$pcdt);    
 }else{
  $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
  $totrcd=updatingx($conn,dftval($_GET["laydb"],""),"select count(*) as result from ".$tbnm." ".$fmcdt,"utf8");
  $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
  $tabrst=selectedx($conn,dftval($_GET["laydb"],""),"select ".$sokeys." from ".$tbnm." ".$fmcdt." ".$pcdt,"utf8","");
  
 }
}else{
  if (dftval($_GET["laydb"],"")==""){
    $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
    $totrcd=updatingx($conn,dftval($_GET["dbnm"],""),"select count(*) as result from ".$tbnm." ".$fmcdt,"utf8");
    $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
    $tabrst=selectedx($conn,dftval($_GET["dbnm"],""),"select ".$sokeys." from ".$tbnm." ".$fmcdt." ".$pcdt,"utf8","");    
  }else{
    $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
    $totrcd=updatingx($conn,dftval($_GET["laydb"],""),"select count(*) as result from ".$tbnm." ".$fmcdt,"utf8");
    $conn=mysql_connect($dinfo["fip"],$dinfo["fuser"],$dinfo["fpass"]);
    $tabrst=selectedx($conn,dftval($_GET["laydb"],""),"select ".$sokeys." from ".$tbnm." ".$fmcdt." ".$pcdt,"utf8","");       
    
  }
}
$totrst=countresult($tabrst);
$fmvalx="";
for ($m=0;$m<$totrst;$m++){
 $fmvalx=$fmvalx.'"opr":"1"},{"check":"no",';
  for ($n=0;$n<count($ptsk);$n++){
    if ($ptsk[$n]!="" and $ptsk[$n]!="OPRT" and $ptsk[$n]!="itemOprt"){
      $sshow=$kb[$ptsk[$n]]["COLUMN_SSHOW"];
      if ($ptsk[$n]==$pssno){
       $fmvalx=$fmvalx.'"id":"'.anyvalue($tabrst,$pssno,$m).'",';
       $fmvalx=$fmvalx.'"'.$pssno.'":"'.anyvalue($tabrst,$pssno,$m).'",';
      }else{
       if ($sshow!="" and $datatype=="jshtml" and strpos($sshow,"unction ")<=0){
          $trox=array();
          $trox["key"]=$ptsk[$n];
          $trox["key0"]="p_".$ptsk[$n].anyvalue($tabrst,$pssno,$m);
          $trox["thissno"]=anyvalue($tabrst,$pssno,$m);
          $trox["showkeys"]=$sokeys;
          $trox["tablename"]=$tbnm;
          $trox["shortid"]=$stid;
          $trox["dxtype"]=$kb[$ptsk[$n]]["COLUMN_DXTYPE"];
          if (intval($kb[$ptsk[$n]]["COLUMN_DSPLD"])==1){
           $trox["dsplhtml"]="";
          }else{
           $trox["dsplhtml"]="displayed:none;";
          };
          if (intval($kb[$ptsk[$n]]["COLUMN_CANGE"])==1){
            $trox["rdolhtml"]="";
          }else{
            $trox["rdolhtml"]="readonly";
          };
          $trox["thisolmk"]=anyvalue($tabrst,"OLMK",$m);
          $trox["tablename"]=$tbnm;
          $trox["sysid"]=$sysid;
          $trox["appid"]=$appid;
          $trox["value"]=anyvalue($tabrst,$ptsk[$n],$m);
          $trox["clstxt"]=$kb[$ptsk[$n]]["COLUMN_CLSTXT"];          
          $trow["ti"]=$m;
          $trow["tj"]=$n;
          $trow["acthtm"]=$kb[$ptsk[$n]]["COLUMN_ACTHTM"];
          $trow["atnhtm"]=$kb[$ptsk[$n]]["COLUMN_ATNHTM"];          
          $sshow=exchangeunit($trox,$sshow);
          $sshow=str_replace("\"","\\\"",$sshow);
          $fmvalx=$fmvalx.'"'.$ptsk[$n].'":"'.turnlab($sshow).'",';
       }else{
         $fmvalx=$fmvalx.'"'.$ptsk[$n].'":"'.anyvalue($tabrst,$ptsk[$n],$m).'",';
       }
      }//p sno
    }//ifptsk
  }//forn
}//form
if ($totrst>0){
  $fmvalx=substr($fmvalx,11,strlen($fmvalx)-11).'"opr":"1"}';
  echo '{"total":"'.$totrcd.'","pssno":"'.$pssno.'","rows":['.$fmvalx.']}';
}else{
  echo '{"total":0,"rows":[]}';
}
     session_write_close();
?>