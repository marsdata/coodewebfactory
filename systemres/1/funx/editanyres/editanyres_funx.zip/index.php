<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $restype=_get("restype");
$rescode=_get("rescode");
//如果不存在则新建该资源
switch($restype){
  case "funx":  
  header("location:/localxres/tempx/htmleditor/index.html?funid=".$rescode);
  break;
  case "tabx":  
  header("location:/localxres/funx/anyjsshort/?stid=2qPIqS-sfile:anyjsshort.php-&pnum=150:".$rescode."&page=1:TABLE_NAME&rdr=1&rnd=".onlymark());
  break;
  case "tempx":
  header("location:/localxres/tempx/tempeditor/index.html?unitid=".$rescode);
  break;
  case "clsx":
  header("location:/localxres/tempx/htmleditor/index.html?clsid=".$rescode);
  break;
  case "formx":
  header("location:/localxres/funx/anyjsshort/?stid=".$rescode."&pnum=30");
  break;
  case "sfunx":
  $snox=UX("select SNO as result from coode_funsetfile where setname='".$rescode."'");  
  header("location:/localxres/tempx/htmleditor/index.html?funid=coode_funsetfile@SNO:".$snox.".funbody");
  break;
  case "afunx":
  $snox=UX("select SNO as result from coode_affairfunlist where funname='".$rescode."'");  
  header("location:/localxres/tempx/htmleditor/index.html?funid=coode_affairfunlist@SNO:".$snox.".funfull");
  break;
  case "dfunx":
  $snox=UX("select SNO as result from coode_datafun where dfunmark='".$rescode."'");  
  header("location:/localxres/tempx/htmleditor/index.html?funid=coode_datafun@SNO:".$snox.".dfuneval");
  break;
  case "mfunx":
  $snox=UX("select SNO as result from coode_multifunlist where funname='".$rescode."'");  
  header("location:/localxres/tempx/htmleditor/index.html?funid=coode_multifunlist@SNO:".$snox.".funfull");
  break;
  case "pagex":
  $tnrst=SX("select tempid,sysid,appid,layid from coode_tiny where tinymark='".$rescode."'");
  $sysid=anyvalue($tnrst,"sysid",0);
  $appid=anyvalue($tnrst,"appid",0);
  $layid=anyvalue($tnrst,"layid",0);
  $tempid=anyvalue($tnrst,"tempid",0);
  if ($tempid!=""){
   header("location:/localxres/tempx/tinylayeditor/index.html?unitid=".$tempid."&tinyid=".$rescode);
  }else{
   header("location:/localxres/funx/anytiny/?tiny=".$rescode);
  }
  break;
  case "cdtrdrx":  
  header("location:/localxres/funx/anyjsshort/?stid=sxIBUb-pnum:30&cdtmark=".qian($rescode,"."));
  break;
  case "parardrx":
  header("location:/localxres/funx/anyjsshort/?stid=zJocDJ-pnum:30&tinymark=".qian($rescode,"."));  
  break;
  case "constx":
  header("location:/localxres/funx/anyjsshort/?stid=gxLSRV-pnum:30");
  break;
  case "configx":
  header("location:/localxres/funx/anyjsshort/?stid=6C02fY-pnum:30-");
  break;
  case "groupx":  
  header("location:/localxres/funx/anyjsshort/?stid=Q8Cfee-pnum:30&plotmark=".$rescode);
  break;
  case "plotx":  
  header("location:/localxres/funx/anyjsshort/?stid=layplot&plmk=".$rescode."&parid=-1");
  break;
  case "dataspacex":
  header("location:/localxres/funx/anyjsshort/?stid=NlULLd-pnum:30");
  break;
  case "sysx":
  header("location:/localxres/funx/anysys/?sysid=".$rescode);
  break;
  case "appx":
  header("location:/localxres/funx/anysys/?appid=".$rescode);
  break;
  case "layx":
  header("location:/localxres/funx/anysys/?layid=".$rescode);
  break;
  case "csspagex":
  header("location:/localxres/csspagex/".$rescode."/index.html");
  break;
  case "iconsetx":  
  header("location:/localxres/funx/anyjsshort/?stid=yqGqy6&pnum=999&page=1&setmark=".$rescode);
  break;
  case "databasex":  
  header("location:/localxres/funx/anyjsshort/?stid=GgPB35-pnum:30");
  default:
}
       session_write_close();
?>