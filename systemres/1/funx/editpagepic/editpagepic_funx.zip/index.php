<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $url=$_GET["url"];
if (substr(str_replace("\\","/",$_SERVER['DOCUMENT_ROOT']),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER['DOCUMENT_ROOT'])."/";
}else{
    $gml=str_replace("\\","/",$_SERVER['DOCUMENT_ROOT']);
};
if (strpos($url,".")>0){
    $pturl=explode(".",$url);
    $totp=count($pturl);
    $exn=$pturl[$totp-1];
    $hy=array(array());
    switch ($exn){
        case "html":
        eval(CLASSX("htmlchange"));
        $hx=new htmlchange();
        $hy=$hx->fmframe($hy,file_get_contents(combineurl($gml,$url)),$url);
        break;
        case "htm":
        eval(CLASSX("htmlchange"));
        $hx=new htmlchange();
        $hy=$hx->fmframe($hy,file_get_contents(combineurl($gml,$url)),$url);
        break;
        case "js":
        break;
        case "css":
        eval(CLASSX("srcofcss"));
        $hx=new srcofcss();
        $hy=$hx->srcabsorb($hy,combineurl($gml,$url));
        break;
        default:
        echo "NO RESOURCE!";
    }
    if (intval($hy["num"]["totimgurl"])>0){
        for ($j=0;$j<$hy["num"]["totimgurl"];$j++){
            if ($hy["imglc"][$j]!=""){
             $extn=UX("select count(*) as result from coode_pagefile where filepath='".$hy["imgpar"][$j]."' and fileurl='".$hy["imgurl"][$j]."'");
             if (intval($extn)>0){
                $xz=UX("update coode_pagefile set UPTM=now() where filepath='".$hy["imgpar"][$j]."' and fileurl='".$hy["imgurl"][$j]."'");
             }else{
                $ptpf=explode("/",$hy["imgurl"][$j]);
                $totpf=count($ptpf);
                $pfile=$ptpf[$totpf-1];
                $pturl=explode(".",$hy["imgurl"][$j]);
                $totp=count($pturl);
                $exf=$pturl[$totp-1];
                $sqla="filename,filecname,parfpath,filepath,filetype,pagesrc,fileurl,filelocal,OLMK,CRTM,UPTM";
                $sqlb="'".$pfile."','".$pfile."','".$url."','".$hy["imgpar"][$j]."','".$exf."','".$hy["imgmyurl"][$j]."','".$hy["imgurl"][$j]."','".$hy["imglc"][$j]."','".onlymark()."',now(),now()";
                $xy=UX("insert into coode_pagefile(".$sqla.")values(".$sqlb.")");
             }         
            }else{
            }
        }
    }
    if (intval($hy["num"]["totscpurl"])>0){
        for ($j=0;$j<$hy["num"]["totscpurl"];$j++){
            if ($hy["jsurl"][$j]!=""){
             $extn=UX("select count(*) as result from coode_pagefile where filepath='".$url."' and fileurl='".$hy["jsurl"][$j]."'");
             if (intval($extn)>0){
                $xz=UX("update coode_pagefile set UPTM=now() where filepath='".$url."' and fileurl='".$hy["jsurl"][$j]."'");
             }else{
                $ptpf=explode("/",$hy["jsurl"][$j]);
                $totpf=count($ptpf);
                $pfile=$ptpf[$totpf-1];
                $pturl=explode(".",$hy["jsurl"][$j]);
                $totp=count($pturl);
                $exf=$pturl[$totp-1];
                $sqla="filename,filecname,parfpath,filepath,filetype,pagesrc,fileurl,filelocal,OLMK,CRTM,UPTM";
                $sqlb="'".$pfile."','".$pfile."','".$url."','".$url."','".$exf."','".$hy["jsurl"][$j]."','".$hy["jsurl"][$j]."','".$hy["jslc"][$j]."','".onlymark()."',now(),now()";
                $xy=UX("insert into coode_pagefile(".$sqla.")values(".$sqlb.")");
             }         
            }else{
            }
        }
    }
    if (intval($hy["num"]["totcssurl"])>0){
        for ($j=0;$j<$hy["num"]["totcssurl"];$j++){
            if ($hy["cssurl"][$j]!=""){
             $extn=UX("select count(*) as result from coode_pagefile where filepath='".$url."' and fileurl='".$hy["cssurl"][$j]."'");
             if (intval($extn)>0){
                $xz=UX("update coode_pagefile set UPTM=now() where filepath='".$url."' and fileurl='".$hy["cssurl"][$j]."'");
             }else{
                $ptpf=explode("/",$hy["cssurl"][$j]);
                $totpf=count($ptpf);
                $pfile=$ptpf[$totpf-1];
                $pturl=explode(".",$hy["cssurl"][$j]);
                $totp=count($pturl);
                $exf=$pturl[$totp-1];
                $sqla="filename,filecname,parfpath,filepath,filetype,pagesrc,fileurl,filelocal,OLMK,CRTM,UPTM";
                $sqlb="'".$pfile."','".$pfile."','".$url."','".$url."','".$exf."','".$hy["cssurl"][$j]."','".$hy["cssurl"][$j]."','".$hy["csslc"][$j]."','".onlymark()."',now(),now()";
                $xy=UX("insert into coode_pagefile(".$sqla.")values(".$sqlb.")");
             }         
            }else{
            }
        }
    }
    $p=UX("update coode_pagefile set filelocal=fileurl where mid(fileurl,1,1)='/'");
    header("location:/SPEC/EDITOR/anyjsshort.php?stid=k7Lo5n-pnum:30-&filepath=".$url);
}else{
    echo "NO RESOURCE!";
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>