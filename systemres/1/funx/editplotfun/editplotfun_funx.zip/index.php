<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
       if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$kzm="/.js/.css/.html/.php/.asp/.htm/.json/.jpg/.png/.gif/.svg/.jpeg/.jepg/.bmp/.zip/.rar/";
$snox=intval($_GET["SNO"]);
$plmk=$_GET["plotmark"];
$delmk=$_GET["delmk"];
$parid=$_POST["parid"];
$myid=$_POST["myid"];
$mytitle=$_POST["mytitle"];
$mymark=$_POST["mymark"];
$level=$_POST["level"];
$nmk="";
    if ($parid!="" and $parid!="-1" and $parid!="1"){     
     $parmk=UX("select mymark as result from coode_plotmydetail where plotmark='".$plmk."' and myid='".$parid."'");
     $nmk="/".hou($parmk,"/")."/".$mytitle;
     $ndir=$gml.$plmk.hou($parmk,"/")."/".$mytitle;
    }else{
     $nmk="/".$mytitle;
     $ndir=$gml.$plmk.$mytitle;
    }
    if (strpos($mytitle,".")>0){
     $pttt=explode(".",$mytitle);
     $ltt=$pttt[count($pttt)-1];
    }else{
     $ltt=$mytitle;
    }
     if (strpos($kzm,".".$ltt)>0){
     }else{     
      if ($mytitle!="全部文件"){
       if ($gml!="" and $mytitle!=""){
        $z=createdir($ndir);        
       }
      }
     }
     if ($nmk!=""){
      $_POST["mymark"]=$nmk;     
     }
  if ($delmk!=""){
    $drst=SX("select mytitle,mymark from coode_plotdekill where STCODE='".$delmk."' order by length(mymark) desc");
    $totd=countresult($drst);
    if ($totd>0){
      for ($i=0;$i<$totd;$i++){
        $wjm=anyvalue($drst,"mymark",$i);
        if (strpos($wjm,".")>0){
          $ptwj=explode(".",$wjm);
          $lkz=$ptwj[count($ptwj)-1];
        }else{
          $lkz=$wjm;
        }
        if (strpos($kzm,".".$lkz)>0){        
          unlink($gml.$plmk.hou($wjm,"/"));         
        }else{
         if (dir_exist_file($gml.hou($wjm,"/"))){
         }else{
          rmdir($gml.$plmk.hou($wjm,"/"));          
         }
        }        
      }
    }
  }
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>