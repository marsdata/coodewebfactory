<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $tbcdt=$_GET["tbcdtn"];
if (strpos("X".$tbcdt,"SNO")>0){
 $sno=hou("x".$tbcdt,"SNO=");
};
$fmdiv="";
$fmdov="";
$stid=$_GET["stid"];
if (strpos($stid,":")>0){
    $stid=hou($stid,":");
}
if ($sno!=""){
 $tiaojian=" SNO=".$sno;
}else{
 $tiaojian=" shortid='".$stid."' ";
};
$conn=mysql_connect(gl(),glu(),glp());
$cz=updatings($conn,glb(),"select count(*) as result from coode_shortcss where shortid='".$stid."'","utf8");
if ($cz*1==0){  
  $strst=SX("select shorttitle,tablename  from coode_shortdata where shortid='".$stid."'");
  $stitle=anyvalue($strst,"shorttitle",0);
  $tbnm=anyvalue($strst,"tablename",0);
  $conn=mysql_connect(gl(),glu(),glp());
  $newx=updatings($conn,glb(),"insert into coode_shortcss(shortid,describ,CRTM,UPTM,STATUS,tablename)values('".$stid."','".$stitle."',now(),now(),0,'".$tbnm."')","utf8");
}
$conn=mysql_connect(gl(),glu(),glp());
$mnrst=selecteds($conn,glb(),"select SNO,shortid,describ,jsfiles,cssfiles,scriptx,stylex,UPTM,CRTM  from coode_shortcss where ".$tiaojian,"utf8","");//比较公私分离是否成功,展示比较用hcss2
$totrst=countresult($mnrst);
 $stsno=anyvalue($mnrst,"SNO",0);
 $xurl="localxres/funx/anyshortnew/?stid=9LsHGu&SNO=".$stsno."&cfid=newdftstyle";
 header(combineurl("location:http://".glw(),$xurl));
       session_write_close();
?>