<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $hostx=killlaststr(glw());
$hosty=glt();
$extx=UX("select count(*) as result from coode_comuser where siteurl='".$hostx."' ");
if (intval($extx)==0){
 $sqlx="comid,comname,siteurl,CRTM,UPTM,OLMK";
 $sqly="'','$hosty','$hostx',now(),now(),'".onlymark()."'";
 $zz=UX("insert into coode_comuser(".$sqlx.")values(".$sqly.")");
}
$crst=SX("select SNO,siterid from coode_comuser where siteurl='$hostx'");
$snox=anyvalue($crst,"SNO",0);
$srid=anyvalue($crst,"siterid",0);
  $pdata=Array();
  $pdata["siteurl"]=$hostx;
  $pdata["sitename"]=$hosty;
  $pdata["srid"]=$srid;
  $mthost=glm();
  if (strpos($mthost,":443")>0){
       $purl="https://".str_replace(":443","",$mthost)."/localxres/funx/tellthissite/";
  }else{
       $purl="http://".$mthost."/localxres/funx/tellthissite/";
  } 
  $zz=request_post($purl,$pdata);  
  $zd=json_decode($zz,false);
  if (intval($zd->status)==2){
    $zz=UX("update coode_comuser set siterid='".($zd->srid)."' where siteurl='$hostx'");
  }else{
  }
header("location:/localxres/funx/anyshortnew/?stid=SGR0VV&SNO=".$snox);
     session_write_close();
?>