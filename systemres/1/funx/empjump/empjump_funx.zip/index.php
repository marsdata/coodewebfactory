<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
       $fhost=_get("fhost");
  $ak=_get("ak");
  $euid=_get("euid");
  $tasktype=_get("tasktype");
  $taskcode=_get("taskcode");
  $extx=UX("select count(*) as result from coode_userlist where userid='".$euid."'");   
  if (intval($extx)==0 and $euid!=""){
    $sqlx="userid,wrdid,roleids,depart,CRTM,UPTM,OLMK";
    $sqly="'$euid','emp','oprter','".$taskcode."',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_userlist(".$sqlx.")values(".$sqly.")");
  }else{
    $zzb=UX("update coode_userlist set depart='".$taskcode."',wrdid='emp' where userid='".$euid."'");
  }
  $urst=SX("select userid,wrdid,roleids,depart from coode_userlist where userid='".$euid."'");          
  $totu=countresult($urst);            
  if ($totu>0){
             setcookie("uid",$euid,time()+3600,"/");                      
             setcookie("depart",anyvalue($urst,"depart",0),time()+3600,"/");           
             setcookie("roleids",anyvalue($urst,"roleids",0),time()+3600,"/");                  
             setcookie("deadline",time()+3600,time()+3600,"/");
             $stoken=md5(anyvalue($urst,"userid",0).$sysid.time());
             setcookie("stoken",$stoken,time()+3600,"/");            
             $rname=anyvalue($urst,"realname",0);
             if ($rname==""){
               $rname=getRandChar(6);
             }
             $comid=anyvalue($urst,"wrdid",0);
             setcookie("cid",$comid,time()+3600,"/");
             $depart=anyvalue($urst,"depart",0);
             $sqla="userid,realname,comid,sysid,depart,dpmore,posids,stoken,deadline,logintime,loginarea,fromdomain,CRTM,UPTM,OLMK,CRTOR";
             $sqlb="'".$euid."','".$rname."','".$comid."','".gln()."','','','','".$stoken."',date_add(now(), interval 30 minute),now(),'','',now(),now(),'".onlymark()."','".$euid."'";
             $c=UX("insert into coode_loginstoken(".$sqla.")values(".$sqlb.")");
             switch($tasktype){
              case "sbpp":
               header("location:/localxres/funx/anytiny/?tiny=OGpWuH");
               break;
              case "ydxxtx":
               header("location:/localxres/funx/gotoaddc/");
               break; 
              case "xzgs":
               header("location:/localxres/funx/gotoaddv/");
               break; 
              case "yddpp":
               header("location:/localxres/funx/gotomat/");
              break;
              default:
             }
   }else{
      header("location:/localxres/tempx/mbl404/index.html");
   }
     session_write_close();
?>