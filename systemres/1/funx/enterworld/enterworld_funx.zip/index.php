<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $world=dftval($_GET["world"],"");
$wrst=SX("select SNO,worldtitle,loginpage from coode_worlddefine where worldcode='".$world."'");
$totw=countresult($wrst);
if (intval($totw)>0){
  $loginpage=anyvalue($wrst,"loginpage",0);
  if ($loginpage!=""){
   header("location:/localxres/funx/anytiny/tiny=".$loginpage);
  }else{  
    header("location:localxres/pagex/2/wrproute/GkCjjZbr/q7wdD4/index.html?world=".$world);
  }
}
     session_write_close();
?>