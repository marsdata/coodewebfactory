<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $instcode=_get("instcode");
$fbcode=_get("fbcode");
if (es($instcode)*es($fbcode)==1){
 $sqlx="instcode,sysid,fbcode,fbtype,belongtype,restype,rescode,restitle,headpic,midpic,CRTM,UPTM,OLMK";
 $sqly="'".$instcode."',sysid,fbcode,'inst',belongtype,restype,rescode,restitle,headpic,midpic,now(),now(),md5(RAND())";
 $zz=UX("insert into coode_fbinstres(".$sqlx.")select ".$sqly." from coode_fbinstres where fbcode='".$fbcode."' and concat(fbcode,'".$instcode."',restype,rescode) not in (select concat(fbcode,instcode,restype,rescode) from coode_fbinstres)"); 
 $zz1=UX("update coode_fbinstres set newcode=concat(instcode,'_',rescode),newtitle=restitle where fbtype='inst' and newcode=''");
 echo  makereturnjson("1","生成成功","");
}else{
 echo  makereturnjson("0","生成失败-参数不全","");
}
       session_write_close();
?>