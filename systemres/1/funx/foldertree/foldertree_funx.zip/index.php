<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $ddd=$_GET["ddd"];
$timea=time();
if (substr(str_replace("\\","/",$_SERVER['DOCUMENT_ROOT']),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER['DOCUMENT_ROOT'])."/";
}else{
    $gml=str_replace("\\","/",$_SERVER['DOCUMENT_ROOT']);
};
if (substr($ddd,-1)=="/"){
  $ddd=substr($ddd,0,strlen($ddd)-1);
}
if ($ddd!="" and $ddd!="un"."defined"){
   $dir = combineurl($gml,$ddd);  //要获取的目录
}else{
   $dir = $gml;  //要获取的目录
}
 $filePath[1] = $ddd;
 $filenm[1] = $ddd;
 $myid[1]=1;
 $pid[1]=-1;  
if ($ddd!=""  and $ddd!="un"."defined"){
$k=2;
if (is_dir($dir)){
   if ($dh = opendir($dir)){
           while (($file[$k] = readdir($dh) )!= false){
            if ( $file[$k]!="."  and $file[$k]!=".."){
              $filePath[$k] = $dir."/".$file[$k];
              $filenm[$k] = $file[$k];
              $myid[$k]=$k;
              $pid[$k]=1;  
              $k=$k+1;
          };//iffilek          
         };//whilefilek
    closedir($dh);
    };//iffdh
};//if isdir
$tot0=$k-2;
if ($tot0>0){
 $deep=1;
}
 $b=0;
 for ($l=0;$l<$tot0;$l++){
   $predirpath=$filePath[$l+2];
   $prefile=$filenm[$l+2];
   if (strpos($prefile,'.')>0 || substr($prefile,1,1)=='.'){
   }else{
    if (is_dir($predirpath."/") and $prefile!="."  and $prefile!=".."){
      if ($dh = opendir($predirpath."/")){
           while (($file[$k] = readdir($dh) )!= false){
            if ( $file[$k]!="."  and $file[$k]!=".."){
               $filePath[$k] = $predirpath."/".$file[$k];
               $myid[$k]=$k;
               $pid[$k]=$l+2;
               $k=$k+1;//0增
               $b=$b+1;//1本
             };//if filek
           };//while
       closedir($dh);
       };//if dh
     };//if isdir
   };//if ops
 };//for
 $tot1=$b;
 if ($tot1>0){
  $deep=2;
 } 
 $t=0;
  for($m=0;$m<$tot1;$m++){
      $predirpath=$filePath[$tot0+$m+2];
      $prefile=$filenm[$tot0+$m+2];
      if (strpos($prefile,'.')>0 || substr($prefile,1,1)=='.'){
      }else{        
         if (is_dir($predirpath."/")  and $prefile!="."  and $prefile!=".."){
              if ($dh = opendir($predirpath."/")){
                while (($file[$k] = readdir($dh))!= false){
                  if ( $file[$k]!="."  and $file[$k]!=".."){
                    $filePath[$k] = $predirpath."/".$file[$k];
                    $filenm[$k] = $file[$k];
                    $myid[$k]=$k;
                    $pid[$k]=$myid[$tot0+$m+2];
                    
                    $t=$t+1;//2层新增本
                    $b=$b+1;//1层数量
                    $k=$k+1;//0层数量
                   };//if filek
                };//while file
                closedir($dh);
             };//if dh
          };//if isdir
       };//if strpos
   };//for
$tot2=$t;
 if ($tot2>0){
   $deep=3;
 } 
$u=0;
 for($n=0;$n<$tot2;$n++){
      $predirpath=$filePath[$tot0+$tot1+$n+2];
      $prefile=$filenm[$tot0+$tot1+$n+2];
      if (strpos($prefile,'.')>0 || substr($prefile,1,1)=='.'){
      }else{        
         if (is_dir($predirpath."/")  and $prefile!="."  and $prefile!=".."){
              if ($dh = opendir($predirpath."/")){
                while (($file[$k] = readdir($dh))!= false){
                  if ( $file[$k]!="."  and $file[$k]!=".."){
                    $filePath[$k] = $predirpath."/".$file[$k];
                    $filenm[$k] = $file[$k];                    
                    $myid[$k]=$k;                
                    $pid[$k]=$myid[$tot0+$tot1+$n+2];
                    $u=$u+1;//3层新增本
                    $t=$t+1;//2层新增
                    $b=$b+1;//1层数量
                    $k=$k+1;//0层数量
                   };//if filek
                };//while file
                closedir($dh);
             };//if dh
          };//if isdir
       };//if strpos
   };//for 
$tot3=$u;
 if ($tot3>0){
   $deep=4;
 } 
$v=0;
 for($o=1;$o<$tot3+1;$o++){
      $predirpath=$filePath[$tot0+$tot1+$tot2+$o+2];
      $prefile=$filenm[$tot0+$tot1+$tot2+$o+2];
      if (strpos($prefile,'.')>0 || substr($prefile,1,1)=='.'){
      }else{        
         if (is_dir($predirpath."/")  and $prefile!="."  and $prefile!=".."){
              if ($dh = opendir($predirpath."/")){
                while (($file[$k] = readdir($dh))!= false){
                  if ( $file[$k]!="."  and $file[$k]!=".."){
                    $filePath[$k] = $predirpath."/".$file[$k];
                    $filenm[$k] = $file[$k];                    
                    $myid[$k]=$k;
                    $pid[$k]=$myid[$tot0+$tot1+$tot2+$o+2];
                    $v=$v+1;//4层新增本
                    $u=$u+1;//3层新增
                    $t=$t+1;//2层新增
                    $b=$b+1;//1层数量
                    $k=$k+1;//0层数量
                   };//if filek
                };//while file
                closedir($dh);
             };//if dh
          };//if isdir
       };//if strpos
   };//for
$tot4=$v;
 if ($tot4>0){
   $deep=5;
 } 
$w=0;
for($p=1;$p<$tot4+1;$p++){
      $predirpath=$filePath[$tot0+$tot1+$tot2+$tot3+$p+2];  
      $prefile=$filenm[$tot0+$tot1+$tot2+$tot3+$p+2];
      if (strpos($prefile,'.')>0 || substr($prefile,1,1)=='.'){
      }else{        
         if (is_dir($predirpath."/")  and $prefile!="."  and $prefile!=".."){
              if ($dh = opendir($predirpath."/")){
                while (($file[$k] = readdir($dh))!= false){
                  if ( $file[$k]!="."  and $file[$k]!=".."){
                    $filePath[$k] = $predirpath."/".$file[$k];
                    $filenm[$k] = $file[$k];                    
                    $myid[$k]=$k;
                    $pid[$k]=$myid[$tot0+$tot1+$tot2+$tot3+$p+2];
                    $w=$w+1;//5层新增
                    $v=$v+1;//4层新增
                    $u=$u+1;//3层新增
                    $t=$t+1;//2层新增
                    $b=$b+1;//1层数量
                    $k=$k+1;//0层数量
                   };//if filek
                };//while file
                closedir($dh);
             };//if dh
          };//if isdir
       };//if strpos
   };//for 
$tot5=$w;
 if ($tot5>0){
   $deep=6;
 } 
$x=0;
for($r=1;$r<$tot5+1;$r++){
      $predirpath=$filePath[$tot0+$tot1+$tot2+$tot3+$tot4+$r+2];
      $prefile=$filenm[$tot0+$tot1+$tot2+$tot3+$tot4+$r+2];
      if (strpos($prefile,'.')>0 || substr($prefile,1,1)=='.'){
      }else{        
         if (is_dir($predirpath."/")  and $prefile!="."  and $prefile!=".."){
              if ($dh = opendir($predirpath."/")){
                while (($file[$k] = readdir($dh))!= false){
                  if ( $file[$k]!="."  and $file[$k]!=".."){
                    $filePath[$k] = $predirpath."/".$file[$k];
                    $filenm[$k] = $file[$k];                    
                    $myid[$k]=$k;
                    $pid[$k]=$myid[$tot0+$tot1+$tot2+$tot3+$tot4+$r+2];
                    $x=$x+1;//6层新增
                    $w=$w+1;//5层新增
                    $v=$v+1;//4层新增
                    $u=$u+1;//3层新增
                    $t=$t+1;//2层新增
                    $b=$b+1;//1层数量
                    $k=$k+1;//0层数量
                   };//if filek
                };//while file
                closedir($dh);
             };//if dh
          };//if isdir
       };//if strpos
   };//for 
$tot6=$x;
 if ($tot6>0){
   $deep=7;
 } 
if (substr($ddd,0,1)!="/"){
  $ddd="/".$ddd;
}
$totk=$k;
$extfold=UX("select count(*) as result from coode_folderreg where foldermark='".$ddd."'");
if (intval($extfold)==0){
  $sqla="foldermark,deepth,filenum,CRTM,UPTM,CRTOR,OLMK";
  $sqlb="'".$ddd."','".$deep."','".$totk."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";
  $c=UX("insert into coode_folderreg(".$sqla.")values(".$sqlb.")");
}else{
  $c=UX("update coode_folderreg set UPTM=now() where foldmark='".$ddd."'");
}
for($p=1;$p<$totk+1;$p++){  
   if ($filePath[$p]!=""){
     
      $extt=UX("select count(*) as result from coode_foldertree where filepath='".$filePath[$p]."' and parfolder='".$ddd."'");
      if (intval($extt)==0){
        $fnamex=urlfname($filePath[$p]);
        if ($fnamex!=""){
          $folderx=str_replace($fnamex,"",$filePath[$p]);
          $kzm=kuozhanming($fnamex);
        }else{
          $folderx="";
          $fnamex=urlfname($filePath[$p]);
          $kzm="";
        }
        if ($kzm!="php" and $kzm!="PHP"){
         $sqlx="myid,parid,parfolder,filepath,filename,filetype,CRTM,UPTM,CRTOR,OLMK,STATUS,PRIME";
         $sqly="'".$myid[$p]."','".$pid[$p]."','".$ddd."','".$filePath[$p]."','".$fnamex."','".$kzm."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."',1,1";
         $z=UX("insert into coode_foldertree(".$sqlx.")values(".$sqly.")");
        }else{
         if (strpos($ddd,"DNA")>0 or strpos($ddd,"RNA")>0 or strpos($ddd,"SPEC")>0){
         }else{
           unlink($filePath[$p]);
         }
        }
      }else{
        $z=UX("update coode_foldertree set PRIME=1,myid='".$myid[$p]."',parid='".$pid[$p]."',filename='".urlfname($filePath[$p])."',UPTM=now() where filepath='".$filePath[$p]."' and parfolder='".$ddd."'");
      }       
   }
};
$timeb=time();
$timediff=$timeb-$timea;
$kkk0=UX("delete from coode_foldertree where PRIME=0 and parfolder='".$ddd."'");
$kkk1=UX("update coode_foldertree set PRIME=0 where PRIME=1 and parfolder='".$ddd."'");
echo '{"status":"1","msg":"生成'.$ddd.'目录树成功","redirect":"","用时":"'.$timediff.'","深度":"'.$deep.'","节点数":"'.$totk.'"}';
}else{
echo '{"status":"0","msg":"生成'.$ddd.'目录树失败，不能生成根目录树","redirect":"","用时":"'.$timediff.'","深度":"0","节点数":"0"}';
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>