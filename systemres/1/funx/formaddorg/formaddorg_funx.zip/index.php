<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tiny=_get("tiny");
$x=anyfunrun("makeaddorg","","tinyid=".$tiny,"");
$tntt=UX("select tinytitle as result from coode_tiny where tinymark='".$tiny."'");
$srddemo='{"name": "[srdtitle]","bg_color": "color1",
 "children": [childdata]}';
$partdemo='{"name": "[parttitle]","bg_color": "[bgcolor]",
 "children": [childdata]}';
 $plrst=SX("select mytitle,mymark,myid,parid from coode_plotdetail where plotmark='".$tiny."@org' and (parid=-1 or parid=0)");
 $totpl=countresult($plrst);
  $fmdemo="";
  for ($i=0;$i<$totpl;$i++){
    $ldemo=$partdemo;
    $mtt=anyvalue($plrst,"mytitle",$i);
    $mmk=anyvalue($plrst,"mymark",$i);
    $mid=anyvalue($plrst,"myid",$i);
    if ($mmk!=$mtt){
      $mtt=$mtt."/".$mmk;
    }
    $paid=anyvalue($plrst,"parid",$i);
     $ldemo=str_replace("[parttitle]",$mtt,$ldemo);
     $ldemo=str_replace("[bgcolor]","color".($i%9),$ldemo);     
    $plrst1=SX("select mytitle,mymark,myid,parid from coode_plotdetail where plotmark='".$tiny."@org' and parid=".$mid);
    $totpl1=countresult($plrst1);
    $fmdm1="";
    for ($j=0;$j<$totpl1;$j++){
     $ldemo1=$partdemo;
     $mtt1=anyvalue($plrst1,"mytitle",$j);
     $mmk1=anyvalue($plrst1,"mymark",$j);
     $mid1=anyvalue($plrst1,"myid",$j);
     if ($mmk1!=$mtt1){
      $mtt1=$mtt1."/".$mmk1;
     }
     $paid1=anyvalue($plrst1,"parid",$j);
     $ldemo1=str_replace("[parttitle]",$mtt1,$ldemo1);
     $ldemo1=str_replace("[bgcolor]","color".($i%9),$ldemo1);
     $ldemo1=str_replace("childdata","",$ldemo1);
     $fmdm1=$fmdm1.$ldemo1.","; 
    }
    $ldemo=str_replace("childdata",$fmdm1,$ldemo);
    $fmdemo=$fmdemo.$ldemo.",";
  }
  $srddemo=str_replace("childdata",$fmdemo,$srddemo);
  $srddemo=str_replace("[srdtitle]",$tntt,$srddemo);
  echo $srddemo;
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>