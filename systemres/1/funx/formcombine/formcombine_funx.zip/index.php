<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $fmbtn="";
$topsrd='<div id="wrap"><div id="content" ><ul>[inner]</ul>';
$topitem0='<li ><a href="javascript:void(0);" onclick="gosysid(\'[sysid]\')" class="button black">[systitle]</a></li>';
$topitem1='<li ><a href="javascript:void(0);" onclick="gosysid(\'[sysid]\')" class="button white">[systitle]</a></li>';
$topitemb='<li style="display:none;"><a href="javascript:void(0);" onclick="gosysid(\'[sysid]\')">[systitle]</a></li>';
$srst=SX("select sysid,sysname,STATUS from coode_sysinformation");
$tots=countresult($srst);
for ($i=0;$i<$tots;$i++){
 $sysid=anyvalue($srst,"sysid",$i);
 $systitle=anyvalue($srst,"sysname",$i);
 $sysstt=anyvalue($srst,"STATUS",$i);
 if (intval($sysstt)>0){
   if ($i%2==0){
    $itemdemo=$topitem0;
   }else{
    $itemdemo=$topitem1;
   }
 }else{
   $itemdemo=$topitemb;
 }
  $itemdemo=str_replace("[sysid]",$sysid,$itemdemo);
  $itemdemo=str_replace("[systitle]",$systitle,$itemdemo); 
  $fmbtn=$fmbtn.$itemdemo;
}
$topsrd=str_replace("[inner]",$fmbtn,$topsrd);
echo $topsrd;
     session_write_close();
?>