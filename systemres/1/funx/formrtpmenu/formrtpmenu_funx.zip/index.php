<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $fmbtn="";
$firstx='{a  href="javascript:void(0)" class="button black" onclick="runalert(\'sysallres\',\'\',\'\')"}更新所有资源{/a}';
$firsty='{a  href="javascript:void(0)" class="button white" onclick="location.href=\'/localxres/funx/anyjsshort/?stid=GJX37z-pnum:30-\'"}未设置系统或名称{/a}';
$firstz='{a  href="javascript:void(0)" class="button black" onclick="openawin(\'一键升级\',\'/localxres/pagex/1/humanmachine/YoqepJE6/htKUuO/index.html\',800,800)"}一键全部升级{/a}';
$topsrd=turnlab($firstx).turnlab($firsty).turnlab($firstz).'<div id="wrap" style="margin-bottom:20px;"><div id="content" ><ul>[inner]</ul>';
$topitem0='<li ><a href="javascript:void(0);" onclick="gotype(\'[restype]\')" ><img src="[picurl]" style="width:50px;height:40px;"></a></li>';
$srst=SX("select restypecode,midpic from coode_sysrestypedefine");
$tots=countresult($srst);
for ($i=0;$i<$tots;$i++){
 $restype=anyvalue($srst,"restypecode",$i);
 $picurl=anyvalue($srst,"midpic",$i);
 $itemdemo=$topitem0;
  $itemdemo=str_replace("[restype]",$restype,$itemdemo);
  $itemdemo=str_replace("[picurl]",$picurl,$itemdemo); 
  $fmbtn=$fmbtn.$itemdemo;
}
$topsrd=str_replace("[inner]",$fmbtn,$topsrd);
echo $topsrd;
     session_write_close();
?>