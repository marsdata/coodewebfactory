<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $stid=$_GET["stid"];
if ($stid!=""){
  $stid=qian(hou($stid,"stid="),"-");  
  $srst=SX("select widthx,heightx,fixed,shorttitle,addpage from coode_shortdata where shortid='".$stid."'");
  $totr=countresult($srst);
  $addtiny=anyvalue($srst,"addpage",0);
  $longexp=UX("select longexp as result from coode_tiny where tinymark='".$addtiny."'");
  $tt=anyvalue($srst,"shorttitle",0);
  if ($addtiny!=""){
    if ($longexp!=""){
      $rdrurl=$longexp;
    }else{
      $rdrurl=$addtiny;
    }
  }
 if ($totr>0){
    $hh=anyvalue($srst,"heightx",0);
    $ww=anyvalue($srst,"widthx",0);
    if ($hh=="0" or $hh==""){
      $hh="700";
    }
    if ($ww=="0" or $ww==""){
      $ww="600";
    }
    echo "{\"status\":\"1\",\"t\":\"".$tt."\",\"h\":\"".$hh."\",\"w\":\"".$ww."\",\"f\":\"".(anyvalue($srst,"fixed",0)*1)."\",\"redirect\":\"".$rdrurl."\"}";
   
 }else{
    echo "{\"status\":\"0\",\"t\":\"".$tt."\",\"h\":\"0\",\"w\":\"0\",\"f\":\"0\",\"redirect\":\"".$rdrurl."\"}";
 }
}else{
 echo "{\"status\":\"0\",\"t\":\"".$stid."\",\"h\":\"0\",\"w\":\"0\",\"f\":\"0\",\"redirect\":\"\"}";
}
     session_write_close();
?>