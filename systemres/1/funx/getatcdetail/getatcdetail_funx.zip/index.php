<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $commark=_get("commark");
$amark=_get("amark");
$item='{"status":"1","msg":"成功","clstitle":"[clstitle]","clskey":"[clskey]","headicon":"[headicon]","images":"[images]","atccode":"[atccode]","atctitle":"[atctitle]","atcsentence":"[atcsentence]","atcdescrib":"[atcdescrib]","crtm":"[crtm]"}';
    $drst=SX("select clskey,clstitle,headicon,images,atccode,atctitle,atcsentence,atcdescrib,CRTM from comx_article where commark='".$commark."' and atccode='".$amark."'");  
    $totd=countresult($drst);
     $itemx=$item;
     $kk=0;
     $clskey=anyvalue($drst,"clskey",$kk);
     $clstitle=anyvalue($drst,"clstitle",$kk);
     $headicon=anyvalue($drst,"headicon",$kk);
     $images=anyvalue($drst,"images",$kk);
     $atccode=anyvalue($drst,"atccode",$kk);
     $atctitle=anyvalue($drst,"atctitle",$kk);
     $atcsentence=anyvalue($drst,"atcsentence",$kk);
     $atcdescrib=anyvalue($drst,"atcdescrib",$kk);
     $crtmx=anyvalue($drst,"CRTM",$kk);
     $itemx=str_replace("[clskey]",$clskey,$itemx);
     $itemx=str_replace("[clstitle]",$clstitle,$itemx);
     $itemx=str_replace("[headicon]",$headicon,$itemx);
     $itemx=str_replace("[images]",$images,$itemx);
     $itemx=str_replace("[atccode]",$atccode,$itemx);
     $itemx=str_replace("[atctitle]",$atctitle,$itemx);
     $itemx=str_replace("[atcsentence]",$atcsentence,$itemx);
     $itemx=str_replace("[atcdescrib]",$atcdescrib,$itemx);
     $itemx=str_replace("[crtm]",$crtmx,$itemx);
echo $itemx;
     session_write_close();
?>