<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $funid=str_replace("()","",dftval($_GET["clsid"],""));
$conn=mysql_connect(gl(),glu(),glp());
$funfull=updatings($conn,glb(),"select funfull as result from coode_phpcls where funname='".$funid."' or funname='".$funid."()'","utf8");
$nfull="\r\n".tostring($funfull)."\r\n";
$contentx='<?php'.$nfull.'?>';
$edt=vfresedit("clsx",$funid,$_COOKIE["uid"]);
if ($edt==true){  
  echo $contentx;
}else{      
  echo "RED"."IR"."ECT:/localxres/csspagex/404/black/failure.html?type=cls&id=".$funid;
}
     session_write_close();
?>