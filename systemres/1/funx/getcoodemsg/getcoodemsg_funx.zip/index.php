<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $msg0='<div class="prompt_title">快捷工作台</div>
    <div class="prompt_info clearfix">
       <div class="tz_title">系统消息（[totmsg]）</div>
       <a href="javascript:void(0);" class="" onclick="window.open(\'/DNA/EXF/anylay.php?layid=cPFMdJ\')"><i class="fa fa-volume-up icon_prompt label-success"></i>点击这里查看未读消息</a>
    </div>
    ';
    $msg1='<ul style="width:100%;margin-top:20px;margin-left:20px;">
        [lilist]
       </ul>';
       $fma="";
       $demoa='<li style="float:left;width:100px;height:80px" id="[vmark]"><a href="javascript:void(0)" onclick="runlink(\'[linkurl]\',\'[runway]\',\'[vmark]\')"><center><p><img src="[appimg]" style="width:40px;height:40px"></p>[apptext]</center></a></li>';
       
       $qrst=SX("select vmark,headx,vtitle,vurl,vway from coode_quickvisit ");
       $totq=countresult($qrst);
       for ($i=0;$i<$totq;$i++){
         $demob=$demoa;
         $demob=str_replace("[linkurl]",anyvalue($qrst,"vurl",$i),$demob);
         $demob=str_replace("[runway]",anyvalue($qrst,"vway",$i),$demob);
         $demob=str_replace("[apptext]",anyvalue($qrst,"vtitle",$i),$demob);
         $demob=str_replace("[appimg]",anyvalue($qrst,"headx",$i),$demob);
         $demob=str_replace("[vmark]",anyvalue($qrst,"vmark",$i),$demob);
         $fma=$fma.$demob;
       }
       $totmsg=intval(UX(""));
       $msg0=str_replace("[totmsg]",$totmsg,$msg0);
       $msg1=str_replace("[lilist]",$fma,$msg1);
       echo $msg0.$msg1;
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>