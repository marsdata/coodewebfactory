<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      if ($_GET["runerr"]=="1"){
      }else{
       error_reporting(0);
       register_shutdown_function('zyfshutdownfunc'); 
       set_error_handler('zyferror'); 
      }
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
        if ($_SERVER['SERVER_PORT']=="80"){  
  $myhost=$_SERVER["HTTP_HOST"];
 }else{
  $myhost=$_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"];
 }
 $host=$_GET["host"];
 if ($host!=$myhost){
  echo anyfunrun("getcooderes",$host,"","");
 }else{
  $datax='{"status" : "1" , "totrcd" : "[totrcd]", "vls" : [<data>]}';
  $itemx='{"sysid":"[sysid]","restype":"[restype]","rescode":"[rescode]","restitle":"[resrestitle]","vermd5":"[vermd5]"},';
  $resrst=SX("select grpid,resmark,restitle,restype from coode_sysregres where grpid='0' or grpid='1' or grpid='2' or grpid='v'");
  $totx=countresult($resrst);
  $fmdata="";
  for ($jj=0;$jj<$totx;$jj++){
    $itemy=$itemx;
    $grpid=anyvalue($resrst,"grpid",$jj);
    $restype=anyvalue($resrst,"restype",$jj);
    $resmark=anyvalue($resrst,"resmark",$jj);
    $restitle=anyvalue($resrst,"restitle",$jj);
    $vermd5=anyvalue($resrst,"vermd5",$jj);
    $itemy=str_replace("[sysid]",$grpid,$itemy);
    $itemy=str_replace("[restype]",$restype,$itemy);
    $itemy=str_replace("[rescode]",$resmark,$itemy);
    $itemy=str_replace("[restitle]",$restitle,$itemy);
    $itemy=str_replace("[vermd5]",$vermd5,$itemy);
    $fmdata=$fmdata.$itemy;
  }
  $fmdata=killlaststr($fmdata);
  $datax=str_replace("[totrcd]",$totx,$datax);
  $datax=str_replace("<data>",$fmdata,$datax);
  echo $datax;
 }
       session_write_close();
?>