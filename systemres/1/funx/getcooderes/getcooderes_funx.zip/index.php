<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      if ($_GET["runerr"]=="1"){
      }else{
       error_reporting(0);
       register_shutdown_function('zyfshutdownfunc'); 
       set_error_handler('zyferror'); 
      }
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
        if ($_SERVER['SERVER_PORT']=="80"){  
  $myhost=$_SERVER["HTTP_HOST"];
 }else{
  $myhost=$_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"];
 }
 $a=time();
 $host=$_GET["host"];
 if ($host!=$myhost and $host!=""){
  echo anyfunrun("getcooderes",$host,"","");  
 }else{
  $restxt=anyfunrun("anyshort","","stid=yoN6rx&pnum=9999&page=1","");
  $respath=combineurl(localroot(),"sysmap.json");
  $zz=overfile($respath,$restxt);
   if (glm()=="motherhost" or $myhost=="hellowocao.com"){    
    $gitpath=combineurl(localroot(),"/localxres/sysmap.json");
    $zz=overfile($gitpath,$restxt);
    $installpodtxt=file_get_contents(combineurl(localroot(),"localxres/tempx/runingbox/installfld.php"));
    $inspath=combineurl(localroot(),"/localxres/installfld.txt");
    $zz=overfile($inspath,$installpodtxt);
    $earthtxt=file_get_contents(combineurl(localroot(),"/localxres/EARTH.php"));
    $gitearth=combineurl(localroot(),"/localxres/earth.txt");
    $zz=overfile($gitearth,$earthtxt);
    $indextxt=file_get_contents(combineurl(localroot(),"index.php"));
    $gitindex=combineurl(localroot(),"/localxres/index.txt");
    $zz=overfile($gitindex,$indextxt);
    $tabtxt=file_get_contents(combineurl(localroot(),"/systemres/v/basetab.json"));
    $gittab=combineurl(localroot(),"/localxres/basetab.json");
    $zz=overfile($gittab,$tabtxt);
    $udfntxt=file_get_contents(combineurl(localroot(),"/localxres/USERDEFINE.php"));
    $dfttxt=$udfntxt;
    $dfttxt=str_replace('function bl(){return "'.bl(),'function bl(){return "[bdip]',$dfttxt);
    $dfttxt=str_replace('function blu(){return "'.blu(),'function blu(){return "[bduser]',$dfttxt);
    $dfttxt=str_replace('function blp(){return "'.blp(),'function blp(){return "[bdpass]',$dfttxt);
    $dfttxt=str_replace('function blb(){return "'.blb(),'function blb(){return "[bdbase]',$dfttxt);
         //$bkask=file_get_contents("http://divlovecss.com/localxres/funx/askforcoode/?hdomain=".$_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"]);
         //$bkdata=json_decode($bkask);
         //$rcode=$bkdata->rcode;
         //$vcode=$bkdata->vcode;
                    $earthtxta=$dfttxt;
                    $earthtxta=str_replace('function gl(){return "'.gl(),'function gl(){return "[fip]',$earthtxta);
                    $earthtxta=str_replace('function glu(){return "'.glu(),'function glu(){return "[fuser]',$earthtxta);
                    $earthtxta=str_replace('function glp(){return "'.glp(),'function glp(){return "[fpass]',$earthtxta);
                    $earthtxta=str_replace('function glb(){return "'.glb(),'function glb(){return "[fbase]',$earthtxta);
                    $earthtxta=str_replace('function gln(){return "'.gln(),'function gln(){return "[sysid]',$earthtxta);
                    $earthtxta=str_replace('function gla(){return "'.gla(),'function gla(){return "[rcode]',$earthtxta);
                    $earthtxta=str_replace('function glv(){return "'.glv(),'function glv(){return "[vcode]',$earthtxta);
                    $earthtxta=str_replace('function glm(){return "'.glm(),'function glm(){return "[mhost]',$earthtxta);
                    $earthtxta=str_replace('function glt(){return "'.glt(),'function glt(){return "[sysnm]',$earthtxta);
                    $earthtxta=str_replace('function glr(){return "'.glr(),'function glr(){return "[siteid]',$earthtxta);
                    $earthtxta=str_replace('function hostcode(){return "'.hostcode(),'function hostcode(){return "[sitecode]',$earthtxta);
                    $earthtxta=str_replace('function garea(){return "'.garea(),'function garea(){return "[qnycode]',$earthtxta);
    $gitdft=combineurl(localroot(),"/localxres/userdefine.txt");
    $zz=overfile($gitdft,$earthtxta);
    $z=anyfunrun("gitupsecond","","apicode=coodegit&filepath=".$gitpath,"");
    $z=anyfunrun("gitupsecond","","apicode=coodegit&filepath=".$gitearth,"");
    $z=anyfunrun("gitupsecond","","apicode=coodegit&filepath=".$gitindex,"");
    $z=anyfunrun("gitupsecond","","apicode=coodegit&filepath=".$gittab,"");
    $z=anyfunrun("gitupsecond","","apicode=coodegit&filepath=".$inspath,"");
    $zz=anyfunrun("gitupsecond","","apicode=coodegit&filepath=".$gitdft,"");
    $bkjson=json_decode($zz,false);
    if (intval($bkjson->status)==1){
      unlink($gitdft);
      unlink($gitearth);
      unlink($gitindex);
      unlink($gittab);
      unlink($inspath);
      unlink($gitpath);
    }
   }
  $b=time();
  echo $restxt;
 }
       session_write_close();
?>