<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $cssurl=_get("cssurl");
$faceid=_get("faceid");
if ($cssurl!="" and $faceid!=""){
eval(CLASSX("absorbhtml"));
$ahtml=new absorbhtml();
  $uname=urlfname($cssurl);
  $ufpath=str_replace($uname,"",$cssurl);
  $dm=qian(hou($ufpath,"//"),"/");
  $htt=qian($ufpath,"//");
  $ftxt=file_get_contents($cssurl);
  $indexurl=combineurl(localroot(),"/localxres/csspagex/".$faceid."/index.html");
  $htmlarr=$ahtml->splithtml($ftxt);    
  //var_dump($htmlarr);
  $cssfiles=$htmlarr["cssfilex"].$htmlarr["cssfilez"].$htmlarr["cssfiley"];
  $jsfiles=$htmlarr["jsfilex"].$htmlarr["jsfilez"].$htmlarr["jsfiley"];
  $styleo=$htmlarr["stylex"].$htmlarr["stylez"].$htmlarr["styley"].$htmlarr["scriptx"];
  $scripto=$htmlarr["scriptz"].$htmlarr["scripty"];
  $bodyo=$htmlarr["body"];
  $srdo=$htmlarr["srd"];
  $imgarr=Array(Array());
  $imgarr=absorbimgs($ftxt,$imgarr);
  $toti=count($imgarr[1]);
  
  for ($i=0;$i<$toti;$i++){
     $imn=$imgarr[1][$i];    
     $cname=urlfname($imn);
     $kzm=kuozhanming($cname);
     $lcfile=combineurl(localroot(),"/localxres/csspagex/".$faceid."/images/".$cname);
     $rmturl="/localxres/csspagex/".$faceid."/images/".$cname;
     if (strpos($imn," ")>0 or strpos($imn,">")>0){
     }else{
      if (strpos("xx".$imn,"http")>0){
        $zz=downanyfile($imn,$lcfile); 
      }else{
       if (substr($cssf,0,1)!="/"){
        $zz=downanyfile(combineurl($ufpath,$imn),$lcfile);
       }else{
        $sjurl=combineurl($htt."//".$dm,$imn);
        $zz=downanyfile($sjurl,$lcfile);       
       }
      }
      $ftxt=str_replace($imn,$rmturl,$ftxt);
     }   
  }
  $unitid=$faceid.".index";
  $cssfileo="";
  $jsfileo="";
  $ptcssf=explode(";",onlyone($cssfiles));
  $totc=count($ptcssf);
  //echo "totc-".$totc;
  //var_dump($ptcssf);
  for ($j=0;$j<$totc;$j++){
    $cssf=$ptcssf[$j];
    $cname=urlfname($cssf);
    $kzm=kuozhanming($cname);
    if ($cssf!=""){
     if ($kzm=="js"){
      $lcfile=combineurl(localroot(),"/localxres/csspagex/".$faceid."/js/".$cname);
      $rmturl="/localxres/csspagex/".$faceid."/js/".$cname;
     }else{
      $lcfile=combineurl(localroot(),"/localxres/csspagex/".$faceid."/css/".$cname);
      $rmturl="/localxres/csspagex/".$faceid."/css/".$cname;
     }
     $cssfileo=$cssfileo.$rmturl.";";
     $ftxt=str_replace($cssf,$rmturl,$ftxt);
     if (strpos("xx".$cssf,"http")>0){
      $zz=overfile($lcfile,str_replace("jq22-","",file_get_contents($cssf)));
     }else{
       if (substr($cssf,0,1)!="/"){
         $zz=overfile($lcfile,str_replace("jq22-","",file_get_contents(combineurl($ufpath,$cssf)))); 
       }else{
        $sjurl=combineurl($htt."//".$dm,$cssf);
        $zz=overfile($lcfile,str_replace("jq22-","",file_get_contents($sjurl))); 
       }
     }
    }//ifcssf
  }
  $ptjsf=explode(";",onlyone($jsfiles));
  $totj=count($ptjsf);
  for ($k=0;$k<$totj;$k++){
    $jsf=$ptjsf[$k];
    $jname=urlfname($jsf);
    $kzm=kuozhanming($jname);
    if ($jsf!=""){
     if ($kzm=="js"){
      $lcfile=combineurl(localroot(),"/localxres/csspagex/".$faceid."/js/".$jname);
      $rmturl="/localxres/csspagex/".$faceid."/js/".$jname;
     }else{
      $lcfile=combineurl(localroot(),"/localxres/csspagex/".$faceid."/css/".$jname);
      $rmturl="/localxres/csspagex/".$faceid."/css/".$jname;
     }
     $jsfileo=$jsfileo.$rmturl.";";
     $ftxt=str_replace($jsf,$rmturl,$ftxt);
     if (strpos("xx".$jsf,"http")>0){     
      $zz=overfile($lcfile,file_get_contents($jsf)); 
     }else{
       if (substr($jsf,0,1)!="/"){
         $zz=overfile($lcfile,file_get_contents(combineurl($ufpath,$jsf))); 
       }else{
        $sjurl=combineurl($htt."//".$dm,$jsf);
        $zz=overfile($lcfile,file_get_contents($sjurl)); 
       }
     }
    }//ifjsf
   }
  
  if (strpos($ftxt,"title>")>0){
   $utitle=qian(hou($ftxt,"<title>"),"</title>");
  }else if (strpos($ftxt,"TITLE>")>0){
   $utitle=qian(hou($ftxt,"<TITLE>"),"</TITLE>");
  }else{
   $utitle=$faceid;
  }
  
  $zz=overfile($indexurl,$ftxt);
  
  $pagehtml=turnlab($srdo);
   $pagehtml=str_replace("<!--thesecomCSSFILES-->",formcss(onlyone($cssfileo)),$pagehtml);
   
   $pagehtml=str_replace("<!--thesecomJSFILES-->",formjs(onlyone($jsfileo)),$pagehtml);
   
   $pagehtml=str_replace("<!--thiscomSTYLE-->",$styleo,$pagehtml);
   
   $pagehtml=str_replace("<!--thiscomSCRIPT-->",$scripto,$pagehtml);
   
   $pagehtml=str_replace("<!--thiscomHTML-->",turnlab($bodyo),$pagehtml);
   
   $pagehtml=str_replace("<!--thistitle-->",$utitle,$pagehtml);
 
 $extx=UX("select count(*) as result from coode_domainunit where dumark='".$unitid."'");
 if (intval($extx)==0){
   $sqlx="unittitle,unitclass,unitmark,domainmark,dumark,outurl,cssfilex,stylex,scriptx,jsfilex,cssfiley,jsfiley,styley,scripty,templatecode,pagesurround,OLMK,CRTM,UPTM";
   $sqly="'$utitle','content','index','$faceid','$unitid','/localxres/tempx/$faceid/index.html','".onlyone($cssfileo)."','".gohex($styleo)."','".gohex($scripto)."','".onlyone($jsfileo)."','".onlyone($cssfileo)."','".onlyone($jsfileo)."','".gohex($styleo)."','".gohex($scripto)."','".gohex(str_replace("jq22-","",$bodyo))."','".gohex($srdo)."','".onlymark()."',now(),now()";
   $zz=UX("insert into coode_domainunit(".$sqlx.")values(".$sqly.")");      
   $tturl=combineurl(localroot(),"/localxres/tempx/".$faceid."/".$faceid."/");
   is_dir($tturl) OR mkdir($tturl, 0777, true);
   $fromurl=combineurl(localroot(),"/localxres/csspagex/".$faceid."/");
   copy_dir($fromurl,$tturl);
 }else{  
   $zz=UX("update coode_domainunit set UPTM=now() where dumark='".$unitid."'");  
 }
 $exty=UX("select count(*) as result from coode_facelist where faceid='".$faceid."'");
 if (intval($exty)==0){
  $x="faceid,facetype,csshost,faceurl,facetitle,facedescribe,CRTM,UPTM,OLMK,CRTOR";
  $y="'".$faceid."','','".$cssurl."','/localxres/csspagex/".$faceid."/index.html','$utitle','',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."'";
  $z=UX("insert into coode_facelist(".$x.")values(".$y.")");    
 }
 echo makereturnjson("1","下载样式成功","");
}else{
 echo makereturnjson("0","下载失败","");
}
     session_write_close();
?>