<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $sysid=_get("sysid");
 $date=_get("date");
 if ($date!="un"."defined" and $date!=""){
   $todayrst=SX("select newstr,CRTOR,newtime,timestampdiff(second,newtime,now()) as totime from coode_pagedevelop where date('".$date."')=date(newtime) and sysid='".$sysid."' order by newtime desc");
 }else{
   $todayrst=SX("select newstr,CRTOR,newtime,timestampdiff(second,newtime,now()) as totime from coode_pagedevelop where date(now())=date(newtime) and sysid='".$sysid."' order by newtime desc");
 }
 $tottd=countresult($todayrst);
 $fm="[";
 for ($i=0;$i<$tottd;$i++){
   $fm=$fm."{\"newstr\":\"".anyvalue($todayrst,"newstr",$i)."\",\"crtor\":\"".anyvalue($todayrst,"CRTOR",$i)."\",\"newtime\":\"".anyvalue($todayrst,"newtime",$i)."\",\"neartime\":\"".anyvalue($todayrst,"totime",$i)."\"},";
 };
 if ($tottd>0){
    $fm=substr($fm,0,strlen($fm)-1);
 }
 $fm=$fm."]";
 echo $fm;
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>