<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $instmark=dftval($_GET["instmark"],"");
$expx=dftval($_GET["expx"],"");
$frmmark=dftval($_GET["frmmark"],"");
if (es($instmark)*es($expx)*es(frmmark)==1){
  $elerst=SX("select SNO,myid,parid,widthx,heightx,parwx,parhx,pdleft,pdtop,pdright,pdbottom,marleft,martop,marright,marbottom,parstyle,parhcode,divstyle,divhcode,parmark from coode_divfrmeles where instmark='".$instmark."' and mothersrd='".str_replace("@","=",$expx)."' and frmmark='".$frmmark."'");
  $rtntxt='{"status":"1","msg":"请求成功","SNO":"[SNO]","myid":"[myid]","parid":"[parid]","widthx":"[widthx]","heightx":"[heightx]","parwx":"[parwx]","parhx":"[parhx]","pdleft":"[pdleft]","pdtop":"[pdtop]","pdright":"[pdright]","pdbottom":"[pdbottom]","marleft":"[marleft]","marright":"[marright]","martop":"[martop]","marbottom":"[marbottom]","parstyle":"[parstyle]","parhcode":"[parhcode]","thisstyle":"[thisstyle]","thishcode":"[thishcode]","parmark":"[parmark]"}';  
  $snox=anyvalue($elerst,"SNO",0);  
  $myid=anyvalue($elerst,"myid",0);  
  $parid=anyvalue($elerst,"parid",0);  
  $widthx=anyvalue($elerst,"widthx",0);  
  $heightx=anyvalue($elerst,"heightx",0);
  $parwx=anyvalue($elerst,"parwx",0);
  if ($parwx==""){
    $parwx=UX("select widthx as result from coode_divfrmeles where instmark='".$instmark."' and mothersrd='".str_replace("@","=",$expx)."' and myid='".$parid."'");
    $zz=UX("update coode_divfrmeles set parwx='".$parwx."' where SNO=".$snox);    
  }
  $parhx=anyvalue($elerst,"parhx",0);
  if ($parhx==""){
    $parhx=UX("select heightx as result from coode_divfrmeles where instmark='".$instmark."' and mothersrd='".str_replace("@","=",$expx)."' and myid='".$parid."'");
    $zz=UX("update coode_divfrmeles set parhx='".$parhx."' where SNO=".$snox);    
  }
  $pdleft=anyvalue($elerst,"pdleft",0);
  $pdtop=anyvalue($elerst,"pdtop",0);
  $pdright=anyvalue($elerst,"pdright",0);
  $pdbottom=anyvalue($elerst,"pdbottom",0);
  $marleft=anyvalue($elerst,"marleft",0);
  $martop=anyvalue($elerst,"martop",0);
  $marright=anyvalue($elerst,"marright",0);
  $marbottom=anyvalue($elerst,"marbottom",0);
  $parmark=anyvalue($elerst,"parmark",0);
  $parstyle=anyvalue($elerst,"parstyle",0);
  $parhcode=anyvalue($elerst,"parhcode",0);
  $thisstyle=anyvalue($elerst,"divstyle",0);
  $thishcode=anyvalue($elerst,"divhcode",0);
  $rtntxt=str_replace("[SNO]",$snox,$rtntxt);
  $rtntxt=str_replace("[myid]",$myid,$rtntxt);
  $rtntxt=str_replace("[parid]",$parid,$rtntxt);
  $rtntxt=str_replace("[widthx]",$widthx,$rtntxt);
  $rtntxt=str_replace("[heightx]",$heightx,$rtntxt);
  $rtntxt=str_replace("[parwx]",$parwx,$rtntxt);
  $rtntxt=str_replace("[parhx]",$parhx,$rtntxt);
  $rtntxt=str_replace("[pdleft]",$pdleft,$rtntxt);
  $rtntxt=str_replace("[pdtop]",$pdtop,$rtntxt);
  $rtntxt=str_replace("[pdright]",$pdright,$rtntxt);
  $rtntxt=str_replace("[pdbottom]",$pdbottom,$rtntxt);
  $rtntxt=str_replace("[marleft]",$marleft,$rtntxt);
  $rtntxt=str_replace("[martop]",$martop,$rtntxt);
  $rtntxt=str_replace("[marright]",$marright,$rtntxt);
  $rtntxt=str_replace("[marbottom]",$marbottom,$rtntxt);
  $rtntxt=str_replace("[parstyle]",$parstyle,$rtntxt);
  $rtntxt=str_replace("[parhcode]",$parhcode,$rtntxt);
  $rtntxt=str_replace("[thisstyle]",$thisstyle,$rtntxt);
  $rtntxt=str_replace("[thishcode]",$thishcode,$rtntxt);
  $rtntxt=str_replace("[parmark]",$parmark,$rtntxt);
  echo $rtntxt;
}else{
  echo makereturnjson("0","参数不全","");
}
     session_write_close();
?>