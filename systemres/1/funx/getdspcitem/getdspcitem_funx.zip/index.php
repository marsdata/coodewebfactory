<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $datamark=dftval($_GET["dsid"],"");
$snox=dftval($_GET["SNO"],"0");
if ($datamark=="" or $snox==""){
  echo makereturnjson("0","参数不全","");
}else{
  $dkrst=SX("select datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib   from coode_dspckeyx where datamark='".$datamark."' order by sqx");
  $totdk=countresult($dkrst);
  $fmtps="";
  $fmkkk="{";
  $fmrcd="";
  $fmca="";
  $fmcb="";
  $clstxt="";
  for ($i=0;$i<$totdk;$i++){
   $keyx[$i]=anyvalue($dkrst,"keymark",$i);
   $keyy[$i]=anyvalue($dkrst,"keytitle",$i);
   $keytp[$i]=anyvalue($dkrst,"keytype",$i);
   $keylen[$i]=anyvalue($dkrst,"keylen",$i);
   $clstxtx[$i]=anyvalue($dkrst,"clstxt",$i);
   $classp[$i]=anyvalue($dkrst,"classp",$i);
   $sqx[$i]=anyvalue($dkrst,"sqx",$i);
   $keydxtype[$i]=anyvalue($dkrst,"dxtype",$i);
   $keydescrib[$i]=anyvalue($dkrst,"keydescrib",$i);
   $fmtps=$fmtps.'{"keyid":"'.$keyx[$i].'","keytitle":"'.$keyy[$i].'","keytype":"'.$keytp[$i].'","sqx":"'.$sqx[$i].'","keylen":"'.$keylen[$i].'","dxtype":"'.$keydxtype[$i].'","classp":"'.$classp[$i].'","clstxt":"'.$clstxtx[$i].'","keyexp":"'.$keydescrib[$i].'"},';          
   $fmkkk=$fmkkk.'"'.$keyx[$i].'":"",';    
  }//totdk
  $fmtps=killlaststr($fmtps);
  $fmkkk=killlaststr($fmkkk)."}";
  
  $jsondata='{"data":[<datavls>]}';
  $datademo='{"status":"1","datamark":"<datamark>","datatitle":"<datatitle>","tabcls":"<tabcls>","totrcd":"<totrcd>","keytps":[<ktps>],"vls":[<datavls>]}';
  $dsrst=SX("select datatitle,tabcls from coode_dataspace where datamark='".$datamark."'");
  $datatitle=anyvalue($dsrst,"datatitle",0);
  $tabcls=anyvalue($dsrst,"tabcls",0);
  $datarst=SX("select datasno,keymks,valmd5,keyvals from coode_dspcvindex where datamark='".$datamark."' and datasno=".$snox);
  $totda=countresult($datarst);
  $datademo=str_replace("<datamark>",$datamark,$datademo);
  $datademo=str_replace("<datatitle>",$datatitle,$datademo);
  $datademo=str_replace("<tabcls>",$tabcls,$datademo);
  $datademo=str_replace("<ktps>",$fmtps,$datademo);
  $datademo=str_replace("<totrcd>",$totda,$datademo);
  $fmvalx="";
 
   $datasno=anyvalue($datarst,"datasno",0);
   $keymks=anyvalue($datarst,"keymks",0);
   $valmd5=anyvalue($datarst,"valmd5",0);
   $keyvals=anyvalue($datarst,"keyvals",0);   
   $fmitem="{";
     $detailrst=SX("select keymark,keytype,intval,tinyintval,dateval,datetimeval,varcharval,textval,longtextval,decimalval,classp from coode_dspcval where datamark='".$datamark."' and datasno='".$snox."'");
     //echo $detailrst;
     $totdtl=countresult($detailrst);       
     for ($k=0;$k<$totdtl;$k++){
         $kmk=anyvalue($detailrst,"keymark",$k);
         $ktp=anyvalue($detailrst,"keytype",$k);
         $classpx=anyvalue($detailrst,"classp",$k);
         $intval=anyvalue($detailrst,"intval",$k);
         $tinyintval=anyvalue($detailrst,"tinyintval",$k);
         $dateval=anyvalue($detailrst,"dateval",$k);
         $datetimeval=anyvalue($detailrst,"datetimeval",$k);
         $varcharval=anyvalue($detailrst,"varcharval",$k);         
         $textval=anyvalue($detailrst,"textval",$k);
         $longtextval=anyvalue($detailrst,"longtextval",$k);
         $decimalval=anyvalue($detailrst,"decimalval",$k);
         switch($ktp){
           case "int":
           $valx[$kmk]=$intval;
           break;
           case "tinyint":
           $valx[$kmk]=$tinyintval;
           break;
           case "date":
           $valx[$kmk]=$dateval;
           break;
           case "datetime":
           $valx[$kmk]=$datetimeval;
           break;
           case "varchar":
           $valx[$kmk]=$varcharval;
           break;
           case "text":
           $valx[$kmk]=$textval;
           break;
           case "longtext":
           $valx[$kmk]=$longtextval;
           break;
           case "decimal":
           $valx[$kmk]=$decimalval;
           break;
           default:
         }//swc
         $fmrcd=$fmrcd.$valx[$kmk].",";
     }//fork
     $fmrcd=killlaststr($fmrcd).";";     
    for ($ii=0;$ii<$totdtl;$ii++){
       $fmitem=$fmitem.'"'.$keyx[$ii].'":"'.$valx[$keyx[$ii]].'",';
    }
    if ($totdtl>0){
      $fmitem=killlaststr($fmitem).'}';
    }else{
      $fmitem=$fmkkk;
    }
  $datademo=str_replace("<datavls>",$fmitem,$datademo);
  $jsondata=str_replace("<datavls>",$fmitem,$jsondata);
  echo $datademo;
}
       session_write_close();
?>