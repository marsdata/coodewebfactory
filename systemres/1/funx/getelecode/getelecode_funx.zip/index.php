<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $elemark=dftval($_GET["elemark"],"");
$elerst=SX("select eletitle,jsscode,htmlcode from coode_tinyhtml  where elemark='".$elemark."'");
$tote=countresult($elerst);
if (intval($tote)>0){
  $eletitle=anyvalue($elerst,"eletitle",0);
  $jsscode=anyvalue($elerst,"jsscode",0);
  $htmlcode=anyvalue($elerst,"htmlcode",0);
  echo '{"status":"1","msg":"获取成功","eletitle":"'.dftval($eletitle,$elemark).'","jsscode":"'.$jsscode.'","htmlcode":"'.$htmlcode.'"}';  
}else{
  echo makereturnjson("0","获取失败","");
}
     session_write_close();
?>