<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $drst=SX("select SNO,fburl,gtitle,fbnick,hellotxt,CRTM from fb_hello where STATUS=0 and timestampdiff(minute,UPTM,now())>0 limit 0,1");
$totx=countresult($drst);
if ($totx>0){
  $snox=anyvalue($drst,"SNO",0);
  $insnick=anyvalue($drst,"fbnick",0);
  $durl=anyvalue($drst,"fburl",0);
  $dtitle=anyvalue($drst,"fbnick",0)."@".anyvalue($drst,"gtitle",0);
  $pinglun=tostring(anyvalue($drst,"hellotxt",0));
  $srst=SX("select hellotxt as result from hello_txt order by RAND() limit 0,1");
  $htxt=anyvalue($srst,"hellotxt",0);
  $dpinglun=gohex($insnick.",".$htxt.$pinglun);
  $crtm=anyvalue($drst,"CRTM",0);
  $zz=UX("update fb_hello set STATUS=1,finishtime=now(),finishman='"._get("mancode")."' where SNO=".$snox);
  echo '{"status":"1","crtm":"'.$crtm.'","durl":"'.$durl.'","dtitle":"'.$dtitle.'","dpinglun":"'.$dpinglun.'"}';
}else{
 echo makereturnjson("0","","");
}
       session_write_close();
?>