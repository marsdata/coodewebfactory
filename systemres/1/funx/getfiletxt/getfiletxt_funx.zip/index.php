<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $filename=$_GET["filename"];
$filepath=$_GET["filepath"];
  if (substr(str_replace("\\","/",$_SERVER['DOCUMENT_ROOT']),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER['DOCUMENT_ROOT'])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER['DOCUMENT_ROOT']);
  };
  $filex=$filepath.$filename;
if ($filex!="" and strpos($filex,"EARTH.php")<=0){
  if (strpos("x".$filex,"http")>0){
    $txtx=file_get_contents($filex);
  }else{
    $txtx=file_get_contents(combineurl(localroot(),$filex));
    if ($txtx==""){
     if (substr($gml,-1)!="/" and substr($filepath,0,1)!="/"){
      $txtx=file_get_contents($gml."/".$filepath);
      $txtx=str_replace(tabstr(),"     ",$txtx);
     }else{
      if (substr($gml,-1)=="/" and substr($filex,0,1)=="/"){     
        $txtx=file_get_contents(substr($gml,0,strlen($gml)-1).$filex);
        $txtx=str_replace(tabstr(),"     ",$txtx);
      }else{
        $txtx=file_get_contents($gml.$filex);
        $txtx=str_replace(tabstr(),"     ",$txtx);
      }
     }
    }    
  }
}else{
 $txtx="";
}
$extx=1;
if ($extx>0){
  if ($txtx!=""){
    echo $txtx;
  }else{
    if (strpos($filex,"EARTH.php")>0){
      echo "RED"."IRE"."CT:/FACE/404/black/failure.html?type=file&id=".$filex;      
    }else{
      echo $filex;    
    }
  }
}else{
  $ptpt=explode($filex);
  $pth=$ptpt[count($ptpt)-1];
  echo "RED"."IRE"."CT:/FACE/404/black/failure.html?type=file&id=".$filex;
}
     session_write_close();
?>