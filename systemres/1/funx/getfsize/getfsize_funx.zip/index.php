<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $filename=$_GET["filename"];
$path=addendx($_GET["path"]);
$path=str_replace(localroot(),"",$path);
$longpath=combineurl(localroot(),$path);
function getfsize($filename) {
    // 1. 基础验证：路径是否存在
    if (!file_exists($filename)) {
        trigger_error("路径不存在：{$filename}", E_USER_WARNING);
        return false;
    }
    // 2. 计算文件/目录的原始字节大小
    $byteSize = 0;
    if (is_file($filename)) {
        // 单个文件：直接获取字节大小
        $byteSize = filesize($filename);
        // 处理文件大小获取失败的情况（如无读取权限）
        if ($byteSize === false) {
            trigger_error("无权限读取文件大小：{$filename}", E_USER_WARNING);
            return false;
        }
    } elseif (is_dir($filename)) {
        // 目录：递归计算所有子文件/子目录的总字节大小
        $dirHandle = opendir($filename);
        if (!$dirHandle) {
            trigger_error("无权限打开目录：{$filename}", E_USER_WARNING);
            return false;
        }
        // 遍历目录，排除.和..
        while (($file = readdir($dirHandle)) !== false) {
            if ($file == '.' || $file == '..') continue;
            $subPath = rtrim($filename, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $file;
            // 递归累加子项大小（子项是文件直接加，是目录继续递归）
            $subSize = is_file($subPath) ? filesize($subPath) : getfsize($subPath);
            if ($subSize !== false) {
                $byteSize += is_numeric($subSize) ? $subSize : getByteSizeFromResult($subSize);
            }
        }
        closedir($dirHandle);
    }
    // 3. 字节转最小单位KB（1KB = 1024 字节），避免0字节或极小值
    $size = $byteSize / 1024;
    if ($size < 0.01) $size = 0.01; // 处理小于0.01KB的情况，避免显示0KB
    // 4. 定义单位级别（最小KB，最大TB），按1024进制递进
    $units = ['KB', 'MB', 'GB', 'TB'];
    $unitIndex = 0; // 初始单位为KB
    // 5. 自动适配更大单位（当大小>=1024时，升级单位，直到TB为止）
    while ($size >= 1024 && $unitIndex < count($units) - 1) {
        $size /= 1024;
        $unitIndex++;
    }
    // 6. 格式化结果：保留2位小数 + 拼接单位
    return number_format($size, 2) . $units[$unitIndex];
}
$dirPath = combineurl($longpath,$filename);
$size = getfsize($dirPath);
if ($size !== false) {
    echo makereturnjson("1",$size,"");
} else {
    echo makereturnjson("0","获取失败","");
}
       session_write_close();
?>