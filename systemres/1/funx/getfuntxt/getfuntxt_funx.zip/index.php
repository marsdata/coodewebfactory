<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $funid=$_GET["funid"];
$parall=$_GET["parall"];
$fn=str_replace("()","",$funid);
$s="";
if (isx2($fn,"SNO:","@")){
  $skey=hou($fn,".");
  $sno=qian(hou($fn,"SNO:"),".");
  $tbnm=qian($fn,"@");
  $funfull=UX("select ".$skey." as result from ".$tbnm."  where SNO='".$sno."' ");
  $edt=vfresedit("tabx",$tbnm,$_COOKIE["uid"]);
  $s="1";
}else{
 if (isx1($fn,"@") and !isx1($fn,"SNO:")){
   $ckey=hou($fn,".");
   $tbnm=qian(hou($fn,"@"),".");
   $skey=qian($fn,"@");
   $s="1";
   if ($parall==""){
     $funfull=UX("select ".$skey." as result from coode_keydetailx where TABLE_NAME='".$tbnm."'  and COLUMN_NAME='".$ckey."' ");
   }else{
     $funfull=UX("select ".$skey." as result from coode_tabparallel where tablename='".$tbnm."'  and tabkey='".$ckey."' ");
   }
   $conn=mysql_connect(gl(),glu(),glp());
   $tbname=updatings($conn,glb(),"select tabtitle as result from coode_tablist where TABLE_NAME='".$tbnm."' ","utf8");   
   $edt=vfresedit("tabx",$tbnm,$_COOKIE["uid"]);
 }else{
   $conn=mysql_connect(gl(),glu(),glp());
   $funname=updatings($conn,glb(),"select funname as result from coode_funlist where funname='".$fn."' or funname='".$fn."()'","utf8");
   $funfull=UX("select funfull as result from coode_funlist  where funname='".$fn."' or funname='".$fn."()'");     
   $edt=vfresedit("funx",$fn,$_COOKIE["uid"]);
 }
}
$nfull=huanhang().tostring($funfull).huanhang();
if ($s=="1"){
  $contentx=tostring($funfull);
}else{
  $contentx='<?php'.$nfull.'?>';
}
if ($edt==true ){
  echo $contentx;
}else{   
  if (getip()==""  ){
   echo "returnstr:please don't touch my website!Thank you!  ";
  }else{
   echo "RED"."IRE"."CT:/localxres/csspagex/404/black/failure.html?type=fun&id=".$fn;
  }
}
     session_write_close();
?>