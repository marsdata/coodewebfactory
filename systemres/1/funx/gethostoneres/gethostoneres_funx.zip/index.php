<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $host=$_GET["host"];
$sysid=$_GET["sysid"];
//SNO,grpid,subid,restype,resmark,restitle,headpic,midpic,vermd5,PRIME,CRTOR,OLMK,CRTM,OPRT
$a=time();
if ($host!=""){   
   $restype=$_GET["restype"];
   $resmark=$_GET["resmark"];
   $restitle=$_GET["restitle"];
   $vermd5=$_GET["vermd5"];  
   if ($resmark!="" and $restype!=""){
    $kk=UX("delete from coode_hostregres where grpid='".$sysid."' and host='".$host."' and restype='".$restype."' and resmark='".$resmark."'");  
   
    $sqla="host,grpid,restype,resmark,restitle,hostver,CRTM,UPTM,CRTOR,OLMK";   
    $sqlb="'$host','$sysid','$restype','$resmark','$restitle','".$vermd5."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";
    $zz=UX("insert into coode_hostregres(".$sqla.")values(".$sqlb.")");
   
    $kk=UX("delete from coode_syshostres where sysid='".$sysid."' and host='".$host."' and restype='".$restype."' and rescode='".$resmark."'");     
    $sqlc="motherhost,rescode,restype,restitle,mtver,sysid,CRTM,UPTM,OLMK,STATUS";
    $sqld="'".$host."','".$resmark."','".$restype."','".$restitle."','".$vermd5."','".$sysid."',now(),now(),'".onlymark()."',0";
    $zz=UX("insert into coode_syshostres(".$sqlc.")values(".$sqld.")");
   }
   $b=time();
   echo makereturnjson("1","获取成功-耗时".($b-$a)."秒","");
}else{
   echo makereturnjson("0","获取失败","");
}
       session_write_close();
?>