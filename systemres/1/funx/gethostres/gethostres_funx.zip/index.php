<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     //getsvshost(_get("sysid"))
$sysid=$_GET["sysid"];
$host=$_GET["host"];
$jsontxt=anyfunrun("anyshort",_get("host"),"stid=GJXex0&sysid=".$sysid,"");
$jsondata=json_decode($jsontxt,false);
$zz=UX("delete from coode_syshostres where sysid='".$sysid."' and host='".$host."'");
$vls=$jsondata->vls;
for ($j=0;$j<count($vls);$j++){
  $grpid=$vls[$j]->grpid;
  $restype=$vls[$j]->restype;
  $resmark=$vls[$j]->resmark;
  $restitle=$vls[$j]->restitle;
  $vmd5=$vls[$j]->vermd5;
  $crtm=$vls[$j]->CRTM;
  $uptm=$vls[$j]->UPTM;
  $crtor=$vls[$j]->CRTOR;
  $sqlx="motherhost,sysid,restype,rescode,restitle,mtver,CRTM,UPTM,CRTOR";
  $sqly="'".$host."','".$sysid."','".$restype."','".$resmark."','".$restitle."','".$vmd5."','".$crtm."','".$uptm."','".$crtor."'";
  $sz=UX("insert into coode_syshostres(".$sqlx.")values(".$sqly.")");
}
$zzz=UX("update coode_syshostres,coode_sysregres set coode_syshostres.PRIME=1,coode_syshostres.vermd5=coode_sysregres.vermd5 where coode_syshostres.restype=coode_sysregres.restype and coode_syshostres.rescode=coode_sysregres.resmark");
$zzz=UX("update coode_syshostres set STATUS=1 where mtver=vermd5");
echo makereturnjson("1","执行成功","/localxres/funx/anyjsshort/?stid=uINBt3-pnum:30-&sysid=".$sysid."&hostdm=".$host);
     session_write_close();
?>