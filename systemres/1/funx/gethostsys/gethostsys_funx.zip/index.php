<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $mthost=glm();
if (glm()!="motherhost"){
 $kk=UX("delete from coode_hostregsys");
 $nn=anyfunrun("retabsno","","tabnm=coode_hostregsys","");
 $sysdata=anyfunrun("anyshort",$mthost,"stid=wDCvc9&pnum=999&page=1&datatype=json","");
 $datax=json_decode($sysdata,false);
 $vlx=$datax->vls;
 $sqla="host,sysid,sysname,devehead,deveman,describ,headpic,midpic,hostver,STATUS,STCODE,CRTM,UPTM,OLMK,CRTOR";
 for ($jj=0;$jj<count($vlx);$jj++){
  $host=$vlx[$jj]->host;
  $sysid=$vlx[$jj]->sysid;
  $sysname=$vlx[$jj]->sysname;
  $devehead=$vlx[$jj]->devehead;
  $deveman=$vlx[$jj]->deveman;
  $describ=$vlx[$jj]->describ;
  $midpic=$vlx[$jj]->midpic;
  $hdpic=$vlx[$jj]->headpic;
  $stt=$vlx[$jj]->STATUS;
  $stcode=$vlx[$jj]->STCODE;
  
   if (strpos($hdpic,"//")>0){
     $headpic=$hdpic;
   }else{
     $headpic=combineurl("http://".$host,$hdpic);
   }
  
  $hostver=$vlx[$jj]->hostver;
  $sqlb="'$host','$sysid','$sysname','$devehead','$deveman','$describ','$headpic','$midpic','$hostver','".$stt."','".$stcode."',now(),now(),'".onlymark()."','system'";
  $zzz=UX("insert into coode_hostregsys(".$sqla.")values(".$sqlb.")"); 
 }
 $nn=UX("update coode_hostregsys set PRIME=0 ");
 $nn=UX("update coode_hostregsys set PRIME=1 where sysid in(select sysid from coode_sysinformation)");
 $nn2=UX("update coode_hostregsys,coode_sysinformation set coode_hostregsys.thisver=coode_sysinformation.VRT where coode_hostregsys.sysid=coode_sysinformation.sysid");
 
 
 $kk=UX("delete from coode_svshost");
 $nn=anyfunrun("retabsno","","tabnm=coode_svshost","");
 
 $sqla="hostid,hosttitle,host,port,describ,CRTM,UPTM,CRTOR,OLMK";
 $svsdata=anyfunrun("anyshort",$mthost,"stid=MEej1A&pnum=999&page=1&datatype=json","");
 $datay=json_decode($svsdata,false);
 $vly=$datax->vls;
 for ($jj=0;$jj<count($vly);$jj++){
  $hostid=$vly[$jj]->hostid;
  $hosttitle=$vly[$jj]->hosttitle;
  $host=$vly[$jj]->host;
  $port=$vly[$jj]->port;
  $describ=$vly[$jj]->describ;
  $sqlb="'$hostid','$hosttitle','$host','$port','$describ',now(),now(),'".$_COOKIE["uid"]."',md5(RAND())";
  $zz=UX("insert into coode_svshost(".$sqla.")values(".$sqlb.")");
 }
   echo makereturnjson("1","获取成功","");
 }else{
   $nn=UX("update coode_hostregsys set PRIME=1 where sysid in(select sysid from coode_sysinformation)");
   echo makereturnjson("0","本机为主机","");
 }
       session_write_close();
?>