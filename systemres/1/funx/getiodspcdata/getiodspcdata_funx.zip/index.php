<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $datamark=dftval($_GET["datamark"],"");
$areamark=dftval($_GET["areamark"],"");
$datatype=dftval($_GET["datatype"],"");
$jrst=SX("select jsonShort,jsonData,dataRcd from iO_dataSpace where spcMark='".$datamark."' and srcArea='".$areamark."' and itemUTime=itemPUTime");
$totr=countresult($jrst);
if ($totr==0 or anyvalue($jrst,"dataRcd",0)==""){
 $dkrst=SX("select spcMark,keyMark,keyTitle,keyLen,clsTxt,classP,sQx,keyType,dxType,keyDescrib   from iO_dspcKey where srcArea='".$areamark."' and spcMark='".$datamark."' order by sQx");  
 $totdk=countresult($dkrst);
 $fmtps="";
 $fmrcd="";
 $fmca="";
 $fmcb="";
 $clstxt="";
  for ($i=0;$i<$totdk;$i++){
   $keyx[$i]=anyvalue($dkrst,"keyMark",$i);
   $keyy[$i]=anyvalue($dkrst,"keyTitle",$i);
   $keytp[$i]=anyvalue($dkrst,"keyType",$i);
   $keylen[$i]=anyvalue($dkrst,"keyLen",$i);
   $clstxtx[$i]=anyvalue($dkrst,"clsTxt",$i);
   $classp[$i]=anyvalue($dkrst,"classP",$i);
   $keydxtype[$i]=anyvalue($dkrst,"dxType",$i);
   $fmtps=$fmtps.'{"keyid":"'.$keyx[$i].'","keytitle":"'.$keyy[$i].'","keytype":"'.$keytp[$i].'","keylen":"'.$keylen[$i].'"},';
   $fmrcd=$fmrcd.$keyx[$i].",";
  }//totdk
  $fmtps=killlaststr($fmtps);
  $fmrcd=killlaststr($fmrcd)."@/@";
  $fmrcd=str_replace(",","@-@",$fmrcd);
  $jsondata='{"data":[<datavls>]}';
  $datademo='{"status":"1","datamark":"<datamark>","totrcd":"<totrcd>","keytps":[<ktps>],"vls":[<datavls>]}';
  $datarst=SX("select datasNo,keyMarks,valMd5,keyVals from iO_dspcVIndex where srcArea='".$areamark."' and spcMark='".$datamark."'");
  $totda=countresult($datarst);
  $datademo=str_replace("<datamark>",$datamark,$datademo);
  $datademo=str_replace("<ktps>",$fmtps,$datademo);
  $datademo=str_replace("<totrcd>",$totda,$datademo);
  $fmvalx="";
 
  for ($j=0;$j<$totda;$j++){
   $datasno=anyvalue($datarst,"datasNo",$j);
   $keymks=anyvalue($datarst,"keyMarks",$j);
   $valmd5=anyvalue($datarst,"valMd5",$j);
   $keyvals=anyvalue($datarst,"keyVals",$j);   
 
   $fmitem="{";
   if ($keyvals!=""){
     $ptkey=explode(",",$keymks);     
     $ptval=explode("@-@",$keyvals);     
     for ($k=0;$k<count($ptkey);$k++){
       $valx[$ptkey[$k]]=$ptval[$k];      
       $fmrcd=$fmrcd.$ptval[$k].",";
       if ($classp[$k]==1){
         $fmca=$fmca.$ptval[$k].",";
       }
       if ($classp[$k]==2){
         $fmcb=$fmcb.$ptval[$k].",";
       }
     }//fork
       $fmrcd=killlaststr($fmrcd).";";
   }else{//ifkeyvals
     $detailrst=SX("select keyMark,keyType,intVal,tinyIntval,dateVal,datetimeVal,varcharVal,textVal,longtextVal,decimalVal,classP from iO_dspcVal where srcArea='".$areamark."' and spcMark='".$datamark."' and datasNo='".$datasno."'");
     $totdtl=countresult($detailrst);       
     for ($k=0;$k<$totdtl;$k++){
         $kmk=anyvalue($detailrst,"keyMark",$k);
         $ktp=anyvalue($detailrst,"keyType",$k);
         $classpx=anyvalue($detailrst,"classP",$k);
         $intval=anyvalue($detailrst,"intVal",$k);
         $tinyintval=anyvalue($detailrst,"tinyIntval",$k);
         $dateval=anyvalue($detailrst,"dateVal",$k);
         $datetimeval=anyvalue($detailrst,"datetimeVal",$k);
         $varcharval=anyvalue($detailrst,"varcharVal",$k);
         $textval=anyvalue($detailrst,"textVal",$k);
         $longtextval=anyvalue($detailrst,"longtextVal",$k);
         $decimalval=anyvalue($detailrst,"decimalVal",$k);
         switch($ktp){
           case "int":
           $valx[$kmk]=$intval;
           break;
           case "tinyint":
           $valx[$kmk]=$tinyintval;
           break;
           case "dateval":
           $valx[$kmk]=$dateval;
           break;
           case "datetimeval":
           $valx[$kmk]=$datetimeval;
           break;
           case "varcharval":
           $valx[$kmk]=$varcharval;
           break;
           case "textval":
           $valx[$kmk]=$textval;
           break;
           case "longtextval":
           $valx[$kmk]=$longtextval;
           break;
           case "decimalval":
           $valx[$kmk]=$decimalval;
           break;
           default:
         }//swc
         $fmrcd=$fmrcd.$valx[$kmk].",";
         if (intval($classpx)==1){
           $fmca=$fmca.$valx[$kmk].",";
         }
         if (intval($classpx)==2){
           $fmcb=$fmcb.$valx[$kmk].",";
         }
     }//fork
     $fmrcd=killlaststr($fmrcd).";";
     
   }//ifkeyval
   
     for ($i=0;$i<$totdk;$i++){
       $fmitem=$fmitem.'"'.$keyx[$i].'":"'.$valx[$keyx[$i]].'",';
     }
     $fmitem=killlaststr($fmitem).'}';
   $fmvalx=$fmvalx.$fmitem.',';
 }//forj
 
 $fmvalx=killlaststr($fmvalx);
  $fmca=killlaststr($fmca);
 $fmcb=killlaststr($fmcb);
 if ($fmca!="" and $fmcb!=""){
   $clstxt=$fmcb."|".$fmca;
 }
 $fmrcd=str_replace(",","@-@",$fmrcd);
 $fmrcd=str_replace(";","@/@",$fmrcd);
 $datademo=str_replace("<datavls>",$fmvalx,$datademo);
 $jsondata=str_replace("<datavls>",$fmvalx,$jsondata);
 $px=UX("update iO_dataSpace set itemUTime=itemPUTime,outClstxt='".$clstxt."',dataRcd='".$fmrcd."',jsonData='".gohex($jsondata)."',jsonShort='".gohex($datademo)."',totRcd='".$totda."' where srcArea='".$areamark."' and spcMark='".$datamark."'");
 
 switch($datatype){
  case "jsonshort":
  echo $datademo;
  break;
  case "jsondata":
  echo $jsondata;
  break;
  case "datarcd":
  echo str_replace("@-@","#"."-#",str_replace("@/@","#"."/#",$fmrcd));
  break;
  case "clstxt":
  echo $clstxt;
  break;
  default:
  echo $datademo;
 }
}else{//jrst=0
 
 $datademo=tostring(anyvalue($jrst,"jsonShort",0));
 $jsondata=tostring(anyvalue($jrst,"jsonData",0));
 $datarcd=tostring(anyvalue($jrst,"dataRcd",0));
 $clstxt=tostring(anyvalue($jrst,"outClsTxt",0));
 switch($datatype){
  case "jsonshort":
  echo $datademo;
  break;
  case "jsondata":
  echo $jsondata;
  break;
  case "datarcd":
  echo str_replace("@-@","#"."-#",str_replace("@/@","#"."/#",$datarcd));
  break;
  case "clstxt":
  echo $clstxt;
  break;
  default:
  echo $datademo;
 }
}
 
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>