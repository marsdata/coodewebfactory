<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $temptype=dftval($_GET["temptype"],"");
$tempmark=dftval($_GET["tempmark"],"");
$tinymark=dftval($_GET["tinymark"],"");
$srd='{"code":"0","msg":"","count":"[count]","data":[<data>]}';
   
$item='{"orderNumber":"[sqx]","checked":[chk],"authority":"[authority]","authorityId":[id],"parentId":[pid],"menuIcon":"[menuicon]","menuUrl":"[menuurl]","isMenu":[imenu],"open":[open],"authorityName":"[restitle]","rmark":"[rmark]","restype":"[restype]","createTime":"[CRTM]","updateTime":"[UPTM]","rmturl":"[rmturl]"},';
switch($temptype){
  case "face":
  $drst=SX("select restype,rmark,rtitle,reslocalurl,resrmturl,parid,myid,CRTM from coode_resjarset where tempmark='".$tempmark."' and temptype='".$temptype."'");
  break;
  case "temp":
  $drst=SX("select restype,rmark,rtitle,reslocalurl,resrmturl,parid,myid,CRTM from coode_resjarset where tempmark='".$tempmark."' and temptype='".$temptype."' order by parid ");
  break;
  case "tiny":
  $drst=SX("select restype,rmark,rtitle,reslocalurl,resrmturl,parid,myid,CRTM from coode_resjarset where tempmark='".$tempmark."' and temptype='".$temptype."' and tinymark='".$tempmark."'");
  break;
  default:
} 
  $fma="";
  $totd=countresult($drst);
  for ($p=0;$p<$totd;$p++){
    $restype=anyvalue($drst,"restype",$p);
    $rmark=anyvalue($drst,"rmark",$p);
    $rtitle=anyvalue($drst,"rtitle",$p);
    $reslocalurl=anyvalue($drst,"reslocalurl",$p);
    $resrmturl=anyvalue($drst,"resrmturl",$p);
    $parid=anyvalue($drst,"parid",$p);
    $myid=anyvalue($drst,"myid",$p);
    $crtm=anyvalue($drst,"CRTM",$p);
    $uptm=anyvalue($drst,"UPTM",$p);
    $itemx=$item;
     $itemx=str_replace("[id]",$myid,$itemx);
     $itemx=str_replace("[sqx]",($p+1),$itemx);
     $itemx=str_replace("[chk]","0",$itemx);
     $itemx=str_replace("[authority]","",$itemx);
     $itemx=str_replace("[menuicon]","null",$itemx);    
     $itemx=str_replace("[open]","true",$itemx);
     if ($restype=="folder"){
       $itemx=str_replace("[imenu]","0",$itemx);    
     }else{
       $itemx=str_replace("[imenu]","1",$itemx);    
     }
     $itemx=str_replace("[pid]",$parid,$itemx);
     $itemx=str_replace("[restitle]",$rtitle,$itemx);
     $itemx=str_replace("[rmark]",$rmark,$itemx);
     $itemx=str_replace("[restype]",$restype,$itemx);
     $itemx=str_replace("[CRTM]",$crtm,$itemx);
     $itemx=str_replace("[UPTM]",$uptm,$itemx);
     $itemx=str_replace("[menuurl]",$resrmturl,$itemx);
     $itemx=str_replace("[rtitle]",$rtitle,$itemx);
     $fma=$fma.$itemx;
  }
  $fma=killlaststr($fma);
  $srd=str_replace("<data>",$fma,$srd);
  echo $srd;
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>