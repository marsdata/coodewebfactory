<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $urst=SX("select email,realname,city,mobile,nickname from coode_userlist where userid='".$_COOKIE["uid"]."'");
$totu=countresult($urst);
if ($totu>0){
  $email=anyvalue($urst,"email",0);
  $realname=anyvalue($urst,"realname",0);
  $city=anyvalue($urst,"city",0);
  $mobile=anyvalue($urst,"mobile",0);
  $nickname=anyvalue($urst,"nickname",0);
  echo '{"status":"1","msg":"获取成功","email":"'.$email.'","realname":"'.$realname.'","city":"'.$city.'","mobile":"'.$mobile.'","nickname":"'.$nickname.'"}';
}else{
  echo makereturnjson("0","获取失败","");
}
     session_write_close();
?>