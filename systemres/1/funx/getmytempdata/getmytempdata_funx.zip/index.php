<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $unitid=$_GET["unitid"];
if (strpos($unitid,".")>0){
 $domain=qian($unitid,".");
 $mark=hou($unitid,".");
 $tmpback="";
 $trst=SX("select sysid,appid,unittitle,unitclass,unitdescrib,outurl,industry,business,matter,casecode,cssfilex,stylex,scriptx,jsfilex,cssfiley,jsfiley,styley,scripty,templatecode,demoresult,pagesurround from coode_mydonunit where domainmark='".$domain."' and unitmark='".$mark."'");
 $sysid=anyvalue($trst,"sysid",0);
 $tmpback=$tmpback."\"sysid\":\"".$sysid."\",";
 $appid=anyvalue($trst,"appid",0);
 $tmpback=$tmpback."\"appid\":\"".$appid."\",";
 $unittitle=anyvalue($trst,"unittitle",0);
 $tmpback=$tmpback."\"unittitle\":\"".$unittitle."\",";
 $unitclass=anyvalue($trst,"unitclass",0);
 $tmpback=$tmpback."\"unitclass\":\"".$unitclass."\",";
 $unitdescrib=anyvalue($trst,"unitdescrib",0);
 $tmpback=$tmpback."\"unitdescrib\":\"".$unitdescrib."\",";
 $outurl=anyvalue($trst,"outurl",0);
 $tmpback=$tmpback."\"outurl\":\"".$outurl."\",";
 $industry=anyvalue($trst,"industry",0);
 $tmpback=$tmpback."\"industry\":\"".$industry."\",";
 $business=anyvalue($trst,"business",0);
 $tmpback=$tmpback."\"business\":\"".$business."\",";
 $matter=anyvalue($trst,"matter",0);
 $tmpback=$tmpback."\"matter\":\"".$matter."\",";
 $casecode=anyvalue($trst,"casecode",0);
 $tmpback=$tmpback."\"casecode\":\"".$casecode."\",";
 $cssfilex=anyvalue($trst,"cssfilex",0);
 $tmpback=$tmpback."\"cssfilex\":\"".$cssfilex."\",";
 $stylex=anyvalue($trst,"stylex",0);
 $tmpback=$tmpback."\"stylex\":\"".$stylex."\",";
 $scriptx=anyvalue($trst,"scriptx",0);
 $tmpback=$tmpback."\"scriptx\":\"".$scriptx."\",";
 $jsfilex=anyvalue($trst,"jsfilex",0);
 $tmpback=$tmpback."\"jsfilex\":\"".$jsfilex."\",";
 $cssfiley=anyvalue($trst,"cssfiley",0);
 $tmpback=$tmpback."\"cssfiley\":\"".$cssfiley."\",";
 $jsfiley=anyvalue($trst,"jsfiley",0);
 $tmpback=$tmpback."\"jsfiley\":\"".$jsfiley."\",";
 $styley=anyvalue($trst,"styley",0);
 $tmpback=$tmpback."\"styley\":\"".$styley."\",";
 $scripty=anyvalue($trst,"scripty",0); 
 $tmpback=$tmpback."\"scripty\":\"".$scripty."\",";
 $templatecode=anyvalue($trst,"templatecode",0);
 $tmpback=$tmpback."\"templatecode\":\"".$templatecode."\",";
 $demoresult=anyvalue($trst,"demoresult",0);
 $tmpback=$tmpback."\"demoresult\":\"".$demoresult."\",";
 $pagesurround=anyvalue($trst,"pagesurround",0);
 $tmpback=$tmpback."\"pagesurround\":\"".$pagesurround."\",";
 echo "{\"status\":\"1\",\"msg\":\"@succ\",".killlaststr($tmpback)."}";
}else{
 echo "{\"status\":\"0\",\"msg\":\"@fail\"}";
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>