<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      if ($_GET["runerr"]=="1"){
      }else{
       error_reporting(0);
       register_shutdown_function('zyfshutdownfunc'); 
       set_error_handler('zyferror'); 
      }
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $comwrdid=$_GET["comwrdid"];
$apitype=$_GET["apitype"];
switch($apitype){
  case "github":
     switch($comwrdid){
    case "coodesystem":
     echo makereturnjson("1","marsdata@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:coodewebfactory","git.hellowocao.com");
    default: 
     echo makereturnjson("1","marsdata@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:".$comwrdid,"git.hellowocao.com/".$comwrdid);
    }
  break;
  default:
   switch($comwrdid){
    case "coodesystem":
    //七牛云王晓华接口
     echo makereturnjson("1","coodesys@ByT3o4z00sqYo8QYqW_18-7ez9mzLOegZreDeNu0:1HF536BCJjSN9tKysAnOjrQKrph4XBFp3xjcmVb0","coodesys.hellowocao.com");
    default: 
    //七牛云海口龙华接口
     echo makereturnjson("1","wrdstock@y3PqU_YEsNMfc9N4vjoStfcQFkB8SXnO8LLMJLV_:GFcVrI1QTM2MgNzLHu33ED7gao6nLU5GYbqFuEGh","wrdstock.hellowocao.com");
    }
}
       session_write_close();
?>