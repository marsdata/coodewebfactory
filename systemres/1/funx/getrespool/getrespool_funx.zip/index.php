<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $endtime=UX("select pushtime as result from coode_respool order by pushtime desc");
$etime=dftval(_get("endtime"),$endtime); 
$etm=date("Y-m-d",strtotime($etime));
$poolpath=combineurl("http://".glm(),"/localxres/funx/anyshort/?datatype=json&stid=QWq8iv&page=1&pnum=30&endtime=".$etm);
$pooltxt=file_get_contents($poolpath);
$pooldata=json_decode($pooltxt,false);
$vls=$pooldata->vls;
for ($i=0;$i<count($vls);$i++){
  $fromhost=$vls[$i]->fromhost;
  $restype=$vls[$i]->restype;
  $resmark=$vls[$i]->resmark;
  $restitle=$vls[$i]->restitle;
  $vermd5=$vls[$i]->vermd5;
  $pushtime=$vls[$i]->pushtime;
  $exta=UX("select count(*) as result from coode_respool where vermd5='".$vermd5."'");
  if (intval($exta)==0){
    $sqlx="fromhost,restype,resmark,restitle,vermd5,pushtime,CRTM,UPTM,OLMK";
    $sqly="'$fromhost','$restype','$resmark','$restitle','$vermd5','$pushtime',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_respool(".$sqlx.")values(".$sqly.")");
  }else{
    $zz=UX("update coode_respool set UPTM=now()  where vermd5='".$vermd5."'");
   
  }
}
$zz=UX("update coode_respool set isin=1 where restype='clsx' and resmark in (select funname from coode_phpcls)");
$zz0=UX("update coode_respool set isin=1 where restype='funx' and resmark in (select funname from coode_funlist)");
$zz1=UX("update coode_respool set isin=1 where restype='sfunx' and resmark in (select setname from coode_funsetfile)");
$zz2=UX("update coode_respool set isin=1 where restype='mfunx' and resmark in (select funname from coode_multifunlist)");
$zz3=UX("update coode_respool set isin=1 where restype='tabx' and resmark in (select TABLE_NAME from coode_tablist)");
$zz4=UX("update coode_respool set isin=1 where restype='formx' and resmark in (select shortid from coode_shortdata)");
echo $pooltxt;
     session_write_close();
?>