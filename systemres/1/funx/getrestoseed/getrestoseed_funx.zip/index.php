<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $restype=dftval($_GET["restype"],"");
$rescode=dftval($_GET["rescode"],"");
$resmd5=dftval($_GET["resmd5"],"");
$murl=combineurl("http://".glw(),"/localxres/funx/resinpoolinfo/");
$pd["none"]="";
$bktxt=request_post($murl,$pd);
$bkdata=json_decode($bktxt);
if (intval($bkdata->status)>0){
  $resurl=$bkdata->resurl;
  $kzmx=kuozhanming($resurl);
  $lcurl=combineurl(localroot(),"/localxres/seeds/".$restype."/".$rescode."/".$resmd5."/".$rescode."_".$restype.".".$kzmx); 
  $kd=downanyfile($resurl,$lcurl);
  $sqla="vermd5,restype,resmark,rmturl,lcsavepath,CRTM,UPTM,OLMK";
  $sqlb="'".$resmd5."','".$restype."','".$rescode."','".$resurl."','".$lcurl."',now(),now(),'".onlymark()."'";
  $cc=UX("insert into coode_seeds(".$sqla.")values(".$sqlb.")");
  echo makereturnjson("1","下载成功","");
}else{
  echo makereturnjson("0","下载失败","");
}
     session_write_close();
?>