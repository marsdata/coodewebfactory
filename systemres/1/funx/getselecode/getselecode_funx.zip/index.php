<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $selemark=dftval($_GET["selemark"],"");
$elerst=SX("select seletitle,jsscode,htmlcode from coode_elecode  where selemark='".$selemark."'");
$tote=countresult($elerst);
if (intval($tote)>0){
  $eletitle=anyvalue($elerst,"seletitle",0);
  $jsscode=anyvalue($elerst,"jsscode",0);
  $htmlcode=anyvalue($elerst,"htmlcode",0);
  echo '{"status":"1","msg":"获取成功","seletitle":"'.dftval($eletitle,$selemark).'","jsscode":"'.$jsscode.'","htmlcode":"'.$htmlcode.'"}';  
}else{
  echo makereturnjson("0","获取失败","");
}
     session_write_close();
?>