<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $dbmark=dftval($_GET["dbmark"],"");
$tabnm=dftval($_GET["tabnm"],"");
$dkeys=dftval($_GET["dkeys"],"");
$reskeyx=dftval($_GET["reskeyx"],"");
$ak=dftval($_GET["ak"],"");
$av=dftval($_GET["av"],"");
$arole=UX("select hostrolex as result from coode_scvuser where apikey='".$ak."' and apival='".$av."'");
$prst=SX("select SNO,shortid from coode_clientdataplan where '".$arole."' like concat('%',chostrole,'%') and dbmark='".$dbmark."' and dbtabnm='".$tabnm."' and thiskeys='".$dkeys."' and reskeys='".$reskeyx."'");
$totp=countresult($prst);
if ($dbmark==""){
  $drst=SX("select shortid,shorttitle from coode_shortdata where showkeys='".$dkeys."' where tablename='".$tabnm."'")
  $totd=countresult($drst);  
  if ($totd>0){
    $stidx=anyvalue($drst,"shortid",0);
    echo '{"status":"1","shortid":"'.$stidx.'","msg":"获取成功"}';
  }else{
    $stidx=getRandChar(6);
    $sqlx="tablename,shortid,dttp,showkeys,CRTM,UPTM,OLMK";
    $sqly="'$tabnm','$stidx','json','$dkeys',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_shortdata(".$sqlx.")values(".$sqly.")");
     echo '{"status":"1","shortid":"'.$stidx.'","msg":"获取成功"}';
  }
}else{
  $drst=SX("select shortid,shorttitle from coode_dbshort where showkeys='".$dkeys."' where tablename='".$tabnm."' and catalog='".$dbmark."'")
  $totd=countresult($drst);  
  if ($totd>0){
    $stidx=anyvalue($drst,"shortid",0);
    echo '{"status":"1","shortid":"'.$stidx.'","msg":"获取成功"}';
  }else{
    $stidx=getRandChar(6);
    $sqlx="catalog,tablename,shortid,dttp,showkeys,CRTM,UPTM,OLMK";
    $sqly="'$dbmark','$tabnm','$stidx','json','$dkeys',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_shortdata(".$sqlx.")values(".$sqly.")");
     echo '{"status":"1","shortid":"'.$stidx.'","msg":"获取成功"}';
  }
}
     session_write_close();
?>