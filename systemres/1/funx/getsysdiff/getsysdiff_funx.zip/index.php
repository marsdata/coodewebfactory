<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
         $sysid=$_GET["sysid"];
    if ($_SERVER['SERVER_PORT']=="80"){     
      $myhost=$_SERVER["HTTP_HOST"];
    }else{
      $myhost=$_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"];
    }
    $mthost=anyfunrun("svshost",glm(),"hostid=".$sysid,"");
    $vurl=combineurl("http://".$mthost,"/localxres/funx/sysdiffres/?sysid=".$sysid."&fromhost=".$myhost);
    //echo $vurl;
    echo file_get_contents($vurl);
     session_write_close();
?>