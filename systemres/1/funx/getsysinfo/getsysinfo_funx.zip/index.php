<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     //获取PHP运行方式：      php_sapi_name()       (PHP run mode：apache2handler)
//获取前进程用户名：        Get_Current_User()
//获取Zend版本：          Zend_Version()
//获取PHP安装路径：      DEFAULT_INCLUDE_PATH
//获取当前文件绝对路径：    __FILE__
//获取Http请求中Host值：    $_SERVER['HTTP_HOST']          (返回值为域名或IP)
//接受请求的服务器IP：      $_SERVER['SERVER_ADDR']            (有时候获取不到，推荐用：GetHostByName($_SERVER['SERVER_NAME']))
//获取客户端IP：            $_SERVER['REMOTE_ADDR']
//获取服务器解译引擎：      $_SERVER['SERVER_SOFTWARE']
//获取服务器CPU数量：      $_SERVER['PROCESSOR_IDENTIFIER']
//获取服务器系统目录：      $_SERVER['SystemRoot']
//获取服务器域名：$_SERVER['SERVER_NAME']   (建议使用：$_SERVER['HTTP_HOST'])
//获取用户域名：            $_SERVER['USERDOMAIN']
$sysid=gln();
$sysname=anyvalue($srst,"sysname",0);
$systp= php_uname('s');//只获取系统类型：          php_uname('s')       (或：PHP_OS，例：Windows NT)
$sysban=php_uname('r');//只获取系统版本号：        php_uname('r')
$phpban=PHP_VERSION;//获取PHP版本：          PHP_VERSION
$hostip=GetHostByName($_SERVER['SERVER_NAME']);//获取服务器IP：            GetHostByName($_SERVER['SERVER_NAME'])
$mysqlban=UX("select VERSION() as result");
$ccrtm=UX("select date(CRTM) as result from rberpbox_comuser where comid='".$_COOKIE["cid"]."'");
$lang=$_SERVER['HTTP_ACCEPT_LANGUAG'];//获取服务器语言：          $_SERVER['HTTP_ACCEPT_LANGUAG']
//获取服务器Web端口：      $_SERVER['SERVER_PORT']
echo "{\"sysid\":\"".$sysid."\",\"uid\":\"".$_COOKIE["uid"]."\",\"cid\":\"".$_COOKIE["cid"]."\",\"phpban\":\"".$phpban."\",\"hostip\":\"".$hostip."\",\"lang\":\"".$lang."\",\"systitle\":\"".glt()."\"}";
     session_write_close();
?>