<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $demox='{"status":"1","msg":"成功","totsys":"[totsys]","corelist":[<corelist>],"oprtlist":[<oprtlist>],"toollist":[<toollist>],"oalist":[<oalist>],"erplist":[<erplist>],"datalist":[<datalist>]}';
$itemx='{"sysid":"[sysid]","systitle":"[systitle]"},';
$corerst=SX("select sysid,sysname from coode_sysinformation where syscls='coresys'");
$totc=countresult($corerst);
$fma="";
for ($k=0;$k<$totc;$k++){
  $sysid=anyvalue($corerst,"sysid",$k);
  $sysnm=anyvalue($corerst,"sysname",$k);
  $itemy=$itemx;
  $itemy=str_replace("[sysid]",$sysid,$itemy);
  $itemy=str_replace("[systitle]",$sysnm,$itemy);
  $fma=$fma.$itemy;
}
$fma=killlaststr($fma);
$oprtrst=SX("select sysid,sysname from coode_sysinformation where syscls='oprtsys'");
$fmb="";
$toto=countresult($oprtrst);
for ($k=0;$k<$toto;$k++){
  $sysid=anyvalue($oprtrst,"sysid",$k);
  $sysnm=anyvalue($oprtrst,"sysname",$k);
  $itemy=$itemx;
  $itemy=str_replace("[sysid]",$sysid,$itemy);
  $itemy=str_replace("[systitle]",$sysnm,$itemy);
  $fmb=$fmb.$itemy;
}
$fmb=killlaststr($fmb);
$toolrst=SX("select sysid,sysname from coode_sysinformation where syscls='toolsys'");
$tott=countresult($toolrst);
$fmc="";
for ($k=0;$k<$tott;$k++){
  $sysid=anyvalue($toolrst,"sysid",$k);
  $sysnm=anyvalue($toolrst,"sysname",$k);
  $itemy=$itemx;
  $itemy=str_replace("[sysid]",$sysid,$itemy);
  $itemy=str_replace("[systitle]",$sysnm,$itemy);
  $fmc=$fmc.$itemy;
}
$fmc=killlaststr($fmc);
$oarst=SX("select sysid,sysname from coode_sysinformation where syscls='oasys'");
$totoa=countresult($oarst);
$fmd="";
for ($k=0;$k<$totoa;$k++){
  $sysid=anyvalue($oarst,"sysid",$k);
  $sysnm=anyvalue($oarst,"sysname",$k);
  $itemy=$itemx;
  $itemy=str_replace("[sysid]",$sysid,$itemy);
  $itemy=str_replace("[systitle]",$sysnm,$itemy);
  $fmd=$fmd.$itemy;
}
$fmd=killlaststr($fmd);
$erprst=SX("select sysid,sysname from coode_sysinformation where syscls='erpsys'");
$tote=countresult($erprst);
$fme="";
for ($k=0;$k<$tote;$k++){
  $sysid=anyvalue($erprst,"sysid",$k);
  $sysnm=anyvalue($erprst,"sysname",$k);
  $itemy=$itemx;
  $itemy=str_replace("[sysid]",$sysid,$itemy);
  $itemy=str_replace("[systitle]",$sysnm,$itemy);
  $fme=$fme.$itemy;
}
$fme=killlaststr($fme);
$datarst=SX("select sysid,sysname from coode_sysinformation where syscls='datasys'");
$totd=countresult($datarst);
$fmf="";
for ($k=0;$k<$totd;$k++){
  $sysid=anyvalue($datarst,"sysid",$k);
  $sysnm=anyvalue($datarst,"sysname",$k);
  $itemy=$itemx;
  $itemy=str_replace("[sysid]",$sysid,$itemy);
  $itemy=str_replace("[systitle]",$sysnm,$itemy);
  $fmf=$fmf.$itemy;
}
$fmf=killlaststr($fmf);
$demox=str_replace("<corelist>",$fma,$demox);
$demox=str_replace("<oprtlist>",$fmb,$demox);
$demox=str_replace("<toollist>",$fmc,$demox);
$demox=str_replace("<oalist>",$fmd,$demox);
$demox=str_replace("<erplist>",$fme,$demox);
$demox=str_replace("<datalist>",$fmf,$demox);
$totsys=intval($totc)+intval($toto)+intval($tott)+intval($totoa)+intval($tote)+intval($totd);
$demox=str_replace("[totsys]",$totsys,$demox);
echo $demox;
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>