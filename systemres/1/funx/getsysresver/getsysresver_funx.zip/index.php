<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       eval(RESFUNSET("resrelyrp"));
$rescode=_get("rescode");
$restype=_get("restype");
$vmd5=resvermd5($restype,$rescode);
$zz=UX("update coode_sysregres set PRIME=1,vermd5='".$vmd5."' where resmark='".$rescode."' and restype='".$restype."'");
echo '{"status":"1","msg":"获取成功","rescode":"'.$rescode."_".$restype.'","vmd5":"'.$vmd5.'"}';
       session_write_close();
?>