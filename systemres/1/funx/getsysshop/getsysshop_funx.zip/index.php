<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $bktxt=anyfunrun("anyshort",glm(),"stid=q9Vsng","");
$bkdata=json_decode($bktxt,false);
$vls=$bkdata->vls;
for ($j=0;$j<count($vls);$j++){
  $sysname=$vls[$j]->sysname;
  $sysid=$vls[$j]->sysid;
  $vermd5=$vls[$j]->vermd5;
  $faceimg=$vls[$j]->faceimg;
  $crtor=$vls[$j]->CRTOR;
  $extx=UX("select count(*) as result from coode_hostregsys where sysid='".$sysid."'");
  if (intval($extx)==0){
    $sqlx="sysid,sysname,headpic,hostver,CRTOR,OLMK,CRTM,UPTM";
    $sqly="'$sysid','$sysname','$faceimg','$vermd5','$crtor','".onlymark()."',now(),now()";
    $zz=UX("insert into coode_hostregsys(".$sqlx.")values(".$sqly.")");
  }else{
    $zz=UX("update coode_hostregsys set UPTM=now() where sysid='".$sysid."'");
  }
}
$zz=UX("update coode_hostregsys set insite=1 where sysid in(select sysid from coode_sysinformation)");
header("location:/localxres/funx/anyjsshort/?stid=wDCvc9-pnum:30-");
     session_write_close();
?>