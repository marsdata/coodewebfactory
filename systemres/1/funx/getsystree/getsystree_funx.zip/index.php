<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $ddd=$_GET["ddd"];
$fff=$_GET["fff"];
if (substr(str_replace("\\","/",$_SERVER['DOCUMENT_ROOT']),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER['DOCUMENT_ROOT'])."/";
}else{
    $gml=str_replace("\\","/",$_SERVER['DOCUMENT_ROOT']);
};
if ($ddd!=""){
   $dir = $gml.$ddd;  //要获取的目录
}else{
   $dir = $gml;  //要获取的目录
}
$ljwj=0;
$ljsz=0;
$cgsz=10*1024*1024;
//先判断指定的路径是不是一个文件夹
$k=2;
if (is_dir($dir)){
   if ($dh = opendir($dir)){
           while (($file[$k] = readdir($dh) )!= false){
            if ( $file[$k]!="."  and $file[$k]!=".."){
              $filePath[$k] = $dir.$file[$k];
              $fsize[$k]=0;
              $fsize[$k]=0;
              $fctime[$k]=date("Y-m-d H:i:s");
              $futime[$k]=date("Y-m-d H:i:s");
              $fhash[$k]="";            
              $fhash[$k]="";
              $filenm[$k] = $file[$k];
              $bz[$k]="[1]".$k;
              $pid[$k]='1';    
          $k=$k+1;
          };//iffilek          
         };//whilefilek
    closedir($dh);
    };//iffdh
};//if isdir
$totf=$k-1;
//$totk=$totf;
 $j=2;
 for ($i=2;$i<$totf+2;$i++){   
   if (strpos($file[$i],'.')>0 || substr($file[$i],1,1)=='.'){
   }else{
    if (is_dir($dir.$file[$i]."/") and $file[$i]!="."  and $file[$i]!=".."){
      if ($dh = opendir($dir.$file[$i]."/")){
           while (($file[$k] = readdir($dh) )!= false){
            if ( $file[$k]!="."  and $file[$k]!=".."){
              $filePath[$k] = $dir.$file[$i]."/".$file[$k];
              $fsize[$k]=0;
              $fsize[$k]=0;
              $fctime[$k]=date("Y-m-d H:i:s");
              $futime[$k]=date("Y-m-d H:i:s");
              $fhash[$k]="";
              $pid[$k]=$i;         
               $k=$k+1;
               $j=$j+1;
             };//if filek
           };//while
       closedir($dh);
       };//if dh
     };//if isdir
   };//if ops
 };//for
 $totj=$j-1;
  //$j=2-----totj 是第二层的递增过程，他的基数是 TOTF,最大也就是TOTF+TOTJS
 $t=2;
// echo "totj=".$totj;
  for($m=2;$m<$totj+2;$m++){
      if (strpos($file[$totf+$m],'.')>0 || substr($file[$totf+$m],1,1)=='.'){
      }else{        
         if (is_dir($dir.$file[$pid[$totf+$m]]."/".$file[$totf+$m]."/")  and $file[$totf+$m]!="."  and $file[$totf+$m]!=".."){
              if ($dh = opendir($dir.$file[$pid[$totf+$m]]."/".$file[$totf+$m]."/")){
                while (($file[$k] = readdir($dh))!= false){
                  if ( $file[$k]!="."  and $file[$k]!=".."){
                    $filePath[$k] = $dir.$file[$pid[$totf+$m]]."/".$file[$totf+$m]."/".$file[$k];
                    $fsize[$k]=0;
                    $fctime[$k]=date("Y-m-d H:i:s");
                    $futime[$k]=date("Y-m-d H:i:s");
                    $fhash[$k]=""; 
                    $filenm[$k] = $file[$k];
                    $bz[$k]="[3]".$pid[$totf+$m].".".$m.".".$t;
                    $pid[$k]=($totf+$m)."";
                    $t=$t+1;
                    $j=$j+1;
                    $k=$k+1;
                   };//if filek
                };//while file
                closedir($dh);
             };//if dh
          };//if isdir
       };//if strpos
   };//for m=1
$totk=$k;
$fmbt="";
$fmbtb="";
$fmbtc="";
$fmtb="";
$fmbtx="";
for($p=2;$p<$totk;$p++){  
   $fpx=str_replace($dir,"/",$filePath[$p]);
   $fpx=str_replace("//","/",$fpx);
  if ($fpx!=""){ 
    $fmbtc=$fmbtc."{\"id\":\"".$p."\",\"name\":\"".$fpx."\",\"pid\":\"".$pid[$p]."\"},";   
    if (strpos($file[$p],".")>0){
    }else{   
      $fmbtx=$fmbtx."{\"id\":\"".$p."\",\"title\":\"".$fpx."\",\"pid\":\"".$pid[$p]."\"},";   
    }
   }
};
$fmbty="[{\"id\":\"1\",\"title\":\"".$ddd."全部文件\",\"pid\":\"-1\"},".substr($fmbtc,0,strlen($fmbtc)-1)."]";
$fmbty=str_replace("\"name\"","\"title\"",$fmbty);
$fmbtc="[".substr($fmbtc,0,strlen($fmbtc)-1)."]";
$fmbtx="[{\"id\":\"1\",\"title\":\"".$ddd."全部文件\",\"pid\":\"-1\"},".substr($fmbtx,0,strlen($fmbtx)-1)."]";
$nmd5=md5($fmbtc);
$conn=mysql_connect(gl(),glu(),glp());
$extmd5=updatings($conn,glb(),"select count(*) as result from coode_sitefile UPMD5='".$nmd5."'","utf8");
if ($extmd5*1==0){
$conn=mysql_connect(gl(),glu(),glp());
$xy=updatings($conn,glb(),"delete from coode_sitefile where length(UPMD5)=32","utf8");
 for($p=1;$p<$totk;$p++){  
  $fmtb=$fmtb."('".$file[$p]."','".$file[$p]."','','".str_replace($file[$p],"",str_replace($dir,"/",$filePath[$p]))."','".str_replace($dir,"/",$filePath[$p])."','".$fctime[$p]."','".$futime[$p]."','".$nmd5."','".$fsize[$p]."','".$flnr."','".onlymark()."','".$p."','".$pid[$p]."'),";
  if (intval($p/100)==($p/100)){
    $fmtb=substr($fmtb,0,strlen($fmtb)-1);  
    $conn=mysql_connect(gl(),glu(),glp());
    $x=updatings($conn,glb(),"insert into coode_sitefile(filename,filecname,fileexplain,folder,updateurl,CRTM,UPTM,UPMD5,filesize,filetext,OLMK,myid,parid)values".$fmtb,"utf8");
    $fmtb="";
   }
  };
 $fmtb=substr($fmtb,0,strlen($fmtb)-1);  
 $conn=mysql_connect(gl(),glu(),glp());
 $x=updatings($conn,glb(),"insert into coode_sitefile(filename,filecname,fileexplain,folder,updateurl,CRTM,UPTM,UPMD5,filesize,filetext,OLMK,myid,parid)values".$fmtb,"utf8");
};
if ($fff=="1"){
  echo $fmbtx;
}else{
 if ($fff=="2"){
  echo $fmbty;
 }else{
  echo $fmbtc;
 }
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>