<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tbrst=SX("select TABLE_NAME from coode_tablist");
$conn=mysql_connect(gl(),glu(),glp());
$result=selecteds($conn,"information_schema","select TABLE_NAME from COLUMNS where TABLE_SCHEMA='".glb()."' group by TABLE_NAME","utf8","");
$totr=countresult($result);
//4种不用你判断1(00),2(01),3(10),4(11)
      $filePath[1] ='系统表';
      $bz[1]="[1]";
      $pid[1]='0';
      $nid[1]='1';
      $filePath[2] ='erp表';
      $bz[2]="[2]";
      $pid[2]='0';
      $nid[2]='2';
      $filePath[3] ='app表';
      $bz[3]="[3]";
      $pid[3]='0';
      $nid[3]='3';
      $filePath[4] ='其他表';
      $bz[4]="[4]";
      $pid[4]='0';
      $nid[4]='4';
for ($k=0;$k<$totr;$k++){
      $filePath[$k+5] =anyvalue($result,"TABLE_NAME",$k);
      $filenm[$k+5] =anyvalue($result,"TABLE_NAME",$k);
      $bz[$k+5]="[1]".($k+1);
      if (strpos($tbrst,$filenm[$k+5])>0){
       $zz=UX("update coode_tablist set UPTM=now() where TABLE_NAME='".$filenm[$k+5]."'");
      }else{      
       $x=UX("insert into coode_tablist(TABLE_NAME,tabtitle,CRTM,UPTM,CRTOR,PTOF,VRT,OLMK,schm)values('".$filenm[$k+5]."','',now(),now(),'".$_COOKIE['uid']."','','','".date('Ymdhis').getRandChar(6)."','".glb()."')");
      }  
      $pid[$k+5]='4';
      $nid[$k+5]=$k+5;
      if (strpos(".".anyvalue($result,"TABLE_NAME",$k),'coode')>0){
       $pid[$k+5]='1';
       $nid[$k+5]=$k+5;
      };
      if (strpos(".".anyvalue($result,"TABLE_NAME",$k),'erp')>0){
       $pid[$k+5]='2';
       $nid[$k+5]=$k+5;
      };
      if (strpos(".".anyvalue($result,"TABLE_NAME",$k),'".$_COOKIE["cid"]."')>0){
        $pid[$k+5]='3';
        $nid[$k+5]=$k+5;
      };
}; 
$totk=$totr+4;
$fmbt="";
$fmbtb="";
$fmbtc="";
for  ($p=1;$p<=$totk;$p++){ 
  $fmbtc=$fmbtc."{\"id\":\"".$nid[$p]."\",\"name\":\"".$filePath[$p]."\",\"pid\":\"".$pid[$p]."\"},";
 };
$fmbtc="[".substr($fmbtc,0,strlen($fmbtc)-1)."]";
 if ($totk>0){
  $gqsl=UX("select count(*) as result from coode_tablist where timestampdiff(minute,UPTM,now())>30");
  if ($totk/($gqsl+1)>=5){
   $z=UX("delete from coode_tablist where timestampdiff(minute,UPTM,now())>30");  
   $bx=UX("delete from coode_keydetailx where TABLE_NAME not in(select TABLE_NAME from coode_tablist)");
   $by=UX("delete from coode_keydetaily where TABLE_NAME not in(select TABLE_NAME from coode_tablist)");
  }
 }
echo $fmbtc;
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>