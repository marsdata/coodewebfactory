<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $unitid=$_GET["unitid"];
$tinyid=$_GET["tinyid"];
if (strpos($unitid,".")>0){
 $domain=qian($unitid,".");
 $mark=hou($unitid,".");
 $tmpback="";
 if ($tinyid=="" or $tinyid=="un"."defined"){
   $trst=SX("select sysid,appid,unittitle,unitclass,unitdescrib,outurl,industry,business,matter,casecode,cssfilex,stylex,scriptx,jsfilex,cssfiley,jsfiley,styley,scripty,templatecode,demoresult,pagesurround from coode_domainunit where domainmark='".$domain."' and unitmark='".$mark."'");
   $appid="";
   $layid="";
 }else{
   $trst=SX("select sysid,appid,layid,unittitle,unitclass,unitdescrib,outurl,industry,business,matter,casecode,cssfilex,stylex,scriptx,jsfilex,cssfiley,jsfiley,styley,scripty,templatecode,demoresult,pagesurround from coode_unittiny where domainmark='".$domain."' and unitmark='".$mark."' and tinyid='".$tinyid."'");
   $appid=anyvalue($trst,"appid",0);
   $layid=anyvalue($trst,"layid",0);
 }
 $sysid=anyvalue($trst,"sysid",0);
 $tmpback=$tmpback."\"sysid\":\"".$sysid."\",";
 
 $tmpback=$tmpback."\"appid\":\"".$appid."\",";
 
 $tmpback=$tmpback."\"layid\":\"".$layid."\",";
 $unittitle=anyvalue($trst,"unittitle",0);
 $tmpback=$tmpback."\"unittitle\":\"".$unittitle."\",";
 $unitclass=anyvalue($trst,"unitclass",0);
 $tmpback=$tmpback."\"unitclass\":\"".$unitclass."\",";
 $unitdescrib=anyvalue($trst,"unitdescrib",0);
 $tmpback=$tmpback."\"unitdescrib\":\"".$unitdescrib."\",";
 $outurl=anyvalue($trst,"outurl",0);
 $tmpback=$tmpback."\"outurl\":\"".$outurl."\",";
 $industry=anyvalue($trst,"industry",0);
 $tmpback=$tmpback."\"industry\":\"".$industry."\",";
 $business=anyvalue($trst,"business",0);
 $tmpback=$tmpback."\"business\":\"".$business."\",";
 $matter=anyvalue($trst,"matter",0);
 $tmpback=$tmpback."\"matter\":\"".$matter."\",";
 $casecode=anyvalue($trst,"casecode",0);
 $tmpback=$tmpback."\"casecode\":\"".$casecode."\",";
 $cssfilex=anyvalue($trst,"cssfilex",0);
 $tmpback=$tmpback."\"cssfilex\":\"".$cssfilex."\",";
 $stylex=anyvalue($trst,"stylex",0);
 $tmpback=$tmpback."\"stylex\":\"".$stylex."\",";
 $scriptx=anyvalue($trst,"scriptx",0);
 $tmpback=$tmpback."\"scriptx\":\"".$scriptx."\",";
 $jsfilex=anyvalue($trst,"jsfilex",0);
 $tmpback=$tmpback."\"jsfilex\":\"".$jsfilex."\",";
 $cssfiley=anyvalue($trst,"cssfiley",0);
 $tmpback=$tmpback."\"cssfiley\":\"".$cssfiley."\",";
 $jsfiley=anyvalue($trst,"jsfiley",0);
 $tmpback=$tmpback."\"jsfiley\":\"".$jsfiley."\",";
 $styley=anyvalue($trst,"styley",0);
 $tmpback=$tmpback."\"styley\":\"".$styley."\",";
 $scripty=anyvalue($trst,"scripty",0); 
 $tmpback=$tmpback."\"scripty\":\"".$scripty."\",";
 $templatecode=anyvalue($trst,"templatecode",0);
 $tmpback=$tmpback."\"templatecode\":\"".$templatecode."\",";
 $demoresult=anyvalue($trst,"demoresult",0);
 $tmpback=$tmpback."\"demoresult\":\"".$demoresult."\",";
 $pagesurround=anyvalue($trst,"pagesurround",0);
 $tmpback=$tmpback."\"pagesurround\":\"".$pagesurround."\",";
 echo "{\"status\":\"1\",\"msg\":\"@succ\",".killlaststr($tmpback)."}";
}else{
 echo "{\"status\":\"0\",\"msg\":\"@fail\"}";
}
     session_write_close();
?>