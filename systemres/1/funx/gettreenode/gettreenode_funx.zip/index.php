<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $treemark=dftval($_GET["treemark"],"");
$treetype=dftval($_GET["treetype"],"");
if ($treetype=="node"){
$srd='{"code":"0","msg":"","count":"[count]","datax":[<data>]}';
}else{
$srd='{"code":"0","msg":"","count":"[count]","data":[<data>]}';
}
$item0='{id:"ajson[id]",parent:"[parent]",text:"[text]",state:{opend:true}},';
$item='{"orderNumber":"[sqx]","checked":[chk],"authority":"[authority]","authorityId":[id],"parentId":[pid],"menuIcon":"[menuicon]","menuUrl":"[menuurl]","isMenu":[imenu],"open":[open],"authorityName":"[restitle]","rmark":"[rmark]","restype":"[restype]","createTime":"[CRTM]","updateTime":"[UPTM]","rmturl":"[rmturl]"},';
$nrst=SX("select nodemark,nodecode,nodetitle,myid,parid,CRTM,UPTM,isend,isopen from coode_nodes where treemark='".$treemark."'");
  $fma="";
  $totd=countresult($nrst);
  for ($p=0;$p<$totd;$p++){
       $nodemark=anyvalue($nrst,"nodemark",$p);
      $nodecode=anyvalue($nrst,"nodecode",$p);
      $nodetitle=anyvalue($nrst,"nodetitle",$p);
      $myid=anyvalue($nrst,"myid",$p);
      $parid=anyvalue($nrst,"parid",$p);
      $crtm=anyvalue($nrst,"CRTM",$p);
      $uptm=anyvalue($nrst,"UPTM",$p);
      $isend=anyvalue($nrst,"isend",$p);
      $isopen=anyvalue($nrst,"isopen",$p);
      switch($treetype){
      case "node":
       $itemx=$item0;
       $itemx=str_replace("[id]",$myid,$itemx);
       $itemx=str_replace("[sqx]",($p+1),$itemx);
       $itemx=str_replace("[chk]","0",$itemx);
       $itemx=str_replace("[text]",$nodetitle,$itemx);
       
       
       $itemx=str_replace("[open]","true",$itemx);
       
       if (intval($parid)==-1){
        $itemx=str_replace("[parent]","#",$itemx);
       }else{
        $itemx=str_replace("[parent]","ajson".$parid,$itemx);
       }
       break;
      case "menu":
       $itemx=$item;
       $itemx=str_replace("[id]",$myid,$itemx);
       $itemx=str_replace("[sqx]",($p+1),$itemx);
       $itemx=str_replace("[chk]","0",$itemx);
       $itemx=str_replace("[authority]",$nodecode,$itemx);
       $itemx=str_replace("[menuicon]","null",$itemx);    
       $itemx=str_replace("[open]","true",$itemx);
       if ($restype=="folder"){
         $itemx=str_replace("[imenu]","0",$itemx);    
       }else{
         $itemx=str_replace("[imenu]","1",$itemx);    
       }
        $itemx=str_replace("[pid]",$parid,$itemx);
      break;  
      default:
     }      
     $itemx=str_replace("[rmark]",$rmark,$itemx);
     $itemx=str_replace("[restype]",$restype,$itemx);
     $itemx=str_replace("[CRTM]",$crtm,$itemx);
     $itemx=str_replace("[UPTM]",$uptm,$itemx);
     $itemx=str_replace("[menuurl]",$resrmturl,$itemx);
     $itemx=str_replace("[restitle]",$nodetitle,$itemx);
     $fma=$fma.$itemx;
  }
  $fma=killlaststr($fma);
  $srd=str_replace("<data>",$fma,$srd);
  $srd=str_replace("[count]",$totd,$srd);
  echo $srd;
     session_write_close();
?>