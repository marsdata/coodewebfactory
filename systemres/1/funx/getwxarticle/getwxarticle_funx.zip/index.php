<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $aid=dftval($_GET["aid"],"UCgLHD-Wbn-R2pDXd7YoWQ");
$urly="https://mp.weixin.qq.com/s/".$aid;
$urlx="https://mmbiz.qpic.cn/";
$urlz="//res.wx.qq.com/mmbizappmsg/zh_CN/htmledition/js/";
$bktxt=file_get_contents($urly);
$fmx="";
$pttxt=explode($urlx,$bktxt);
$totpt=count($pttxt);
for ($p=1;$p<$totpt;$p++){
  $tmpurl=qian($pttxt[$p],"\"");
  $olmkx=md5($tmpurl);
  $spath=combineurl(localroot(),"/localxres/funx/anytest/".$olmkx.".jpeg");
  $surl=combineurl("http://".glw(),"/localxres/funx/anytest/".$olmkx.".jpeg");
  if (tmpurl!=""){
    if (file_exists($spath)){
    }else{
     $kk=GrabImage($urlx.$tmpurl, $spath);
     
    }
    $bktxt=str_replace($urlx.$tmpurl,$surl,$bktxt);
    //echo $p."--".$urlx.$tmpurl."--".$olmkx."@@@@";
  }
}
$pttxt=explode($urlz,$bktxt);
$totpt=count($pttxt);
for ($p=1;$p<$totpt;$p++){
  $tmpurl=qian($pttxt[$p],"\"");
  $olmkx=md5($tmpurl);
  $kzmx=kuozhanming($tmpurl);
  $spath=combineurl(localroot(),"/localxres/funx/anytest/".$olmkx.".".$kzmx);
  $surl=combineurl("http://".glw(),"/localxres/funx/anytest/".$olmkx.".".$kzmx);
  if (tmpurl!=""){
    if (file_exists($spath)){
    }else{
     $bkfile=file_get_contents("http:".$urlz.$tmpurl);
     $zz=overfile($spath,$bkfile);     
    }
    $bktxt=str_replace($urlz.$tmpurl,$surl,$bktxt);    
  }
}
$bktxt=str_replace("https","http",$bktxt);
$bktxt=str_replace("data-src","src",$bktxt);
echo $bktxt;
     session_write_close();
?>