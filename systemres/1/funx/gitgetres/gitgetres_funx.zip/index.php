<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $tokenx="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";
$config = [
    'user'    => 'marsdata',
    'repo'    => 'coodewebfactory',
    'branch'  => 'master',
    'file'    => 'localxres/sysmap.json',
    'timeout' => 10
];
// 1. 调用 GitHub API 获取文件信息（含最后更新时间）
$api_url = "https://api.github.com/repos/{$config['user']}/{$config['repo']}/contents/{$config['file']}?ref={$config['branch']}";
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL            => $api_url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => $config['timeout'],
    CURLOPT_USERAGENT      => 'PHP-GitHub-File-Check',
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
]);
$api_response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
if ($http_code === 200) {
    $file_info = json_decode($api_response, true);
    
    echo "🔍 文件状态：\n";
    echo "文件分支：{$config['branch']}\n";
    echo "最后更新时间：{$file_info['commit']['committer']['date']}\n";
    echo "最后提交信息：{$file_info['commit']['message']}\n";
    echo "当前版本".$file_info['sha']."\n";
    echo "文件大小".$file_info['size']."\n";
    // 2. 再获取文件内容（确保是最新版）
    $raw_url = $file_info['download_url']; // API 返回的最新 Raw 地址
    $content = file_get_contents($raw_url);
    echo "\n✅ 最新文件内容：\n{$content}";
} else {
    die("❌ 验证失败：无法获取文件最新状态（HTTP {$http_code}）");
}
       session_write_close();
?>