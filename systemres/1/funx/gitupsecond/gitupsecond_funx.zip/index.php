<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      if ($_GET["runerr"]=="1"){
      }else{
       error_reporting(0);
       register_shutdown_function('zyfshutdownfunc'); 
       set_error_handler('zyferror'); 
      }
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       /**
 * PHP7.2 向 GitHub 提交/覆盖文件（自动处理 SHA 值）
 * 支持首次创建、二次覆盖同名文件
 */
$filepath=$_GET["filepath"];   //不带localroot的
$filepath=str_replace(localroot(),"",$filepath);
$fpath=getfilepath($filepath);
if (substr($fpath,0,1)=="/"){
  $fpath=substr($fpath,1,strlen($fpath)-1);
}
$fname=getfilename($filepath);
$fnamex=combineurl(localroot(),$filepath);
if (file_exists($fnamex)){
 $isfile=1;
}else{
 $isfile=0;
}
$des=date("Y-m-d H:i:s")."创建的".$filepath;
$apicode=$_GET["apicode"];
$comwrdid=$_GET["comwrdid"];
$apitxt=getapi($apicode);
$appid=qian($apitxt,"@");
$appsk=hou(qian($apitxt,":"),"@");
if ($comwrdid==""){
  $appse=hou($apitxt,":");
}else{
  $appse=$comwrdid;
}
//echo $appid."--".$appsk."--".$appse;
// ====================== 配置项（请修改）======================
$config = [
    'github_token' => $appsk,
    'owner'        => $appid,
    'repo'         => $appse,
    'target_dir'   => $fpath, // 如：docs/backup/
    'local_file'   => $fnamex,     // 如：./test.txt
    'commit_msg'   => 'Update '.$fname.' in '.$fpath,   // 如：Update test.txt in docs/backup/
];
// ====================== 工具函数：发送 GitHub API 请求 ======================
function sendGitHubRequest($url, $token, $method = 'GET', $postData = []) {
    $ch = curl_init();
    $options = [
        CURLOPT_URL            => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            "Authorization: token {$token}",
            "Accept: application/vnd.github.v3+json",
            "User-Agent: PHP7.2-GitHub-File-Upload",
        ],
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
    ];
    // 处理 POST/PUT 请求
    if ($method !== 'GET') {
        $options[CURLOPT_CUSTOMREQUEST] = $method;
        $options[CURLOPT_POSTFIELDS] = json_encode($postData);
    }
    curl_setopt_array($ch, $options);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    if ($error) {
        die("CURL 错误：{$error}\n");
    }
    $responseData = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        die("响应解析失败：{$response}\n");
    }
    return [
        'http_code' => $httpCode,
        'data'      => $responseData
    ];
}
// ====================== 核心逻辑 ======================
// 1. 验证配置和文件
if (empty($config['github_token']) or es($appid)*es($appsk)*es($appse)==0 or $isfile==0) {    
    echo makereturnjson("-1","错误：GitHub 令牌,文件名等参数或不全apicode=".$apicode."&isfile=".$isfile."&apitxt=".$apitxt,"");
}else{
  if (!file_exists($config['local_file'])) {    
    echo makereturnjson("-1","错误：本地文件 {$config['local_file']} 不存在","");
  }else{
   // 2. 构造文件路径
   $fileName = basename($config['local_file']);
   $apiPath = rtrim($config['target_dir'], '/') . '/' . $fileName;
   $apiUrl = "https://api.github.com/repos/{$config['owner']}/{$config['repo']}/contents/{$apiPath}";
   // 3. 第一步：获取文件当前的 SHA 值（文件不存在则返回 404）
   $shaResponse = sendGitHubRequest($apiUrl, $config['github_token']);
   $fileSha = null;  
    if ($shaResponse['http_code'] === 200) {
      // 文件已存在，获取 SHA 值
      $fileSha = $shaResponse['data']['sha'];      
      $fmerr="检测到文件已存在，SHA 值：{$fileSha}<br>"; 
    } else{
      $fmerr="获取文件 SHA 失败（HTTP {$shaResponse['http_code']}）<br>"; 
    }
    if ($shaResponse['http_code'] !== 404) {
      // 非 404 错误（如 401/403），直接报错     
       //echo makereturnjson($shaResponse['http_code'],$fmerr,"");        
          //.json_encode($shaResponse['data']);
          // 4. 读取文件并 Base64 编码
          $fileContent = file_get_contents($config['local_file']);
          $base64Content = base64_encode($fileContent);
         if ($base64Content === false) {
           $fmerr=$fmerr."错误：文件内容 Base64 编码失败<br>";
         }
         // 5. 构造提交数据（含 SHA 值，支持覆盖）
        $postData = [
         'message' => $config['commit_msg'],
         'content' => $base64Content,
        ];
        if ($fileSha) {
          $postData['sha'] = $fileSha; // 有 SHA 值则添加，实现覆盖
        }
        // 6. 第二步：提交/覆盖文件
          $uploadResponse = sendGitHubRequest($apiUrl, $config['github_token'], 'PUT', $postData);
        // 7. 处理提交结果
        if ($uploadResponse['http_code'] === 201) {
         $fmerr=$fmerr."√ 文件首次创建成功！<br>";
         $fmerr=$fmerr. "文件地址：{$uploadResponse['data']['content']['html_url']}";
         echo makereturnjson("1",$fmerr,"");
        } elseif ($uploadResponse['http_code'] === 200) {
         $fmerr=$fmerr."√文件覆盖成功！<br>";
         $fmerr=$fmerr."文件地址：{$uploadResponse['data']['content']['html_url']}<br>";
         $fmerr=$fmerr."版本历史：{$uploadResponse['data']['content']['html_url']}/history";
         echo makereturnjson("1",$fmerr,"");
        } else {
          $fmerr=$fmerr."×操作失败（HTTP {$uploadResponse['http_code']}）"; 
          //. json_encode($uploadResponse['data']) . "\n");
          echo makereturnjson("0",$fmerr,"");
        } 
    }else{
     
       //.json_encode($shaResponse['data']);
      // 4. 读取文件并 Base64 编码
      $fileContent = file_get_contents($config['local_file']);
      $base64Content = base64_encode($fileContent);
      if ($base64Content === false) {
        $fmerr=$fmerr."错误：文件内容 Base64 编码失败<br>";
      }
      // 5. 构造提交数据（含 SHA 值，支持覆盖）
     $postData = [
      'message' => $config['commit_msg'],
      'content' => $base64Content,
      ];
     if ($fileSha) {
      $postData['sha'] = $fileSha; // 有 SHA 值则添加，实现覆盖
     }
     // 6. 第二步：提交/覆盖文件
       $uploadResponse = sendGitHubRequest($apiUrl, $config['github_token'], 'PUT', $postData);
     // 7. 处理提交结果
     if ($uploadResponse['http_code'] === 201) {
       $fmerr=$fmerr."√ 文件首次创建成功！<br>";
       $fmerr=$fmerr. "文件地址：{$uploadResponse['data']['content']['html_url']}";
       echo makereturnjson("1",$fmerr,"");
     } elseif ($uploadResponse['http_code'] === 200) {
       $fmerr=$fmerr."√文件覆盖成功！<br>";
       $fmerr=$fmerr."文件地址：{$uploadResponse['data']['content']['html_url']}<br>";
       $fmerr=$fmerr."版本历史：{$uploadResponse['data']['content']['html_url']}/history";
       echo makereturnjson("1",$fmerr,"");
     } else {
        $fmerr=$fmerr."×操作失败（HTTP {$uploadResponse['http_code']}）"; 
        //. json_encode($uploadResponse['data']) . "\n");
        echo makereturnjson("0",$fmerr,"");
     } 
     //-------------------------------------------------------------------------------
    }//first404
  }//文件存不存在
}//参数全不全
       session_write_close();
?>