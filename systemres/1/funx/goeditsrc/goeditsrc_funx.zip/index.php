<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $sno=$_GET["SNO"];
$tinyid=$_GET["tinyid"];
$trst=SX("select tinymark,tempid,laypath,shortid,longexp from coode_tiny where SNO='".$sno."' or tinymark='".$tinyid."'");
$tinyid=anyvalue($trst,"tinymark",0);
$tempid=anyvalue($trst,"tempid",0);
$longexp=anyvalue($trst,"longexp",0);
$laypath=anyvalue($trst,"laypath",0);
$shortid=anyvalue($trst,"shortid",0);
if ($laypath!=""){
 if ($shortid!=""){
    $idrst=SX("select caseid,detailid from coode_shortdata where shortid='".$shortid."'");
    $caseid=anyvalue($idrst,"caseid",0);
    $detailid=anyvalue($idrst,"detailid",0);
    if (strpos($longexp,"anyjsshort")>0){
      $tmpid=$caseid; 
    }else{
      $tmpid=$detailid;
    }   
 }else{
   $tmpid=$tempid;   
 }
 header("location:/localxres/tempx/tinylayeditor/index.html?unitid=".$tmpid."&tinyid=".$tinyid);
}else{
 echo makereturnjson("0","不存在地址","");
}
       session_write_close();
?>