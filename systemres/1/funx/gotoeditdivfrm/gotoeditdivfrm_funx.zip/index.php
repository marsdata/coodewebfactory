<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $instmark=dftval($_GET["instmark"],"");
$expx=str_replace("@","=",dftval($_GET["expx"],""));
$frmmark=dftval($_GET["frmmark"],"");
$snox=UX("select SNO as result from coode_divfrmeles where instmark='".$instmark."' and frmmark='".$frmmark."' and mothersrd='".$expx."'");
if (intval($snox)>0){
  header("location:/localxres/tempx/htmleditor/index.html?funid=coode_divfrmeles@SNO:".$snox.".divcode");
}else{
 header("location:/localxres/funx/anyjsshort/?stid=nqoGWo-pnum:30-");
}
     session_write_close();
?>