<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $dumark=$_GET["dumark"];
$dm=qian($dumark,".");
$mk=hou($dumark,".");
$ext0=UX("select count(*) as result from coode_makeformact where domainmark='".$dm."' and unitmark='".$mk."'");
if (intval($ext0)==0){
 $sqlx="domainmark,unitmark,dumark,evaltype,CRTM,UPTM,CRTOR,OLMK";
 $sqly="'".$dm."','".$mk."','".$dm.".".$mk."','',now(),now(),'','".onlymark()."'";
 $bb=UX("insert into coode_makeformact(".$sqlx.")values(".$sqly.")");
 $snox=UX("select SNO as result from coode_makeformact where domainmark='".$dm."' and unitmark='".$mk."'");
}else{
 $snox=UX("select SNO as result from coode_makeformact where domainmark='".$dm."' and unitmark='".$mk."'");
}
header("location:/localxres/tempx/htmleditor/index.html?funid=coode_makeformact@SNO:".$snox.".evalcode");
     session_write_close();
?>