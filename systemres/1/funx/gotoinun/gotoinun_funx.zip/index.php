<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snox=_get("SNO");
$itype=_get("itype");
$hrst=SX("select sysid,sysname,VRT from coode_hostregsys where SNO=".$snox);
$sysid=anyvalue($hrst,"sysid",0);
$vrt=anyvalue($hrst,"VRT",0);
if ($itype=="1"){
  header("location:/localxres/pagex/1/humanmachine/gW6PYqg8/X4cIJk/index.html?sysid=".$sysid);
}else{
  if ($vrt!="locked"){
    header("location:/localxres/pagex/1/humanmachine/fd3rqLWv/Gn22Wa/index.html?sysid=".$sysid);
  }else{
    header("location:/localxres/pagex/1/humanmachine/fd3rqLWv/Gn22Wa/index.html?rnd=".onlymark());
  }
}
     session_write_close();
?>