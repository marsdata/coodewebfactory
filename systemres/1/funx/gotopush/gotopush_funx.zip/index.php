<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $url="/localxres/funx/anyshortnew/?stid=QVKyRS&SNO=0&";
    if ( $_SERVER['SERVER_PORT']=="80"){     
      $fromhost=$_SERVER["HTTP_HOST"];    
    }else{
      $fromhost=$_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"];
    }
//$url=$url."fromhost=".$fromhost;
$restype=_get("restype");
$rescode=_get("rescode");
$url=$url."restype=".$restype;
$url=$url."&resid=".$rescode;
$url=$url."&vermd5=".onlymark();
header("location:".$url);
     session_write_close();
?>