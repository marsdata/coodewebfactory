<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $pd=array();
$url="http://spccode.com/gptplus.php";
$askstrx=$_POST["askstr"];
$pd["askstr"]=$askstrx;
$bktxt=request_post($url,$pd);
$datax=json_decode($bktxt,false);
$status=$datax->code;
$datay=$datax->data;
$htmlx=$datay->html;
$htmlz=$htmlx;
$htmlz=str_replace("\n","\r\n",$htmlz);
$caption=dftval($_GET["caption"],"");
$sqlx="myquestion,gptanswer,apikey,asktime,askman,caption";
$sqly="'".gohex($askstrx)."','".gohex($htmlz)."','".gla()."',now(),'".$_COOKIE["uid"]."','".$caption."'";
echo $bktxt;
if (intval($status)==200){
  if ($htmlx!="null" and $caption!=""){
    $zz=UX("insert into coode_chatgptqa(".$sqlx.")values(".$sqly.")");
  }
  //echo str_replace("获取成功","Success-".date("Y-m-d H:i:s"),$bktxt);
  //echo '{"code":200,"htmlcode":"'.gohex($htmlx).'"}';
}else{
  //echo '{"code":0,"msg":"未获取成功:'.date("Y-m-d H:i:s").'"}';
}
     session_write_close();
?>