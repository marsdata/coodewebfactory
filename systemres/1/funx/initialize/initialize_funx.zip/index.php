<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      if ($_GET["runerr"]=="1"){
      }else{
       error_reporting(0);
       register_shutdown_function('zyfshutdownfunc'); 
       set_error_handler('zyferror'); 
      }
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       eval(RESFUNSET("userinfo"));
$zz0=newrole("god","上帝","universe","universe");
$zz1q=newuser("admin","123456","universe","上帝超管","god,","","universe");
$zz2q=newuser("hellowocao","woailiaolan3.14","universe","人类超管","god,","","universe");
$z0=UX("update coode_keydetailx set TABLE_SCHEMA='".glb()."'");
$z1=UX("update coode_keydetaily set TABLE_SCHEMA='".glb()."'");
$z2=UX("update coode_keydetailz set TABLE_SCHEMA='".glb()."'");
$z3=UX("update coode_tablist set schm='".glb()."'");
if (glm()!="motherhost"){
 $bkshort=anyfunrun("anyshort",glm(),"stid=coodesys&pnum=99&page=1","");
 $bkjson=json_decode($bkshort,false);
 $totrcd=$bkjson->totrcd;
 $vls=$bkjson->vls;
 $sqlx="restypecode,restypetitle,typedescrib,headpic,midpic,numx,relyotherres,localsavepath,CRTM,UPTM,OLMK,CRTOR";
 for ($jj=0;$jj<$totrcd;$jj++){
   $tpcode=$vls[$jj]->restypecode;
   $tptitle=$vls[$jj]->restypetitle;
   $tpdescrib=$vls[$jj]->typedescrib;
   $headpic=$vls[$jj]->headpic;
   $midpic=$vls[$jj]-midpic;
   $numx=$vls[$jj]-numx;
   $rothers=$vls[$jj]-relyotherres;
   $lcpath=$vls[$jj]-localsavepath;
   $sqly="'".$tpcode."','".$tptitle."','".$tpdescrib."','".$headpic."','".$midpic."','".$numx."','".$rothers."','".$lcpath."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."'";
   $exttp=UX("select count(*) as result from coode_sysrestypedefine where restypecode='".$tpcode."'");
   if (intval($exttp)==0){
     $zz=UX("insert into coode_sysrestypedefine(".$sqlx.")values(".$sqly.")");
   }
 }
}
echo makereturnjson("1","系统数据初始化成功","");
       session_write_close();
?>