<?php
function gl(){return "[cdip]";}//DESCRIB glb():本系统mysql 数据库IP END@glb()
function glu(){return "[cduser]";}//DESCRIB glu():本系统mysql 数据库用户名 END@glu()
function glp(){return "[cdpass]";}//DESCRIB glp():本系统mysql 数据库密码 END@glp()
function glb(){return "[cdbase]";}//DESCRIB glb():本系统mysql 数据库 END@lgb()
function gln(){return "[firstsys]";}//DESCRIB gln():当前使用系统名称 END@gln()
function gla(){return "[ak]";}//DESCRIB gla():当前apikey END@gln()
function glv(){return "[av]";}//DESCRIB glv():当前api verfy 使用系统版本号 END@gln()
function glt(){return "[sitename]";}//DESCRIB glt():当前实例名称 END@glt()
function glm(){return "[motherhost]";}//DESCRIB glm():母系统域名 END@glt() localhost 为本地模式不联网
function hostcode(){return "[hostcode]";}//DESCRIB glr():授权注册码 END@glt() 申请试用后，提供服务器IP地址，给您安装，转移操作
function runblog(){return "[runblog]";}//日志记录是否开启
function runprocess(){return "[runprocess]";}//日志记录是否开启
function remoteway(){return "[remoteway]";}//远程模式，可以上传资源到母机
function bl(){return "[bdip]";}//DESCRIB glb():业务系统mysql 数据库IP END@glb()
function blu(){return "[bduser]";}//DESCRIB glu():业务系统mysql 数据库用户名 END@glu()
function blp(){return "[bdpass]";}//DESCRIB glp():业务系统mysql 数据库密码 END@glp()
function blb(){return "[bdbase]";}//DESCRIB glb():业务系统mysql 数据库 END@lgb()
function bln(){return "[secondsys]";}//DESCRIB gln():当前业务使用系统名称 END@gln()
function blt(){return "[bussname]";}//DESCRIB glt():当前实例名称 END@glt()
//-------------配置分界线
function _get($str){ $val = !empty($_GET[$str]) ? $_GET[$str] : ""; return $val; } //DESCRIB ():  END@()

function _cookie($str){$val = !empty($_COOKIE[$str]) ? $_COOKIE[$str] : ""; return $val; }//DESCRIB ():  END@()

function combineurl($qu,$hu){if (substr($qu,-1)=="/"){$qu=killlaststr($qu);}if (substr($hu,0,1)=="/"){return $qu.$hu;}else{return $qu."/".$hu;}}//DESCRIB ():  END@()

function getRandChar($length){$str = null;$strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";$max = strlen($strPol)-1;for($i=0;$i<$length;$i++){$str.=$strPol[rand(0,$max)]; }return $str;}

function hou($fullstr,$astr){if ($fullstr!="" and $astr!=""){$cunzaibu=strpos("x".$fullstr,$astr);if ($cunzaibu>0 ){$spos=strpos($fullstr,$astr);$lens=strlen($astr);$alll=strlen($fullstr);return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));}else{return $fullstr;};}else{return "";}}//DESCRIB (): 完美兼容中文混合取字符串后面 END@()

function killlaststr($strx){ return substr($strx,0,strlen($strx)-1);}

function localroot(){if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){$gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";}else{$gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);};if (strpos($gml,":")>0){$qdq=qian($gml,":");$gml=strtoupper($qdq).":".hou($gml,":");};return $gml;}//DESCRIB localroot(): 获取本地根目录 END@localroot()

function qian($fullstr,$astr){if ($fullstr!="" and $astr!=""){$cunzaibu=strpos("x".$fullstr,$astr);if ($cunzaibu>0 ){$astrlen=strpos($fullstr,$astr);$fmrt=substr($fullstr,0,$astrlen);return $fmrt;}else{return $fullstr;}}else{return "";}}//DESCRIB qian(): 完美兼容中文混合 END@qian()

function String2Hex($string){if (substr($string,0,10)=="dTYPE_HEX:"){return $string;}else{$hex='';for ($i=0; $i < strlen($string); $i++){$hex .= dechex(ord($string[$i]));}return $hex;}}

function UX($asqlstr){$conn=mysql_connect(gl(),glu(),glp());return updatings($conn,glb(),$asqlstr,"utf8");}//DESCRIB ():  END@()

function onlymark(){
   return makeguid();
}//DESCRIB ():  END@()


function es($strx){
    $strx=str_replace(" ","",$strx);
    $strx=str_replace("un"."defined","",$strx);
    if ($strx!=""){
        return 1;
    }else{
        return 0;
    }
}

function spacex($nx){
    $tmpx="";
    for ($i=0;$i<$nx;$i++){
        $tmpx=$tmpx." ";
    }
    return $tmpx;
}


function overfile($fnm,$ftxt){
  $lsx=explode("/",$fnm);
  $totls=count($lsx);
  $frt=str_replace($lsx[$totls-1],"",$fnm);
  is_dir($frt) OR mkdir($frt, 0777, true); 
 $myfile = fopen($fnm, "w") or die("Unable to open file!");
 $txt = $ftxt;
 fwrite($myfile, $txt);
 fclose($myfile);
 return 1;
}

function file(){
       $data = implode('', $this -> datasec);
       $ctrldir = implode('', $this -> ctrl_dir);
       return
         $data .
         $ctrldir .
         $this -> eof_ctrl_dir .
         pack('v', sizeof($this -> ctrl_dir)) .
         pack('v', sizeof($this -> ctrl_dir)) .
         pack('V', strlen($ctrldir)) .
         pack('V', strlen($data)) .
         "x00x00";
 }
   
function TX($tsql){
    if ($tsql!=""){
     $keyx=qian(hou($tsql,"elect"),"from");
     $keyx=str_replace(" ","",$keyx);
     if (strpos($tsql,"limit")>0){
        $pnumx=hou(hou($tsql,"limit"),",");
     }else{
        $pnumx="30";
     }
     $ptkx=explode(",",$keyx);
     $totp=count($ptkx);
     $headx="";
     $bodyx="";
     for ($i=0;$i<$totp;$i++){
        $mykey[$i]=qian($ptkx[$i],"@");
        $mytit[$i]=qian(hou($ptkx[$i],"@"),"(");
        $mytype[$i]=qian(hou($ptkx[$i],"("),")");
        $headx=$headx.$mykey[$i]."#-#";
     }
     $headx=$headx."#/#";
     for ($j=0;$j<intval($pnumx);$j++){
        for ($i=0;$i<$totp;$i++){
         $bodyx=$bodyx.gettestvalue($j,$mykey[$i],$mytit[$i],$mytype[$i])."#-#";
        }
        $bodyx=$bodyx."#/#";
     }
     return $headx.$bodyx;
    }else{
     return "ERROR#/#NO SQLSTR";   
    }
}


function NS($datamark,$datatitle,$kdefine){
  $extds=UX("select count(*) as result from coode_dataspace where datamark='".$datamark."'");
  if (intval($extds)==0){
    $ptkdf=explode(",",$kdefine);
    $toto=count($ptkdf);
    $srcid=$datamark;
    $srcarea="";
    $sqla="datamark,datatitle,CRTM,UPTM,CRTOR,OLMK";
    $sqlb="'$datamark','$datatitle',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";
    $zab=UX("insert into coode_dataspace(".$sqla.")values(".$sqlb.")");
    if ($srcid!=""){
     $strudemo='{"dspccode":"[dspccode]","dspctitle":"[dspctitle]","keynames":"[keynames]","ktps":[<kdata>]}';
     $itemdemo='{"keyname":"[keyname]","keytitle":"[keytitle]","dxtype":"[dxtype]","datatype":"[datatype]","keylen":"[keylen]"},';
     $strudemo=str_replace("[dspctitle]",$datatitle,$strudemo);
     $fma="";
      for ($bb=0;$bb<intval($toto);$bb++){
        $titlex=qian($ptkdf[$bb],"(");  
        $orgid=getRandChar(8);
        //String2Hex($titlex);
        $otypex=qian(hou($ptkdf[$bb],"("),")");
           switch($otypex){
            case "tinyint":
            $keytype="tinyint";
            $keylen="4";
            break;
            case "int":
            $keytype="int";
            $keylen="11";
            break;
            case "varchar20":
            $keytype="varchar";
            $keylen="20";
            break;
            case "varchar50":
            $keytype="varchar";
            $keylen="50";
            break;
            case "varchar100":
            $keytype="varchar";
            $keylen="100";
            break;
            case "varchar255":
            $keytype="varchar";
            $keylen="255";
            break;
            case "varchar1024":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "decimal1":
            $keytype="decimal";
            $keylen="10.1";
            break;
            case "decimal2":
            $keytype="decimal";
            $keylen="10.2";
            break;
            case "decimal3":
            $keytype="decimal";
            $keylen="10.3";
            break;
            case "decimal4": 
            $keytype="decimal";
            $keylen="10.4";
            break;
            case "select":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "multiselect":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "checkbox":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "multicheckbox":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "imagex":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "images":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "filex":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "files":
            $keytype="varchar";
            $keylen="1024";
            break;
          }
        $itemx=$itemdemo;
        $itemx=str_replace("[keyname]",$orgid,$itemx);
        $itemx=str_replace("[keytitle]",$titlex,$itemx);
        $itemx=str_replace("[dxtype]",$otypex,$itemx);
        $itemx=str_replace("[datatype]",$keytype,$itemx);
        $itemx=str_replace("[keylen]",$keylen,$itemx);
        $fma=$fma.$itemx;
        if ($titlex!="" and $titlex!="undefined"){
           $extx=UX("select count(*) as result from coode_dspckey where domainmark='".$srcarea."' and datamark='".$srcid."' and keytitle='".$titlex."' ");
           if (intval($extx)==0){
             $z=UX("insert into coode_dspckey(domainmark,datamark,dxtype,keytype,keylen,keymark,keytitle,CRTM,UPTM,CRTOR)values('".$srcarea."','".$srcid."','".$otypex."','".$ktype."','".$keylen."','".$orgid."','".$titlex."',now(),now(),'".$_COOKIE["uid"]."')");         
           }else{
             $z=UX("update coode_dspckey set UPTM=now(),dxtype='".$otypex."',keytype='".$keytype."',keylen='".$keylen."' where domainmark='".$srcarea."' and datamark='".$srcid."' and keytitle='".$titlex."' ");
           }   
         }
       }
       $fma=killlaststr($fma);
       $strudemo=str_replace("[kdata]",$fma,$strudemo);
       if ($srcid!=""){
        $strujson=combineurl(localroot(),"/localxres/dataspacex/".$srcid."/","structure.json");       
        $zz=overfile($strujson,$strudemo);
       }
       $bb=UX("delete from coode_dspckey where timestampdiff(second,UPTM,now())>30 and domainmark='".$srcarea."' and datamark='".$srcid."' ");    
       $sqlx="domainmark,datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib,CRTM,UPTM,CRTOR,OLMK";
       $zzx=UX("insert into coode_dspckeyx(".$sqlx.")select ".$sqlx." from coode_dspckey where datamark='".$datamark."' and concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey where datamark='".$datamark."')");
       $bbx=UX("delete from coode_dspckeyx where concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey)");
       $zzy=UX("insert into coode_dspckeyy(".$sqlx.")select ".$sqlx." from coode_dspckey where datamark='".$datamark."' and concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey where datamark='".$datamark."')");
       $bby=UX("delete from coode_dspckeyy where concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey)");
       $zzz=UX("insert into coode_dspckeyz(".$sqlx.")select ".$sqlx." from coode_dspckey where datamark='".$datamark."' and concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey where datamark='".$datamark."')");
       $bbz=UX("delete from coode_dspckeyz where concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey)");
       //在表单表格显示中计算xyz的文件structurex.json
       return 1;
     }else{
        return 0;
     }
    }else{
       return 0;
    }
}
//删除一个结构


?>