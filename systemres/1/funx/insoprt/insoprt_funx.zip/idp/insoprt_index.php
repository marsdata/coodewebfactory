<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
   error_reporting(0);
   register_shutdown_function('zyfshutdownfunc'); 
   set_error_handler('zyferror'); 
   include 'insoprt_base.php';          
   $way=$_GET["way"];
$motherhost=$_GET["motherhost"];
$sscode=$_GET["sscode"];
switch($way){
  case "getres"
  $tabtxt=file_get_contents("http://".$motherhost."/localxres/funx/anyshort/?stid=asS6C&pnum=30");
  $tabdata=json_decode($tabtxt,false);
  $vls=$tabdata->vls;
  for ($ii=0;$ii<count($vls);$ii++){
   $crtsql=$vls[$ii]->createsql;
   $conn=mysql_connect(gl(),glu(),$glp());
   $zz=updatingx($conn,glb(),$crtsql,"utf8");
  }
  echo file_get_contents("http://".$motherhost."/localxres/funx/askinstall/?ssmark=".$ssmark);
  
  break;
  case "fnsres":
  $restype=$_GET["restype"];
  $rescode=$_GET["rescode"];
  echo file_get_contents("http://".$motherhost."/localxres/funx/fnsinstall/?ssmark=".$ssmark."&rescode=".$rescode."&restype=".$restype);
  break;
  default;
}
          
?>