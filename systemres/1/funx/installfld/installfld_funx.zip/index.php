<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       eval(RESFUNSET("resrelyrp"));
eval(RESFUNSET("tabdataoprt"));
eval(RESFUNSET("dspbasecoprt"));
   
   $restype=$_GET["restype"];
   $rescode=$_GET["rescode"];
   $sysid=$_GET["sysid"];
   $vermd5=$_GET["vermd5"];
function tornx($txx){
  if ($txx==true){
   return 1;
  }else{
   return 0;
  }
}
$succx=0;
 if (es($restype)*es($rescode)==1){
     
   switch($restype){
    case "pagex":
     
     $newurl=combineurl(localroot(),"/install/resjar/pagex/".$rescode."_pagex.zip");
     $newpath=combineurl(localroot(),"/remotexres/receive/pagex/".$rescode."/");
    break;
    case "tempx":
    
    $newurl=combineurl(localroot(),"/install/resjar/tempx/".qian($rescode,".")."_tempx.zip");
    $newpath=combineurl(localroot(),"/remotexres/receive/tempx/".qian($rescode,".")."/");
    $tarpath=combineurl(localroot(),"/localxres/tempx/".qian($rescode,".")."/"); 
    break;
    default:
    
    $newurl=combineurl(localroot(),"/install/resjar/".$restype."/".str_replace(".","_",$rescode)."_".$restype.".zip");
    $newpath=combineurl(localroot(),"/remotexres/receive/".$restype."/".qian($rescode,".")."/");
    $tarpath=combineurl(localroot(),"/localxres/".$restype."/".qian($rescode,".")."/"); 
   }
   $err="";
    $kk=unlink($newurl);
    $kk2=deltree($newpath);
    $zz=unzip($newurl,$newpath);
    
  
    switch($restype){
     case "pagex":
      $jsonf0=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-resdata.json");
      $uu=takevaljson($jsonf0);
      $succx=$succx+tornx($uu);
      $jsonf1=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-pagedata.json");
      $uu=takevaljson($jsonf1);
      $succx=$succx+tornx($uu);
      $jsonf2=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-app.json");
      $uu=takevaljson($jsonf2);
      $succx=$succx+tornx($uu);
      $jsonf3=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-lay.json");
      $uu=takevaljson($jsonf3);
      $succx=$succx+tornx($uu);
      $jsonf4=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-temp.json");
      $uu=takevaljson($jsonf4);
      $succx=$succx+tornx($uu);
      $trst=SX("select sysid,appid,layid,tempid from coode_tiny where tinymark='".$rescode."'");
      $totx=countresult($trst);
      $sysid=anyvalue($trst,"sysid",0);
      $appid=anyvalue($trst,"appid",0);
      $layid=anyvalue($trst,"layid",0);
      $tempid=anyvalue($trst,"tempid",0);
      if ($totx>0){
        if ($tempid!=""){
         $tarpath=combineurl(localroot(),"/localxres/pagex/".qian($tempid,".")."/".$rescode."/"); 
        }else{
         $tarpath=combineurl(localroot(),"/localxres/pagex/seedx/".$rescode."/"); 
        }
      }else{
       $tarpath="";
      }
     break;
     case "tabx":
     $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
     $relytxt=file_get_contents($relyresurl);
     $relydata=json_decode($relytxt,false);        
     $crtsql=$relydata->crtsql;
        $z0=crttab(0,$crtsql);
     $vls=$relydata->vls;
     for ($j=0;$j<count($vls);$j++){
      $verx=$vls[$j]->resmd5;
      $jsonf=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$verx.".json"); 
      $uu=takevaljson($jsonf);
      $succx=$succx+tornx($uu);
     }
     $zz=anyfunrun("initialize","","","");
     break;
     case "formx":
     $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
     $relytxt=file_get_contents($relyresurl);
     $relydata=json_decode($relytxt,false);
     $vls=$relydata->vls;
     for ($j=0;$j<count($vls);$j++){
      $verx=$vls[$j]->resmd5;
      $jsonf=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$verx.".json"); 
      $uu=takevaljson($jsonf);
      $succx=$succx+tornx($uu);
     }
     
     break;
     case "plotx":
     $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
     $relytxt=file_get_contents($relyresurl);
     $relydata=json_decode($relytxt,false);
     $vls=$relydata->vls;
     for ($j=0;$j<count($vls);$j++){
      $verx=$vls[$j]->resmd5;
      $jsonf=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$verx.".json"); 
      $uu=takevaljson($jsonf);
      $succx=$succx+tornx($uu);
     }
     break;
     case "groupx":
     $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
     $relytxt=file_get_contents($relyresurl);
     $relydata=json_decode($relytxt,false);
     $vls=$relydata->vls;
     for ($j=0;$j<count($vls);$j++){
      $verx=$vls[$j]->resmd5;
      $jsonf=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$verx.".json"); 
      $uu=takevaljson($jsonf);
      $succx=$succx+tornx($uu);
     }
     break;
     case "dataspacex":
     $kk0=UX("delete from coode_dataspace where datamark='".$rescode."'");
     $kk1=UX("delete from coode_dspckey where datamark='".$rescode."'");
     $kk0=UX("delete from coode_dspcvindex where datamark='".$rescode."'");
     $kk1=UX("delete from coode_dspckeyx where datamark='".$rescode."'");
     $kk1=UX("delete from coode_dspckeyy where datamark='".$rescode."'");
     $kk1=UX("delete from coode_dspckeyz where datamark='".$rescode."'");
     
     
     $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
     $relytxt=file_get_contents($relyresurl);
     $relydata=json_decode($relytxt,false);
     $vls=$relydata->vls;
     for ($j=0;$j<count($vls);$j++){
      $verx=$vls[$j]->resmd5;
      $jsonf=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$verx.".json"); 
      $uu=takevaljson($jsonf);
      $succx=$succx+tornx($uu);
     }
     $jsfile=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/jsshort.json");
     $jsshort=file_get_contents($jsfile);
     $jsdata=json_decode($jsshort,false);
     $ktps=$jsdata->keytps;
     $vls=$jsdata->vls;
     $fmktp="";
     for ($kk=0;$kk<count($ktps);$kk++){
       $keyid=$ktps[$kk]->keyid;
      if ($keyid!="datasno"){
        $fmktp=$fmktp.$ktps[$kk]->keyid."&";
      }
     }
     $fmktp=killlaststr($fmktp);
     for ($ii=0;$ii<count($vls);$ii++){
      $fmvls="";
      for ($kk=0;$kk<count($ktps);$kk++){
        $tmpvx="";
        $keyid=$ktps[$kk]->keyid;
        if ($keyid!="datasno"){
        
        eval('$tmpvx=$vls[$ii]->'.$keyid.';');
        $fmvls=$fmvls.$keyid."=".$tmpvx."&";
        }
      }
      $fmvls=killlaststr($fmvls);
      $nn=ND($rescode,$fmktp,$fmvls);
     }
     $xx=UX("insert into coode_dspckeyx(domainmark,datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib)select domainmark,datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib from coode_dspckey where datamark='".$rescode."'");
     break;
     default:
      $jsonf=combineurl(localroot(),"/remotexres/receive/".$restype."/".qian($rescode,".")."/".str_replace(".","_",$rescode)."_".$restype."-resdata.json");
      $uu=takevaljson($jsonf);
      $succx=$succx+tornx($uu);
   }
    if ($tarpath!=""){    
      $zz=copy_underdir($newpath,$tarpath);
     if ($restype=="tempx" or $restype=="pagex"){
      $localcss=combineurl(localroot(),"/localxres/csspagex/");     
      $zz1=copy_underdir($tarpath,$localcss);
      $zxc=deletefiles($localcss,0);//删除其余文件
       if ($restype=="pagex"){
         $myurl=combineurl("http://".glw(),"/localxres/funx/maketinytounit/?tinyid=".$rescode."&newdo=tempx");
         $zz=file_get_contents($myurl);      
       }
     }
    }
  
  
    $sqla="insmark,institle,rescode,restype,restitle,vermd5,sysid,CRTM,UPTM,OLMK,STATUS";
    $sqlb="'".date("Y-m-d")."','".getip()."','".$rescode."','".$restype."','".$rescode."','".$vermd5."','".$sysid."',now(),now(),'".onlymark()."',1";
    $zz=UX("insert into coode_installdetail(".$sqla.")values(".$sqlb.")");
  
  echo makereturnjson("1","成功安装".$succx."条。".$err,"");
}else{
  echo makereturnjson("0","安装失败-参数不全-".$fromhost."/".$restype."/".$rescode,"");
}
       session_write_close();
?>