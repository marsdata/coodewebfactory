<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
        $rescode=_get("rescode");
 $restype=_get("restype");
 $instcode=_get("instcode");
 $stt="0";
 if (es($rescode)*es(restype)*es($instcode)==1){
  $fbres=SX("select SNO,newcode,newtitle from coode_fbinstres where instcode='".$instcode."' and restype='".$restype."' and rescode='".$rescode."'");
  $totres=countresult($fbres);
  $stt="1";
  $msg="生成成功";
  if ($totres>0){
   $newcode=anyvalue($fbres,"newcode",0);
   $newtitle=anyvalue($fbres,"newtitle",0);
   switch($restype){
     case "tabx":
     $trst=SX("select tabnick,createsql from coode_fbtabdefine where tabnick='".$rescode."'");
     $tabsql=anyvalue($trst,"createsql",0);
     if ($tabsql!=""){
      $conn=mysql_connect(gl(),glu(),glp());
      $tabsql=str_replace("[tabnick]",$newcode,$tabsql);
      $zn=updatingx($conn,glb(),$tabsql,"utf8");
            
      $sqlx="'".$newcode."',rescode,imghead,worldmarks,restpcode,resenword,reschiword,allkeys,mainsqx,subsqx,olmkkey,areakey,md5key,createsql,contentkeys,jsonconts,keynames,keytpnms,jsontpnms,srckey,srcttk,parreskey,aitkey,aivkey,issys,ispmiss,'".$newtitle."',tabtype,tabcls,sysid,keylens,sizetype,grpmark,vermd5,hasshort,beforeview,ickey,iwkey,copyrightmark,STATUS,OLMK,CRTM,UPTM";
      $sqly="TABLE_NAME,rescode,imghead,worldmarks,restpcode,resenword,reschiword,allkeys,mainsqx,subsqx,olmkkey,areakey,md5key,createsql,contentkeys,jsonconts,keynames,keytpnms,jsontpnms,srckey,srcttk,parreskey,aitkey,aivkey,issys,ispmiss,tabtitle,tabtype,tabcls,sysid,keylens,sizetype,grpmark,vermd5,hasshort,beforeview,ickey,iwkey,copyrightmark,STATUS,OLMK,CRTM,UPTM";
      $zz=UX("insert into coode_tablist(".$sqly.")select ".$sqlx." from coode_fbtabdefine where tabnick='".$rescode."'");         
      
      $sqlc="'".$newcode."',acthtml,aftdel,aftist,aftupd,appid,atnhtml,bfdel,bfist,bfupd,changeable,CHARACTER_MAXIMUM_LENGTH,CHARACTER_OCTET_LENGTH,CHARACTER_SET_NAME,classp,clstxt,COLLATION_NAME,COLUMN_COMMENT,COLUMN_DEFAULT,COLUMN_KEY,COLUMN_NAME,COLUMN_TYPE,CRTM,CRTOR,DATA_TYPE,DATETIME_PRECISION,displayed,dxtype,EXTRA,isfixed,IS_NULLABLE,jspostfun,jsshowfun,keyexplain,keytitle,NUMERIC_PRECISION,NUMERIC_SCALE,OLMK,ORDINAL_POSITION,parallelto,PRIME,PRIVILEGES,PTOF,rescode,RIP,shortid,SQX,STATUS,STCODE,sysid,syspostfun,sysshowfun,TABLE_CATALOG,TABLE_SCHEMA,tdcode,tdomain,tgroup,thcode,UPTM,valuezero,vermd5,VQX,VRT";
      $sqld="TABLE_NAME,acthtml,aftdel,aftist,aftupd,appid,atnhtml,bfdel,bfist,bfupd,changeable,CHARACTER_MAXIMUM_LENGTH,CHARACTER_OCTET_LENGTH,CHARACTER_SET_NAME,classp,clstxt,COLLATION_NAME,COLUMN_COMMENT,COLUMN_DEFAULT,COLUMN_KEY,COLUMN_NAME,COLUMN_TYPE,CRTM,CRTOR,DATA_TYPE,DATETIME_PRECISION,displayed,dxtype,EXTRA,isfixed,IS_NULLABLE,jspostfun,jsshowfun,keyexplain,keytitle,NUMERIC_PRECISION,NUMERIC_SCALE,OLMK,ORDINAL_POSITION,parallelto,PRIME,PRIVILEGES,PTOF,rescode,RIP,shortid,SQX,STATUS,STCODE,sysid,syspostfun,sysshowfun,TABLE_CATALOG,TABLE_SCHEMA,tdcode,tdomain,tgroup,thcode,UPTM,valuezero,vermd5,VQX,VRT";
      $zz2=UX("insert into coode_keydetailx(".$sqld.")select ".$sqlc." from coode_fbkeydx where tabnick='".$rescode."'");      
      
     }
     break;
     case "formx":
       $fmrst=SX("select SNO,tabnick from coode_fbform where shortid='".$rescode."'");
       $oldtab=anyvalue($fmrst,"tabnick",0);
       $newtab=UX("select newcode as result from coode_fbinstres where instcode='".$instcode."' and rescode='".$oldtab."' and restype='tabx'");
       $sqlx="datahost,sysid,retrievekey,caseid,caseext,detailid,detailext,vermd5,allkeys,showkeys,skeys,frmexp,sqlbody,cdt,extc,orddt,lang,dttp,jsonid,keyitem,issys,fileurl,addtitle,addpage,heightx,widthx,fixed,lastvisit,tabcls,schm,OLMK,UPTM,CRTM";
       $zz=UX("insert into coode_shortdata(tabnick,tablename,shortid,shorttitle,".$sqlx.")select '','".$newtab."','".$newcode."','".$newtitle."',".$sqlx." from coode_fbform where shortid='".$rescode."'");                        
       $sqlc="acthtml,aftdel,aftist,aftupd,appid,atnhtml,bfdel,bfist,bfupd,changeable,CHARACTER_MAXIMUM_LENGTH,CHARACTER_OCTET_LENGTH,CHARACTER_SET_NAME,classp,clstxt,COLLATION_NAME,COLUMN_COMMENT,COLUMN_DEFAULT,COLUMN_KEY,COLUMN_NAME,COLUMN_TYPE,CRTM,CRTOR,DATA_TYPE,DATETIME_PRECISION,displayed,dxtype,EXTRA,isfixed,IS_NULLABLE,jspostfun,jsshowfun,keyexplain,keytitle,NUMERIC_PRECISION,NUMERIC_SCALE,OLMK,ORDINAL_POSITION,parallelto,PRIME,PRIVILEGES,PTOF,rescode,RIP,SQX,STATUS,STCODE,sysid,syspostfun,sysshowfun,TABLE_CATALOG,TABLE_SCHEMA,tdcode,tdomain,thcode,UPTM,valuezero,vermd5,VQX,VRT";
       $sqld="shortid,TABLE_NAME,acthtml,aftdel,aftist,aftupd,appid,atnhtml,bfdel,bfist,bfupd,changeable,CHARACTER_MAXIMUM_LENGTH,CHARACTER_OCTET_LENGTH,CHARACTER_SET_NAME,classp,clstxt,COLLATION_NAME,COLUMN_COMMENT,COLUMN_DEFAULT,COLUMN_KEY,COLUMN_NAME,COLUMN_TYPE,CRTM,CRTOR,DATA_TYPE,DATETIME_PRECISION,displayed,dxtype,EXTRA,isfixed,IS_NULLABLE,jspostfun,jsshowfun,keyexplain,keytitle,NUMERIC_PRECISION,NUMERIC_SCALE,OLMK,ORDINAL_POSITION,parallelto,PRIME,PRIVILEGES,PTOF,rescode,RIP,SQX,STATUS,STCODE,sysid,syspostfun,sysshowfun,TABLE_CATALOG,TABLE_SCHEMA,tdcode,tdomain,thcode,UPTM,valuezero,vermd5,VQX,VRT";
       $zz2=UX("insert into coode_keydetaily(".$sqld.")select '".$newcode."','".$newtab."',".$sqlc." from coode_fbkeydy where shortid='".$rescode."'");                  
       $extform=UX("select count(*) as result from coode_shortdata where shortid='".$newcode."'");
       if (intval($extform)==0){
         $stt="0";
         $msg="生成失败，请更换识别码";
       }
     break;
     case "funx":
      $sqlx="sysid,vers,vermd5,usearea,industry,business,matter,imhead,funtype,funcls,funkey,fkeys,qrytest,formtest,parallelto,CRTM,UPTM,funbody,afffuns,affclss,afftabs,funfull,oldfull,lastfull,filelcpath,isdb,isfile,lang,istemp,issys,isiden,ispmiss,syn,fileurl,copyrightmark,relycore,linex,allcharas,OLMK,STATUS";
      $zz=UX("insert into coode_funlist(funname,funcname,".$sqlx.")select '".$newcode."','".$newtitle."',".$sqlx." from coode_fbfunx where funname='".$rescode."'");
     break;
     case "sfunx":
       $sqlx="sysid,vers,vermd5,usearea,restype,rescode,funnames,qrytest,funbody,afffuns,affclss,afftabs,funfull,oldfull,lastfull,filelcpath,isdb,isfile,lang,istemp,issys,isiden,ispmiss,fileurl,OLMK,CRTOR,STATUS";
       $zz=UX("insert into coode_funsetfile(setname,setcname,".$sqlx.")select '".$newcode."','".$newtitle."',".$sqlx." from coode_fbsfunx where setname='".$rescode."'");
     break;
     case "pagex":
       $sqlx="appid,auditmd5,catalog,colora,colorb,CRTM,CRTOR,imghead,ismbl,ispmiss,layid,laypath,longexp,OLMK,pagecls,PRIME,PTOF,RIP,schm,shortid,STATUS,STCODE,sysid,tabname,tabnick,tempid,UPTM,vermd5,VRT";
       $zz=UX("insert into coode_tiny(tinymark,tinytitle,".$sqlx.")select '".$newcode."','".$newtitle."',".$sqlx." from coode_fbpagex where tinymark='".$rescode."'");    
     break;
     case "tempx":
       $sqlx="sysid,relyface,unitclass,funcls,frmexp,darela,colora,unitdescrib,outurl,pagehtml,vermd5,industry,business,matter,casecode,cssfilex,stylex,scriptx,jsfilex,cssfiley,jsfiley,styley,scripty,containsub,width,height,inwidth,inheight,templatecode,demoresult,pagesurround,subvermd5,copyrightmark,OLMK,UPTM,CRTM,STATUS";
       $zz=UX("insert into coode_domainunit(unitmark,domainmark,dumark,unittitle,".$sqlx.")select '".qian($newcode,".")."','".hou($newcode,".")."','".$newcode."','".$newtitle."',".$sqlx." from coode_fbdu where dumark='".$rescode."'");
     break;
     case "layx":
       $sqlx="sysid,appid,pagelay,CRTM,CRTOR,OLMK,STATUS,UPTM,mobilelay,pageurl,mobileurl,pshortid,mshortid,pagemd5,vermd5,colora";
       $zz=UX("insert into coode_applay(layid,laytitle,".$sqlx.")select '".$newcode."','".$newtitle."',".$sqlx." from coode_fblay where layid='".$rescode."'");
     break;
     default:
   }
   echo  makereturnjson($stt,$msg,"");
  }else{
   echo  makereturnjson("0","生成失败-资源不存在","");
  }  
 }else{
  echo  makereturnjson("0","生成失败-参数不全","");
 }
 
       session_write_close();
?>