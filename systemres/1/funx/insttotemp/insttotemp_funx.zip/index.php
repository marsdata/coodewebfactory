<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include mdir().'RNA/EARTH.php';
    $stk=$_GET["stk"];
    if (strpos(_get("fid"),"login")<=0){
     setcookie("uid",$_COOKIE["uid"],time()+3600,"/");
     setcookie("cid",$_COOKIE["cid"],time()+3600,"/");
     setcookie("uid",$_COOKIE["userid"],time()+3600,"/");
     setcookie("cid",$_COOKIE["comid"],time()+3600,"/");
     setcookie("grpcid",$_COOKIE["grpcid"],time()+3600,"/");
     setcookie("depart",$_COOKIE["depart"],time()+3600,"/");
     setcookie("dpmore",$_COOKIE["dpmore"],time()+3600,"/");
     setcookie("posids",$_COOKIE["posids"],time()+3600,"/");
     setcookie("roleids",$_COOKIE["roleids"],time()+3600,"/");
     setcookie("sysid",$_COOKIE["sysid"],time()+3600,"/");
     setcookie("stoken",$_COOKIE["stoken"],time()+3600,"/");
     setcookie("deadline",time()+3600,time()+3600,"/");
    }
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snox=dftval($_GET["SNO"],"");
$erst=SX("select nmPlate,wholePic,eqmCode,srcTitle,mVersion,inPlace,itemCrtID,muser,mVender,sysID,inDptID,mType from gmc_manmachine where sNo=".$snox);
$tote=countresult($erst);
if (intval($tote)>0){
 $tempx=1;
 $nmplate=anyvalue($erst,"nmPlate",0);
 $tempx=$tempx*es($nmplate);
 $wholepic=anyvalue($erst,"wholePic",0);
 $tempx=$tempx*es($wholepic);
 $eqmcode=anyvalue($erst,"eqmCode",0); 
 $tempx=$tempx*es($eqmcode);
 $srctitle=anyvalue($erst,"srcTitle",0);
 $tempx=$tempx*es($srctitle);
 $mversion=anyvalue($erst,"mVersion",0);
 $tempx=$tempx*es($mversion);
 $inplace=anyvalue($erst,"inPlace",0);
 $tempx=$tempx*es($inplace);
 $itemuid=anyvalue($erst,"itemCrtID",0);
 $tempx=$tempx*es($itemuid);
 $itemcid=anyvalue($erst,"muser",0);
 $tempx=$tempx*es($itemcid);
 $mvender=anyvalue($erst,"mVender",0);
 $tempx=$tempx*es($mvender);
 $sysid=anyvalue($erst,"sysID",0);
 $tempx=$tempx*es($sysid);
 $indptid=anyvalue($erst,"inDptID",0);
 $tempx=$tempx*es($indptid);
 $mtype=anyvalue($erst,"mType",0);
 $tempx=$tempx*es($mtype);
 $extx=UX("select count(*) as result from gmc_mmCls where eqmCode='".$eqmcode."'");
 if (intval($extx)==0){
   if ($tempx==1){
    $sqlx="eqmCode,srcTitle,mVersion,inPlace,nmPlate,wholePic,itemCTime,itemUTime,itemOnlyMark,itemCrtID,muser,mVender,sysID,inDptID,mType";
    $sqly="'$eqmcode','$srctitle','$mversion','$inplace','$nmplate','$wholepic',now(),now(),'".onlymark()."','$itemuid','$itemcid','$mvender','$sysid','$indptid','$mtype'";
    $zz=UX("insert into gmc_mmCls(".$sqlx.")values(".$sqly.")");
    $zx=UX("update gmc_manmachine,gmc_mmCls set gmc_mmCls.sysID=gmc_manmachine.sysID,gmc_mmCls.mType=gmc_manmachine.mType,gmc_mmCls.mSize=gmc_manmachine.mSize,gmc_mmCls.ratedVol=gmc_manmachine.ratedVol,gmc_mmCls.ratedCurr=gmc_manmachine.ratedCurr,gmc_mmCls.safePara=gmc_manmachine.safePara,gmc_mmCls.prolicense=gmc_manmachine.prolicense,gmc_mmCls.ratedFre=gmc_manmachine.ratedFre,gmc_mmCls.epSafeNo=gmc_manmachine.epSafeNo,gmc_mmCls.spSign=gmc_manmachine.epSign,gmc_mmCls.weight=gmc_manmachine.weight,gmc_mmCls.outSno=gmc_manmachine.outSno,gmc_mmCls.mDescrib=gmc_manmachine.mDescrib,gmc_mmCls.mVender=gmc_manmachine.mVender,gmc_mmCls.VenderID=gmc_manmachine.VenderID,gmc_mmCls.inDptID=gmc_manmachine.inDptID,gmc_mmCls.linkMan=gmc_manmachine.linkMan,gmc_mmCls.svsMan=gmc_manmachine.svsMan,gmc_mmCls.lMPos=gmc_manmachine.lMPos,gmc_mmCls.sMPos=gmc_manmachine.sMPos,gmc_mmCls.lMTel=gmc_manmachine.lMTel,gmc_mmCls.mMTel=gmc_manmachine.sMTel where gmc_manmachine.eqmCode=gmc_mmCls.eqmCode and gmc_manmachine.sNo='".$snox."'");
    echo makereturnjson("1","执行新增名称模板成功","");
   }else{
     echo makereturnjson("0","执行失败，参数不全","");
   }   
 }else{
   $uu=UX("update gmc_mmCls set inPlace='".$inplace."',nmPlate='".$nmplate."',wholePic='".$wholepic."' where eqmCode='".$eqmcode."'");   
   $zx=UX("update gmc_manmachine,gmc_mmCls set gmc_mmCls.sysID=gmc_manmachine.sysID,gmc_mmCls.mType=gmc_manmachine.mType,gmc_mmCls.mSize=gmc_manmachine.mSize,gmc_mmCls.ratedVol=gmc_manmachine.ratedVol,gmc_mmCls.ratedCurr=gmc_manmachine.ratedCurr,gmc_mmCls.safePara=gmc_manmachine.safePara,gmc_mmCls.prolicense=gmc_manmachine.prolicense,gmc_mmCls.ratedFre=gmc_manmachine.ratedFre,gmc_mmCls.epSafeNo=gmc_manmachine.epSafeNo,gmc_mmCls.spSign=gmc_manmachine.epSign,gmc_mmCls.weight=gmc_manmachine.weight,gmc_mmCls.outSno=gmc_manmachine.outSno,gmc_mmCls.mDescrib=gmc_manmachine.mDescrib,gmc_mmCls.mVender=gmc_manmachine.mVender,gmc_mmCls.VenderID=gmc_manmachine.VenderID,gmc_mmCls.inDptID=gmc_manmachine.inDptID,gmc_mmCls.linkMan=gmc_manmachine.linkMan,gmc_mmCls.svsMan=gmc_manmachine.svsMan,gmc_mmCls.lMPos=gmc_manmachine.lMPos,gmc_mmCls.sMPos=gmc_manmachine.sMPos,gmc_mmCls.lMTel=gmc_manmachine.lMTel,gmc_mmCls.mMTel=gmc_manmachine.sMTel where gmc_manmachine.eqmCode=gmc_mmCls.eqmCode and gmc_manmachine.sNo='".$snox."'");
   echo makereturnjson("1","执行成功，但已存在","");
 }
}else{
 echo makereturnjson("0","不存在记录","");
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>