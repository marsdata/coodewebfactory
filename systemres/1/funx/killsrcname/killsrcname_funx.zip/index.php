<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $areamark=dftval($_GET["areamark"],"");
$srcid=dftval($_GET["srcid"],"");
$srctype=dftval($_GET["srctype"],"");
$apikey=gla();
$apiverify=glv();
if ($areamark!="" and $srcid!="" and $srctype!=""){
  $bktxt=file_get_contents("http://".glm()."/DNA/EXF/anyfuns.php?fid=killdevesrc&areamark=".$areamark."&srcid=".$srcid."&srctype=".$srctype."&srctitle=".$srctitle."&apikey=".$apikey."&apiverify=".$apiverify);
  $bkdata=json_decode($bktxt,false);
  if (intval($bkdata->status)==1){
    switch($srctype){
      case "funname":
      $dd=UX("delete from iO_phpFunction where areaMark='".$areamark."' and funName='".$srcid."'");
      break;
      case "clsname":
      $dd=UX("delete from iO_phpClass where areaMark='".$areamark."' and clsName='".$srcid."'");
      break;
      case "tabname":
      $tabnm=UX("select tabRName as result from iO_tabList where tabArea='".$areamark."' and tabName='".$srcid."'");
      $conn=mysql_connect(gl(),glu(),glp());
      $kx=updatingx($conn,glb(),"drop table ".$tabnm,"utf8");
      $dd=UX("delete from iO_tabList where tabArea='".$areamark."' and tabName='".$srcid."'");
      break;
      case "sysname":
      $dd=UX("delete from iO_sysList where sysArea='".$areamark."' and sysID='".$srcid."'");
      break;
      case "appname":
      $dd=UX("delete from iO_appList where appArea='".$areamark."' and appID='".hou($srcid,".")."' and sysID='".qian($srcid,".")."'");
      break;
      case "layname":
      $dd=UX("delete from iO_layList where layArea='".$areamark."' and layID='".hou($srcid,".")."' and appID='".qian(hou($srcid,"@"),".")."' and sysID='".qian($srcid,"@")."'");
      break;
      case "tinyname":
      $dd=UX("delete from iO_tinyList where layArea='".$areamark."' and tinyID='".hou($srcid,"/")."' and layID='".qian(hou($srcid,"."),"/")."' and appID='".qian(hou($srcid,"@"),".")."' and sysID='".qian($srcid,"@")."'");
      break;
      case "dataspace":
      $dd=UX("delete from iO_dataSpace where srcArea='".$areamark."' and spcMark='".$srcid."'");
      $dd=UX("delete from iO_dspcVIndex where srcArea='".$areamark."' and spcMark='".$srcid."'");
      $dd=UX("delete from iO_dspcKey where srcArea='".$areamark."' and spcMark='".$srcid."'");
      $dd=UX("delete from iO_dspcVal where srcArea='".$areamark."' and spcMark='".$srcid."'");
      break;
      case "facename":
      $dd=UX("delete from iO_faceTemp where srcArea='".$areamark."' and fTempID='".$srcid."'");
      break;
      case "formname":
      $dd=UX("delete from iO_formList where tabArea='".$areamark."' and formID='".$srcid."'");
      break;
      case "plotname":
      $dd=UX("delete from iO_plotList where plotArea='".$areamark."' and plotID='".$srcid."'");
      break;
      case "tempname":
      $dd=UX("delete from iO_pageTemp where srcArea='".$areamark."' and pTempID='".$srcid."'");
      break;
      case "pltname":
      $dd=UX("delete from iO_pointLineTemp where srcArea='".$areamark."' and evalMark='".$srcid."'");
      break;
      case "lftname":
       $dd=UX("delete from iO_lineFaceTemp where srcArea='".$areamark."' and lfMark='".$srcid."'");
      break;
      case "oftname":
        $dd=UX("delete from iO_objFaceTemp where srcArea='".$areamark."' and ofMark='".$srcid."'");
      break;
      default:
    }
    $zz=UX("delete from iO_developSpace where srcArea='".$areamark."' and srcID='".$srcid."'");
    echo $bktxt;
  }else{
    echo $bktxt;
  }
}else{
  echo makereturnjson("0","参数不全","");
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>