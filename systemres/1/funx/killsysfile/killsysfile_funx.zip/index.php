<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snox=_get("SNO");
$frst=SX("select filetype,lcpath,filelcurl from coode_filelist where SNO=".$snox);
$ftype=anyvalue($frst,"filetype",0);
$lcpath=anyvalue($frst,"lcpath",0);
$lcurl=anyvalue($frst,"filelcurl",0);
if ($ftype!="folder"){
  $zk=UX("delete from coode_filelist where SNO=".$snox);
  $kk=unlink($lcurl);  
 echo  makereturnjson("1","删除文件成功","/localxres/funx/visitpath/?path=".$lcpath);
}else{
 $zk=UX("delete from coode_filelist where filelcurl='".$lcurl."' or lcpath like '".$lcurl."%'");
  $kk=deltree($lcurl);
 echo makereturnjson("1","删除目录成功","/localxres/funx/visitpath/?path=".$lcpath);
}
     session_write_close();
?>