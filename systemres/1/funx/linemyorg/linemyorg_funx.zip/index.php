<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $plmk=_get("plmk");
$frt=' { "from" : [from], "to" : "[to]" } ';
 $demo='{"id":"[id]","label":"[label]",shape:"[shape]",color:"[color]"}';
 $fmdemo="";
 $fmline="";
if ($plmk!=""){  
  $plrst=SX("select SNO,myid,parid,mymark,mytitle,myurl,mydescrib,STATUS from coode_plotmydetail where parid=-1 and plotmark='".$plmk."'");
  $totyi=countresult($plrst);  
  $fmyi="";
  for ($i=0;$i<$totyi;$i++){
    $dqmyid=anyvalue($plrst,"myid",$i);
    $sttx=anyvalue($plrst,"STATUS",$i);
    $snox=anyvalue($plrst,"SNO",$i);
    $yidemo=$demo;
     $yidemo=str_replace("[label]",anyvalue($plrst,"mytitle",$i),$yidemo);
     $yidemo=str_replace("[id]",anyvalue($plrst,"myid",$i),$yidemo);       
     $yidemo=str_replace("[url]",tostring(anyvalue($plrst,"myurl",$i)),$yidemo);
     $yidemo=str_replace("[open]","false",$yidemo);
     if (intval($sttx)==0){
       $yidemo=str_replace("[shape]","",$yidemo);
       $yidemo=str_replace("[color]","green",$yidemo);
     }else if(intval($sttx)==1){
       $yidemo=str_replace("[shape]","",$yidemo);
       $yidemo=str_replace("[color]","red",$yidemo);
     }else{
       $yidemo=str_replace("[shape]","",$yidemo);
       $yidemo=str_replace("[color]","orange",$yidemo);
     }
     $fmdemo=$fmdemo.$yidemo.",";
     $z=UX("update coode_plotdetail set level=1 where SNO=".$snox);
     if ($i<$totyi-1){
      $predemo=$frt;
      $predemo=str_replace("[from]",anyvalue($plrst,"myid",$i),$predemo);
      $predemo=str_replace("[to]",anyvalue($plrst,"myid",($i+1)),$predemo);
      $fmline=$fmline.$predemo.",";
     }
     
    $ysrst=SX("select SNO,myid,parid,mymark,mytitle,myurl,mydescrib,STATUS from coode_plotmydetail where parid=".$dqmyid." and plotmark='".$plmk."'");  
    $toter=countresult($ysrst);     
    if ($toter>0){
      $fmer=""; 
      for ($j=0;$j<$toter;$j++){
        $erdemo=$demo;
        $stty=anyvalue($ysrst,"STATUS",$j);
        $snoy=anyvalue($ysrst,"SNO",$j);
        $erdemo=str_replace("[label]",anyvalue($ysrst,"mytitle",$j),$erdemo);
        $erdemo=str_replace("[id]",anyvalue($ysrst,"myid",$j),$erdemo);       
        $erdemo=str_replace("[url]",tostring(anyvalue($ysrst,"myurl",$j)),$erdemo);
        $erdemo=str_replace("[open]","false",$erdemo);
        if (intval($stty)==0){
          $erdemo=str_replace("[shape]","triangle",$erdemo);
          $erdemo=str_replace("[color]","green",$erdemo);
        }else if(intval($stty)==1){
          $erdemo=str_replace("[shape]","triangle",$erdemo);
          $erdemo=str_replace("[color]","red",$erdemo);
        }else{
          $erdemo=str_replace("[shape]","triangle",$erdemo);
          $erdemo=str_replace("[color]","orange",$erdemo);
        }
        $fmdemo=$fmdemo.$erdemo.",";
        $predemo=$frt;
        
        $predemo=str_replace("[from]",anyvalue($plrst,"myid",$i),$predemo);
        $predemo=str_replace("[to]",anyvalue($ysrst,"myid",$j),$predemo);
        if (strpos($fmline,$predemo)<=0){
         $fmline=$fmline.$predemo.",";
        }
        $dqeid=anyvalue($ysrst,"myid",$j);
        $z=UX("update coode_plotdetail set level=2 where SNO=".$snoy);
        $esrst=SX("select SNO,myid,parid,mymark,mytitle,myurl,mydescrib,STATUS from coode_plotmydetail where parid=".$dqeid." and plotmark='".$plmk."'");      
        $totsan=countresult($esrst);        
       $fmsan="";
        if ($totsan>0){
          for ($k=0;$k<$totsan;$k++){
           $newdemo=$demo;           
           $sttz=anyvalue($esrst,"STATUS",$k);
           $snoz=anyvalue($esrst,"SNO",$k);
           $newdemo=str_replace("[label]",anyvalue($esrst,"mytitle",$k),$newdemo);
           $newdemo=str_replace("[id]",anyvalue($esrst,"myid",$k),$newdemo);
           $newdemo=str_replace("[hscd]","false",$newdemo);
           $newdemo=str_replace("[url]",tostring(anyvalue($esrst,"myurl",$k)),$newdemo);
           $newdemo=str_replace("[open]","false",$newdemo);
           $newdemo=str_replace("[inner]","''",$newdemo);
           if(intval($sttz)==0){
            $newdemo=str_replace("[shape]","dot",$newdemo);
            $newdemo=str_replace("[color]","green",$newdemo);
           }else if(intval($sttz)==1){
            $newdemo=str_replace("[shape]","dot",$newdemo);
            $newdemo=str_replace("[color]","red",$newdemo);
           }else{
            $newdemo=str_replace("[shape]","dot",$newdemo);
            $newdemo=str_replace("[color]","orange",$newdemo);
           }
           $fmdemo=$fmdemo.$newdemo.",";
           $predemo=$frt;
           $z=UX("update coode_plotdetail set level=3 where SNO=".$snoz);
            $predemo=str_replace("[from]",anyvalue($ysrst,"myid",$j),$predemo);
            $predemo=str_replace("[to]",anyvalue($esrst,"myid",$k),$predemo);
            if (strpos($fmline,$predemo)<=0){
             $fmline=$fmline.$predemo.",";
            }
          }                   
        }else{                  
        }//totsan                     
      }//forj            
    }else{//toter  
    }//toter    
  }//fori
}else{   
}
if ($fmdemo!=""){
  $fmdemo="[".killlaststr($fmdemo)."]";
}
if ($fmline!=""){
  $fmline="[".killlaststr($fmline)."]";
}
echo $fmdemo."|".$fmline;
     session_write_close();
?>