<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $pgstoken=_get("pgstoken");
$lgrst=SX("select userid,wrdid,depart,posids from coode_loginstoken where timestampdiff(second,now(),deadline)>0 and stoken='".$pgstoken."'");
$totlg=countresult($lgrst);
if ($totlg>0){
  $uid=anyvalue($lgrst,"userid",0);
  $wid=anyvalue($lgrst,"wrdid",0);
  $depart=anyvalue($lgrst,"depart",0);
  $posids=anyvalue($lgrst,"posids",0);
  setcookie("uid",$uid,time()+3600,"/");          
  setcookie("cid",$wid,time()+3600,"/");  
  setcookie("depart",$depart,time()+3600,"/");          
  setcookie("posids",$posids,time()+3600,"/");          
  setcookie("stoken",$pgstoken,time()+3600,"/");  
  echo makereturnjson("1","成功","");
}else{
  echo makereturnjson("0","未发现","");
}
     session_write_close();
?>