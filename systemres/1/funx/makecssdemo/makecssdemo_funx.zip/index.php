<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $tdmcode=_get("tdmcode");
$shortid=_get("shortid");
$csstype=_get("csstype");
$trst=SX("select dxtype,typerowsrd,typesrd,typedemo,typedfunx,typeheadx,typeheadsfx,typesfunx from coode_tempcssfunx where tdmcode='".$tdmcode."'");
$tott=countresult($trst);
//超异步搜索；输入问题；没有主站，只有关系站，关系站如果多，太站自己的资源，向下帮助提问；如果有匹配的答案则告知提问HOST 结果在哪里有。或者获得问题的人直接回复该主机该问题。
//资源索引也是随机分配，每个端至少有这个少数获取推送的功能，开多了会影响速度；自己的关系圈内发布的新资源可以第一时间看到，可以采用；并发布到自己的关系圈中。
//网络遍历搜索，如果是同一个问题则停止继续帮助询问；
$cssdemo=combineurl(localroot(),"/localxres/tempx/".qian($tdmcode,".")."/js/".str_replace(".","_",$tdmcode)."_cssdemo.js");
$keyfile=combineurl(localroot(),"/localxres/formx/".$shortid."/js/".str_replace(".","_",$tdmcode)."_".$shortid."demo.js");
$fmcode="kcode=new Array();".huanhang();
for ($j=0;$j<$tott;$j++){
  $dxtype=anyvalue($trst,"dxtype",$j);
  $typerowsrd=tostring(anyvalue($trst,"typerowsrd",$j));
  $typesrd=tostring(anyvalue($trst,"typesrd",$j));
  $typedemo=tostring(anyvalue($trst,"typedemo",$j));
  $typedfunx=tostring(anyvalue($trst,"typedfunx",$j));
  $typeheadx=tostring(anyvalue($trst,"typeheadx",$j));
  $typeheadsfx=tostring(anyvalue($trst,"typeheadsfx",$j));
  $typesfunx=tostring(anyvalue($trst,"typesfunx",$j));
  $fmcode=$fmcode.'kcode["'.$dxtype.'DEMO"]="'.str_replace(huanhang(),'',str_replace('"','\"',$typedemo)).'";'.huanhang();
  $fmcode=$fmcode.'kcode["'.$dxtype.'SRD"]="'.str_replace(huanhang(),'',str_replace('"','\"',$typesrd)).'";'.huanhang();
  $fmcode=$fmcode.'kcode["'.$dxtype.'ROWSRD"]="'.str_replace(huanhang(),'',str_replace('"','\"',$typerowsrd)).'";'.huanhang();
  $fmcode=$fmcode.$typeheadx.huanhang();
  $fmcode=$fmcode.'kcode["'.$dxtype.'HEADSTART"]="'.str_replace(huanhang(),'',str_replace('"','\"',$typeheadsfx)).'";'.huanhang();
  $fmcode=$fmcode.'kcode["'.$dxtype.'START"]="'.str_replace(huanhang(),'',str_replace('"','\"',$typesfunx)).'";'.huanhang();
  if (substr($typedemo,0,10)=="functionx("){
    $fmcode=$fmcode.$typedfunx.huanhang();
  }
}
 $dmrst=SX("select tabformsrd,tabformwhole,srdstart from coode_tempcssdfn where tdmcode='".$tdmcode."'");
  $tabformsrd=tostring(anyvalue($dmrst,"tabformsrd",0));
  $tabformwhole=tostring(anyvalue($dmrst,"tabformwhole",0));
  $srdstart=tostring(anyvalue($dmrst,"srdstart",0));
  $fmcode=$fmcode.'kcode["TABSRD"]="'.str_replace(huanhang(),'',str_replace('"','\"',$tabformsrd)).'";'.huanhang();
  $fmcode=$fmcode.'kcode["TABWHOLE"]="'.str_replace(huanhang(),'',str_replace('"','\"',$tabformwhole)).'";'.huanhang();
  $fmcode=$fmcode.$srdstart.huanhang();
  if ($csstype=="ktype" or $csstype==""){
    if ($tdmcode!=""){ 
      $zz=overfile($cssdemo,$fmcode);
    }
  }else{
   $tfrst=SX("select datakey,dxtype,keysrd,keydemo,keyrowsrd,keydfunx,keyheadx,keyheadsfx,keysfunx,pxpos from coode_tlfcssfunx where tdmcode='".$tdmcode."' and formid='".$shortid."'");
   $totf=countresult($tfrst);
   for ($ff=0;$ff<$totf;$ff++){
     $datakey=anyvalue($tfrst,"datakey",$ff);
     $keysrd=tostring(anyvalue($tfrst,"keysrd",$ff));
     $keydemo=tostring(anyvalue($tfrst,"keydemo",$ff));
     $keyrowsrd=tostring(anyvalue($tfrst,"keyrowsrd",$ff));
     $keydfunx=tostring(anyvalue($tfrst,"keydfunx",$ff));
     $keyheadx=tostring(anyvalue($tfrst,"keyheadx",$ff));
     $keyheadsfx=tostring(anyvalue($tfrst,"keyheadsfx",$ff));
     $keysfunx=tostring(anyvalue($tfrst,"keysfunx",$ff));
     $pxpos=anyvalue($tfrst,"pxpos",$ff);
     $fmcode=$fmcode.'kcode["'.$datakey.'DEMO"]="'.str_replace(huanhang(),'',str_replace('"','\"',$keydemo)).'";'.huanhang();
     $fmcode=$fmcode.'kcode["'.$datakey.'SRD"]="'.str_replace(huanhang(),'',str_replace('"','\"',$keysrd)).'";'.huanhang();
     $fmcode=$fmcode.'kcode["'.$datakey.'ROWSRD"]="'.str_replace(huanhang(),'',str_replace('"','\"',$keyrowsrd)).'";'.huanhang();
     $fmcode=$fmcode.$keyheadx.huanhang();
     $fmcode=$fmcode.'kcode["'.$datakey.'HEADSTART"]="'.str_replace(huanhang(),'',str_replace('"','\"',$keyheadsfx)).'";'.huanhang();
     $fmcode=$fmcode.'kcode["'.$datakey.'START"]="'.str_replace(huanhang(),'',str_replace('"','\"',$keysfunx)).'";'.huanhang();
     if (substr($keydemo,0,10)=="functionx("){
      $fmcode=$fmcode.$keydfunx.huanhang();
     }
   }
   if ($shortid!="" and $tdmcode!=""){
     //$keydir=combineurl(localroot(),"/localxres/formx/".$shortid."/js/");
     //$z0=createdir($keydir);     
     $zz=overfile($keyfile,$fmcode);
   }
  }  
  echo makereturnjson("1","生成成功","");
       session_write_close();
?>