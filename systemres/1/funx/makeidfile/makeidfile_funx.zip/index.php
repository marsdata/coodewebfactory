<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sqx=dftval($_GET["sqx"],"");
$sqlmd5=dftval($_GET["sqlmd5"],"");
$sysid=dftval($_GET["sysid"],"");
if ($sysid==""){
  $outpath=combineurl(localroot(),"/localxres/install/core/01.sql");
}else{
  $outpath=combineurl(localroot(),"/localxres/install/".$sysid."/".$sysid.".sql");
}
$idrst=SX("select strtype,sqlstring from coode_resrelyinst where sqlmd5='".$sqlmd5."'");
$toti=countresult($idrst);
if (intval($toti)>0){
 $strtype=anyvalue($idrst,"strtype",0);
 $sqlstring=anyvalue($idrst,"sqlstring",0);
 if (intval($sqx)==0){
  $zz=overfile($outpath,uncoodesql($sqlstring).huanhang());
 }else{
  $zz=appendfile($outpath,uncoodesql($sqlstring).huanhang());
 }
}
echo makereturnjson("1","写入成功","");
     session_write_close();
?>