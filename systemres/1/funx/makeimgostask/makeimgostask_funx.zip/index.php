<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snos=dftval($_GET["snos"],"");
$ptsno=explode(",",$snos);
$totpt=count($ptsno);
$fmcdt="";
for ($i=0;$i<$totpt;$i++){
 if ($ptsno[$i]!=""){
   $fmcdt=$fmcdt." SNO=".$ptsno[$i]." or ";
 }
}
$fmcdt=substr($fmcdt,0,strlen($fmcdt)-3);
$afrst=SX("select taskid,askmark,asktitle,imgsize,imgtype,price from coode_askimgtask where (".$fmcdt.") and ostaskid=''");
$tota=countresult($afrst);
$totp=0;
for ($j=0;$j<$tota;$j++){
  $totp=$totp+intval(anyvalue($afrst,"price",$j));
  
}
$txid=getRandChar(6);
$uhead=UX("select headpic as result from coode_userlist where userid='".$_COOKIE["uid"]."'");
$osqlx="taskid,tasktitle,taskimg,pstheadx,workurl,tasktype,stocktime,CRTM,UPTM,deadline,poster";
$osqly="'".$txid."','图片设计','/DNA/EXF/anyfuns.php?fid=askforimg&w=334&h=340&tempid=a.b&askmark=picdesign&asktitle=图片设计','".$uhead."','/SPEC/EDITOR/anyjsshort.php?stid=EvggHN-pnum:30-&refresh=1','imgdesign',30,now(),now(),DATE_ADD(now(),INTERVAL 2 DAY),'".$_COOKIE["uid"]."'";
$z=UX("insert into outsource_task(".$osqlx.")values(".$osqly.")");
$zzB=UX("update coode_askimgtask set ostaskid='".$txid."'  where (".$fmcdt.") and ostaskid=''");
echo makereturnjson("1","请求成功","");
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>