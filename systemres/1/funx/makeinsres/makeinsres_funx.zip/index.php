<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $sysid=_get("sysid");
$host=_get("host");
$insmark=_get("insmark");
  $markb=$insmark."@".date("Y-m-d");
  $kk=UX("delete from coode_installdetail where insmark='".$markb."'");
  $sqla="host,insmark,institle,rescode,restype,restitle,vermd5,thisver,sysid,CRTM,UPTM,finishtime,OLMK,STATUS";
  $sqlb="host,'".$markb."','".$sysname."',resmark,restype,restitle,hostver,thisver,grpid,now(),now(),now(),md5(RAND()*1000),0";
  $zz=UX("insert into coode_installdetail(".$sqla.")select ".$sqlb." from coode_hostregres where grpid='".$sysid."' and host='".$host."'");
  
  $ss=UX("update coode_installdetail,coode_sysregres set coode_installdetail.thisver=coode_sysregres.vermd5 where coode_installdetal.sysid=coode_sysregres.grpid and coode_installdetail.rescode=coode_sysregres.resmark and coode_installdetail.restype=coode_sysregres.restype");    
  $ss=UX("update coode_installdetail set PRIME=1 where vermd5=thisver");    
  $totres=UX("select count(*) as result from coode_installdetail where  grpid='".$sysid."' and host='".$host."'");
  $diffres=UX("select count(*) as result from coode_installdetail where PRIME=1 and  grpid='".$sysid."' and host='".$host."'");
  $ss=UX("update coode_hostressys set totres='".$totres."',insite='".$diffres."' where  sysid='".$sysid."' and host='".$host."'");
  $ss=UX("update coode_installidx set succnum=0,failnum=0 where   insmark='".$insmark."'");
if ( $totres>0){
   echo makereturnjson("1","生成成功","");
}else{
  echo makereturnjson("0","生成失败，未获取远程资源","");
}
       session_write_close();
?>