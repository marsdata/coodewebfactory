<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $allresfile=combineurl(localroot(),"/localxres/funx/makeislfile/install/runingbox/allres.json");
$bktxt=file_get_contents("http://".killlaststr(glw())."/localxres/funx/askinstall/?ssmark=".onlymark());
$tabtxt=file_get_contents("http://".killlaststr(glw())."/localxres/funx/anyshort/?stid=asS6C&pnum=30");
$tabfile=combineurl(localroot(),"/localxres/funx/makeislfile/install/runingbox/firsttab.json");
$zz=overfile($allresfile,$bktxt);
$zz=overfile($tabfile,$tabtxt);
echo makereturnjson("1","生成成功","");
       session_write_close();
?>