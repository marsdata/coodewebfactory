<?php
function gl(){return "[cdip]";}//DESCRIB glb():本系统mysql 数据库IP END@glb()
function glu(){return "[cduser]";}//DESCRIB glu():本系统mysql 数据库用户名 END@glu()
function glp(){return "[cdpass]";}//DESCRIB glp():本系统mysql 数据库密码 END@glp()
function glb(){return "[cdbase]";}//DESCRIB glb():本系统mysql 数据库 END@lgb()
function gln(){return "[firstsys]";}//DESCRIB gln():当前使用系统名称 END@gln()
function gla(){return "[ak]";}//DESCRIB gla():当前apikey END@gln()
function glv(){return "[av]";}//DESCRIB glv():当前api verfy 使用系统版本号 END@gln()
function glt(){return "[sitename]";}//DESCRIB glt():当前实例名称 END@glt()
function glm(){return "[motherhost]";}//DESCRIB glm():母系统域名 END@glt() localhost 为本地模式不联网
function hostcode(){return "[hostcode]";}//DESCRIB glr():授权注册码 END@glt() 申请试用后，提供服务器IP地址，给您安装，转移操作
function runblog(){return "[runblog]";}//日志记录是否开启
function runprocess(){return "[runprocess]";}//日志记录是否开启
function remoteway(){return "[remoteway]";}//远程模式，可以上传资源到母机
function bl(){return "[bdip]";}//DESCRIB glb():业务系统mysql 数据库IP END@glb()
function blu(){return "[bduser]";}//DESCRIB glu():业务系统mysql 数据库用户名 END@glu()
function blp(){return "[bdpass]";}//DESCRIB glp():业务系统mysql 数据库密码 END@glp()
function blb(){return "[bdbase]";}//DESCRIB glb():业务系统mysql 数据库 END@lgb()
function bln(){return "[secondsys]";}//DESCRIB gln():当前业务使用系统名称 END@gln()
function blt(){return "[bussname]";}//DESCRIB glt():当前实例名称 END@glt()
//-------------配置分界线
function _get($str){ $val = !empty($_GET[$str]) ? $_GET[$str] : ""; return $val; } //DESCRIB ():  END@()

function _cookie($str){$val = !empty($_COOKIE[$str]) ? $_COOKIE[$str] : ""; return $val; }//DESCRIB ():  END@()

function combineurl($qu,$hu){if (substr($qu,-1)=="/"){$qu=killlaststr($qu);}if (substr($hu,0,1)=="/"){return $qu.$hu;}else{return $qu."/".$hu;}}//DESCRIB ():  END@()

function getRandChar($length){$str = null;$strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";$max = strlen($strPol)-1;for($i=0;$i<$length;$i++){$str.=$strPol[rand(0,$max)]; }return $str;}

function hou($fullstr,$astr){if ($fullstr!="" and $astr!=""){$cunzaibu=strpos("x".$fullstr,$astr);if ($cunzaibu>0 ){$spos=strpos($fullstr,$astr);$lens=strlen($astr);$alll=strlen($fullstr);return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));}else{return $fullstr;};}else{return "";}}//DESCRIB (): 完美兼容中文混合取字符串后面 END@()

function killlaststr($strx){ return substr($strx,0,strlen($strx)-1);}

function localroot(){if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){$gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";}else{$gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);};if (strpos($gml,":")>0){$qdq=qian($gml,":");$gml=strtoupper($qdq).":".hou($gml,":");};return $gml;}//DESCRIB localroot(): 获取本地根目录 END@localroot()

function qian($fullstr,$astr){if ($fullstr!="" and $astr!=""){$cunzaibu=strpos("x".$fullstr,$astr);if ($cunzaibu>0 ){$astrlen=strpos($fullstr,$astr);$fmrt=substr($fullstr,0,$astrlen);return $fmrt;}else{return $fullstr;}}else{return "";}}//DESCRIB qian(): 完美兼容中文混合 END@qian()

function String2Hex($string){if (substr($string,0,10)=="dTYPE_HEX:"){return $string;}else{$hex='';for ($i=0; $i < strlen($string); $i++){$hex .= dechex(ord($string[$i]));}return $hex;}}
function mysql_connect($fi,$fu,$fp){return new mysqli($fi,$fu,$fp);}//DESCRIB mysql_connect(): 连接数据库方法，如果是php5.5-
function UX($asqlstr){$conn=mysql_connect(gl(),glu(),glp());return updatings($conn,glb(),$asqlstr,"utf8");}//DESCRIB ():  END@()

function onlymark(){
   return makeguid();
}//DESCRIB ():  END@()
function updatingx($con,$db,$sqlstr,$lan){
 //mysql_select_db($db, $con);
 //mysql_query("SET NAMES ".$lan);    
 if (gettype($con)=="object" and $con){
 $con -> query("set names '".$lan."'"); //数据库输出编码
 $con -> select_db($db); //打开数据库
 $result = $con->query($sqlstr); //查询成功
//$result = mysql_query($sqlstr);
  if (strpos($sqlstr,"result")>0){
   if ($result){
      while($row = mysqli_fetch_array($result))
      {
        mysqli_close($con);
        return empty($row["result"])?"":$row["result"];
      }
   }else{
     $sqlerror=mysqli_error($con);
     mysqli_close($con);  
     return "failure:SE-".$sqlerror."@".$sqlstr;
   }
  }else{
   mysqli_close($con);
   return $result?1:0;
  };
 }else{
  if (gettype($con)=="object"){
   return "failure:SE-".mysqli_error();
  }else{
  //远程
   $purl="http://".$con["host"]."/localxres/funx/updatingx/?db=".$db."&uid=".glr();
   $pdata=array();
   $pdata["sqlstr"]=$sqlstr;
   return request_post($purl,$pdata);
  }
 } 
}//DESCRIB ():  END@()


function updatings($con,$fb,$sqlx,$lag){
  $fmwhere="";
if (strpos("x".$sqlx,"select")>0 or strpos("x".$sqlx,"update")>0 or strpos("x".$sqlx,"insert")>0  or strpos("x".$sqlx,"delete")>0){
   $ddrst=updatingx($con,$fb,$sqlx,$lag);
}else{
  $_GET["UPDTSTR"]=_get("UPDTSTR");
 if (strpos("xxx".$_GET["UPDTSTR"],$fb.$sqlx)>0){
   $ddrst="failure:die to repeat in ".$fb."-running_".$sqlx;
 }else{
  if (strpos("x".$sqlx,"UPDATE ")>0 and strpos("x".$sqlx," SET ")>0 ){
  //发现修改 先检查是否真的变动了，如果没有变动则跳过不然后边有好多访问数据请求浪费时间  

    $_GET["tbnm"]=qian(hou($sqlx,"UPDATE ")," SET ");
    $_GET["tbnm"]=str_replace(" ","",$_GET["tbnm"]);
    $prisno=UX("select mainsqx as result from coode_tablist where TABLE_NAME='".$_GET["tbnm"]."'");
    $gsno=hou($sqlx,$prisno."=");
    $gsno=str_replace(" ","",$gsno);
    $gsno=str_replace(")","",$gsno);
    $gsno=str_replace("'","",$gsno);
    $_GET["SNO"]=$gsno;
    $sqlstr=qian(hou($sqlx," SET ")," WHERE ");
    $cstj=hou($sqlx," WHERE ");
    //用这个判断就可以
    $ptsql=explode(",",$sqlstr);
    $totp=count($ptsql);
    $fmallkx="";
    $evx="";
   // echo "SNO=".$gsno;
  if ($totp>0 and $sqlstr!=""){
    for ($z=0;$z<$totp;$z++){
      $pppx=$ptsql[$z];
      $tkkk=qian($pppx,"=");
      $tvvv=hou($pppx,"=");
      $fmallkx=$fmallkx.$tkkk.",";
      if (substr($tvvv,0,1)=="'" or substr($tvvv,-1)=="'"){
        $evx='$_POST[\'p_'.$tkkk.$gsno.'\']='.$tvvv.';';
        $fmwhere=$fmwhere." and ".$ptsql[$z];
      }else{
        $tvvv="'".$tvvv."'";
        $evx='$_POST[\'p_'.$tkkk.$gsno.'\']='.$tvvv.';';
        $fmwhere=$fmwhere." and ".$ptsql[$z];
      }
     // echo $evx."---";
      eval($evx);      
    }//for    //单个接受字段里如果有,逗号会被分割
  //  echo $fmwhere."--";
  }else{//totp!>0
      $pppx=$sqlstr;
      $tkkk=qian($pppx,"=");
      $tvvv=hou($pppx,"=");
      $fmallkx=$fmallkx.$tkkk.",";
      if (substr($tvvv,0,1)=="'" or substr($tvvv,-1)=="'"){
        $evx='$_POST[\'p_'.$tkkk.$gsno.'\']='.$tvvv.';';
        $fmwhere=$fmwhere." and ".$ptsql[$z];
      }else{
        $tvvv="'".$tvvv."'";
        $evx='$_POST[\'p_'.$tkkk.$gsno.'\']='.$tvvv.';';
        $fmwhere=$fmwhere." and ".$ptsql[$z];
      }
     // echo $evx."---";
      eval($evx);      
    };//if    
    $fmwhere=$cstj.$fmwhere;
    $fmallkx=substr($fmallkx,0,strlen($fmallkx)-1);  
    $_GET["kies"]=$fmallkx;
    $_GET["kies"]=str_replace(" ","",$_GET["kies"]);
   //$frst=anyfunrun("anyrcv",$_GET["appid"],"");
  }else{//update
   if (strpos("x".$sqlx,"INSERT ")>0 and strpos("x".$sqlx," INTO ")>0){
    //发现新增
    $_GET["SNO"]="0";
    $_GET["tbnm"]=qian(hou($sqlx,"INTO "),"(");
    $_GET["tbnm"]=str_replace(" ","",$_GET["tbnm"]);
    $_GET["kies"]=qian(hou($sqlx,$_GET["tbnm"]."("),")VALUES");
    $_GET["kies"]=str_replace(" ","",$_GET["kies"]);
    $allkx=$_GET["kies"];
    $allvx=hou($sqlx,"VALUES(");
    $allvx=substr($allvx,0,strlen($allvx)-1);
    //为什么只用一个HOU因为后面的括号有可能是值所以一个括号容易出错
    $ptkx=explode(",",$allkx);
    $ptvx=explode(",",$allvx);
    $totp=count($ptkx);
    $evx="";
    if ($totp>0 and $allvx!=""){
     for ($z=0;$z<$totp;$z++){
      if (substr($ptvx[$z],0,1)=="'"){
        $evx='$_POST[\'p_'.$ptkx[$z].'0\']='.$ptvx[$z].';';
      }else{
        $ptvx[$z]="'".$ptvx[$z]."'";
        $evx='$_POST[\'p_'.$ptkx[$z].'0\']='.$ptvx[$z].';';
      }
      eval($evx);      
     }
    }
  }else{//insert
    //未发现 则执行查询
    if (strpos("x".$sqlx,"DELETE ")>0 and strpos("x".$sqlx," FROM ")>0){
       $_GET["tbnm"]=qian(hou($sqlx,"FROM ")," WHERE ");       
       $_GET["kies"]="-killitem";
       $gcdt=hou($sqlx,"where ");
       if ($gsno!=""){
         $gcdt=" SNO=".$gsno;
       }else{
         if ($golmk!=""){
           $gcdt=" OLMK='".$golmk."'";
         }else{
         }
       }
      $gcdt=str_replace(" ","",$gcdt);
      if (strpos($gcdt,"=")>0 or strpos($gcdt,"like")>0){       
        $_GET["killcdt"]=$gcdt;
      }else{
        $_GET["killcdt"]="";
      }
    }else{   //delete  
    }//delete
   }//insert 
  }  //update
  
    if ($_GET["UPDTSTR"]==""){//这个判断防止死循环
      $_GET["UPDTSTR"]=$fb.$sqlx;
    }else{
      $_GET["UPDTSTR"]=$_GET["UPDTSTR"]."/".$fb.$sqlx;
    }
    if ($fmwhere==""){
     $ddrst=makercv();
    }else{
      $conn=mysql_connect(gl(),glu(),glp());
      $dontchange=updatingx($conn,glb(),"select count(*) as result from ".$_GET["tbnm"]." where ".$fmwhere,"utf8");
      if ($dontchange*1>0){//没变一样，就不执行makercv 不然太耗时间
        //$ddrst=updatingx($con,$fb,$sqlx,$lag); 啥也不执行
        $ddrst="select count(*) as result from ".$_GET["tbnm"]." where ".$fmwhere;
      }else{
        $ddrst=makercv();
      }
    }
  }
 }//防止死循环 
 return $ddrst;
}//DESCRIB ():  END@()


function Hex2String($hex){$string='';for ($i=0; $i < strlen($hex)-1; $i+=2){$string .= chr(hexdec($hex[$i].$hex[$i+1]));}return $string;}
function tostring($vlsx){
  if (strpos("x".$vlsx,"TYPE_HEX:")>0){
    $houvlx=Hex2String(hou($vlsx,"TYPE_HEX:"));
    $houvlx=str_replace("-r-n","\r\n",str_replace("\\'","'",$houvlx));
    return str_replace("-/-/","\\",$houvlx);
  }else{
    $vlsx=str_replace("-r-n","\r\n",str_replace("\\'","'",$vlsx));
    return str_replace("-/-/","\\",$vlsx);
  };
}



function es($strx){
    $strx=str_replace(" ","",$strx);
    $strx=str_replace("un"."defined","",$strx);
    if ($strx!=""){
        return 1;
    }else{
        return 0;
    }
}

function spacex($nx){
    $tmpx="";
    for ($i=0;$i<$nx;$i++){
        $tmpx=$tmpx." ";
    }
    return $tmpx;
}


function overfile($fnm,$ftxt){
  $lsx=explode("/",$fnm);
  $totls=count($lsx);
  $frt=str_replace($lsx[$totls-1],"",$fnm);
  is_dir($frt) OR mkdir($frt, 0777, true); 
 $myfile = fopen($fnm, "w") or die("Unable to open file!");
 $txt = $ftxt;
 fwrite($myfile, $txt);
 fclose($myfile);
 return 1;
}


   
function TX($tsql){
    if ($tsql!=""){
     $keyx=qian(hou($tsql,"elect"),"from");
     $keyx=str_replace(" ","",$keyx);
     if (strpos($tsql,"limit")>0){
        $pnumx=hou(hou($tsql,"limit"),",");
     }else{
        $pnumx="30";
     }
     $ptkx=explode(",",$keyx);
     $totp=count($ptkx);
     $headx="";
     $bodyx="";
     for ($i=0;$i<$totp;$i++){
        $mykey[$i]=qian($ptkx[$i],"@");
        $mytit[$i]=qian(hou($ptkx[$i],"@"),"(");
        $mytype[$i]=qian(hou($ptkx[$i],"("),")");
        $headx=$headx.$mykey[$i]."#-#";
     }
     $headx=$headx."#/#";
     for ($j=0;$j<intval($pnumx);$j++){
        for ($i=0;$i<$totp;$i++){
         $bodyx=$bodyx.gettestvalue($j,$mykey[$i],$mytit[$i],$mytype[$i])."#-#";
        }
        $bodyx=$bodyx."#/#";
     }
     return $headx.$bodyx;
    }else{
     return "ERROR#/#NO SQLSTR";   
    }
}


function NS($datamark,$datatitle,$kdefine){
  $extds=UX("select count(*) as result from coode_dataspace where datamark='".$datamark."'");
  if (intval($extds)==0){
    $ptkdf=explode(",",$kdefine);
    $toto=count($ptkdf);
    $srcid=$datamark;
    $srcarea="";
    $sqla="datamark,datatitle,CRTM,UPTM,CRTOR,OLMK";
    $sqlb="'$datamark','$datatitle',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";
    $zab=UX("insert into coode_dataspace(".$sqla.")values(".$sqlb.")");
    if ($srcid!=""){
     $strudemo='{"dspccode":"[dspccode]","dspctitle":"[dspctitle]","keynames":"[keynames]","ktps":[<kdata>]}';
     $itemdemo='{"keyname":"[keyname]","keytitle":"[keytitle]","dxtype":"[dxtype]","datatype":"[datatype]","keylen":"[keylen]"},';
     $strudemo=str_replace("[dspctitle]",$datatitle,$strudemo);
     $fma="";
      for ($bb=0;$bb<intval($toto);$bb++){
        $titlex=qian($ptkdf[$bb],"(");  
        $orgid=getRandChar(8);
        //String2Hex($titlex);
        $otypex=qian(hou($ptkdf[$bb],"("),")");
           switch($otypex){
            case "tinyint":
            $keytype="tinyint";
            $keylen="4";
            break;
            case "int":
            $keytype="int";
            $keylen="11";
            break;
            case "varchar20":
            $keytype="varchar";
            $keylen="20";
            break;
            case "varchar50":
            $keytype="varchar";
            $keylen="50";
            break;
            case "varchar100":
            $keytype="varchar";
            $keylen="100";
            break;
            case "varchar255":
            $keytype="varchar";
            $keylen="255";
            break;
            case "varchar1024":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "decimal1":
            $keytype="decimal";
            $keylen="10.1";
            break;
            case "decimal2":
            $keytype="decimal";
            $keylen="10.2";
            break;
            case "decimal3":
            $keytype="decimal";
            $keylen="10.3";
            break;
            case "decimal4": 
            $keytype="decimal";
            $keylen="10.4";
            break;
            case "select":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "multiselect":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "checkbox":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "multicheckbox":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "imagex":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "images":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "filex":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "files":
            $keytype="varchar";
            $keylen="1024";
            break;
          }
        $itemx=$itemdemo;
        $itemx=str_replace("[keyname]",$orgid,$itemx);
        $itemx=str_replace("[keytitle]",$titlex,$itemx);
        $itemx=str_replace("[dxtype]",$otypex,$itemx);
        $itemx=str_replace("[datatype]",$keytype,$itemx);
        $itemx=str_replace("[keylen]",$keylen,$itemx);
        $fma=$fma.$itemx;
        if ($titlex!="" and $titlex!="undefined"){
           $extx=UX("select count(*) as result from coode_dspckey where domainmark='".$srcarea."' and datamark='".$srcid."' and keytitle='".$titlex."' ");
           if (intval($extx)==0){
             $z=UX("insert into coode_dspckey(domainmark,datamark,dxtype,keytype,keylen,keymark,keytitle,CRTM,UPTM,CRTOR)values('".$srcarea."','".$srcid."','".$otypex."','".$ktype."','".$keylen."','".$orgid."','".$titlex."',now(),now(),'".$_COOKIE["uid"]."')");         
           }else{
             $z=UX("update coode_dspckey set UPTM=now(),dxtype='".$otypex."',keytype='".$keytype."',keylen='".$keylen."' where domainmark='".$srcarea."' and datamark='".$srcid."' and keytitle='".$titlex."' ");
           }   
         }
       }
       $fma=killlaststr($fma);
       $strudemo=str_replace("[kdata]",$fma,$strudemo);
       if ($srcid!=""){
        $strujson=combineurl(localroot(),"/localxres/dataspacex/".$srcid."/","structure.json");       
        $zz=overfile($strujson,$strudemo);
       }
       $bb=UX("delete from coode_dspckey where timestampdiff(second,UPTM,now())>30 and domainmark='".$srcarea."' and datamark='".$srcid."' ");    
       $sqlx="domainmark,datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib,CRTM,UPTM,CRTOR,OLMK";
       $zzx=UX("insert into coode_dspckeyx(".$sqlx.")select ".$sqlx." from coode_dspckey where datamark='".$datamark."' and concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey where datamark='".$datamark."')");
       $bbx=UX("delete from coode_dspckeyx where concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey)");
       $zzy=UX("insert into coode_dspckeyy(".$sqlx.")select ".$sqlx." from coode_dspckey where datamark='".$datamark."' and concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey where datamark='".$datamark."')");
       $bby=UX("delete from coode_dspckeyy where concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey)");
       $zzz=UX("insert into coode_dspckeyz(".$sqlx.")select ".$sqlx." from coode_dspckey where datamark='".$datamark."' and concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey where datamark='".$datamark."')");
       $bbz=UX("delete from coode_dspckeyz where concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey)");
       //在表单表格显示中计算xyz的文件structurex.json
       return 1;
     }else{
        return 0;
     }
    }else{
       return 0;
    }
}
//删除一个结构


?>