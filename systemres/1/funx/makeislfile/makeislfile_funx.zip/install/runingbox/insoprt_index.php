<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
  error_reporting(0);
   register_shutdown_function('zyfshutdownfunc'); 
   set_error_handler('zyferror'); 
   include 'insoprt_base.php';          
   $way=$_GET["way"];
$motherhost=$_GET["motherhost"];
$ssmark=$_GET["ssmark"];
switch($way){
  case "getres":
  //$tabtxt=file_get_contents("http://".$motherhost."/localxres/funx/anyshort/?stid=asS6C&pnum=30"); //远程
  $tabtxt=file_get_contents("firsttab.json");  //本地
  $tabdata=json_decode($tabtxt,false);
  $vls=$tabdata->vls;
  for ($ii=0;$ii<count($vls);$ii++){
   $tabnm=$vls[$ii]->TABLE_NAME;
   $tabtt=$vls[$ii]->tabtitle;
   $srckey=$vls[$ii]->srckey;
   $srcttk=$vls[$ii]->srcttk;
   $parreskey=$vls[$ii]->parreskey;
   $crtsql=tostring($vls[$ii]->createsql);
   $conn=mysql_connect(gl(),glu(),glp());
   $zz=updatingx($conn,glb(),$crtsql,"utf8");
   $sqlx="schm,TABLE_NAME,olmkkey,srckey,srcttk,parreskey,tabtitle,createsql,CRTM,UPTM,OLMK";
   $sqly="'".glb()."','".$tabnm."','OLMK','".$srckey."','".$srcttk."','".$parreskey."','".$tabtt."','".$crtsql."',now(),now(),md5(RAND())";
   $conn=mysql_connect(gl(),glu(),glp());
   $zz=updatings($conn,glb(),"insert into coode_tablist(".$sqlx.")values(".$sqly.")","utf8");  
  }
  //echo file_get_contents("http://".$motherhost."/localxres/funx/askinstall/?ssmark=".$ssmark); //远程
  echo file_get_contents("allres.json"); //本地
  break;
  case "fnsres":
  $restype=$_GET["restype"];
  $rescode=$_GET["rescode"];
  echo file_get_contents("http://".$motherhost."/localxres/funx/fnsinstall/?ssmark=".$ssmark."&rescode=".$rescode."&restype=".$restype);
  break;
  default;
}
          
?>