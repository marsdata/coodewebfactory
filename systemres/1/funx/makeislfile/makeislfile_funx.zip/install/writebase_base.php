<?php
function gl(){return "[cdip]";}//DESCRIB glb():本系统mysql 数据库IP END@glb()
function glu(){return "[cduser]";}//DESCRIB glu():本系统mysql 数据库用户名 END@glu()
function glp(){return "[cdpass]";}//DESCRIB glp():本系统mysql 数据库密码 END@glp()
function glb(){return "[cdbase]";}//DESCRIB glb():本系统mysql 数据库 END@lgb()
function gln(){return "[firstsys]";}//DESCRIB gln():当前使用系统名称 END@gln()
function gla(){return "[ak]";}//DESCRIB gla():当前apikey END@gln()
function glv(){return "[av]";}//DESCRIB glv():当前api verfy 使用系统版本号 END@gln()
function glt(){return "[sitename]";}//DESCRIB glt():当前实例名称 END@glt()
function glm(){return "[motherhost]";}//DESCRIB glm():母系统域名 END@glt() localhost 为本地模式不联网
function hostcode(){return "[hostcode]";}//DESCRIB glr():授权注册码 END@glt() 申请试用后，提供服务器IP地址，给您安装，转移操作
function runblog(){return "[runblog]";}//日志记录是否开启
function runprocess(){return "[runprocess]";}//日志记录是否开启
function remoteway(){return "[remoteway]";}//远程模式，可以上传资源到母机
function bl(){return "[bdip]";}//DESCRIB glb():业务系统mysql 数据库IP END@glb()
function blu(){return "[bduser]";}//DESCRIB glu():业务系统mysql 数据库用户名 END@glu()
function blp(){return "[bdpass]";}//DESCRIB glp():业务系统mysql 数据库密码 END@glp()
function blb(){return "[bdbase]";}//DESCRIB glb():业务系统mysql 数据库 END@lgb()
function bln(){return "[secondsys]";}//DESCRIB gln():当前业务使用系统名称 END@gln()
function blt(){return "[bussname]";}//DESCRIB glt():当前实例名称 END@glt()
//-------------配置分界线
function _get($str){ $val = !empty($_GET[$str]) ? $_GET[$str] : ""; return $val; } //DESCRIB ():  END@()

function _post($str){ $val = !empty($_POST[$str]) ? $_POST[$str] : ""; return $val; } //DESCRIB ():  END@()

function _server($str){$val = !empty($_SERVER[$str]) ? $_SERVER[$str] : ""; return $val; }//DESCRIB ():  END@()

function _cookie($str){$val = !empty($_COOKIE[$str]) ? $_COOKIE[$str] : ""; return $val; }//DESCRIB ():  END@()

function combineurl($qu,$hu){if (substr($qu,-1)=="/"){$qu=killlaststr($qu);}if (substr($hu,0,1)=="/"){return $qu.$hu;}else{return $qu."/".$hu;}}//DESCRIB ():  END@()

function countresult($fullresult){if (strpos($fullresult,"数据库报错")<=0){$partkn=explode("#/#",$fullresult);$countkn=count($partkn);return $countkn-2;}else{return 0;}}//DESCRIB ():  END@()

function glw(){
    if ($_SERVER["SERVER_PORT"] == "80"){
      return $_SERVER["HTTP_HOST"]."/";
    }else{
      return $_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"]."/";  
    }
}//DESCRIB glw():本服务器域名  结尾要加/ 如果没有域名请用本机分配的固定IP,结尾也要加/ END@glw()

function getRandChar($length){$str = null;$strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";$max = strlen($strPol)-1;for($i=0;$i<$length;$i++){$str.=$strPol[rand(0,$max)]; }return $str;}

function huanhang(){return "\r\n";}//DESCRIB ():  END@()

function hou($fullstr,$astr){if ($fullstr!="" and $astr!=""){$cunzaibu=strpos("x".$fullstr,$astr);if ($cunzaibu>0 ){$spos=strpos($fullstr,$astr);$lens=strlen($astr);$alll=strlen($fullstr);return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));}else{return $fullstr;};}else{return "";}}//DESCRIB (): 完美兼容中文混合取字符串后面 END@()

function killlaststr($strx){ return substr($strx,0,strlen($strx)-1);}

function localroot(){if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){$gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";}else{$gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);};if (strpos($gml,":")>0){$qdq=qian($gml,":");$gml=strtoupper($qdq).":".hou($gml,":");};return $gml;}//DESCRIB localroot(): 获取本地根目录 END@localroot()

function mysql_connect($fi,$fu,$fp){return new mysqli($fi,$fu,$fp);}//DESCRIB mysql_connect(): 连接数据库方法，如果是php5.5- 去掉此函数并修改select相关方法 END@mysql_connect()

function qian($fullstr,$astr){if ($fullstr!="" and $astr!=""){$cunzaibu=strpos("x".$fullstr,$astr);if ($cunzaibu>0 ){$astrlen=strpos($fullstr,$astr);$fmrt=substr($fullstr,0,$astrlen);return $fmrt;}else{return $fullstr;}}else{return "";}}//DESCRIB qian(): 完美兼容中文混合 END@qian()

function SX($asqlstr){$conn=mysql_connect(gl(),glu(),glp());return selecteds($conn,glb(),$asqlstr,"utf8","");}//DESCRIB ():  END@()

function String2Hex($string){if (substr($string,0,10)=="dTYPE_HEX:"){return $string;}else{$hex='';for ($i=0; $i < strlen($string); $i++){$hex .= dechex(ord($string[$i]));}return $hex;}}

function UX($asqlstr){$conn=mysql_connect(gl(),glu(),glp());return updatings($conn,glb(),$asqlstr,"utf8");}//DESCRIB ():  END@()

function onlymark(){
   return makeguid();
}//DESCRIB ():  END@()


function es($strx){
    $strx=str_replace(" ","",$strx);
    $strx=str_replace("un"."defined","",$strx);
    if ($strx!=""){
        return 1;
    }else{
        return 0;
    }
}

function dftval($valx,$valy){
    if (notemptyb($valx)){
        return $valx;
    }else{
        return $valy;
    }
}

function unstrs($gfstring){
  if ($gfstring!=""){
    $gftxt=str_replace('«','<'.'?'.'p'.'hp',$gfstring);
    $gftxt=str_replace('»','?'.'>',$gftxt);
    $gftxt=str_replace("^","'",$gftxt);
    $gftxt=str_replace("卍卍","\r\n",$gftxt);
    $gftxt=str_replace("卍","\r\n",$gftxt);
    $gftxt=str_replace("\\\"","\"",$gftxt);
    $gftxt=str_replace('\\','',$gftxt);
    $gftxt=str_replace("δ","&",$gftxt);
    $gftxt=str_replace("&amp;","&",$gftxt);
    $gftxt=str_replace("＝","=",$gftxt);
    $gftxt=str_replace('？','?',$gftxt);
    $gftxt=str_replace("＋","+",$gftxt);
    $gftxt=str_replace("/r/n","\r\n",$gftxt);
    $gftxt=str_replace("|~","\"",$gftxt); //要转义的 ""
    $gftxt=str_replace('/~','\"',$gftxt); //不转
    $gftxt=str_replace('@r@n','".\'\r\n\'."',$gftxt);
    $gftxt=str_replace('/-r/-n','\r\n',$gftxt);
    $gftxt=str_replace("↘","\\",$gftxt);
    return $gftxt;
   }else{
    return "";
   }
  }
  
function anyvalue($fullresult,$keynm,$sqc)
{
  $keyname=qian($fullresult,"#/#");
  $partkn=explode("#-#",$keyname);
  $partresult=explode("#/#",$fullresult);
  $countprs=count($partresult);
  $countkn=count($partkn);
  $tempkey=0;
  for ($x=0;$x<=$countkn-1;$x++)
   {
    if ($partkn[$x]==$keynm)
    {
     $tempkey=$x;
     };
   };
  $sqcresult=$partresult[$sqc+1];
  $partpart=explode("#-#",$sqcresult);
  return $partpart[$tempkey];
}//DESCRIB ():  END@()

function spacex($nx){
    $tmpx="";
    for ($i=0;$i<$nx;$i++){
        $tmpx=$tmpx." ";
    }
    return $tmpx;
}


function makereturnjson($sttx,$msgx,$rdrurl){
    if ($sttx!="" and $msgx!=""){
        return '{"status":"'.$sttx.'","msg":"'.$msgx.'","redirect":"'.$rdrurl.'"}';
    }else{
        return '{"status":"0","msg":"未定义状态","redirect":"'.$rdrurl.'"}';
    }
}

function overfile($fnm,$ftxt){
  $lsx=explode("/",$fnm);
  $totls=count($lsx);
  $frt=str_replace($lsx[$totls-1],"",$fnm);
  is_dir($frt) OR mkdir($frt, 0777, true); 
 $myfile = fopen($fnm, "w") or die("Unable to open file!");
 $txt = $ftxt;
 fwrite($myfile, $txt);
 fclose($myfile);
 return 1;
}

function TX($tsql){
    if ($tsql!=""){
     $keyx=qian(hou($tsql,"elect"),"from");
     $keyx=str_replace(" ","",$keyx);
     if (strpos($tsql,"limit")>0){
        $pnumx=hou(hou($tsql,"limit"),",");
     }else{
        $pnumx="30";
     }
     $ptkx=explode(",",$keyx);
     $totp=count($ptkx);
     $headx="";
     $bodyx="";
     for ($i=0;$i<$totp;$i++){
        $mykey[$i]=qian($ptkx[$i],"@");
        $mytit[$i]=qian(hou($ptkx[$i],"@"),"(");
        $mytype[$i]=qian(hou($ptkx[$i],"("),")");
        $headx=$headx.$mykey[$i]."#-#";
     }
     $headx=$headx."#/#";
     for ($j=0;$j<intval($pnumx);$j++){
        for ($i=0;$i<$totp;$i++){
         $bodyx=$bodyx.gettestvalue($j,$mykey[$i],$mytit[$i],$mytype[$i])."#-#";
        }
        $bodyx=$bodyx."#/#";
     }
     return $headx.$bodyx;
    }else{
     return "ERROR#/#NO SQLSTR";   
    }
}

function AV($expx){
  //expx= tabnm@cdt=1||b=2&&c=4:::.*SNO
  $rtnav=Array(Array());
  $tabnm=qian($expx,"@");
  $cdtx=qian(hou($expx,"@"),":::");
  $cdty=str_replace("=","='",$cdtx);
  $cdty=str_replace(":",":'",$cdty);
  $cdty=str_replace("&&","'&&",$cdty);
  $cdty=str_replace("||","'||",$cdty);
  $cdty=str_replace("*","%",$cdty);
  $cdty=str_replace("||"," or ",$cdty);
  $cdty=str_replace("&&"," and ",$cdty);
  $cdty=str_replace(":"," like ",$cdty);
  $keyx=hou($expx,":::");
  $rtnav["keys"][0]=$keyx;
  $rtnav["tabname"][0]=$tabnm;
  if ($tabnm!="" and $cdtx!="" and $keyx!=""){
   if (strpos($keyx,",")){
    $ptk=explode(",",$keyx);
    $drst=SX("select ".$keyx." from ".$tabnm." where ".$cdty);
    $totd=countresult($drst);
    if ($totd>1){
    $rtnav[0][0]=9;
    $rtnav["tot"][0]=$totd;
     for ($d=0;$d<$totd;$d++){     
       for ($k=0;$k<count($ptk);$k++){
        $rtnav[$ptk[$k]][$d]=anyvalue($drst,$ptk[$k],$d);
       }
     }
    }else if ($totd==1){
       $rtnav[0][0]=3;
       $rtnav["tot"][0]=$totd;
       for ($k=0;$k<count($ptk);$k++){
        $rtnav[$ptk[$k]][$d]=anyvalue($drst,$ptk[$k],0);
       }
    }else{
     $rtnav["tot"][0]=$totd;
     $rtnav[0][0]=0;
    }
  }else{
    switch($keyx){
      case "*":
      $allkeys=UX("select allkeys as result from coode_tablist where TABLE_NAME='".$tabnm."'");
      $allkeyx=hou($allkeys,"|");
      $keyx=$allkeyx;
      $rtnav["keys"][0]=$keyx;
      $ptk=explode(",",$allkeyx);
      $drst=SX("select ".$keyx." from ".$tabnm." where ".$cdty);
      $totd=countresult($drst);
      if ($totd>1){
         $rtnav[0][0]=9;
         $rtnav["tot"][0]=$totd;
         $rtnav[0][1]=$drst;
         for ($d=0;$d<$totd;$d++){     
            for ($k=0;$k<count($ptk);$k++){
                $rtnav[$ptk[$k]][$d]=anyvalue($drst,$ptk[$k],$d);
            }
         }
      }else if ($totd==1){
         $rtnav[0][0]=3;
         $rtnav["tot"][0]=$totd;
         $fmline="";
         for ($k=0;$k<count($ptk);$k++){
           $rtnav[$ptk[$k]][$d]=anyvalue($drst,$ptk[$k],0);
           $fmline=$fmline.anyvalue($drst,$ptk[$k],0).",";
         }
        $fmline=killlaststr($fmline);
        $rtnav[0][1]=$fmline;
      }else{
       $rtnav[0][1]="";
       $rtnav["tot"][0]=$totd;
       $rtnav[0][0]=0;
      }
      break;
      case ".":
       $totd=UX("select count(*) as result from ".$tabnm." where ".$cdty);
       $rtnav["tot"][0]=$totd;
       $rtnav[0][1]=$totd;
       $rtnav[0][0]=1;
      break;
      default:
       $drst=SX("select ".$keyx." from ".$tabnm." where ".$cdty);
       $totd=countresult($drst);
       if ($totd>1){
        $rtnav["tot"][0]=$totd;
        $rtnav[0][0]=4;
        $fmline="";
        for ($d=0;$d<$totd;$d++){           
          $rtnav[$keyx][$d]=anyvalue($drst,$keyx,$d);
          $fmline=$fmline.anyvalue($drst,$keyx,$d).",";
        }
        $fmline=killlaststr($fmline);
        $rtnav[0][1]=$fmline;
       }else if ($totd==1){
        $rtnav["tot"][0]=$totd;
        $rtnav[0][1]=anyvalue($drst,$keyx,0);
        $rtnav[0][0]=1;
       }else{
        $rtnav[0][1]="";
        $rtnav["tot"][0]=$totd;
        $rtnav[0][0]=0;
       }
    }//swc
  }
 }else{//not empty
     $rtnav["tot"][0]=0;
     $rtnav[0][0]=0;
 }
 return $rtnav;
}

function KT($cstr){
  $ktypex=file_get_contents(combineurl("http://".glw(),"/localxres/funx/aikeytypes/?chkeyx=".$cstr));
  $ktypex=strtolower($ktypex);
  $dtype=qian($ktypex,"(");
  $dtlen=qian(hou($ktypex,"("),")");
  //bit date time timestamp datetime year enum set text blob
  switch($dtype){
    case "bit":
    return $dtype;
    break;  
    case "timestamp":
    return $dtype;
    break;   
    case "time":
    return $dtype;
    break;   
    case "year":
    return $dtype;
    break;   
    case "enum":
    return $dtype;
    break;   
    case "set":
    return $dtype;
    break;   
    case "date":
    return $dtype;
    break;
    case "datetime":
    return $dtype;
    break;
    case "text":
    return $dtype;
    break;
    case "longtext":
    return $dtype;
    break;
    case "blob":
    return $dtype;
    break;
    case "decimal":
    return $dtype."(10,4)";
    break;
    default:
    return $ktypex;
  }
}

function RD($dmark){
$datamark=$dmark;
$dkrst=SX("select datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib   from coode_dspckey where datamark='".$datamark."' order by sqx");
  $totdk=countresult($dkrst);
  $fmtps="";
  $fmrcd="datasno,";
  $fmca="";
  $fmcb="";
  $clstxt="";
  for ($i=0;$i<$totdk;$i++){
   $keyx[$i]=anyvalue($dkrst,"keymark",$i);
   $keyy[$i]=anyvalue($dkrst,"keytitle",$i);
   $keytp[$i]=anyvalue($dkrst,"keytype",$i);
   $keylen[$i]=anyvalue($dkrst,"keylen",$i);
   $clstxtx[$i]=anyvalue($dkrst,"clstxt",$i);
   $classp[$i]=anyvalue($dkrst,"classp",$i);
   $keydxtype[$i]=anyvalue($dkrst,"dxtype",$i);
   $fmtps=$fmtps.'{"keyid":"'.$keyx[$i].'","keytitle":"'.$keyy[$i].'","keytype":"'.$keytp[$i].'","keylen":"'.$keylen[$i].'"},';
   $fmrcd=$fmrcd.$keyx[$i].",";
  }//totdk
  $fmtps=killlaststr($fmtps);
  $fmrcd=killlaststr($fmrcd)."@/@";
  $fmrcd=str_replace(",","@-@",$fmrcd);
  $jsondata='{"data":[<datavls>]}';
  $datademo='{"status":"1","datamark":"<datamark>","datatitle":"<datatitle>","totrcd":"<totrcd>","keytps":[<ktps>],"vls":[<datavls>]}';
  $datatitle=UX("select datatitle as result from coode_dataspace where datamark='".$datamark."'");
  $datarst=SX("select datasno,keymks,valmd5,keyvals from coode_dspcvindex where datamark='".$datamark."'");
  $totda=countresult($datarst);
  $datademo=str_replace("<datamark>",$datamark,$datademo);
  $datademo=str_replace("<datatitle>",$datatitle,$datademo);
  $datademo=str_replace("<ktps>",$fmtps,$datademo);
  $datademo=str_replace("<totrcd>",$totda,$datademo);
  $fmvalx="";
 
  for ($j=0;$j<$totda;$j++){
   $datasno=anyvalue($datarst,"datasno",$j);
   $keymks=anyvalue($datarst,"keymks",$j);
   $valmd5=anyvalue($datarst,"valmd5",$j);
   $keyvals=anyvalue($datarst,"keyvals",$j);
   $rcdrowx="";
   $fmitem="{";
   if ($keyvals!=""){
     $ptkey=explode(",",$keymks);     
     $ptval=explode("@-@",$keyvals);     
     for ($k=0;$k<count($ptkey);$k++){
       $valx[$ptkey[$k]]=$ptval[$k];             
       $rcdrowx=$rcdrowx.$ptval[$k].",";
       if ($classp[$k]==1){
         $fmca=$fmca.$ptval[$k].",";
       }
       if ($classp[$k]==2){
         $fmcb=$fmcb.$ptval[$k].",";
       }
     }//fork
       $fmrcd=$fmrcd.$datasno.",".$rcdrowx;
       $fmrcd=killlaststr($fmrcd).";";
    }else{
     $detailrst=SX("select keymark,keytype,intval,tinyintval,dateval,datetimeval,varcharval,textval,longtextval,decimalval,classp from coode_dspcval where datamark='".$datamark."' and datasno='".$datasno."'");
     $totdtl=countresult($detailrst);       
     for ($k=0;$k<$totdtl;$k++){
         $kmk=anyvalue($detailrst,"keymark",$k);
         $ktp=anyvalue($detailrst,"keytype",$k);
         $classpx=anyvalue($detailrst,"classp",$k);
         $intval=anyvalue($detailrst,"intval",$k);
         $tinyintval=anyvalue($detailrst,"tinyintval",$k);
         $dateval=anyvalue($detailrst,"dateval",$k);
         $datetimeval=anyvalue($detailrst,"datetimeval",$k);
         $varcharval=anyvalue($detailrst,"varcharval",$k);
         $textval=anyvalue($detailrst,"textval",$k);
         $longtextval=anyvalue($detailrst,"longtextval",$k);
         $decimalval=anyvalue($detailrst,"decimalval",$k);
         switch($ktp){
           case "int":
           $valx[$kmk]=$intval;
           break;
           case "tinyint":
           $valx[$kmk]=$tinyintval;
           break;
           case "dateval":
           $valx[$kmk]=$dateval;
           break;
           case "datetimeval":
           $valx[$kmk]=$datetimeval;
           break;
           case "varcharval":
           $valx[$kmk]=$varcharval;
           break;
           case "textval":
           $valx[$kmk]=$textval;
           break;
           case "longtextval":
           $valx[$kmk]=$longtextval;
           break;
           case "decimalval":
           $valx[$kmk]=$decimalval;
           break;
           default:
         }//swc
         $rcdrowx=$rcdrowx.$valx[$kmk].",";         
         if (intval($classpx)==1){
           $fmca=$fmca.$valx[$kmk].",";
         }
         if (intval($classpx)==2){
           $fmcb=$fmcb.$valx[$kmk].",";
         }
     }//fork     
     $fmrcd=$fmrcd.$datasno.",".$rcdrowx;
     $fmrcd=killlaststr($fmrcd).";";     
    }//ifkeyval
    
    for ($i=0;$i<$totdk;$i++){
       $fmitem=$fmitem.'"'.$keyx[$i].'":"'.$valx[$keyx[$i]].'",';
    }
     $fmitem=killlaststr($fmitem).'}';
     $fmvalx=$fmvalx.$fmitem.',';
  }//forj
  $fmvalx=killlaststr($fmvalx);
  $fmca=killlaststr($fmca);
  $fmcb=killlaststr($fmcb);
  if ($fmca!="" and $fmcb!=""){
   $clstxt=$fmcb."|".$fmca;
  }
 
  $fmrcd=str_replace(",","@-@",$fmrcd);
  $fmrcd=str_replace(";","@/@",$fmrcd);
  
  $datademo=str_replace("<datavls>",$fmvalx,$datademo);
  $jsondata=str_replace("<datavls>",$fmvalx,$jsondata);
  
  $jshortpath=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/jsshort.json");
  $jsonpath=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/data.json");
  $coodex=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/coodercd.txt");
  $coodeclstxt=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/coodeclstxt.txt");
  $z0=overfile($jshortpath,$datademo);
  $z1=overfile($jsonpath,$jsondata);
  $newrcd=str_replace("@-@","#"."-#",str_replace("@/@","#"."/#",$fmrcd));
  $z2=overfile($coodex,$newrcd);
  $z3=overfile($coodeclstxt,$clstxt);
  return true;
}

function ND($dmark,$pk,$pvstr){
 if (es($dmark)*es($pk)*es($pvstr)==1){
 $lastsno=UX("select datasno as result from coode_dspcvindex where datamark='".$dmark."' order by datasno desc");
 $newsno=intval($lastsno)+1;
 $kval=array();
  if (strpos($pk,"&")>0){
    $ptk=explode("&",$pk);
    $totpt=count($ptk);
    for ($nn=0;$nn<$totpt;$nn++){
      $tempk=$ptk[$nn];
      $tempv=dftval($_POST[$tempk],"");
    }
    $ptv=explode("&",$pvstr);
    $totptv=count($ptv);
    for ($mm=0;$mm<$totptv;$mm++){
       $temppart=$ptv[$mm];
       $tempkey=qian($ptv[$mm],"=");
       $tempval=unstrs(hou($ptv[$mm],"="));
       $kval[$tempkey]=dftval($tempval,unstrs($_POST[$tempkey]));       
    }
    $tt=UX("insert into coode_dspcval(datamark,datasno,keymark,keytitle,keytype,keylen,CRTM,UPTM,OLMK)select datamark,'".($newsno)."',keymark,keytitle,keytype,keylen,now(),now(),RAND()*1000000 from coode_dspckey where datamark='".$dmark."'");
    $dskrst=SX("select keymark,keytype,keytitle from coode_dspckey where datamark='".$dmark."'");
    $totds=countresult($dskrst);
    $fmk="";
    $fmv="";
    for ($oo=0;$oo<$totds;$oo++){
       $kmk=anyvalue($dskrst,"keymark",$oo);
       $ktp=anyvalue($dskrst,"keytype",$oo);
       $fmk=$fmk.$kmk.",";
       $fmv=$fmv.$kval[$kmk]."@-@";
       $kxx=$ktp."val";
       $dx=UX("update coode_dspcval set ".$kxx."='".$kval[$kmk]."',UPTM=now() where datamark='".$dmark."' and datasno='".($newsno)."' and keymark='".$kmk."'");      
    }
    $fmk=killlaststr($fmk);
    $fmv=killlaststr($fmv);
    $fmv=killlaststr($fmv);
    $fmv=killlaststr($fmv);
    $allkeys=$fmk;
    $tempdata=$fmv;
    $zz=UX("insert into coode_dspcvindex(datamark,datasno,keymks,valmd5,keyvals,CRTM,UPTM,CRTOR,OLMK)values('".$dmark."','".($newsno)."','".$allkeys."','".md5($tempdata)."','".$tempdata."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."') ON DUPLICATE KEY update UPTM=now(),keymks='".$allkeys."',valmd5='".md5($tempdata)."',keyvals='".$tempdata."'");
    //$bb=addprcx("insert into coode_dspcvindex(datamark,datasno,keymks,valmd5,keyvals,CRTM,UPTM,CRTOR,OLMK)values('".$dmark."','".($newsno)."','".$allkeys."','".md5($tempdata)."','".$tempdata."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."') ON DUPLICATE KEY update UPTM=now(),keymks='".$allkeys."',valmd5='".md5($tempdata)."',keyvals='".$tempdata."'".huanhang());
  }else{
      $temppart=$pvstr;
      $tempkey=qian($pvstr,"=");
      $tempval=unstrs(hou($pvstr,"="));
      $kval[$tempkey]=dftval($tempval,unstrs($_POST[$tempkey]));       
    
    $tt=UX("insert into coode_dspcval(datamark,datasno,keymark,keytitle,keytype,keylen,CRTM,UPTM,OLMK)select datamark,'".($newsno)."',keymark,keytitle,keytype,keylen,now(),now(),RAND()*1000000 from coode_dspckey where datamark='".$dmark."'");
    $dskrst=SX("select keymark,keytype,keytitle from coode_dspckey where datamark='".$dmark."'");
    $totds=countresult($dskrst);
    $fmk="";
    $fmv="";
    for ($oo=0;$oo<$totds;$oo++){
       $kmk=anyvalue($dskrst,"keymark",$oo);
       $ktp=anyvalue($dskrst,"keytype",$oo);
       $fmk=$fmk.$kmk.",";
       $fmv=$fmv.$kval[$kmk]."@-@";
       $kxx=$ktp."val";
       $dx=UX("update coode_dspcval set ".$kxx."='".$kval[$kmk]."',UPTM=now() where datamark='".$dmark."' and datasno='".($newsno)."' and keymark='".$kmk."'");      
    }
    $fmk=killlaststr($fmk);
    $fmv=killlaststr($fmv);
    $fmv=killlaststr($fmv);
    $fmv=killlaststr($fmv);
    $allkeys=$fmk;
    $tempdata=$fmv;
    $zz=UX("insert into coode_dspcvindex(datamark,datasno,keymks,valmd5,keyvals,CRTM,UPTM,CRTOR,OLMK)values('".$dmark."','".($newsno)."','".$allkeys."','".md5($tempdata)."','".$tempdata."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."') ON DUPLICATE KEY update UPTM=now(),keymks='".$allkeys."',valmd5='".md5($tempdata)."',keyvals='".$tempdata."'");
  }
 }else{
   return -3.14;
 }
}
//在已有的DASP中更改

function NS($datamark,$datatitle,$kdefine){
  $extds=UX("select count(*) as result from coode_dataspace where datamark='".$datamark."'");
  if (intval($extds)==0){
    $ptkdf=explode(",",$kdefine);
    $toto=count($ptkdf);
    $srcid=$datamark;
    $srcarea="";
    $sqla="datamark,datatitle,CRTM,UPTM,CRTOR,OLMK";
    $sqlb="'$datamark','$datatitle',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";
    $zab=UX("insert into coode_dataspace(".$sqla.")values(".$sqlb.")");
    if ($srcid!=""){
     $strudemo='{"dspccode":"[dspccode]","dspctitle":"[dspctitle]","keynames":"[keynames]","ktps":[<kdata>]}';
     $itemdemo='{"keyname":"[keyname]","keytitle":"[keytitle]","dxtype":"[dxtype]","datatype":"[datatype]","keylen":"[keylen]"},';
     $strudemo=str_replace("[dspctitle]",$datatitle,$strudemo);
     $fma="";
      for ($bb=0;$bb<intval($toto);$bb++){
        $titlex=qian($ptkdf[$bb],"(");  
        $orgid=getRandChar(8);
        //String2Hex($titlex);
        $otypex=qian(hou($ptkdf[$bb],"("),")");
           switch($otypex){
            case "tinyint":
            $keytype="tinyint";
            $keylen="4";
            break;
            case "int":
            $keytype="int";
            $keylen="11";
            break;
            case "varchar20":
            $keytype="varchar";
            $keylen="20";
            break;
            case "varchar50":
            $keytype="varchar";
            $keylen="50";
            break;
            case "varchar100":
            $keytype="varchar";
            $keylen="100";
            break;
            case "varchar255":
            $keytype="varchar";
            $keylen="255";
            break;
            case "varchar1024":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "decimal1":
            $keytype="decimal";
            $keylen="10.1";
            break;
            case "decimal2":
            $keytype="decimal";
            $keylen="10.2";
            break;
            case "decimal3":
            $keytype="decimal";
            $keylen="10.3";
            break;
            case "decimal4": 
            $keytype="decimal";
            $keylen="10.4";
            break;
            case "select":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "multiselect":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "checkbox":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "multicheckbox":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "imagex":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "images":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "filex":
            $keytype="varchar";
            $keylen="1024";
            break;
            case "files":
            $keytype="varchar";
            $keylen="1024";
            break;
          }
        $itemx=$itemdemo;
        $itemx=str_replace("[keyname]",$orgid,$itemx);
        $itemx=str_replace("[keytitle]",$titlex,$itemx);
        $itemx=str_replace("[dxtype]",$otypex,$itemx);
        $itemx=str_replace("[datatype]",$keytype,$itemx);
        $itemx=str_replace("[keylen]",$keylen,$itemx);
        $fma=$fma.$itemx;
        if ($titlex!="" and $titlex!="undefined"){
           $extx=UX("select count(*) as result from coode_dspckey where domainmark='".$srcarea."' and datamark='".$srcid."' and keytitle='".$titlex."' ");
           if (intval($extx)==0){
             $z=UX("insert into coode_dspckey(domainmark,datamark,dxtype,keytype,keylen,keymark,keytitle,CRTM,UPTM,CRTOR)values('".$srcarea."','".$srcid."','".$otypex."','".$ktype."','".$keylen."','".$orgid."','".$titlex."',now(),now(),'".$_COOKIE["uid"]."')");         
           }else{
             $z=UX("update coode_dspckey set UPTM=now(),dxtype='".$otypex."',keytype='".$keytype."',keylen='".$keylen."' where domainmark='".$srcarea."' and datamark='".$srcid."' and keytitle='".$titlex."' ");
           }   
         }
       }
       $fma=killlaststr($fma);
       $strudemo=str_replace("[kdata]",$fma,$strudemo);
       if ($srcid!=""){
        $strujson=combineurl(localroot(),"/localxres/dataspacex/".$srcid."/","structure.json");       
        $zz=overfile($strujson,$strudemo);
       }
       $bb=UX("delete from coode_dspckey where timestampdiff(second,UPTM,now())>30 and domainmark='".$srcarea."' and datamark='".$srcid."' ");    
       $sqlx="domainmark,datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib,CRTM,UPTM,CRTOR,OLMK";
       $zzx=UX("insert into coode_dspckeyx(".$sqlx.")select ".$sqlx." from coode_dspckey where datamark='".$datamark."' and concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey where datamark='".$datamark."')");
       $bbx=UX("delete from coode_dspckeyx where concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey)");
       $zzy=UX("insert into coode_dspckeyy(".$sqlx.")select ".$sqlx." from coode_dspckey where datamark='".$datamark."' and concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey where datamark='".$datamark."')");
       $bby=UX("delete from coode_dspckeyy where concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey)");
       $zzz=UX("insert into coode_dspckeyz(".$sqlx.")select ".$sqlx." from coode_dspckey where datamark='".$datamark."' and concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey where datamark='".$datamark."')");
       $bbz=UX("delete from coode_dspckeyz where concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey)");
       //在表单表格显示中计算xyz的文件structurex.json
       return 1;
     }else{
        return 0;
     }
    }else{
       return 0;
    }
}
//删除一个结构

function SY($dmk){
    return file_get_contents(combineurl(localroot(),"/localxrex/dataspacex/".$dmk."/coodercd.txt"));
}

function CX($sqlrcd,$skey){
  $totcx=countresult($sqlrcd);
  $fmall="";
  for ($cc=0;$cc<$totcx;$cc++){
      $fmall=$fmall.anyvalue($sqlrcd,$skey,$cc).",";
  }
  return killlaststr($fmall);
}


?>