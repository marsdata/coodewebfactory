<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       eval(RESFUNSET("tabdataoprt"));
eval(RESFUNSET("resrelyrp"));
$a=time();
$sysid=dftval($_GET["sysid"],"");
$restype=dftval($_GET["restype"],"");
$snoy=dftval($_GET["snox"],"");
$rescode=str_replace("()","",dftval($_GET["rescode"],""));
$kk=UX("delete from coode_resrelyinst where   restype='".$restype."' and rescode='".$rescode."'");
  $b=time();
  echo makereturnjson("1","制作".$restype."@".$rescode."数据安装脚本成功，耗时".($b-$a)."秒","");
  echo makereturnjson("0","制作".$restype."@".$rescode."数据安装脚本失败","");
       session_write_close();
?>