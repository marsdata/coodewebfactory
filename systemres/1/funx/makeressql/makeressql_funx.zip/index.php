<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sysid=dftval($_GET["sysid"],"");
$restype=dftval($_GET["restype"],"");
$rescode=dftval($_GET["rescode"],"");

if ($fma!=""){
  $zz=file_get_contents("http://".combineurl(glw(),"/localxres/funx/makeresinstall/?restype=".$restype."&rescode=".$rescode."&sysid=".$sysid));
  echo makereturnjson("1","写入成功",$imd5);
}else{
  echo makereturnjson("0","写入失败，未发现数据","");
}
     session_write_close();
?>