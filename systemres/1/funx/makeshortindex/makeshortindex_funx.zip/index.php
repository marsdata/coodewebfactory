<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sysid=$_GET["sysid"];
if ($sysid=="" or $sysid=="999"){
  $fxrst=SX("select sysid,shortid,shorttitle,tablename,CRTM,UPTM,vermd5 from coode_shortdata");
  $sysid="999";
  $savepath="/ORG/system/allshortindex.js";
}else{
  $fxrst=SX("select sysid,shortid,shorttitle,tablename,CRTM,UPTM,vermd5 from coode_shortdata where sysid='".$sysid."'");
  $savepath="/ORG/system/".$sysid."/tabs/shortindex.js";
}
$totfx=countresult($fxrst);
$srddemo='$shortindex=\'{"sysid":"'.$sysid.'","shortdata":[(shortdata)]}\';';
$demox='{"shortid":"[shortid]","sxsid":"[sxsid]","tablename":"[tablename]","shorttitle":"[shorttitle]","vermd5":"[vermd5]","CRTM":"[CRTM]","UPTM":"[UPTM]"},';
$fmxyz="";
for ($i=0;$i<$totfx;$i++){
  $demoy=$demox;
  $shortid=anyvalue($fxrst,"shortid",$i);  
  $tablename=anyvalue($fxrst,"tablename",$i);  
  $shorttitle=anyvalue($fxrst,"shorttitle",$i);
  $vermd5=anyvalue($fxrst,"vermd5",$i);
  $sxsid=anyvalue($fxrst,"sysid",$i);
  $CRTM=anyvalue($fxrst,"CRTM",$i);
  $UPTM=anyvalue($fxrst,"UPTM",$i);
  $demoy=str_replace("[shortid]",$shortid,$demoy);
  $demoy=str_replace("[sxsid]",$sxsid,$demoy);
  $demoy=str_replace("[tablename]",$tablename,$demoy);
  $demoy=str_replace("[shorttitle]",$shorttitle,$demoy);
  $demoy=str_replace("[vermd5]",$vermd5,$demoy);
  $demoy=str_replace("[CRTM]",$CRTM,$demoy);
  $demoy=str_replace("[UPTM]",$UPTM,$demoy);
  $fmxyz=$fmxyz.$demoy;
}
 $fmxyz=killlaststr($fmxyz);
 $srddemo=str_replace("(shortdata)",$fmxyz,$srddemo);
 $fullpath=combineurl(localroot(),$savepath);
 $v=overfile($fullpath,$srddemo);
 $bbb=file_get_contents("http://".glw()."DNA/EXF/qnyupload.php?lcfile=".$fullpath);
 echo '{"status":"1","msg":"成功-'.$totfx.'","redirect":""}';
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>