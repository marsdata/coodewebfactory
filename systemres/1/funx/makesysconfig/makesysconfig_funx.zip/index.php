<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sysid=$_GET["sysid"];
$z=anyfunrun("killoldtab","","","");
$z=anyfunrun("bakplot","","sysid=".$sysid,"");
$z=anyfunrun("bakdtf","","","");
$z=anyfunrun("baksysda","","","");
$z=anyfunrun("bakrole","","","");
$z=anyfunrun("bakpos","","","");
$z=anyfunrun("makesysdatabak","","sysid=".$sysid,"");
$x=makecore();
$zz=newsyscoretabfun($sysid);
$zx=UX("delete from coode_pagefuntab where sysid=''");
$demox=$sysid."config={\"sysid\":\"".$sysid."\",\"tabs\":\"[tabx]\",\"funs\":\"[funx]\",\"clss\":\"[clsx]\",\"chtmls\":\"[chtmls]\",\"menus\":\"[menus]\",\"cases\":\"[casex]\",\"pages\":\"[pagex]\",\"units\":\"[unity]\",\"unitp\":\"[unitx]\",\"sysitem\":\"[itemsql]\"}";
$tfs=SX("select sourceid from coode_pagefuntab where sourcecls='tab' and sysid='".$sysid."'");
 $tot=countresult($tfs);
 $fmt="";
 for ($i=0;$i<$tot;$i++){
   $fmt=$fmt.anyvalue($tfs,"sourceid",$i).",";
 }
 $fmt=killlaststr($fmt);
 $ffs=SX("select sourceid from coode_pagefuntab where sourcecls='fun' and sysid='".$sysid."'");
 $tot=countresult($ffs);
 $fmf="";
 for ($i=0;$i<$tot;$i++){
   $fmf=$fmf.anyvalue($ffs,"sourceid",$i).",";
 }
 $fmf=killlaststr($fmf);
 $cfs=SX("select sourceid from coode_pagefuntab where sourcecls='cls' and sysid='".$sysid."'");
 $tot=countresult($cfs);
 $fmc="";
 for ($i=0;$i<$tot;$i++){
   $fmc=$fmc.anyvalue($cfs,"sourceid",$i).",";
 }
 $fmc=killlaststr($fmc);
 $demox=str_replace("[tabx]",$fmt,$demox);
 $demox=str_replace("[funx]",$fmf,$demox);
 $demox=str_replace("[clsx]",$fmc,$demox);
 $psx=SX("select pageid from coode_compage");
$psx=hou($psx,"#/#");
$psx=str_replace("#/#",",",$psx);
$psx=str_replace("#-#",",",$psx);
$usx=SX("select unitmark from coode_comunit");
$usx=hou($usx,"#/#");
$usx=str_replace("#/#",",",$usx);
$usx=str_replace("#-#",",",$usx);
$csx=SX("select cfid from coode_caseform");
$csx=hou($csx,"#/#");
$csx=str_replace("#/#",",",$csx);
$csx=str_replace("#-#",",",$csx);
$csh=SX("select cssmark from coode_casehtml");
$csh=hou($csh,"#/#");
$csh=str_replace("#/#",",",$csh);
$csh=str_replace("#-#",",",$csh);
$uux=SX("select units from coode_tiny where sysid='".$sysid."' group by units");
$uux=hou($uux,"#/#");
$uux=str_replace("#/#",",",$uux);
$uux=str_replace("#-#",",",$uux);
$uuy=SX("select unitid from coode_cssunit where sysid='".$sysid."'");
$uuy=hou($uuy,"#/#");
$uuy=str_replace("#/#",",",$uuy);
$uuy=str_replace("#-#",",",$uuy);
$uux=onlyone($uux.",".$uuy);
$mns=SX("select menumark from coode_commenu ");
$mns=hou($mns,"#/#");
$mns=str_replace("#/#",",",$mns);
$mns=str_replace("#-#",",",$mns);
$demox=str_replace("[casex]",$csx,$demox);
$demox=str_replace("[chtmls]",$csh,$demox);
$demox=str_replace("[pagex]",$psx,$demox);
$demox=str_replace("[unitx]",$usx,$demox);
$demox=str_replace("[unity]",$uux,$demox);
$demox=str_replace("[menus]",$mns,$demox);
$x=UX("update coode_sysinformation set units='".$uux."' where sysid='".$sysid."'");
$ptux=explode(",",$uux);
$totpt=count($ptux);
for ($i=0;$i<$totpt;$i++){
  if ($ptux[$i]!=""){    
     if (strpos("xx".$ptux[$i],"@")<=0){
      copy_dir(localroot()."FACE/".$ptux[$i],localroot()."DEVELOPING/".$sysid."/FACE/".$ptux[$i]);
      if ($sysid=="coode"){
       copy_dir(localroot()."FACE/".$ptux[$i],localroot()."DEVELOPING/1/FACE/".$ptux[$i]);    
      }
     }
    $exty=UX("select count(*) as result from coode_cssunit where unitid='".$ptux[$i]."'");
    if (intval($exty)>0){
     $z=UX("update coode_cssunit set UPTM=now() where unitid='".$ptux[$i]."'");
    }else{
     $z=UX("insert into coode_cssunit(unitid,unittitle,OLMK,CRTM,UPTM,sysid)values('".$ptux[$i]."','','".onlymark()."',now(),now(),'".$sysid."')");     
    }
  }
}
 $curl=combineurl(localroot(),"/DNA/EXF/sysbase/install/".$sysid."config.js");
 $z=overfile($curl,$demox); 
$instpath=localroot()."DNA/EXF/sysbase/install/".$sysid."_tiny.js";
$srddemo="{\"tablename\":\"".$tablenm."\",\"vls\":[[data]]}";
$indemo="{\"type\":\"[type]\",\"keys\":\"[keys]\",\"valuex\":\"[valuex]\"}";
$fmjson="";
$crt=UX("select createsql as result from coode_tablist where TABLE_NAME='coode_tiny'");
$crtsql=gohex($crt);
$tdemo=$indemo;
$tdemo=str_replace("[type]","create",$tdemo);
$tdemo=str_replace("[keys]","",$tdemo);
$tdemo=str_replace("[valuex]",$crtsql,$tdemo);
$fmjson=$fmjson.$tdemo.",";
$tbdtrst=SX("select frmsql,datasql from coode_datainstall where srcid='".$sysid."_tiny'");
$totrst=countresult($tbdtrst);
for ($i=0;$i<$totrst;$i++){
 $tdemo=$indemo;
 $tdemo=str_replace("[type]","insert",$tdemo);
 $tdemo=str_replace("[keys]",anyvalue($tbdtrst,"frmsql",$i),$tdemo);
 $tdemo=str_replace("[valuex]",gohex(anyvalue($tbdtrst,"datasql",$i)),$tdemo);
 $fmjson=$fmjson.$tdemo.",";
}
$fmjson=killlaststr($fmjson);
$srddemo=$sysid."_tiny=".str_replace("[data]",$fmjson,$srddemo);
$x=overfile($instpath,$srddemo);
$instpath=localroot()."DNA/EXF/sysbase/install/".$sysid."_plot.js";
$srddemo="{\"tablename\":\"".$tablenm."\",\"vls\":[[data]]}";
$indemo="{\"type\":\"[type]\",\"keys\":\"[keys]\",\"valuex\":\"[valuex]\"}";
$fmjson="";
$crt=UX("select createsql as result from coode_tablist where TABLE_NAME='coode_plotdetail'");
$crtsql=gohex($crt);
$tdemo=$indemo;
$tdemo=str_replace("[type]","create",$tdemo);
$tdemo=str_replace("[keys]","",$tdemo);
$tdemo=str_replace("[valuex]",$crtsql,$tdemo);
$fmjson=$fmjson.$tdemo.",";
$tbdtrst=SX("select frmsql,datasql from coode_datainstall where srcid='".$sysid."_plot'");
$totrst=countresult($tbdtrst);
for ($i=0;$i<$totrst;$i++){
 $tdemo=$indemo;
 $tdemo=str_replace("[type]","insert",$tdemo);
 $tdemo=str_replace("[keys]",anyvalue($tbdtrst,"frmsql",$i),$tdemo);
 $tdemo=str_replace("[valuex]",gohex(anyvalue($tbdtrst,"datasql",$i)),$tdemo);
 $fmjson=$fmjson.$tdemo.",";
}
$fmjson=killlaststr($fmjson);
$srddemo=$sysid."_plot=".str_replace("[data]",$fmjson,$srddemo);
$x=overfile($instpath,$srddemo);
$instpath=localroot()."DNA/EXF/sysbase/install/".$sysid."_apps.js";
$srddemo="{\"tablename\":\"".$tablenm."\",\"vls\":[[data]]}";
$indemo="{\"type\":\"[type]\",\"keys\":\"[keys]\",\"valuex\":\"[valuex]\"}";
$fmjson="";
$crt=UX("select createsql as result from coode_tablist where TABLE_NAME='coode_appdefault'");
$crtsql=gohex($crt);
$tdemo=$indemo;
$tdemo=str_replace("[type]","create",$tdemo);
$tdemo=str_replace("[keys]","",$tdemo);
$tdemo=str_replace("[valuex]",$crtsql,$tdemo);
$fmjson=$fmjson.$tdemo.",";
$tbdtrst=SX("select frmsql,datasql from coode_datainstall where srcid='".$sysid."_apps'");
$totrst=countresult($tbdtrst);
for ($i=0;$i<$totrst;$i++){
 $tdemo=$indemo;
 $tdemo=str_replace("[type]","insert",$tdemo);
 $tdemo=str_replace("[keys]",anyvalue($tbdtrst,"frmsql",$i),$tdemo);
 $tdemo=str_replace("[valuex]",gohex(anyvalue($tbdtrst,"datasql",$i)),$tdemo);
 $fmjson=$fmjson.$tdemo.",";
}
$fmjson=killlaststr($fmjson);
$srddemo=$sysid."_apps=".str_replace("[data]",$fmjson,$srddemo);
$x=overfile($instpath,$srddemo);
$instpath=localroot()."DNA/EXF/sysbase/install/".$sysid."_sys.js";
$srddemo="{\"tablename\":\"".$tablenm."\",\"vls\":[[data]]}";
$indemo="{\"type\":\"[type]\",\"keys\":\"[keys]\",\"valuex\":\"[valuex]\"}";
$fmjson="";
$crt=UX("select createsql as result from coode_tablist where TABLE_NAME='coode_sysinformation'");
$crtsql=gohex($crt);
$tdemo=$indemo;
$tdemo=str_replace("[type]","create",$tdemo);
$tdemo=str_replace("[keys]","",$tdemo);
$tdemo=str_replace("[valuex]",$crtsql,$tdemo);
$fmjson=$fmjson.$tdemo.",";
$tbdtrst=SX("select frmsql,datasql from coode_datainstall where srcid='".$sysid."_sys'");
$totrst=countresult($tbdtrst);
for ($i=0;$i<$totrst;$i++){
 $tdemo=$indemo;
 $tdemo=str_replace("[type]","insert",$tdemo);
 $tdemo=str_replace("[keys]",anyvalue($tbdtrst,"frmsql",$i),$tdemo);
 $tdemo=str_replace("[valuex]",gohex(anyvalue($tbdtrst,"datasql",$i)),$tdemo);
 $fmjson=$fmjson.$tdemo.",";
}
$fmjson=killlaststr($fmjson);
$srddemo=$sysid."_sys=".str_replace("[data]",$fmjson,$srddemo);
$x=overfile($instpath,$srddemo);
$srddemo="{\"jsonid\":\"sysmarket\",\"vls\":[[data]]}";
$indemo="{\"sysid\":\"[sysid]\",\"systitle\":\"[systitle]\",\"syshead\":\"[syshead]\"}";
$tbdtrst=SX("select sysid,sysname,faceimg from coode_sysinformation");
$totrst=countresult($tbdtrst);
$fmjson="";
$instpath=localroot()."DNA/EXF/sysbase/install/sysmarket.js";
for ($i=0;$i<$totrst;$i++){
 $tdemo=$indemo;
 $tdemo=str_replace("[sysid]",anyvalue($tbdtrst,"sysid",$i),$tdemo);
 $tdemo=str_replace("[systitle]",anyvalue($tbdtrst,"sysname",$i),$tdemo);
 $tdemo=str_replace("[syshead]",anyvalue($tbdtrst,"faceimg",$i),$tdemo);
 $fmjson=$fmjson.$tdemo.",";
}
$fmjson=killlaststr($fmjson);
$srddemo="syslist=".str_replace("[data]",$fmjson,$srddemo);
$x=overfile($instpath,$srddemo);
echo "1";
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>