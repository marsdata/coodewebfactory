<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sysid=$_GET["sysid"];
$demo="<script type=\"text/javascript\" src=\"[fpath]\"></script>";
//$trst=SX("select sourceid,sourcecls from coode_pagefuntab where sysid='".$sysid."'");
//$tot=countresult($trst);
$fmdemo="";
  $tdemo=$demo;
  $tdemo=str_replace("[fpath]","http://".glw()."DNA/EXF/sysbase/jquery.min.js",$tdemo);
  $fmdemo=$fmdemo.$tdemo."\r\n";  
  $tdemo=$demo;
  $tdemo=str_replace("[fpath]","http://".glw()."DNA/EXF/sysbase/sysjs.js",$tdemo);
  $fmdemo=$fmdemo.$tdemo."\r\n";  
  $tot=0;
for ($i=0;$i<$tot;$i++){
  $tdemo=$demo;
  if (anyvalue($trst,"sourcecls",$i)=="fun"){
    $tdemo=str_replace("[fpath]","http://".glw()."DNA/EXF/sysbase/install/".anyvalue($trst,"sourceid",$i)."_fun.js",$tdemo);
  }
  if (anyvalue($trst,"sourcecls",$i)=="cls"){
    $tdemo=str_replace("[fpath]","http://".glw()."DNA/EXF/sysbase/install/".anyvalue($trst,"sourceid",$i)."_cls.js",$tdemo);
  }
  if (anyvalue($trst,"sourcecls",$i)=="tab"){
    $tdemo=str_replace("[fpath]","http://".glw()."DNA/EXF/sysbase/install/".anyvalue($trst,"sourceid",$i).".js",$tdemo);
  }
  $fmdemo=$fmdemo.$tdemo."\r\n";  
}
//$prst=SX("select pageid from coode_compage");
//$totp=countresult($prst);
$totp=0;
for ($i=0;$i<$totp;$i++){
  $tdemo=$demo;
  $tdemo=str_replace("[fpath]","http://".glw()."DNA/EXF/sysbase/install/".anyvalue($prst,"pageid",$i)."_page.js",$tdemo);
  $fmdemo=$fmdemo.$tdemo."\r\n";  
}
//$prst=SX("select unitmark from coode_comunit");
//$totp=countresult($prst);
$totp=0;
for ($i=0;$i<$totp;$i++){
  $tdemo=$demo;
  $tdemo=str_replace("[fpath]","http://".glw()."DNA/EXF/sysbase/install/".anyvalue($prst,"unitmark",$i)."_unit.js",$tdemo);
  $fmdemo=$fmdemo.$tdemo."\r\n";  
}
//$prst=SX("select cfid from coode_caseform");
//$totp=countresult($prst);
$totp=0;
for ($i=0;$i<$totp;$i++){
  $tdemo=$demo;
  $tdemo=str_replace("[fpath]","http://".glw()."DNA/EXF/sysbase/install/".anyvalue($prst,"cfid",$i)."_case.js",$tdemo);
  $fmdemo=$fmdemo.$tdemo."\r\n";  
}
  $tdemo=$demo;
  $tdemo=str_replace("[fpath]","http://".glw()."DNA/EXF/sysbase/install/".$sysid."config.js",$tdemo);
  $fmdemo=$fmdemo.$tdemo."\r\n";  
  $tdemo=$demo;
  $tdemo=str_replace("[fpath]","http://".glw()."DNA/EXF/sysbase/install/".$sysid."_apps.js",$tdemo);
  $fmdemo=$fmdemo.$tdemo."\r\n";  
  $tdemo=$demo;
  $tdemo=str_replace("[fpath]","http://".glw()."DNA/EXF/sysbase/install/".$sysid."_sys.js",$tdemo);
  $fmdemo=$fmdemo.$tdemo."\r\n";  
  $tdemo=$demo;
  $tdemo=str_replace("[fpath]","http://".glw()."DNA/EXF/sysbase/install/".$sysid."_plot.js",$tdemo);
  $fmdemo=$fmdemo.$tdemo."\r\n";  
  $tdemo=$demo;
  $tdemo=str_replace("[fpath]","http://".glw()."DNA/EXF/sysbase/install/".$sysid."_tiny.js",$tdemo);
  $fmdemo=$fmdemo.$tdemo;  
  echo $fmdemo;
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>