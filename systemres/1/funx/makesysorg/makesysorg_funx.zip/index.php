<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sysid=_get("sysid");
if ($sysid!=""){
 $kill=UX("delete from coode_plotdetail where plotmark='".$sysid."@org'");
 $sysname=UX("select sysname as result from coode_sysinformation where sysid='".$sysid."'");
 $x=UX("insert into coode_plotlist (plotmark,layoutid,plotcls,markname,CRTOR,CRTM,UPTM,OLMK)values('system@org','coode_plotdetail','sysorg','本实例所有系统','',now(),now(),'".onlymark()."')"); 
 $x=UX("insert into coode_plotlist (plotmark,layoutid,plotcls,markname,CRTOR,CRTM,UPTM,OLMK)values('".$sysid."@org','coode_plotdetail','sysorg','".$sysname."','',now(),now(),'".onlymark()."')"); 
 $sqlx="plotmark,level,myid,parid,mytitle,partitle,mymark,parmark,myurl,myclick,CRTM,UPTM,CRTOR,OLMK";
 
 $appsx=SX("select appname,appid from coode_appdefault where sysid='".$sysid."'");
 $totapp=countresult($appsx);
 $myid=0;
 for ($i=0;$i<$totapp;$i++){
   $myid=($myid+1);   
   $appid=anyvalue($appsx,"appid",$i);
   $sqly="'".$sysid."@org',1,".$myid.",-1,'".anyvalue($appsx,"appname",$i)."','','".$appid."','','','',now(),now(),'','".onlymark()."'";
   $Z=UX("insert into coode_plotdetail(".$sqlx.")values(".$sqly.")");
   $parid=$myid;
   $addsx=SX("select tinymark,tinytitle from coode_tiny where appid='".$appid."'");
   $totadd=countresult($addsx);
   for ($j=0;$j<$totadd;$j++){
    $myid=($myid+1);   
    $addid=anyvalue($addsx,"tinymark",$j);
    $sqly="'".$sysid."@org',2,".$myid.",".$parid.",'".anyvalue($addsx,"tinytitle",$j)."','','".$addid."','','','',now(),now(),'','".onlymark()."'";
    $Z=UX("insert into coode_plotdetail(".$sqlx.")values(".$sqly.")");
   }
 } 
 $syssx=SX("select sysname,sysid from coode_sysinformation ");
 $totsys=countresult($syssx);
 $myid=0;
 for ($i=0;$i<$totsys;$i++){
   $myid=($myid+1);   
   $sid=anyvalue($syssx,"sysid",$i);
   $sqly="'system@org',1,".$myid.",-1,'".anyvalue($syssx,"sysname",$i)."','','".$sid."','','','',now(),now(),'','".onlymark()."'";
   $Z=UX("insert into coode_plotdetail(".$sqlx.")values(".$sqly.")");
 }
 echo "1";
}else{
 echo "0";
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>