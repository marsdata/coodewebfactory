<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sysid=$_GET["sysid"];
$tablistcrt='CREATE TABLE coode_tablist (SNO  int(11) NOT NULL AUTO_INCREMENT ,schm  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,rescode  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,imghead  varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,worldmarks  varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,restpcode  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,tabnick  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,TABLE_NAME  varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,resenword  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,reschiword  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,allkeys  text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,mainsqx  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,subsqx  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,olmkkey  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,areakey  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,md5key  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,createsql  text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,contentkeys  text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,jsonconts  text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,keynames  text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,keytpnms  text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,jsontpnms  text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,srckey  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,srcttk  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,issys  tinyint(4) NOT NULL ,ispmiss  tinyint(4) NOT NULL ,tabtitle  varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,tabtype  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,tabcls  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,sysid  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,keylens  int(11) NOT NULL ,sizetype  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,grpmark  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,CRTOR  varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,vermd5  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,hasshort  tinyint(4) NOT NULL ,beforeview  longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,ickey  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,iwkey  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,copyrightmark  varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,STATUS  tinyint(4) NOT NULL ,OLMK  varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,CRTM  datetime NOT NULL ,PTOF  varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,VRT  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,UPTM  datetime NOT NULL ,STCODE  varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,PRIME  int(11) NOT NULL ,RIP  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,OPRT  varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,PRIMARY KEY (SNO),UNIQUE INDEX oltab (TABLE_NAME) USING BTREE )ENGINE=InnoDBDEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ciAUTO_INCREMENT=2213ROW_FORMAT=COMPACT;';
//加一个代码创建指令，TAB- KEY- 自动创建下列代码 再keyx中选择字段，创建数据显示函数
//结构是本地的，数据ANYSHORT 来自外部的数据库，本地要是修改了，远程的也要同步。
//表格有个开关用本地数据还是远程数据
    $fdir1=combineurl(localroot(),"/localxres/pagex/".$sysid."/");
    $todir1=combineurl(localroot(),"/localxres/install/".$sysid."/resjar/pagex/".$sysid."/");
    $zz0=copy_underdir($fdir1,$todir1);
if ($sysid!="0" and $sysid!="1"){        
    $fdir0=combineurl(localroot(),"/localxres/csspagex/");
    $todir0=combineurl(localroot(),"/localxres/install/".$sysid."/resjar/csspagex/");
    $zz1=copy_underdir($fdir0,$todir0);  
    $fdir=combineurl(localroot(),"/localxres/install/1/resjar/");
    $todir=combineurl(localroot(),"/localxres/install/".$sysid."/resjar/");   
    $zz1=copy_underdir($fdir,$todir);
}
$zz=UX("update coode_resrelyinst set sqlstring='".$tablistcrt."',sqlmd5='".md5($tablistcrt)."' where rescode='coode_tablist' and restype='tabx' and sysid='0' and sqlstring=''");
$demo='{"status":"1","msg":"表格创建数据获取成功","totrcd":"[totrcd]","data":[<data>],"alltab":"[alltab]","tabmd5":"[tabmd5]"}';
$tdrst=SX("select restype,rescode,restitle,relytab,sqlstring,sqlmd5 from coode_resrelyinst where sysid='".$sysid."' and strtype='createsql' group by sqlmd5");
$item='{"restype":"[restype]","rescode":"[rescode]","restitle":"[restitle]","relytab":"[relytab]","sqlstring":"[sqlstring]","sqlmd5":"[sqlmd5]"},';
$fmdata="";
$fmtab="";
$tottd=countresult($tdrst);
if ($tottd>0){
 $fmmd5="";
 for ($j=0;$j<$tottd;$j++){
  $itemx=$item;
  $restype=anyvalue($tdrst,"restype",$j);
  $rescode=anyvalue($tdrst,"rescode",$j);
  $restitle=anyvalue($tdrst,"restitle",$j);  
  $relytab=anyvalue($tdrst,"relytab",$j);
  $sqlstring=anyvalue($tdrst,"sqlstring",$j);
  $sqlmd5=anyvalue($tdrst,"sqlmd5",$j);
  $itemx=str_replace("[restype]",$restype,$itemx);
  $itemx=str_replace("[rescode]",$rescode,$itemx);
  $itemx=str_replace("[restitle]",$restitle,$itemx);
  $itemx=str_replace("[relytab]",$relytab,$itemx);
  $itemx=str_replace("[sqlstring]",$sqlstring,$itemx);
  $itemx=str_replace("[sqlmd5]",$sqlmd5,$itemx);
  $fmdata=$fmdata.$itemx;
  $fmtab=$fmtab.$relytab.",";
  $fmmd5=$fmmd5.$sqlmd5;
 }
 $fmdata=killlaststr($fmdata);
 $demo=str_replace("<data>",$fmdata,$demo);
 $demo=str_replace("[totrcd]",$tottd,$demo);
 $demo=str_replace("[tabmd5]",md5($fmmd5),$demo);
 $demo=str_replace("[alltab]","@ALLTAB@:".$fmtab,$demo);
 $savepath=combineurl(localroot(),"/localxres/install/".$sysid."/tabcrt-".$sysid.".json");
 $zz=overfile($savepath,$demo);
 //echo $demo;
 echo makereturnjson("1","生成成功","");
}else{
 echo makereturnjson("0","生成失败","");
}
     session_write_close();
?>