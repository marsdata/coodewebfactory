<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sysid=$_GET["sysid"];
if ($sysid=="" or $sysid=="999"){
  $tbrst=SX("select TABLE_NAME,tabtitle,sysid,CRTM,UPTM,vermd5 from coode_tablist");
  $sysid="999";
  $savepath="/ORG/system/alltabindex.js";
}else{
  $tbrst=SX("select TABLE_NAME,tabtitle,sysid,CRTM,UPTM,vermd5 from coode_tablist where sysid='".$sysid."'");
  $savepath="/ORG/system/".$sysid."/tabs/tabindex.js";
}
$tottb=countresult($tbrst);
$srddemo='$tabindex=\'{"sysid":"'.$sysid.'","tabdata":[(tabdata)]}\';';
$demox='{"tablename":"[tabname]","tabletitle":"[tabtitle]","sxsid":"[sxsid]","vermd5":"[vermd5]","CRTM":"[CRTM]","UPTM":"[UPTM]"},';
$fmxyz="";
for ($i=0;$i<$tottb;$i++){
  $demoy=$demox;
  $tabname=anyvalue($tbrst,"TABLE_NAME",$i);
  $sxsid=anyvalue($tbrst,"sysid",$i);
  $tabtitle=anyvalue($tbrst,"tabtitle",$i);
  $vermd5=anyvalue($tbrst,"vermd5",$i);
  $CRTM=anyvalue($tbrst,"CRTM",$i);
  $UPTM=anyvalue($tbrst,"UPTM",$i);
  $demoy=str_replace("[tabname]",$tabname,$demoy);
  $demoy=str_replace("[sxsid]",$sxsid,$demoy);
  $demoy=str_replace("[tabtitle]",$tabtitle,$demoy);
  $demoy=str_replace("[vermd5]",$vermd5,$demoy);
  $demoy=str_replace("[CRTM]",$CRTM,$demoy);
  $demoy=str_replace("[UPTM]",$UPTM,$demoy);
  $fmxyz=$fmxyz.$demoy;
}
 $fmxyz=killlaststr($fmxyz);
 $srddemo=str_replace("(tabdata)",$fmxyz,$srddemo);
 $fullpath=combineurl(localroot(),$savepath);
 $v=overfile($fullpath,$srddemo);
 $bbb=file_get_contents("http://".glw()."DNA/EXF/qnyupload.php?lcfile=".$fullpath);
 echo '{"status":"1","msg":"成功-'.$tottb.'","redirect":""}';
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>