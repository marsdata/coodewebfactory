<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tinyid=_get("tinyid");
$tnrst=SX("select sysid,appid,layid,unittitle,outurl,domainmark,casecode,cssfiley,jsfiley,styley,scripty,templatecode,pagesurround from coode_unittiny where tinyid='".$tinyid."'");
$tottn=countresult($tnrst);
if ($tottn>0){
  $utitle=anyvalue($tnrst,"unittitle",0);
  $sysid=anyvalue($tnrst,"sysid",0);
  $dmark=anyvalue($tnrst,"domainmark",0);
  $appid=anyvalue($tnrst,"appid",0);
  $outurl=anyvalue($tnrst,"outurl",0);
  
  $stylex=tostring(anyvalue($tnrst,"styley",0));
  $scriptx=tostring(anyvalue($tnrst,"scripty",0));
  $casecode=tostring(anyvalue($tnrst,"casecode",0));
  $casedemo=$casecode;
  $tmpcode=tostring(anyvalue($tnrst,"templatecode",0));
  $bodycode=$tmpcode;
  $otmpcode=$tmpcode;
  $srdcode=tostring(anyvalue($tnrst,"pagesurround",0));
  $srddemo=$srdcode;
  $jsfiles=tostring(anyvalue($tnrst,"jsfiley",0));
  $cssfiles=tostring(anyvalue($tnrst,"cssfiley",0));
  
  $alljsfiles=$jsfiles;
  $allcssfiles=$cssfiles;
  $allstylex=$stylex;
  $allscriptx=$scriptx;
  $pagehtml=turnlab($srdcode);
  $ptjsfiles=explode(";",$jsfiles);
  $totptj=count($ptjsfiles);
  $ptcssfiles=explode(";",$cssfiles);
  $totptc=count($ptcssfiles);
  
  $leiia=0;
  $b=eval(RESFUNSET("tabdataoprt"));
  $b=eval(RESFUNSET("recline"));
    if ($casedemo!=""){
      eval($casedemo);
    }
    $pagehtml=str_replace("<!--thesecomCSSFILES-->",formcss(onlyone($allcssfiles)),$pagehtml);
    $pagehtml=str_replace("<!--thesecomJSFILES-->",formjs(onlyone($alljsfiles)),$pagehtml);
    $pagehtml=str_replace("<!--thiscomSTYLE-->",$allstylex,$pagehtml);
    $pagehtml=str_replace("<!--thiscomSCRIPT-->",$allscriptx,$pagehtml);
    $pagehtml=str_replace("<!--thiscomHTML-->",turnlab($tmpcode),$pagehtml);
    $pagehtml=str_replace("<!--thistitle-->",$utitle,$pagehtml);
   
  
        $outx=combineurl(localroot(),$outurl);            
        overfile($outx,str_replace("/localxres/csspagex/","",$pagehtml));      
  
     echo makereturnjson("1","生成成功","");
 }else{
     echo makereturnjson("0","提交失败-不存在","");
 }
     session_write_close();
?>