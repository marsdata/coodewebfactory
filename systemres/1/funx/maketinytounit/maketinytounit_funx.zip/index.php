<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tinyid=dftval($_GET["tinyid"],"");
$tnrst=SX("select sysid,appid,layid,tempid from coode_tiny where tinymark='".$tinyid."'");
$totx=countresult($tnrst);
if (intval($totx)>0){
   
   $sysid=anyvalue($tnrst,"sysid",0);
   $appid=anyvalue($tnrst,"appid",0);
   $layid=anyvalue($tnrst,"layid",0);
   $tempid=anyvalue($tnrst,"tempid",0);
   
   $newdo=dftval($_GET["newdo"],$tinyid);
   if ($newdo=="tempx"){
     $newdumark=$tempid;
   }else{
     $newdumark=$newdo.".index";   
   }
   $extd=UX("delete from coode_domainunit dumark='".$newdumark."'");
   $sqlx="sysid,unittitle,domainmark,unitmark,dumark,outurl,vermd5,stylex,scriptx,cssfilex,cssfiley,jsfilex,jsfiley,styley,scripty,templatecode,pagesurround,CRTM,UPTM,OLMK,VRT";
   $sqly="sysid,unittitle,'".qian($newdumark,".")."','".hou($newdumark,".")."','".$newdumark."',outurl,vermd5,stylex,scriptx,cssfilex,cssfiley,jsfilex,jsfiley,styley,scripty,templatecode,pagesurround,CRTM,UPTM,OLMK,VRT";
   $zz=UX("insert into coode_domainunit(".$sqlx.")select ".$sqly." from coode_unittiny where tinyid='".$tinymark."'");
   $zz1=UX("update coode_domainunit set outurl=replace(outurl,'/localxres/pagex/".$sysid."/".$appid."/".$layid."/".$tinymark."','/localxres/tempx/".$newdumark."') where dumark='".$newdumark."'");
   $zz1=UX("update coode_domainunit set cssfilex=replace(cssfilex,'/localxres/pagex/".$sysid."/".$appid."/".$layid."/".$tinymark."','/localxres/tempx/".$newdumark."') where dumark='".$newdumark."'");
   $zz1=UX("update coode_domainunit set cssfiley=replace(cssfiley,'/localxres/pagex/".$sysid."/".$appid."/".$layid."/".$tinymark."','/localxres/tempx/".$newdumark."') where dumark='".$newdumark."'");
   $zz1=UX("update coode_domainunit set jsfilex=replace(jsfilex,'/localxres/pagex/".$sysid."/".$appid."/".$layid."/".$tinymark."','/localxres/tempx/".$newdumark."') where dumark='".$newdumark."'");
   $zz1=UX("update coode_domainunit set jsfiley=replace(jsfiley,'/localxres/pagex/".$sysid."/".$appid."/".$layid."/".$tinymark."','/localxres/tempx/".$newdumark."') where dumark='".$newdumark."'");
   $newdir=combineurl(localroot(),"/localxres/tempx/".qian($newdumark,"."));
   $cx=createdir($newdir);
   $fromdir=combineurl(localroot(),"/localxres/pagex/".$sysid."/".$appid."/".$layid."/".$tinymark."/");
   $zz3=copy_dir($fromdir, $newdir."/");   
   
   echo makereturnjson("1","转化成功","");
}else{
  echo makereturnjson("0","转化失败","");
}
     session_write_close();
?>