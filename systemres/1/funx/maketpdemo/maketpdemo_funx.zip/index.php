<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $tempid=_get("tempid");
$srst=SX("select sysid,unitclass from coode_domainunit where dumark='".$tempid."'");
$sysid=anyvalue($srst,"sysid",0);
$uclass=anyvalue($srst,"unitclass",0);
switch($uclass){
 case "list":
 $typefunx=constval("typemklhtml");
 $typeheadx=constval("typemklheadhtm");
 break;
 case "Mlist":
 $typefunx=constval("typemklhtml");
 $typeheadx=constval("typemklheadhtm");
 break;
 case "form":
 $typefunx=constval("typemkfhtml");
 $typeheadx=constval("typemkfheadhtm");
 break;
 case "Mform":
 $typefunx=constval("typemkfhtml");
 $typeheadx=constval("typemkfheadhtm");
 break;
 default:
}
$sqlx="sysid,tdmcode,datatype,dxtype,typedfunx,typeheadx,CRTM,UPTM,OLMK";
$sqly="'".$sysid."','".$tempid."','',keyid,'".gohex($typefunx)."','".gohex($typeheadx)."',now(),now(),md5(RAND())";
$zz=UX("insert into coode_tempcssfunx(".$sqlx.")select ".$sqly." from coode_grpclass where clsmark='XvlEaV' and concat('".$tempid."',keyid) not in (select concat(tdmcode,dxtype) from coode_tempcssfunx)");
//echo "insert into coode_tempcssfunx(".$sqlx.")select ".$sqly." from coode_grpclass where clsmark='XvlEaV' and concat('".$tempid."',keyid) not in (select concat(tdmcode,dxtype) from coode_tempcssfunx);
$nn=UX("update coode_tempcssfunx set typedfunx=replace(typedfunx,hex('[tpmark]'),hex(dxtype)), typeheadx=replace(typeheadx,hex('[tpmark]'),hex(concat(dxtype,'hd')))");
echo makereturnjson("1","生成成功","");
       session_write_close();
?>