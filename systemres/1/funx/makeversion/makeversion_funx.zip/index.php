<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sysid=$_GET["sysid"];
$sqlx="sysid,appid,srctype,srcid,vermd5,lastupdate";
$a0=UX("update coode_keydetailx,coode_tablist set coode_keydetailx.sysid=coode_tablist.sysid,coode_keydetailx.appid=coode_tablist.appid where coode_keydetailx.TABLE_NAME=coode_tablist.TABLE_NAME");
$sqlkxdata="'".$sysid."',appid,'keydetailx',concat(TABLE_NAME,'.',COLUMN_NAME),VRT,now()";
$z0=UX("insert into coode_appsrc(".$sqlx.")select ".$sqlkxdata." from coode_keydetailx where sysid='".$sysid."' and concat(sysid,TABLE_NAME,'.',COLUMN_NAME) not in(select concat(sysid,srcid) from coode_appsrc)");
$z0=UX("update coode_appsrc,coode_keydetailx set coode.appsrc.lastupdate=now(),coode_appsrc.vermd5=coode_keydetailx.VRT where coode_appsrc.sysid=coode_keydetailx.sysid and coode_appsrc.srcid=concat(coode_keydetailx.TABLE_NAME,'.',coode_keydetailx.COLUMN_NAME)");
$a1=UX("update coode_keydetaily,coode_shortdata set coode_keydetaily.sysid=coode_shortdata.sysid,coode_keydetaily.appid=coode_shortdata.appid where coode_keydetaily.shortid=coode_shortdata.shortid");
$sqlkydata="'".$sysid."',appid,'keydetaily',concat(shortid,'@',TABLE_NAME,'.',COLUMN_NAME),VRT,now()";
$z1=UX("insert into coode_appsrc(".$sqlx.")select ".$sqlkydata." from coode_keydetaily where sysid='".$sysid."' and concat(sysid,shortid,'@',TABLE_NAME,'.',COLUMN_NAME) not in(select concat(sysid,srcid) from coode_appsrc)");
$z1=UX("update coode_appsrc,coode_keydetaily set coode.appsrc.lastupdate=now(),coode_appsrc.vermd5=coode_keydetaily.VRT where coode_appsrc.sysid=coode_keydetaily.sysid and coode_appsrc.srcid=concat(coode_keydetaily.shortid,'@',coode_keydetaily.TABLE_NAME,'.',coode_keydetaily.COLUMN_NAME)");
$b=UX("update coode_tablist set vermd5=md5(createsql)");
$sqltabdata="'".$sysid."',appid,'table',TABLE_NAME,vermd5,now()";
$z2=UX("insert into coode_appsrc(".$sqlx.")select ".$sqltabdata." from coode_tablist where sysid='".$sysid."' and concat(sysid,TABLE_NAME) not in(select concat(sysid,srcid) from coode_appsrc)");
$z2=UX("update coode_appsrc,coode_tablist set coode.appsrc.lastupdate=now(),coode_appsrc.vermd5=coode_tablist.vermd5 where coode_appsrc.sysid=coode_tablist.sysid and coode_appsrc.srcid=coode_tablist.TABLE_NAME");
$sqlfundata="'".$sysid."',appid,'function',replace(funname,'()',''),vermd5,now()";
$z3=UX("insert into coode_appsrc(".$sqlx.")select ".$sqlfundata." from coode_funlist where sysid='".$sysid."' and concat(sysid,replace(funname,'()','')) not in(select concat(sysid,srcid) from coode_appsrc)");
$z3=UX("update coode_appsrc,coode_funlist set coode.appsrc.lastupdate=now(),coode_appsrc.vermd5=coode_funlist.vermd5 where coode_appsrc.sysid=coode_funlist.sysid and coode_appsrc.srcid=replace(coode_funlist.funname,'()','')");
$sqlclsdata="'".$sysid."',appid,'class',replace(funname,'()',''),vermd5,now()";
$z4=UX("insert into coode_appsrc(".$sqlx.")select ".$sqlclsdata." from coode_phpcls where sysid='".$sysid."' and concat(sysid,replace(funname,'()','')) not in(select concat(sysid,srcid) from coode_appsrc)");
$z4=UX("update coode_appsrc,coode_phpcls set coode.appsrc.lastupdate=now(),coode_appsrc.vermd5=coode_phpcls.vermd5 where coode_appsrc.sysid=coode_phpcls.sysid and coode_appsrc.srcid=replace(coode_phpcls.funname,'()','')");
$sqltinydata="'".$sysid."',appid,'tiny',tinymark,auditmd5,now()";
$z5=UX("insert into coode_appsrc(".$sqlx.")select ".$sqltinydata." from coode_tiny where sysid='".$sysid."' and concat(sysid,tinymark) not in(select concat(sysid,srcid) from coode_appsrc)");
$z5=UX("update coode_appsrc,coode_tiny set coode.appsrc.lastupdate=now(),coode_appsrc.vermd5=coode_tiny.auditmd5 where coode_appsrc.sysid=coode_tiny.sysid and coode_appsrc.srcid=coode_tiny.tinymark");
$apprst=SX("select SNO,appid from coode_appdefault where sysid='".$sysid."'");
$tota=countresult($apprst);
for ($i=0;$i<$tota;$i++){
 $snox=anyvalue($apprst,"SNO",$i);
 $appidx=anyvalue($apprst,"appid",$i);
 $arstx=SX("select vermd5 from coode_appsrc where sysid='".$sysid."' and appid='".$appidx."'");
 $namd5=md5($arstx);
 $zz=UX("update coode_appdefault set vermd5='".$namd5."' where SNO=".$snox);
}
$allarst=SX("select vermd5 from coode_appsrc where sysid='".$sysid."'");
$sysmd5=md5($allarst);
 $yy=UX("update coode_sysinformation set lastupdt=date(now()),vermd5='".$sysmd5."' where sysid='".$sysid."'");
echo "1";
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>