<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
       $likemd5=_get("likemd5");
  $kill=_get("kill");  
  $sckey=dftval($_GET["sckey"],"");
  if ($sckey=="pstemp"){
    $sckey=$_COOKIE["uid"];
  }
  $fmallmd5="";
  $fmaj="[";
     $mtpicrst=SX("select imghsturl,VRT from coode_icons where setmark like '%".$sckey."%' order by RAND() limit 0,9");
     $totmy=countresult($mtpicrst);    
     if ($totmy>0){
      for ($j=0;$j<$totmy;$j++){
        $fmallmd5=$fmallmd5.anyvalue($mtpicrst,"VRT",$j).",";
        $fmaj=$fmaj."{\"svgmd5\":\"".anyvalue($mtpicrst,"vermd5",$j)."\",\"svgfrom\":\"".anyvalue($mtpicrst,"imghsturl",$j)."\"},";
      }
       $fmaj=substr($fmaj,0,strlen($fmaj)-1);
     }
    
    $fmaj=$fmaj."]";  
    echo $fmaj;
     session_write_close();
?>