<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     eval(RESFUNSET("accoprt"));
$sno=dftval($_GET["SNO"],"");
$conn=mysql_connect(gl(),glu(),glp());
$tbrst=selecteds($conn,glb(),"select TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME from coode_keydetailx where SNO=".$sno,"utf8","");
$fbasex=anyvalue($tbrst,"TABLE_SCHEMA",0);
$tbnmx=anyvalue($tbrst,"TABLE_NAME",0);
$cname=anyvalue($tbrst,"COLUMN_NAME",0);
$ncnm=_post("p_COLUMN_NAME".$sno);
$conn=mysql_connect(gl(),glu(),glp());
$bfval=selecteds($conn,glb(),"select TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,keytitle,keyexplain,clstxt,jsshowfun,jspostfun,sysshowfun,syspostfun,dxtype from coode_keydetailx where TABLE_NAME='".$tbnmx."' and TABLE_SCHEMA='".$fbasex."'","utf8","");
 if (editacc("tabx",$tbnmx)){
   $dtp=$_POST["p_DATA_TYPE".$sno];
   $mlen=$_POST["p_CHARACTER_MAXIMUM_LENGTH".$sno];   
   if ($_POST["p_changeable".$sno]!="" or $_POST["p_displayed".$sno]!=""  or $_POST["p_keytitle".$sno]!=""){
         $x=UX("update coode_shortdata set headdemo='' where tablename='".$tbnmx."' and headdemo<>'@'");   
         $x=UX("update coode_shortdata set tabdemo='' where tablename='".$tbnmx."' and tabdemo<>'@'");   
         $x=UX("update coode_shortdata set searchdemo='' where tablename='".$tbnmx."' and searchdemo<>'@'");   
   }
   if ($dtp!=""){
       switch ($dtp){
       case "int":
       $conn=mysql_connect(gl(),glu(),glp());
       if($cname!="SNO" and $cname!="sNo"){
        if ($ncnm==$cname or $ncnm=="" or $ncnm=="un"."defined"){
         $z=updatingx($conn,glb(),"ALTER TABLE ".$tbnmx." MODIFY ".$cname." int(11) NOT NULL","utf8");
        }else{       
         $z=updatingx($conn,glb(),"ALTER TABLE ".$tbnmx." CHANGE COLUMN ".$cname." ".$ncnm." int(11) NOT NULL","utf8");        
        }
        $yy=UX("update coode_keydetaily set COLUMN_NAME='".$ncnm."',DATA_TYPE='int',dxtype='int' where TABLE_NAME='".$tbnmx."' and COLUMN_NAME='".$cname."'");
      }
      
       break;
       case "tinyint":
       $conn=mysql_connect(gl(),glu(),glp());
       if ($ncnm==$cname or $ncnm=="" or $ncnm=="un"."defined"){
         $z=updatingx($conn,glb(),"ALTER TABLE ".$tbnmx." MODIFY ".$cname." tinyint(4) NOT NULL","utf8");
       }else{       
         $z=updatingx($conn,glb(),"ALTER TABLE ".$tbnmx." CHANGE COLUMN ".$cname." ".$ncnm." tinyint(4) NOT NULL","utf8");         
       }
       $yy=UX("update coode_keydetaily set COLUMN_NAME='".$ncnm."',DATA_TYPE='tinyint',dxtype='tinyint' where TABLE_NAME='".$tbnmx."' and COLUMN_NAME='".$cname."'");
       break;
       case "varchar":
       if ($mlen=="" or $mlen=="un"."defined"){
         $mlen="255";
       }
       $conn=mysql_connect(gl(),glu(),glp());
       if ($ncnm==$cname or $ncnm=="" or $ncnm=="un"."defined"){
        $z=updatingx($conn,glb(),"ALTER TABLE ".$tbnmx." MODIFY ".$cname." varchar(".$mlen.") NOT NULL","utf8");
       }else{       
        $z=updatingx($conn,glb(),"ALTER TABLE ".$tbnmx." CHANGE COLUMN ".$cname." ".$ncnm." varchar(".$mlen.") NOT NULL","utf8");        
       }
       $yy=UX("update coode_keydetaily set COLUMN_NAME='".$ncnm."',DATA_TYPE='varchar',dxtype='varchar' where TABLE_NAME='".$tbnmx."' and COLUMN_NAME='".$cname."'");
       break;
       case "date":
       $conn=mysql_connect(gl(),glu(),glp());
       if ($ncnm==$cname or $ncnm=="" or $ncnm=="un"."defined"){
        $z=updatingx($conn,glb(),"ALTER TABLE ".$tbnmx." MODIFY ".$cname." date NOT NULL","utf8");
       }else{       
        $z=updatingx($conn,glb(),"ALTER TABLE ".$tbnmx." CHANGE COLUMN ".$cname." ".$ncnm." date NOT NULL","utf8");        
       }
       $yy=UX("update coode_keydetaily set COLUMN_NAME='".$ncnm."',DATA_TYPE='date',dxtype='date' where TABLE_NAME='".$tbnmx."' and COLUMN_NAME='".$cname."'");
       break;
       case "datetime":
       $conn=mysql_connect(gl(),glu(),glp());
       if ($ncnm==$cname or $ncnm=="" or $ncnm=="un"."defined"){
        $z=updatingx($conn,glb(),"ALTER TABLE ".$tbnmx." MODIFY ".$cname." datetime NOT NULL","utf8");
       }else{       
        $z=updatingx($conn,glb(),"ALTER TABLE ".$tbnmx." CHANGE COLUMN ".$cname." ".$ncnm." datetime NOT NULL","utf8");        
       }
       $yy=UX("update coode_keydetaily set COLUMN_NAME='".$ncnm."',DATA_TYPE='datetime',dxtype='dttm' where TABLE_NAME='".$tbnmx."' and COLUMN_NAME='".$cname."'");
       break;
       case "text":
       $conn=mysql_connect(gl(),glu(),glp());
       if ($ncnm==$cname or $ncnm=="" or $ncnm=="un"."defined"){
        $z=updatingx($conn,glb(),"ALTER TABLE ".$tbnmx." MODIFY ".$cname." text NOT NULL","utf8");
       }else{       
        $z=updatingx($conn,glb(),"ALTER TABLE ".$tbnmx." CHANGE COLUMN ".$cname." ".$ncnm." text NOT NULL","utf8");        
       }
       $yy=UX("update coode_keydetaily set COLUMN_NAME='".$ncnm."',DATA_TYPE='text',dxtype='text' where TABLE_NAME='".$tbnmx."' and COLUMN_NAME='".$cname."'");
       break;
       case "longtext":
       $conn=mysql_connect(gl(),glu(),glp());
       if ($ncnm==$cname or $ncnm=="" or $ncnm=="un"."defined"){
        $z=updatingx($conn,glb(),"ALTER TABLE ".$tbnmx." MODIFY ".$cname." longtext NOT NULL","utf8");
       }else{       
        $z=updatingx($conn,glb(),"ALTER TABLE ".$tbnmx." CHANGE COLUMN ".$cname." ".$ncnm." longtext NOT NULL","utf8");        
       }
       $yy=UX("update coode_keydetaily set COLUMN_NAME='".$ncnm."',DATA_TYPE='longtext',dxtype='text' where TABLE_NAME='".$tbnmx."' and COLUMN_NAME='".$cname."'");
       break;
       default:
      }
   }
 }else{
   $zz=newacc("tabx",$tbnmx,"",$_COOKIE["uid"]);
  $ext=0;
 }
     session_write_close();
?>