<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $domain=$_GET["domain"];
$mark=$_GET["mark"];
$tempid=$domain.".".$mark;
 if ($tempid!=""){
 $trst=SX("select sysid,appid,unittitle,unitclass,unitdescrib,outurl,industry,business,matter,casecode,cssfilex,stylex,scriptx,jsfilex,cssfiley,jsfiley,styley,scripty,templatecode,demoresult,pagesurround from coode_mydonunit where domainmark='".$domain."' and unitmark='".$mark."'");
    $cssfilex=anyvalue($trst,"cssfilex",0);  
    $stylex=tostring(anyvalue($trst,"stylex",0));  
    $stx=str_replace("/MYFACE/","/FACE/",$stylex);
    $scriptx=tostring(anyvalue($trst,"scriptx",0));  
    $scx=str_replace("/MYFACE/","/FACE/",$scriptx);
    $jsfilex=anyvalue($trst,"jsfilex",0);  
    $cssfiley=anyvalue($trst,"cssfiley",0);  
    $jsfiley=anyvalue($trst,"jsfiley",0);  
    $styley=tostring(anyvalue($trst,"styley",0));  
    $sty=str_replace("/MYFACE/","/FACE/",$styley);
    $scripty=tostring(anyvalue($trst,"scripty",0));
    $scy=str_replace("/MYFACE/","/FACE/",$scripty);
    $templatecode=tostring(anyvalue($trst,"templatecode",0));
    $tempcode=str_replace("/MYFACE/","/FACE/",$templatecode);
    $extx=UX("select count(*) as result from coode_domainunit where dumark='".$tempid."' ");
    if(intval($extx)==0){
     $allfaces=absorbmyface($cssfiley).absorbmyface($jsfiley).absorbmyface($styley).absorbmyface($scripty);
     $ptfc=explode(",",$allfaces);
     for ($b=0;$b<count($ptfc);$b++){
       if ($ptfc[$b]!=""){
         $layf=combineurl(localroot(),"/MYFACE/".$ptfc[$b]);
         $layp=combineurl(localroot(),"/FACE/".$ptfc[$b]);
         is_dir($layp) OR mkdir($layp, 0777, true);   
         copy_dir($layf,$layp);
       }
     }
     $sql0="sysid,appid,unittitle,unitclass,unitmark,domainmark,dumark,unitdescrib,outurl,pagehtml,vermd5,industry,business,matter,casecode,cssfilex,stylex,jsfilex,scriptx,cssfiley,styley,jsfiley,scripty,containsub,width,height,inwidth,inheight,templatecode,demoresult,pagesurround,subvermd5,copyrightmark,CRTM,UPTM";
     $sql1="sysid,appid,unittitle,unitclass,unitmark,domainmark,dumark,unitdescrib,'".$newlx."',pagehtml,vermd5,industry,business,matter,casecode,cssfilex,stylex,jsfilex,scriptx,cssfiley,styley,jsfiley,scripty,containsub,width,height,inwidth,inheight,templatecode,demoresult,pagesurround,subvermd5,copyrightmark,CRTM,UPTM";
     $sql2=UX("insert into coode_domainunit(".$sql0.")select ".$sql1." from coode_mydonunit where dumark='".$tempid."'");
     $sql3=UX("update coode_domainunit set  templatecode='".gohex($tempcode)."',outurl=replace(outurl,'/myunits/','/units/'),cssfilex=replace(cssfilex,'/MYFACE/','/FACE/'), cssfiley=replace(cssfiley,'/MYFACE/','/FACE/'), jsfilex=replace(jsfilex,'/MYFACE/','/FACE/'), jsfiley=replace(jsfiley,'/MYFACE/','/FACE/') where dumark='".$tempid."' ");    
     echo '{"status":"1","msg":"新建成功","redirect":""}';
    }else{
     echo '{"status":"0","msg":"新建失败","redirect":""}';
    }
 }else{  
  echo '{"status":"0","msg":"新建失败","redirect":""}';
 }
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>