<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $dsid=_get("dsid");
$stcd=getRandChar(7);
$dsrst=SX("select datatitle,tabcls,CRTOR from coode_dataspace where datamark='".$dsid."'");
$datatitle=anyvalue($dsrst,"datatitle",0);
$tabcls=anyvalue($dsrst,"tabcls",0);
$crtor=anyvalue($dsrst,"CRTOR",0);
$krst=SX("select keymark,keytitle from coode_dspckey where datamark='".$dsid."'");
$totk=countresult($krst);
for ($j=0;$j<$totk;$j++){
  $fmkeys=$fmkeys.anyvalue($krst,"keymark",$j).",";
}
$fmkeys=killlaststr($fmkeys);
$sqlx="domainmark,datamark,datatitle,dscode,dstitle,dskeys,datatype,caseid,detailid,tabcls,CRTM,UPTM,CRTOR,OLMK";
$sqlz="'','".$dsid."','".$datatitle."','".$stcd."','".$datatitle."','".$fmkeys."','html','layuitable.index','layuiform.index','".$tabcls."',now(),now(),'".$crtor."','".onlymark()."'";
$zz=UX("insert into coode_dsshort(".$sqlx.")values(".$sqlz.")");
echo makereturnjson("1","创建成功","");
     session_write_close();
?>