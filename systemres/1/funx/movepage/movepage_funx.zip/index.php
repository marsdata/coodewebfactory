<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $sno=$_GET["SNO"];
  $tinyrst=SX("select sysid,appid,layid,tempid,shortid,tinymark,longexp,laypath from coode_tiny where SNO=".$sno);
   $sysid=anyvalue($tinyrst,"sysid",0);
   $appid=anyvalue($tinyrst,"appid",0);
   $layid=anyvalue($tinyrst,"layid",0);
   $laypath=anyvalue($tinyrst,"laypath",0);
   $tempid=anyvalue($tinyrst,"tempid",0);
   $shortid=anyvalue($tinyrst,"shortid",0);
   $tinyid=anyvalue($tinyrst,"tinymark",0);
   $newlx="/localxres/pagex/".qian($tempid,".")."/".$tinyid."/index.html";   
   $zz=UX("update coode_tiny set laypath='".$newlx."',STCODE='-1' where SNO=".$sno);
   if (es($tempid)>=1){
     $layf=combineurl(localroot(),"/localxres/pagex/".qian($tempid,".")."/".$tinyid);
     $layp=combineurl(localroot(),"/localxres/pagex/".$sysid."/".$appid."/".$layid."/".$tinyid);
     is_dir($layf) OR mkdir($layf, 0777, true);  
     copy_dir($layp,$layf);             
   }
   $zz=UX("update coode_tiny set laypath='".$newlx."',STCODE='1' where SNO=".$sno);
   echo makereturnjson("1","移动成功","");
       session_write_close();
?>