<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $dttp=$_GET['dttp'];
 $dbnm=str_replace(" ","",dftval($_GET['dnm'],""));
 $tbnm=str_replace(" ","",dftval($_GET['tbnm'],""));
 $slkey=str_replace(" ","",dftval($_GET['slkey'],""));
 eval(RESFUNSET("keyinfo"));
 if (substr($slkey,-1)==","){
  $tmpkey=substr($slkey,0,strlen($slkey)-1);
 }else{
  $tmpkey=$slkey;
 };
 if ($slkey=="*"){
  $alif=allkeyinfo($alif,$dbnm,$tbnm);
   $tmpkey=$alif["COLUMN"]["ALLKEY"];
 };
    $stidx=getRandChar(6);
    $_POST["p_shortid0"]=$stidx;
    $_POST["p_tablename0"]=$tbnm;
    $_POST["p_showkeys0"]=$tmpkey;     
    $_POST["p_skeys0"]="";
    $_POST["p_CRTM0"]=date("Y-m-d H:i:s");
    $_POST["p_UPTM0"]=date("Y-m-d H:i:s");
    $_POST["p_sqlbody0"]="";
    $_POST["p_showfile0"]="anyjsshort.php";
    $_POST["p_cdt0"]="";
    $_POST["p_orddt0"]="";
    $_POST["p_lang0"]="php";
    $_POST["p_schm0"]=$dbnm;
    if ($dttp=="html" or $dttp==""){
      $_POST["p_dttp0"]="html";
    }
    if ($dttp=="json"){
      $_POST["p_dttp0"]="json";
    }
    $_POST["p_issys0"]="0";
    $_POST["p_fileurl0"]=glw();
    $olmkx=date("YmdHis").getRandChar(6);
    $_POST["p_OLMK0"]=$olmkx;
    $_POST["p_VRT0"]="";
    $_POST["p_PTOF0"]=$_COOKIE["cid"]."/".$_COOKIE["gid"];
    if ($dbnm=="" or $dbnm==glb()){
      $x=anyrcv('coode_shortdata','shortid,tablename,showkeys,skeys,CRTM,UPTM,sqlbody,showfile,cdt,orddt,lang,dttp,issys,fileurl,OLMK,VRT,PTOF','0','html');
    }else{
      $x=anyrcv('coode_mydbshort','schm,shortid,tablename,showkeys,skeys,CRTM,UPTM,sqlbody,showfile,cdt,orddt,lang,dttp,issys,fileurl,OLMK,VRT,PTOF','0','html');
    }
    $conn=mysql_connect(gl(),glu(),glp());
    if ($dbnm=="" or $dbnm==glb()){
      $extn=updatings($conn,glb(),"select count(*) as result from coode_shortdata where shortid='".$stidx."'","utf8");
    }else{
      $cc=UX("update coode_dbshort set schm='".$dbnm."' where OLMK='".$olmkx."'");
      $extn=updatings($conn,glb(),"select count(*) as result from coode_mydbshort where shortid='".$stidx."'","utf8");
    }
      $conn=mysql_connect(gl(),glu(),glp());    
      $bdx=updatings($conn,glb(),"update coode_shortaffect set UPTM=now() where tablename='coode_shortdata' ","utf8");
      $conn=mysql_connect(gl(),glu(),glp());    
      $bdx=updatings($conn,glb(),"update coode_shortaffect set UPTM=now() where tablename='coode_dbshort' ","utf8");
    if ($extn>0){
        $conn=mysql_connect(gl(),glu(),glp());
       if ($dbnm=="" or $dbnm==glb()){
          $nbtn=updatings($conn,glb(),"update coode_shortdata set ctraw=0,additemx=1,newbutton=1,allkillbtn=1,topbtn=1,bottombtn=1,dtx=1,tbhd=1,obtn=1,vbtn=1,xbtn=1,sps=0,oprtx=1,caseid='dftliststyle',lang='tablelistx',dttp='html' where shortid='".$stidx."'","utf8");
        }else{
          $nbtn=updatings($conn,glb(),"update coode_mydbshort set ctraw=0,additemx=1,newbutton=1,allkillbtn=1,topbtn=1,bottombtn=1,dtx=1,tbhd=1,obtn=1,vbtn=1,xbtn=1,sps=0,oprtx=1,caseid='dftliststyle',lang='tablelistx',dttp='html' where shortid='".$stidx."'","utf8");
        }
      echo "1";
    }else{
      echo "0";
    }
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>