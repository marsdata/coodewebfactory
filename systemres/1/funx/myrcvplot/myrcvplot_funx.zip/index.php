<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $plid=$_GET['plid'];
 $plrst=$_POST['plrst'];
 $ckd=$_POST["ckd"];
 if ($plrst!=""){
   $plrst=substr($plrst,0,strlen($plrst)-1);
 };
 $ptrst=explode(";",$plrst);
 $ptckd=explode("--",$ckd);
 $totpc=count($ptckd);
 $totpt=count($ptrst);
 $ntime=date("Y-m-d H:i:s");
 $fmallmk="";
 if (strpos($plid,"/")>0){
   $conn=mysql_connect(gl(),glu(),glp());
   $czd=updatings($conn,glb(),"select count(*) as result from coode_plotmydetail where plotmark='".$plid."' and myid>9000","utf8");
 }else{
   $czd=0;
 }
 $fmbdyl="";
 for ($i=0;$i<$totpt;$i++){
   $thispt=explode(",",$ptrst[$i]);
   $totthis=count($thispt);
   $conn=mysql_connect(gl(),glu(),glp());
   $thispt[4]=str_replace('level','',$thispt[4]);
   $thispt[3]=str_replace('treeDemo','',$thispt[3]);
   $thispt[3]=str_replace('ul','',$thispt[3]);
   $thispt[3]=str_replace('_','',$thispt[3])*1;
   $thispt[2]=str_replace('treeDemo','',$thispt[2]);
   $thispt[2]=str_replace('ul','',$thispt[2]);
   $thispt[2]=str_replace('_','',$thispt[2])*1;
   if ( $thispt[0]=="_blank"){//add
    $conn=mysql_connect(gl(),glu(),glp());
      $xt=1;
      while($xt>=1){
         $mk=getRandChar(2);
         $conn=mysql_connect(gl(),glu(),glp());
         $xt=updatingx($conn,glb(),"select count(*) as result from coode_plotmydetail where plotmark='".$plid."' and mymark='".$mk."'","utf8");
      };
      $fmallmk=$fmallmk.$mk.",";
     $conn=mysql_connect(gl(),glu(),glp());
     $ptof=atv("(coode_plotmydetail@plotmark='".$plid."' and myid='".$thispt[3]."').PTOF");
     $x=updatings($conn,glb(),"INSERT INTO coode_plotmydetail(plotmark,CRTM,UPTM,myid,parid,mymark,mytitle,level,OLMK,PTOF)VALUES('".$plid."','".$ntime."','".$ntime."','".$thispt[2]."','".$thispt[3]."','".$mk."','".$thispt[1]."','".$thispt[4]."','".onlymark()."','".$ptof."')","utf8");
   }else{//update
     $fmallmk=$fmallmk.$thispt[0].",";
     $parptof=atv("(coode_plotmydetail@plotmark='".$plid."' and myid='".$thispt[3]."').PTOF");
     $conn=mysql_connect(gl(),glu(),glp());
     $orst=selecteds($conn,glb(),"select SNO,myid,parid,mytitle,level,PTOF from coode_plotmydetail where plotmark='".$plid."' and mymark='".$thispt[0]."'","utf8","");
     $toto=countresult($orst);     
     if ($toto>0){        
      if (anyvalue($orst,"PTOF",0)==$parptof and (anyvalue($orst,"myid",0)*1)==($thispt[2]*1) and (anyvalue($orst,"parid",0)*1)==($thispt[3]*1) and anyvalue($orst,"mytitle",0)==$thispt[1] and (anyvalue($orst,"level",0)*1)==($thispt[4]*1)){
        $conn=mysql_connect(gl(),glu(),glp());
        $extb=updatingx($conn,glb(),"update coode_plotmydetail set UPTM='".$ntime."' where SNO=".anyvalue($orst,"SNO",0),"utf8");
        echo "----".anyvalue($orst,"SNO",0)."<br>";
      }else{//如果有变化则执行变化的 发现会有修改失败的时候先执行时间，防止丢失    不判断STATUS 是因为 群组 个人太多太乱，这里不判断     
       $conn=mysql_connect(gl(),glu(),glp());
       $extb=updatingx($conn,glb(),"update coode_plotmydetail set CRTM='".$ntime."',UPTM='".$ntime."',myid='".$thispt[2]."',PTOF='".$parptof."',parid='".$thispt[3]."',mytitle='".$thispt[1]."',level='".$thispt[4]."' where SNO=".anyvalue($orst,"SNO",0),"utf8");
       echo "xxx"."update coode_plotmydetail set CRTM='".$ntime."',UPTM='".$ntime."',myid='".$thispt[2]."',PTOF='".$parptof."',parid='".$thispt[3]."',mytitle='".$thispt[1]."',level='".$thispt[4]."' where SNO=".anyvalue($orst,"SNO",0)."<br>";
      }
     }else{//
       $fmbdyl=$fmbdyl.$thispt[0].",";
     }
   };//if
};//for
echo $fmbdyl."1";
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>