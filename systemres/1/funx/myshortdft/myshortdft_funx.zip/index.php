<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $stid=$_GET["shortid"];
if (dftval($_GET["dbnm"],"")==""){
  $strst=SX("select tablename,sysid from coode_shortdata where shortid='".$stid."'");
}else{
  $strst=SX("select tablename,sysid from coode_mydbshort where shortid='".$stid."'");
}
$tbnm=anyvalue($strst,"tablename",0);
eval(RESFUNSET("keyinfo"));
eval(RESFUNSET("keyfunbase"));
if (dftval($_GET["dbnm"],"")==""){
 $sysid=UX("select concat('x',sysid) as result from coode_tablist where TABLE_NAME='".$tbnm."'");
 if ($sysid=="x"){
  $sysid="noname";
 }else{
  $sysid=substr($sysid,1,strlen($sysid)-1);
 }
}else{
 $sysid=UX("select concat('x',sysid) as result from coode_mydbtablist where TABLE_NAME='".$tbnm."' and schm='".dftval($_GET["dbnm"],"")."'");
 if ($sysid=="x"){
  $sysid="noname";
 }else{
  $sysid=substr($sysid,1,strlen($sysid)-1);
 }
}
if (dftval($_GET["dbnm"],"")==""){
   $_GET["sid"]=$stid;
   $stdfttxt="STDFT".$stid."=".anyshort("stbase","","");
   $savepath0="/ORG/system/".$sysid."/tabs/".$tbnm."/".$stid.".js";
   $savever0="/ORG/system/".$sysid."/tabs/".$tbnm."/".$stid."jsversion/".date("YmdHis").".js";
 }else{
   $_GET["sid"]=$stid;
   $stdfttxt="STDFT".$stid."=".file_get_contents("http://".glw()."SPEC/EDITOR/anyshort.php?stid=stbeUd&sid=".$stid."&rnd=".getRandChar(8));   
   $savepath0="/ORG/system/".$sysid."/mytabs/".$tbnm."/".$stid.".js";
   $savever0="/ORG/system/".$sysid."/mytabs/".$tbnm."/".$stid."jsversion/".date("YmdHis").".js";
 }
 if (file_exists($savepath0)){
    $oldstdfttxt=file_get_contents($savepath0);
 }else{
    $oldstdfttxt="";
 }
if ($oldstdfttxt!=$stdfttxt){
 $x=overfile(combineurl(localroot(),$savepath0),$stdfttxt);
 $y=overfile(combineurl(localroot(),$savever0),$stdfttxt);
 $bbb0=file_get_contents("http://".glw()."DNA/EXF/qnyupload.php?lcfile=".combineurl(localroot(),$savepath0));
 $cbb0=file_get_contents("http://".glw()."DNA/EXF/qnyupload.php?lcfile=".combineurl(localroot(),$savever0));
 $ok=unlink(combineurl(localroot(),$savever0));
}
$kbase=thekeyfun($kbase,glb(),"SHORTID",$stid);
$fmcc="";
$fmcd="";
$fmcc=$kbase["CODE"]["JS"];
if (dftval($_GET["dbnm"],"")==""){
 $savepath1="/ORG/system/".$sysid."/tabs/".$tbnm."/".$stid."_detail.js";
 $savever1="/ORG/system/".$sysid."/tabs/".$tbnm."/".$stid."detailjsversion/".date("YmdHis").".js";
}else{
 $savepath1="/ORG/system/".$sysid."/mytabs/".$tbnm."/".$stid."_detail.js";
 $savever1="/ORG/system/".$sysid."/mytabs/".$tbnm."/".$stid."detailjsversion/".date("YmdHis").".js";
}
if (file_exists($savepath1)){
  $oldfmcc=file_get_contents($savepath1);
}else{
  $oldfmcc="";
}
if ($oldfmcc!=$fmcc){
 $x=overfile(combineurl(localroot(),$savepath1),$fmcc);
 $y=overfile(combineurl(localroot(),$savever1),$fmcc);
 $bbb1=file_get_contents("http://".glw()."DNA/EXF/qnyupload.php?lcfile=".combineurl(localroot(),$savepath1));
 $cbb1=file_get_contents("http://".glw()."DNA/EXF/qnyupload.php?lcfile=".combineurl(localroot(),$savever1));
 $ok=unlink(combineurl(localroot(),$savever1));
}
$kb=thekeyinfo($kb,glb(),$tbnm,"*");
$akb=allkeyinfo($akb,glb(),$tbnm);
$_GET["tablename"]=$tbnm;
if (dftval($_GET["dbnm"],"")==""){
 $_GET["sid"]=$stid;
 $fmcd= "TBFRM".$tbnm."=".anyshort("tabcol","","").";\r\n";
 $fmcd=$fmcd.$kb["CODE"]["JS"].$akb["CODE"]["JS"];
 $savepath2="/ORG/system/".$sysid."/tabs/".$tbnm."/".$stid."_table.js";
 $savever2="/ORG/system/".$sysid."/tabs/".$tbnm."/".$stid."tablejsversion/".date("YmdHis").".js";
}else{
 $_GET["sid"]=$stid;
 $fmcd= "TBFRM".$tbnm."=".file_get_contents("http://".glw()."SPEC/EDITOR/anyshort.php?stid=tabd2K&tablename=".$tbnm."&dnm=".dftval($_GET["dbnm"],"")).";\r\n";
 $fmcd=$fmcd.$kb["CODE"]["JS"].$akb["CODE"]["JS"];
 $savepath2="/ORG/system/".$sysid."/mytabs/".$tbnm."/".$stid."_table.js";
 $savever2="/ORG/system/".$sysid."/mytabs/".$tbnm."/".$stid."tablejsversion/".date("YmdHis").".js";
}
if (file_exists($savepath2)){
  $oldfmcd=file_get_contents($savepath2);
}else{
  $oldfmcd="";
}
if ($oldfmcd!=$fmcd){
 $x=overfile(combineurl(localroot(),$savepath2),$fmcd);
 $y=overfile(combineurl(localroot(),$savever2),$fmcd);
 $bbb2=file_get_contents("http://".glw()."DNA/EXF/qnyupload.php?lcfile=".combineurl(localroot(),$savepath2));
 $cbb2=file_get_contents("http://".glw()."DNA/EXF/qnyupload.php?lcfile=".combineurl(localroot(),$savever2));
 $ok=unlink(combineurl(localroot(),$savever2));
}
echo '{"status":"1","msg":"成功","redirect":""}'; 
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>