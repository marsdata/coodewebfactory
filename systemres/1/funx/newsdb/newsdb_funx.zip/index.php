<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $dttp=$_GET['dttp'];
 $dmk=str_replace(" ","",dftval($_GET['dmk'],""));
 $tbnm=str_replace(" ","",dftval($_GET['tbnm'],""));
 $slkey=str_replace(" ","",dftval($_GET['slkey'],""));
 eval(RESFUNSET("keyinfo"));
 if (substr($slkey,-1)==","){
  $tmpkey=substr($slkey,0,strlen($slkey)-1);
 }else{
  $tmpkey=$slkey;
 };
 if ($slkey=="*"){
  $alif=allkeyinfo($alif,$dbnm,$tbnm);
   $tmpkey=$alif["COLUMN"]["ALLKEY"];
 };
    $stidx=getRandChar(6);
   
    if ($dmk=="" or $dmk=="thishostcore"){
       $sqlx="shortid,tablename,showkeys,skeys,CRTM,UPTM,cdt,orddt,dttp,caseid,detailid,OLMK,CRTOR";
       $sqly="'$stidx','$tbnm','$tmpkey','',now(),now(),'','order by CRTM desc','html','layuitable.index','layuiform.index','".onlymark()."','".$_COOKIE["uid"]."'";
       $zz=UX("insert into coode_shortdata(".$sqlx.")values(".$sqly.")");
    }else{
       $sqlx="catalog,schm,shortid,tablename,showkeys,skeys,CRTM,UPTM,cdt,orddt,dttp,caseid,detailid,OLMK,CRTOR";
       $sqly="'".$dmk."','$dbnm','$stidx','$tbnm','$tmpkey','',now(),now(),'','','html','layuitable.index','layuiform.index','".onlymark()."','".$_COOKIE["uid"]."'";
       $zz=UX("insert into coode_dbshort(".$sqlx.")values(".$sqly.")");
    }
    
    if ($dmk=="" or $dmk=="thishostcore"){
      $extn=UX("select count(*) as result from coode_shortdata where shortid='".$stidx."'");
    }else{      
      $extn=UX("select count(*) as result from coode_dbshort where shortid='".$stidx."' and catalog='".$dmk."'");
    }
    
    if ($extn>0){
      $rdru="/localxres/funx/anyjsshort/?stid=".$stidx."-pnum:30-";
      echo makereturnjson("1","成功",$rdru);
    }else{
      $rdru="/localxres/funx/anydbshort/?dbmk=".$dmk."&stid=".$stidx."-pnum:30-";
      echo makereturnjson("1","成功",$rdru);
    }
     session_write_close();
?>