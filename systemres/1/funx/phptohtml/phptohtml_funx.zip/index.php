<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $urlmark=$_GET["urlmark"];
$tbnm=$_GET["tbnm"];
$cssmk=$_GET["cssmk"];
$sid=$_GET["sid"];
$snos="0,".$_GET["snos"];
$page=str_replace("undefined","",$_GET["page"]);
$pnum=str_replace("undefined","",$_GET["pnum"]);
$phtml=$_POST["phtml"];
$pfile=unstrs($phtml);
if (strpos($pfile,"<select")>0){ 
 $pfile="";
}else{
 $pfile="<html>\r\n".str_replace($urlmark,"",$pfile)."\r\n</html>";
};
       $conn=mysql_connect(gl(),glu(),glp());
       $tbcdtss=updatingx($conn,glb(),"select cdt as result from coode_shortdata where shortid='".$sid."'","utf8");
      if (strlen($tbcdtss)>5){
        if(strpos($tbcdtss,"like")<=0 and strpos($tbcdtss,"=")<=0 and strpos($tbcdtss,"by")<=0){
         $tbcdtss=Hex2String($tbcdtss); //未发现说面加密了,需要解密,否则不用解密       
        };
        $tbcdtss=str_replace("[gid]",$_COOKIE["gid"],$tbcdtss);
        $tbcdtss=str_replace("[uid]",$_COOKIE["uid"],$tbcdtss);
        $tbcdtss=str_replace("[cid]",$_COOKIE["cid"],$tbcdtss);
        $tbcdtss=str_replace("[date]",date("Y-m-d"),$tbcdtss);
        $tbcdtss=str_replace("[now]",date("Y-m-d H:i:s"),$tbcdtss);
       $ptnhtxt=explode("[get-",$tbcdtss);
       $totpt=count($ptnhtxt);
       for ($f=0;$f<$totpt;$f++){
          $tmpok=qian($ptnhtxt[$f],"]");
         $tbcdtss=str_replace("[get-".$tmpok."]",$_GET[$tmpok],$tbcdtss);     
       };         
       $ptnhtxt=explode("[post-",$tbcdtss);
       $totpt=count($ptnhtxt);
       for ($f=0;$f<$totpt;$f++){
         $tmpok=qian($ptnhtxt[$f],"]");
         $tbcdtss=str_replace("[post-".$tmpok."]",$_POST[$tmpok],$tbcdtss);     
       };
       $ptnhtxt=explode("[cookie-",$tbcdtss);
       $totpt=count($ptnhtxt);
       for ($f=0;$f<$totpt;$f++){
         $tmpok=qian($ptnhtxt[$f],"]");
         $tbcdtss=str_replace("[cookie-".$tmpok."]",$_COOKIE[$tmpok],$tbcdtss);     
       };
        $tbcdtss=str_replace("[anymark]",date("YmdHis").getRandChar(6),$tbcdtss);
      }        
        $stcode=str_replace(" ","",$tbcdtss);
        $stcode=str_replace("'","",$stcode);
        $stcode=str_replace("=","eq",$stcode);
        $stcode=str_replace("<>","en",$stcode);
        $stcode=str_replace(">","gr",$stcode);
        $stcode=str_replace("<","le",$stcode);
        
  $yy=createdir($gml."ORG/BRAIN/files/".$tbnm);
  $rpt=$gml."ORG/BRAIN/files/".$tbnm."/";
  $fpn=$rpt.$urlmark."--".$stcode.".html";
  $k=overfile($fpn,$pfile);
  $furl="/ORG/BRAIN/files/".$tbnm."/".$urlmark."--".$stcode.".html";
  $conn=mysql_connect(gl(),glu(),glp());
  $exturl=updatingx($conn,glb(),"select count(*) as result from coode_shortaffect where shortid='".$sid."' and stylecls='".$cssmk."' and pagecls='list' and tablename='".$tbnm."' and pnum='".$pnum."' and page='".$page."' ","utf8");
  $conn=mysql_connect(gl(),glu(),glp());
  $sks=updatingx($conn,glb(),"select showkeys as result from coode_shortdata where shortid='".$sid."'  ","utf8");
  if (($exturl*1)==0){
    $conn=mysql_connect(gl(),glu(),glp());
    $xx=updatingx($conn,glb(),"insert into coode_shortaffect(shortid,snos,showkeys,stylecls,pagecls,tablename,pnum,page,CRTM,UPTM,stockurl,STCODE)values('".$sid."','".$snos."','".$sks."','".$cssmk."','list','".$tbnm."','".$pnum."','".$page."',now(),now(),'".$furl."','".$stcode."')","utf8");
  }else{
    $conn=mysql_connect(gl(),glu(),glp());
    $yy=updatingx($conn,glb(),"update coode_shortaffect set stockurl='".$furl."',CRTM=UPTM where shortid='".$sid."' and stylecls='".$cssmk."' and pagecls='list' and tablename='".$tbnm."' and pnum='".$pnum."' and page='".$page."' ","utf8");
  }
echo "1";
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>