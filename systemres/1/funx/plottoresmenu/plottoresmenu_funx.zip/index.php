<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $plotmark="resmenux";
$plottitle="资源菜单";
$zz1=UX("delete from coode_resmenu");
$zz2=UX("delete from coode_sysrestypedefine");
$nn1=anyfunrun("retabsno","","tabnm=coode_resmenu","");
$nn2=anyfunrun("retabsno","","tabnm=coode_sysrestypedefine","");
$sqla="plotmark,level,myid,parid,mymark,parmark,mytitle,myurl,withface,fontshow,mydescrib,rescode,CRTM,UPTM,OLMK";
$sqlc="mncode,mntitle,restype,vurl,sqx,CRTM,UPTM,OLMK";
$sqld="mymark,mytitle,parmark,myurl,fontname,CRTM,UPTM,OLMK";
$zz1=UX("insert into coode_resmenu(".$sqlc.")select ".$sqld." from coode_plotdetail where plotmark='".$plotmark."' and parid!=-1");
$sqle="restypecode,restypetitle,typedescrib,headpic,midpic,numx,relyotherres,CRTM,UPTM,OLMK";
$sqlf="mymark,mytitle,mydescrib,fontshow,withface,myid-1,rescode,CRTM,UPTM,OLMK";
$gg=UX("insert into coode_sysrestypedefine(".$sqle.")select ".$sqlf." from coode_plotdetail where plotmark='".$plotmark."' and parid=-1");
echo makereturnjson("1","将节点转资源菜单成功","");
       session_write_close();
?>