<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $xurl=$_GET["xurl"];
$stid=hou($xurl,"stid=");
$stid=qian($stid,"-");
$topx='<!DOCTYPE html><html><head><meta http-equiv="content-type" content="text/html;charset=utf-8"><title>[tabletitle]</title><style type="text/css">table{border:1px solid #000000;table-layout:fixed;border-collapse:collapse}td{border:1px solid #000000;word-wrap:break-word;word-break:break-all;font-size:12px}</style></head>';
$conn=mysql_connect(gl(),glu(),glp());
$sttt=updatings($conn,glb(),"select shorttitle as result from coode_shortdata where shortid='".$stid."'","utf8");
if (strpos($xurl,"page=")>0){
  $page=qian(hou($xurl,"page="),"&");
}else{
  $page="1";
}
if (strpos($xurl,"pnum=")>0){
$pnum=qian(hou($xurl,"pnum="),"&");
}else{
$pnum="30";
}
if (strpos($xurl,"xkey=")>0){
    $xkey=qian(hou($xurl,"xkey="),"&");
}else{
    $xkey=$_GET["xkey"];
}
if (strpos($xurl,"xval=")>0){
   $xval=qian(hou($xurl,"xval="),"&");
}else{
   $xval=$_GET["xval"]; 
}
//if (strpos($pnum,":")>0){
//  $oval=hou($pnum,":");
//}
//if (strpos($page,":")>0){
//  $okey=hou($page,":");
//}
//if ($okey!="" and $oval!=""){
    
//}else{
    
//}
$_GET["print"]="1";
$_GET["xkey"]=$xkey;
$_GET["xval"]=$xval;
$bkh=anyshort($stid,$page,$pnum);
if ($sttt!=""){
 $bkh=str_replace("[tabletitle]",$sttt,$bkh);
 $topx=str_replace("[tabletitle]",$sttt,$topx);
}else{
 $topx=str_replace("[tabletitle]",$stid."分表",$topx);
}
echo $topx."<body><div style=\"width:auto;align:center;\">".$bkh."</div></body></html>";  
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>