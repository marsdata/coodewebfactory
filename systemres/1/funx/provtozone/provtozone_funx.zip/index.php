<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $zz=UX("update eqm_venders set chinaarea='db' where province='辽宁省' or  province='吉林省' or  province='黑龙江省' ");
$zz=UX("update eqm_venders set chinaarea='xb' where province='新疆维吾尔族自治区' or  province='青海省' or  province='宁夏回族自治区'  or  province='甘肃省'  or  province='陕西省'");
$zz=UX("update eqm_venders set chinaarea='hb' where province='山西省' or  province='内蒙古自治区' or  province='河北省'  or  province='河南省'  or  province='山东省'  or  province='北京市'  or  province='天津市' ");
$zz=UX("update eqm_venders set chinaarea='hd' where province='上海市' or  province='江苏省' or  province='浙江省'  or  province='安徽省'  or  province='江西省' ");
$zz=UX("update eqm_venders set chinaarea='hz' where province='湖北省' or  province='湖南省' ");
$zz=UX("update eqm_venders set chinaarea='dn' where province='福建省' or  province='台湾省' ");
$zz=UX("update eqm_venders set chinaarea='hn' where province='广东省' or  province='广西省' or  province='海南省' ");
$zz=UX("update eqm_venders set chinaarea='xn' where province='西藏自治区' or  province='四川省' or  province='云南省'  or  province='贵州省'  or  province='重庆市' ");
echo makereturnjson("1","制作成功","");
     session_write_close();
?>