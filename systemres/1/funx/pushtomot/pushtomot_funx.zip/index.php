<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     eval(RESFUNSET("resrelyrp"));
$restype=_get("restype");
$rescode=_get("rescode");
$tohost=getsvshost(_get("sysid"));
$vmd5=resvermd5($restype,$rescode);
$pmk=getRandChar(8);
$prst=SX("select tohost,pushmark,resid,restype,vermd5 from coode_pushres where OLMK='".$olmkx."'");
$sqlx="tohost,pushmark,resid,restype,vermd5,CRTM,UPTM,OLMK";
$sqly="'".$tohost."','".$pmk."','".$rescode."','".$restype."','".$vmd5."',now(),now(),'".onlymark()."'";
$zz=UX("insert into coode_pushres(".$sqlx.")values(".$sqly.")");
  $tohost=hou($tohost,"://");
  $resid=$rescode;  
  $vermd5=$vmd5;
  $pushmark=$pmk;
  
  if (strpos($tohost,":")>0){
    $dkh=hou($tohost,":");
  }else{
    $dkh="80";
  }
  if ($dkh=="443"){
    $purl=combineurl("https://".qian($tohost,":"),"/localxres/funx/rcvres/?pushmark=".$pushmark);
  }else{
    $purl=combineurl("http://".$tohost,"/localxres/funx/rcvres/?pushmark=".$pushmark);
  }
  $pool=SX("select SNO,grpid,restitle from coode_sysregres where  resmark='".$resid."' and restype='".$restype."'");
  $toto=countresult($pool);
  if ($toto>0){
    $sysid=anyvalue($pool,"grpid",0);
    $rtitle=anyvalue($pool,"restitle",0);
    $purl=$purl."&sysid=".$sysid;
    $purl=$purl."&restitle=".$rtitle;
    $purl=$purl."&fromhost=".killlaststr(glw());
      $purl=$purl."&vermd5=".$vermd5;  
      $purl=$purl."&restype=".$restype;  
      $purl=$purl."&rescode=".$resid;       
      echo file_get_contents($purl);
  }else{
    echo makereturnjson("0","未发现coode_sysregres","");
  }
  
  
     session_write_close();
?>