<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $stid=dftval(qian($_GET["stid"],"-"),"");
$qry=dftval($_GET["qry"],"");
$qry2=dftval($_GET["qry2"],"");
$pnum=dftval($_GET["pnum"],"30");
$page=dftval($_GET["page"],"1");
$shortbs=array();
$shortbs=shortinfo($stid,$shortbs);
$kies=$shortbs["showkeys"];
$cdtx=$shortbs["cdt"];
$tbname=$shortbs["tablename"];
$ptk=explode(",",$kies);
$totk=count($ptk);
$srddemo='{"data":[data],"total":"[total]"}';
$itemx="";
$pgcdt="";
$pgcdt="limit ".($page-1)*$pnum.",".$pnum;
$kb=array();
$kb=thekeyfun($kb,glb(),$tbname,$kies);
if ($qry2!=""){
  $extcdt=" and concat(".$kies.") like '%".$qry2."%' ";
  if ($cdtx!=""){
   $extcdt=$extcdt." and ".$cdtx;
  }
  $totrcd=UX("select count(*) as result from ".$tbname." where concat(".$kies.") like '%".$qry."%' ".$extcdt);
}else{
  $extcdt="";
  if ($cdtx!=""){
   $extcdt=$extcdt." and ".$cdtx;
  }
  $totrcd=UX("select count(*) as result from ".$tbname." where concat(".$kies.") like '%".$qry."%' ".$extcdt);
} 
$strst=SX("select ".$kies." from ".$tbname." where concat(".$kies.") like '%".$qry."%' ".$extcdt.$pgcdt);
$totst=countresult($strst);
$fmall="";
for ($j=0;$j<$totst;$j++){
 $itemy="{";
  for ($k=0;$k<$totk;$k++){
    $tkey=$ptk[$k];
    if ($tkey!=""){
     $jshow=turnlab($kb[$tkey]["COLUMN_JSHOW"]);     
     $preval=anyvalue($strst,$tkey,$j);
     if ($jshow!=""){
          $trox=array();
          $trox["key"]=$tkey;
          $trox["key0"]="p_".$tkey.anyvalue($strst,"SNO",$j);
          $trox["thissno"]=anyvalue($strst,"SNO",$j);
          $trox["showkeys"]=$kies;
          $trox["tablename"]=$tbname;
          $trox["shortid"]=$stid;
          $trox["dxtype"]=$kb[$tkey]["COLUMN_DXTYPE"];
          if (intval($kb[$tkey]["COLUMN_DSPLD"])==1){
           $trox["dsplhtml"]="";
          }else{
           $trox["dsplhtml"]="displayed:none;";
          };
          if (intval($kb[$tkey]["COLUMN_CANGE"])==1){
            $trox["rdolhtml"]="";
          }else{
            $trox["rdolhtml"]="readonly";
          };
          $trox["thisolmk"]=anyvalue($strst,"OLMK",$j);
          $trox["tablename"]=$tbname;
          $trox["sysid"]=$sysid;
          $trox["appid"]=$appid;
          $trox["value"]=$preval;
          $trox["ti"]=$j;
          $trox["tj"]=$k;
          $trox["acthtm"]=$kb[$ptsk[$n]]["COLUMN_ACTHTM"];
          $trox["atnhtm"]=$kb[$ptsk[$n]]["COLUMN_ATNHTM"];          
          $jshow=exchangeunit($trox,$jshow);
          $ptnhtxt=explode("[key-",$jshow);
          $totpt=count($ptnhtxt);          
          for ($f=0;$f<$totpt;$f++){
            $tmpok=qian($ptnhtxt[$f],"]");
            $jshow=str_replace("[key-".$tmpok."]",anyvalue($strst,$tmpok,$j),$jshow);     
          };  
          $jshow=str_replace("\"","\\\"",$jshow);
          $itemy=$itemy.'"'.$tkey.'":"'.$jshow.'",';
     }else{
       $itemy=$itemy.'"'.$tkey.'":"'.$preval.'",';
     }
    }//fork
  }//forj
  $itemy=killlaststr($itemy)."},";
  $fmall=$fmall.$itemy;
}
$fmall=killlaststr($fmall);
$srddemo=str_replace("[data]",'['.$fmall.']',$srddemo);
$srddemo=str_replace("[total]",$totrcd,$srddemo);
echo $srddemo;
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>