<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $dbmarkx=$_POST["dbmark"];
$tabnmx=$_POST["tabnm"];
$hostkeyx=$_POST["hostkeys"];
$hostcrtx=$_POST["hostcrtx"];
$jsondatax=downandeq($_POST["jsondata"]);//直接接受数据包，不需要来源的STID 有表名，可以还原数据
$jsonkeyx=$_POST["jsonkeys"];
$jsonreskeyx=$_POST["jsonreskeys"];
$ak=dftval($_GET["ak"],"");
$av=dftval($_GET["av"],"");
//数据一次同步不要太多，否则容易卡死
if (verifyscv($ak,$av)){
 $arole=UX("select hostrolex as result from coode_scvuser where apikey='".$ak."' and apival='".$av."'");
 $extp=UX("select count(*) as result from coode_clientdataplan where dbmark='".$dbmarkx."' and dbtabnm='".$tabnmx."' and thiskeys='".$hostkeyx."' and av='".$av."' and STATUS=1");
 //echo "select count(*) as result from coode_clientdataplan where dbmark='".$dbmarkx."' and dbtabnm='".$tabnmx."' and thiskeys='".$hostkeyx."' and av='".$av."' and STATUS=1";
 if (intval($extp)>0){
  if (jdatatotab($jsondatax,$dbmarkx,$tabnmx,$jsonreskeyx,$jsonkeyx,$hostkeyx)){
   echo makereturnjson("1","操作成功","");
  }else{   
   echo makereturnjson("0","操作失败","");
  }
 }else{
   //如果没有计划则新建个计划
   $extq=UX("select count(*) as result from coode_clientdataplan where dbmark='".$dbmarkx."' and dbtabnm='".$tabnmx."' and thiskeys='".$hostkeyx."' and '".$arole."' like concat('%',chostrole,'%')");
   if (intval($extq)==0){
     $sqlx="av,dbmark,dbtabnm,thiskeys,reskeys,deadline,createsql,CRTM,UPTM,OLMK,chostrole";
     $sqly="'".$av."','$dbmarkx','$tabnmx','$hostkeyx','$jsonreskeyx','".date("Y-m-d H:i:s")."','".$hostcrtx."',now(),now(),'".onlymark()."','".$arole."'";
     $zz=UX("insert into coode_clientdataplan(".$sqlx.")values(".$sqly.")");
   }
   echo makereturnjson("-1","无权操作","");
 }
}else{
  echo makereturnjson("-1","无权操作","");
}
     session_write_close();
?>