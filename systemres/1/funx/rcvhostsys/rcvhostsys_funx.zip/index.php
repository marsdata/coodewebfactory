<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $sysid=$_GET["sysid"];
$myhost=$_POST["myhost"];
$sysname=$_POST["sysname"];
$vermd5=$_POST["vermd5"];
$faceimg=$_POST["faceimg"];
$detail=$_POST["detail"];
$rnm=$_POST["rnm"];
$vxpic=$_POST["vxpic"];
if (strpos($vxpic,"//")>0){
}else{
  $vxpic=combineurl("http://".$myhost,$vxpic);
}
$extx=UX("select count(*) as result from coode_hostregsys where sysid='".$sysid."' and host='".$myhost."'");
if (intval($extx)==0){
  $sqla="host,sysid,sysname,devehead,deveman,headpic,midpic,hostver,CRTM,UPTM,OLMK,CRTOR,describ";
  $sqlb="'".$myhost."','".$sysid."','".$sysname."','".$vxpic."','".$rnm."','".combineurl("http://".$myhost,$faceimg)."','".$faceimg."','".$vermd5."',now(),now(),'".onlymark()."','hellowocao','".$detail."'";
  $zz=UX("insert into coode_hostregsys(".$sqla.")values(".$sqlb.")");
  echo makereturnjson("1","提交成功","");
}else{
  $exty=UX("select count(*) as result from coode_hostregsys where sysid='".$sysid."' and host='".$myhost."' and STATUS=-1");
  if (intval($exty)==1){      
      $yy=UX("select STCODE as result from coode_hostregsys where sysid='".$sysid."' and host='".$myhost."' and STATUS=-1");    
      echo makereturnjson("-1","更新失败，黑名单(".$yy.")","");    
  }else{
      $zz=UX("update coode_hostregsys set deveman='".$rnm."',devehead='".$vxpic."',STATUS=0,UPTM=now(),sysname='".$sysname."',describ='".$detail."',headpic='".combineurl("http://".$myhost,$faceimg)."',hostver='".$vermd5."' where host='".$myhost."' and sysid='".$sysid."'");
      echo makereturnjson("1","更新成功","");
  }
}
$nn=UX("update coode_hostregsys set PRIME=0 ");
$nn=UX("update coode_hostregsys set PRIME=1 where sysid in(select sysid from coode_sysinformation)");
       session_write_close();
?>