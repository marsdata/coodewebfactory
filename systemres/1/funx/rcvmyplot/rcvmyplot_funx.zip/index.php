<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $plid=$_GET['plid'];
 $plrst=$_POST['plrst'];
 $ckd=$_POST["ckd"];
 if ($plrst!=""){
   $plrst=substr($plrst,0,strlen($plrst)-1);
 };
 $ptrst=explode(";",$plrst);
 $ptckd=explode("--",$ckd);
 $totpc=count($ptckd);
 $totpt=count($ptrst);
 $ntime=date("Y-m-d H:i:s");
 $fmallmk="";
 if (strpos($plid,"/")>0){
   $conn=mysql_connect(gl(),glu(),glp());
   $czd=updatings($conn,glb(),"select count(*) as result from coode_plotmydetail where plotmark='".$plid."' and myid>9000","utf8");
 }else{
   $czd=0;
 }
 $fmbdyl="";
$cfunx=atv("(coode_plotmylist@plotmark='".$plid."').clickfun");
$pltt=atv("(coode_plotlist@plotmark='".$plid."').markname");
if (editacc("plotname",$plid)){
 for ($i=0;$i<$totpt;$i++){
   $thispt=explode(",",$ptrst[$i]);
   $totthis=count($thispt);
   $conn=mysql_connect(gl(),glu(),glp());
   $thispt[4]=str_replace('level','',$thispt[4]);
   $thispt[3]=str_replace('treeDemo','',$thispt[3]);
   $thispt[3]=str_replace('ul','',$thispt[3]);
   $thispt[3]=str_replace('_','',$thispt[3])*1;
   $thispt[2]=str_replace('treeDemo','',$thispt[2]);
   $thispt[2]=str_replace('ul','',$thispt[2]);
   $thispt[2]=str_replace('_','',$thispt[2])*1;
     $_POST["parid"]=$thispt[3];
     $_POST["myid"]=$thispt[2];
     $_POST["mytitle"]=$thispt[1];     
     $_POST["level"]=$thispt[4];
   if ( $thispt[0]=="_blank"){//add
    $conn=mysql_connect(gl(),glu(),glp());
      $xt=1;
      while($xt>=1){
         $mk=getRandChar(2);
         $conn=mysql_connect(gl(),glu(),glp());
         $xt=updatingx($conn,glb(),"select count(*) as result from coode_plotmydetail where plotmark='".$plid."' and mymark='".$mk."'","utf8");
      };
      
    $conn=mysql_connect(gl(),glu(),glp());
     $ptof=atv("(coode_plotmydetail@plotmark='".$plid."' and myid='".$thispt[3]."').PTOF");
     $_POST["mymark"]=$mk;
      if ($cfunx!=""){
       $z=anyfunrun($cfunx,_get("appid"),"plotmark=".$plid."&SNO=0","parid=".$_POST["parid"]."&myid=".$_POST["myid"]."&mytitle=".$_POST["mytitle"]."&mymark=".$_POST["mymark"]."&level=".$_POST["level"]);
       echo $z;
      }
      $fmallmk=$fmallmk.$_POST["mymark"].",";
      
     $x=updatings($conn,glb(),"INSERT INTO coode_plotmydetail(plotmark,CRTM,UPTM,myid,parid,mymark,mytitle,level,OLMK,PTOF)VALUES('".$plid."','".$ntime."','".$ntime."','".$_POST["myid"]."','".$_POST["parid"]."','".$_POST["mymark"]."','".$_POST["mytitle"]."','".$_POST["level"]."','".onlymark()."','".$ptof."')","utf8");   
   }else{//update     
     $_POST["mymark"]=$thispt[0];
     $parptof=atv("(coode_plotmydetail@plotmark='".$plid."' and myid='".$thispt[3]."').PTOF");
     $conn=mysql_connect(gl(),glu(),glp());
     $orst=selecteds($conn,glb(),"select SNO,myid,parid,mytitle,level,PTOF from coode_plotmydetail where plotmark='".$plid."' and mymark='".$_POST["mymark"]."'","utf8","");
     $toto=countresult($orst);     
     if ($toto>0){        
      if (anyvalue($orst,"PTOF",0)==$parptof and (anyvalue($orst,"myid",0)*1)==($thispt[2]*1) and (anyvalue($orst,"parid",0)*1)==($thispt[3]*1) and anyvalue($orst,"mytitle",0)==$thispt[1] and (anyvalue($orst,"level",0)*1)==($thispt[4]*1)){
        $conn=mysql_connect(gl(),glu(),glp());
        $extb=updatingx($conn,glb(),"update coode_plotmydetail set UPTM='".$ntime."' where SNO=".anyvalue($orst,"SNO",0),"utf8");
        $fmallmk=$fmallmk.$_POST["mymark"].",";
      }else{//如果有变化则执行变化的 发现会有修改失败的时候先执行时间，防止丢失    不判断STATUS 是因为 群组 个人太多太乱，这里不判断     
        if (strpos($plid,"/")>0 and ($czd*1)>0){
           if ($cfunx!=""){
             $y=anyfunrun($cfunx,_get("appid"),"plotmark=".$plid."&SNO=".anyvalue($orst,"SNO",0),"parid=".$_POST["parid"]."&myid=".$_POST["myid"]."&mytitle=".$_POST["mytitle"]."&mymark=".$_POST["mymark"]."&level=".$_POST["level"]);
           }
           $conn=mysql_connect(gl(),glu(),glp());
           $extb=updatingx($conn,glb(),"update coode_plotmydetail set CRTM='".$ntime."',UPTM='".$ntime."',myid='".$_POST["myid"]."',mymark='".$_POST["mymark"]."',PTOF='".$parptof."',parid='".$_POST["parid"]."',mytitle='".$_POST["mytitle"]."',level='".$_POST["level"]."' where SNO=".anyvalue($orst,"SNO",0),"utf8");
        }else{
           if ($cfunx!=""){
            $y=anyfunrun($cfunx,_get("appid"),"plotmark=".$plid."&SNO=".anyvalue($orst,"SNO",0),"parid=".$_POST["parid"]."&myid=".$_POST["myid"]."&mytitle=".$_POST["mytitle"]."&mymark=".$_POST["mymark"]."&level=".$_POST["level"]);
           }
           $conn=mysql_connect(gl(),glu(),glp());
           $extb=updatings($conn,glb(),"UPDATE coode_plotmydetail SET UPTM='".$ntime."',myid='".$thispt[2]."',PTOF='".$parptof."',parid='".$_POST["parid"]."',mymark='".$_POST["mymark"]."',mytitle='".$_POST["mytitle"]."',level='".$_POST["level"]."' WHERE SNO=".anyvalue($orst,"SNO",0),"utf8");
        }
        $fmallmk=$fmallmk.$_POST["mymark"].",";
      }
     }else{//
       $fmbdyl=$fmbdyl.$thispt[0].",";
       $fmallmk=$fmallmk.$_POST["mymark"].",";
     }
   };//if
};//for
if (strpos($plid,"appp")>0){//如果是权限节点
  $gxid=str_replace("appp","",hou($plid,"/"));
  if ($gxid*1>0){//cid 用的不太好这个节点隶属谁应该用谁 影响部门下的职位，职位在影响个人
    $allposx=atvs("(coode_mypos@cid='".qian($plid,"/")."' and depart='".$gxid."').posid"); 
    $allposx="xx,".qian($plid,"/")."/".str_replace(",",",".qian($plid,"/")."/",$allposx);
    for ($t;$t<$totpc;$t++){ 
      $conn=mysql_connect(gl(),glu(),glp());
      $nc=updatingx($conn,glb(),"update coode_plotmydetail set STATUS='".hou($ptckd[$t],":")."' where mymark='".qian($ptckd[$t],":")."' and plotmark='".$plid."'","utf8");    
      $conn=mysql_connect(gl(),glu(),glp());
      $tob=updatingx($conn,glb(),"update coode_pmiss set grpvalx='".hou($ptckd[$t],":")."' where concat(appid,'-',behiver,'pmt',method)='".qian($ptckd[$t],":")."' and '".$allposx."' like concat('%,',groupid,',%')","utf8");
      $conn=mysql_connect(gl(),glu(),glp());
      $tob=updatingx($conn,glb(),"update coode_pmiss set grpvalx='".hou($ptckd[$t],":")."' where concat(appid,method)='".qian($ptckd[$t],":")."' and '".$allposx."' like concat('%,',groupid,',%')","utf8");
      $conn=mysql_connect(gl(),glu(),glp());
      $tob=updatingx($conn,glb(),"update coode_permission set grpvalx='".hou($ptckd[$t],":")."' where concat(appid,'-',behiver,'pmt',method)='".qian($ptckd[$t],":")."' and '".qian($plid,"/")."/".$gxid."'=groupid","utf8");
      $conn=mysql_connect(gl(),glu(),glp());
      $tob=updatingx($conn,glb(),"update coode_permission set grpvalx='".hou($ptckd[$t],":")."' where concat(appid,method)='".qian($ptckd[$t],":")."' and '".qian($plid,"/")."/".$gxid."'=groupid","utf8");     
    }    
  }else{//如果不是部门事pos    
    $allposx=str_replace("appp","",$plid);
    for ($t;$t<$totpc;$t++){ 
      $conn=mysql_connect(gl(),glu(),glp());
      $nc=updatingx($conn,glb(),"update coode_plotmydetail set STATUS='".hou($ptckd[$t],":")."' where mymark='".qian($ptckd[$t],":")."' and plotmark='".$plid."'","utf8");    
      $conn=mysql_connect(gl(),glu(),glp());
      $tob=updatingx($conn,glb(),"update coode_pmiss set grpvalx='".hou($ptckd[$t],":")."' where concat(appid,'-',behiver,'pmt',method)='".qian($ptckd[$t],":")."' and groupid='".$allposx."'","utf8");
      $conn=mysql_connect(gl(),glu(),glp());
      $tob=updatingx($conn,glb(),"update coode_pmiss set grpvalx='".hou($ptckd[$t],":")."' where concat(appid,method)='".qian($ptckd[$t],":")."' and groupid='".$allposx."'","utf8");
      $conn=mysql_connect(gl(),glu(),glp());
      $tob=updatingx($conn,glb(),"update coode_permission set valx='".hou($ptckd[$t],":")."' where concat(appid,'-',behiver,'pmt',method)='".qian($ptckd[$t],":")."' and groupid='".$allposx."'","utf8");
      $conn=mysql_connect(gl(),glu(),glp());
      $tob=updatingx($conn,glb(),"update coode_permission set valx='".hou($ptckd[$t],":")."' where concat(appid,method)='".qian($ptckd[$t],":")."' and groupid='".$allposx."'","utf8");     
    }    
    
  }
 }//如果是权限节点
//要将过期的扔进MYPLOT
   $conn=mysql_connect(gl(),glu(),glp());
   $zsl=updatings($conn,glb(),"select count(*) as result from coode_plotmydetail where plotmark='".$plid."'","utf8");
   $conn=mysql_connect(gl(),glu(),glp());
   $gqsl=updatings($conn,glb(),"select count(*) as result from coode_plotmydetail where plotmark='".$plid."' and ',".$fmallmk.",' not like concat('%,',mymark,',%')","utf8");     
   if (($gqsl/$zsl)*100<=25){//  1/4 以下才可以抛弃不然容易删错 懂了，上次就是数量差不多到那些就造成错乱了 数量少的话容易被删掉
    $conn=mysql_connect(gl(),glu(),glp());//反正这里搞不好容易出错 还是加上时间判断，让MAKERCV的时间不包括MYPLOTDETAIL的就可以了
    $allkx="plotmark,CRTM,UPTM,level,myid,parid,oriid,mytitle,partitle,orititle,mymark,parmark,orimark,myurl,myclick,CRTOR,mydescrib,PRIME,OLMK,PTOF";
    $delmk=onlymark();
    $throw=updatingx($conn,glb(),"insert into coode_plotdekill(".$allkx.",STCODE)select ".$allkx.",'".$delmk."' from coode_plotmydetail where plotmark='".$plid."' and ',".$fmallmk.",' not like concat('%,',mymark,',%')","utf8");    
    if ($cfunx!=""){
     $y=anyfunrun($cfunx,_get("appid"),"plotmark=".$plid."&SNO=".anyvalue($orst,"SNO",0)."&delmk=".$delmk,"parid=".$_POST["parid"]."&myid=".$_POST["myid"]."&mytitle=".$_POST["mytitle"]."&mymark=".$_POST["mymark"]."&level=".$_POST["level"]);
     echo $y;
    }
    $conn=mysql_connect(gl(),glu(),glp());//这样删除判断比较保险起见 时间总脱 现在的情况是fmallmk 有时候只提交了一部分
    $delx=updatingx($conn,glb(),"delete  from coode_plotmydetail where plotmark='".$plid."'  and ',".$fmallmk.",' not like concat('%,',mymark,',%')","utf8");
    $conn=mysql_connect(gl(),glu(),glp());
    $scbm=updatings($conn,glb(),"delete from coode_mygroup where concat(cid,'config')='".$plid."' and gid not in(select mymark from coode_plotmydetail where  PTOF='department' and plotmark='".$plid."')","utf8");
    $conn=mysql_connect(gl(),glu(),glp());
    $sczw=updatings($conn,glb(),"delete from coode_mypos where concat(cid,'config')='".$plid."'  and posid not in(select mymark from coode_plotmydetail where PTOF='position' and plotmark='".$plid."')","utf8");
    $conn=mysql_connect(gl(),glu(),glp());
    $sczw=updatings($conn,glb(),"delete from coode_userlist where concat(comp,'config')='".$plid."'  and userid not in(select mytitle from coode_plotmydetail where PTOF='users' and mymark<>'compolar' and plotmark='".$plid."')","utf8");
    $conn=mysql_connect(gl(),glu(),glp());
    $apid=updatings($conn,glb(),"select myid as result from coode_plotmydetail where mymark='comappsx' and plotmark='".$plid."'","utf8");
    if ($apid*1>0){
     $allnapp=atvs("(coode_plotmydetail@plotmark='".$plid."' and parid=".$apid.").mymark");
     $allnapp=substr($allnapp,0,strlen($allnapp)-1);
     $conn=mysql_connect(gl(),glu(),glp());
     $nap=updatings($conn,glb(),"update coode_sysdefault set keyval='".$allnapp."' where syskey='applist' and companyid='".str_replace("config","",$plid)."'","utf8");
    }
   }
   //$delold=UX("delete from coode_plotdetail where plotmark='BAK-".$plid."'");
   $bak=UX("insert into coode_plotdetail (plotmark,CRTM,UPTM,myid,parid,mymark,mytitle,level,OLMK,STATUS)select concat('BAK".date("YmdHis")."-',plotmark),CRTM,UPTM,myid,parid,mymark,mytitle,level,OLMK,STATUS from coode_plotmydetail where plotmark='".$plid."'");
    $conn=mysql_connect(gl(),glu(),glp());
    $tob=updatingx($conn,glb(),"update coode_plotmydetail,coode_permission set coode_permission.valx=coode_plotmydetail.STATUS where concat(coode_permission.appid,'-',coode_permission.behiver,'pmt',coode_perminssion.method)=coode_plotmydetail.mymark and coode_plotmydetail.plotmark=concat(coode_permission.groupid,'appp')","utf8");
    //紧接着应该把permission 的群组权限 影响到 PMISS里的群组结果
    $conn=mysql_connect(gl(),glu(),glp());
    $tob=updatingx($conn,glb(),"update coode_pmiss,coode_permission set coode_pmiss.grpvalx=coode_permission.valx where concat(coode_permission.appid,'-',coode_permission.behiver,'pmt',coode_perminssion.method)=concat(coode_pmiss.appid,'-',coode_pmiss.behiver,'pmt',coode_pmiss.method) and concat(coode_pmiss.compid,coode_pmiss.groupid)=concat(coode_permission.compid,coode_permission.groupid)","utf8");
    $conn=mysql_connect(gl(),glu(),glp());
    $tob=updatingx($conn,glb(),"update coode_plotmydetail,coode_pmiss set coode_pmiss.valx=coode_plotmydetail.STATUS where concat(coode_pmiss.appid,'-',coode_pmiss.behiver,'pmt',coode_pmiss.method)=coode_plotmydetail.mymark and coode_plotmydetail.plotmark=concat(coode_pmiss.groupid,coode_pmiss.clientid,'appp')","utf8");
    $conn=mysql_connect(gl(),glu(),glp());
    $tob=updatingx($conn,glb(),"update coode_plotmydetail,coode_permission set coode_permission.valx=coode_plotmydetail.STATUS where concat(coode_permission.appid,'-',coode_permission.method)=coode_plotmydetail.mymark and coode_plotmydetail.plotmark=concat(coode_permission.groupid,'appp')","utf8");
    $conn=mysql_connect(gl(),glu(),glp());
    $tob=updatingx($conn,glb(),"update coode_plotmydetail,coode_pmiss set coode_pmiss.valx=coode_plotmydetail.STATUS where concat(coode_pmiss.appid,'-',coode_pmiss.method)=coode_plotmydetail.mymark and coode_plotmydetail.plotmark=concat(coode_pmiss.groupid,coode_pmiss.clientid,'appp')","utf8");
    $conn=mysql_connect(gl(),glu(),glp());
    $tob=updatingx($conn,glb(),"update coode_pmiss,coode_permission set coode_pmiss.grpvalx=coode_permission.valx where concat(coode_pmiss.appid,'-',coode_pmiss.metcls,'-',coode_pmiss.method,'-',coode_pmiss.behiver)=concat(coode_permission.appid,'-',coode_permission.metcls,'-',coode_permission.method,'-',coode_permission.behiver) and concat(coode_pmiss.compid,coode_pmiss.appid,coode_pmiss.groupid)=concat(coode_permission.compid,coode_permission.appid,coode_permission.groupid)","utf8");
    echo $fmbdyl."1";
   }else{
     $aa="fromurl,etel,code,askforwhat,askforstr,CRTM,UPTM,OLMK,STATUS,CRTOR,accesstime";  
     $bb="'".$plid."','".$_COOKIE["uid"]."','".$pltt."','plotname','".$plid."',now(),now(),'".onlymark()."',0,'".$_COOKIE["uid"]."',now()";
     $afsps=UX("insert into coode_afspace(".$aa.")values(".$bb.")");
     echo "0";
   }
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>