<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $plid=$_GET['plid'];
 $plrst=$_POST['plrst'];
 $ckd=$_POST['ckd'];
 if ($plrst!=""){
   $plrst=substr($plrst,0,strlen($plrst)-1);
 };
 $ptckd=explode("--",$ckd);
 $totpc=count($ptckd);
 $ptrst=explode(";",$plrst);
 $totpt=count($ptrst);
$cfunx=atv("(coode_plotlist@plotmark='".$plid."').clickfun");
$pltt=atv("(coode_plotlist@plotmark='".$plid."').markname");
if (editacc("plotname",$plid)){
$ntime=date("Y-m-d H:i:s");
 for ($i=0;$i<$totpt;$i++){
   $thispt=explode(",",$ptrst[$i]);
   $totthis=count($thispt);
   $conn=mysql_connect(gl(),glu(),glp());
   $thispt[4]=str_replace('level','',$thispt[4]);
   $thispt[3]=str_replace('treeDemo','',$thispt[3]);
   $thispt[3]=str_replace('ul','',$thispt[3]);
   $thispt[3]=str_replace('_','',$thispt[3])*1;
   $thispt[2]=str_replace('treeDemo','',$thispt[2]);
   $thispt[2]=str_replace('ul','',$thispt[2]);
   $thispt[2]=str_replace('_','',$thispt[2])*1;
     $_POST["parid"]=$thispt[3];
     $_POST["myid"]=$thispt[2];
     $_POST["mytitle"]=$thispt[1];     
     $_POST["level"]=$thispt[4];
   if ( $thispt[0]=="_blank"){//add
    $conn=mysql_connect(gl(),glu(),glp());
      $xt=1;
      while($xt>=1){
         $mk=getRandChar(2);
         $conn=mysql_connect(gl(),glu(),glp());
         $xt=updatingx($conn,glb(),"select count(*) as result from coode_plotdetail where plotmark='".$plid."' and mymark='".$mk."'","utf8");
      };
      $_POST["mymark"]=$mk;
     if ($cfunx!=""){
       $y=anyfunrun($cfunx,_get("appid"),"plotmark=".$plid."&SNO=0","parid=".$thispt[3]."&myid=".$thispt[2]."&mytitle=".$thispt[1]."&mymark=".$mk."&level=".$thispt[4]);
     }
     
     $conn=mysql_connect(gl(),glu(),glp());    
     $x=updatings($conn,glb(),"INSERT INTO coode_plotdetail(plotmark,CRTM,UPTM,myid,parid,mymark,mytitle,level,OLMK)VALUES('".$plid."','".$ntime."','".$ntime."','".$_POST["myid"]."','".$_POST["parid"]."','".$_POST["mymark"]."','".$_POST["mytitle"]."','".$_POST["level"]."','".onlymark()."')","utf8");
   }else{//update
     $_POST["mymark"]=$thispt[0];
     $conn=mysql_connect(gl(),glu(),glp());
     $orst=selecteds($conn,glb(),"select SNO,myid,parid,mytitle,level,PTOF,STATUS from coode_plotdetail where plotmark='".$plid."' and mymark='".$thispt[0]."'","utf8","");
     $toto=countresult($orst);
     if ($toto>0){
      if (anyvalue($orst,"myid",0)==($thispt[2]*1) and anyvalue($orst,"parid",0)==($thispt[3]*1) and anyvalue($orst,"mytitle",0)==$thispt[1] and anyvalue($orst,"level",0)==($thispt[4]*1)){
         if ($cfunx!=""){
             $y=anyfunrun($cfunx,_get("appid"),"plotmark=".$plid."&SNO=".anyvalue($orst,"SNO",0),"parid=".$thispt[3]."&myid=".$thispt[2]."&mytitle=".$thispt[1]."&mymark=".$mk."&level=".$thispt[4]);
         }
        $conn=mysql_connect(gl(),glu(),glp());
        $extb=updatingx($conn,glb(),"update coode_plotdetail set CRTM='".$ntime."',UPTM='".$ntime."' where SNO=".anyvalue($orst,"SNO",0),"utf8");
      }else{
         if ($cfunx!=""){
             $y=anyfunrun($cfunx,_get("appid"),"plotmark=".$plid."&SNO=".anyvalue($orst,"SNO",0),"parid=".$thispt[3]."&myid=".$thispt[2]."&mytitle=".$thispt[1]."&mymark=".$mk."&level=".$thispt[4]);
         }
        $conn=mysql_connect(gl(),glu(),glp());
        $extb=updatings($conn,glb(),"UPDATE coode_plotdetail SET UPTM='".$ntime."',myid='".$_POST["myid"]."',parid='".$_POST["parid"]."',mytitle='".$_POST["mytitle"]."',level='".$_POST["level"]."' WHERE SNO=".anyvalue($orst,"SNO",0),"utf8");
      }
     }else{
     }
   };//if
};//for
$conn=mysql_connect(gl(),glu(),glp());
 $xyz=updatingx($conn,glb(),"insert into coode_plotlist(plotmark,CRTOR,CRTM,UPTM,OLMK)select plotmark,'".$_COOKIE["uid"]."',now(),now(),'".onlymark()."' from coode_plotdetail where concat(plotmark,'@') not in(select concat(plotmark,'@') from coode_plotlist) group by plotmark","utf8");
$conn=mysql_connect(gl(),glu(),glp());
$nx=updatingx($conn,glb(),"update coode_shortaffect set UPTM=now() where tablename='coode_plotlist' or tablename='coode_plotdetail'","utf8");
for ($t;$t<$totpc;$t++){
  $conn=mysql_connect(gl(),glu(),glp());
  $nc=updatingx($conn,glb(),"update coode_plotdetail set STATUS='".hou($ptckd[$t],":")."' where mymark='".qian($ptckd[$t],":")."' and plotmark='".$plid."'","utf8");
}
   $conn=mysql_connect(gl(),glu(),glp());
   $zsl=updatings($conn,glb(),"select count(*) as result from coode_plotdetail where plotmark='".$plid."'","utf8");
   $conn=mysql_connect(gl(),glu(),glp());
   $gqsl=updatings($conn,glb(),"select count(*) as result from coode_plotdetail where plotmark='".$plid."' and UPTM<>'".$ntime."'","utf8");
   
   if (($gqsl/$zsl)*100<=25){//  1/4 以下才可以抛弃不然容易删错
    $conn=mysql_connect(gl(),glu(),glp());
    $delmk=onlymark();
    $allkx="plotmark,CRTM,UPTM,level,myid,parid,oriid,mytitle,partitle,orititle,mymark,parmark,orimark,myurl,myclick,CRTOR,mydescrib,PRIME,OLMK,PTOF";
    $throw=updatingx($conn,glb(),"insert into coode_plotdekill(".$allkx.",STCODE)select ".$allkx.",'".$delmk."' from coode_plotdetail where plotmark='".$plid."' and UPTM<>'".$ntime."'","utf8");
    if ($cfunx!=""){
     $y=anyfunrun($cfunx,_get("appid"),"plotmark=".$plid."&delmk=".$delmk."&SNO=".anyvalue($orst,"SNO",0),"parid=".$_POST["parid"]."&myid=".$_POST["myid"]."&mytitle=".$_POST["mytitle"]."&mymark=".$_POST["mymark"]."&level=".$_POST["level"]);
    }
    $conn=mysql_connect(gl(),glu(),glp());
    $delx=updatingx($conn,glb(),"delete  from coode_plotdetail where plotmark='".$plid."' and UPTM<>'".$ntime."'","utf8");
   }
 //$bak=UX("insert into coode_plotmydetail (plotmark,CRTM,UPTM,myid,parid,mymark,mytitle,level,OLMK,STATUS)select concat('BAK".date("YmdHis")."-',plotmark),CRTM,UPTM,myid,parid,mymark,mytitle,level,OLMK,STATUS from coode_plotdetail where plotmark='".$plid."'");
 echo "1";
}else{
   $aa="fromurl,etel,code,askforwhat,askforstr,CRTM,UPTM,OLMK,STATUS,CRTOR,accesstime";  
   $bb="'".$plid."','".$_COOKIE["uid"]."','".$pltt."','plotname','".$plid."',now(),now(),'".onlymark()."',0,'".$_COOKIE["uid"]."',now()";
   $afsps=UX("insert into coode_afspace(".$aa.")values(".$bb.")");
 echo "0";
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>