<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $fnm=$_POST["file_name"];
$nmtp=qian($fnm,".");
$ptnm=explode("_",$nmtp);
if (count($ptnm)==3){
  $rescode=$ptnm[0].".".$ptnm[1];
  $restype=$ptnm[2];
}else{
  $rescode=$ptnm[0];
  $restype=$ptnm[1];
}
$fpp=combineurl(localroot(),"/remotexres/receive/".$restype."/".qian($rescode,".")."/");
$fpb=combineurl(localroot(),"/remotexres/receive/".$restype."/");
$cc=createdir($fpp);
$tmpnm=$_FILES["file_data"]["tmp_name"];
$fpn=combineurl($fpb,$fnm);
$fpn2=combineurl("http://".glw(),"/remotexres/receive/".$restype."/".$fnm);
move_uploaded_file($tmpnm, $fpn);
$zz=unzip($fpn,$fpp);
    switch($restype){
       case "pagex":
       $jsonf0=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-resdata.json");         
       $jsonf1=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-pagedata.json");
       $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $rtitle=$relydata->rtitle;
       $rcode=$relydata->rcode;
       $rtype=$relydata->rtype;         
       break;
       case "tabx":
       $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $rtitle=$relydata->rtitle;
       $rcode=$relydata->rcode;
       $rtype=$relydata->rtype;
       
       break;
       case "formx":
       $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $rtitle=$relydata->rtitle;
       $rcode=$relydata->rcode;
       $rtype=$relydata->rtype;
       break;
       case "plotx":
       $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $rtitle=$relydata->rtitle;
       $rcode=$relydata->rcode;
       $rtype=$relydata->rtype;
       break;
       case "groupx":
       $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);   
       $rtitle=$relydata->rtitle;
       $rcode=$relydata->rcode;
       $rtype=$relydata->rtype;
       break;
       case "dataspacex":
       $relyresurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $rtitle=$relydata->rtitle;
       $rcode=$relydata->rcode;
       $rtype=$relydata->rtype;
       break;
       default:
       $rcode=$rescode;
       $rtype=$restype;
       $rtitle=UX("select restitle as result from coode_sysregres where resmark='".$rcode."' and restype='".$rtype."'");
     }
echo '{"status":"1","message":"'.$rcode.",".$rtype.",".$rtitle.'","url":"'.$fpn2.'"}';
     session_write_close();
?>