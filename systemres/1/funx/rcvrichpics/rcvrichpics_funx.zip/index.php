<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $mypath="/todayfiles/".date("Y-m-d")."/".getRandChar(8);
if ($_COOKIE["uid"]!=""){
  $savepath=combineurl("/localxres/iconsetx/".$_COOKIE["uid"],$mypath);
}else{
  $savepath="";
}
if ($_COOKIE["uid"]!=""){
 $extm=UX("select count(*) as result from coode_iconset where setmark='".$_COOKIE["uid"]."'");
  if (intval($extm)==0){
    $upic=dftval(UX("select headpic as result from coode_userlist where userid='".$_COOKIE["uid"]."'"),"/localxres/iconsetx/18841880246/todayfiles/2023-05-16/QrVG5U/man1.png");
    $sqle="setarea,setmark,imgmark,grppath,outurl,CRTM,UPTM,OLMK,CRTOR";
    $sqlf="'localxres','".$_COOKIE["uid"]."','person','/localxres/iconsetx/".$_COOKIE["uid"]."/','".$upic."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."'";
    $gg=UX("insert into coode_iconset(".$sqle.")values(".$sqlf.")");    
  }
}
$mytitle=dftval($_GET["mytitle"],"");
$mypmd5=substr(md5($mypath),0,16);
$mythex=String2Hex($mytitle);
$grpmark=$mypath;
$gml=localroot();
 $sqlx="tempmark,temptitle,tempdate,grpmark,filefromurl,filehosturl,filelocalurl,filename,filetype,fromhost,CRTM,UPTM,OLMK,STATUS,CRTOR";
 $sqly="'[olmk]','[olmk]','".qian(hou($mypath,"todayfiles/"),"/")."','".$grpmark."','[rmturl]','[hosturl]','[localurl]','[filename]','[filetype]','[fromhost]',now(),now(),'".onlymark()."',1,'".$_COOKIE["uid"]."'";
 $sqlm="imgmark,imgtitle,setmark,stockplace,imgtype,imglcurl,imgrmturl,imghsturl,CRTM,UPTM,OLMK";
 $sqln="'[imgmark]','[imgtitle]','[setmark]','[stockplace]','[imgtype]','[imglcurl]','[imgrmturl]','[imghsturl]',now(),now(),'[olmkx]'";
 $imgtypex="xx,svg,jpg,jpeg,png,gif,bmp,";
$exty=UX("select count(*) as result from coode_todaygrp where grpmark='".$grpmark."'");
if (intval($exty)==0){
  $sqla="grpmark,grptitle,CRTM,UPTM,OLMK,CRTOR";
  $sqlb="'$grpmark','$grpmark',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."'";
  $bz=UX("insert into coode_todaygrp(".$sqla.")values(".$sqlb.")");
}
if ($savepath!=""){
 
    $fx=$_FILES["file"];
    $tmpnmx=$fx["tmp_name"];        
    $fnmx=$fx["name"];
    $fextx=hou($fnmx,".");
    $yy=createdir(combineurl(localroot(),$savepath)); 
    $rpt=combineurl(localroot(),$savepath);  
    $fpn=combineurl($rpt,$fnmx);
    $rmturl=combineurl("http://".glw(),str_replace($gml,"",$fpn));
    $hosturl=combineurl("/",str_replace($gml,"",$fpn));
    move_uploaded_file($tmpnmx, $fpn);  
    $sqlz=$sqly;
    $sqlz=str_replace("[rmturl]",$rmturl,$sqlz);
    $sqlz=str_replace("[fromhost]",killlaststr(glw()),$sqlz);
    $sqlz=str_replace("[hosturl]",$hosturl,$sqlz);
    $sqlz=str_replace("[localurl]",$fpn,$sqlz);
    $sqlz=str_replace("[olmk]",getRandChar(8),$sqlz);
    $sqlz=str_replace("[filename]",$fnmx,$sqlz);
    $sqlz=str_replace("[filetype]",$fextx,$sqlz);
    if (strpos($imgtypex,$fextx)>0){
     $sqlo=$sqln;
     $sqlo=str_replace("[imgmark]",str_replace($fextx,"",$fnmx),$sqlo);
     $sqlo=str_replace("[imgtitle]",$fnmx,$sqlo);
     $sqlo=str_replace("[stockplace]",$savepath,$sqlo);
     $sqlo=str_replace("[setmark]",$_COOKIE["uid"],$sqlo);
     $sqlo=str_replace("[imgtype]",$fextx,$sqlo);
     $sqlo=str_replace("[imglcurl]",$fpn,$sqlo);
     $sqlo=str_replace("[imgrmturl]",$rmturl,$sqlo);
     $sqlo=str_replace("[imghsturl]",$hosturl,$sqlo);
     $sqlo=str_replace("[olmkx]",onlymark(),$sqlo);
     $oo=UX("insert into coode_icons(".$sqlm.")values(".$sqlo.")");
    }
    $zz=UX("insert into coode_todayfiles(".$sqlx.")values(".$sqlz.")");   
    echo '{"status":"1","msg":"上传单文件成功","link":"'.$rmturl.'","redirect":""}';
  }else{
   echo '{"status":"0","msg":"参数不全","redirect":""}';
  }
     session_write_close();
?>