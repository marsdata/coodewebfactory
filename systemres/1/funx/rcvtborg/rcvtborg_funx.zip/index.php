<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $fmknm=$_POST["fmknm"];//关键词名
$fmktt=$_POST["fmktt"];//关键词标题
$fmktp=$_POST["fmktp"];//关键词类型
$fmklen=$_POST["fmklen"];//关键词长度
$fmkstt=$_POST["fmkstt"];//关键词状态
$tbnm=$_POST["tbnm"];//表名
$tbtt=$_POST["tbtt"];//表标题
$ptknm=explode(",",$fmknm);
$totp=count($ptknm);
eval(CLASSX("pinyin"));
if (ischi($tbnm)==1){
 $tbtt=$tbnm;
 $tbnm=$py->utf8_to($tbnm,false);
}else{
}
$ptktt=explode(",",$fmktt);
$ptktp=explode(",",$fmktp);
$ptklen=explode(",",$fmklen);
$ptkstt=explode(",",$fmkstt);
$fmkx="";
$stbnm=$tbnm;
$conn=mysql_connect(gl(),glu(),glp());
$ext0=updatings($conn,glb(),"select count(*) as result from coode_tablist where TABLE_NAME='".$stbnm."'","utf8");
$bb=" SNO int(11) NOT NULL AUTO_INCREMENT,OLMK varchar(100) NOT NULL,CRTOR varchar(100) NOT NULL,CRTM datetime NOT NULL,UPTM datetime NOT NULL,STATUS tinyint(4) NOT NULL,PTOF varchar(100) NOT NULL,PRIME int(11) NOT NULL,";
if ($ext0*1==0 and $tbnm!="" and $fmknm!=""){//不存在的时候才可以新增
$py=new pinyin();
 for ($i=0;$i<$totp-1;$i++){
   if (ischi($ptknm[$i])==1){
    $ptknm[$i]=$py->utf8_to($ptknm[$i],false);
   }else{    
   }
   if ($ptklen[$i]=="0" or $ptklen[$i]==""){
    if ($ptktp[$i]!="decimal"){
      $fmkx=$fmkx.$ptknm[$i]." ".$ptktp[$i]." NOT NULL,";   
    }else{
       $fmkx=$fmkx.$ptknm[$i]." ".$ptktp[$i]."(10,2) NOT NULL,";
    }
   }else{
    $fmkx=$fmkx.$ptknm[$i]." ".$ptktp[$i]."(".$ptklen[$i].") NOT NULL,";
   }
 };
 $cc="CREATE TABLE ".$stbnm."(";
 $dd="PRIMARY KEY (SNO) ) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;";
 $fx=$cc.$bb.$fmkx.$dd;
 $conn=mysql_connect(gl(),glu(),glp());
 //echo $fx."--";
 $z=anyfunrun("askspace","","acls=tablename&astr=".$stbnm,"");
 $x=updatingx($conn,glb(),$fx,"utf8"); 
 $anf=anyfunrun("newframe",_get("appid"),"tablename=".$stbnm,"fmknm=".$fmknm."&fmktt=".$fmktt);
 $conn=mysql_connect(gl(),glu(),glp());
 $exttt=updatings($conn,glb(),"select count(*) as result from coode_keydetailx where TABLE_NAME='".$stbnm."'","utf8"); 
 if ($exttt*1>0){
  $conn=mysql_connect(gl(),glu(),glp());
  $tt=updatings($conn,glb(),"update coode_tablist set tabtitle='".$tbtt."',PTOF='".myfirstpos()."' where TABLE_NAME='".$stbnm."'","utf8");
  $aftval=SX("select TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,keytitle,keyexplain,clstxt,jsshowfun,jspostfun,sysshowfun,syspostfun,dxtype from coode_keydetailx where TABLE_NAME='".$stbnm."' and TABLE_SCHEMA='".glb()."'");
  $bid=onlymark();
  $upmark=getRandChar(6);
  $ntbup=UX("insert into coode_updatetable(schm,tablename,optime,beforefrm,afterfrm,CRTM,CRTOR,UPTM,RIP,billid,upmark)values('".$fbasex."','".$tbnmx."',now(),'".$bfval."','".$aftval."',now(),'".$_COOKIE["uid"]."',now(),'".getip()."','".$bid."','".$upmark."')");
  eval(CLASSX("tablediff"));
  $td=new tablediff();
  $tarr=$td->difftab($bfval,$aftval,$tarr);
  eval(CLASSX("anychange"));
  $ac=new anychange();
  $hrst=SX("select sysid,appid,pagemark from coode_pagesrc where sourceid='".$stbnm."'");
  $toth=countresult($hrst);
   if ($toth>0){
    for ($k=0;$k<$toth;$k++){
     $hatxt=$ac->srcchange($stbnm,"tab",anyvalue($hrst,"sysid",$k),anyvalue($hrst,"appid",$k),anyvalue($hrst,"pagemark",$k),$bid,$tarr);
    }
   }else{
     $hatxt=$ac->srcchange($stbnm,"tab","coode","anyapp","anypage",$bid,$tarr);
   }
  echo "1";
 }else{
  echo "0:run failure";
 }
}else{
 echo "0:lack of var-".$tbnm."-".$fmknm;
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>