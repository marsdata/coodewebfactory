<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tempmark=dftval($_POST["tempmark"],"");
$temptype=dftval($_POST["temptype"],"");
$tinymark=dftval($_POST["tinymark"],"");
$restype=dftval($_POST["restype"],"");
$myid=dftval($_POST["myid"],"");
$parid=dftval($_POST["parid"],"");
$olmk=dftval($_POST["olmk"],"");
$resmark=dftval($_POST["resmark"],"");
$restitle=dftval($_POST["restitle"],"");
$rmturl=dftval($_POST["rmturl"],"");
$jsondata=dftval($_POST["dt"],"");
if ($myid=="0"){
  $extx=UX("select count(*) as result from coode_resjarset where tempmark='".$tempmark."' and OLMK='".$olmk."'");
  if (intval($extx)==0){
    if ($rmturl!=""){
      $kzm=kuozhanming($rmturl);
      $fnm=urlfname($rmturl);
      if ($tinymark==""){
        $rpt=combineurl(localroot(),"/units/".qian($tempmark,".")."/images");
        $bb=downanyfile($rmturl,$rpt."/".$fnm);
        $reslcurl=$rpt."/".$fnm;
      }else{
        $trst=SX("select sysid,appid,layid from coode_tiny where tinymark='".$tinymark."'");
        $sysid=anyvalue($trst,"sysid",0);
        $appid=anyvalue($trst,"appid",0);
        $layid=anyvalue($trst,"layid",0);
        $rpt=combineurl(localroot(),"/SYS/".$sysid."/".$appid."/".$layid."/".$tinymark."/images");
        $bb=downanyfile($rmturl,$rpt."/".$fnm);
        $reslcurl=$rpt."/".$fnm;
      }
    }
    $lastid=UX("select myid as result from coode_resjarset where tempmark='".$tempmark."' and temptype='".$temptype."' and tinymark='".$tinymark."' order by myid desc");
    $sqlx="temptype,tempmark,tinymark,restype,rmark,rtitle,reslocalurl,resrmturl,jsondata,myid,parid,CRTM,UPTM,OLMK";
    $sqly="'$temptype','$tempmark','$tinymark','$restype','$resmark','$restitle','$reslcurl','$rmturl','$jsondata','".($lastid+1)."','".$parid."',now(),now(),'".$olmk."'";
    $zz=UX("insert into coode_resjarset(".$sqlx.")values(".$sqly.")");
  }else{
    $lastid=UX("select myid as result from coode_resjarset where tempmark='".$tempmark."' and temptype='".$temptype."' and tinymark='".$tinymark."' order by myid desc");
    $bb=UX("update coode_resjarset set myid='".($lastid+1)."',rmark='".$resmark."',rtitle='".$restitle."',resrmturl='".$rmturl."',jsondata='".$jsondata."' where tempmark='".$tempmark."' and OLMK='".$olmk."'");
  }
}else{
  $bb=UX("update coode_resjarset set rmark='".$resmark."',rtitle='".$restitle."',resrmturl='".$rmturl."',jsondata='".$jsondata."' where tempmark='".$tempmark."' and OLMK='".$olmk."'");
}
echo makereturnjson("1","操作成功","");
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>