<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $funid=$_GET["funid"];
if (isx2($funid,"SNO:","@")){
    $bid=onlymark();
    $snox=qian(hou($funid,"SNO:"),".");
    $tbnm=qian($funid,"@");
    $keyx=hou($funid,".");
    $txtfull=UX("select ".$keyx." as result from ".$tbnm." where SNO=".$snox);
    $txttxt=tostring($txtfull);
    switch ($tbnm){
        case "coode_updatefile":
            $fpath=tostring(UX("select filepath as result from ".$tbnm." where SNO=".$snox));
            if ($fpath!=""){
             $oldfull=file_get_contents($fpath);    
             $oldtxt=$oldfull;
             $rcvftxt=$txttxt;
             $filepath=$fpath;
             $xz=overfile($fpath,$txttxt);
             $ny=UX("update coode_sitefile set filetext='".tohex($rcvftxt)."' where  updateurl='".$filepath."'"); 
              if ($oldtxt!=$rcvftxt){
               $wjkzm=laststr($filepath,".");
               switch ($wjkzm){
                case "html":
                 eval(CLASSX("htmldiff"));
                 $hd=new htmldiff();
                 $farr=$hd->hdiff($oldtxt,$rcvftxt,$farr); 
                break;
                case "htm":
                 eval(CLASSX("htmldiff"));
                 $hd=new htmldiff();
                 $farr=$hd->hdiff($oldtxt,$rcvftxt,$farr); 
                break;
                case "php":
                 eval(CLASSX("changecount"));
                 $cc=new changecount();
                 $farr=$cc->funchange($oldtxt,$rcvftxt,$farr); 
                break;
                case "js":
                eval(CLASSX("changecount"));
                $cc=new changecount();
                 $farr=$cc->funchange($oldtxt,$rcvftxt,$farr); 
                 break;
                case "css":
               eval(CLASSX("htmldiff"));
                $hd=new htmldiff();
                $farr=$hd->hdiff($oldtxt,$rcvftxt,$farr); 
                break;
                default:
              } 
             eval(CLASSX("anychange"));
             $ac=new anychange();
              $hrst=SX("select sysid,appid,pagemark from coode_pagesrc where sourcecls='file' and sourceid='".$filepath."'");
              $toth=countresult($hrst);
              if ($toth>0){
                for ($k=0;$k<$toth;$k++){
                 $hatxt=$ac->srcchange($filepath,".".$wjkzm,anyvalue($hrst,"sysid",$k),anyvalue($hrst,"appid",$k),anyvalue($hrst,"pagemark",$k),$bid,$farr);
                }
              }else{
               $hatxt=$ac->srcchange($filepath,".".$wjkzm,"coode","anyapp","anypage",$bid,$farr);
              }
              $ctx=UX("select sum(newchara-killchara) as result from coode_pagedevelop where newaction like 'UPDATE%".$filepath."'");
              $zx=UX("update coode_pagesrc set sourcelong='".$ctx."' where sourceid='".$filepath."' and sourcecls='file'");
             }
            }
        break;
        case "coode_updatefun":
            $funname=UX("select funname as result from ".$tbnm." where SNO=".$snox);
            $funname=str_replace("()","",$funname);
            $funname=hou($funname,"fun-");
            $funname=hou($funname,"cls-");
            $fn=$funname;
            if ($funname!=""){
              $oldfull=tostring(UX("select funfull as result from coode_funlist  where funname='".$funname."' or funname='".$funname."()'"));
                if ($oldfull==""){
                   $oldcls=$oldfull=tostring(UX("select funfull as result from coode_phpcls  where funname='".$funname."' or funname='".$funname."()'"));
                   $z=UX("update coode_phpcls set funfull='".$txtfull."' where funname='".$funname."' or funname='".$funname."()'");    
                }else{
                   $z=UX("update coode_funlist set funfull='".$txtfull."' where funname='".$funname."' or funname='".$funname."()'");    
                }
                eval(CLASSX("changecount"));
                $cc=new changecount();
                $farr=$cc->funchange($oldfull,$txttxt,$farr); 
                eval(CLASSX("anychange"));
                $ac=new anychange();
                $hrst=SX("select sysid,appid,pagemark from coode_pagesrc where (sourcecls='fun' or sourcecls='function') and sourceid='".$fn."'");
                $toth=countresult($hrst);
                if ($toth>0){
                  for ($k=0;$k<$toth;$k++){
                     if ($oldcls==""){
                      $hatxt=$ac->srcchange($fn,"function",anyvalue($hrst,"sysid",$k),anyvalue($hrst,"appid",$k),anyvalue($hrst,"pagemark",$k),$bid,$farr);
                     }else{
                      $hatxt=$ac->srcchange($fn,"funcls",anyvalue($hrst,"sysid",$k),anyvalue($hrst,"appid",$k),anyvalue($hrst,"pagemark",$k),$bid,$farr);     
                     }
                  }
                }else{ 
                    if ($oldcls==""){
                      $hatxt=$ac->srcchange($fn,"function","coode","anyapp","anypage",$bid,$farr);
                    }else{
                      $hatxt=$ac->srcchange($fn,"funcls","coode","anyapp","anypage",$bid,$farr);
                    }
                }
                if ($oldcls==""){
                 $ctx=UX("select sum(newchara-killchara) as result from coode_pagedevelop where newaction='UPDATEfunction-".$fn."'");
                 $zx=UX("update coode_pagesrc set sourcelong='".$ctx."' where sourceid='".$fn."' and (sourcecls='function' or sourcecls='fun')");
                }else{
                 $ctx=UX("select sum(newchara-killchara) as result from coode_pagedevelop where newaction='UPDATEfuncls-".$fn."'");
                 $zx=UX("update coode_pagesrc set sourcelong='".$ctx."' where sourceid='".$fn."' and (sourcecls='cls' or sourcecls='class')");
                }
              }
           break;
           default:
             $fpath=tostring(UX("select filepath as result from ".$tbnm." where SNO=".$snox));
            if ($fpath!=""){
             $oldfull=file_get_contents($fpath);    
             $oldtxt=$oldfull;
             $rcvftxt=$txttxt;
             $filepath=$fpath;
             $xz=overfile($fpath,$txttxt);
             $ny=UX("update coode_sitefile set filetext='".tohex($rcvftxt)."' where  updateurl='".$filepath."'"); 
              if ($oldtxt!=$rcvftxt){
               $wjkzm=laststr($filepath,".");
               switch ($wjkzm){
                case "html":
                 eval(CLASSX("htmldiff"));
                 $hd=new htmldiff();
                 $farr=$hd->hdiff($oldtxt,$rcvftxt,$farr); 
                break;
                case "htm":
                 eval(CLASSX("htmldiff"));
                 $hd=new htmldiff();
                 $farr=$hd->hdiff($oldtxt,$rcvftxt,$farr); 
                break;
                case "php":
                 eval(CLASSX("changecount"));
                 $cc=new changecount();
                 $farr=$cc->funchange($oldtxt,$rcvftxt,$farr); 
                break;
                case "js":
                eval(CLASSX("changecount"));
                $cc=new changecount();
                 $farr=$cc->funchange($oldtxt,$rcvftxt,$farr); 
                 break;
                case "css":
               eval(CLASSX("htmldiff"));
                $hd=new htmldiff();
                $farr=$hd->hdiff($oldtxt,$rcvftxt,$farr); 
                break;
                default:
              } 
             eval(CLASSX("anychange"));
             $ac=new anychange();
              $hrst=SX("select sysid,appid,pagemark from coode_pagesrc where sourcecls='file' and sourceid='".$filepath."'");
              $toth=countresult($hrst);
              if ($toth>0){
                for ($k=0;$k<$toth;$k++){
                 $hatxt=$ac->srcchange($filepath,".".$wjkzm,anyvalue($hrst,"sysid",$k),anyvalue($hrst,"appid",$k),anyvalue($hrst,"pagemark",$k),$bid,$farr);
                }
              }else{
               $hatxt=$ac->srcchange($filepath,".".$wjkzm,"coode","anyapp","anypage",$bid,$farr);
              }
              $ctx=UX("select sum(newchara-killchara) as result from coode_pagedevelop where newaction like 'UPDATE%".$filepath."'");
              $zx=UX("update coode_pagesrc set sourcelong='".$ctx."' where sourceid='".$filepath."' and sourcecls='file'");
             }
            }
    }
  echo "1";
}else{
  echo "0";
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>