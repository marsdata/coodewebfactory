<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sno=_get("sno");
$rst=SX("select TABLE_NAME,TABLE_SCHEMA,COLUMN_NAME,bfist,aftist,bfupd,aftupd,bfdel,aftdel from coode_keydetailx where SNO=".$sno);
$totr=countresult($rst);
if (intval($totr)>0){
    $tbnm=anyvalue($rst,"TABLE_NAME",0);
    $schm=anyvalue($rst,"TABLE_SCHEMA",0);
    $colm=anyvalue($rst,"COLUMN_NAME",0);
    $rrst=SX("select TABLE_NAME,TABLE_SCHEMA,COLUMN_NAME,bfist,aftist,bfupd,aftupd,bfdel,aftdel from coode_keydetaily where shortid='".$tbnm."' and COLUMN_NAME='".$colm."' and TABLE_SCHEMA='".$schm."'");    
    $totrr=countresult($rrst);
     if ($totrr>0){
      $bfist=anyvalue($rrst,"bfist",0);
      $aftist=anyvalue($rrst,"aftist",0);
      $bfupd=anyvalue($rrst,"bfupd",0);
      $aftupd=anyvalue($rrst,"aftupd",0);
      $bfdel=anyvalue($rrst,"bfdel",0);
      $aftdel=anyvalue($rrst,"aftdel",0);
      $x=UX("update coode_keydetailx set PRIME=0,bfist='".$bfist."',aftist='".$aftist."',bfupd='".$bfupd."',aftupd='".$aftupd."',bfdel='".$bfdel."',aftdel='".$aftdel."' where SNO=".$sno);      
      echo "1";
     }else{
      echo "0";
     }
}else{
    echo "0";
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>