<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $namex="files";
$ducode=dftval(str_replace("\\","/",$_GET["mycode"]),"");
$mycode=qian($ducode,".");
if ($mycode!=""){
 if (count($_FILES[$namex])==1){
    $tmpnm=$_FILES[$namex]["tmp_name"];
    $fnm=$_FILES[$namex]["name"];
    $fext=hou($fnm,".");
    $tmptp=$_FILES[$namex]["type"];
    $tmperr=$_FILES[$namex]["error"];
    $fpn=combineurl(localroot(),"/localxres/tempx/".$mycode."/images/".$fpn);
    $cc=createdir(combineurl(localroot(),"/localxres/tempx/".$mycode."/images/"));
    $hosturl=combineurl("http://".glw(),str_replace(localroot(),"",$fpn));
    $xdurl="/localxres/tempx/".$mycode."/images/".$fpn;
    $fmd5=md5_file($fpn);
    move_uploaded_file($tmpnm, $fpn);
    $sqlx="taskcode,pictitle,picurl,piclocal,pictype,picsno,picmd5,fileurl,CRTM,UPTM,OLMK";
    $sqly="'$ducode','$fnm','$xdurl','$fpn','$fext',1,'$fmd5','$hosturl',now(),now(),'".onlymark()."'";
    $zz=UX("insert into outsource_devepics(".$sqlx.")values(".$sqly.")");
    echo '{"status":"1","msg":"上传单文件成功","redirect":""}';
  }else{  
    $ufiles=$_FILES[$namex];  
    for ($p=0;$p<count($_FILES[$namex]);$p++){     
     $fnm=$ufiles["name"][$p];
     if ($fnm!=""){
        $tmpnm=$ufiles["tmp_name"][$p];
        $fext=hou($fnm,".");
        $tmptp=$ufiles["type"][$p];
        $tmperr=$ufiles["error"][$p];    
        $fpn=combineurl(localroot(),"/localxres/tempx/".$mycode."/images/".$fnm);
        $cc=createdir(combineurl(localroot(),"/localxres/tempx/".$mycode."/images/"));
        $hosturl=combineurl("http://".glw(),str_replace(localroot(),"",$fpn));
        $xdurl="/localxres/tempx/".$mycode."/images/".$fnm;
        move_uploaded_file($tmpnm, $fpn);
        $fmd5=md5_file($fpn);
        $sqlx="taskcode,pictitle,picurl,piclocal,pictype,picsno,picmd5,fileurl,CRTM,UPTM,OLMK";
        $sqly="'$ducode','$fnm','$xdurl','$fpn','$fext','$p','$fmd5','$hosturl',now(),now(),'".onlymark()."'";
        $zz=UX("insert into outsource_devepics(".$sqlx.")values(".$sqly.")");
     }//fnm
    }//for
    echo '{"status":"1","msg":"上传多文件成功","redirect":""}';
   }  
}else{
   echo '{"status":"0","msg":"参数不全","redirect":""}';
}
     session_write_close();
?>