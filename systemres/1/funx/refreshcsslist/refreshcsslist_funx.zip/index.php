<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $ddd="/localxres/csspagex";
$dir = combineurl(localroot(),$ddd);  //要获取的目录
$k=0;
$a=time();
//$fpath=cinbineurl(localroot(),$ddd);
//$kk=delFileUnderDir($fpath);
$a=time();
$thisurl=combineurl("http://".glw(),"/localxres/funx/anyshort/?stid=5plHV1");
$bktxt=file_get_contents($thisurl);
$jdata=json_decode($bktxt,false);
$fmall="xx./";
$vls=$jdata->vls;
for ($j=0;$j<count($vls);$j++){
  $fcid=$vls[$j]->faceid;
  $fmall=$fmall.$fcid."/";
}
if (is_dir($dir)){
   if ($dh = opendir($dir)){
           while (($file[$k] = readdir($dh) )!= false){
            if ( $file[$k]!="."  and $file[$k]!=".."){
              $filePath[$k] = $dir."/".$file[$k];
              $fsize[$k]=0;             
              $fctime[$k]=date("Y-m-d H:i:s");
              $futime[$k]=date("Y-m-d H:i:s");
              $fhash[$k]="";
              $filenm[$k] = $file[$k];    
            $k=$k+1;
          };//iffilek          
         };//whilefilek
      closedir($dh);
    };//iffdh
};//if isdir
$tmp=0;
for ($t=0;$t<$k;$t++){  
     if (strpos($filenm[$t],".")>0){
       $kk=unlink(combineurl($dir."/",$filenm[$t]));
     }else{
      if (strpos($fmall,$filenm[$t])<=0){
       $x="faceid,sysid,facetype,faceurl,facetitle,facedescribe,CRTM,UPTM,OLMK,CRTOR";
       $y="'".$filenm[$t]."','1','','/localxres/csspagex/".$filenm[$t]."/index.html','/localxres/csspagex/".$filenm[$t]."','',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."'";
       $z=UX("insert into coode_facelist(".$x.")values(".$y.")");     
       $tmp=$tmp+1;
      }
       
    }
}
$z=UX("update coode_facelist set UPTM=now() where ',,".$fmall."' like concat('%,',faceid,',%')");
 $kkk=UX("delete from coode_facelist where timestampdiff(minute,UPTM,now())>30");
$b=time();
echo makereturnjson("1","分析成功--耗时".($b-$a)."获取到".$tmp."个","");
     session_write_close();
?>