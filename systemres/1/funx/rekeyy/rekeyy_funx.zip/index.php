<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $kk=UX("delete from coode_dbshort");
$zz=UX("insert into coode_dbshort(catalog,tabnick)select shortid,shortid from coode_keydetaily where TABLE_SCHEMA!='".glb()."' group by shortid");
$k2=UX("delete from coode_keydetaily where TABLE_SCHEMA='".glb()."' and shortid in (select tabnick from coode_dbshort)");
$zzz=UX("update coode_keydetaily set TABLE_SCHEMA='".glb()."'");
$kk=UX("delete from coode_dbshort");
$zz=UX("insert into coode_dbshort(catalog,tabnick)select TABLE_NAME,TABLE_NAME from coode_keydetailx where TABLE_SCHEMA!='".glb()."' group by TABLE_NAME");
$k2=UX("delete from coode_keydetailx where TABLE_SCHEMA='".glb()."' and TABLE_NAME in (select tabnick from coode_dbshort)");
$zzz=UX("update coode_keydetailx set TABLE_SCHEMA='".glb()."'");
echo makereturnjson("1","重置成功","");
       session_write_close();
?>