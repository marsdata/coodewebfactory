<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $a=time();
 $rst=SX("select SNO,resmark,restype from coode_sysregres where STATUS=0 order by SNO ");
 $totr=countresult($rst);
 for ($j=0;$j<$totr;$j++){
   $snox=anyvalue($rst,"SNO",$j);
   $resmark=anyvalue($rst,"resmark",$j);
   $restype=anyvalue($rst,"restype",$j);
   switch($restype){
    case "pagex":
     $filepath=combineurl(localroot(),"/localxres/pagex/seedx/".$resmark."/".$resmark."_".$restype.".zip");
    break;
    case "tempx":
     $filepath=combineurl(localroot(),"/localxres/tempx/".qian($resmark,".")."/".qian($resmark,".")."_".$restype.".zip");
    break;
    case "cdtrdrx":
    $$filepath=combineurl(localroot(),"/localxres/cdtrdrx/".qian($resmark,".")."/".qian($resmark,".")."_".$restype.".zip");
    break;
    default:
     $filepath=combineurl(localroot(),"/localxres/".$restype."/".$resmark."/".$resmark."_".$restype.".zip");
   }
   $fmd5=md5_file($filepath);
   $zz=UX("update coode_sysregres set STATUS=1,vermd5='".$fmd5."' where SNO=".$snox);
 }
 $b=time();
 echo makereturnjson("1","操作完成，耗时：".($b-$a),"");
     session_write_close();
?>