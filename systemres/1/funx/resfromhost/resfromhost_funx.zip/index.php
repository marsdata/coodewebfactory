<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
          $kk=UX("delete from coode_syshostres");   
   $kk=UX("delete from coode_hostregres");
   $nn=anyfunrun("retabsno","","tabnm=coode_hostregres","");
   $nn=anyfunrun("retabsno","","tabnm=coode_syshostres","");
   $ss=UX("update coode_sysregres set coode_sysregres.mtmd5=''");
   echo makereturnjson("1","全部清理-成功","");
       session_write_close();
?>