<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       eval(RESFUNSET("plotfun"));
$plotmark="resmenux";
$plottitle="资源菜单";
$zz=newplot($plotmark,$plottitle);
$zz1=UX("delete from coode_plotdetail where plotmark='".$plotmark."'");
$nn=anyfunrun("retabsno","","tabnm=coode_plotdetail","");
$sqla="plotmark,level,myid,parid,mymark,parmark,mytitle,myurl,withface,fontshow,mydescrib,rescode,fontname,CRTM,UPTM,OLMK";
$sqlb="'".$plotmark."',0,numx+1,-1,restypecode,'',restypetitle,'javascript:void(0)',midpic,headpic,typedescrib,relyotherres,'',now(),now(),md5(RAND())";
$zzz=UX("insert into coode_plotdetail(".$sqla.")select ".$sqlb." from coode_sysrestypedefine");
$sqld="'".$plotmark."',1,SNO+26,0,mncode,restype,mntitle,vurl,'','','','',sqx,now(),now(),md5(RAND())";
$zzz2=UX("insert into coode_plotdetail(".$sqla.")select ".$sqld." from coode_resmenu");
$zz0=UX("update coode_plotdetail,coode_sysrestypedefine set coode_plotdetail.parid=coode_sysrestypedefine.numx+1 where coode_plotdetail.parmark=coode_sysrestypedefine.restypecode and coode_plotdetail.plotmark='".$plotmark."'");
echo makereturnjson("1","将资源菜单转成节点成功","");
       session_write_close();
?>