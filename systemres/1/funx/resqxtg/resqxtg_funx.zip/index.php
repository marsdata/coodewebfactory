<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $rescode=dftval($_GET["rescode"],"");
$restype=dftval($_GET["restype"],"");
if (es($rescode)*es($restype)==1 ){  
  $resname="";
  $extx=UX("select count(*) as result from coode_devespace where restype='".$restype."' and rescode='".$rescode."'");
  if (intval($extx)==0){  
   $sqlx="acccode,restype,rescode,restitle,resarea,fromip,fromhost,askman,CRTM,UPTM,OLMK,STATUS,OPRT";
   $sqly="'$acode','$restype','$rescode','$resname','".glm()."','','".$_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"]."','".$_COOKIE["uid"]."',now(),now(),'".onlymark()."',1,-1";
   $zz=UX("insert into coode_devespace(".$sqlx.")values(".$sqly.")");
  }else{
    $zz=UX("update coode_devespace set STATUS=1,OPRT=-1 where restype='".$restype."' and rescode='".$rescode."'");
  } 
}else{
  echo makereturnjson("0","参数不全","");
}
     session_write_close();
?>