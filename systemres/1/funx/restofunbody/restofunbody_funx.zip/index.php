<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $restype=_get("restype");
$rescode=_get("rescode");
$fbcode=_get("fbcode");
if (es($restype)*es($rescode)*es($fbcode)==1){
 switch($restype){
  case "tempx":
  $extx0=UX("select count(*) as result from coode_fbdu where dumark='".$rescode."' and fbcode='".$fbcode."'");
  if (intval($extx0)==0){
    $sqlx="sysid,relyface,unittitle,unitclass,funcls,frmexp,darela,colora,unitmark,domainmark,dumark,unitdescrib,outurl,pagehtml,vermd5,industry,business,matter,casecode,cssfilex,stylex,scriptx,jsfilex,cssfiley,jsfiley,styley,scripty,containsub,width,height,inwidth,inheight,templatecode,demoresult,pagesurround,subvermd5,copyrightmark,OLMK,UPTM,CRTM,STATUS";
    $zz=UX("insert into coode_fbdu(fbcode,".$sqlx.")select '".$fbcode."',".$sqlx." from coode_domainunit where dumark='".$rescode."'");
  }
  break;
  case "tabx":
  $extx0=UX("select count(*) as result from coode_fbtabdefine where tabnick='".$rescode."' and fbcode='".$fbcode."'");
  if (intval($extx0)==0){
   $sqlx="tabnick,rescode,imghead,worldmarks,restpcode,resenword,reschiword,allkeys,mainsqx,subsqx,olmkkey,areakey,md5key,createsql,contentkeys,jsonconts,keynames,keytpnms,jsontpnms,srckey,srcttk,parreskey,aitkey,aivkey,issys,ispmiss,tabtitle,tabtype,tabcls,sysid,keylens,sizetype,grpmark,vermd5,hasshort,beforeview,ickey,iwkey,copyrightmark,STATUS,OLMK,CRTM,UPTM";
   $sqly="TABLE_NAME,rescode,imghead,worldmarks,restpcode,resenword,reschiword,allkeys,mainsqx,subsqx,olmkkey,areakey,md5key,createsql,contentkeys,jsonconts,keynames,keytpnms,jsontpnms,srckey,srcttk,parreskey,aitkey,aivkey,issys,ispmiss,tabtitle,tabtype,tabcls,sysid,keylens,sizetype,grpmark,vermd5,hasshort,beforeview,ickey,iwkey,copyrightmark,STATUS,OLMK,CRTM,UPTM";
   $zz=UX("insert into coode_fbtabdefine(fbcode,".$sqlx.")select '".$fbcode."',".$sqly." from coode_tablist where TABLE_NAME='".$rescode."'");   
   $cc=UX("update coode_fbtabdefine set createsql=replace(createsql,tabnick,'[tabnick]')");
   $sqlc="tabnick,acthtml,aftdel,aftist,aftupd,appid,atnhtml,bfdel,bfist,bfupd,changeable,CHARACTER_MAXIMUM_LENGTH,CHARACTER_OCTET_LENGTH,CHARACTER_SET_NAME,classp,clstxt,COLLATION_NAME,COLUMN_COMMENT,COLUMN_DEFAULT,COLUMN_KEY,COLUMN_NAME,COLUMN_TYPE,CRTM,CRTOR,DATA_TYPE,DATETIME_PRECISION,displayed,dxtype,EXTRA,isfixed,IS_NULLABLE,jspostfun,jsshowfun,keyexplain,keytitle,NUMERIC_PRECISION,NUMERIC_SCALE,OLMK,ORDINAL_POSITION,parallelto,PRIME,PRIVILEGES,PTOF,rescode,RIP,shortid,SQX,STATUS,STCODE,sysid,syspostfun,sysshowfun,TABLE_CATALOG,TABLE_SCHEMA,tdcode,tdomain,tgroup,thcode,UPTM,valuezero,vermd5,VQX,VRT";
   $sqld="TABLE_NAME,acthtml,aftdel,aftist,aftupd,appid,atnhtml,bfdel,bfist,bfupd,changeable,CHARACTER_MAXIMUM_LENGTH,CHARACTER_OCTET_LENGTH,CHARACTER_SET_NAME,classp,clstxt,COLLATION_NAME,COLUMN_COMMENT,COLUMN_DEFAULT,COLUMN_KEY,COLUMN_NAME,COLUMN_TYPE,CRTM,CRTOR,DATA_TYPE,DATETIME_PRECISION,displayed,dxtype,EXTRA,isfixed,IS_NULLABLE,jspostfun,jsshowfun,keyexplain,keytitle,NUMERIC_PRECISION,NUMERIC_SCALE,OLMK,ORDINAL_POSITION,parallelto,PRIME,PRIVILEGES,PTOF,rescode,RIP,shortid,SQX,STATUS,STCODE,sysid,syspostfun,sysshowfun,TABLE_CATALOG,TABLE_SCHEMA,tdcode,tdomain,tgroup,thcode,UPTM,valuezero,vermd5,VQX,VRT";
   $zz2=UX("insert into coode_fbkeydx(fbcode,".$sqlc.")select '".$fbcode."',".$sqld." from coode_keydetailx where TABLE_NAME='".$rescode."'");
  }
  break;
  case "formx":
  $extx0=UX("select count(*) as result from coode_fbform where shortid='".$rescode."' and fbcode='".$fbcode."'");
  if (intval($extx0)==0){
    $sqlx="tabnick,shortid,shorttitle,datahost,sysid,retrievekey,caseid,caseext,detailid,detailext,tablename,vermd5,allkeys,showkeys,skeys,frmexp,sqlbody,cdt,extc,orddt,lang,dttp,jsonid,keyitem,issys,fileurl,addtitle,addpage,heightx,widthx,fixed,lastvisit,tabcls,schm,OLMK,UPTM,CRTM";
    $zz=UX("insert into coode_fbform(fbcode,".$sqlx.")select '".$fbcode."',".$sqlx." from coode_shortdata where shortid='".$rescode."'");    
    $zz1=UX("update coode_fbform set tabnick=tablename");
    $sqlc="shortid,tabnick,acthtml,aftdel,aftist,aftupd,appid,atnhtml,bfdel,bfist,bfupd,changeable,CHARACTER_MAXIMUM_LENGTH,CHARACTER_OCTET_LENGTH,CHARACTER_SET_NAME,classp,clstxt,COLLATION_NAME,COLUMN_COMMENT,COLUMN_DEFAULT,COLUMN_KEY,COLUMN_NAME,COLUMN_TYPE,CRTM,CRTOR,DATA_TYPE,DATETIME_PRECISION,displayed,dxtype,EXTRA,isfixed,IS_NULLABLE,jspostfun,jsshowfun,keyexplain,keytitle,NUMERIC_PRECISION,NUMERIC_SCALE,OLMK,ORDINAL_POSITION,parallelto,PRIME,PRIVILEGES,PTOF,rescode,RIP,SQX,STATUS,STCODE,sysid,syspostfun,sysshowfun,TABLE_CATALOG,TABLE_SCHEMA,tdcode,tdomain,thcode,UPTM,valuezero,vermd5,VQX,VRT";
    $sqld="shortid,TABLE_NAME,acthtml,aftdel,aftist,aftupd,appid,atnhtml,bfdel,bfist,bfupd,changeable,CHARACTER_MAXIMUM_LENGTH,CHARACTER_OCTET_LENGTH,CHARACTER_SET_NAME,classp,clstxt,COLLATION_NAME,COLUMN_COMMENT,COLUMN_DEFAULT,COLUMN_KEY,COLUMN_NAME,COLUMN_TYPE,CRTM,CRTOR,DATA_TYPE,DATETIME_PRECISION,displayed,dxtype,EXTRA,isfixed,IS_NULLABLE,jspostfun,jsshowfun,keyexplain,keytitle,NUMERIC_PRECISION,NUMERIC_SCALE,OLMK,ORDINAL_POSITION,parallelto,PRIME,PRIVILEGES,PTOF,rescode,RIP,SQX,STATUS,STCODE,sysid,syspostfun,sysshowfun,TABLE_CATALOG,TABLE_SCHEMA,tdcode,tdomain,thcode,UPTM,valuezero,vermd5,VQX,VRT";
    $zz2=UX("insert into coode_fbkeydy(fbcode,".$sqlc.")select '".$fbcode."',".$sqld." from coode_keydetaily where shortid='".$rescode."'");    
  }
  break;
  case "funx":
  $extx0=UX("select count(*) as result from coode_fbfunx where funname='".$rescode."' and fbcode='".$fbcode."'");
  if (intval($extx0)==0){
    $sqlx="sysid,vers,vermd5,usearea,funname,funcname,industry,business,matter,imhead,funtype,funcls,funkey,fkeys,qrytest,formtest,parallelto,CRTM,UPTM,funbody,afffuns,affclss,afftabs,funfull,oldfull,lastfull,filelcpath,isdb,isfile,lang,istemp,issys,isiden,ispmiss,syn,fileurl,copyrightmark,relycore,linex,allcharas,OLMK,STATUS";
    $zz=UX("insert into coode_fbfunx(fbcode,".$sqlx.")select '".$fbcode."',".$sqlx." from coode_funlist where funname='".$rescode."'");
  }
  break;
  case "sfunx":
  $extx0=UX("select count(*) as result from coode_fbsfunx where setname='".$rescode."' and fbcode='".$fbcode."'");
  if (intval($extx0)==0){
    $sqlx="sysid,vers,vermd5,usearea,setname,setcname,restype,rescode,funnames,qrytest,funbody,afffuns,affclss,afftabs,funfull,oldfull,lastfull,filelcpath,isdb,isfile,lang,istemp,issys,isiden,ispmiss,fileurl,OLMK,CRTOR,STATUS";
    $zz=UX("insert into coode_fbsfunx(fbcode,".$sqlx.")select '".$fbcode."',".$sqlx." from coode_funsetfile where setname='".$rescode."'");
  }
  break;
  case "layx":  
  $extx0=UX("select count(*) as result from coode_fblay where layid='".$rescode."' and fbcode='".$fbcode."'");
  if (intval($extx0)==0){
    $sqlx="sysid,appid,layid,laytitle,pagelay,CRTM,CRTOR,OLMK,STATUS,UPTM,mobilelay,pageurl,mobileurl,pshortid,mshortid,pagemd5,vermd5,colora";
    $zz=UX("insert into coode_fblay(fbcode,".$sqlx.")select '".$fbcode."',".$sqlx." from coode_applay where layid='".$rescode."'");
  }
  break;
  case "pagex":
  $extx0=UX("select count(*) as result from coode_fbpagex where tinymark='".$rescode."' and fbcode='".$fbcode."'");
  if (intval($extx0)==0){
    $sqlx="appid,auditmd5,catalog,colora,colorb,CRTM,CRTOR,imghead,ismbl,ispmiss,layid,laypath,longexp,OLMK,pagecls,PRIME,PTOF,RIP,schm,shortid,STATUS,STCODE,sysid,tabname,tabnick,tempid,tinymark,tinytitle,UPTM,vermd5,VRT";
    $zz=UX("insert into coode_fbpagex(fbcode,".$sqlx.")select '".$fbcode."',".$sqlx." from coode_tiny where tinymark='".$rescode."'");    
  }
  break;
  default: 
 }
 $ss=UX("update coode_fbinstres,coode_sysregres set coode_fbinstres.restitle=coode_sysregres.restitle where  coode_fbinstres.rescode=coode_sysregres.resmark and  coode_fbinstres.restype=coode_sysregres.restype ");
 if (intval($extx0)==0){
  echo makereturnjson("1","转化到功能复合体成功","");
 }else{
  echo makereturnjson("0","转化到功能复合体失败，已存在","");
 }
}else{
 echo makereturnjson("0","转化到功能复合体失败，缺少参数","");
}
       session_write_close();
?>