<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tabnm=_get("tabnm");
$lktab=$tabnm."_wait";
$trst=SX("select TABLE_NAME,mainsqx,allkeys from coode_tablist where TABLE_NAME='".$tabnm."'");
$msqx=anyvalue($trst,"mainsqx",0);
$akeyx=anyvalue($trst,"allkeys",0);
$bkeyx=hou($akeyx,"|");
if ($msqx!=""){
  $ckeyx=str_replace($msqx.",","",$bkeyx);  
  $conn=mysql_connect(gl(),glu(),glp());
  $zz=updatingx($conn,glb(),"create table ".$lktab." like ".$tabnm,"utf8");
  $cc=UX("insert into ".$lktab."(".$ckeyx.")select ".$ckeyx." from ".$tabnm);
  $conn=mysql_connect(gl(),glu(),glp());
  $zz=updatingx($conn,glb(),"rename table ".$tabnm." to ".$tabnm."_oldx","utf8");
  $conn=mysql_connect(gl(),glu(),glp());
  $zz=updatingx($conn,glb(),"rename table ".$lktab." to ".$tabnm,"utf8");
  $conn=mysql_connect(gl(),glu(),glp());
  $zz=updatingx($conn,glb(),"drop table if exists ".$tabnm."_oldx","utf8");
  echo makereturnjson("1","重置序号成功","");  
}else{
  echo makereturnjson("0","重置序号失败","");
}
     session_write_close();
?>