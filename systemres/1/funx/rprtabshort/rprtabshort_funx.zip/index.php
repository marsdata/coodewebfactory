<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snox=dftval($_GET["SNO"],"");
eval(RESFUNSET("tabbaseinfo"));
$crst=SX("select dbmark,dbtabnm,createsql,thiskeys from coode_clientdataplan where SNO=".$snox);
$dmark=anyvalue($crst,"dbmark",0);
$dtabnm=anyvalue($crst,"dbtabnm",0);
$csql=anyvalue($crst,"createsql",0);
$tkeys=anyvalue($crst,"thiskeys",0);
$dinfo=array();
$dinfo=takedbinfo($dmark,$dtabnm,$dinfo);
$dbnm=$dinfo["dbnm"];
$fip=$dinfo["fip"];
$fuser=$dinfo["fuser"];
$fpass=$dinfo["fpass"];
$fbase=$dinfo["fbase"];
if (extdbtab($fip,$fuser,$fpass,$fbase,$dtabnm)){
}else{
  $conn=mysql_connect($fip,$fuser,$fpass);
  $zz=updatingx($conn,$dbnm,$csql,"utf8");
}
if ($dmark=="thishostcore" or $dmark==""){
   $extst=UX("select count(*) as result from coode_shortdata where showkeys='".$tkeys."' and dttp='json' and tablename='".$dtabnm."' and orddt=''");
   if (intval($extst)==0){
     $stidx=getRandChar(6);
     $sqlx="shortid,tablename,showkeys,skeys,CRTM,UPTM,cdt,orddt,dttp,caseid,detailid,OLMK,CRTOR";
     $sqly="'$stidx','$dtabnm','$tkeys','',now(),now(),'','','json','layuitable.index','layuiform.index','".onlymark()."','".$_COOKIE["uid"]."'";
     $zz=UX("insert into coode_shortdata(".$sqlx.")values(".$sqly.")");        
   }else{
     $stidx=UX("select shortid as result from coode_shortdata where showkeys='".$tkeys."' and dttp='json' and tablename='".$dtabnm."' and orddt=''");
   }
   $zz=UX("update coode_clientdataplan set shortid='".$stidx."' where  shortid='' and SNO=".$snox);
}else{
   $extst=UX("select count(*) as result from coode_dbshort where showkeys='".$tkeys."' and dttp='json' and tablename='".$dtabnm."' and orddt=''");
   if (intval($extst)==0){
       $stidx=getRandChar(6);
       $conn=mysql_connect($fip,$fuser,$fpass);
       $sqlx="schm,shortid,tablename,showkeys,skeys,CRTM,UPTM,cdt,orddt,dttp,caseid,detailid,OLMK,CRTOR";
       $sqly="'$dbnm','$stidx','$dtabnm','$tkeys','',now(),now(),'','','json','layuitable.index','layuiform.index','".onlymark()."','".$_COOKIE["uid"]."'";
       $zz=updatingx($conn,$dbnm,"insert into coode_dbshort(".$sqlx.")values(".$sqly.")","utf8");
   }else{
      $stidx=UX("select shortid as result from coode_dbshort where showkeys='".$tkeys."' and dttp='json' and tablename='".$dtabnm."' and orddt=''");    
   }
   $zz=UX("update coode_clientdataplan set shortid='".$stidx."' where shortid='' and SNO=".$snox);
}
echo makereturnjson("1","修复表单成功","");
     session_write_close();
?>