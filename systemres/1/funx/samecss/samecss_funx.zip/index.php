<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $dumark=_get("dumark");
$unittitle=_get("unittitle");
$vermd5=_get("vermd5");
$extx=UX("select count(*) as result from coode_hosttemps where rescode='".$dumark."'");
if (intval($extx)==0){
  $sqlx="rescode,restype,fromhost,restitle,CRTM,UPTM,OLMK";
  $sqly="'$dumark','tempx','".glm()."','$unittitle',now(),now(),'".onlymark()."'";
  $zz=UX("insert into coode_hosttemps(".$sqlx.")values(".$sqly.")");
}else{
  $zz=UX("update coode_hosttemps set restitle='".$unittitle."',hostmd5='".$vermd5."' where rescode='".$dumark."'");
}
echo makereturnjson("1","增加或修改成功","");
     session_write_close();
?>