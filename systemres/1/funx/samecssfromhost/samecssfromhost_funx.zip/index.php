<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $lastsno=UX("select posno as result from coode_cssthis order by posno desc");
$jurl=combineurl("http://".glm(),"/localxres/funx/anyshort/?stid=Vzd9UJ&lastsno=".$lastsno);
$jsonx=file_get_contents($jurl);
$dbmark="thishostcore";
$tabnmx="coode_cssthis";
$olkeyx="OLMK";
$jsonkeys="SNO,rescode,restype,fromhost,reshead,downurl,restitle,resdescrib,vermd5,indexurl,STATUS,STCODE,OLMK,OPRT";
$tabkeys="posno,rescode,restype,fromhost,reshead,downurl,restitle,resdescrib,vermd5,indexurl,STATUS,STCODE,OLMK,OPRT";
$zz=jdatatotab($jsonx,$dbmark,$tabnmx,$olkeyx,$jsonkeys,$tabkeys);
$zzx=UX("update coode_cssthis set isin=1 where restype='tempx' and rescode in(select dumark from coode_domainunit)");
$zzy=UX("update coode_cssthis set isin=1 where restype='csspagex' and rescode in(select faceid from coode_facelist)");
$zzy=UX("update coode_cssthis set isin=1 where restype='pagex' and rescode in(select tinyid from coode_unittiny)");
$zzz=UX("update coode_cssthis,coode_facelist set coode_facelist.facetitle=coode_cssthis.restitle where coode_cssthis.rescode=coode_facelist.faceid");
$totnin=UX("select count(*) as result from coode_cssthis where isin=0");
if (intval($totnin)>0){
 $rdru="/localxres/tempx/multicmdrun/index.html?method=samecssfromhs&way=quick";
 echo makereturnjson("1","下载成功",$rdru);
}else{
 echo makereturnjson("0","-无需升级","");
}
     session_write_close();
?>