<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $wrdcode=dftval($_POST["wrdcode"],"");
$wrdname=dftval($_POST["wrdname"],"");
$passwd=dftval($_POST["passwd"],"");
$asktel=dftval($_POST["asktel"],"");
$email=dftval($_POST["email"],"");
if (es($wrdcode)*es($wrdname)*es($passwd)*es($asktel)==1){
 $upurl=combineurl("http://".glm(),"/localxres/funx/rcvclientwrd/?ak=".gla()."&av=".glv());
 $pd=array();
 $pd["wrdcode"]=$wrdcode;
 $pd["wrdname"]=$wrdname;
 $pd["passwd"]=$passwd;
 $pd["asktel"]=$asktel;
 $pd["email"]=$email;
 $bktxt=request_post($upurl,$pd);
 $bkdata=json_decode($bktxt);
 if (intval($bkdata->status)>0){
   $extb=UX("select count(*) as result from coode_worlddefine where worldcode='".$wrdcode."'");
   if (intval($extb)==0){
    $sqla="worldcode,worldtitle,passwordx,emailx,regmobile,headimg,worldtype,CRTM,UPTM,OLMK,CRTOR";
    $sqlb="'$wrdcode','$wrdname','$passwd','$email','$asktel','/localxres/iconsetx/restype/myworld.png','-1',now(),now(),'".onlymark()."','".$asktel."'";
    $zz=UX("insert into coode_worlddefine(".$sqla.")values(".$sqlb.")");
    echo makereturnjson("1","申请成功","");
   }else{
    echo makereturnjson("0","申请失败，该世界已存在","");
   }
 }else{
   echo makereturnjson("0","申请失败，母机返回错误","");
 }
}else{
 echo makereturnjson("0","失败,缺少参数","");
}
     session_write_close();
?>