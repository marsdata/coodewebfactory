<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $dt=$_POST["dt"];
$fn=str_replace("()","",$_GET["fn"]);
$dt=unstrs($dt);
$dt=str_replace('<?php'.huanhang(),'',$dt);
$dt=str_replace(huanhang().'?>','',$dt);
$dtlen=strlen($dt);
 $bid=onlymark();
 $datax=gohex($dt);
 $odata="";
 $extx=0;
if (isx2($fn,"SNO:","@")){
 $skey=hou($fn,".");
 $sno=qian(hou($fn,"SNO:"),".");
 $tbnm=qian($fn,"@");
 $rst=SX("select SNO,".$skey." as funfull,OLMK as funcname from ".$tbnm."  where SNO='".$sno."' ");
 $odata=UX("select ".$skey." as result from ".$tbnm." where SNO='".$sno."'");
 $extx=intval(UX("select count(*) as result from coode_afspace where fromurl='".$tbnm."' and askforwhat='tablename' and accstt=1 and etel='".$_COOKIE["uid"]."'"));
}else{
 if (isx1($fn,"@") and !isx1($fn,"SNO:")){
   $ckey=hou($fn,".");
   $tbnm=qian(hou($fn,"@"),".");
   $skey=qian($fn,"@");
   $rst=SX("select SNO,".$skey." as funfull,keytitle as funcname from coode_keydetailx where TABLE_NAME='".$tbnm."'  and COLUMN_NAME='".$ckey."' ");
   $odata=UX("select ".$skey." as result from coode_keydetailx where TABLE_NAME='".$tbnm."'  and COLUMN_NAME='".$ckey."' ");
   $extx=intval(UX("select count(*) as result from coode_afspace where fromurl='".$tbnm."' and askforwhat='tablename' and accstt=1 and etel='".$_COOKIE["uid"]."'"));
 }else{
   $rst=SX("select SNO,funname,funbody,funfull,funcname from coode_funfile  where funname='".$fn."' or funname='".$fn."()'");
   $odata=anyvalue($rst,"funfull",0);
   $extx=intval(UX("select count(*) as result from coode_afspace where fromurl='".$fn."' and askforwhat='bfunname' and accstt=1 and etel='".$_COOKIE["uid"]."'"));
 }
} 
$totrst=countresult($rst);
$newffl=tostring($datax);
$oldffl=tostring($odata);
if ($totrst>0 and $extx>0){  
  $newfbd="";    
  $funnm=anyvalue($rst,"funcname",0);    
  $x=UX("insert into coode_updatefun(updator,RIP,optime,upmark,funname,beforevalue,aftervalue,billid,CRTM,UPTM,CRTOR,OLMK,bfmd5,aftmd5,authtime)values('".$_COOKIE["uid"]."','".getip()."',now(),'".$fn."','".$funnm."','".$odata."','".$datax."','".$bid."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."','".md5($odata)."','".md5($datax)."',now())");  
 if (isx2($fn,"SNO:","@")){
   $skey=hou($fn,".");
   $sno=qian(hou($fn,"SNO:"),".");
   $tbnm=qian($fn,"@");  
   $x=UX("update ".$tbnm." set ".$skey."='".$datax."',UPTM=now() where SNO='".$sno."'");   
 }else{
  if (isx1($fn,"@") and !isx1($fn,"SNO:")){
   $ckey=hou($fn,".");
   $tbnm=qian(hou($fn,"@"),".");
   $skey=qian($fn,"@");  
   $x=UX("update coode_keydetailx set ".$skey."='".$datax."',UPTM=now() where TABLE_NAME='".$tbnm."' and COLUMN_NAME='".$ckey."'");   
  }else{
   $x=UX("update coode_funfile set funfull='".$datax."',PRIME=1,UPTM=now() where funname='".$fn."' or funname='".$fn."()'");   
  }
 }  
 eval(CLASSX("changecount"));
 $cc=new changecount(); 
 $farr=$cc->funchange($oldffl,$newffl,$farr);
}else{ 
 if ($totrst==0){
  if (!isx1($fn,"@")){
   if ($fn!=""){
    eval(CLASSX("changecount"));
    $cc=new changecount();
    $farr=$cc->funchange($oldffl,$newffl,$farr); 
    $nx=UX("insert into coode_funfile(funname,funbody,funfull,CRTM,UPTM,CRTOR,OLMK,PTOF,STATUS,ispmiss,PRIME)values('".str_replace("()","",$fn)."()','','".$datax."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."','".myfirstpos()."',1,1,1)"); 
   }
  }
 }
};
if ($fn!=""){
 eval(CLASSX("anychange"));
 $ac=new anychange();
 $hrst=SX("select sysid,appid,pagemark from coode_pagesrc where (sourcecls='fun' or sourcecls='function') and sourceid='".$fn."'");
 $toth=countresult($hrst);
 if ($toth>0){
  for ($k=0;$k<$toth;$k++){
   $hatxt=$ac->srcchange($fn,"function",anyvalue($hrst,"sysid",$k),anyvalue($hrst,"appid",$k),anyvalue($hrst,"pagemark",$k),$bid,$farr);
  }
 }else{ 
   $hatxt=$ac->srcchange($fn,"function","coode","anyapp","anypage",$bid,$farr);
 }
  $srcmd5=md5($datax);
  $z=recsrcver("fun",$fn,$srcmd5,$funnm,$fn,"");
  $ctx=UX("select sum(newchara-killchara) as result from coode_pagedevelop where newaction='UPDATEfunction-".$fn."'");
  $zx=UX("update coode_pagesrc set sourcelong='".$ctx."' where sourceid='".$fn."' and (sourcecls='function' or sourcecls='fun')");  
  echo "1";
}else{
  echo "0";
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>