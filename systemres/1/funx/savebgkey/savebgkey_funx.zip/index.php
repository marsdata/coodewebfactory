<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $bgcode=dftval($_GET["bgcode"],"");
$keyobjs=dftval($_POST["keyobjs"],"");
//身份证号(varchar30)@-@姓名(varchar30)
eval(RESFUNSET("dspbasecoprt"));
if ($bgcode!=""){
 if (strpos($keyobjs,"@-@")){
  $ptkey=explode("@-@",$keyobjs);  
  $totptk=count($ptkey);
  $fmknms="";
  for ($kk=0;$kk<$totptk;$kk++){
     $fname=qian($ptkey[$kk],"(");
     $ftype=qian(hou($ptkey[$kk],"("),")");
     $fmknms=$fmknms.$fname.",";
  }
  $fmknms=killlaststr($fmknms);
  $breakx=0;
  $kd=KCTD("coode_wrdgrpbra","bragrpcode=".$bgcode);
  while ($totext!=$totptk and $breakx<10){
   $knms=KN($fmknms);  
   $ptkcol=explode("/",$knms);
   $fmkv="";
   $totext=0;
      
   for ($kz=0;$kz<$totptk;$kz++){   
    $fname=qian($ptkey[$kz],"(");       
    $ftype=qian(hou($ptkey[$kz],"("),")");    
    if ($ftype=="notype"){
      $ftype="varchar";
      //$ftype=KT($fname);
    }    
    $colstr=$ptkcol[$kz];   
    $fmkv="dktype=".$ftype."&brarestitle=".$fname."&CRTOR=".$_COOKIE["uid"]."&bradescrib=".qian($colstr,"@");   
    $fmkcdt="bragrpcode=".$bgcode."&brarescode=".hou(str_replace("_","",$colstr),"@");      
    if (hou($colstr,"@")!=""){   
     if (newdata("coode_wrdgrpbra",$fmkv,$fmkcdt)){
      // echo "tt--".$fmkv."--".$fmkcdt.huanhang();
     }else{
       //echo "ff--".$fmkv."--".$fmkcdt.huanhang();
     }
    }
    if (hou($colstr,"@")!=""){
     if (ECTD("coode_wrdgrpbra","bragrpcode=".$bgcode."&brarestitle=".$fname)){
      $totext=$totext+1;
     }
    }    
   }   
   $breakx=$breakx+1;
  }
  if ($totext==$totptk){
    $zz=UX("update coode_wrdrestporg set STATUS=1 where bgrpmark='".$bgcode."'");
    $zz=UX("update coode_wrdbragroup set STATUS=1 where brasetmark='".$bgcode."'");
    echo makereturnjson("1","创建成功","");
  }else{
    echo makereturnjson("0","创建失败","");
  }
 }else{
  echo makereturnjson("0","保存失败，至少提交2个字段","");
 }
}else{
 echo makereturnjson("0","保存失败，参数不全","");
}
     session_write_close();
?>