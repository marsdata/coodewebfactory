<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       //这是保存函数的FID=SAVEFUNC 方法，你点保存就是执行此方法，所以修改出错之后系统无法运行，请改此文件慎重
$dt=$_POST["dt"];
$fn=$_GET["fn"];
$fn=str_replace("()","",$fn);
$fn=str_replace(" ","",$fn);
$dt=unstrs($dt);
$wholedt=$dt;
$dt=str_replace('<?php'.huanhang(),'',$dt);
$dt=str_replace(huanhang().'?>','',$dt);
$datax=gohex($dt);
$premd5=md5($datax);
$conn=mysql_connect(gl(),glu(),glp());
 $rst=selectedx($conn,glb(),"select SNO,funname,funbody,funfull,funcname,sysid,appid from coode_phpcls  where funname='".$fn."' or funname='".$fn."()'","utf8","");
$totrst=countresult($rst);
$bid=onlymark();
$newffl=tostring($datax);
  $oldfbd=anyvalue($rst,"funbody",0);
  $funnm=anyvalue($rst,"funcname",0);
  $odata=anyvalue($rst,"funfull",0);
  $sysid=anyvalue($rst,"sysid",0);
  $appid=anyvalue($rst,"appid",0);
  $oldffl=tostring($odata);
  $newfbd="";  
//本系统中所有大写字段定义为系统字段，如CRTM创建时刻，UPTM更改时刻，OLMK唯一标记，这些字段每个表都有SNO是数据编号自动递增
//小写字段是每个表自己的特征字段
 if ($totrst>0){
  $conn=mysql_connect(gl(),glu(),glp());
  $x=updatingx($conn,glb(),"update coode_phpcls set funfull='".$datax."',PRIME=1,UPTM=now() where funname='".$fn."' or funname='".$fn."()'","utf8");           
 }else{
  $zz=UX("insert into coode_phpcls(funname,funcname,funfull,PRIME,CRTM,UPTM,OLMK)values('".$fn."','".$fn."','".$datax."',1,now(),now(),'".onlymark()."')");
 }
   $outpath=combineurl(localroot(),"/localxres/clsx/".$fn."/index.php");   
   $zz=overfile($outpath,$wholedt);
   $srclenx= checklines($odata,$datax);
    $olenx=qian($srclenx,"/");
    $nlenx=hou($srclenx,"/");
    $kx=reclines($fn,$fn,$fn,$fn,"cls",$olenx,$nlenx,$datax);
    $zk=tellmysrc("clsx",$fn,$fn,$premd5,$datax); 
    echo "1"; 
       session_write_close();
?>