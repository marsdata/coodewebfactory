<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $instmark=dftval($_GET["instmark"],"");
$expx=dftval($_GET["expx"],"");
$frmmark=dftval($_GET["frmmark"],"");
if (es($instmark)*es($expx)*es(frmmark)==1){
 $pdleft=dftval($_POST["pdleft"],"");
 $pdtop=dftval($_POST["pdtop"],"");
 $pdright=dftval($_POST["pdright"],"");
 $pdbottom=dftval($_POST["pdbottom"],"");
 $marleft=dftval($_POST["marleft"],"");
 $martop=dftval($_POST["martop"],"");
 $marright=dftval($_POST["marright"],"");
 $marbottom=dftval($_POST["marbottom"],"");
 $zz0=UX("update coode_divfrmeles set pdleft='".$pdleft."',pdtop='".$pdtop."',pdright='".$pdright."',pdbottom='".$pdbottom."',marleft='".$marleft."',martop='".$martop."',marright='".$marright."',marbottom='".$marbottom."' where instmark='".$instmark."' and mothersrd='".str_replace("@","=",$expx)."' and frmmark='".$frmmark."'");
 $parid=UX("select parid as result from coode_divfrmeles  where instmark='".$instmark."' and mothersrd='".str_replace("@","=",$expx)."' and frmmark='".$frmmark."'");
 $zz1=UX("update coode_divfrmeles set mypdleft='".$pdleft."',mypdtop='".$pdtop."',mypdright='".$pdright."',mypdbottom='".$pdbottom."' where instmark='".$instmark."' and mothersrd='".str_replace("@","=",$expx)."' and myid='".$parid."'");
 echo makereturnjson("1","保存成功","");
}
     session_write_close();
?>