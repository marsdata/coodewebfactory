<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $instmark=dftval($_GET["instmark"],"");
$expx=dftval($_GET["expx"],"");
$frmmark=dftval($_GET["frmmark"],"");
if (es($instmark)*es($expx)*es(frmmark)==1){
 $parwx=dftval($_POST["parwx"],"");
 $parhx=dftval($_POST["parhx"],"");
 $parstyle=dftval($_POST["parstyle"],"");
 $parhcode=dftval($_POST["parhcode"],"");
 $thiswx=dftval($_POST["thiswx"],"");
 $thishx=dftval($_POST["thishx"],"");
 $thisstyle=dftval($_POST["thisstyle"],"");
 $thishcode=dftval($_POST["thishcode"],"");
 $zz0=UX("update coode_divfrmeles set parwx='".$parwx."',parhx='".$parhx."',widthx='".$thiswx."',heightx='".$thishx."',parstyle='".$parstyle."',parhcode='".$parhcode."',divstyle='".$thisstyle."',divhcode='".$thishcode."' where instmark='".$instmark."' and mothersrd='".str_replace("@","=",$expx)."' and frmmark='".$frmmark."'");
 $parid=UX("select parid as result from coode_divfrmeles  where instmark='".$instmark."' and mothersrd='".str_replace("@","=",$expx)."' and frmmark='".$frmmark."'");
 $myid=UX("select myid as result from coode_divfrmeles  where instmark='".$instmark."' and mothersrd='".str_replace("@","=",$expx)."' and frmmark='".$frmmark."'");
 $zz0=UX("update coode_divfrmeles set widthx='".$parwx."',heightx='".$parhx."' where instmark='".$instmark."' and mothersrd='".str_replace("@","=",$expx)."' and myid='".$parid."'");
 $zz1=UX("update coode_divfrmeles set parwx='".$thiswx."',parhx='".$thishx."' where instmark='".$instmark."' and mothersrd='".str_replace("@","=",$expx)."' and parid='".$myid."'");
 echo makereturnjson("1","保存成功","");
}
     session_write_close();
?>