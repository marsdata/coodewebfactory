<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $instmark=$_POST["instmark"];
$insttitle=$_POST["insttitle"];
$expx=$_POST["expx"];
$expy=str_replace("@","=",$expx);
$stylex=unstrs($_POST["stylex"]);
$scriptx=unstrs($_POST["scriptx"]);
$frmcodex=unstrs($_POST["frmcode"]);
$pagesrdx=unstrs($_POST["pagecode"]);
if ($pagesrdx==""){
  $pagesrdx=constval("pagesrdcode");
}
$outurl=$_POST["outurl"];
$ext0=UX("select count(*) as result from coode_divfrmindex where instmark='".$instmark."' and mothersrd='".$expx."'");
if (intval($ext0)>0){
 $fmscrpt=$scriptx;
 $fmstyle=$stylex;
 $dcrst=SX("select scriptx,stylex from coode_divfrmcode where  instmark='".$instmark."' and mothersrd='".$expy."'");
 $totd=countresult($dcrst);
 for ($jj=0;$jj<$totd;$jj++){
   $dscriptx=tostring(anyvalue($dcrst,"scriptx",$jj));
   $dstylex=tostring(anyvalue($dcrst,"stylex",$jj));
   $fmscript=$fmscript.$dscriptx;
   $fmstyle=$fmstyle.$dstylex;
 }
 $scripty=$fmscript;
 $styley=$fmstyle;
 
 $sqlx="UPTM=now(),mothersrd='".$expx."',insttitle='".$insttitle."',stylex='".gohex($stylex)."',scriptx='".gohex($scriptx)."',outurl='".$outurl."',pagesrd='".gohex($pagesrdx)."'";
 $z=UX("update coode_divfrmindex set ".$sqlx." where instmark='".$instmark."' and mothersrd='".$expx."'");              
 $sqly="styley='".gohex($styley)."',scripty='".gohex($scripty)."'";
 $z=UX("update coode_divfrmindex set ".$sqly." where instmark='".$instmark."' and mothersrd='".$expx."'");              
}
 
eval(RESFUNSET("divfrmfun"));
$expz=str_replace("@","=",$expx);
//这是合成测试显示加颜色的页面
$cmbcode="";
$idxrst=SX("select insttitle,scripty,styley,jsfilex,cssfilex,pagesrd,widthx,heightx from coode_divfrmindex where instmark='".$instmark."' and mothersrd='".$expx."'");
$totidx=countresult($idxrst);
$fmjsf="";
$fmcssf="";
$fmscript="";
$fmstyle="";
if (intval($totidx)>0){
$outx=combineurl(localroot(),$outurl);
  $insttitle=anyvalue($idxrst,"insttitle",0);
  $scripty=tostring(anyvalue($idxrst,"scripty",0));
  $styley=tostring(anyvalue($idxrst,"styley",0));
  $jsfilex=tostring(anyvalue($idxrst,"jsfilex",0));
  $cssfilex=tostring(anyvalue($idxrst,"cssfilex",0));
  $pagesrd=tostring(anyvalue($idxrst,"pagesrd",0));
  $fmjsf=formjs(onlyone($jsfilex));
  $fmcssf=formcss(onlyone($cssfilex));
  $wx=anyvalue($idxrst,"widthx",0);
  $hx=anyvalue($idxrst,"heightx",0);
  if ($pagesrd==""){
   $pagesrd=constval("pagesrdcode");
  }
 $dsplno=array();
 $dsplno[0]="";
 $dsplno[1]="display:none;";
 $isdspl=0;
 $dcrst=SX("select myid,parid,frmmark,divcode,divstyle,STATUS from coode_divfrmeles where  instmark='".$instmark."' and mothersrd='".$expz."' and parid=-1"); 
 $totd=countresult($dcrst); 
  $myid=anyvalue($dcrst,"myid",0);
  $parid=anyvalue($dcrst,"parid",0);
  $divcode=tostring(anyvalue($dcrst,"divcode",0));
  $thisfmk=anyvalue($dcrst,"frmmark",0);
  $status=anyvalue($dcrst,"STATUS",0);
  $divstyle=anyvalue($dcrst,"divstyle",0);
   $bstyle="position:relative;z-index:99;".$divstyle;
   $thisstyle=makedivvalstyle($bstyle,$instmark,$expz,$thisfmk,intval($wx),intval($hx));
   $isdspl=1;
  $d1crst=SX("select myid,parid,frmmark,divcode,divstyle,STATUS from coode_divfrmeles where  instmark='".$instmark."' and mothersrd='".$expz."' and parid=".$myid); 
  $totd1=countresult($d1crst);
  $fmc1="";
  for ($j1=0;$j1<$totd1;$j1++){
    $myid1=anyvalue($d1crst,"myid",$j1);
    $parid1=anyvalue($d1crst,"parid",$j1);
    $divcode1=tostring(anyvalue($d1crst,"divcode",$j1));
    $divstyle1=anyvalue($d1crst,"divstyle",$j1);
    $thisfmk1=anyvalue($d1crst,"frmmark",$j1);
    $status1=anyvalue($dcrst,"STATUS",0);
      $bstyle1="position:relative;z-index:99;".$divstyle1;
      $thisstyle1=makedivnewstyle($bstyle1,$instmark,$expz,$thisfmk1);
      $isdspl=1;
      $d2crst=SX("select myid,parid,frmmark,divcode,divstyle,STATUS from coode_divfrmeles where  instmark='".$instmark."' and mothersrd='".$expz."' and parid=".$myid1); 
      $totd2=countresult($d2crst);
      $fmc2="";
      for ($j2=0;$j2<$totd2;$j2++){
       $myid2=anyvalue($d2crst,"myid",$j2);
       $parid2=anyvalue($d2crst,"parid",$j2);
       $divcode2=tostring(anyvalue($d2crst,"divcode",$j2));
       $divstyle2=anyvalue($d2crst,"divstyle",$j2);
       $thisfmk2=anyvalue($d2crst,"frmmark",$j2);
       $status2=anyvalue($d2crst,"STATUS",$j2);        
         $bstyle2="position:relative;z-index:99;".$divstyle2;
         $thisstyle2=makedivnewstyle($bstyle2,$instmark,$expz,$thisfmk2);
         $isdspl=1;
        
          $d3crst=SX("select myid,parid,frmmark,divcode,divstyle,STATUS from coode_divfrmeles where  instmark='".$instmark."' and mothersrd='".$expz."' and parid=".$myid2); 
          $totd3=countresult($d3crst);
          $fmc3="";
          for ($j3=0;$j3<$totd3;$j3++){
           $myid3=anyvalue($d3crst,"myid",$j3);
           $parid3=anyvalue($d3crst,"parid",$j3);
           $divcode3=tostring(anyvalue($d3crst,"divcode",$j3));
            
           $divstyle3=anyvalue($d3crst,"divstyle",$j3);
           $thisfmk3=anyvalue($d3crst,"frmmark",$j3);
           $status3=anyvalue($d3crst,"STATUS",$j3);
        
            
             $isdspl=1;
             $bstyle3="position:relative;z-index:99;".$divstyle3;
             $thisstyle3=makedivnewstyle($bstyle3,$instmark,$expz,$thisfmk3);
            
           $divcode3=str_replace($instmark.$thisfmk3."hcode"," style=\"".$thisstyle3."\"",$divcode3);  
           $fmc3=$fmc3.$divcode3;          
          }
         $divcode2=str_replace($instmark.$thisfmk2."hcode"," style=\"".$thisstyle2."\"",$divcode2);  
         if (intval($status2)==0){
           $divcode2=str_replace($instmark.$thisfmk2."INNER",$fmc3,$divcode2);  
         }
         $fmc2=$fmc2.$divcode2;
      }
    $divcode1=str_replace($instmark.$thisfmk1."hcode"," style=\"".$thisstyle1."\"",$divcode1);  
    if (intval($status1)==0){
      $divcode1=str_replace($instmark.$thisfmk1."INNER",$fmc2,$divcode1);  
    }
    $fmc1=$fmc1.$divcode1;
  }
  $divcode=str_replace($instmark.$thisfmk."hcode"," style=\"".$thisstyle."\"",$divcode);
  $divcode=str_replace($instmark.$thisfmk."INNER",$fmc1,$divcode); 
//{!--shortJSFILES--}
//{!--shortCSSFILES--}
//{!--shortSTYLE--}
//{!--shortSCRIPT--}   
  $pagesrd=turnlab($pagesrd);    
  $pagesrd=str_replace("<!--thistitle-->",$insttitle,$pagesrd);
  $pagesrd=str_replace("<!--thesecomCSSFILES-->",$fmcssf,$pagesrd);
  $pagesrd=str_replace("<!--thesecomJSFILES-->",$fmjsf,$pagesrd);
  $pagesrd=str_replace("<!--thiscomSTYLE-->",$styley,$pagesrd);
  $pagesrd=str_replace("<!--thiscomSCRIPT-->",$scripty,$pagesrd);
  $pagesrd=str_replace("<!--thiscomHTML-->",turnlab($divcode),$pagesrd); 
  $zz=UX("insert into coode_divfrmcode(instmark,divmark,parmark,CRTM,UPTM,OLMK)select instmark,concat(divmark,'INNER'),divmark,now(),now(),OLMK from coode_divfrmeles where instmark='".$instmark."' and STATUS=1");
  $drst=SX("select divmark,innercode from coode_divfrmcode where instmark='".$instmark."'");
  $totd=countresult($drst);
  for ($dd=0;$dd<$totd;$dd++){
    $incode=tostring(anyvalue($drst,"innercode",$dd));
    $dmark=anyvalue($drst,"divmark",$dd);
    $pagesrd=str_replace($dmark,$incode,$pagesrd);
  }
  overfile($outx,$pagesrd);
}else{
  //echo "No Code!";
}  
  
echo makereturnjson("1","成功",$outx);
     session_write_close();
?>