<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $dft=_get("dft");
$dsid=_get("dsid");
$snox=dftval(_get("SNO"),"0");
$dorst=SX("select keymark,keytitle,keytype from coode_dspckeyx where datamark='".$dsid."'");
$totdo=countresult($dorst);
$fmx="";
$fmy="";
$fmup="";
for ($o=0;$o<$totdo;$o++){
  $colid=anyvalue($dorst,"keymark",$o);
  $coltt=anyvalue($dorst,"keytitle",$o);
  $coltp=anyvalue($dorst,"keytype",$o);
  $pdata=dftval(unstrs($_POST["p_".$colid.$snox]),"");
  $fmx=$fmx.$colid.",";
  $fmy=$fmy.$pdata.",";
  $fmup=$fmup.$colid."='".$pdata."',";
}
$fmx=killlaststr($fmx);
$fmy=killlaststr($fmy);
$fmy=str_replace(",","@-@",$fmy);
$fmup=killlaststr($fmup);
if ($snox=="0"){
  if ($dft==""){
   $endno=UX("select datasno as result from coode_dspcvindex where datamark='".$dsid."' order by datasno desc");
   $nextone=intval($endno)+1;
   $zz=UX("insert into coode_dspcvindex(datamark,datasno,keymks,valmd5,keyvals,CRTM,UPTM,CRTOR,OLMK)values('".$dsid."','".($nextone)."','".$fmx."','".md5(fmy)."','".$fmy."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."')");
   $tt=UX("insert into coode_dspcval(datamark,datasno,keymark,keytitle,keytype,keylen,CRTM,UPTM,OLMK)select datamark,'".($nextone)."',keymark,keytitle,keytype,keylen,now(),now(),RAND()*1000000 from coode_dspckey where datamark='".$dsid."'");
   for ($o=0;$o<$totdo;$o++){
    $colid=anyvalue($dorst,"keymark",$o);
    $coltt=anyvalue($dorst,"keytitle",$o);
    $coltp=anyvalue($dorst,"keytype",$o);
    $kxx=$coltp."val";
    $dx=UX("update coode_dspcval set ".$kxx."='".unstrs($_POST["p_".$colid.$snox])."',UPTM=now() where datamark='".$dsid."' and datasno='".($nextone)."' and keymark='".$colid."'");      
   }
  }else{
   $kk=UX("delete from coode_dspcval where datamark='".$dsid."' and datasno=0");
   $kk=UX("delete from coode_dspcindex where datamark='".$dsid."' and datasno=0");
   $zz=UX("insert into coode_dspcvindex(datamark,datasno,keymks,valmd5,keyvals,CRTM,UPTM,CRTOR,OLMK)values('".$dsid."','0','".$fmx."','".md5(fmy)."','".$fmy."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."')");
   $tt=UX("insert into coode_dspcval(datamark,datasno,keymark,keytitle,keytype,keylen,CRTM,UPTM,OLMK)select datamark,0,keymark,keytitle,keytype,keylen,now(),now(),RAND()*1000000 from coode_dspckey where datamark='".$dsid."'");
   $zz=UX("update coode_dspcvindex set keymks='".$fmx."',valmd5='".md5($fmy)."',keyvals='".$fmy."',UPTM=now() where datamark='".$dsid."' and datasno=0"); 
   for ($o=0;$o<$totdo;$o++){
    $colid=anyvalue($dorst,"keymark",$o);
    $coltt=anyvalue($dorst,"keytitle",$o);
    $coltp=anyvalue($dorst,"keytype",$o);
    $kxx=$coltp."val";
    $pval=dftval($_POST["p_".$colid.$snox],"");
    if ($pval!="" or $pval==" " or $pval=="."){
     if ($pval==" " or $pval=="."){
       $pval="";
     }
     $dx=UX("update coode_dspcval set ".$kxx."='".unstrs($pval)."',UPTM=now() where datamark='".$dsid."' and datasno=0 and keymark='".$colid."'");    
    }else{
     $dx=UX("update coode_dspcval set UPTM=now() where datamark='".$dsid."' and datasno=0 and keymark='".$colid."'");
    }
   }
  }
}else{
  $tt=UX("insert into coode_dspcval(domainmark,datamark,datasno,keymark,keytitle,keytype,keylen,CRTM,UPTM,OLMK)select domainmark,datamark,'".$snox."',keymark,keytitle,keytype,keylen,CRTM,UPTM,RAND()*100000 from coode_dspckey where datamark='".$dsid."' and concat(domainmark,datamark,'".$snox."',keymark) not in (select concat(domainmark,datamark,datasno,keymark) from coode_dspcval)");
  $zz=UX("update coode_dspcvindex set keymks='".$fmx."',valmd5='".md5($fmy)."',keyvals='".$fmy."',UPTM=now() where datamark='".$dsid."' and datasno='".$snox."'"); 
  for ($o=0;$o<$totdo;$o++){
    $colid=anyvalue($dorst,"keymark",$o);
    $coltt=anyvalue($dorst,"keytitle",$o);
    $coltp=anyvalue($dorst,"keytype",$o);
    $kxx=$coltp."val";
    $pval=dftval($_POST["p_".$colid.$snox],"");
    if ($pval!="" or $pval==" " or $pval=="."){
     if ($pval==" " or $pval=="."){
       $pval="";
     }
     $dx=UX("update coode_dspcval set ".$kxx."='".unstrs($pval)."',UPTM=now() where datamark='".$dsid."' and datasno='".($snox)."' and keymark='".$colid."'");       
    }else{
     $dx=UX("update coode_dspcval set UPTM=now() where datamark='".$dsid."' and datasno='".($snox)."' and keymark='".$colid."'");       
    }
  }
}
 $dkrst=SX("select datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib   from coode_dspckey where datamark='".$dsid."' order by sqx");
  $totdk=countresult($dkrst);
  $fmtps='{"keyid":"datasno","keytitle":"编号","keytype":"varchar","keylen":"100","dxtype":"varchar","classp":"0","clstxt":""},';
  $fmrcd="datasno,";
  $fmca="";
  $fmcb="";
  $clstxt="";
  for ($i=0;$i<$totdk;$i++){
   $keyx[$i]=anyvalue($dkrst,"keymark",$i);
   $keyy[$i]=anyvalue($dkrst,"keytitle",$i);
   $keytp[$i]=anyvalue($dkrst,"keytype",$i);
   $keylen[$i]=anyvalue($dkrst,"keylen",$i);
   $clstxtx[$i]=anyvalue($dkrst,"clstxt",$i);
   $classp[$i]=anyvalue($dkrst,"classp",$i);
   $keydxtype[$i]=anyvalue($dkrst,"dxtype",$i);
   $fmtps=$fmtps.'{"keyid":"'.$keyx[$i].'","keytitle":"'.$keyy[$i].'","keytype":"'.$keytp[$i].'","keylen":"'.$keylen[$i].'","dxtype":"'.$keydxtype[$i].'","classp":"'.$classp[$i].'","clstxt":"'.$clstxtx[$i].'"},';
   $fmrcd=$fmrcd.$keyx[$i].",";
  }//totdk
  $fmtps=killlaststr($fmtps);
  $fmrcd=killlaststr($fmrcd)."@/@";
  $fmrcd=str_replace(",","@-@",$fmrcd);
  $jsondata='{"data":[<datavls>]}';
  $datademo='{"status":"1","datamark":"<datamark>","datatitle":"<datatitle>","totrcd":"<totrcd>","keytps":[<ktps>],"vls":[<datavls>]}';
  $datatitle=UX("select datatitle as result from coode_dataspace where datamark='".$dsid."'");
  $datarst=SX("select datasno,keymks,valmd5,keyvals from coode_dspcvindex where datamark='".$dsid."' and datasno!=0 order by datasno");
  $totda=countresult($datarst);
  $datademo=str_replace("<datamark>",$datamark,$datademo);
  $datademo=str_replace("<datatitle>",$datatitle,$datademo);
  $datademo=str_replace("<ktps>",$fmtps,$datademo);
  $datademo=str_replace("<totrcd>",$totda,$datademo);
  $fmvalx="";
 
  for ($j=0;$j<$totda;$j++){
   $datasno=anyvalue($datarst,"datasno",$j);
   $keymks=anyvalue($datarst,"keymks",$j);
   $valmd5=anyvalue($datarst,"valmd5",$j);
   $keyvals=anyvalue($datarst,"keyvals",$j);
   $rcdrowx="";
   $fmitem='{';
     $detailrst=SX("select keymark,keytype,intval,tinyintval,dateval,datetimeval,varcharval,textval,longtextval,decimalval,classp from coode_dspcval where datamark='".$dsid."' and datasno='".$datasno."'");
     $totdtl=countresult($detailrst);       
     for ($k=0;$k<$totdtl;$k++){
         $kmk=anyvalue($detailrst,"keymark",$k);
         $ktp=anyvalue($detailrst,"keytype",$k);
         $classpx=anyvalue($detailrst,"classp",$k);
         $intval=anyvalue($detailrst,"intval",$k);
         $tinyintval=anyvalue($detailrst,"tinyintval",$k);
         $dateval=anyvalue($detailrst,"dateval",$k);
         $datetimeval=anyvalue($detailrst,"datetimeval",$k);
         $varcharval=anyvalue($detailrst,"varcharval",$k);
         $textval=anyvalue($detailrst,"textval",$k);
         $longtextval=anyvalue($detailrst,"longtextval",$k);
         $decimalval=anyvalue($detailrst,"decimalval",$k);
         switch($ktp){
           case "int":
           $valx[$kmk]=$intval;
           break;
           case "tinyint":
           $valx[$kmk]=$tinyintval;
           break;
           case "date":
           $valx[$kmk]=$dateval;
           break;
           case "datetime":
           $valx[$kmk]=$datetimeval;
           break;
           case "varchar":
           $valx[$kmk]=$varcharval;
           break;
           case "text":
           $valx[$kmk]=$textval;
           break;
           case "longtext":
           $valx[$kmk]=$longtextval;
           break;
           case "decimal":
           $valx[$kmk]=$decimalval;
           break;
           default:
         }//swc
         $rcdrowx=$rcdrowx.$valx[$kmk].",";
         if (intval($classpx)==1){
           $fmca=$fmca.$valx[$kmk].",";
         }
         if (intval($classpx)==2){
           $fmcb=$fmcb.$valx[$kmk].",";
         }
     }//fork
     $fmrcd=$fmrcd.$datasno.",".$rcdrowx;
     $fmrcd=killlaststr($fmrcd).";";         
     $fmitem=$fmitem.'"datasno":"'.$datasno.'",';
    for ($i=0;$i<$totdk;$i++){
       $fmitem=$fmitem.'"'.$keyx[$i].'":"'.$valx[$keyx[$i]].'",';
    }
     $fmitem=killlaststr($fmitem).'}';
     $fmvalx=$fmvalx.$fmitem.',';
  }//forj
  $fmvalx=killlaststr($fmvalx);
  $fmca=killlaststr($fmca);
  $fmcb=killlaststr($fmcb);
  if ($fmca!="" and $fmcb!=""){
   $clstxt=$fmcb."|".$fmca;
  } 
  $fmrcd=str_replace(",","@-@",$fmrcd);
  $fmrcd=str_replace(";","@/@",$fmrcd);
  $datademo=str_replace("<datavls>",$fmvalx,$datademo);
  $jsondata=str_replace("<datavls>",$fmvalx,$jsondata);  
  $jshortpath=combineurl(localroot(),"/localxres/dataspacex/".$dsid."/jsshort.json");
  $jsonpath=combineurl(localroot(),"/localxres/dataspacex/".$dsid."/data.json");
  $coodex=combineurl(localroot(),"/localxres/dataspacex/".$dsid."/coodercd.txt");
  $coodeclstxt=combineurl(localroot(),"/localxres/dataspacex/".$dsid."/coodeclstxt.txt");
  $z0=overfile($jshortpath,$datademo);
  $z1=overfile($jsonpath,$jsondata);
  $newrcd=str_replace("@-@","#"."-#",str_replace("@/@","#"."/#",$fmrcd));
  $z2=overfile($coodex,$newrcd);
  $z3=overfile($coodeclstxt,$clstxt);
  echo makereturnjson("1","提交成功",$errs);
       session_write_close();
?>