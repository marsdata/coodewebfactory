<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $datamark=dftval($_GET["datamark"],"");
$totrcd=dftval($_GET["totrcd"],"");
$allkeys=dftval($_GET["allkeys"],"");
$alltps=dftval($_GET["alltps"],"");
$ptkx=explode(",",$allkeys);
$pttx=explode(",",$alltps);
$pdata=dftval(unstrs($_POST["pdata"]),"");
$pdatab=dftval(unstrs($_POST["pdatab"]),"");
$ptdata=explode("@/@",$pdata);
$ptdatab=explode("@/@",$pdatab);
$totptd=count($ptdata);
$totkx=count($ptkx);
$totktp=count($pttx);
$errs="";
  if ($totkx==$totktp){ 
   for ($j=0;$j<$totptd;$j++){
    if ($ptdata[$j]!=""){
     $ptval=explode("@-@",$ptdata[$j]);
     if (strpos("x".$alltps,"text")>0){
       $tempptdata=hou($ptdatab[$j],"@-@");
     }else{
       $tempptdata=hou($ptdata[$j],"@-@");
     }
     if (($totkx+1)==count($ptval)){
       $zz=UX("insert into coode_dspcvindex(datamark,datasno,keymks,valmd5,keyvals,CRTM,UPTM,CRTOR,OLMK)values('".$datamark."','".($j)."','".$allkeys."','".md5(hou($ptdata[$j],"@-@"))."','".$tempptdata."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."') ON DUPLICATE KEY update UPTM=now(),keymks='".$allkeys."',valmd5='".md5(hou($ptdata[$j],"@-@"))."',keyvals='".$tempptdata."'");       
       $extd=UX("select count(*) as result from coode_dspcval where datamark='".$datamark."' and datasno='".($j)."'");          
       if ($extd==count($ptkx) ){
         for ($p=0;$p<count($ptkx);$p++){
          $kxx=$pttx[$p]."val";
          $dx=UX("update coode_dspcval set ".$kxx."='".$ptval[$p+1]."',UPTM=now() where datamark='".$datamark."' and datasno='".($j)."' and keymark='".$ptkx[$p]."'");      
         }    
       }else{  
        // $errs=$errs."保存数与数据字段数不一致,说明需要新增或者增加了字段重新保存";
         $zz=UX("delete from coode_dspcval where datamark='".$datamark."' and datasno='".($j)."'");
         $tt=UX("insert into coode_dspcval(datamark,datasno,keymark,keytitle,keytype,keylen,CRTM,UPTM,OLMK)select datamark,'".($j)."',keymark,keytitle,keytype,keylen,now(),now(),RAND()*1000000 from coode_dspckey where datamark='".$datamark."'");
         for ($p=0;$p<count($ptkx);$p++){
          $kxx=$pttx[$p]."val";
          $dx=UX("update coode_dspcval set ".$kxx."='".$ptval[$p+1]."',UPTM=now() where datamark='".$datamark."' and datasno='".($j)."' and keymark='".$ptkx[$p]."'");      
         }    
       }//ifextd 存储数据数与字段数一样
      }//ptkx-ptval分割后值与字段数量相同
     }else{
      //$errs=$errs."分割项与值数不一致(".count($ptkx)."-".count($ptval).")";
     }//ifptdata 分割项不能为空
    }//for    
    $zzs=UX("delete from coode_dspcval where timestampdiff(second,UPTM,now())>9 and datamark='".$datamark."'");
    $zzb=UX("delete from coode_dspcvindex where timestampdiff(second,UPTM,now())>9 and datamark='".$datamark."'");
    $px=UX("update coode_dataspace set STATUS=0 where datamark='".$datamark."'");
//---------------------------------------------------
 $dkrst=SX("select datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib   from coode_dspckey where datamark='".$datamark."' order by sqx");
  $totdk=countresult($dkrst);
  $fmtps="";
  $fmrcd="datasno,";
  $fmca="";
  $fmcb="";
  $clstxt="";
  for ($i=0;$i<$totdk;$i++){
   $keyx[$i]=anyvalue($dkrst,"keymark",$i);
   $keyy[$i]=anyvalue($dkrst,"keytitle",$i);
   $keytp[$i]=anyvalue($dkrst,"keytype",$i);
   $keylen[$i]=anyvalue($dkrst,"keylen",$i);
   $clstxtx[$i]=anyvalue($dkrst,"clstxt",$i);
   $classp[$i]=anyvalue($dkrst,"classp",$i);
   $keydxtype[$i]=anyvalue($dkrst,"dxtype",$i);
   $fmtps=$fmtps.'{"keyid":"'.$keyx[$i].'","keytitle":"'.$keyy[$i].'","keytype":"'.$keytp[$i].'","keylen":"'.$keylen[$i].'"},';
   $fmrcd=$fmrcd.$keyx[$i].",";
  }//totdk
  $fmtps=killlaststr($fmtps);
  $fmrcd=killlaststr($fmrcd)."@/@";
  $fmrcd=str_replace(",","@-@",$fmrcd);
  $jsondata='{"data":[<datavls>]}';
  $datademo='{"status":"1","datamark":"<datamark>","datatitle":"<datatitle>","totrcd":"<totrcd>","keytps":[<ktps>],"vls":[<datavls>]}';
  $datatitle=UX("select datatitle as result from coode_dataspace where datamark='".$datamark."'");
  $datarst=SX("select datasno,keymks,valmd5,keyvals from coode_dspcvindex where datamark='".$datamark."' and datasno!=0");
  $totda=countresult($datarst);
  $datademo=str_replace("<datamark>",$datamark,$datademo);
  $datademo=str_replace("<datatitle>",$datatitle,$datademo);
  $datademo=str_replace("<ktps>",$fmtps,$datademo);
  $datademo=str_replace("<totrcd>",$totda,$datademo);
  $fmvalx="";
 
  for ($j=0;$j<$totda;$j++){
   $datasno=anyvalue($datarst,"datasno",$j);
   $keymks=anyvalue($datarst,"keymks",$j);
   $valmd5=anyvalue($datarst,"valmd5",$j);
   $keyvals=anyvalue($datarst,"keyvals",$j);
   $rcdrowx="";
   $fmitem="{";
   if ($keyvals!=""){
     $ptkey=explode(",",$keymks);     
     $ptval=explode("@-@",$keyvals);     
     for ($k=0;$k<count($ptkey);$k++){
       $valx[$ptkey[$k]]=$ptval[$k];             
       $rcdrowx=$rcdrowx.$ptval[$k].",";
       if ($classp[$k]==1){
         $fmca=$fmca.$ptval[$k].",";
       }
       if ($classp[$k]==2){
         $fmcb=$fmcb.$ptval[$k].",";
       }
     }//fork
       $fmrcd=$fmrcd.$datasno.",".$rcdrowx;
       $fmrcd=killlaststr($fmrcd).";";
    }else{
     $tt=UX("insert into coode_dspcval(domainmark,datamark,datasno,keymark,keytitle,keytype,keylen,CRTM,UPTM,OLMK)select domainmark,datamark,'".$datasno."',keymark,keytitle,keytype,keylen,CRTM,UPTM,RAND()*100000 from coode_dspckey where datamark='".$datamark."' and concat(domainmark,datamark,'".$datasno."',keymark) not in (select concat(domainmark,datamark,datasno,keymark) from coode_dspcval)");
     $detailrst=SX("select keymark,keytype,intval,tinyintval,dateval,datetimeval,varcharval,textval,longtextval,decimalval,classp from coode_dspcval where datamark='".$datamark."' and datasno='".$datasno."'");
     $totdtl=countresult($detailrst);       
     for ($k=0;$k<$totdtl;$k++){
         $kmk=anyvalue($detailrst,"keymark",$k);
         $ktp=anyvalue($detailrst,"keytype",$k);
         $classpx=anyvalue($detailrst,"classp",$k);
         $intval=anyvalue($detailrst,"intval",$k);
         $tinyintval=anyvalue($detailrst,"tinyintval",$k);
         $dateval=anyvalue($detailrst,"dateval",$k);
         $datetimeval=anyvalue($detailrst,"datetimeval",$k);
         $varcharval=anyvalue($detailrst,"varcharval",$k);
         $textval=anyvalue($detailrst,"textval",$k);
         $longtextval=anyvalue($detailrst,"longtextval",$k);
         $decimalval=anyvalue($detailrst,"decimalval",$k);
         switch($ktp){
           case "int":
           $valx[$kmk]=$intval;
           break;
           case "tinyint":
           $valx[$kmk]=$tinyintval;
           break;
           case "dateval":
           $valx[$kmk]=$dateval;
           break;
           case "datetimeval":
           $valx[$kmk]=$datetimeval;
           break;
           case "varcharval":
           $valx[$kmk]=$varcharval;
           break;
           case "textval":
           $valx[$kmk]=$textval;
           break;
           case "longtextval":
           $valx[$kmk]=$longtextval;
           break;
           case "decimalval":
           $valx[$kmk]=$decimalval;
           break;
           default:
         }//swc
         $rcdrowx=$rcdrowx.$valx[$kmk].",";
         if (intval($classpx)==1){
           $fmca=$fmca.$valx[$kmk].",";
         }
         if (intval($classpx)==2){
           $fmcb=$fmcb.$valx[$kmk].",";
         }
     }//fork
     $fmrcd=$fmrcd.$datasno.",".$rcdrowx;
     $fmrcd=killlaststr($fmrcd).";";     
    }//ifkeyval
    
    for ($i=0;$i<$totdk;$i++){
       $fmitem=$fmitem.'"'.$keyx[$i].'":"'.$valx[$keyx[$i]].'",';
    }
     $fmitem=killlaststr($fmitem).'}';
     $fmvalx=$fmvalx.$fmitem.',';
  }//forj
  $fmvalx=killlaststr($fmvalx);
  $fmca=killlaststr($fmca);
  $fmcb=killlaststr($fmcb);
  if ($fmca!="" and $fmcb!=""){
   $clstxt=$fmcb."|".$fmca;
  }
 
  $fmrcd=str_replace(",","@-@",$fmrcd);
  $fmrcd=str_replace(";","@/@",$fmrcd);
  
  $datademo=str_replace("<datavls>",$fmvalx,$datademo);
  $jsondata=str_replace("<datavls>",$fmvalx,$jsondata);
  
  $jshortpath=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/jsshort.json");
  $jsonpath=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/data.json");
  $coodex=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/coodercd.txt");
  $coodeclstxt=combineurl(localroot(),"/localxres/dataspacex/".$datamark."/coodeclstxt.txt");
  $z0=overfile($jshortpath,$datademo);
  $z1=overfile($jsonpath,$jsondata);
  $newrcd=str_replace("@-@","#"."-#",str_replace("@/@","#"."/#",$fmrcd));
  $z2=overfile($coodex,$newrcd);
  $z3=overfile($coodeclstxt,$clstxt);
//----------------------------------------------------
    echo makereturnjson("1","提交成功",$errs);
  }else{
    echo makereturnjson("0","字段数与字段类型数不一致","");
  }//ifptk pttx
 
 
  
 
     session_write_close();
?>