<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $srcmark=dftval($_GET["srcmark"],"");
$toto=dftval($_GET["toto"],"");
$srcarea=qian($srcmark,"-");
$srcid=hou($srcmark,"-");
if ($srcmark!=""){
 $strudemo='{"dspccode":"[dspccode]","dspctitle":"[dspctitle]","keynames":"[keynames]","ktps":[<kdata>]}';
 $itemdemo='{"keyname":"[keyname]","keytitle":"[keytitle]","dxtype":"[dxtype]","datatype":"[datatype]","keylen":"[keylen]"},';
 $fma="";
  for ($bb=0;$bb<intval($toto);$bb++){
    $titlex=dftval($_POST["title".($bb)],"");  
    $orgid=getRandChar(8);
    //String2Hex($titlex);
    $otypex=dftval($_POST["otype".($bb)],"");
         switch($otypex){
           case "tinyint":
           $keytype="tinyint";
           $keylen="4";
           break;
           case "int":
           $keytype="int";
           $keylen="11";
           break;
           case "varchar20":
           $keytype="varchar";
           $keylen="20";
           break;
           case "varchar50":
           $keytype="varchar";
           $keylen="50";
           break;
           case "varchar100":
           $keytype="varchar";
           $keylen="100";
           break;
           case "varchar255":
           $keytype="varchar";
           $keylen="255";
           break;
           case "varchar1024":
           $keytype="varchar";
           $keylen="1024";
           break;
           case "decimal1":
           $keytype="decimal";
           $keylen="10.1";
           break;
           case "decimal2":
           $keytype="decimal";
           $keylen="10.2";
           break;
           case "decimal3":
           $keytype="decimal";
           $keylen="10.3";
           break;
           case "decimal4":
           $keytype="decimal";
           $keylen="10.4";
           break;
           case "select":
           $keytype="varchar";
           $keylen="1024";
           break;
           case "multiselect":
           $keytype="varchar";
           $keylen="1024";
           break;
           case "checkbox":
           $keytype="varchar";
           $keylen="1024";
           break;
           case "multicheckbox":
           $keytype="varchar";
           $keylen="1024";
           break;
           case "imagex":
           $keytype="varchar";
           $keylen="1024";
           break;
           case "images":
           $keytype="varchar";
           $keylen="1024";
           break;
           case "filex":
           $keytype="varchar";
           $keylen="1024";
           break;
           case "files":
           $keytype="varchar";
           $keylen="1024";
           break;
           case "chtml":
           $keytype="varchar";
           $keylen="1024";
           break;
           default:
         }
    $itemx=$itemdemo;
    $itemx=str_replace("[keyname]",$orgid,$itemx);
    $itemx=str_replace("[keytitle]",$titlex,$itemx);
    $itemx=str_replace("[dxtype]",$otypex,$itemx);
    $itemx=str_replace("[datatype]",$keytype,$itemx);
    $itemx=str_replace("[keylen]",$keylen,$itemx);
    $fma=$fma.$itemx;
    if ($titlex!="" and $titlex!="undefined"){
       $extx=UX("select count(*) as result from coode_dspckey where domainmark='".$srcarea."' and datamark='".$srcid."' and keytitle='".$titlex."' ");
       if (intval($extx)==0){
         $z=UX("insert into coode_dspckey(domainmark,datamark,dxtype,keytype,keylen,keymark,keytitle,CRTM,UPTM,CRTOR)values('".$srcarea."','".$srcid."','".$otypex."','".$ktype."','".$keylen."','".$orgid."','".$titlex."',now(),now(),'".$_COOKIE["uid"]."')");         
       }else{
         $z=UX("update coode_dspckey set UPTM=now(),dxtype='".$otypex."',keytype='".$keytype."',keylen='".$keylen."' where domainmark='".$srcarea."' and datamark='".$srcid."' and keytitle='".$titlex."' ");
       }   
     }
   }
   $fma=killlaststr($fma);
   $strudemo=str_replace("[kdata]",$fma,$strudemo);
   if ($srcid!=""){
     $strujson=combineurl(localroot(),"/localxres/dataspacex/".$srcid."/","structure.json");
   }
   $zz=overfile($strujson,$strudemo);
    $bb=UX("delete from coode_dspckey where timestampdiff(second,UPTM,now())>30 and domainmark='".$srcarea."' and datamark='".$srcid."' ");    
    $sqlx="domainmark,datamark,keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib,CRTM,UPTM,CRTOR,OLMK";
    $zzx=UX("insert into coode_dspckeyx(".$sqlx.")select ".$sqlx." from coode_dspckey where datamark='".$datamark."' and concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey where datamark='".$datamark."')");
    $bbx=UX("delete from coode_dspckeyx where concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey)");
    $zzy=UX("insert into coode_dspckeyy(".$sqlx.")select ".$sqlx." from coode_dspckey where datamark='".$datamark."' and concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey where datamark='".$datamark."')");
    $bby=UX("delete from coode_dspckeyy where concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey)");
    $zzz=UX("insert into coode_dspckeyz(".$sqlx.")select ".$sqlx." from coode_dspckey where datamark='".$datamark."' and concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey where datamark='".$datamark."')");
    $bbz=UX("delete from coode_dspckeyz where concat(datamark,keymark) not in(select concat(datamark,keymark) from coode_dspckey)");
    //在表单表格显示中计算xyz的文件structurex.json
    echo makereturnjson("1","成功","");
}else{
    echo makereturnjson("0","失败","");
}
     session_write_close();
?>