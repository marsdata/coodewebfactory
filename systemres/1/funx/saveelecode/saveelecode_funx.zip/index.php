<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $elemark=dftval($_GET["elemark"],"");
$jsscode=unstrs($_POST["jsscode"]);
$htmlcode=unstrs($_POST["htmlcode"]);
$zz=UX("update coode_tinyhtml set jsscode='".gohex($jsscode)."',htmlcode='".gohex($htmlcode)."' where elemark='".$elemark."'");
$pagesrd=constval("pagesrdcode");
$zz=UX("update coode_tinyhtml set pagesrd='".gohex($pagesrd)."' where elemark='".$elemark."' and pagesrd=''");
$prst=SX("select eletitle,pagesrd,jsscode,htmlcode,jsfilex,cssfilex,widthx,heightx,isfloat from coode_tinyhtml where elemark='".$elemark."'");
$outurly="/localxres/tinyhtml/".$elemark."/index.html";
$outurlx=combineurl(localroot(),$outurly);
$zz=UX("update coode_tinyhtml set outurl='".$outurly."' where elemark='".$elemark."' and outurl=''");
$totp=countresult($prst);
if (intval($totp)>0){
  $jsscode=tostring(anyvalue($prst,"jsscode",0));
  $htmlcode=tostring(anyvalue($prst,"htmlcode",0));
  $pagesrd=tostring(anyvalue($prst,"pagesrd",0));
  $jsfilex=tostring(anyvalue($prst,"jsfilex",0));
  $cssfilex=tostring(anyvalue($prst,"cssfilex",0));
   $eletitle=anyvalue($prst,"eletitle",0);
   $widthx=dftval(anyvalue($prst,"widthx",0),"100%");
   $heightx=dftval(anyvalue($prst,"heightx",0),"100%");
   $isfloat=anyvalue($prst,"isfloat",0);
   $fmjsf=formjs(onlyone($jsfilex));
   $fmcssf=formcss(onlyone($cssfilex));
   $pagesrd=str_replace("{body","{body style=\"text-align:center;width:100%;height:100%;\"",$pagesrd);
   if (intval($isfloat)==1){
       $srddemo=$htmlcode;
   }else{
       $srddemo='{div id="'.$elemark.'elex" style="margin:auto;margin-top:200px;border:1px solid black;width:'.$widthx.';height:'.$heightx.'"}'.huanhang().'[INCODE]'.huanhang().'{/div}';
       $srddemo=str_replace("[INCODE]",$htmlcode,$srddemo);
   }
  $pagesrd=turnlab($pagesrd);    
  if (strpos($jsscode,"!--bottom->")>0){
    $csscode=qian($jsscode,"<!--bottom->");
    $scccode=hou($jsscode,"<!--bottom->");
  }else{
    $csscode=$jsscode;
    $scccode="";
  }
  $pagesrd=str_replace("<!--thistitle-->",$eletitle,$pagesrd);
  $pagesrd=str_replace("<!--thesecomCSSFILES-->",$fmcssf,$pagesrd);
  $pagesrd=str_replace("<!--thesecomJSFILES-->",$fmjsf,$pagesrd);
  $pagesrd=str_replace("<!--thiscomSTYLE-->",$csscode,$pagesrd);
  $pagesrd=str_replace("<!--thiscomSCRIPT-->",$scccode,$pagesrd);
  $pagesrd=str_replace("<!--thiscomHTML-->",turnlab($srddemo),$pagesrd);
  $pagesrd=str_replace("[date]",date("YmdHis"),$pagesrd);
  $zz=overfile($outurlx,$pagesrd);
}
echo makereturnjson("1","成功","");
     session_write_close();
?>