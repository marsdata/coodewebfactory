<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
        $dt=$_POST["dt"];
 $fn=str_replace("()","",$_GET["fn"]);
 
 $dt=unstrs($dt);
 $dt=str_replace('<?php'.huanhang(),'',$dt);
 $dt=str_replace(huanhang().'?>','',$dt);
 
 $dtlen=strlen($dt);
 $bid=onlymark();
 $datax=gohex($dt);
 $odata="";
 $extx=0;
 
  $b=eval(RESFUNSET("recline"));
 
if (isx2($fn,"SNO:","@")){
 $skey=hou($fn,".");
 $sno=qian(hou($fn,"SNO:"),".");
 $tbnm=qian($fn,"@");
 $rst=SX("select SNO,".$skey." as funfull,OLMK as funcname from ".$tbnm."  where SNO='".$sno."' ");
 $odata=UX("select ".$skey." as result from ".$tbnm." where SNO='".$sno."'"); 
}else{
 if (isx1($fn,"@") and !isx1($fn,"SNO:")){
    $ckey=hou($fn,".");
    $tbnm=qian(hou($fn,"@"),".");
    $skey=qian($fn,"@");
    $rst=SX("select SNO,".$skey." as funfull,keytitle as funcname from coode_keydetailx where TABLE_NAME='".$tbnm."'  and COLUMN_NAME='".$ckey."' ");
    $odata=UX("select ".$skey." as result from coode_keydetailx where TABLE_NAME='".$tbnm."'  and COLUMN_NAME='".$ckey."' ");  
    $sysid="";
    $appid="";
 }else{
    $rst=SX("select SNO,funname,funbody,funfull,funcname,sysid,appid from coode_funlist  where funname='".$fn."' or funname='".$fn."()'");
    $odata=anyvalue($rst,"funfull",0);
    $sysid=anyvalue($rst,"sysid",0);
    $appid=anyvalue($rst,"appid",0);    
    $outfun=constval("funtemp");    
    $outfun=str_replace("[relycore]","../../EARTH.php",$outfun);
    $outfun=str_replace("[fundata]",$dt,$outfun);
    $outpath=combineurl(localroot(),"/localxres/funx/".$fn."/index.php");
    $outfun='<?php'.huanhang().$outfun.huanhang().'?>';
    $zz=anyfunrun("auditfunction","","funid=".$fn,"");
    overfile($outpath,$outfun);
    
 }
} 
$totrst=countresult($rst);
$newffl=tostring($datax);
$oldffl=tostring($odata);
if ($totrst>0){  
  $newfbd="";      
  $funnm=anyvalue($rst,"funcname",0);
 if (isx2($fn,"SNO:","@")){
    $skey=hou($fn,".");
    $sno=qian(hou($fn,"SNO:"),".");
    $tbnm=qian($fn,"@");
    $x=UX("update ".$tbnm." set PRIME=1,".$skey."='".$datax."',UPTM=now() where SNO='".$sno."'");
    
    switch($tbnm){
        case "coode_funsetfile":
         $setmark=UX("select setname as result from coode_funsetfile where SNO=".$sno);
         $setlayurl=combineurl(localroot(),"/localxres/sfunx/".$setmark."/index.php");
         $setdata='<?php'.huanhang().$dt.huanhang().'?>';
         $sof=overfile($setlayurl,$setdata);
        break;
        case "coode_multifunlist":
         $mmark=UX("select funname as result from coode_multifunlist where SNO=".$sno);                  
         $moutfun=constval("funtemp");
         $moutfun=str_replace("[fundata]",$dt,$moutfun);
         $moutpath=combineurl(localroot(),"/localxres/mfunx/".$mmark."/index.php");
         $moutfun='<?php'.huanhang().$moutfun.huanhang().'?>';
         $sof=overfile($moutpath,$moutfun);
        case "coode_affairfunlist":
         $amark=UX("select funname as result from coode_affairfunlist where SNO=".$sno);                  
         $aoutfun=constval("funtemp");
         $aoutfun=str_replace("[fundata]",$dt,$aoutfun);
         $aoutpath=combineurl(localroot(),"/localxres/afunx/".$amark."/index.php");
         $aoutfun='<?php'.huanhang().$moutfun.huanhang().'?>';
         $aof=overfile($aoutpath,$aoutfun);
        break;
        case "coode_datafun":
         $dmark=UX("select dfunmark as result from coode_datafun where SNO=".$sno);                  
         $doutfun=constval("dfuntemp");
         $doutfun=str_replace("[fundata]",$dt,$doutfun);
         $doutfun=str_replace("[fid]",$dmark,$doutfun);
         $doutpath=combineurl(localroot(),"/localxres/dfunx/".$dmark."/index.php");
         $doutfun='<?php'.huanhang().$doutfun.huanhang().'?>';
         $dof=overfile($doutpath,$doutfun);
        break;
        case "coode_sysconstant":
         $cmark=UX("select constantid as result from coode_sysconstant where SNO=".$sno);                  
         $coutfun=constval("consttemp");         
         $coutpath=combineurl(localroot(),"/localxres/constx/".$cmark."/index.php");
         $coutfun='<?php'.huanhang().$coutfun.huanhang().'?>';
         $cof=overfile($coutpath,$coutfun);
         $coutpath1=combineurl(localroot(),"/localxres/constx/".$cmark."/val.txt");
         $cof1=overfile($coutpath1,$dt);
        break;
        case "coode_keydetailx":
             $tabnmx=UX("select TABLE_NAME as result from coode_keydetailx where SNO=".$sno);
             $colurl=combineurl("http://".glw(),"/localxres/funx/tabcol/?tablename=".$tabnmx."&cid=".$_COOKIE["cid"]."&uid=".$_COOKIE["uid"]);
             $zz2=UX("update coode_tablist set PRIME=1 where TABLE_NAME='".$tabnmx."'");
             $zz=file_get_contents($colurl);
        break;
        case "coode_keydetaily":
             $shortid=UX("select shortid as result from coode_keydetaily where SNO=".$sno);
             $qc=file_get_contents("http://".glw()."localxres/funx/shortcol/?shortid=".$shortid."&cid=".$_COOKIE["cid"]."&uid=".$_COOKIE["uid"]);
             $zzx=file_get_contents(combineurl("http://".glw(),"/localxres/funx/shortdft/?shortid=".$shortid."&cid=".$_COOKIE["cid"]."&uid=".$_COOKIE["uid"]));
             $zz2=UX("update coode_shortdata set OPRT='3.14' where shortid='".$shortid."'");
        break;
        case "coode_iconset":
        $zz=UX("update coode_iconset set outpath=concat('".combineurl(localroot(),"/localxres/iconsetx/imgcls/")."',setmark,'.svg'),outurl=concat('/localxres/iconsetx/imgcls/',setmark,'.svg') where outurl='' or outpath=''");
        break;
        default:
    }
    
 }else{
  if (isx1($fn,"@") and !isx1($fn,"SNO:")){
    //这里都是表格变动后端脚本，对前端没影响
    $ckey=hou($fn,".");
    $tbnm=qian(hou($fn,"@"),".");
    $ut=UX("update coode_tablist set OPRT='3.14' where TABLE_NAME='".$tbnm."'");
    $skey=qian($fn,"@");  
    $x=UX("update coode_keydetailx set ".$skey."='".$datax."',UPTM=now(),PRIME=1 where TABLE_NAME='".$tbnm."' and COLUMN_NAME='".$ckey."'");    
  }else{    
    $x=UX("update coode_funlist set funfull='".$datax."',PRIME=1,UPTM=now() where funname='".$fn."' or funname='".$fn."()'");    
             
  }
 }  
}else{ 
 if ($totrst==0){
  if (!isx1($fn,"@")){
    if ($fn!=""){      
      $nx=UX("insert into coode_funlist(funname,funbody,funfull,CRTM,UPTM,CRTOR,OLMK,PTOF,STATUS,ispmiss,PRIME)values('".str_replace("()","",$fn)."','','".$datax."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."','".myfirstpos()."',1,1,1)"); 
    }
  }
 }
};
if ($fn!=""){
  if (isx2($fn,"SNO:","@")){
  }else{
      if (isx1($fn,"@") and !isx1($fn,"SNO:")){
        $srclenx= checklines($odata,$datax);
        $olenx=qian($srclenx,"/");
        $nlenx=hou($srclenx,"/");
        $kx=reclines($tbnm,$tbnm,$fn,$fn,"tabaction",$olenx,$nlenx,$datax);
      }else{
        $srclenx= checklines($odata,$datax);
        $olenx=qian($srclenx,"/");
        $nlenx=hou($srclenx,"/");
        $kx=reclines($fn,$fn,$fn,$fn,"function",$olenx,$nlenx,$datax);
      }
  }
  echo makereturnjson("1","提交成功","");
}else{
  echo makereturnjson("0","提交失败","");
}
       session_write_close();
?>