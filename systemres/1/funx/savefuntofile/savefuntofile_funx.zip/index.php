<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
         $funsno=dftval($_GET["funsno"],"");
  $funid=dftval($_GET["funid"],"");
  $rst=SX("select SNO,funname,funbody,funfull,funcname,sysid,afffuns from coode_funlist  where SNO='".$funsno."' or funname='".$funid."' or funname='".$funid."()'");
  $totr=countresult($rst);
  if ($totr>0){
  $fsno=anyvalue($rst,"SNO",0);
  $fn=str_replace("()","",anyvalue($rst,"funname",0));
  $afunx="/,".anyvalue($rst,"afffuns",0).",";
  $odata=tostring(anyvalue($rst,"funfull",0));  
  $outfun=constval("idpfunt");
  $first=constval("phpdft");
  //$parafile=combineurl(localroot(),"/localxres/dataspacex/sitebase/jsshort.json");
  //$jstxt=file_get_contents($parafile);
  //$jsdata=json_decode($jstxt,false);
  //$vls=$jsdata->vls;
  $fmbase="";
  //for ($cc=0;$cc<count($vls);$cc++){
   //$sitekey=$vls[$cc]->sitekey;
   //$siteval=$vls[$cc]->siteval;
   //$first=str_replace("[".$sitekey."]",$siteval,$first);
  //}
  $fmbase=$fmbase.$first.huanhang();
  $crst=SX("select funname,filelcpath from coode_funcool where '".$afunx."' like concat('%,',funname,',%')");
  $totc=countresult($crst);
  for  ($cc=0;$cc<$totc;$cc++){
   $fxpath=anyvalue($crst,"filelcpath",$cc);
   $fxtxt=file_get_contents($fxpath);
   $fmbase=$fmbase.$fxtxt.huanhang();
  }
  $outfun=str_replace("[relycore]",$fn."_base.php",$outfun);  
  $outfun=str_replace("[fundata]",$odata,$outfun);  
  $basepath=combineurl(localroot(),"/localxres/funx/".$fn."/idp/".$fn."_base.php");
  $outpath=combineurl(localroot(),"/localxres/funx/".$fn."/idp/".$fn."_index.php");
  $outfun='<?php'.huanhang().$outfun.huanhang().'?>';
  $basefun='<?php'.huanhang().$fmbase.huanhang().'?>';
  overfile($outpath,$outfun);
  overfile($basepath,$basefun);
  $zz=UX("update coode_funlist set isiden=1 where SNO='".$funsno."' or funname='".$funid."' or funname='".$funid."()'");
  echo makereturnjson("1","生成不依赖环境且独立的脚本成功".$funsno,"");
  }else{
  echo makereturnjson("0","生成不依赖环境且独立的脚本失败".$funsno,"");
  }
       session_write_close();
?>