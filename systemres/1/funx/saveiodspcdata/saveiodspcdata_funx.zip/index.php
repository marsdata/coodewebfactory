<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $datamark=dftval($_GET["datamark"],"");
$areamark=dftval($_GET["areamark"],"");
$totrcd=dftval($_GET["totrcd"],"");
$allkeys=dftval($_GET["allkeys"],"");
$alltps=dftval($_GET["alltps"],"");
$ptkx=explode(",",$allkeys);
$pttx=explode(",",$alltps);
$pdata=dftval(unstrs($_POST["pdata"]),"");
$ptdata=explode("@/@",$pdata);
$totptd=count($ptdata);
$totkx=count($ptkx);
$totktp=count($pttx);
$urlx="http://".glm()."/DNA/EXF/anyfuns.php?fid=saveioxdspcval&areamark=".$areamark."&datamark=".$datamark."&totrcd=".$totrcd."&allkeys=".$allkeys."&alltps=".$alltps."&apikey=".gla()."&apiverify=".glv();
$postdata["pdata"]=$pdata;
$bktxt=request_post($urlx,$postdata);
$bkdata=json_decode($bktxt,false);
if (intval($bkdata->status)==1){
  $errs="";
  if ($totkx==$totktp){ 
  for ($j=0;$j<$totptd;$j++){
   if ($ptdata[$j]!=""){
     $ptval=explode("@-@",$ptdata[$j]);
     if (strpos("x".$alltps,"text")>0){
       $tempptdata="";
     }else{
       $tempptdata=hou($ptdata[$j],"@-@");
     }
     if (($totkx+1)==count($ptval)){
       $zz=UX("insert into iO_dspcVIndex(srcArea,spcMark,datasNo,keyMarks,valMd5,keyVals,itemCTime,itemUTime,itemCrtID,itemOnlyMark)values('".$areamark."','".$datamark."','".($j)."','".$allkeys."','".md5(hou($ptdata[$j],"@-@"))."','".$tempptdata."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."') ON DUPLICATE KEY update itemUTime=now(),keyMarks='".$allkeys."',valMd5='".md5(hou($ptdata[$j],"@-@"))."',keyVals='".$tempptdata."'");       
       $extd=UX("select count(*) as result from iO_dspcVal where srcArea='".$areamark."' and spcMark='".$datamark."' and datasNo='".($j)."'");          
       if ($extd==count($ptkx) ){
         for ($p=0;$p<count($ptkx);$p++){
          $kxx=$pttx[$p]."val";
          $dx=UX("update iO_dspcVal set ".$kxx."='".$ptval[$p+1]."',itemCTime=now() where srcArea='".$areamark."' and spcMark='".$datamark."' and datasNo='".($j)."' and keyMark='".$ptkx[$p]."'");      
         }    
       }else{  
        // $errs=$errs."保存数与数据字段数不一致";
         $zz=UX("delete from iO_dspcVal where srcArea='".$areamark."' and spcMark='".$datamark."' and datasNo='".($j)."'");
         $tt=UX("insert into iO_dspcVal(srcArea,spcMark,datasNo,keyMark,keyTitle,keyType,keyLen,itemCTime,itemUTime,itemOnlyMark)select srcArea,spcMark,'".($j)."',keyMark,keyTitle,keyType,keyLen,now(),now(),RAND()*1000000 from iO_dspcKey where spcMark='".$datamark."'");
         for ($p=0;$p<count($ptkx);$p++){
          $kxx=$pttx[$p]."val";
          $dx=UX("update iO_dspcVal set ".$kxx."='".$ptval[$p+1]."',itemUTime=now() where srcArea='".$areamark."' and spcMark='".$datamark."' and datasNo='".($j)."' and keyMark='".$ptkx[$p]."'");      
         }    
       }//ifextd 存储数据数与字段数一样
      }//ptkx-ptval分割后值与字段数量相同
     }else{
      //$errs=$errs."分割项与值数不一致(".count($ptkx)."-".count($ptval).")";
     }//ifptdata 分割项不能为空
    }//for    
    $zzs=UX("delete from iO_dspcVal where timestampdiff(second,itemUTime,now())>9 and spcMark='".$datamark."' and srcArea='".$areamark."'");
    $zzb=UX("delete from iO_dspcVIndex where timestampdiff(second,itemUTime,now())>9 and spcMark='".$datamark."' and srcArea='".$areamark."'");
    $px=UX("update iO_dataSpace set itemPUTime=now() where spcMark='".$datamark."' and srcArea='".$areamark."'");
    echo makereturnjson("1","提交成功",$errs);
  }else{
    echo makereturnjson("0","字段数与字段类型数不一致","");
  }//ifptk pttx
}else{
 echo $bktxt;
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>