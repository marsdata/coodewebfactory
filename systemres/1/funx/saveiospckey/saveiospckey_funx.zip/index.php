<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $datamark=dftval($_GET["datamark"],"");
$areamark=dftval($_GET["areamark"],"");
$datatitle=dftval($_GET["datatitle"],"");
$lenx=dftval($_GET["lenx"],"");
$oldrst=SX("select sNo,keyMark,keyType,keyLen,dxType,keyTitle from iO_dspcKey where spcMark='".$datamark."'");
$totold=countresult($oldrst);
for ($m=0;$m<$totold;$m++){
 $keyid=anyvalue($oldrst,"keyMark",$m);
 $keydatatype[$keyid]=anyvalue($oldrst,"keyType",$m);
 $keydxtype[$keyid]=anyvalue($oldrst,"dxType",$m);
 $keylenx[$keyid]=anyvalue($oldrst,"keyLen",$m);
 $keytitle[$keyid]=anyvalue($oldrst,"keyTitle",$m);
 $oldkeyids=$oldkeyids.$keyid.",";
}
if (intval($totold)==0){
   $sqla="spcMark,dataTitle,itemCTime,itemUTime,itemPUTime,itemOnlyMark";
   $sqlb="'".str_replace(" ","",$datamark)."','".str_replace(" ","",$datatitle)."',now(),now(),now(),'".onlymark()."'";
   $qq=UX("insert into iO_dataSpace(".$sqla.")values(".$sqlb.")");   
}
$tmpj=0;
$prekeys="";
$oldkeyids="xx,".$oldkeyids;
$urlx="http://".glm()."/DNA/EXF/anyfuns.php?fid=saveioxdspckey&areamark=".$areamark."&datamark=".$datamark."&datatitle=".$datatitle."&lenx=".$lenx."&apikey=".gla()."&apiverify=".glv();
for ($i=0;$i<intval($lenx);$i++){
  $postdata["colid".$i]=$_POST["colid".$i];
  $postdata["coltitle".$i]=$_POST["coltitle".$i];
  $postdata["collen".$i]=$_POST["collen".$i];
  $postdata["coldes".$i]=$_POST["coldes".$i];
  $postdata["coldatatype".$i]=$_POST["coldatatype".$i];
  $postdata["coldxtype".$i]=$_POST["coldxtype".$i];
}
$datatxt=request_post($urlx,$postdata);
$datax=json_decode($datatxt,false);
if (intval($datax->status)==1){
  for ($i=0;$i<intval($lenx);$i++){
    $colid=dftval(str_replace(" ","",$_POST["colid".$i]),""); 
    $coltitle=dftval(str_replace(" ","",$_POST["coltitle".$i]),"");
    $collen=dftval(str_replace(" ","",$_POST["collen".$i]),"");
    $coldes=dftval(str_replace(" ","",$_POST["coldes".$i]),"");
    $coldatatype=dftval(str_replace(" ","",$_POST["coldatatype".$i]),"");
    $coldxtype=dftval(str_replace(" ","",$_POST["coldxtype".$i]),"");
    $tbnmx=$tabmark;
    $cname=$colid;
    $prekeys=$prekeys.$colid.",";
   if (strpos($oldkeyids,",".$colid.",")>0){
     $zz=UX("update iO_dspcKey set itemUTime=now() where srcArea='".$areamark."' and spcMark='".$datamark."' and keyMark='".$colid."'");
      if (intval($collen)!=intval($keylenx[$colid]) or $coldatatype!=$keydatatype[$colid]){
         switch ($coldatatype){
          case "int":
           $yy=UX("update iO_dspcKey set itemUTime=now(),keyTitle='".$coltitle."',keyLen=11,sQx='".$i."',keyType='int',dxType='int' where srcArea='".$areamark."' and spcMark='".$datamark."' and keyMark='".$colid."'");
          break;
          case "tinyint":        
           $yy=UX("update iO_dspcKey set itemUTime=now(), keyTitle='".$coltitle."',keyLen=4,sQx='".$i."',keyType='tinyint',dxType='tinyint' where srcArea='".$areamark."' and spcMark='".$datamark."' and keyMark='".$colid."'");
          break;
          case "varchar":
          if ($mlen=="" or $mlen=="un"."defined"){
           $mlen="255";
          }
          $yy=UX("update iO_dspcKey set itemUTime=now(), keyTitle='".$coltitle."',keyLen='".$mlen."',sQx='".$i."',keyType='varchar',dxType='varchar255' where srcArea='".$areamark."' and spcMark='".$datamark."' and keyMark='".$colid."'");
          break;
          case "date":
           $yy=UX("update iO_dspcKey set itemUTime=now(), keyTitle='".$coltitle."',keyLen='".$mlen."',sQx='".$i."',keyType='date',dxType='date' where srcArea='".$areamark."' and spcMark='".$datamark."' and keyMark='".$colid."'");
          break;
          case "datetime":
           $yy=UX("update iO_dspcKey set itemUTime=now(), keyTitle='".$coltitle."',keyLen='".$mlen."',sQx='".$i."',keyType='datetime',dxType='datetime' where srcArea='".$areamark."' and spcMark='".$datamark."' and keyMark='".$colid."'");
          break;
          case "text":
           $yy=UX("update iO_dspcKey set itemUTime=now(), keyTitle='".$coltitle."',keyLen='".$mlen."',sQx='".$i."',keyType='text',dxType='text' where spcMark='".$datamark."' and keyMark='".$colid."'");
          break;
          case "longtext":
           $yy=UX("update iO_dspcKey set itemUTime=now(), keyTitle='".$coltitle."',keyLen='".$mlen."',sQx='".$i."',keyType='longtext',dxType='longtext' where srcArea='".$areamark."' and spcMark='".$datamark."' and keyMark='".$colid."'");
          break;
          default:
         }//swc
       }else{          
       }//if change
     }else{    
       $coid[$tmpj]=$colid;
       $cott[$tmpj]=$coltitle;
       $colen[$tmpj]=$collen;
       $codes[$tmpj]=$coldes;
       $codtp[$tmpj]=$coldatatype;
       $codxtp[$tmpj]=$coldxtype;     
       $sqlx="keyType,keyLen,keyTitle,keyDescrib,dxType";
       if ($colid!=""){
        $zz=UX("insert into iO_dspcKey(srcArea,spcMark,keyMark,".$sqlx.",itemCTime,itemUTime,sQx)values('".$areamark."','".$datamark."','".$colid."','".$coldatatype."','".$collen."','".$coltitle."','".$coldes."','".$coldxtype."',now(),now(),'".$i."')");       
       }
       $tmpj=$tmpj+1;  
     }//in
   }//for
   $darst=SX("select datasMo,dataMark from iO_dspcVIndex where spcMark='".$datamark."' and srcArea='".$areamark."'");
   for ($m=0;$m<countresult($darst);$m++){
    $dsn=anyvalue($darst,"datasNo",$m);
    $tt=UX("insert into iO_dspcVal(srcArea,spcMark,datasNo,keyMark,keyTitle,keyType,keyLen,itemCTime,itemUTime,itemOnlyMark)select srcArea,spcMark,'".($dsn)."',keyMark,keyTitle,keyType,keyLen,now(),now(),RAND()*1000000 from iO_dspcKey where spcMark='".$datamark."' and concat(spcMark,'".$dsn."',keyMark) not in(select concat(spcMark,datasNo,keyMark) from iO_dspcVal)");  
   }
   $xx=UX("update iO_dspcVIndex set itemPUTime=now() where spcMark='".$datamark."' and srcArea='".$areamark."'");
   $KX=UX("delete from iO_dspcKey where timestampdiff(second,itemUTime,now())>15 and spcMark='".$datamark."' and srcArea='".$areamark."'");
   $bb=UX("delete from iO_dspcVal where spcMark='".$datamark."' and srcArea='".$areamark."' and keyMark not in(select keyMark from iO_dspcKey where spcMark='".$datamark."' and srcArea='".$areamark."')");
 echo makereturnjson("1","修改成功","");
}else{
 echo $datatxt;
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>