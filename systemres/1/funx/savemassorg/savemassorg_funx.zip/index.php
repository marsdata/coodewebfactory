<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $bsmark=dftval($_GET["bsmark"],"");
$toto=dftval($_GET["toto"],"");
if ($bsmark!=""){
  $fmtt="";
  for ($bb=0;$bb<intval($toto);$bb++){
    $titlex=dftval($_POST["coltt".($bb+1)],"");  
    $orgid=chitopyx($titlex)."_".getRandChar(3);    
    $otypex=dftval($_POST["coltp".($bb+1)],"");
    $fmtt=$fmtt.$titlex.",";
         switch($otypex){
           case "tinyint":
           $keytype="tinyint";
           $keylen="4";
           break;           
           case "int":
           $keytype="int";
           $keylen="11";
           break;
           case "varchar":
           $keytype="varchar";
           $keylen="255";
           break;
           case "varchar20":
           $keytype="varchar";
           $keylen="20";
           break;
           case "varchar50":
           $keytype="varchar";
           $keylen="50";
           break;
           case "varchar100":
           $keytype="varchar";
           $keylen="100";
           break;
           case "varchar255":
           $keytype="varchar";
           $keylen="255";
           break;
           case "varchar1024":
           $keytype="varchar";
           $keylen="1024";
           break;
           case "decimal1":
           $keytype="decimal";
           $keylen="10.1";
           break;
           case "decimal2":
           $keytype="decimal";
           $keylen="10.2";
           break;
           case "decimal3":
           $keytype="decimal";
           $keylen="10.3";
           break;
           case "decimal4":
           $keytype="decimal";
           $keylen="10.4";
           break;
           case "select":
           $keytype="varchar";
           $keylen="1024";
           break;
           case "multiselect":
           $keytype="varchar";
           $keylen="1024";
           break;
           case "checkbox":
           $keytype="varchar";
           $keylen="1024";
           break;
           case "multicheckbox":
           $keytype="varchar";
           $keylen="1024";
           break;
           case "imagex":
           $keytype="varchar";
           $keylen="1024";
           break;
           case "images":
           $keytype="varchar";
           $keylen="1024";
           break;
           case "filex":
           $keytype="varchar";
           $keylen="1024";
           break;
           case "files":
           $keytype="varchar";
           $keylen="1024";
           break;
         }
    if ($titlex!="" and $titlex!="undefined"){
       $extx=UX("select count(*) as result from coode_wrdgrpbra where bragrpcode='".$bsmark."'  and brarestitle='".$titlex."' ");
       if (intval($extx)==0){
         $z=UX("insert into coode_wrdgrpbra(bragrpcode,brarescode,brarestitle,dxtype,dktype,CRTM,UPTM,CRTOR)values('".$bsmark."','".$orgid."','".$titlex."','".$otypex."','".$keytype."(".$keylen.")',now(),now(),'".$_COOKIE["uid"]."')");         
       }else{
         $z=UX("update coode_wrdgrpbra set UPTM=now(),dxtype='".$otypex."',dktype='".$keytype."(".$keylen.")' where  bragroupcode='".$bsmark."' and brarestitle='".$titlex."' ");
       }   
     }
     
   }//for
   $fmtt=killlaststr($fmtt);
   $pttt=explode(",",$fmtt);
   $tott=count($pttt);
    $ZZ=UX("update coode_wrdbragroup set STATUS=1 where brasetmark='".$bsmark."'");
    echo makereturnjson("1","成功","");
}else{
    echo makereturnjson("0","失败","");
}
     session_write_close();
?>