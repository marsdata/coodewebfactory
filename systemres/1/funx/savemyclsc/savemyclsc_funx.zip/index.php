<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     //这是保存函数的FID=SAVEFUNC 方法，你点保存就是执行此方法，所以修改出错之后系统无法运行，请改此文件慎重
$dt=$_POST["dt"];
$fn=$_GET["fn"];
$fn=str_replace("()","",$fn);
$fn=str_replace(" ","",$fn);
$dt=unstrs($dt);
$dt=str_replace('<?php'.huanhang(),'',$dt);
$dt=str_replace(huanhang().'?>','',$dt);
$dt=str_replace(tabstr(),"    ",$dt);
$datax=gohex($dt);
$conn=mysql_connect(gl(),glu(),glp());
 $rst=selectedx($conn,glb(),"select SNO,funname,funbody,funfull,funcname,sysid,appid from coode_mycls  where funname='".$fn."' or funname='".$fn."()'","utf8","");
$totrst=countresult($rst);
$extx=intval(UX("select count(*) as result from coode_afmyspace where askforstr='".$fn."' and (askforwhat='clsname' or askforwhat='cls') and accstt=1 and etel='".$_COOKIE["uid"]."'"));
$bid=onlymark();
$newffl=tostring($datax);
if ($totrst>0 and $extx>0){
  $oldfbd=anyvalue($rst,"funbody",0);
  $funnm=anyvalue($rst,"funcname",0);
  $odata=anyvalue($rst,"funfull",0);
  $sysid=anyvalue($rst,"sysid",0);
  $appid=anyvalue($rst,"appid",0);
  $oldffl=tostring($odata);
  $newfbd="";   
  $conn=mysql_connect(gl(),glu(),glp());
  $x=updatingx($conn,glb(),"update coode_mycls set funfull='".$datax."',PRIME=1,UPTM=now() where funname='".$fn."' or funname='".$fn."()'","utf8");
      
}else{
 if ($totrst==0){
  if ($fn!=""){
   $conn=mysql_connect(gl(),glu(),glp());
   $newx=updatingx($conn,glb(),"insert into coode_mycls(funname,funbody,funfull,CRTM,UPTM,CRTOR,OLMK,PTOF,STATUS,ispmiss,PRIME)values('".str_replace("()","",$fn)."','','".$datax."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."','".myfirstpos()."',1,1,1)","utf8"); 
  }
 }
};
if ($fn!=""){
 
 if ($extx>0){
    $srclenx= checklines($odata,$datax);
    $olenx=qian($srclenx,"/");
    $nlenx=hou($srclenx,"/");
    $kx=recmylines($fn,$fn,$fn,$fn,"cls",$olenx,$nlenx,$datax);
  echo "1";
 }else{
  echo "0:nopmt";
 }
}else{
 echo "0";
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>