<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $dt=$_POST["dt"];
$fn=str_replace("()","",$_GET["fn"]);
$parall=$_GET["parall"];
$dt=unstrs($dt);
$dt=str_replace('<?php'.huanhang(),'',$dt);
$dt=str_replace(huanhang().'?>','',$dt);
$dt=str_replace(tabstr(),"     ",$dt);
$dtlen=strlen($dt);
 $bid=onlymark();
 $datax=gohex($dt);
 $odata="";
 $extx=0;
if (isx2($fn,"SNO:","@")){
 $skey=hou($fn,".");
 $sno=qian(hou($fn,"SNO:"),".");
 $tbnm=qian($fn,"@");
 $rst=SX("select SNO,".$skey." as funfull,OLMK as funcname from ".$tbnm."  where SNO='".$sno."' ");
 $odata=UX("select ".$skey." as result from ".$tbnm." where SNO='".$sno."'");
 $extx=intval(UX("select count(*) as result from coode_afspace where askforstr='".$tbnm."' and (askforwhat='tablename' or askforwhat='tab') and accstt=1 and etel='".$_COOKIE["uid"]."'")); 
}else{
 if (isx1($fn,"@") and !isx1($fn,"SNO:")){
   $ckey=hou($fn,".");
   $tbnm=qian(hou($fn,"@"),".");
   $skey=qian($fn,"@");
   $rst=SX("select SNO,".$skey." as funfull,keytitle as funcname from coode_keydetailx where TABLE_NAME='".$tbnm."'  and COLUMN_NAME='".$ckey."' ");
   $odata=UX("select ".$skey." as result from coode_mydbkeydx where TABLE_NAME='".$tbnm."'  and COLUMN_NAME='".$ckey."' ");
   $extx=intval(UX("select count(*) as result from coode_afmyspace where askforstr='".$tbnm."' and (askforwhat='tablename' or askforwhat='tab') and accstt=1 and etel='".$_COOKIE["uid"]."'"));
   $sysid="";
   $appid="";
 }else{
   $rst=SX("select SNO,funname,funbody,funfull,funcname,sysid,appid from coode_myfun  where funname='".$fn."' or funname='".$fn."()'");
   $odata=anyvalue($rst,"funfull",0);
   $sysid=anyvalue($rst,"sysid",0);
   $appid=anyvalue($rst,"appid",0);
   $extx=intval(UX("select count(*) as result from coode_afmyspace where askforstr='".$fn."' and (askforwhat='funname' or askforwhat='fun') and accstt=1 and etel='".$_COOKIE["uid"]."'"));
 }
} 
$totrst=countresult($rst);
$newffl=tostring($datax);
$oldffl=tostring($odata);
if ($totrst>0 and $extx>0){  
   $newfbd="";    
   $funnm=anyvalue($rst,"funcname",0);      
 if (isx2($fn,"SNO:","@")){
   $skey=hou($fn,".");
   $sno=qian(hou($fn,"SNO:"),".");
   $tbnm=qian($fn,"@");  
   $x=UX("update ".$tbnm." set ".$skey."='".$datax."',UPTM=now() where SNO='".$sno."'");   
 }else{
  if (isx1($fn,"@") and !isx1($fn,"SNO:")){
     $ckey=hou($fn,".");
     $tbnm=qian(hou($fn,"@"),".");
     $skey=qian($fn,"@");  
     if ($parall==""){
       $x=UX("update coode_dbmykeydx set ".$skey."='".$datax."',UPTM=now(),PRIME=1 where TABLE_NAME='".$tbnm."' and COLUMN_NAME='".$ckey."'");   
     }else{
       $x=UX("update coode_tabparallel set ".$skey."='".$datax."',UPTM=now() where tablename='".$tbnm."' and tabkey='".$ckey."'");   
     }
  }else{   
     if ($parall==""){
      $x=UX("update coode_myfun set funfull='".$datax."',PRIME=1,UPTM=now() where funname='".$fn."' or funname='".$fn."()'");   
     }else{   
      $x=UX("update coode_funparallel set funfull='".$datax."',PRIME=1,UPTM=now() where (funname='".$fn."' or funname='".$fn."()') and parallmark='".$parall."'");   
     }
     if (glm()=="[motherhost]"){
      $mhost=qian(glw(),"/");
     }else{
      $mhost=glm();
     }
       
  }
 }  
}else{ 
 if ($totrst==0){
  if (!isx1($fn,"@")){
   if ($fn!=""){
    $nx=UX("insert into coode_myfun(funname,funbody,funfull,CRTM,UPTM,CRTOR,OLMK,PTOF,STATUS,ispmiss,PRIME)values('".str_replace("()","",$fn)."()','','".$datax."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."','".myfirstpos()."',1,1,1)"); 
   }
  }
 }
};
if ($fn!=""){
  if (isx2($fn,"SNO:","@")){
  }else{
    if (isx1($fn,"@") and !isx1($fn,"SNO:")){
      $srclenx= checklines($odata,$datax);
      $olenx=qian($srclenx,"/");
      $nlenx=hou($srclenx,"/");
      $kx=recmylines($tbnm,$tbnm,$fn,$fn,"tabaction",$olenx,$nlenx,$datax);
    }else{
      $srclenx= checklines($odata,$datax);
      $olenx=qian($srclenx,"/");
      $nlenx=hou($srclenx,"/");
      $kx=recmylines($fn,$fn,$fn,$fn,"function",$olenx,$nlenx,$datax);
    }
  }
  
  echo "1";
}else{
  echo "0";
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>