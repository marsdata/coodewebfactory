<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     function tempdefault(){
 $dft='{!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"}
{html xmlns="http://www.w3.org/1999/xhtml"}
{!--本页面由酷德WEB工厂合成，此页面若含有您所开发资源，请申诉，版权申诉地址 http(s)://'.glw().'SYS/1/userrequest/ --}
{!--本页面由酷德WEB工厂合成，此页面若含有错误，请提交工单，工单提交地址 http(s)://'.glw().'SYS/1/userrequest/finderr.html --}
{head}
{meta http-equiv="Content-Type" content="text/html; charset=utf-8" /}
{title}{!--thistitle--}{/title}
{!--thesecomCSSFILES--}
{!--thesecomJSFILES--}
{!--shortJSFILES--}
{!--shortCSSFILES--}
{!--thiscomSTYLE--}
{!--shortSTYLE--}
{/head}
{body}
  {!--thiscomHTML--}
  {!--thiscomSCRIPT--}
  {!--shortSCRIPT--}
{/body}
{/html}
 ';
 return $dft;
}
function mbltmpdft(){
 $dft='{!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"}
{html}
{!--本页面由酷德WEB工厂合成，此页面若含有您所开发资源，请申诉，版权申诉地址 http(s)://'.glw().'SYS/1/userrequest/ --}
{!--本页面由酷德WEB工厂合成，此页面若含有错误，请提交工单，工单提交地址 http(s)://'.glw().'SYS/1/userrequest/finderr.html --}
{head}
{meta charset="utf-8"}
{meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" /}
{meta name="format-detection" content="telephone=no,email=no,date=no,address=no"}
{title}{!--thistitle--}{/title}
{!--thesecomCSSFILES--}
{!--thesecomJSFILES--}
{!--shortJSFILES--}
{!--shortCSSFILES--}
{!--thiscomSTYLE--}
{!--shortSTYLE--}
{/head}
{body}
  {!--thiscomHTML--}
  {!--thiscomSCRIPT--}
  {!--shortSCRIPT--}
{/body}
{/html}
 ';
 return $dft;
}
function zhushifu(){
 return "/"."/";
}
function casedft($typex,$dm,$dk){
 switch($typex){
  case "form":
  $dft=zhushifu().'before var-- stid,snox, $dxtp,$itemcode,$colname,$snox,$ktitle,$dtype,$clstxt,$thusvalue,$cg,$dspl stid,sttab, ,$colname,$snox,$ktitle$tbnmx,$dvalue,$dsno,$dkey,$sfun,$dn
        '.zhushifu().'shortdata sttt=anyvalue($strst,"shorttitle",0);$sttab=anyvalue($strst,"tablename",0);skeys=anyvalue($strst,"showkeys",0);
        '.zhushifu().'shortcss diytop=tostring(anyvalue($diyrst,"diytop",0));diybottom=tostring(anyvalue($diyrst,"diybottom",0));casecodey=tostring(anyvalue($diyrst,"casecode",0));
        $ccode["varchar"]=getmycodedemo("varchar","'.$dm.'","'.$dk.'");
        $ccode["chtml"]=getmycodedemo("chtml","'.$dm.'","'.$dk.'");
        $ccode["text"]=getmycodedemo("text","'.$dm.'","'.$dk.'");
        $ccode["tarea"]=getmycodedemo("tarea","'.$dm.'","'.$dk.'");
        $ccode["clstxt"]=getmycodedemo("clstxt","'.$dm.'","'.$dk.'");
        $ccode["clsduo"]=getmycodedemo("clsduo","'.$dm.'","'.$dk.'");
        $ccode["date"]=getmycodedemo("date","'.$dm.'","'.$dk.'");
        $ccode["dttm"]=getmycodedemo("dttm","'.$dm.'","'.$dk.'");
        $ccode["int"]=getmycodedemo("int","'.$dm.'","'.$dk.'");
        $ccode["decimal"]=getmycodedemo("decimal","'.$dm.'","'.$dk.'");
        $ccode["image"]=getmycodedemo("image","'.$dm.'","'.$dk.'");
        $ccode["imgx"]=getmycodedemo("imgx","'.$dm.'","'.$dk.'");
        $ccode["filex"]=getmycodedemo("filex","'.$dm.'","'.$dk.'");
        $ccode["duofile"]=getmycodedemo("duofile","'.$dm.'","'.$dk.'");
        $ccode["check"]=getmycodedemo("check","'.$dm.'","'.$dk.'");
        $ccode["checkduo"]=getmycodedemo("checkduo","'.$dm.'","'.$dk.'");
        $ccode["varcharSRD"]=getmycodedemo("varcharSRD","'.$dm.'","'.$dk.'");        
        $ccode["textSRD"]=getmycodedemo("textSRD","'.$dm.'","'.$dk.'");
        $ccode["tareaSRD"]=getmycodedemo("tareaSRD","'.$dm.'","'.$dk.'");
        $ccode["clstxtSRD"]=getmycodedemo("clstxtSRD","'.$dm.'","'.$dk.'");
        $ccode["clsduoSRD"]=getmycodedemo("clsduoSRD","'.$dm.'","'.$dk.'");
        $ccode["dateSRD"]=getmycodedemo("dateSRD","'.$dm.'","'.$dk.'");
        $ccode["dttmSRD"]=getmycodedemo("dttmSRD","'.$dm.'","'.$dk.'");
        $ccode["intSRD"]=getmycodedemo("intSRD","'.$dm.'","'.$dk.'");
        $ccode["decimalSRD"]=getmycodedemo("decimalSRD","'.$dm.'","'.$dk.'");
        $ccode["imageSRD"]=getmycodedemo("imageSRD","'.$dm.'","'.$dk.'");
        $ccode["imgxSRD"]=getmycodedemo("imgxSRD","'.$dm.'","'.$dk.'");
        $ccode["filexSRD"]=getmycodedemo("filexSRD","'.$dm.'","'.$dk.'");
        $ccode["duofileSRD"]=getmycodedemo("duofileSRD","'.$dm.'","'.$dk.'");
        $ccode["checkSRD"]=getmycodedemo("checkSRD","'.$dm.'","'.$dk.'");
        $ccode["checkduoSRD"]=getmycodedemo("checkduoSRD","'.$dm.'","'.$dk.'");
        $ccode["varcharINLINE"]=getmycodedemo("varcharINLINE","'.$dm.'","'.$dk.'");        
        $ccode["textINLINE"]=getmycodedemo("textINLINE","'.$dm.'","'.$dk.'");
        $ccode["tareaINLINE"]=getmycodedemo("tareaINLINE","'.$dm.'","'.$dk.'");
        $ccode["clstxtINLINE"]=getmycodedemo("clstxtINLINE","'.$dm.'","'.$dk.'");
        $ccode["clsduoINLINE"]=getmycodedemo("clsduoINLINE","'.$dm.'","'.$dk.'");
        $ccode["dateINLINE"]=getmycodedemo("dateINLINE","'.$dm.'","'.$dk.'");
        $ccode["dttmINLINE"]=getmycodedemo("dttmINLINE","'.$dm.'","'.$dk.'");
        $ccode["intINLINE"]=getmycodedemo("intINLINE","'.$dm.'","'.$dk.'");
        $ccode["decimalINLINE"]=getmycodedemo("decimalINLINE","'.$dm.'","'.$dk.'");
        $ccode["imageINLINE"]=getmycodedemo("imageINLINE","'.$dm.'","'.$dk.'");
        $ccode["imgxINLINE"]=getmycodedemo("imgxINLINE","'.$dm.'","'.$dk.'");
        $ccode["filexINLINE"]=getmycodedemo("filexINLINE","'.$dm.'","'.$dk.'");
        $ccode["duofileINLINE"]=getmycodedemo("duofileINLINE","'.$dm.'","'.$dk.'");
        $ccode["checkINLINE"]=getmycodedemo("checkINLINE","'.$dm.'","'.$dk.'");
        $ccode["checkduoINLINE"]=getmycodedemo("checkduoINLINE","'.$dm.'","'.$dk.'");
        $ccode["srd"]=getmycodedemo("srd","'.$dm.'","'.$dk.'");
        $ccode["inline"]=getmycodedemo("inline","'.$dm.'","'.$dk.'");
        $ccode["itemsrd"]=getmycodedemo("itemsrd","'.$dm.'","'.$dk.'");
        $ccode["onerow"]=getmycodedemo("onerow","'.$dm.'","'.$dk.'");
        $ccode["duorow"]=getmycodedemo("duorow","'.$dm.'","'.$dk.'");
        $ccode["varcharFUNCTION"]=getmycodedemo("varcharFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["chtmlFUNCTION"]=getmycodedemo("chtmlFUNCTION","'.$dm.'","'.$dk.'");        
        $ccode["textFUNCTION"]=getmycodedemo("textFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["tareaFUNCTION"]=getmycodedemo("tareaFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["clstxtFUNCTION"]=getmycodedemo("clstxtFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["clsduoFUNCTION"]=getmycodedemo("clsduoFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["dateFUNCTION"]=getmycodedemo("dateFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["dttmFUNCTION"]=getmycodedemo("dttmFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["intFUNCTION"]=getmycodedemo("intFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["decimalFUNCTION"]=getmycodedemo("decimalFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["imageFUNCTION"]=getmycodedemo("imageFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["imgxFUNCTION"]=getmycodedemo("imgxFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["filexFUNCTION"]=getmycodedemo("filexFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["duofileFUNCTION"]=getmycodedemo("duofileFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["checkFUNCTION"]=getmycodedemo("checkFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["checkduoFUNCTION"]=getmycodedemo("checkduoFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["srdFUNCTION"]=getmycodedemo("srdFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["inlineFUNCTION"]=getmycodedemo("inlineFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["itemsrdFUNCTION"]=getmycodedemo("itemsrdFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["onerowFUNCTION"]=getmycodedemo("onerowFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["duorowFUNCTION"]=getmycodedemo("duorowFUNCTION","'.$dm.'","'.$dk.'");';
  break;
  case "Mform":
  $dft=zhushifu().'before var-- stid,snox, $dxtp,$itemcode,$colname,$snox,$ktitle,$dtype,$clstxt,$thusvalue,$cg,$dspl stid,sttab, ,$colname,$snox,$ktitle$tbnmx,$dvalue,$dsno,$dkey,$sfun,$dn
        '.zhushifu().'shortdata sttt=anyvalue($strst,"shorttitle",0);$sttab=anyvalue($strst,"tablename",0);skeys=anyvalue($strst,"showkeys",0);
        '.zhushifu().'shortcss diytop=tostring(anyvalue($diyrst,"diytop",0));diybottom=tostring(anyvalue($diyrst,"diybottom",0));casecodey=tostring(anyvalue($diyrst,"casecode",0));
        $ccode["varchar"]=getmycodedemo("varchar","'.$dm.'","'.$dk.'");
        $ccode["chtml"]=getmycodedemo("chtml","'.$dm.'","'.$dk.'");
        $ccode["text"]=getmycodedemo("text","'.$dm.'","'.$dk.'");
        $ccode["tarea"]=getmycodedemo("tarea","'.$dm.'","'.$dk.'");
        $ccode["clstxt"]=getmycodedemo("clstxt","'.$dm.'","'.$dk.'");
        $ccode["clsduo"]=getmycodedemo("clsduo","'.$dm.'","'.$dk.'");
        $ccode["date"]=getmycodedemo("date","'.$dm.'","'.$dk.'");
        $ccode["dttm"]=getmycodedemo("dttm","'.$dm.'","'.$dk.'");
        $ccode["int"]=getmycodedemo("int","'.$dm.'","'.$dk.'");
        $ccode["decimal"]=getmycodedemo("decimal","'.$dm.'","'.$dk.'");
        $ccode["image"]=getmycodedemo("image","'.$dm.'","'.$dk.'");
        $ccode["imgx"]=getmycodedemo("imgx","'.$dm.'","'.$dk.'");
        $ccode["filex"]=getmycodedemo("filex","'.$dm.'","'.$dk.'");
        $ccode["duofile"]=getmycodedemo("duofile","'.$dm.'","'.$dk.'");
        $ccode["check"]=getmycodedemo("check","'.$dm.'","'.$dk.'");
        $ccode["checkduo"]=getmycodedemo("checkduo","'.$dm.'","'.$dk.'");
        $ccode["varcharSRD"]=getmycodedemo("varcharSRD","'.$dm.'","'.$dk.'");        
        $ccode["textSRD"]=getmycodedemo("textSRD","'.$dm.'","'.$dk.'");
        $ccode["tareaSRD"]=getmycodedemo("tareaSRD","'.$dm.'","'.$dk.'");
        $ccode["clstxtSRD"]=getmycodedemo("clstxtSRD","'.$dm.'","'.$dk.'");
        $ccode["clsduoSRD"]=getmycodedemo("clsduoSRD","'.$dm.'","'.$dk.'");
        $ccode["dateSRD"]=getmycodedemo("dateSRD","'.$dm.'","'.$dk.'");
        $ccode["dttmSRD"]=getmycodedemo("dttmSRD","'.$dm.'","'.$dk.'");
        $ccode["intSRD"]=getmycodedemo("intSRD","'.$dm.'","'.$dk.'");
        $ccode["decimalSRD"]=getmycodedemo("decimalSRD","'.$dm.'","'.$dk.'");
        $ccode["imageSRD"]=getmycodedemo("imageSRD","'.$dm.'","'.$dk.'");
        $ccode["imgxSRD"]=getmycodedemo("imgxSRD","'.$dm.'","'.$dk.'");
        $ccode["filexSRD"]=getmycodedemo("filexSRD","'.$dm.'","'.$dk.'");
        $ccode["duofileSRD"]=getmycodedemo("duofileSRD","'.$dm.'","'.$dk.'");
        $ccode["checkSRD"]=getmycodedemo("checkSRD","'.$dm.'","'.$dk.'");
        $ccode["checkduoSRD"]=getmycodedemo("checkduoSRD","'.$dm.'","'.$dk.'");
        $ccode["varcharINLINE"]=getmycodedemo("varcharINLINE","'.$dm.'","'.$dk.'");        
        $ccode["textINLINE"]=getmycodedemo("textINLINE","'.$dm.'","'.$dk.'");
        $ccode["tareaINLINE"]=getmycodedemo("tareaINLINE","'.$dm.'","'.$dk.'");
        $ccode["clstxtINLINE"]=getmycodedemo("clstxtINLINE","'.$dm.'","'.$dk.'");
        $ccode["clsduoINLINE"]=getmycodedemo("clsduoINLINE","'.$dm.'","'.$dk.'");
        $ccode["dateINLINE"]=getmycodedemo("dateINLINE","'.$dm.'","'.$dk.'");
        $ccode["dttmINLINE"]=getmycodedemo("dttmINLINE","'.$dm.'","'.$dk.'");
        $ccode["intINLINE"]=getmycodedemo("intINLINE","'.$dm.'","'.$dk.'");
        $ccode["decimalINLINE"]=getmycodedemo("decimalINLINE","'.$dm.'","'.$dk.'");
        $ccode["imageINLINE"]=getmycodedemo("imageINLINE","'.$dm.'","'.$dk.'");
        $ccode["imgxINLINE"]=getmycodedemo("imgxINLINE","'.$dm.'","'.$dk.'");
        $ccode["filexINLINE"]=getmycodedemo("filexINLINE","'.$dm.'","'.$dk.'");
        $ccode["duofileINLINE"]=getmycodedemo("duofileINLINE","'.$dm.'","'.$dk.'");
        $ccode["checkINLINE"]=getmycodedemo("checkINLINE","'.$dm.'","'.$dk.'");
        $ccode["checkduoINLINE"]=getmycodedemo("checkduoINLINE","'.$dm.'","'.$dk.'");
        $ccode["srd"]=getmycodedemo("srd","'.$dm.'","'.$dk.'");
        $ccode["inline"]=getmycodedemo("inline","'.$dm.'","'.$dk.'");
        $ccode["itemsrd"]=getmycodedemo("itemsrd","'.$dm.'","'.$dk.'");
        $ccode["onerow"]=getmycodedemo("onerow","'.$dm.'","'.$dk.'");
        $ccode["duorow"]=getmycodedemo("duorow","'.$dm.'","'.$dk.'");
        $ccode["varcharFUNCTION"]=getmycodedemo("varcharFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["chtmlFUNCTION"]=getmycodedemo("chtmlFUNCTION","'.$dm.'","'.$dk.'");        
        $ccode["textFUNCTION"]=getmycodedemo("textFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["tareaFUNCTION"]=getmycodedemo("tareaFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["clstxtFUNCTION"]=getmycodedemo("clstxtFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["clsduoFUNCTION"]=getmycodedemo("clsduoFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["dateFUNCTION"]=getmycodedemo("dateFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["dttmFUNCTION"]=getmycodedemo("dttmFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["intFUNCTION"]=getmycodedemo("intFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["decimalFUNCTION"]=getmycodedemo("decimalFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["imageFUNCTION"]=getmycodedemo("imageFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["imgxFUNCTION"]=getmycodedemo("imgxFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["filexFUNCTION"]=getmycodedemo("filexFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["duofileFUNCTION"]=getmycodedemo("duofileFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["checkFUNCTION"]=getmycodedemo("checkFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["checkduoFUNCTION"]=getmycodedemo("checkduoFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["srdFUNCTION"]=getmycodedemo("srdFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["inlineFUNCTION"]=getmycodedemo("inlineFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["itemsrdFUNCTION"]=getmycodedemo("itemsrdFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["onerowFUNCTION"]=getmycodedemo("onerowFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["duorowFUNCTION"]=getmycodedemo("duorowFUNCTION","'.$dm.'","'.$dk.'");';
  break;
  case "detail":
 $dft=zhushifu().'before var-- stid,snox$dxtp,$itemcode,$colname,$snox,$ktitle,$dtype,$clstxt,$thusvalue,$cg,$dspl
        '.zhushifu().'shortdata sttt=anyvalue($strst,"shorttitle",0);sttab=anyvalue($strst,"tablename",0);skeys=anyvalue($strst,"showkeys",0);
        '.zhushifu().'shortcss diytop=tostring(anyvalue($diyrst,"diytop",0));diybottom=tostring(anyvalue($diyrst,"diybottom",0));casecodey=tostring(anyvalue($diyrst,"casecode",0));
        $ccode["varchar"]=getmycodedemo("varchar","'.$dm.'","'.$dk.'");
        $ccode["chtml"]=getmycodedemo("chtml","'.$dm.'","'.$dk.'");
        $ccode["text"]=getmycodedemo("text","'.$dm.'","'.$dk.'");
        $ccode["tarea"]=getmycodedemo("tarea","'.$dm.'","'.$dk.'");
        $ccode["clstxt"]=getmycodedemo("clstxt","'.$dm.'","'.$dk.'");
        $ccode["clsduo"]=getmycodedemo("clsduo","'.$dm.'","'.$dk.'");
        $ccode["date"]=getmycodedemo("date","'.$dm.'","'.$dk.'");
        $ccode["dttm"]=getmycodedemo("dttm","'.$dm.'","'.$dk.'");
        $ccode["int"]=getmycodedemo("int","'.$dm.'","'.$dk.'");
        $ccode["decimal"]=getmycodedemo("decimal","'.$dm.'","'.$dk.'");
        $ccode["image"]=getmycodedemo("image","'.$dm.'","'.$dk.'");
        $ccode["imgx"]=getmycodedemo("imgx","'.$dm.'","'.$dk.'");
        $ccode["filex"]=getmycodedemo("filex","'.$dm.'","'.$dk.'");
        $ccode["duofile"]=getmycodedemo("duofile","'.$dm.'","'.$dk.'");
        $ccode["check"]=getmycodedemo("check","'.$dm.'","'.$dk.'");
        $ccode["checkduo"]=getmycodedemo("checkduo","'.$dm.'","'.$dk.'");
        $ccode["varcharSRD"]=getmycodedemo("varcharSRD","'.$dm.'","'.$dk.'");        
        $ccode["textSRD"]=getmycodedemo("textSRD","'.$dm.'","'.$dk.'");
        $ccode["tareaSRD"]=getmycodedemo("tareaSRD","'.$dm.'","'.$dk.'");
        $ccode["clstxtSRD"]=getmycodedemo("clstxtSRD","'.$dm.'","'.$dk.'");
        $ccode["clsduoSRD"]=getmycodedemo("clsduoSRD","'.$dm.'","'.$dk.'");
        $ccode["dateSRD"]=getmycodedemo("dateSRD","'.$dm.'","'.$dk.'");
        $ccode["dttmSRD"]=getmycodedemo("dttmSRD","'.$dm.'","'.$dk.'");
        $ccode["intSRD"]=getmycodedemo("intSRD","'.$dm.'","'.$dk.'");
        $ccode["decimalSRD"]=getmycodedemo("decimalSRD","'.$dm.'","'.$dk.'");
        $ccode["imageSRD"]=getmycodedemo("imageSRD","'.$dm.'","'.$dk.'");
        $ccode["imgxSRD"]=getmycodedemo("imgxSRD","'.$dm.'","'.$dk.'");
        $ccode["filexSRD"]=getmycodedemo("filexSRD","'.$dm.'","'.$dk.'");
        $ccode["duofileSRD"]=getmycodedemo("duofileSRD","'.$dm.'","'.$dk.'");
        $ccode["checkSRD"]=getmycodedemo("checkSRD","'.$dm.'","'.$dk.'");
        $ccode["checkduoSRD"]=getmycodedemo("checkduoSRD","'.$dm.'","'.$dk.'");
        $ccode["varcharINLINE"]=getmycodedemo("varcharINLINE","'.$dm.'","'.$dk.'");        
        $ccode["textINLINE"]=getmycodedemo("textINLINE","'.$dm.'","'.$dk.'");
        $ccode["tareaINLINE"]=getmycodedemo("tareaINLINE","'.$dm.'","'.$dk.'");
        $ccode["clstxtINLINE"]=getmycodedemo("clstxtINLINE","'.$dm.'","'.$dk.'");
        $ccode["clsduoINLINE"]=getmycodedemo("clsduoINLINE","'.$dm.'","'.$dk.'");
        $ccode["dateINLINE"]=getmycodedemo("dateINLINE","'.$dm.'","'.$dk.'");
        $ccode["dttmINLINE"]=getmycodedemo("dttmINLINE","'.$dm.'","'.$dk.'");
        $ccode["intINLINE"]=getmycodedemo("intINLINE","'.$dm.'","'.$dk.'");
        $ccode["decimalINLINE"]=getmycodedemo("decimalINLINE","'.$dm.'","'.$dk.'");
        $ccode["imageINLINE"]=getmycodedemo("imageINLINE","'.$dm.'","'.$dk.'");
        $ccode["imgxINLINE"]=getmycodedemo("imgxINLINE","'.$dm.'","'.$dk.'");
        $ccode["filexINLINE"]=getmycodedemo("filexINLINE","'.$dm.'","'.$dk.'");
        $ccode["duofileINLINE"]=getmycodedemo("duofileINLINE","'.$dm.'","'.$dk.'");
        $ccode["checkINLINE"]=getmycodedemo("checkINLINE","'.$dm.'","'.$dk.'");
        $ccode["checkduoINLINE"]=getmycodedemo("checkduoINLINE","'.$dm.'","'.$dk.'");
        $ccode["srd"]=getmycodedemo("srd","'.$dm.'","'.$dk.'");
        $ccode["inline"]=getmycodedemo("inline","'.$dm.'","'.$dk.'");
        $ccode["itemsrd"]=getmycodedemo("itemsrd","'.$dm.'","'.$dk.'");
        $ccode["onerow"]=getmycodedemo("onerow","'.$dm.'","'.$dk.'");
        $ccode["duorow"]=getmycodedemo("duorow","'.$dm.'","'.$dk.'");
        $ccode["varcharFUNCTION"]=getmycodedemo("varcharFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["chtmlFUNCTION"]=getmycodedemo("chtmlFUNCTION","'.$dm.'","'.$dk.'");        
        $ccode["textFUNCTION"]=getmycodedemo("textFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["tareaFUNCTION"]=getmycodedemo("tareaFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["clstxtFUNCTION"]=getmycodedemo("clstxtFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["clsduoFUNCTION"]=getmycodedemo("clsduoFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["dateFUNCTION"]=getmycodedemo("dateFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["dttmFUNCTION"]=getmycodedemo("dttmFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["intFUNCTION"]=getmycodedemo("intFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["decimalFUNCTION"]=getmycodedemo("decimalFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["imageFUNCTION"]=getmycodedemo("imageFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["imgxFUNCTION"]=getmycodedemo("imgxFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["filexFUNCTION"]=getmycodedemo("filexFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["duofileFUNCTION"]=getmycodedemo("duofileFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["checkFUNCTION"]=getmycodedemo("checkFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["checkduoFUNCTION"]=getmycodedemo("checkduoFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["srdFUNCTION"]=getmycodedemo("srdFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["inlineFUNCTION"]=getmycodedemo("inlineFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["itemsrdFUNCTION"]=getmycodedemo("itemsrdFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["onerowFUNCTION"]=getmycodedemo("onerowFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["duorowFUNCTION"]=getmycodedemo("duorowFUNCTION","'.$dm.'","'.$dk.'");';
  
  break;
case "Mdetail":
 $dft=zhushifu().'before var-- stid,snox$dxtp,$itemcode,$colname,$snox,$ktitle,$dtype,$clstxt,$thusvalue,$cg,$dspl
        '.zhushifu().'shortdata sttt=anyvalue($strst,"shorttitle",0);sttab=anyvalue($strst,"tablename",0);skeys=anyvalue($strst,"showkeys",0);
        '.zhushifu().'shortcss diytop=tostring(anyvalue($diyrst,"diytop",0));diybottom=tostring(anyvalue($diyrst,"diybottom",0));casecodey=tostring(anyvalue($diyrst,"casecode",0));
        $ccode["varchar"]=getmycodedemo("varchar","'.$dm.'","'.$dk.'");
        $ccode["chtml"]=getmycodedemo("chtml","'.$dm.'","'.$dk.'");
        $ccode["text"]=getmycodedemo("text","'.$dm.'","'.$dk.'");
        $ccode["tarea"]=getmycodedemo("tarea","'.$dm.'","'.$dk.'");
        $ccode["clstxt"]=getmycodedemo("clstxt","'.$dm.'","'.$dk.'");
        $ccode["clsduo"]=getmycodedemo("clsduo","'.$dm.'","'.$dk.'");
        $ccode["date"]=getmycodedemo("date","'.$dm.'","'.$dk.'");
        $ccode["dttm"]=getmycodedemo("dttm","'.$dm.'","'.$dk.'");
        $ccode["int"]=getmycodedemo("int","'.$dm.'","'.$dk.'");
        $ccode["decimal"]=getmycodedemo("decimal","'.$dm.'","'.$dk.'");
        $ccode["image"]=getmycodedemo("image","'.$dm.'","'.$dk.'");
        $ccode["imgx"]=getmycodedemo("imgx","'.$dm.'","'.$dk.'");
        $ccode["filex"]=getmycodedemo("filex","'.$dm.'","'.$dk.'");
        $ccode["duofile"]=getmycodedemo("duofile","'.$dm.'","'.$dk.'");
        $ccode["check"]=getmycodedemo("check","'.$dm.'","'.$dk.'");
        $ccode["checkduo"]=getmycodedemo("checkduo","'.$dm.'","'.$dk.'");
         $ccode["varcharSRD"]=getmycodedemo("varcharSRD","'.$dm.'","'.$dk.'");        
        $ccode["textSRD"]=getmycodedemo("textSRD","'.$dm.'","'.$dk.'");
        $ccode["tareaSRD"]=getmycodedemo("tareaSRD","'.$dm.'","'.$dk.'");
        $ccode["clstxtSRD"]=getmycodedemo("clstxtSRD","'.$dm.'","'.$dk.'");
        $ccode["clsduoSRD"]=getmycodedemo("clsduoSRD","'.$dm.'","'.$dk.'");
        $ccode["dateSRD"]=getmycodedemo("dateSRD","'.$dm.'","'.$dk.'");
        $ccode["dttmSRD"]=getmycodedemo("dttmSRD","'.$dm.'","'.$dk.'");
        $ccode["intSRD"]=getmycodedemo("intSRD","'.$dm.'","'.$dk.'");
        $ccode["decimalSRD"]=getmycodedemo("decimalSRD","'.$dm.'","'.$dk.'");
        $ccode["imageSRD"]=getmycodedemo("imageSRD","'.$dm.'","'.$dk.'");
        $ccode["imgxSRD"]=getmycodedemo("imgxSRD","'.$dm.'","'.$dk.'");
        $ccode["filexSRD"]=getmycodedemo("filexSRD","'.$dm.'","'.$dk.'");
        $ccode["duofileSRD"]=getmycodedemo("duofileSRD","'.$dm.'","'.$dk.'");
        $ccode["checkSRD"]=getmycodedemo("checkSRD","'.$dm.'","'.$dk.'");
        $ccode["checkduoSRD"]=getmycodedemo("checkduoSRD","'.$dm.'","'.$dk.'");
        $ccode["varcharINLINE"]=getmycodedemo("varcharINLINE","'.$dm.'","'.$dk.'");        
        $ccode["textINLINE"]=getmycodedemo("textINLINE","'.$dm.'","'.$dk.'");
        $ccode["tareaINLINE"]=getmycodedemo("tareaINLINE","'.$dm.'","'.$dk.'");
        $ccode["clstxtINLINE"]=getmycodedemo("clstxtINLINE","'.$dm.'","'.$dk.'");
        $ccode["clsduoINLINE"]=getmycodedemo("clsduoINLINE","'.$dm.'","'.$dk.'");
        $ccode["dateINLINE"]=getmycodedemo("dateINLINE","'.$dm.'","'.$dk.'");
        $ccode["dttmINLINE"]=getmycodedemo("dttmINLINE","'.$dm.'","'.$dk.'");
        $ccode["intINLINE"]=getmycodedemo("intINLINE","'.$dm.'","'.$dk.'");
        $ccode["decimalINLINE"]=getmycodedemo("decimalINLINE","'.$dm.'","'.$dk.'");
        $ccode["imageINLINE"]=getmycodedemo("imageINLINE","'.$dm.'","'.$dk.'");
        $ccode["imgxINLINE"]=getmycodedemo("imgxINLINE","'.$dm.'","'.$dk.'");
        $ccode["filexINLINE"]=getmycodedemo("filexINLINE","'.$dm.'","'.$dk.'");
        $ccode["duofileINLINE"]=getmycodedemo("duofileINLINE","'.$dm.'","'.$dk.'");
        $ccode["checkINLINE"]=getmycodedemo("checkINLINE","'.$dm.'","'.$dk.'");
        $ccode["checkduoINLINE"]=getmycodedemo("checkduoINLINE","'.$dm.'","'.$dk.'");
        $ccode["srd"]=getmycodedemo("srd","'.$dm.'","'.$dk.'");
        $ccode["inline"]=getmycodedemo("inline","'.$dm.'","'.$dk.'");
        $ccode["itemsrd"]=getmycodedemo("itemsrd","'.$dm.'","'.$dk.'");
        $ccode["onerow"]=getmycodedemo("onerow","'.$dm.'","'.$dk.'");
        $ccode["duorow"]=getmycodedemo("duorow","'.$dm.'","'.$dk.'");
        $ccode["varcharFUNCTION"]=getmycodedemo("varcharFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["chtmlFUNCTION"]=getmycodedemo("chtmlFUNCTION","'.$dm.'","'.$dk.'");        
        $ccode["textFUNCTION"]=getmycodedemo("textFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["tareaFUNCTION"]=getmycodedemo("tareaFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["clstxtFUNCTION"]=getmycodedemo("clstxtFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["clsduoFUNCTION"]=getmycodedemo("clsduoFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["dateFUNCTION"]=getmycodedemo("dateFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["dttmFUNCTION"]=getmycodedemo("dttmFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["intFUNCTION"]=getmycodedemo("intFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["decimalFUNCTION"]=getmycodedemo("decimalFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["imageFUNCTION"]=getmycodedemo("imageFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["imgxFUNCTION"]=getmycodedemo("imgxFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["filexFUNCTION"]=getmycodedemo("filexFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["duofileFUNCTION"]=getmycodedemo("duofileFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["checkFUNCTION"]=getmycodedemo("checkFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["checkduoFUNCTION"]=getmycodedemo("checkduoFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["srdFUNCTION"]=getmycodedemo("srdFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["inlineFUNCTION"]=getmycodedemo("inlineFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["itemsrdFUNCTION"]=getmycodedemo("itemsrdFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["onerowFUNCTION"]=getmycodedemo("onerowFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["duorowFUNCTION"]=getmycodedemo("duorowFUNCTION","'.$dm.'","'.$dk.'");';
  break;
  case "menu":
  $dft='$ccode["srd"]="";
      $ccode["lv1"]="";
      $ccode["lv2"]="";
      $ccode["lv3"]="";
      $ccode["lv4"]="";
      $ccode["lv5"]="";';
  break;
  case "list":
  $dft=zhushifu().'before var-- stid,pgpnum,pnum,page,$dxtype,$icode,$colnm,$snox,$coltt,$dttype,$clstxt,$tval,$cg,$dspl
        '.zhushifu().'sttt=anyvalue($strst,"shorttitle",0);sttab=anyvalue($strst,"tablename",0);skeys=anyvalue($strst,"showkeys",0);
        '.zhushifu().'casecodey=tostring(anyvalue($strst,"casecode",0)); diytop=tostring(anyvalue($diyrst,"diytop",0));
        '.zhushifu().'diybottom=tostring(anyvalue($diyrst,"diybottom",0));casecodez=tostring(anyvalue($stcssrst,"casecode",0));
          $ccode["varchar"]=getmycodedemo("varchar","'.$dm.'","'.$dk.'");
        $ccode["chtml"]=getmycodedemo("chtml","'.$dm.'","'.$dk.'");
        $ccode["text"]=getmycodedemo("text","'.$dm.'","'.$dk.'");
        $ccode["tarea"]=getmycodedemo("tarea","'.$dm.'","'.$dk.'");
        $ccode["clstxt"]=getmycodedemo("clstxt","'.$dm.'","'.$dk.'");
        $ccode["clsduo"]=getmycodedemo("clsduo","'.$dm.'","'.$dk.'");
        $ccode["date"]=getmycodedemo("date","'.$dm.'","'.$dk.'");
        $ccode["dttm"]=getmycodedemo("dttm","'.$dm.'","'.$dk.'");
        $ccode["int"]=getmycodedemo("int","'.$dm.'","'.$dk.'");
        $ccode["decimal"]=getmycodedemo("decimal","'.$dm.'","'.$dk.'");
        $ccode["image"]=getmycodedemo("image","'.$dm.'","'.$dk.'");
        $ccode["imgx"]=getmycodedemo("imgx","'.$dm.'","'.$dk.'");
        $ccode["filex"]=getmycodedemo("filex","'.$dm.'","'.$dk.'");
        $ccode["duofile"]=getmycodedemo("duofile","'.$dm.'","'.$dk.'");
        $ccode["check"]=getmycodedemo("check","'.$dm.'","'.$dk.'");
        $ccode["checkduo"]=getmycodedemo("checkduo","'.$dm.'","'.$dk.'");
        $ccode["tabdemo"]=getmycodedemo("tabdemo","'.$dm.'","'.$dk.'");
        $ccode["srd"]=getmycodedemo("srd","'.$dm.'","'.$dk.'");
        $ccode["tabtr"]=getmycodedemo("tabtr","'.$dm.'","'.$dk.'");
        $ccode["tabtd"]=getmycodedemo("tabtd","'.$dm.'","'.$dk.'");
        $ccode["tabhdtr"]=getmycodedemo("tabhdtr","'.$dm.'","'.$dk.'");
        $ccode["tabhdtd"]=getmycodedemo("tabhdtd","'.$dm.'","'.$dk.'");
        $ccode["pgsrd"]=getmycodedemo("pgsrd","'.$dm.'","'.$dk.'");
        $ccode["pgin"]=getmycodedemo("pgin","'.$dm.'","'.$dk.'");
        $ccode["pgout"]=getmycodedemo("pgout","'.$dm.'","'.$dk.'");
        $ccode["pgfirst"]=getmycodedemo("pgfirst","'.$dm.'","'.$dk.'");
        $ccode["pglast"]=getmycodedemo("pglast","'.$dm.'","'.$dk.'");
        $ccode["pgslcls"]=getmycodedemo("pgslcls","'.$dm.'","'.$dk.'");
        $ccode["oprt"]=getmycodedemo("oprt","'.$dm.'","'.$dk.'");
        $ccode["searchdemo"]=getmycodedemo("searchdemo","'.$dm.'","'.$dk.'");
        $ccode["content"]=getmycodedemo("content","'.$dm.'","'.$dk.'");
        $ccode["varcharFUNCTION"]=getmycodedemo("varcharFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["chtmlFUNCTION"]=getmycodedemo("chtmlFUNCTION","'.$dm.'","'.$dk.'");        
        $ccode["textFUNCTION"]=getmycodedemo("textFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["tareaFUNCTION"]=getmycodedemo("tareaFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["clstxtFUNCTION"]=getmycodedemo("clstxtFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["clsduoFUNCTION"]=getmycodedemo("clsduoFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["dateFUNCTION"]=getmycodedemo("dateFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["dttmFUNCTION"]=getmycodedemo("dttmFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["intFUNCTION"]=getmycodedemo("intFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["decimalFUNCTION"]=getmycodedemo("decimalFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["imageFUNCTION"]=getmycodedemo("imageFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["imgxFUNCTION"]=getmycodedemo("imgxFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["filexFUNCTION"]=getmycodedemo("filexFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["duofileFUNCTION"]=getmycodedemo("duofileFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["checkFUNCTION"]=getmycodedemo("checkFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["checkduoFUNCTION"]=getmycodedemo("checkduoFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["srdFUNCTION"]=getmycodedemo("srdFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["tabtrFUNCTION"]=getmycodedemo("tabtrFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["tabtdFUNCTION"]=getmycodedemo("tabtdFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["tabhdtrFUNCTION"]=getmycodedemo("tabhdtrFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["tabhdtdFUNCTION"]=getmycodedemo("tabhdtdFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["pgsrdFUNCTION"]=getmycodedemo("pgsrdFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["pginFUNCTION"]=getmycodedemo("pginFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["pgoutFUNCTION"]=getmycodedemo("pgoutFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["pgfirstFUNCTION"]=getmycodedemo("pgfirstFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["pglastFUNCTION"]=getmycodedemo("pglastFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["oprtFUNCTION"]=getmycodedemo("oprtFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["pgslclsFUNCTION"]=getmycodedemo("pgslclsFUNCTION","'.$dm.'","'.$dk.'");';
        
  break;
case "Mlist":
  $dft=zhushifu().'before var-- stid,pgpnum,pnum,page,$dxtype,$icode,$colnm,$snox,$coltt,$dttype,$clstxt,$tval,$cg,$dspl
        '.zhushifu().'sttt=anyvalue($strst,"shorttitle",0);sttab=anyvalue($strst,"tablename",0);skeys=anyvalue($strst,"showkeys",0);
        '.zhushifu().'casecodey=tostring(anyvalue($strst,"casecode",0)); diytop=tostring(anyvalue($diyrst,"diytop",0));
        '.zhushifu().'diybottom=tostring(anyvalue($diyrst,"diybottom",0));casecodez=tostring(anyvalue($stcssrst,"casecode",0));
          $ccode["varchar"]=getmycodedemo("varchar","'.$dm.'","'.$dk.'");
        $ccode["chtml"]=getmycodedemo("chtml","'.$dm.'","'.$dk.'");
        $ccode["text"]=getmycodedemo("text","'.$dm.'","'.$dk.'");
        $ccode["tarea"]=getmycodedemo("tarea","'.$dm.'","'.$dk.'");
        $ccode["clstxt"]=getmycodedemo("clstxt","'.$dm.'","'.$dk.'");
        $ccode["clsduo"]=getmycodedemo("clsduo","'.$dm.'","'.$dk.'");
        $ccode["date"]=getmycodedemo("date","'.$dm.'","'.$dk.'");
        $ccode["dttm"]=getmycodedemo("dttm","'.$dm.'","'.$dk.'");
        $ccode["int"]=getmycodedemo("int","'.$dm.'","'.$dk.'");
        $ccode["decimal"]=getmycodedemo("decimal","'.$dm.'","'.$dk.'");
        $ccode["image"]=getmycodedemo("image","'.$dm.'","'.$dk.'");
        $ccode["imgx"]=getmycodedemo("imgx","'.$dm.'","'.$dk.'");
        $ccode["filex"]=getmycodedemo("filex","'.$dm.'","'.$dk.'");
        $ccode["duofile"]=getmycodedemo("duofile","'.$dm.'","'.$dk.'");
        $ccode["check"]=getmycodedemo("check","'.$dm.'","'.$dk.'");
        $ccode["checkduo"]=getmycodedemo("checkduo","'.$dm.'","'.$dk.'");
        $ccode["tabdemo"]=getmycodedemo("tabdemo","'.$dm.'","'.$dk.'");
        $ccode["srd"]=getmycodedemo("srd","'.$dm.'","'.$dk.'");
        $ccode["tabtr"]=getmycodedemo("tabtr","'.$dm.'","'.$dk.'");
        $ccode["tabtd"]=getmycodedemo("tabtd","'.$dm.'","'.$dk.'");
        $ccode["tabhdtr"]=getmycodedemo("tabhdtr","'.$dm.'","'.$dk.'");
        $ccode["tabhdtd"]=getmycodedemo("tabhdtd","'.$dm.'","'.$dk.'");
        $ccode["pgsrd"]=getmycodedemo("pgsrd","'.$dm.'","'.$dk.'");
        $ccode["pgin"]=getmycodedemo("pgin","'.$dm.'","'.$dk.'");
        $ccode["pgout"]=getmycodedemo("pgout","'.$dm.'","'.$dk.'");
        $ccode["pgfirst"]=getmycodedemo("pgfirst","'.$dm.'","'.$dk.'");
        $ccode["pglast"]=getmycodedemo("pglast","'.$dm.'","'.$dk.'");
        $ccode["pgslcls"]=getmycodedemo("pgslcls","'.$dm.'","'.$dk.'");
        $ccode["oprt"]=getmycodedemo("oprt","'.$dm.'","'.$dk.'");
        $ccode["searchdemo"]=getmycodedemo("searchdemo","'.$dm.'","'.$dk.'");
        $ccode["content"]=getmycodedemo("content","'.$dm.'","'.$dk.'");
        $ccode["varcharFUNCTION"]=getmycodedemo("varcharFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["chtmlFUNCTION"]=getmycodedemo("chtmlFUNCTION","'.$dm.'","'.$dk.'");        
        $ccode["textFUNCTION"]=getmycodedemo("textFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["tareaFUNCTION"]=getmycodedemo("tareaFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["clstxtFUNCTION"]=getmycodedemo("clstxtFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["clsduoFUNCTION"]=getmycodedemo("clsduoFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["dateFUNCTION"]=getmycodedemo("dateFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["dttmFUNCTION"]=getmycodedemo("dttmFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["intFUNCTION"]=getmycodedemo("intFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["decimalFUNCTION"]=getmycodedemo("decimalFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["imageFUNCTION"]=getmycodedemo("imageFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["imgxFUNCTION"]=getmycodedemo("imgxFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["filexFUNCTION"]=getmycodedemo("filexFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["duofileFUNCTION"]=getmycodedemo("duofileFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["checkFUNCTION"]=getmycodedemo("checkFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["checkduoFUNCTION"]=getmycodedemo("checkduoFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["srdFUNCTION"]=getmycodedemo("srdFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["tabtrFUNCTION"]=getmycodedemo("tabtrFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["tabtdFUNCTION"]=getmycodedemo("tabtdFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["tabhdtrFUNCTION"]=getmycodedemo("tabhdtrFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["tabhdtdFUNCTION"]=getmycodedemo("tabhdtdFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["pgsrdFUNCTION"]=getmycodedemo("pgsrdFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["pginFUNCTION"]=getmycodedemo("pginFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["pgoutFUNCTION"]=getmycodedemo("pgoutFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["pgfirstFUNCTION"]=getmycodedemo("pgfirstFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["pglastFUNCTION"]=getmycodedemo("pglastFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["oprtFUNCTION"]=getmycodedemo("oprtFUNCTION","'.$dm.'","'.$dk.'");
        $ccode["pgslclsFUNCTION"]=getmycodedemo("pgslclsFUNCTION","'.$dm.'","'.$dk.'");';
        
  break;
  default:
  $dft="";
 }
 return $dft;
}
function jcurltolocal($urlx,$sysid,$appid,$domx,$mrkx){
 $filex=urlfname($urlx); 
 $ptmy=explode(".",$filex);
 $totpt=count($ptmy);
 $kzm=$ptmy[$totpt-1];
 $tmpdir="";
    switch($kzm){
     case "js":
     $tmpdir="js";
     break;
     case "css":
     $tmpdir="css";
     break;
     case "jpg":
     $tmpdir="images";
     break;
     case "png":
     $tmpdir="images";
     break;
     case "gif":
     $tmpdir="images";
     break;
     case "svg":
     $tmpdir="images";
     break;
     case "bmp":
     $tmpdir="images";
     break;
     default:
   }
    $tofile=combineurl(localroot(),"/DEVELOPING/".$sysid."/".$appid."/".$domx."/".$tmpdir."/".$filex);
    $gofile=$tmpdir."/".$filex;
    $topath=combineurl(localroot(),"/DEVELOPING/".$sysid."/".$appid."/".$domx."/".$tmpdir."/");
  if (strpos($urlx,"://")>0 or substr($urlx,0,2)=="//"){  
     if (strpos($urlx,glw())>0){
      $frompath=combineurl(localroot(),hou($urlx,glw()));     
     }else{
     }
  }else{
   if (strpos("x".$urlx,"../")>0){
    $frompath=connurl(localroot(),$urlx);
   }else{
    $frompath=combineurl(localroot(),$urlx);
   }
  }
  $totofile=hou($tofile,localroot());
  if (substr($totofile,0,1)!="/"){
    $totofile="/".$totofile;
  }
  if ($kzm!=""){
    return $gofile;
  }else{
    return "";
  }
}
function manyfileto($jcfiles,$sid,$aid,$dmx,$mkx){
 $fmaaa="";
 if ($jcfiles!=""){
  $ptjcf=explode(";",$jcfiles);
  $totptjcf=count($ptjcf);
  if ($totptjcf>1){
    for ($w=0;$w<$totptjcf;$w++){
     $tmpjcf=jcurltolocal($ptjcf[$w],$sid,$aid,$dmx,$mkx);
     if ($tmpjcf!=""){
      $fmaaa=$fmaaa.$tmpjcf.";";
     }
    }
    return $fmaaa;
  }else{
   return "";
  }
 } 
}
$clone=$_GET["clone"];
$domain=$_POST["domain"];
$mark=$_POST["mark"];
$amd5="a".md5($domain.$mark);
$z=setvarval($amd5,"");
$utitle=$_POST["unittitle"];
$uclass=$_POST["unitclass"];
$udescrib=$_POST["unitdescrib"];
$sysid=$_POST["sysid"];
$appid=$_POST["appid"];
$stylex=unstrs($_POST["stylex"]);
$scriptx=unstrs($_POST["scriptx"]);
$casecode=unstrs($_POST["casecode"]);
$casedemo=$casecode;
$tmpcode=unstrs($_POST["tmpcode"]);
$otmpcode=$tmpcode;
$srdcode=unstrs($_POST["srdcode"]);
$srddemo=$srdcode;
$jsfiles=unstrs($_POST["jsfiles"]);
$cssfiles=unstrs($_POST["cssfiles"]);
$outurl=$_POST["outurl"];
$alljsfiles=$jsfiles;
$allcssfiles=$cssfiles;
$allstylex=$stylex;
$allscriptx=$scriptx;
$pagehtml=turnlab($srdcode);
$clopagehtml=turnlab($srdcode);
$clojsfiles="";
$clocssfiles="";
$cloalljsfiles="";
$cloallcssfiles="";
$cloalljsfiles=$clojsfiles;
$cloallcssfiles=$clocssfiles;
$ptjsfiles=explode(";",$jsfiles);
$totptj=count($ptjsfiles);
$fmface="";
for ($m=0;$m<$totptj;$m++){
  $extm=UX("select count(*) as result from coode_mydounfiles where sysid='".$sysid."' and appid='".$appid."' and unitmark='".$mark."' and domainmark='".$domain."' and fileoriurl='".$ptjsfiles[$m]."'");
  $fdmurl=str_replace("/MYFACE/","",$ptjsfiles[$m]);
  if ($fdmurl!=""){
   $clojsfiles=$clojsfiles.$fdmurl.";";
  }
  if (strpos($ptjsfiles[$m],"MYFACE/")>0){
    $tmpface=qian(hou($ptjsfiles[$m],"MYFACE/"),"/");
    if (strpos($fmface,$tmpface)>0){      
    }else{
      $fmface=$fmface.$tmpface.";";
    }
  }
  if (intval($extm)==0){
    $sqlm="sysid,appid,domainmark,unitmark,fileoriurl,filedmurl,CRTM,UPTM,CRTOR,OLMK";
    $sqln="'".$sysid."','".$appid."','".$domain."','".$mark."','".$ptjsfiles[$m]."','".$fdmurl."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";
    $o=UX("insert into coode_mydounfiles(".$sqlm.")values(".$sqln.")");
  }
}
$ptcssfiles=explode(";",$cssfiles);
$totptc=count($ptcssfiles);
for ($n=0;$n<$totptj;$n++){
  $extn=UX("select count(*) as result from coode_mydounfiles where sysid='".$sysid."' and appid='".$appid."' and unitmark='".$mark."' and domainmark='".$domain."' and fileoriurl='".$ptcssfiles[$n]."'");
  $fdmurl=str_replace("/MYFACE/","",$ptcssfiles[$m]);
  if ($fdmurl!=""){
    $clocssfiles=$clocssfiles.$fdmurl.";";
  }
  if (strpos($ptcssfiles[$n],"MYFACE/")>0){
    $tmpface=qian(hou($ptcssfiles[$n],"MYFACE/"),"/");
    if (strpos($fmface,$tmpface)>0){      
    }else{
      $fmface=$fmface.$tmpface.";";
    }
  }
  if (intval($extn)==0){
    $sqlm="sysid,appid,domainmark,unitmark,fileoriurl,filedmurl,CRTM,UPTM,CRTOR,OLMK";
    $sqln="'".$sysid."','".$appid."','".$domain."','".$mark."','".$ptcssfiles[$n]."','".$fdmurl."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";
    $o=UX("insert into coode_mydounfiles(".$sqlm.")values(".$sqln.")");
  }  
}
$otherface=absorbmyface($tmpcode).absorbmyface($stylex).absorbmyface($scriptx);
$otherface=str_replace(",",";",$otherface);
if ($otherface!=""){
  $fmface=$fmface.$otherface;
}
$fmface=onlyone($fmface);
$ptface=explode(";",$fmface);
$totface=count($ptface);
if($outurl!=""){
 $ptout=explode("/",$outurl);
 $totpto=count($ptout);
 $fmpto="";
 for ($z=0;$z<($totpto-1);$z++){
  $fmpto=$fmpto.$ptout[$z]."/";
 }
}
for ($f=0;$f<$totface;$f++){
  if ($ptface[$f]!="" and strpos('x'.$ptface[$f],'"')<=0  and strpos("x".$ptface[$f],"'")<=0){
    $tmpface=$ptface[$f];
    $tmpfromurl=combineurl(localroot(),"/MYFACE/".$tmpface);
    $tturl=combineurl(localroot(),$fmpto.$tmpface);
    $duext=UX("select count(*) as result from coode_duwithface where faceid='".$tmpface."' and dumark='".$domain.".".$mark."'");
    if (intval($duext)==0){
      $sqla="dumark,faceid,dutitle,facetitle,withdescrib,CRTM,UPTM,OLMK";
      $sqlb="'".$domain.".".$mark."','".$tmpface."','','','',now(),now(),'".onlymark()."'";
      $cc=UX("insert into coode_duwithface(".$sqla.")values(".$sqlb.")");
    }    
    if($outurl!=""){
      is_dir($tturl) OR mkdir($tturl, 0777, true);
      copy_dir($tmpfromurl,$tturl);
    }
  }
}
eval(CLASSX("coodetemplate"));
$ct=new coodetemplate();
$newtempc=$tmpcode;
$leiia=0;
if ($uclass!="menu" and $uclass!="form" and $uclass!="list" and $uclass!="detail"  and $uclass!="Mlist" and $uclass!="Mdetail" and $uclass!="Mform" ){
 $extnext=2; 
 while($extnext>1 and $leijia<10){
  $ptcode=explode("{!--TEMP.",$tmpcode);
  $leijia++;
  $totpt=count($ptcode);
  if ($totpt==1){
   $totpt=0;
  }
  $extnext=$totpt;
   if ($clone!=""){
    for ($i=1;$i<$totpt;$i++){   
        $partkey[$i]=qian($ptcode[$i],"=");
        $partval[$i]=qian(hou($ptcode[$i],"="),"--}");
        $newtempc=str_replace("{!--TEMP.".$partkey[$i]."=".$partval[$i]."--}","{--TEMP.".$partkey[$i]."=".$domain.".".hou($partval[$i],".")."--}",$newtempc);    
    }  
   }
 for ($i=1;$i<$totpt;$i++){
   $partkey[$i]=qian($ptcode[$i],"=");
   $partval[$i]=qian(hou($ptcode[$i],"="),"--}");
   $dmx=qian($partval[$i],".");
   $mkx=hou($partval[$i],".");
   if (strpos($mkx,"@")>0){
     $mky=qian($mkx,"@");
     $mkv=hou($mkx,"@");
   }else{
     $mky=$mkx;
     $mkv="";
   }   
   $tmprst=SX("select sysid,appid,cssfilex,jsfilex,stylex,scriptx,templatecode,unitclass,unittitle from coode_mydounit where domainmark='".$dmx."' and unitmark='".$mkx."'");
   if (countresult($tmprst)==0 and strpos($tmprst,"报错")<=0 and $dmx!="" and $mkx!=""){
      if ($clone==""){
       $sqlx="sysid,appid,domainmark,unitmark,CRTM,UPTM,CRTOR,OLMK,templatecode,pagesurround";
       $sqly="'".$sysid."','".$appid."','".$dmk."','".$mky."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."','','.gohex(tempdefault()).'";
       $z=UX("insert into coode_mydonunit(".$sqlx.")values(".$sqly.")");
      }else{//最重要的克隆的时候把下级变成DOMAIN
       $sqlx="sysid,appid,domainmark,unitmark,CRTM,UPTM,CRTOR,OLMK,templatecode,pagesurround";
       $sqly="'".$sysid."','".$appid."','".$domain."','".$mky."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."','','.gohex(tempdefault()).'";
       $z=UX("insert into coode_mydonunit(".$sqlx.")values(".$sqly.")");
      }
       $tmpcssfilex="";
       $tmpjsfilex="";
       $tmpstylex="";
       $tmpscriptx="";
       $unitclass="";
       $unittitle="";
       $tmpcodex="";
       $sid=$sysid;
       $aid=$appid;       
       $totptj=0;
       $fmclojsf="";
       $fmclocssf="";
       $tmpcode=str_replace("{!--TEMP.".$partkey[$i]."=".$partval[$i]."--}","{!--TMP.".$partkey[$i]."=".$partval[$i]."--}",$tmpcode);
    }else{
     $tmpcssfilex=tostring(anyvalue($tmprst,"cssfilex",0));
     $tmpjsfilex=tostring(anyvalue($tmprst,"jsfilex",0));
     $tmpstylex=tostring(anyvalue($tmprst,"stylex",0));
     $tmpscriptx=tostring(anyvalue($tmprst,"scriptx",0));
     $unitclass=tostring(anyvalue($tmprst,"unitclass",0));
     $unittitle=tostring(anyvalue($tmprst,"unittitle",0));
     $tmpcodex=tostring(anyvalue($tmprst,"templatecode",0));
     $casecodey=tostring(anyvalue($tmprst,"casecode",0));
     $sid=tostring(anyvalue($tmprst,"sysid",0));
     $aid=tostring(anyvalue($tmprst,"appid",0));
     $ptjsfiles=explode(";",$tmpjsfilex);
     $totptj=count($ptjsfiles);
     $fmclojsf="";
     $fmclocssf="";
     for ($m=0;$m<$totptj;$m++){
      $extm=UX("select count(*) as result from coode_mydounfiles where sysid='".$sid."' and appid='".$aid."' and unitmark='".$mkx."' and domainmark='".$dmx."' and fileoriurl='".$ptjsfiles[$m]."'");
      $fdmurl=str_replace("/MYFACE/","",$ptjsfiles[$m]);
      if ($fdmurl!=""){
        $fmclojsf=$fmclojsf.$fdmurl.";";
      }
      if (intval($extm)==0){
         if ($ptjsfiles[$m]!=""){
          $sqlm="sysid,appid,domainmark,unitmark,fileoriurl,filedmurl,CRTM,UPTM,CRTOR,OLMK";
          $sqln="'".$sid."','".$aid."','".$dmx."','".$mkx."','".$ptjsfiles[$m]."','".$fdmurl."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";
          $o=UX("insert into coode_mydounfiles(".$sqlm.")values(".$sqln.")");
         }
       }
     }//for m
    $ptcssfiles=explode(";",$tmpcssfilex);
    $totptc=count($ptcssfiles);    
    for ($n=0;$n<$totptj;$n++){
       $extn=UX("select count(*) as result from coode_mydounfiles where sysid='".$sid."' and appid='".$aid."' and unitmark='".$mkx."' and domainmark='".$dmx."' and fileoriurl='".$ptcssfiles[$n]."'");
       $fdmurl=str_replace("/MYFACE/","",$ptjsfiles[$m]);
       if ($fdmurl!=""){
         $fmclocssf=$fmclocssf.$fdmurl.";";
       }
      if (intval($extn)==0){
        if ($ptcssfiles[$n]!=""){
         $sqlm="sysid,appid,domainmark,unitmark,fileoriurl,filedmurl,CRTM,UPTM,CRTOR,OLMK";
         $sqln="'".$sysid."','".$appid."','".$dmx."','".$mkx."','".$ptcssfiles[$n]."','".$fdmurl."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";
         $o=UX("insert into coode_mydounfiles(".$sqlm.")values(".$sqln.")");
        }
       }
     }//forn
     if ($clone!=""){       
       $pkey="";
       $pval="";       
       $newnewcode=$tmpcodex;
       $sid=$sysid;
       $aid=$appid;
       $dmx=$domain;
      if ($domain!="" and hou($pval[$i],".")!=""){
         $extzz=UX("select count(*) as result from coode_mydonunit where domainmark='".$domain."' and unitmark='".hou($pval[$i],".")."'");
         if (intval($extzz)==0){
          $sqla="cssfilex,jsfilex,stylex,scriptx,templatecode,unitclass,sysid,appid,domainmark,unitmark,unittitle,CRTM,UPTM,CRTOR,OLMK";
          $sqlb="'".$tmpcssfilex."','".$tmpjsfilex."','".gohex($tmpstylex)."','".gohex($tmpscriptx)."','".gohex($tmpcodex)."','".$unitclass."','".$sid."','".$aid."','".$domain."','".hou($pval[$i],".")."','".$unittitle."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";
          $z=UX("insert into coode_mydomainunit(".$sqla.")values(".$sqlb.")");
        }else{
          $z=UX("update coode_mydomainunit set cssfilex='".$tmpcssfilex."',jsfilex='".$tmpjsfilex."',stylex='".gohex($tmpstylex)."',scriptx='".gohex($tmpscriptx)."',templatecode='".gohex($tmpcodex)."',unittitle='".$unittitle."',UPTM=now() where domainmark='".$domain."' and unitmark='".hou($pval[$i],".")."'");
        }
      }
     }//ifclone
     $extclo=UX("select count(*) as result from coode_mydocloneunit where domainmark='".$dmx."' and unitmark='".$mkx."' and sysid='".$sid."' and appid='".$aid."'");
     if ($extclo==0){
        if ($dmx!="" and $mkx!=""){
         $sqla="cssfilex,jsfilex,stylex,scriptx,templatecode,unitclass,sysid,appid,domainmark,unitmark,unittitle,CRTM,UPTM,CRTOR,OLMK";
         $sqlb="'".$fmclocssf."','".$fmclojsf."','".gohex($tmpstylex)."','".gohex($tmpscriptx)."','".gohex($tmpcodex)."','".$unitclass."','".$sid."','".$aid."','".$dmx."','".$mkx."','".$unittitle."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."'";
         $z=UX("insert into coode_mydocloneunit(".$sqla.")values(".$sqlb.")");
        }
     }else{
        $supd=" cssfilex='".$fmclocssf."',jsfilex='".$fmclojsf."',stylex='".gohex($tmpstylex)."',scriptx='".gohex($tmpscriptx)."',templatecode='".gohex($tmpcodex)."',unitclass='".$unitclass."' ";
        $scdt=" domainmark='".$dmx."' and unitmark='".$mkx."' and sysid='".$sid."' and appid='".$aid."'";
        $s=UX("update coode_mydocloneunit set ".$supd." where ".$scdt);
     }//ifextclo
     switch($unitclass){
       case "menu":
       $tmpcode=str_replace("{!--TEMP.".$partkey[$i]."=".$partval[$i]."--}",$ct->maketempcode("menu",$dmx,$mky,$mkv,$casecodey),$tmpcode);       
       $alljsfiles=$alljsfiles.$tmpjsfilex.$ct->maketmpcdjsf("menu",$dmx,$mky,$mkv,$casecode);
       $allcssfiles=$allcssfiles.$tmpcssfilex.$ct->maketmpcdcssf("menu",$dmx,$mky,$mkv,$casecode);
       $cloalljsfiles=$cloalljsfiles.$fmclojsf.maketmpcdjsf("menu",$dmx,$mky,$mkv,$casecode);
       $cloallcssfiles=$cloalljsfiles.$fmclocssf.maketmpcdcssf("menu",$dmx,$mky,$mkv,$casecode);
       $allstylex=$allstylex.$tmpstylex.$ct->maketmpcdstlx("menu",$dmx,$mky,$mkv,$casecode);
       $allscriptx=$allscriptx.$tmpscriptx.$ct->maketmpcdscptx("menu",$dmx,$mky,$mkv,$casecode);
       break;
       case "list":
       $tmpcode=str_replace("{!--TEMP.".$partkey[$i]."=".$partval[$i]."--}",$ct->maketempcode("list",$dmx,$mky,$mkv,$casecodey),$tmpcode);
       $alljsfiles=$alljsfiles.$tmpjsfilex.$ct->maketmpcdjsf("list",$dmx,$mky,$mkv,$casecode);
       $allcssfiles=$allcssfiles.$tmpcssfilex.$ct->maketmpcdcssf("list",$dmx,$mky,$mkv,$casecode);
       $cloalljsfiles=$cloalljsfiles.$fmclojsf.maketmpcdjsf("list",$dmx,$mky,$mkv,$casecode);
       $cloallcssfiles=$cloalljsfiles.$fmclocssf.maketmpcdcssf("list",$dmx,$mky,$mkv,$casecode);
       $allstylex=$allstylex.$tmpstylex.$ct->maketmpcdstlx("list",$dmx,$mky,$mkv,$casecode);
       $allscriptx=$allscriptx.$tmpscriptx.$ct->maketmpcdscptx("list",$dmx,$mky,$mkv,$casecode);
       break;
       case "Mlist":
       $tmpcode=str_replace("{!--TEMP.".$partkey[$i]."=".$partval[$i]."--}",$ct->maketempcode("list",$dmx,$mky,$mkv,$casecodey),$tmpcode);
       $alljsfiles=$alljsfiles.$tmpjsfilex.$ct->maketmpcdjsf("list",$dmx,$mky,$mkv,$casecode);
       $allcssfiles=$allcssfiles.$tmpcssfilex.$ct->maketmpcdcssf("list",$dmx,$mky,$mkv,$casecode);
       $cloalljsfiles=$cloalljsfiles.$fmclojsf.maketmpcdjsf("list",$dmx,$mky,$mkv,$casecode);
       $cloallcssfiles=$cloalljsfiles.$fmclocssf.maketmpcdcssf("list",$dmx,$mky,$mkv,$casecode);
       $allstylex=$allstylex.$tmpstylex.$ct->maketmpcdstlx("list",$dmx,$mky,$mkv,$casecode);
       $allscriptx=$allscriptx.$tmpscriptx.$ct->maketmpcdscptx("list",$dmx,$mky,$mkv,$casecode);
       break;
       case "detail":
       $tmpcode=str_replace("{!--TEMP.".$partkey[$i]."=".$partval[$i]."--}",$ct->maketempcode("detail",$dmx,$mky,$mkv,$casecodey),$tmpcode);
       $alljsfiles=$alljsfiles.$tmpjsfilex.$ct->maketmpcdjsf("detail",$dmx,$mky,$mkv,$casecode);
       $allcssfiles=$allcssfiles.$tmpcssfilex.$ct->maketmpcdcssf("detail",$dmx,$mky,$mkv,$casecode);
       $cloalljsfiles=$cloalljsfiles.$fmclojsf.maketmpcdjsf("detail",$dmx,$mky,$mkv,$casecode);
       $cloallcssfiles=$cloalljsfiles.$fmclocssf.maketmpcdcssf("detail",$dmx,$mky,$mkv,$casecode);
       $allstylex=$allstylex.$tmpstylex.$ct->maketmpcdstlx("detail",$dmx,$mky,$mkv,$casecode);
       $allscriptx=$allscriptx.$tmpscriptx.$ct->maketmpcdscptx("detail",$dmx,$mky,$mkv,$casecode);
       break;
       case "Mdetail":
       $tmpcode=str_replace("{!--TEMP.".$partkey[$i]."=".$partval[$i]."--}",$ct->maketempcode("detail",$dmx,$mky,$mkv,$casecodey),$tmpcode);
       $alljsfiles=$alljsfiles.$tmpjsfilex.$ct->maketmpcdjsf("detail",$dmx,$mky,$mkv,$casecode);
       $allcssfiles=$allcssfiles.$tmpcssfilex.$ct->maketmpcdcssf("detail",$dmx,$mky,$mkv,$casecode);
       $cloalljsfiles=$cloalljsfiles.$fmclojsf.maketmpcdjsf("detail",$dmx,$mky,$mkv,$casecode);
       $cloallcssfiles=$cloalljsfiles.$fmclocssf.maketmpcdcssf("detail",$dmx,$mky,$mkv,$casecode);
       $allstylex=$allstylex.$tmpstylex.$ct->maketmpcdstlx("detail",$dmx,$mky,$mkv,$casecode);
       $allscriptx=$allscriptx.$tmpscriptx.$ct->maketmpcdscptx("detail",$dmx,$mky,$mkv,$casecode);
       break;
       case "form":
       $tmpcode=str_replace("{!--TEMP.".$partkey[$i]."=".$partval[$i]."--}",$ct->maketempcode("form",$dmx,$mky,$mkv,$casecodey),$tmpcode);
       $alljsfiles=$alljsfiles.$tmpjsfilex.$ct->maketmpcdjsf("form",$dmx,$mky,$mkv,$casecode);
       $allcssfiles=$allcssfiles.$tmpcssfilex.$ct->maketmpcdcssf("form",$dmx,$mky,$mkv,$casecode);
       $cloalljsfiles=$cloalljsfiles.$fmclojsf.maketmpcdjsf("form",$dmx,$mky,$mkv,$casecode);
       $cloallcssfiles=$cloalljsfiles.$fmclocssf.maketmpcdcssf("form",$dmx,$mky,$mkv,$casecode);
       $allstylex=$allstylex.$tmpstylex.$ct->maketmpcdstlx("form",$dmx,$mky,$mkv,$casecode);
       $allscriptx=allscriptx.$tmpscriptx.$ct->maketmpcdscptx("form",$dmx,$mky,$mkv,$casecode);
       break;
       case "Mform":
       $tmpcode=str_replace("{!--TEMP.".$partkey[$i]."=".$partval[$i]."--}",$ct->maketempcode("form",$dmx,$mky,$mkv,$casecodey),$tmpcode);
       $alljsfiles=$alljsfiles.$tmpjsfilex.$ct->maketmpcdjsf("form",$dmx,$mky,$mkv,$casecode);
       $allcssfiles=$allcssfiles.$tmpcssfilex.$ct->maketmpcdcssf("form",$dmx,$mky,$mkv,$casecode);
       $cloalljsfiles=$cloalljsfiles.$fmclojsf.maketmpcdjsf("form",$dmx,$mky,$mkv,$casecode);
       $cloallcssfiles=$cloalljsfiles.$fmclocssf.maketmpcdcssf("form",$dmx,$mky,$mkv,$casecode);
       $allstylex=$allstylex.$tmpstylex.$ct->maketmpcdstlx("form",$dmx,$mky,$mkv,$casecode);
       $allscriptx=allscriptx.$tmpscriptx.$ct->maketmpcdscptx("form",$dmx,$mky,$mkv,$casecode);
       break;
       default:       
       $tmpcode=str_replace("{!--TEMP.".$partkey[$i]."=".$partval[$i]."--}",$tmpcodex,$tmpcode);
       $alljsfiles=$alljsfiles.$tmpjsfilex;
       $allcssfiles=$allcssfiles.$tmpcssfilex;
       $cloalljsfiles=$cloalljsfiles.$fmclojsf;
       $cloallcssfiles=$cloalljsfiles.$fmclocssf;
       $allstylex=$allstylex.$tmpstylex;
       $allscriptx=$allscriptx.$tmpscriptx;
     }//switch
    }//if counttmp
   }//if i
  } // while
   $pagehtml=str_replace("<!--thesecomCSSFILES-->",formcss(onlyone($allcssfiles)),$pagehtml);
   $pagehtml=str_replace("<!--thesecomJSFILES-->",formjs(onlyone($alljsfiles)),$pagehtml);
   $pagehtml=str_replace("<!--thiscomSTYLE-->",$allstylex,$pagehtml);
   $pagehtml=str_replace("<!--thiscomSCRIPT-->",$allscriptx,$pagehtml);
   $pagehtml=str_replace("<!--thiscomHTML-->",turnlab($tmpcode),$pagehtml);
   $pagehtml=str_replace("<!--thistitle-->",$utitle,$pagehtml);
   $clopagehtml=str_replace("<!--thesecomCSSFILES-->",formcss(onlyone(str_replace("/FACE/","",$allcssfiles))),$clopagehtml);
   $clopagehtml=str_replace("<!--thesecomJSFILES-->",formjs(onlyone(str_replace("/FACE/","",$cloalljsfiles))),$clopagehtml);
   $clopagehtml=str_replace("<!--thiscomSTYLE-->",$allstylex,$clopagehtml);
   $clopagehtml=str_replace("<!--thiscomSCRIPT-->",$allscriptx,$clopagehtml);
   $clopagehtml=str_replace("<!--thiscomHTML-->",turnlab($tmpcode),$clopagehtml);
   $clopagehtml=str_replace("<!--thistitle-->",$utitle,$clopagehtml);
   
 }else{//menu,list,detail,form Mlist,Mdetail,Mform
   $extnext=0;
   $dmx=$domain;
   $mkx=$mark;
   if (strpos($mkx,"@")>0){
     $mky=qian($mkx,"@");
     $mkv=hou($mkx,"@");
   }else{
     $mky=$mkx;
     $mkv="";
   } 
   if ($casedemo==""){
       $casedemo=casedft($uclass,$domain,$mark);
   }    
   if (strpos($mark,"@")>0){
     $setk=qian($mark,"@");
     $setv=hou($mark,"@");
   }else{
     $setk=$mark;
     $serv="";
   }
   $alljsfiles=onlyone($jsfiles.$ct->maketmpcdjsf($uclass,$domain,$setk,$setv,$casecode));
   $allcssfiles=onlyone($cssfiles.$ct->maketmpcdcssf($uclass,$domain,$setk,$setv,$casecode));
   $allstylex=$stylex.$ct->maketmpcdstlx($uclass,$domain,$setk,$setv,$casecode);   
   $allscriptx=$scriptx.$ct->maketmpcdscptx($uclass,$domain,$setk,$setv,$casecode);
   $makecodey=$ct->maketempcode($uclass,$dmx,$mky,$mkv,$casecode);
   $pagehtml=str_replace("<!--thesecomCSSFILES-->",formcss(onlyone($allcssfiles)),$pagehtml);  
   $pagehtml=str_replace("<!--thesecomJSFILES-->",formjs(onlyone($alljsfiles)),$pagehtml);   
   $pagehtml=str_replace("<!--thiscomSTYLE-->",$allstylex,$pagehtml);   
   $pagehtml=str_replace("<!--thiscomSCRIPT-->",$allscriptx,$pagehtml);   
   $pagehtml=str_replace("<!--thiscomHTML-->",$makecodey,$pagehtml);  
   $pagehtml=str_replace("<!--thistitle-->",$utitle,$pagehtml);
   $clopagehtml=str_replace("<!--thesecomCSSFILES-->",formcss(onlyone(str_replace("/FACE/","",$allcssfiles))),$clopagehtml);
   $clopagehtml=str_replace("<!--thesecomJSFILES-->",formjs(onlyone(str_replace("/FACE/","",$alljsfiles))),$clopagehtml);
   $clopagehtml=str_replace("<!--thiscomSTYLE-->",$allstylex,$clopagehtml);
   $clopagehtml=str_replace("<!--thiscomSCRIPT-->",$allscriptx,$clopagehtml);
   $clopagehtml=str_replace("<!--thiscomHTML-->",$makecodey,$clopagehtml);
   $clopagehtml=str_replace("<!--thistitle-->",$utitle,$clopagehtml);
  }
  $ext0=UX("select count(*) as result from coode_mydomainunit where domainmark='".$domain."' and unitmark='".$mark."'");
  if ($srddemo==""){   
    if (substr($uclass,0,1)=="M"){
      $srddemo=mbltmpdft();
    }else{
      $srddemo=tempdefault();
    }    
  }
  if ($casecode==""){
       $casecode=casedft($uclass,$domain,$mark);
   }
  if (intval($ext0)>0){
    $sqlx="UPTM=now(),sysid='".$sysid."',appid='".$appid."',unittitle='".$utitle."',unitclass='".$uclass."',unitdescrib='".$udescrib."',cssfilex='".onlyone($cssfiles)."',jsfilex='".onlyone($jsfiles)."',stylex='".gohex($stylex)."',scriptx='".gohex($scriptx)."',casecode='".gohex($casedemo)."',templatecode='".gohex($otmpcode)."',pagesurround='".gohex($srdcode)."',cssfiley='".onlyone($allcssfiles)."',jsfiley='".onlyone($alljsfiles)."',styley='".gohex($allstylex)."',scripty='".gohex($allscriptx)."',demoresult='".gohex(turnlab($tmpcode))."',pagesurround='".gohex($srddemo)."',pagehtml='".gohex($pagehtml)."',outurl='".$outurl."'";
    $z=UX("update coode_mydonunit set ".$sqlx." where domainmark='".$domain."' and unitmark='".$mark."'");    
  }else{
    if ($domain!="" and $mark!=""){
     $sqlx="sysid,appid,outurl,domainmark,unitmark,unittitle,unitclass,unitdescrib,cssfilex,jsfilex,stylex,scriptx,cssfiley,jsfiley,styley,scripty,casecode,templatecode,pagesurround,demoresult,pagehtml";
     $sqly="'".$sysid."','".$appid."','".$outurl."','".$domain."','".$mark."','".$utitle."','".$uclass."','".$udescrib."','".onlyone($cssfiles)."','".onlyone($jsfiles)."','".gohex($stylex)."','".gohex($scriptx)."','".onlyone($allcssfiles)."','".onlyone($alljsfiles)."','".gohex($allstylex)."','".gohex($allscriptx)."','".gohex($casecode)."','".gohex($otmpcode)."','".gohex($srddemo)."','".gohex(turnlab($tmpcode))."','".gohex($pagehtml)."'";
     $z=UX("insert into coode_mydonunit(".$sqlx.")values(".$sqly.")");
    }
  }
  $ext1=UX("select count(*) as result from coode_mydocloneunit where domainmark='".$domain."' and unitmark='".$mark."'");
  if (intval($ext1)>0){
    $sqlx="dumark='".$domain.".".$mark."',sysid='".$sysid."',appid='".$appid."',unittitle='".$utitle."',unitclass='".$uclass."',unitdescrib='".$udescrib."',cssfilex='".onlyone($clocssfiles)."',jsfilex='".onlyone($clojsfiles)."',stylex='".gohex($stylex)."',scriptx='".gohex($scriptx)."',casecode='".gohex($casedemo)."',templatecode='".gohex($otmpcode)."',pagesurround='".gohex($srdcode)."',cssfiley='".onlyone($cloallcssfiles)."',jsfiley='".onlyone($cloalljsfiles)."',styley='".gohex($allstylex)."',scripty='".gohex($allscriptx)."',demoresult='".gohex(turnlab($tmpcode))."',pagesurround='".gohex($srddemo)."',pagehtml='".gohex($pagehtml)."',outurl='".$outurl."'";
    $z=UX("update coode_mydocloneunit set ".$sqlx." where domainmark='".$domain."' and unitmark='".$mark."'");    
  }else{
    if ($domain!="" and $mark!=""){
     $sqlx="sysid,appid,outurl,dumark,domainmark,unitmark,unittitle,unitclass,unitdescrib,cssfilex,jsfilex,stylex,scriptx,cssfiley,jsfiley,styley,scripty,casecode,templatecode,pagesurround,demoresult,pagehtml";
     $sqly="'".$sysid."','".$appid."','".$outurl."','".$domain.".".$mark."','".$domain."','".$mark."','".$utitle."','".$uclass."','".$udescrib."','".onlyone($clocssfiles)."','".onlyone($clojsfiles)."','".gohex($stylex)."','".gohex($scriptx)."','".onlyone($cloallcssfiles)."','".onlyone($cloalljsfiles)."','".gohex($allstylex)."','".gohex($allscriptx)."','".gohex($casecode)."','".gohex($otmpcode)."','".gohex($srddemo)."','".gohex(turnlab($tmpcode))."','".gohex($pagehtml)."'";
     $z=UX("insert into coode_mydocloneunit(".$sqlx.")values(".$sqly.")");
    }
  }
  $ZZ=UX("update coode_mydonunit set dumark=concat(domainmark,'.',unitmark)");
  if ($domain!="" and $mark!=""){
    if (strpos($outurl,".html")>0){     
       $outx=combineurl(localroot(),$outurl);                   
       $odata=gohex(file_get_contents($outx));
       $srclenx= checklines($odata,gohex($pagehtml));
       $olenx=qian($srclenx,"/");
       $nlenx=hou($srclenx,"/");
       $kx=recmylines($domain.".".$mark,$domain.".".$mark,$domain.".".$mark,$domain.".".$mark,"template",$olenx,$nlenx,$pagehtml);
       overfile($outx,str_replace("/MYFACE/","",$pagehtml));      
    }      
    for ($f=0;$f<$totface;$f++){
      if ($ptface[$f]!="" and strpos('x'.$ptface[$f],'"')<=0  and strpos("x".$ptface[$f],"'")<=0){
       if ($quick==""){
        $tmpface=$ptface[$f];      
        $b=anyfunrun("upfoldertocloud","","ddd=/MYFACE/".$tmpface,"");
       }
     }
    }
    if ($quick==""){
      $cba=anyfunrun("upfoldertocloud","","ddd=/myunits/".$domain,"");
    }
    echo "1";
  }else{
    echo "0";
  }
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>