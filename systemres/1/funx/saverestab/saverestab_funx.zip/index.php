<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $restype=dftval($_GET["restype"],"");
$resmark=dftval($_GET["resmark"],"");
$resmark=str_replace("_temp","_unit",$resmark);
$rescode=str_replace("_unit","",$resmark);
$rescode=str_replace("_tab","",$rescode);
$rescode=str_replace("_data","",$rescode);
$rescode=str_replace("_plot","",$rescode);
$rescode=str_replace("_temp","",$rescode);
$rescode=str_replace("_fun","",$rescode);
$rescode=str_replace("_cls","",$rescode);
$rescode=str_replace("_tiny","",$rescode);
$demo='{"restype":"[restype]","resmark":"[resmark]","relyface":"[relyface]","restitle":"[restitle]","content":"[contx]","host":"'.$_SERVER["HTTP_HOST"].'","reskey":"[reskey]","crtsql":[{crtdata}],"itemlist":[{itemdata}],"filelist":[{filelist}]}';
$tabdemo='{"tabname":"[tabname]","sqldata":"[sqldata]"},';
$itemdemo='{"istsql":"[istsql]","svals":"[svals]"},';
$filedemo='{"localurl":"[localurl]","remoteurl":"[remoteurl]"},';
$tabnms=dftval($_GET["tabnms"],"");
$ptitle=dftval($_GET["ptitle"],"");
$fmb="";
if (strpos($tabnms,",")>0){
  $pttab=explode(",",$tabnms);
  $totpt=count($pttab);
  for ($i=0;$i<$totpt;$i++){
   $crtsql[$i]=UX("select createsql as result from coode_tablist where TABLE_NAME='".$pttab[$i]."'");    
   $fmb=$fmb.'{"tabname":"'.$pttab[$i].'","sqldata":"'.$crtsql[$i].'"},';
  }
  $fmb=killlaststr($fmb);
}else{
   $crtsqlx=UX("select createsql as result from coode_tablist where TABLE_NAME='".$tabnms."'");    
   $fmb=$fmb.'{"tabname":"'.$pttab[$i].'","sqldata":"'.$crtsqlx.'"}';
} 
   switch($restype){
    case "plot":  
    $outpath=combineurl(localroot(),"/seeds/plots/");
    $tturl=combineurl(localroot(),"/seeds/plots/".$rescode."/");
    break;
    case "temp":
    $outpath=combineurl(localroot(),"/seeds/temps/");
    $tturl=combineurl(localroot(),"/seeds/temps/".str_replace("_",".",$rescode)."/");    
    break;
    case "tab":
    $outpath=combineurl(localroot(),"/seeds/tabs/");
    $tturl=combineurl(localroot(),"/seeds/tabs/".$rescode."/");
    break;
    case "data":
    $outpath=combineurl(localroot(),"/seeds/datas/");
    $tturl=combineurl(localroot(),"/seeds/datas/".$rescode."/");
    break;
    case "tiny":
    $outpath=combineurl(localroot(),"/seeds/tinys/");
    $tturl=combineurl(localroot(),"/seeds/tinys/".$rescode."/");
    break;
    default:
   }
   switch($restype){
     case "plot":
     $frst=SX("select plotmark,markname from coode_plotlist where plotmark='".$rescode."'");
     $ftitle=anyvalue($frst,"markname",0);
     break;
     case "temp":
     $frst=SX("select unittitle,unitclass from coode_domainunit where dumark='".$rescode."'");
     $ftitle=anyvalue($frst,"unittitle",0);
     break;
     case "tab":
     $frst=SX("select tabtitle,OLMK from coode_tablist where TABLE_NAME='".$rescode."'");
     $ftitle=anyvalue($frst,"tabttitle",0);
     break;
     case "data":
     $frst=SX("select tabtitle,OLMK from coode_tablist where TABLE_NAME='".$rescode."'");
     $ftitle=anyvalue($frst,"tabttitle",0);
     $isinblog=UX("select count(*) as result from coode_keydetailx where DATA_TYPE like '%text%' and TABLE_NAME='".$rescode."'");
     $isbig=UX("select count(*) as result from ".$rescode);
     $datasrd='{"tabname":"'.$rescode.'","vls":[<data>]}';
     $itemsno=dftval($_GET["itemsno"],""); 
     if ($itemsno==""){
      if (intval($isinblog)==0 and intval($isbig)<=5000){
        $idrst=SX("select SNO,schm,itemcrtm,itemuptm,itemptof,itemsrcid,itemsrctt,tabsno,tabolmk,conjson,datajson,tabkeys,frmsql,datasql from coode_datainstall where srcid='".$rescode.".Detail'");
        $totd=countresult($idrst);
        $itemsrdx='{"sqx":"[sqx]","tabsno":"[tabsno]","tabkeys":"[tabkeys]",[arrdata],"frmsql":"[frmsql]","datasql":"[datasql]"},';
        $fmxyz="";
        
        for ($tt=0;$tt<$totd;$tt++){
          $snox=anyvalue($idrst,"SNO",$tt);
          $schmx=anyvalue($idrst,"schm",$tt);
          $itemcrtm=anyvalue($idrst,"itemcrtm",$tt);
          $itemuptm=anyvalue($idrst,"itemuptm",$tt);
          $itemptof=anyvalue($idrst,"itemptof",$t);
          $itemsrctt=anyvalue($idrst,"itemsrctt",$tt);
          $tabsno=anyvalue($idrst,"tabsno",$tt);
          $tabolmk=anyvalue($idrst,"tabolmk",$tt);
          $conjson=anyvalue($idrst,"conjson",$tt);
          $datajson=anyvalue($idrst,"datajson",$tt);
          $tabkeys=anyvalue($idrst,"tabkeys",$tt);
          $frmsql=anyvalue($idrst,"frmsql",$tt);
          $datasql=anyvalue($idrst,"datasql",$tt);
          $itemsrd=$itemsrdx;
          $datajson=str_replace("〖","\"",$datajson);
          $datajson=str_replace("Ｔ","\":\"",$datajson);
          $datajson=str_replace("Ｖ","\",\"",$datajson);
          $datajson=str_replace("〗","\"",$datajson);
          $itemsrd=str_replace("[arrdata]",$datajson,$itemsrd);
          $itemsrd=str_replace("[sqx]",$tt,$itemsrd);
          $itemsrd=str_replace("[tabsno]",$tabsno,$itemsrd);
          $itemsrd=str_replace("[tabkeys]",$tabkeys,$itemsrd);
          $itemsrd=str_replace("[frmsql]",$frmsql,$itemsrd);
          $itemsrd=str_replace("[datasql]",$datasql,$itemsrd);
          $fmxyz=$fmxyz.$itemsrd;
        }
         $fmxyz=killlaststr($fmxyz);
        $datasrd='{"tabname":"'.$rescode.'","msg":"islist","vls":[<data>]}';
        $datasrd=str_replace("<data>",$fmxyz,$datasrd);
        $svpath=combineurl(localroot(),"/seeds/datas/".$rescode."/detailindex.json");
        $zj=overfile($svpath,$datasrd);
      }else{
        $datasrd='{"tabname":"'.$rescode.'","msg":"nolist","vls":[<data>]}';
        $datasrd=str_replace("<data>","",$datasrd);
        $svpath=combineurl(localroot(),"/seeds/datas/".$rescode."/detailindex.json");
        $zj=overfile($svpath,$datasrd);
      }
     }else{
     
        $idrst=SX("select SNO,schm,itemcrtm,itemuptm,itemptof,itemsrcid,itemsrctt,tabsno,tabolmk,conjson,datajson,tabkeys,frmsql,datasql from coode_datainstall where srcid='".$tabnm.".Detail' and tabsno='".$itemsno."'");
        $snox=anyvalue($idrst,"SNO",0);
        $schmx=anyvalue($idrst,"schm",0);
        $itemcrtm=anyvalue($idrst,"itemcrtm",0);
        $itemuptm=anyvalue($idrst,"itemuptm",0);
        $itemptof=anyvalue($idrst,"itemptof",0);
        $itemsrctt=anyvalue($idrst,"itemsrctt",0);
        $tabsno=anyvalue($idrst,"tabsno",0);
        $tabolmk=anyvalue($idrst,"tabolmk",0);
        $conjson=anyvalue($idrst,"conjson",0);
        $datajson=anyvalue($idrst,"datajson",0);
        $tabkeys=anyvalue($idrst,"tabkeys",0);
        $frmsql=anyvalue($idrst,"frmsql",0);
        $datasql=anyvalue($idrst,"datasql",0);
        $itemsrd=str_replace("[tabnm]",$tabnm,$itemsrd);
        $itemsrd=str_replace("[tabsno]",$tabsno,$itemsrd);
        $itemsrd=str_replace("[tabkeys]",$tabkeys,$itemsrd);
        $itemsrd=str_replace("[tabsno]",$tabsno,$itemsrd);
        $datajson=str_replace("〖","\"",$datajson);
        $datajson=str_replace("Ｔ","\":\"",$datajson);
        $datajson=str_replace("Ｖ","\",\"",$datajson);
        $datajson=str_replace("〗","\"",$datajson);
        $itemsrd=str_replace("[arrdata]",$datajson,$itemsrd);
        $itemsrd=str_replace("[frmsql]",$frmsql,$itemsrd);
        $itemsrd=str_replace("[datasql]",$datasql,$itemsrd);
        $ofnm=combineurl(localroot(),"/seeds/datas/".$tabnm."/details/".$tabsno.".json");
        $kz=overfile($ofnm,$itemsrd);        
        
     }
     
     break;
     case "tiny":
      $frst=SX("select tinytitle,tinymark,sysid,appid,layid from coode_tiny where tinymark='".$rescode."'");
      $ftitle=anyvalue($frst,"tinytitle",0);
      $sysid=anyvalue($frst,"sysid",0);
      $appid=anyvalue($frst,"appid",0);
      $layid=anyvalue($frst,"layid",0);
     break;     
     default:
   }
   
   $totf=countresult($frst);
   if (intval($totf)>0){
     
     $demo=str_replace("[restype]",$restype,$demo);
     $demo=str_replace("[restitle]",$ftitle,$demo);
     $demo=str_replace("[resmark]",$rescode,$demo);
     $demo=str_replace("[contx]","",$demo);
     $demo=str_replace("[reskey]","",$demo);     
     $demo=str_replace("[relyface]","",$demo);               
     $demo=str_replace("{crtdata}",$tabcrt,$demo);
     if ($itemsno==""){
       $drst=SX("select frmsql,datasql from coode_datainstall where srcid='".$resmark."'");     
       $totd=countresult($drst);
       $fmitem="";
      for ($p=0;$p<$totd;$p++){
       $frmsql=anyvalue($drst,"frmsql",$p);
       $datasql=anyvalue($drst,"datasql",$p);
       $itemx=$itemdemo;
       $itemx=str_replace("[istsql]",$frmsql,$itemx);
       $itemx=str_replace("[svals]",$datasql,$itemx);
       $fmitem=$fmitem.$itemx;
      }
       $b=time();
       $fmitem=killlaststr($fmitem);
       $demo=str_replace("{itemdata}",$fmitem,$demo);
       $demo=str_replace("{crtdata}","",$demo);
       $demo=str_replace("{filelist}","",$demo);
       $zz=overfile($outpath.$resmark.".json",$demo);
       $zz1=overfile($tturl."index.json",$demo);      
       $frompath=combineurl(localroot(),"/seeds/localarea/");
       $topath=$tturl;
       $xx=copy_dir($frompath,$topath);
       $xxx=UX("delete from coode_seeds where restype='".$restype."' and resmark='".$rescode."'");
       $sqlx="sysid,appid,layid,restype,resmark,restitle,seedcontent,OLMK,CRTM,UPTM";
       $sqly="'".$sysid."','".$appid."','".$layid."','".$restype."','".$rescode."','".$ftitle."','".$demo."','".onlymark()."',now(),now()";
       $zzz=UX("insert into coode_seeds(".$sqlx.")values(".$sqly.")");
       echo makereturnjson("1","生成节点为".$resmark."的种子成功",($b-$a));
      }else{
       echo makereturnjson("1","生成".$tabnm."表的序号为".$tabsno."的数据成功","");
      }
    }else{
     echo makereturnjson("0","生成节点为".$resmark."的种子失败",($b-$a));
    }
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>