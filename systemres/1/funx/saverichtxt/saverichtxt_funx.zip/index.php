<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       eval(RESFUNSET("tabbaseinfo"));
eval(RESFUNSET("dspbasecoprt"));
$datapath=dftval($_GET["datapath"],"");
//$datapath="TAB:dbmk@tabnm/resid_SNO:30.savekey";  AV  SETV 用这个方法快速查看
//$datapath="DS:dtmk@30.savekey";
$richtxt=unstrs(dftval(_post("richtxt"),""));
if ($datapath!=""){      
    $nnn=SPV($datapath,gohex($richtxt));      
   echo makereturnjson("1","修改成功","");
}else{
  echo makereturnjson("0","参数不全","");
}
       session_write_close();
?>