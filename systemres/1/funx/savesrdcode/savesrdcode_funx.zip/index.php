<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $tdmcode=_get("tdmcode");
if ($tdmcode!=""){
 $srddemo=gohex(unstrs(_post("srddemo")));
 $tabformsrd=gohex(unstrs(_post("tabformsrd")));
 $tabformwhole=gohex(unstrs(_post("tabformwhole")));
 $srdstart=gohex(unstrs(_post("srdstart")));
 $stylex=gohex(unstrs(_post("stylex")));
 $scriptx=gohex(unstrs(_post("scriptx")));
 $zz=UX("update coode_tempcssdfn set scriptx='".$scriptx."',stylex='".$stylex."',srddemo='".$srddemo."',tabformsrd='".$tabformsrd."',tabformwhole='".$tabformwhole."',srdstart='".$srdstart."' where tdmcode='".$tdmcode."'");
 $zz=UX("update coode_temploveform set scriptx='".$scriptx."',stylex='".$stylex."',srddemo='".$srddemo."',tabformsrd='".$tabformsrd."',tabformwhole='".$tabformwhole."',srdstart='".$srdstart."' where tdmcode='".$tdmcode."'");
 $zz=UX("update coode_domainunit set scriptx='".$scriptx."',stylex='".$stylex."',pagesurround='".$srddemo."' where dumark='".$tdmcode."'");
 //$zz=addprcx("update coode_tempcssdfn set srddemo='".$srddemo."',tabformsrd='".$tabformsrd."',tabformwhole='".$tabformwhole."',srdstart='".$srdstart."' where tdmcode='".$tdmcode."'");
 echo makereturnjson("1","修改成功","");
}else{
 echo makereturnjson("0","修改失败-参数不全","");
}
       session_write_close();
?>