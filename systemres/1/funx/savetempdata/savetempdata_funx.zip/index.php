<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $b=eval(RESFUNSET("tabdataoprt"));
$b=eval(RESFUNSET("recline"));
$b=eval(RESFUNSET("democode"));
$b=eval(RESFUNSET("tempneedcode"));
 
$domain=$_POST["domain"];
$mark=$_POST["mark"];
$amd5="a".md5($domain.$mark);
$z=setvarval($amd5,"");
$utitle=$_POST["unittitle"];
$uclass=$_POST["unitclass"];
$udescrib=$_POST["unitdescrib"];
$stylex=unstrs($_POST["stylex"]);
$scriptx=unstrs($_POST["scriptx"]);
$casecode=unstrs($_POST["casecode"]);
$casedemo=$casecode;
$tmpcode=unstrs($_POST["tmpcode"]);
$bodycode=$tmpcode;
$otmpcode=$tmpcode;
$srdcode=unstrs($_POST["srdcode"]);
$srddemo=$srdcode;
$jsfiles=unstrs($_POST["jsfiles"]);
$cssfiles=unstrs($_POST["cssfiles"]);
$outurl=$_POST["outurl"];
$alljsfiles=$jsfiles;
$allcssfiles=$cssfiles;
$allstylex=$stylex;
$allscriptx=$scriptx;
$pagehtml=turnlab($srdcode);
$rmthtml="";
$quick=dftval($_GET["quick"],"");
$ptjsfiles=explode(";",$jsfiles);
$totptj=count($ptjsfiles);
$ptcssfiles=explode(";",$cssfiles);
$totptc=count($ptcssfiles);
$fmface="";
for ($m=0;$m<$totptc;$m++){
  if (strpos($ptcssfiles[$m],"localxres/csspagex/")>0){
   $tmpface=qian(hou($ptcssfiles[$m],"localxres/csspagex/"),"/");
   if (strpos($fmface,$tmpface)>0){    
   }else{
    $fmface=$fmface.$tmpface.";";
   }
  }
}
for ($m=0;$m<$totptj;$m++){
  if (strpos($ptjsfiles[$m],"localxres/csspagex/")>0){
   $tmpface=qian(hou($ptjsfiles[$m],"localxres/csspagex/"),"/");
   if (strpos($fmface,$tmpface)>0){    
   }else{
    $fmface=$fmface.$tmpface.";";
   }
  }
}
$otherface=absorbface($tmpcode).absorbface($stylex).absorbface($scriptx);
$otherface=str_replace(",",";",$otherface);
if ($otherface!=""){
  $fmface=$fmface.$otherface;
}
$fmface=onlyone($fmface);
$ptface=explode(";",$fmface);
$totface=count($ptface);
 $ptout=explode("/",$outurl);
 $totpto=count($ptout);
 $fmpto="";
 for ($z=0;$z<($totpto-1);$z++){
  $fmpto=$fmpto.$ptout[$z]."/";
 }
 for ($f=0;$f<$totface;$f++){
  if ($ptface[$f]!="" and strpos('x'.$ptface[$f],'"')<=0  and strpos("x".$ptface[$f],"'")<=0){
   $tmpface=$ptface[$f];
   $tmpfromurl=combineurl(localroot(),"/localxres/csspagex/".$tmpface);
   $tturl=combineurl(localroot(),$fmpto.$tmpface);
    $extf=UX("select count(*) as result from coode_unitface where faceid='".$tmpface."' and dumark='".$domain.".".$mark."'");
    if (intval($extf)==0){
      $sqlx="faceid,dumark,CRTM,UPTM,OLMK,CRTOR";
      $sqly="'$tmpface','".$domain.".".$mark."',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."'";
      $sz=UX("insert into coode_unitface($sqlx)values($sqly)");
    }else{
      $uu=UX("update coode_unitface set UPTM=now()  where faceid='".$tmpface."' and dumark='".$domain.".".$mark."'");
    }
    if ($outurl!=""){
     if ($quick==""){
      is_dir($tturl) OR mkdir($tturl, 0777, true);
      copy_dir($tmpfromurl,$tturl);
     }else{
      if ($quick=="2"){
       if (is_dir($tturl)){      
       }else{
        is_dir($tturl) OR mkdir($tturl, 0777, true);
        copy_dir($tmpfromurl,$tturl);
       }
      }
     }
    }
  }
 }
 $uu=UX("delete from coode_unitface where  dumark='".$domain.".".$mark."' and timestampdiff(second,UPTM,now())>30");
eval(CLASSX("coodetemplate"));
$ct=new coodetemplate();
$newtempc=$tmpcode;
if ($uclass!="menu" and $uclass!="form" and $uclass!="list" and $uclass!="detail"  and $uclass!="Mlist" and $uclass!="Mdetail" and $uclass!="Mform" ){
  $rmthtml=$pagehtml;
  if ($casedemo!=""){
    eval($casedemo);
  }
  $pagehtml=str_replace("<!--thesecomCSSFILES-->",formcss(onlyone($allcssfiles)),$pagehtml);
  $rmthtml=str_replace("<!--thesecomCSSFILES-->",formrmtcss(onlyone($allcssfiles)),$rmthtml);
  $pagehtml=str_replace("<!--thesecomJSFILES-->",formjs(onlyone($alljsfiles)),$pagehtml);
  $rmthtml=str_replace("<!--thesecomJSFILES-->",formrmtjs(onlyone($alljsfiles)),$rmthtml);
  $pagehtml=str_replace("<!--thiscomSTYLE-->",$allstylex,$pagehtml);
  $rmthtml=str_replace("<!--thiscomSTYLE-->",$allstylex,$rmthtml);
  $pagehtml=str_replace("<!--thiscomSCRIPT-->",$allscriptx,$pagehtml);
  $rmthtml=str_replace("<!--thiscomSCRIPT-->",$allscriptx,$rmthtml);
  $pagehtml=str_replace("<!--thiscomHTML-->",turnlab($tmpcode),$pagehtml);
  $rmthtml=str_replace("<!--thiscomHTML-->",turnlab($tmpcode),$rmthtml);
  $pagehtml=str_replace("<!--thistitle-->",$utitle,$pagehtml);
  $rmthtml=str_replace("<!--thistitle-->",$utitle,$rmthtml);  
 }else{//menu,list,detail,form Mlist,Mdetail,Mform  一下是MFORM
  $extnext=0;
  $dmx=$domain;
  $mkx=$mark;
  if (strpos($mkx,"@")>0){
    $mky=qian($mkx,"@");
    $mkv=hou($mkx,"@");
  }else{
    $mky=$mkx;
    $mkv="";
  } 
  if ($casedemo==""){
     $casedemo=casedft($uclass,$domain,$mark);
  }   
  if (strpos($mark,"@")>0){
    $setk=qian($mark,"@");
    $setv=hou($mark,"@");
  }else{
    $setk=$mark;
    $serv="";
  }
   $alljsfiles=onlyone($jsfiles.$ct->maketmpcdjsf($uclass,$domain,$setk,$setv,$casecode)."/localxres/tempx/".$domain."/js/".$domain."_".$mark."_".strtolower($uclass)."demo.js?date=[date];/localxres/tempx/".$domain."/js/".$domain."_".$mark."_cssdemo.js?date=[date];");
   $allcssfiles=onlyone($cssfiles.$ct->maketmpcdcssf($uclass,$domain,$setk,$setv,$casecode)."/localxres/tempx/".$domain."/css/".$domain."_".$mark."_".strtolower($uclass)."ldemo.css?date=[date];");
   $allstylex=$stylex;  
   $allscriptx=$scriptx;  
   $makecodey=$ct->maketempcode($uclass,$dmx,$mky,$mkv,$casecode);
   if (str_replace(" ","",$otmpcode)==""){    
    $otmpcode=$makecodey;
    $tmpcode=$makecodey;
   }
   $outaurl=combineurl(localroot(),"/localxres/tempx/".$domain."/js/".$domain."_".$mark."_".strtolower($uclass)."demo.js");   
   $outburl=combineurl(localroot(),"/localxres/tempx/".$domain."/css/".$domain."_".$mark."_".strtolower($uclass)."ldemo.css");   
   $axx=overfile($outaurl,$ct->maketmpcdscptx($uclass,$domain,$setk,$setv,$casecode));   
   $bxx=overfile($outburl,$ct->maketmpcdstlx($uclass,$domain,$setk,$setv,$casecode));
  $rmthtml=$pagehtml;
  $pagehtml=str_replace("<!--thesecomCSSFILES-->",formcss(onlyone($allcssfiles)),$pagehtml);
  $rmthtml=str_replace("<!--thesecomCSSFILES-->",formrmtcss(onlyone($allcssfiles)),$rmthtml);
  $pagehtml=str_replace("<!--thesecomJSFILES-->",formjs(onlyone($alljsfiles)),$pagehtml);
  $rmthtml=str_replace("<!--thesecomJSFILES-->",formrmtjs(onlyone($alljsfiles)),$rmthtml);
  $pagehtml=str_replace("<!--thiscomSTYLE-->",$allstylex,$pagehtml);
  $rmthtml=str_replace("<!--thiscomSTYLE-->",$allstylex,$rmthtml);
  $pagehtml=str_replace("<!--thiscomSCRIPT-->",$allscriptx,$pagehtml);
  $rmthtml=str_replace("<!--thiscomSCRIPT-->",$allscriptx,$rmthtml);
  $pagehtml=str_replace("<!--thiscomHTML-->",turnlab($tmpcode),$pagehtml);
  $rmthtml=str_replace("<!--thiscomHTML-->",turnlab($tmpcode),$rmthtml);
  $pagehtml=str_replace("<!--thistitle-->",$utitle,$pagehtml);
  $rmthtml=str_replace("<!--thistitle-->",$utitle,$rmthtml);
  }
  $ext0=UX("select count(*) as result from coode_domainunit where domainmark='".$domain."' and unitmark='".$mark."'");
  if ($srddemo==""){  
   if (substr($uclass,0,1)=="M"){
    $srddemo=mbltmpdft();
   }else{
    $srddemo=tempdefault();
   }   
  }
  if ($casecode==""){
     $casecode=casedft($uclass,$domain,$mark);
  }
  if (intval($ext0)>0){
   $sqlx="UPTM=now(),PRIME=1,VRT='".md5($pagehtml)."',unittitle='".$utitle."',unitclass='".$uclass."',unitdescrib='".$udescrib."',cssfilex='".onlyone($cssfiles)."',jsfilex='".onlyone($jsfiles)."',stylex='".gohex($stylex)."',scriptx='".gohex($scriptx)."',casecode='".gohex($casedemo)."',templatecode='".gohex($otmpcode)."',pagesurround='".gohex($srdcode)."',cssfiley='".onlyone($allcssfiles)."',jsfiley='".onlyone($alljsfiles)."',styley='".gohex($allstylex)."',scripty='".gohex($allscriptx)."',demoresult='".gohex(turnlab($tmpcode))."',pagesurround='".gohex($srddemo)."',pagehtml='".gohex($pagehtml)."',outurl='".$outurl."',relyface='".$fmface."'";
   $z=UX("update coode_domainunit set ".$sqlx." where domainmark='".$domain."' and unitmark='".$mark."'");   
  }else{
   if ($domain!="" and $mark!=""){
    $sqlx="vermd5,relyface,outurl,domainmark,unitmark,unittitle,unitclass,unitdescrib,cssfilex,jsfilex,stylex,scriptx,cssfiley,jsfiley,styley,scripty,casecode,templatecode,pagesurround,demoresult,pagehtml";
    $sqly="'".md5($pagehtml)."','".$fmface."','".$outurl."','".$domain."','".$mark."','".$utitle."','".$uclass."','".$udescrib."','".onlyone($cssfiles)."','".onlyone($jsfiles)."','".gohex($stylex)."','".gohex($scriptx)."','".onlyone($allcssfiles)."','".onlyone($alljsfiles)."','".gohex($allstylex)."','".gohex($allscriptx)."','".gohex($casecode)."','".gohex($otmpcode)."','".gohex($srddemo)."','".gohex(turnlab($tmpcode))."','".gohex($pagehtml)."'";
    $z=UX("insert into coode_domainunit(".$sqlx.")values(".$sqly.")");
   }   
  }
  
  $ZZ=UX("update coode_domainunit set dumark=concat(domainmark,'.',unitmark)");
  if ($domain!="" and $mark!=""){
   if (strpos($outurl,".html")>0 ){    
     $outx=combineurl(localroot(),$outurl);        
     $outy=str_replace(".html","-remote.html",$outx); 
     $odata=gohex(file_get_contents($outx));
     $srclenx= checklines($odata,gohex($pagehtml));
     $olenx=qian($srclenx,"/");
     $nlenx=hou($srclenx,"/");
     $kx=reclines($domain.".".$mark,$domain.".".$mark,$domain.".".$mark,$domain.".".$mark,"template",$olenx,$nlenx,$pagehtml);     
     overfile($outx,str_replace("/localxres/csspagex/","",$pagehtml)); 
     overfile($outy,$rmthtml); 
     $seedurl="http://".glw()."localxres/funx/savetoseed/?restype=tempx&resmark=".$domain.".".$mark;
     $zz=file_get_contents($seedurl);
   }       
   echo "1";
  }else{
   echo "0";
  }
       session_write_close();
?>