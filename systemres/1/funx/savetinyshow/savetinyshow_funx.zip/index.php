<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $clone=$_GET["clone"];
$domain=$_POST["domain"];
$tinyid=$_POST["tinyid"];
$mark=$_POST["mark"];
$amd5="a".md5($domain.$mark);
$z=setvarval($amd5,"");
$utitle=$_POST["unittitle"];
$uclass=$_POST["unitclass"];
$udescrib=$_POST["unitdescrib"];
$sysid=$_POST["sysid"];
$appid=$_POST["appid"];
$stylex=unstrs($_POST["stylex"]);
$scriptx=unstrs($_POST["scriptx"]);
$casecode=unstrs($_POST["casecode"]);
$casedemo=$casecode;
$tmpcode=unstrs($_POST["tmpcode"]);
$bodycode=$tmpcode;
$otmpcode=$tmpcode;
$srdcode=unstrs($_POST["srdcode"]);
$srddemo=$srdcode;
$jsfiles=unstrs($_POST["jsfiles"]);
$cssfiles=unstrs($_POST["cssfiles"]);
$outurl=$_POST["outurl"];
$alljsfiles=$jsfiles;
$allcssfiles=$cssfiles;
$allstylex=$stylex;
$allscriptx=$scriptx;
$pagehtml=turnlab($srdcode);
$ptjsfiles=explode(";",$jsfiles);
$totptj=count($ptjsfiles);
$ptcssfiles=explode(";",$cssfiles);
$totptc=count($ptcssfiles);
$leiia=0;
$b=eval(RESFUNSET("tabdataoprt"));
$b=eval(RESFUNSET("recline"));
   if ($casedemo!=""){
    eval($casedemo);
   }
   $pagehtml=str_replace("<!--thesecomCSSFILES-->",formcss(onlyone($allcssfiles)),$pagehtml);
   $pagehtml=str_replace("<!--thesecomJSFILES-->",formjs(onlyone($alljsfiles)),$pagehtml);
   $pagehtml=str_replace("<!--thiscomSTYLE-->",$allstylex,$pagehtml);
   $pagehtml=str_replace("<!--thiscomSCRIPT-->",$allscriptx,$pagehtml);
   $pagehtml=str_replace("<!--thiscomHTML-->",turnlab($tmpcode),$pagehtml);
   $pagehtml=str_replace("<!--thistitle-->",$utitle,$pagehtml);
   
  
  $sqlx="UPTM=now(),unittitle='".$utitle."',unitclass='".$uclass."',unitdescrib='".$udescrib."',cssfilex='".onlyone($cssfiles)."',jsfilex='".onlyone($jsfiles)."',stylex='".gohex($stylex)."',scriptx='".gohex($scriptx)."',casecode='".gohex($casedemo)."',templatecode='".gohex($otmpcode)."',pagesurround='".gohex($srdcode)."',cssfiley='".onlyone($allcssfiles)."',jsfiley='".onlyone($alljsfiles)."',styley='".gohex($allstylex)."',scripty='".gohex($allscriptx)."',demoresult='".gohex(turnlab($tmpcode))."',pagesurround='".gohex($srddemo)."',pagehtml='".gohex($pagehtml)."',outurl='".$outurl."'";
  $z=UX("update coode_unittiny set ".$sqlx." where domainmark='".$domain."' and unitmark='".$mark."' and tinyid='".$tinyid."'");      
  $ZZ=UX("update coode_unittiny set dumark=concat(domainmark,'.',unitmark)");  
  if ($domain!="" and $mark!="" and $tinyid!=""){
    if (strpos($outurl,".html")>0){     
       $outx=combineurl(localroot(),$outurl);            
       $odata=gohex(file_get_contents($outx));
       $srclenx= checklines($odata,gohex($pagehtml));
       $olenx=qian($srclenx,"/");
       $nlenx=hou($srclenx,"/");
       $kx=reclines($tinyid,$tinyid,$tinyid,$tinyid,"tinypage",$olenx,$nlenx,$pagehtml);      
       overfile($outx,str_replace("/localxres/csspagex/","",$pagehtml));      
    }    
    $zz=UX("update coode_tiny set STATUS=1 where tinymark='".$tinyid."'");
    $zzx=anyfunrun("savetoseed","","restype=pagex&resmark=".$tinyid,"");
    echo makereturnjson("1","提交成功","");
  }else{
    echo makereturnjson("0","提交失败","");
  }
     session_write_close();
?>