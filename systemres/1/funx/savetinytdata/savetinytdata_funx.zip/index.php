<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     function tempdefault(){
 $dft='{!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"}
{html xmlns="http://www.w3.org/1999/xhtml"}
{!--本页面由酷德数据工厂合成，此页面若含有您所开发资源，请申诉，版权申诉地址 http(s)://'.glw().'SYS/1/userrequest/ --}
{!--本页面由酷德数据工厂合成，此页面若含有错误，请提交工单，工单提交地址 http(s)://'.glw().'SYS/1/userrequest/finderr.html --}
{!--本页面由酷德数据工厂合成，您想参与修改与编辑请访问该地址申请 http(s)://'.glw().'SYS/1/userrequest/finderr.html --}
{!--本页面由酷德数据工厂合成，查看页面资源归属请访问 http(s)://'.glw().'SYS/1/userrequest/finderr.html --}
{head}
{meta http-equiv="Content-Type" content="text/html; charset=utf-8" /}
{title}{!--thistitle--}{/title}
{!--thesecomCSSFILES--}
{!--thesecomJSFILES--}
{!--shortJSFILES--}
{!--shortCSSFILES--}
{!--thiscomSTYLE--}
{!--shortSTYLE--}
{/head}
{body}
  {!--thiscomHTML--}
  {!--thiscomSCRIPT--}
  {!--shortSCRIPT--}
{/body}
{/html}
 ';
 return $dft;
}
function mbltmpdft(){
 $dft='{!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"}
{html}
{!--本页面由酷德数据工厂合成，此页面若含有您所开发资源，请申诉，版权申诉地址 http(s)://'.glw().'SYS/1/userrequest/ --}
{!--本页面由酷德数据工厂合成，此页面若含有错误，请提交工单，工单提交地址 http(s)://'.glw().'SYS/1/userrequest/finderr.html --}
{!--本页面由酷德数据工厂合成，您想参与修改与编辑请访问该地址申请 http(s)://'.glw().'SYS/1/userrequest/finderr.html --}
{!--本页面由酷德数据工厂合成，查看页面资源归属请访问 http(s)://'.glw().'SYS/1/userrequest/finderr.html --}
{head}
{meta charset="utf-8"}
{meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" /}
{meta name="format-detection" content="telephone=no,email=no,date=no,address=no"}
{title}{!--thistitle--}{/title}
{!--thesecomCSSFILES--}
{!--thesecomJSFILES--}
{!--shortJSFILES--}
{!--shortCSSFILES--}
{!--thiscomSTYLE--}
{!--shortSTYLE--}
{/head}
{body}
  {!--thiscomHTML--}
  {!--thiscomSCRIPT--}
  {!--shortSCRIPT--}
{/body}
{/html}
 ';
 return $dft;
}
function zhushifu(){
 return "/"."/";
}
$demomark=$_POST["demomark"];
$demotitle=$_POST["demotitle"];
$srctype=$_POST["srctype"];
$stylex=unstrs($_POST["stylex"]);
$scriptx=unstrs($_POST["scriptx"]);
$tmpcode=unstrs($_POST["tmpcode"]);
$srddemo=unstrs($_POST["srdcode"]);
$jsfiles=unstrs($_POST["jsfiles"]);
$cssfiles=unstrs($_POST["cssfiles"]);
eval(RESFUNSET("combinecode"));
$outurl=$_POST["outurl"];
  if ($srddemo==""){   
    if (substr($srctype,0,1)=="M"){
      $srddemo=mbltmpdft();
    }else{
      $srddemo=tempdefault();
    }    
  }
  $pagehtml=turnlab($srddemo);
   $pagehtml=str_replace("<!--thesecomCSSFILES-->",formcss(onlyone($cssfiles)),$pagehtml);
   $pagehtml=str_replace("<!--thesecomJSFILES-->",formjs(onlyone($jsfiles)),$pagehtml);
   $pagehtml=str_replace("<!--thiscomSTYLE-->",$stylex,$pagehtml);
   $pagehtml=str_replace("<!--thiscomSCRIPT-->",$scriptx,$pagehtml);
   $pagehtml=str_replace("<!--thiscomHTML-->",turnlab($tmpcode),$pagehtml);
   $pagehtml=str_replace("<!--thistitle-->",$demotitle,$pagehtml);
   $ofile=combineurl(localroot(),$outurl);
       $odata=gohex(file_get_contents($ofile));
       $srclenx= checklines($odata,gohex($pagehtml));
       $olenx=qian($srclenx,"/");
       $nlenx=hou($srclenx,"/");
       $kx=reclines($demomark,$demomark,$demomark,$demomark,"eletemp",$olenx,$nlenx,$pagehtml);
   overfile($ofile,$pagehtml);
  $ext0=UX("select count(*) as result from coode_tinyhtml where demomark='".$demomark."' ");
  if (intval($ext0)>0){
    $sqlx="UPTM=now(),demotitle='".$demotitle."',srctype='".$srctype."',cssfiles='".onlyone($cssfiles)."',jsfiles='".onlyone($jsfiles)."',stylex='".gohex($stylex)."',scriptx='".gohex($scriptx)."',htmlx='".gohex($tmpcode)."',pagesurround='".gohex($srddemo)."'";
    $z=UX("update coode_tinyhtml set ".$sqlx." where demomark='".$demomark."'");    
  }else{
    if ($demomark!=""){
     $sqlx="demomark,demotitle,srctype,cssfiles,jsfiles,stylex,scriptx,htmlx,pagesurround";
     $sqly="'".$demomark."','".$demotitle."','".$srctype."','".onlyone($cssfiles)."','".onlyone($jsfiles)."','".gohex($stylex)."','".gohex($scriptx)."','".gohex($tmpcode)."','".gohex($srddemo)."'";
     $z=UX("insert into coode_tinyhtml(".$sqlx.")values(".$sqly.")");
    }
  }
  echo makereturnjson("1","成功","");
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>