<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       eval(RESFUNSET("tabdataoprt"));
eval(RESFUNSET("resrelyrp"));
$a=time();
$restype=dftval($_GET["restype"],"");
$sysidx=dftval($_GET["sysid"],"");
$resmark=dftval($_GET["resmark"],"");
$vmd5=resvermd5($restype,$resmark);
  if ($_SERVER['SERVER_PORT']=="80"){  
      $myhost=$_SERVER["HTTP_HOST"];
  }else{
      $myhost=$_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"];
  }
  //给csspage  pagex 上报使用
  
$zz=UX("update coode_sysregres set vermd5='".$vmd5."',STATUS=-2,UPTM=now() where restype='".$restype."' and resmark='".$resmark."'");
switch($restype){
 case "cdtrdrx":  
 $srd='{"status":"1","rtype":"[rtype]","rcode":"[rcode]","rtitle":"[rtitle]","ver":"[ver]","vls":[<data>]}';
 $item='{"restype":"[restype]","rescode":"[rescode]","resmd5":"[resmd5]","restitle":"[restitle]","resurl":"[resurl]"},';
 $urst=SX("select SNO,sysid,cdtval from coode_cdtrdr where concat(cdtmark,'.',cdtval)='".$resmark."'");
 $totu=countresult($urst);
 $snox=anyvalue($urst,"SNO",0);
 $sysid=anyvalue($urst,"sysid",0);
 $utitle=anyvalue($urst,"cdtval",0);
 $zz=newsysres($sysidx,$restype,$resmark,$utitle);
 if  ($totu>0){
  $fmitem="";  
  $fpath=combineurl(localroot(),"/localxres/cdtrdrx/".qian($resmark,".")."/");
  $kf=killtpfile($fpath,"json");
  $jpath=makevaljson("cdtrdrx",date("YmdHis"),"coode_cdtrdr",$snox);
  $jfile=combineurl(localroot(),"/localxres/cdtrdrx/".qian($resmark,".")."/".str_replace(".","_",$resmark)."_cdtrdrx-resdata.json"); 
  if ($jpath!=""){
   $zzj=overfile($jfile,file_get_contents($jpath));
  }
  if ($sysidx!=""){  
  $dd=createdir(combineurl(localroot(),"/systemres/".$sysidx."/cdtrdrx/"));
  $ffile=combineurl(localroot(),"/systemres/".$sysidx."/cdtrdrx/".qian($resmark,".")."/".qian($resmark,".")."_cdtrdrx.zip");
   if (file_exists($ffile)){
    unlink($ffile);
    $mm=make_zip_file_for_folder($ffile, $fpath);
   }else{
    $mm=make_zip_file_for_folder($ffile, $fpath);
   }
  }     
  echo makereturnjson("1","转种子成功","");
  }else{
  echo makereturnjson("0","不存在资源","");
  }
  break;
 case "tempx":  
 $srd='{"status":"1","rtype":"[rtype]","rcode":"[rcode]","rtitle":"[rtitle]","ver":"[ver]","vls":[<data>]}';
 $item='{"restype":"[restype]","rescode":"[rescode]","resmd5":"[resmd5]","restitle":"[restitle]","resurl":"[resurl]"},';
 $urst=SX("select SNO,sysid,unittitle from coode_domainunit where dumark='".$resmark."'");
 $totu=countresult($urst);
 $snox=anyvalue($urst,"SNO",0);
 $sysid=anyvalue($urst,"sysid",0);
 $utitle=anyvalue($urst,"unittitle",0);
 $zz=newsysres($sysidx,$restype,$resmark,$utitle);
 $frst=SX("select SNO,faceid from coode_unitface where dumark='".$resmark."'");
 $totf=countresult($frst);
 $fmitem="";
 
  if ($totu>0){
  $fffpath=combineurl(localroot(),"/localxres/tempx/".qian($resmark,".")."/");
  $kf=killtpfile($fpath,"json");
  for ($i=0;$i<$totf;$i++){
  $itemx=$item;
  //如果版本不一致；则新增；如果是垃圾改版变动大，则惩戒；只能克隆新的；要么发布前不允许别人修改；如果允许别人修改；造成改版后果则修改人被惩罚。
  $faceid=anyvalue($frst,"faceid",$i);
  $fpath=combineurl(localroot(),"/localxres/csspagex/".$faceid."/");
  $dd=createdir(combineurl(localroot(),"/systemres/".$sysidx."/csspagex/".$faceid."/"));
  $ffile=combineurl(localroot(),"/systemres/".$sysidx."/csspagex/".$faceid."/".$faceid."_csspagex.zip");
  $ufile=combineurl("http://".glw(),"/systemres/".$sysidx."/csspagex/".$faceid."/".$faceid."_csspagex.zip");
  if (file_exists($ffile)){
   unlink($ffile);
   $mm=make_zip_file_for_folder($ffile, $fpath);
  }else{
   $mm=make_zip_file_for_folder($ffile, $fpath);
  }  
  
  $thismd5=resvermd5("csspagex",$faceid);
  $itemx=str_replace("[restype]","csspagex",$itemx);
  $itemx=str_replace("[rescode]",$faceid,$itemx);
  $itemx=str_replace("[resmd5]",$thismd5,$itemx);
  $fmmd5=$fmmd5.$thismd5;
  $itemx=str_replace("[restitle]",$utitle."的".$faceid,$itemx);
  $itemx=str_replace("[resurl]",$ufile,$itemx);
  $fmitem=$fmitem.$itemx;  
  }
  
  $jpath=makevaljson("tempx",date("YmdHis"),"coode_domainunit",$snox);
  $jfile=combineurl(localroot(),"/localxres/tempx/".qian($resmark,".")."/".str_replace(".","_",$resmark)."_tempx-resdata.json"); 
  if ($jpath!=""){
  $zzj=overfile($jfile,file_get_contents($jpath));
  }
  
  $ufile=combineurl("http://".glw(),"/localxres/tempx/".qian($resmark,".")."/".qian($resmark,".")."_tempx.zip");  
  $itemx=$item;
  $itemx=str_replace("[restype]","tempx",$itemx);
  $itemx=str_replace("[rescode]",$resmark,$itemx);
  $itemx=str_replace("[resmd5]",$thismd5,$itemx);
  $fmmd5=$fmmd5.$thismd5;
  $itemx=str_replace("[restitle]",$utitle,$itemx);
  $itemx=str_replace("[resurl]",$ufile,$itemx);
  $fmitem=$fmitem.$itemx;
  $fmitem=killlaststr($fmitem);  
  $srd=str_replace("[rtype]","tempx",$srd);
  $srd=str_replace("[rcode]",$resmark,$srd);
  $srd=str_replace("[rtitle]",$utitle,$srd);
  
  $srd=str_replace("[ver]",$vmd5,$srd);
  $srd=str_replace("<data>",$fmitem,$srd);
  $resfile=combineurl(localroot(),"/localxres/tempx/".qian($resmark,".")."/".str_replace(".","_",$resmark)."_tempx-relyres.json");
  $zzx=overfile($resfile,$srd);
  if ($sysidx!=""){
  
  $dd=createdir(combineurl(localroot(),"/systemres/".$sysidx."/tempx/".qian($resmark,".")));
  $ffile=combineurl(localroot(),"/systemres/".$sysidx."/tempx/".qian($resmark,".")."/".qian($resmark,".")."_tempx.zip");
  if (file_exists($ffile)){
   unlink($ffile);
   $mm=make_zip_file_for_folder($ffile, $fffpath);
  }else{
   $mm=make_zip_file_for_folder($ffile, $fffpath);
  }
  }
  
  
    echo makereturnjson("1","生成成功","");
  }else{
    echo makereturnjson("0","不存在资源","");
  }
  break;
 case "pagex":
 $srd='{"status":"1","rtype":"[rtype]","rcode":"[rcode]","rtitle":"[rtitle]","ver":"[ver]","vls":[<data>]}';
 $item='{"restype":"[restype]","rescode":"[rescode]","resmd5":"[resmd5]","restitle":"[restitle]","resurl":"[resurl]"},';
 $urst=SX("select SNO,sysid,appid,layid,tinytitle,tempid from coode_tiny where tinymark='".$resmark."'");
 $snoy=anyvalue($urst,"SNO",0);
 $totu=countresult($urst);
 $snox=UX("select SNO as result from coode_unittiny where tinyid='".$resmark."'");
 $sysid=anyvalue($urst,"sysid",0);
 $appid=anyvalue($urst,"appid",0);
 $layid=anyvalue($urst,"layid",0);
 $utitle=anyvalue($urst,"tinytitle",0);
 $dumark=anyvalue($urst,"tempid",0);
 $laysno=UX("select SNO as result from coode_applay where layid='".$layid."'");
 $appsno=UX("select SNO as result from coode_appdefault where appid='".$appid."'");
 $tempsno=UX("select SNO as result from coode_domainunit where dumark='".$dumark."'");
 $zz=newsysres($sysidx,$restype,$resmark,$utitle);
 $frst=SX("select SNO,faceid from coode_unitface where dumark='".$dumark."'");
 $totf=countresult($frst);
 $fmitem="";
  if ($totu>0){
  $fmmd5="";
  $fffpath=combineurl(localroot(),"/localxres/pagex/".qian($dumark,".")."/".$resmark."/");
  $kf=killtpfile($fpath,"json");
  for ($i=0;$i<$totf;$i++){
  $itemx=$item;
  //如果版本不一致；则新增；如果是垃圾改版变动大，则惩戒；只能克隆新的；要么发布前不允许别人修改；如果允许别人修改；造成改版后果则修改人被惩罚。
  $faceid=anyvalue($frst,"faceid",$i);
  $fpath=combineurl(localroot(),"/localxres/csspagex/".$faceid."/");
  $dd=createdir(combineurl(localroot(),"/systemres/".$sysid."/csspagex/".$faceid."/")); 
  $ffile=combineurl(localroot(),"/systemres/".$sysid."/csspagex/".$faceid."/".$faceid."_csspagex.zip");
  $ufile=combineurl("http://".glw(),"/systemres/".$sysid."/csspagex/".$faceid."/".$faceid."_csspagex.zip");
  if (file_exists($ffile)){
    unlink($ffile);
    $mm=make_zip_file_for_folder($ffile, $fpath);
  }else{
    $mm=make_zip_file_for_folder($ffile, $fpath);
  }  
   $thismd5=resvermd5("csspagex",$faceid);  
   $itemx=str_replace("[restype]","csspagex",$itemx);
   $itemx=str_replace("[rescode]",$faceid,$itemx);
   $itemx=str_replace("[resmd5]",$thismd5,$itemx);
   $fmmd5=$fmmd5.$thismd5;
   $itemx=str_replace("[restitle]",$utitle."的".$faceid,$itemx);
   $itemx=str_replace("[resurl]",$ufile,$itemx);
   $fmitem=$fmitem.$itemx;  
  }
  $pagepath=combineurl(localroot(),"/localxres/pagex/".qian($dumark,".")."/".$resmark."/");
  $seedpath=combineurl(localroot(),"/systemres/pagex/".$resmark."/");
  $zzx=copy_underdir($pagepath,$seedpath);
  $jpath=makevaljson("pagex",date("YmdHis"),"coode_unittiny",$snox);
  $jfile=combineurl(localroot(),"/localxres/pagex/".qian($dumark,".")."/".$resmark."/".$resmark."_pagex-resdata.json"); 
  if ($jpath!=""){
    $zzj=overfile($jfile,file_get_contents($jpath));
  }
  $ppath=makevaljson("pagex",date("YmdHis"),"coode_tiny",$snoy);
  $pfile=combineurl(localroot(),"/localxres/pagex/".qian($dumark,".")."/".$resmark."/".$resmark."_pagex-pagedata.json"); 
  if ($ppath!=""){
    $zzz=overfile($pfile,file_get_contents($ppath));
  }
  $lpath=makevaljson("layx",date("YmdHis"),"coode_applay",$laysno);
  $lfile=combineurl(localroot(),"/localxres/pagex/".qian($dumark,".")."/".$resmark."/".$resmark."_pagex-lay.json"); 
  if ($lpath!=""){
    $zzz=overfile($lfile,file_get_contents($lpath));
  }
  $apath=makevaljson("appx",date("YmdHis"),"coode_appdefault",$appsno);
  $afile=combineurl(localroot(),"/localxres/pagex/".qian($dumark,".")."/".$resmark."/".$resmark."_pagex-app.json"); 
  if ($apath!=""){
  $zzz=overfile($afile,file_get_contents($apath));
  }
  $tpath=makevaljson("tempx",date("YmdHis"),"coode_domainunit",$tempsno);
  $tfile=combineurl(localroot(),"/localxres/pagex/".qian($dumark,".")."/".$resmark."/".$resmark."_pagex-temp.json"); 
  if ($tpath!=""){
  $zzz=overfile($tfile,file_get_contents($tpath));
  }
  
  $dd=createdir(combineurl(localroot(),"/systemres/".$sysidx."/pagex/".$resmark."/")); 
  $ffile=combineurl(localroot(),"/systemres/".$sysidx."/pagex/".$resmark."/".$resmark."_pagex.zip");
  
  $ufile=combineurl("http://".glw(),"/localxres/pagex/".qian($dumark,".")."/".$resmark."/".$resmark."_pagex.zip");  
  $itemx=$item;
  $itemx=str_replace("[restype]","pagex",$itemx);
  $itemx=str_replace("[rescode]",$resmark,$itemx);
  $itemx=str_replace("[resmd5]",$vmd5,$itemx);
  $fmmd5=$fmmd5.$thismd5;
  $itemx=str_replace("[restitle]",$utitle,$itemx);
  $itemx=str_replace("[resurl]",$ufile,$itemx);
  $fmitem=$fmitem.$itemx;
  $fmitem=killlaststr($fmitem);  
  $srd=str_replace("[rtype]","pagex",$srd);
  $srd=str_replace("[rcode]",$resmark,$srd);
  $srd=str_replace("[rtitle]",$utitle,$srd);
  
  $srd=str_replace("[ver]",$vmd5,$srd);
  $srd=str_replace("<data>",$fmitem,$srd);
  $resfile=combineurl(localroot(),"/localxres/pagex/".qian($dumark,".")."/".$resmark."/".$resmark."_pagex-relyres.json");
  $zzx=overfile($resfile,$srd);
  if ($sysidx!=""){
   if (file_exists($ffile)){
     unlink($ffile);
     $mm=make_zip_file_for_folder($ffile, $fffpath);
   }else{
     $mm=make_zip_file_for_folder($ffile, $fffpath);
   }
  } 
  
   
   echo makereturnjson("1","模板页面生成成功","");
  }else{  //totu
   $fffpath=combineurl(localroot(),"/localxres/pagex/seedx/".$resmark."/");
   $kf=killtpfile($fpath,"json");
   $pagepath=combineurl(localroot(),"/localxres/pagex/seedx/".$resmark."/");
   $seedpath=combineurl(localroot(),"/localxres/pagex/seedx/".$resmark."/");
   $zzx=copy_underdir($pagepath,$seedpath);
   $ppath=makevaljson("pagex",date("YmdHis"),"coode_tiny",$snoy);
   $pfile=combineurl(localroot(),"/localxres/pagex/seedx/".$resmark."/".$resmark."_pagex-pagedata.json"); 
   if ($ppath!=""){
    $zzz=overfile($pfile,file_get_contents($ppath));
   }
   $lpath=makevaljson("layx",date("YmdHis"),"coode_applay",$laysno);
   $lfile=combineurl(localroot(),"/localxres/pagex/seedx/".$resmark."/".$resmark."_pagex-lay.json"); 
   if ($lpath!=""){
    $zzz=overfile($lfile,file_get_contents($lpath));
   }
  $apath=makevaljson("appx",date("YmdHis"),"coode_appdefault",$appsno);
  $afile=combineurl(localroot(),"/localxres/pagex/seedx/".$resmark."/".$resmark."_pagex-app.json"); 
  if ($apath!=""){
    $zzz=overfile($afile,file_get_contents($apath));
  }
  
  
  $dd=createdir(combineurl(localroot(),"/systemres/".$sysidx."/pagex/".$resmark."/")); 
  $ffile=combineurl(localroot(),"/systemres/".$sysidx."/pagex/".$resmark."/".$resmark."_pagex.zip");
  
  $ufile=combineurl("http://".glw(),"/localxres/pagex/seedx/".$resmark."/".$resmark."_pagex.zip");  
  $itemx=$item;
  $itemx=str_replace("[restype]","pagex",$itemx);
  $itemx=str_replace("[rescode]",$resmark,$itemx);
  $itemx=str_replace("[resmd5]",$vmd5,$itemx);
  $fmmd5=$fmmd5.$thismd5;
  $itemx=str_replace("[restitle]",$utitle,$itemx);
  $itemx=str_replace("[resurl]",$ufile,$itemx);
  $fmitem=$fmitem.$itemx;
  $fmitem=killlaststr($fmitem);  
  $srd=str_replace("[rtype]","pagex",$srd);
  $srd=str_replace("[rcode]",$resmark,$srd);
  $srd=str_replace("[rtitle]",$utitle,$srd);  
  $srd=str_replace("[ver]",$vmd5,$srd);
  $srd=str_replace("<data>",$fmitem,$srd);
  $resfile=combineurl(localroot(),"/localxres/pagex/seedx/".$resmark."/".$resmark."_pagex-relyres.json");
  $zzx=overfile($resfile,$srd);
  if ($sysidx!=""){
  if (file_exists($ffile)){
   unlink($ffile);
   $mm=make_zip_file_for_folder($ffile, $fffpath);
  }else{
   $mm=make_zip_file_for_folder($ffile, $fffpath);
  }
  } 
  echo makereturnjson("1","其他页面制作成功","");
  }
  break;
  case "tabx":
  $a=time();
  $fmitem="";
  $fpath=combineurl(localroot(),"/localxres/tabx/".$resmark."/");
  $kf=killtpfile($fpath,"json");
  $srd='{"status":"1","rtype":"[rtype]","rcode":"[rcode]","rtitle":"[rtitle]","ver":"[ver]","crtsql":"[crtsql]","vls":[<data>]}';
  $item='{"restype":"[restype]","rescode":"[rescode]","resmd5":"[resmd5]","restitle":"[restitle]","resurl":"[resurl]"},';
  $tabrst=SX("select SNO,tabtitle,sysid,createsql from coode_tablist where TABLE_NAME='".$resmark."'");
  $snoy=anyvalue($tabrst,"SNO",0);
  $tabtitle=anyvalue($tabrst,"tabtitle",0);
  $sysid=anyvalue($tabrst,"sysid",0);
  $crtsql=anyvalue($tabrst,"createsql",0);
  $zz=newsysres($sysidx,$restype,$resmark,$tabtitle);
  $itemx=$item;
  $itemx=str_replace("[restype]","jsondata",$itemx);
  $itemx=str_replace("[rescode]",$resmark."_basedata",$itemx);  
  $itemx=str_replace("[restitle]",$tabtitle,$itemx);
  $ufile=makevaljson("tabx",date("YmdHis"),"coode_tablist",$snoy);
  $itemx=str_replace("[resurl]",$ufile,$itemx);
  $datajson=file_get_contents($ufile);
  $thismd5=md5($datajson);
  $dtpath=combineurl(localroot(),"/localxres/tabx/".$resmark."/".$thismd5.".json");
  $islpath=combineurl(localroot(),"/baseinstall/tabcrt/".$resmark.".json");
  $zz=overfile($dtpath,$datajson);
  $zz2=overfile($islpath,$datajson);
  $itemx=str_replace("[resmd5]",$thismd5,$itemx);
  $fmitem=$fmitem.$itemx;
  $kxrst=SX("select SNO,COLUMN_NAME,keytitle from coode_keydetailx where TABLE_NAME='".$resmark."'");
  $totk=countresult($kxrst);
  for ($k=0;$k<$totk;$k++){
  $snoxx=anyvalue($kxrst,"SNO",$k);
  $colname=anyvalue($kxrst,"COLUMN_NAME",$k);
  $ktitle=anyvalue($kxrst,"keytitle",$k);
  $itemx=$item;
  $itemx=str_replace("[restype]","jsondata",$itemx);
  $itemx=str_replace("[rescode]",$colname."_extdata",$itemx);  
  $itemx=str_replace("[restitle]",$ktitle,$itemx);
  $ufile=makevaljson("tabx",date("YmdHis"),"coode_keydetailx",$snoxx);
  $itemx=str_replace("[resurl]",$ufile,$itemx);
  $datajson=file_get_contents($ufile);
  $thismd5=md5($datajson);
  $fmmd5=$fmmd5.$thismd5;
  $dtpath=combineurl(localroot(),"/localxres/tabx/".$resmark."/".$thismd5.".json");
  $zz=overfile($dtpath,$datajson);
  $itemx=str_replace("[resmd5]",$thismd5,$itemx);
  $fmitem=$fmitem.$itemx;
  }
  
  $fmitem=killlaststr($fmitem);  
  $srd=str_replace("[rtype]","tabx",$srd);
  $srd=str_replace("[rcode]",$resmark,$srd);
  $srd=str_replace("[crtsql]",$crtsql,$srd);
  $srd=str_replace("[rtitle]",$tabtitle,$srd);
  $thismd5=md5($fmmd5);
  $srd=str_replace("[ver]",$vmd5,$srd);
  $srd=str_replace("<data>",$fmitem,$srd);
  $resfile=combineurl(localroot(),"/localxres/tabx/".$resmark."/".$resmark."_tabx-relyres.json");
  $zzx=overfile($resfile,$srd);
  if ($sysidx!=""){
  
  $dd=createdir(combineurl(localroot(),"/systemres/".$sysidx."/tabx/".$resmark."/")); 
  $ffile=combineurl(localroot(),"/systemres/".$sysidx."/tabx/".$resmark."/".$resmark."_tabx.zip");
  if (file_exists($ffile)){
   unlink($ffile);
   $mm=make_zip_file_for_folder($ffile, $fpath);
  }else{
   $mm=make_zip_file_for_folder($ffile, $fpath);
  }  
  }  
  
  $b=time();
  echo makereturnjson("1","转化成功，耗时".($b-$a),"");
  break;
  case "plotx":
  $a=time();
  $fmitem="";
  $fpath=combineurl(localroot(),"/localxres/plotx/".$resmark."/");
  $kf=killtpfile($fpath,"json");
  $srd='{"status":"1","rtype":"[rtype]","rcode":"[rcode]","rtitle":"[rtitle]","ver":"[ver]","vls":[<data>]}';
  $item='{"restype":"[restype]","rescode":"[rescode]","resmd5":"[resmd5]","restitle":"[restitle]","resurl":"[resurl]"},';
  $plotrst=SX("select SNO,markname,sysid from coode_plotlist where plotmark='".$resmark."'");
  $snoy=anyvalue($plotrst,"SNO",0);
  $rtitle=anyvalue($plotrst,"markname",0);
  $sysid=anyvalue($plotrst,"sysid",0);
  $zz=newsysres($sysidx,$restype,$resmark,$rtitle);
  $itemx=$item;
  $itemx=str_replace("[restype]","jsondata",$itemx);
  $itemx=str_replace("[rescode]",$resmark."_basedata",$itemx);  
  $itemx=str_replace("[restitle]",$plottitle,$itemx);
  $ufile=makevaljson("plotx",date("YmdHis"),"coode_plotlist",$snoy);
  $itemx=str_replace("[resurl]",$ufile,$itemx);
  $datajson=file_get_contents($ufile);
  $thismd5=md5($datajson);
  $dtpath=combineurl(localroot(),"/localxres/plotx/".$resmark."/".$thismd5.".json");
  $zz=overfile($dtpath,$datajson);
  $itemx=str_replace("[resmd5]",$thismd5,$itemx);
  $fmitem=$fmitem.$itemx;
  $kxrst=SX("select SNO,mymark,mytitle from coode_plotdetail where plotmark='".$resmark."'");
  $totk=countresult($kxrst);
  for ($k=0;$k<$totk;$k++){
  $snoxx=anyvalue($kxrst,"SNO",$k);
  $colname=anyvalue($kxrst,"mymark",$k);
  $ktitle=anyvalue($kxrst,"mytitle",$k);
  $itemx=$item;
  $itemx=str_replace("[restype]","jsondata",$itemx);
  $itemx=str_replace("[rescode]",$colname."_extdata",$itemx);  
  $itemx=str_replace("[restitle]",$ktitle,$itemx);
  $ufile=makevaljson("plotx",date("YmdHis"),"coode_plotdetail",$snoxx);
  $itemx=str_replace("[resurl]",$ufile,$itemx);
  $datajson=file_get_contents($ufile);
  $thismd5=md5($datajson);
  $dtpath=combineurl(localroot(),"/localxres/plotx/".$resmark."/".$thismd5.".json");
  $zz=overfile($dtpath,$datajson);
  $itemx=str_replace("[resmd5]",$thismd5,$itemx);
  $fmmd5=$fmmd5.$thismd5;
  $fmitem=$fmitem.$itemx;
  }
  
  $fmitem=killlaststr($fmitem);  
  $srd=str_replace("[rtype]","plotx",$srd);
  $srd=str_replace("[rcode]",$resmark,$srd);
  $srd=str_replace("[rtitle]",$rtitle,$srd);
  $thismd5=md5($fmmd5);
  $srd=str_replace("[ver]",$vmd5,$srd);
  $srd=str_replace("<data>",$fmitem,$srd);
  $resfile=combineurl(localroot(),"/localxres/plotx/".$resmark."/".$resmark."_plotx-relyres.json");
  $zzx=overfile($resfile,$srd);
  if ($sysidx!=""){
  
  $dd=createdir(combineurl(localroot(),"/systemres/".$sysidx."/plotx/".$resmark."/")); 
  $ffile=combineurl(localroot(),"/systemres/".$sysidx."/plotx/".$resmark."/".$resmark."_plotx.zip");
  if (file_exists($ffile)){
   unlink($ffile);
   $mm=make_zip_file_for_folder($ffile, $fpath);
  }else{
   $mm=make_zip_file_for_folder($ffile, $fpath);
  }  
  }  
  
  $b=time();
  echo makereturnjson("1","转化成功，耗时".($b-$a),"");
  break;
  case "groupx":
  $fpath=combineurl(localroot(),"/localxres/groupx/".$resmark."/");
  $kf=killtpfile($fpath,"json");
  $a=time();
  $fmitem="";
  $srd='{"status":"1","rtype":"[rtype]","rcode":"[rcode]","rtitle":"[rtitle]","ver":"[ver]","vls":[<data>]}';
  $item='{"restype":"[restype]","rescode":"[rescode]","resmd5":"[resmd5]","restitle":"[restitle]","resurl":"[resurl]"},';
  $plotrst=SX("select SNO,markname,sysid from coode_grouplist where plotmark='".$resmark."'");
  $snoy=anyvalue($plotrst,"SNO",0);
  $sysid=anyvalue($plotrst,"sysid",0);
  $rtitle=anyvalue($plotrst,"markname",0);
  $zz=newsysres($sysidx,$restype,$resmark,$rtitle);
  $itemx=$item;
  $itemx=str_replace("[restype]","jsondata",$itemx);
  $itemx=str_replace("[rescode]",$resmark."_basedata",$itemx);  
  $itemx=str_replace("[restitle]",$plottitle,$itemx);
  $ufile=makevaljson("groupx",date("YmdHis"),"coode_grouplist",$snoy);
  $itemx=str_replace("[resurl]",$ufile,$itemx);
  $datajson=file_get_contents($ufile);
  $thismd5=md5($datajson);
  $dtpath=combineurl(localroot(),"/localxres/groupx/".$resmark."/".$thismd5.".json");
  $zz=overfile($dtpath,$datajson);
  $itemx=str_replace("[resmd5]",$thismd5,$itemx);
  $fmitem=$fmitem.$itemx;
  $kxrst=SX("select SNO,keyid,keyval from coode_grpclass where clsmark='".$resmark."'");
  $totk=countresult($kxrst);
  for ($k=0;$k<$totk;$k++){
  $snoxx=anyvalue($kxrst,"SNO",$k);
  $colname=anyvalue($kxrst,"keyid",$k);
  $ktitle=anyvalue($kxrst,"keyval",$k);
  $itemx=$item;
  $itemx=str_replace("[restype]","jsondata",$itemx);
  $itemx=str_replace("[rescode]",$colname."_extdata",$itemx);  
  $itemx=str_replace("[restitle]",$ktitle,$itemx);
  $ufile=makevaljson("groupx",date("YmdHis"),"coode_grpclass",$snoxx);
  $itemx=str_replace("[resurl]",$ufile,$itemx); 
  $datajson=file_get_contents($ufile);
  $thismd5=md5($datajson);
  $dtpath=combineurl(localroot(),"/localxres/groupx/".$resmark."/".$thismd5.".json");
  $zz=overfile($dtpath,$datajson);
  $itemx=str_replace("[resmd5]",$thismd5,$itemx);
  $fmmd5=$fmmd5.$thismd5;
  $fmitem=$fmitem.$itemx;
  }
  
  $fmitem=killlaststr($fmitem);  
  $srd=str_replace("[rtype]","groupx",$srd);
  $srd=str_replace("[rcode]",$resmark,$srd);
  $srd=str_replace("[rtitle]",$rtitle,$srd);
  $thismd5=md5($fmmd5);
  $srd=str_replace("[ver]",$thismd5,$srd);
  $srd=str_replace("<data>",$fmitem,$srd);
  $resfile=combineurl(localroot(),"/localxres/groupx/".$resmark."/".$resmark."_groupx-relyres.json");
  $zzx=overfile($resfile,$srd);
  if ($sysidx!=""){
  
  $dd=createdir(combineurl(localroot(),"/systemres/".$sysidx."/groupx/".$resmark."/")); 
  $ffile=combineurl(localroot(),"/systemres/".$sysidx."/groupx/".$resmark."/".$resmark."_groupx.zip");
   if (file_exists($ffile)){
    unlink($ffile);
    $mm=make_zip_file_for_folder($ffile, $fpath);
   }else{
    $mm=make_zip_file_for_folder($ffile, $fpath);
   }  
  }  
  
  $b=time();
  echo makereturnjson("1","转化成功，耗时".($b-$a),"");
  break;
  case "formx":
  $fpath=combineurl(localroot(),"/localxres/formx/".$resmark."/");
  $kf=killtpfile($fpath,"json");
  $a=time();
  $fmitem="";
  $srd='{"status":"1","rtype":"[rtype]","rcode":"[rcode]","rtitle":"[rtitle]","ver":"[ver]","vls":[<data>]}';
  $item='{"restype":"[restype]","rescode":"[rescode]","resmd5":"[resmd5]","restitle":"[restitle]","resurl":"[resurl]"},';
  $tabrst=SX("select SNO,shorttitle,sysid from coode_shortdata where shortid='".$resmark."'");
  $snoy=anyvalue($tabrst,"SNO",0);
  $rtitle=anyvalue($tabrst,"shorttitle",0);
  $sysid=anyvalue($tabrst,"sysid",0);
  $zz=newsysres($sysidx,$restype,$resmark,$rtitle);
  $itemx=$item;
  $itemx=str_replace("[restype]","jsondata",$itemx);
  $itemx=str_replace("[rescode]",$resmark."_basedata",$itemx);  
  $itemx=str_replace("[restitle]",$rtitle,$itemx);
  $ufile=makevaljson("formx",date("YmdHis"),"coode_shortdata",$snoy);
  $itemx=str_replace("[resurl]",$ufile,$itemx);
  $datajson=file_get_contents($ufile);
  $thismd5=md5($datajson);
  $dtpath=combineurl(localroot(),"/localxres/formx/".$resmark."/".$thismd5.".json");
  $zz=overfile($dtpath,$datajson);
  $itemx=str_replace("[resmd5]",$thismd5,$itemx);
  $fmitem=$fmitem.$itemx;
  
  $cssrst=SX("select SNO,describ from coode_shortcss where shortid='".$resmark."'");
  $snoz=anyvalue($cssrst,"SNO",0);  
  $itemx=$item;
  $itemx=str_replace("[restype]","jsondata",$itemx);
  $itemx=str_replace("[rescode]",$resmark."_cssdata",$itemx);  
  $itemx=str_replace("[restitle]",$rtitle,$itemx);
  $ufile=makevaljson("formx",date("YmdHis"),"coode_shortcss",$snoz);
  $itemx=str_replace("[resurl]",$ufile,$itemx);
  $datajson=file_get_contents($ufile);
  $thismd5=md5($datajson);
  $dtpath=combineurl(localroot(),"/localxres/formx/".$resmark."/".$thismd5.".json");
  $zz=overfile($dtpath,$datajson);
  $itemx=str_replace("[resmd5]",$thismd5,$itemx);
  $fmitem=$fmitem.$itemx;
  $kxrst=SX("select SNO,COLUMN_NAME,keytitle from coode_keydetaily where shortid='".$resmark."'");
  $totk=countresult($kxrst);
  for ($k=0;$k<$totk;$k++){
  $snoxx=anyvalue($kxrst,"SNO",$k);
  $colname=anyvalue($kxrst,"COLUMN_NAME",$k);
  $ktitle=anyvalue($kxrst,"keytitle",$k);
  $itemx=$item;
  $itemx=str_replace("[restype]","jsondata",$itemx);
  $itemx=str_replace("[rescode]",$colname."_extdata",$itemx);  
  $itemx=str_replace("[restitle]",$ktitle,$itemx);
  $ufile=makevaljson("formx",date("YmdHis"),"coode_keydetaily",$snoxx);
  $itemx=str_replace("[resurl]",$ufile,$itemx);
  $datajson=file_get_contents($ufile);
  $thismd5=md5($datajson);
  $dtpath=combineurl(localroot(),"/localxres/formx/".$resmark."/".$thismd5.".json");
  $zz=overfile($dtpath,$datajson);
  $itemx=str_replace("[resmd5]",$thismd5,$itemx);
  $fmmd5=$fmmd5.$thismd5;
  $fmitem=$fmitem.$itemx;
  }
  
  $fmitem=killlaststr($fmitem);  
  $srd=str_replace("[rtype]","formx",$srd);
  $srd=str_replace("[rcode]",$resmark,$srd);
  $srd=str_replace("[rtitle]",$rtitle,$srd);
  
  $srd=str_replace("[ver]",$vmd5,$srd);
  $srd=str_replace("<data>",$fmitem,$srd);
  $resfile=combineurl(localroot(),"/localxres/formx/".$resmark."/".$resmark."_formx-relyres.json");
  $zzx=overfile($resfile,$srd);
  if ($sysidx!=""){
  
  $dd=createdir(combineurl(localroot(),"/systemres/".$sysidx."/formx/".$resmark."/")); 
  $ffile=combineurl(localroot(),"/systemres/".$sysidx."/formx/".$resmark."/".$resmark."_formx.zip");
   if (file_exists($ffile)){
    unlink($ffile);
    $mm=make_zip_file_for_folder($ffile, $fpath);
   }else{
    $mm=make_zip_file_for_folder($ffile, $fpath);
   }
  }  
  
  
  $b=time();
  echo makereturnjson("1","转化成功，耗时".($b-$a),"");
  break;
  case "dataspacex":
  $fpath=combineurl(localroot(),"/localxres/dataspacex/".$resmark."/");
  $kf=killtpfile($fpath,"json");
  $a=time();
  $fmitem="";
  $srd='{"status":"1","rtype":"[rtype]","rcode":"[rcode]","rtitle":"[rtitle]","ver":"[ver]","vls":[<data>]}';
  $item='{"restype":"[restype]","rescode":"[rescode]","resmd5":"[resmd5]","restitle":"[restitle]","resurl":"[resurl]"},';
  $tabrst=SX("select SNO,datatitle,sysid from coode_dataspace where datamark='".$resmark."'");
  $snoy=anyvalue($tabrst,"SNO",0);
  $rtitle=anyvalue($tabrst,"datatitle",0);
  $sysid=anyvalue($tabrst,"sysid",0);  
  $zz=newsysres($sysidx,$restype,$resmark,$rtitle);
  $itemx=$item;
  $itemx=str_replace("[restype]","jsondata",$itemx);
  $itemx=str_replace("[rescode]",$resmark."_basedata",$itemx);  
  $itemx=str_replace("[restitle]",$rtitle,$itemx);
  $ufile=makevaljson("dataspacex",date("YmdHis"),"coode_dataspace",$snoy);
  $itemx=str_replace("[resurl]",$ufile,$itemx);
  $datajson=file_get_contents($ufile);
  $thismd5=md5($datajson);
  $dtpath=combineurl(localroot(),"/localxres/dataspacex/".$resmark."/".$thismd5.".json");
  $zz=overfile($dtpath,$datajson);
  $itemx=str_replace("[resmd5]",$thismd5,$itemx);
  $fmmd5=$fmmd5.$thismd5;
  $fmitem=$fmitem.$itemx;
  $kxrst=SX("select SNO,keymark,keytitle from coode_dspckey where datamark='".$resmark."'");
  $totk=countresult($kxrst);
  for ($k=0;$k<$totk;$k++){
  $snoxx=anyvalue($kxrst,"SNO",$k);
  $colname=anyvalue($kxrst,"keymark",$k);
  $ktitle=anyvalue($kxrst,"keytitle",$k);
  $itemx=$item;
  $itemx=str_replace("[restype]","jsondata",$itemx);
  $itemx=str_replace("[rescode]",$colname."_extdata",$itemx);  
  $itemx=str_replace("[restitle]",$ktitle,$itemx);
  $ufile=makevaljson("dataspacex",date("YmdHis"),"coode_dspckey",$snoxx);
  $itemx=str_replace("[resurl]",$ufile,$itemx);
  $datajson=file_get_contents($ufile);
  $thismd5=md5($datajson);
  $fmmd5=$fmmd5.$thismd5;
  $dtpath=combineurl(localroot(),"/localxres/dataspacex/".$resmark."/".$thismd5.".json");
  $zz=overfile($dtpath,$datajson);
  $itemx=str_replace("[resmd5]",$thismd5,$itemx);
  $fmitem=$fmitem.$itemx;
  }
  
  $fmitem=killlaststr($fmitem);  
  $srd=str_replace("[rtype]","dataspacex",$srd);
  $srd=str_replace("[rcode]",$resmark,$srd);
  $srd=str_replace("[rtitle]",$rtitle,$srd);
  
  $srd=str_replace("[ver]",$vmd5,$srd);
  $srd=str_replace("<data>",$fmitem,$srd);
  $resfile=combineurl(localroot(),"/localxres/dataspacex/".$resmark."/".$resmark."_dataspacex-relyres.json");
  $zzx=overfile($resfile,$srd);
  if ($sysidx!=""){
  
  $dd=createdir(combineurl(localroot(),"/systemres/".$sysidx."/dataspacex/".$resmark."/")); 
  $ffile=combineurl(localroot(),"/systemres/".$sysidx."/dataspacex/".$resmark."/".$resmark."_dataspacex.zip");
   if (file_exists($ffile)){
    unlink($ffile);
    $mm=make_zip_file_for_folder($ffile, $fpath);
   }else{
    $mm=make_zip_file_for_folder($ffile, $fpath);
   }
  }
  
  
  $b=time();
  echo makereturnjson("1","转化成功，耗时".($b-$a),"");
  break;
  default:
   $fpath=combineurl(localroot(),"/localxres/".$restype."/".$resmark."/");
   $kf=killtpfile($fpath,"json");
   $srst=SX("select relyotherres,restypetitle from coode_sysrestypedefine where restypecode='".$restype."'");
   $resexp=anyvalue($srst,"relyotherres",0);
   $tabkey=$resexp;
   $restab=qian($resexp,".");
   $reskey=hou($resexp,".");
   if (strpos($reskey,"_")>0){
     $ressno=UX("select SNO as result from ".$restab." where concat(".str_replace("_",",",$reskey).")='".$resmark."'");
    }else{
     $ressno=UX("select SNO as result from ".$restab." where ".$reskey."='".$resmark."'");
    }
   if ($ressno!=""){
     $kpath=makevaljson($restype,date("YmdHis"),$restab,$ressno);
     $kfile=combineurl(localroot(),"/localxres/".$restype."/".$resmark."/".$resmark."_".$restype."-resdata.json"); 
      if ($kpath!=""){
        $zzz=overfile($kfile,file_get_contents($kpath));
      }
      if ($sysidx!=""){   
        $dd=createdir(combineurl(localroot(),"/systemres/".$sysidx."/".$restype."/".$resmark."/")); 
        $ffile=combineurl(localroot(),"/systemres/".$sysidx."/".$restype."/".$resmark."/".$resmark."_".$restype.".zip");
         if (file_exists($ffile)){
           unlink($ffile);
           $mm=make_zip_file_for_folder($ffile, $fpath);
         }else{
           $mm=make_zip_file_for_folder($ffile, $fpath);
         }  
       }   
        $resttk=UX("select srcttk as result from coode_tablist where TABLE_NAME='".qian($tabkey,".")."'");
        $rtt=UX("select ".$resttk." as result from ".qian($tabkey,".")."  where ".hou($tabkey,".")."='".$resmark."'");
        $zz=newsysres($sysidx,$restype,$resmark,$rtt);        
        echo makereturnjson("1","保存成功","");
   }else{
       echo makereturnjson("0","不存在资源","");
   }
 }//SWITCH  
 $zz=UX("update coode_sysregres set STATUS=1,UPTM=now() where restype='".$restype."' and resmark='".$resmark."'"); 
       session_write_close();
?>