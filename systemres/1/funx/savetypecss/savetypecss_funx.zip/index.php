<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $csstype=_get("csstype");
$snox=_get("SNO");
if ($snox!="" ){ 
$typesrd=gohex(unstrs(_post("typesrd")));
$typerowsrd=gohex(unstrs(_post("typerowsrd")));
$headfirst=gohex(unstrs(_post("headfirst")));
$typefirst=gohex(unstrs(_post("typefirst")));
$keysrd=gohex(unstrs(_post("keysrd")));
$keyrowsrd=gohex(unstrs(_post("keyrowsrd")));
$kheadfirst=gohex(unstrs(_post("kheadfirst")));
$keyfirst=gohex(unstrs(_post("keyfirst")));
$headfunx=gohex(unstrs(_post("headfunx")));
$typefunx=gohex(unstrs(_post("typefunx")));
$kheadfunx=gohex(unstrs(_post("kheadfunx")));
$keyfunx=gohex(unstrs(_post("keyfunx")));
$typedemo=gohex(unstrs(_post("typedemo")));
$keydemo=gohex(unstrs(_post("keydemo")));
switch($csstype){
  case "ktype":
  $zz=UX("update coode_tempcssfunx set typedemo='".$typedemo."',typesrd='".$typesrd."',typerowsrd='".$typerowsrd."',typedfunx='".$typefunx."',typeheadx='".$headfunx."',typesfunx='".$typefirst."',typeheadsfx='".$headfirst."' where SNO=".$snox);
  //$zz=addprcx("update coode_tempcssfunx set typesrd='".$typesrd."',typedfunx='".$typefunx."',typeheadx='".$headfunx."',typesfunx='".$typefirst."',typeheadsfx='".$headfirst."' where SNO=".$snox);
  break;
  case "key":
  $zz=UX("update coode_tlfcssfunx set typedemo='".$typedemo."',keydemo='".$keydemo."',typesrd='".$typesrd."',typerowsrd='".$typerowsrd."',keyrowsrd='".$keyrowsrd."',typedfunx='".$typefunx."',typeheadx='".$headfunx."',typesfunx='".$typefirst."',typeheadsfx='".$headfirst."',keysrd='".$keysrd."',keydfunx='".$keyfunx."',keyheadx='".$kheadfunx."',keysfunx='".$keyfirst."',keyheadsfx='".$kheadfirst."' where SNO=".$snox);
  break;
  default:
  $zz=UX("update coode_tempcssfunx set typedemo='".$typedemo."',typesrd='".$typesrd."',typerowsrd='".$typerowsrd."',typedfunx='".$typefunx."',typeheadx='".$headfunx."',typesfunx='".$typefirst."',typeheadsfx='".$headfirst."' where SNO=".$snox);
}
 echo makereturnjson("1","修改成功","");
}else{
 echo makereturnjson("0","修改失败-参数不全","");
}
       session_write_close();
?>