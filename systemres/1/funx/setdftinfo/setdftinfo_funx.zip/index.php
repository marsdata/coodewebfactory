<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $dsid=_get("dsid");
$dspcdata=anyfunrun("getdspcdata","","datamark=".$dsid."&datatype=json","");
$dspc=json_decode($dspcdata,false);
$vls=$dspc-vls;
$dftpath=combineurl(localroot(),"/localxres/USERDEFINE.php");
$dfttxt=file_get_contents($dftpath);
$fgx="//-------------配置分界线";
$first=constval("phpdft");
for ($j=0;$j<count($vls);$vls){
 $sitekey=$vls[$j]->sitekey;
 $siteval=$vls[$j]->siteval;
 $first=str_replace("[".$sitekey."]",$siteval,$first);
}
$afttxt=hou($dfttxt,$fgx);
$allcode='<?php'.huanhang().$first.$afttxt;
$fnm=combineurl(localroot(),"/localxres/USERDEFINE.php");
$zz=overfile($fnm,$allcode);
echo makereturnjson("1","重写成功","");
       session_write_close();
?>