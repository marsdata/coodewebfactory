<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $a=time();
$areatype=dftval($_GET["areatype"],"");
$setcode=dftval($_GET["setcode"],"");
$sqlx="areatype,areaname,funname,funkey,funcname,funtype,filelcpath,fileurl,CRTM,UPTM,OLMK";
switch($areatype){
 case "clsx":  
  $datax=UX("select funfull as result from coode_phpcls where funname='".$setcode."'"); 
  $datay=tostring($datax);
  $ptfun=explode("function ",$datay);
  $totpt=count($ptfun);
  for ($j=0;$j<$totpt;$j++){
        $funname=qian($ptfun[$j],"(");
        $filename=$areatype."_".$setcode.".".$funname;
        $filepath=combineurl(localroot(),'/localxres/funx/funcool/'.$filename.".txt");
        $fileurl='/localxres/funx/funcool/'.$filename.".txt";
        if ($funname!="" and strpos($funname,"lass ")<=0 and strpos("xx".$funname,"/")<=0 and strpos('xx'.$funname,'$')<=0){
           $funinner=hou($ptfun[$j],")");
           $funparas=killlaststr(qian(hou($ptfun[$j],"("),"{"));
           $funwhole="function ".$ptfun[$j];
           $ptfx=explode("=",$ptfun[$j]);
           for ($p=1;$p<count($ptfx);$p++){
        if (strpos($ptfx[$p],"(")>0){
          $tmpfnm=qian($ptfx[$p],"(");
          $tmpfnm=str_replace(" ","",$tmpfnm);
          $tmpfnm=str_replace(huanhang(),"",$tmpfnm);
          $fmfx=$fmfx.$tmpfnm.",";
        }
           }
      $fmfnms="";
      $crst=SX("select areatype,funname,funcname,funtype,areaname,relyfuns from coode_funcool where '".str_replace("'","\'",$ptfun[$j])."' like concat('%',funname,'%') and areatype='bfunx'");
      $totc=countresult($crst);
       for ($ff=0;$ff<$totc;$ff++){
        $atype=anyvalue($crst,"areatype",$ff);
        $fname=anyvalue($crst,"funname",$ff);
        $fcname=anyvalue($crst,"funcname",$ff);
        $ftype=anyvalue($crst,"funtype",$ff);
        $aname=anyvalue($crst,"areaname",$ff);
        $relyfuns=anyvalue($crst,"relyfuns",$ff);
        $fmfnms=$fmfnms.$fname.",";
      
          }
          $fmfnms=onlyone(killlaststr($fmfnms),",");
           $zz=overfile($filepath,$funwhole);
           $sqly="'".$areatype."','".$setcode."','".$funname."','".$funparas."','','single','".$filepath."','".$fileurl."',now(),now(),'".onlymark()."'";  
           $extf=UX("select count(*) as result from coode_funcool where areatype='".$areatype."' and areaname='".$setcode."' and funname='".$funname."'");
           if (intval($extf)==0){
          $zz=UX("insert into coode_funcool(".$sqlx.")values(".$sqly.")");
           }else{
          $ff=UX("update coode_funcool set UPTM=now(),relyfuns='".$fmfnms."',funkey='".$funparas."',fileurl='".$fileurl."',filelcpath='".$filepath."' where areatype='".$areatype."' and areaname='".$setcode."' and funname='".$funname."'");
           }
        }
  }
  $cc=UX("delete from coode_funcool where areatype='".$areatype."' and areaname='".$setcode."' and timestampdiff(second,UPTM,now())>30");
 break;
 case "bfunx":        
  $datay=file_get_contents(combineurl(localroot(),"/localxres/EARTH.php"));
  $ptfun=explode("function ",$datay);
  $totpt=count($ptfun);
  for ($j=0;$j<$totpt;$j++){
        $funname=qian($ptfun[$j],"(");
        $filename=$areatype."_".$setcode.".".$funname;
        $filepath=combineurl(localroot(),'/localxres/funx/funcool/'.$filename.".txt");
        $fileurl='/localxres/funx/funcool/'.$filename.".txt";
        if ($funname!="" and strpos($funname,"?")<=0){
           $funinner=hou($ptfun[$j],")");
           $funparas=killlaststr(qian(hou($ptfun[$j],"("),"{"));
           $funwhole="function ".$ptfun[$j];
           $fmfx="/,";
           $ptfx=explode("=",$ptfun[$j]);
           for ($p=1;$p<count($ptfx);$p++){
        if (strpos($ptfx[$p],"(")>0){
          $tmpfnm=qian($ptfx[$p],"(");
          $tmpfnm=str_replace(" ","",$tmpfnm);
          $tmpfnm=str_replace(huanhang(),"",$tmpfnm);
          $fmfx=$fmfx.$tmpfnm.",";
        }
           }
      $fmfnms="";
      $crst=SX("select areatype,funname,funcname,funtype,areaname,relyfuns from coode_funcool where '".str_replace("'","\'",$ptfun[$j])."' like concat('%',funname,'%') and areatype='bfunx'");
      $totc=countresult($crst);
       for ($ff=0;$ff<$totc;$ff++){
        $atype=anyvalue($crst,"areatype",$ff);
        $fname=anyvalue($crst,"funname",$ff);
        $fcname=anyvalue($crst,"funcname",$ff);
        $ftype=anyvalue($crst,"funtype",$ff);
        $aname=anyvalue($crst,"areaname",$ff);
        $relyfuns=anyvalue($crst,"relyfuns",$ff);
        $fmfnms=$fmfnms.$fname.",";
      
          }
          $fmfnms=onlyone(killlaststr($fmfnms),",");
           $zz=overfile($filepath,$funwhole);
           $sqly="'".$areatype."','".$setcode."','".$funname."','".$funparas."','','single','".$filepath."','".$fileurl."',now(),now(),'".onlymark()."'";  
           $extf=UX("select count(*) as result from coode_funcool where areatype='".$areatype."' and areaname='".$setcode."' and funname='".$funname."'");
           if (intval($extf)==0){
          $zz=UX("insert into coode_funcool(".$sqlx.")values(".$sqly.")");
           }else{
          $ff=UX("update coode_funcool set UPTM=now(),relyfuns='".$fmfnms."',funkey='".$funparas."',fileurl='".$fileurl."',filelcpath='".$filepath."' where areatype='".$areatype."' and areaname='".$setcode."' and funname='".$funname."'");
           }
        }
  }
  $cc=UX("delete from coode_funcool where areatype='".$areatype."' and areaname='".$setcode."' and timestampdiff(second,UPTM,now())>30");
 break;
 case "sfunx":
  $datax=UX("select funbody as result from coode_funsetfile where setname='".$setcode."'"); 
  $datay=tostring($datax);
  $ptfun=explode("function ",$datay);
  $totpt=count($ptfun);
  $fmfnm="";
  $fmfx="/,";
  $ptfx=explode("=",$datay);
 for ($p=1;$p<count($ptfx);$p++){
        if (strpos($ptfx[$p],"(")>0){
         $tmpfnm=qian($ptfx[$p],"(");
         $tmpfnm=str_replace(" ","",$tmpfnm);
         $tmpfnm=str_replace(huanhang(),"",$tmpfnm);
         $fmfx=$fmfx.$tmpfnm.",";
        }
 }
  for ($j=0;$j<$totpt;$j++){
        $funname=qian($ptfun[$j],"(");
        
        $filename=$areatype."_".$setcode.".".$funname;
        $filepath=combineurl(localroot(),'/localxres/funx/funcool/'.$filename.".txt");
        $fileurl='/localxres/funx/funcool/'.$filename.".txt";
        if ($funname!=""){
          $fmfnm=$fmfnm.$funname.",";
           $funinner=hou($ptfun[$j],")");
           $funparas=killlaststr(qian(hou($ptfun[$j],"("),"{"));
           $funwhole="function ".$ptfun[$j];
           $fmfy="";
           $ptfy=explode("=",$ptfun[$j]);
           for ($pp=1;$pp<count($ptfy);$pp++){
        if (strpos($ptfy[$pp],"(")>0){
          $tmpfnm=qian($ptfy[$pp],"(");
          $tmpfnm=str_replace(" ","",$tmpfnm);
          $tmpfnm=str_replace(huanhang(),"",$tmpfnm);
          $fmfy=$fmfy.$tmpfnm.",";
        }
           }
      $fmfnmx="";
      $crst=SX("select areatype,funname,funcname,funtype,areaname,relyfuns from coode_funcool where '".str_replace("'","\'",$ptfun[$j])."' like concat('%',funname,'%') and areatype='bfunx'");
      $totc=countresult($crst);
       for ($ff=0;$ff<$totc;$ff++){
        $atype=anyvalue($crst,"areatype",$ff);
        $fname=anyvalue($crst,"funname",$ff);
        $fcname=anyvalue($crst,"funcname",$ff);
        $ftype=anyvalue($crst,"funtype",$ff);
        $aname=anyvalue($crst,"areaname",$ff);
        $relyfuns=anyvalue($crst,"relyfuns",$ff);
        $fmfnmx=$fmfnmx.$fname.",";       
          }
          $fmfnmx=onlyone(killlaststr($fmfnmx),",");
           $zz=overfile($filepath,$funwhole);
           $sqly="'".$areatype."','".$setcode."','".$funname."','".$funparas."','','single','".$filepath."','".$fileurl."',now(),now(),'".onlymark()."'";  
           $extf=UX("select count(*) as result from coode_funcool where areatype='".$areatype."' and areaname='".$setcode."' and funname='".$funname."'");
           if (intval($extf)==0){
          $zz=UX("insert into coode_funcool(".$sqlx.")values(".$sqly.")");
           }else{
          $ff=UX("update coode_funcool set UPTM=now(),relyfuns='".$fmfnmx."',funkey='".$funparas."',fileurl='".$fileurl."',filelcpath='".$filepath."' where areatype='".$areatype."' and areaname='".$setcode."' and funname='".$funname."'");
           }
        }
  }
  $fmfnm=killlaststr($fmfnm);
 $fmfnms="";
 $fmtab="";
 $fmcls="";
 $crst=SX("select areatype,funname,funcname,funtype,areaname,relyfuns from coode_funcool where '".str_replace("'","\'",$datay)."' like concat('%',funname,'%') and funtype!='page'");
 $totc=countresult($crst);
 for ($ff=0;$ff<$totc;$ff++){
    $atype=anyvalue($crst,"areatype",$ff);
    $fname=anyvalue($crst,"funname",$ff);
    $fcname=anyvalue($crst,"funcname",$ff);
    $ftype=anyvalue($crst,"funtype",$ff);
    $aname=anyvalue($crst,"areaname",$ff);
    $relyfuns=anyvalue($crst,"relyfuns",$ff);
    if ($relyfuns!=""){
         $fmfnms=$fmfnms.$fname.",".$relyfuns.",";
    }else{
         $fmfnms=$fmfnms.$fname.",";
    }
    switch($atype){
         case "clsx":
           $fmcls=$fmcls.$aname.",";
         break;
         default:
    }
 }
 $fmfnms=onlyone(killlaststr($fmfnms),",");
 $fmcls=onlyone(killlaststr($fmcls),",");
 $trst=SX("select SNO,TABLE_NAME from coode_tablist where '".$datay."' like concat('%\"',TABLE_NAME,'\"%')");
 $tott=countresult($trst);
 for ($t=0;$t<$tott;$t++){
      $tbnm=anyvalue($trst,"TABLE_NAME",$t);
      $fmtab=$fmtab.$tbnm.",";
 }
 $fmtab=onlyone(killlaststr($fmtab),",");
  $zz=UX("update coode_funsetfile set STCODE='".$fmfnm."',afffuns='".$fmfnms."',affclss='".$fmcls."',afftabs='".$fmtab."' where setname='".$setcode."'");
  $zz=UX("update coode_funsetfile set isdb=1  where afffuns like '%SX%' or  afffuns like '%UX%' or  afffuns like '%selecteds%' or  afffuns like '%updatings%' or  afffuns like '%selectedx%' or  afffuns like '%updatingx%' or  afffuns like '%selected%' or  afffuns like '%updating%'");
  $cc=UX("delete from coode_funcool where areatype='".$areatype."' and areaname='".$setcode."' and timestampdiff(second,UPTM,now())>30");
 break;
 case "funx":
 $sqlx="areatype,areaname,funname,funcname,funtype,funfull,CRTM,UPTM,OLMK";
 $zb=UX("insert into coode_funcool(".$sqlx.")select '".$areatype."','".$setcode."',funname,funcname,'page',funfull,now(),now(),OLMK from coode_funlist where concat('".$areatype."','".$setcode."',funname) not in(select concat(areatype,areaname,funname) from coode_funcool)");
 $zc=UX("delete from coode_funcool where areatype='".$areatype."' and areaname='".$setcode."' and funname not in(select funname from coode_funlist)");
 $zc1=UX("update coode_funcool set UPTM=now() where areatype='".$areatype."' and areaname='".$setcode."' ");
 break;
 case "dfunx":
 $sqlx="areatype,areaname,funname,funcname,funtype,funfull,CRTM,UPTM,OLMK";
 $zb=UX("insert into coode_funcool(".$sqlx.")select '".$areatype."','".$setcode."',dfunmark,dftitle,'page',dfuneval,now(),now(),OLMK from coode_datafun where concat('".$areatype."','".$setcode."',dfunmark) not in(select concat(areatype,areaname,funname) from coode_funcool)");
 $zc=UX("delete from coode_funcool where areatype='".$areatype."' and areaname='".$setcode."' and funname not in(select dfunmark from coode_datafun)");
 $zc1=UX("update coode_funcool set UPTM=now() where areatype='".$areatype."' and areaname='".$setcode."' ");
 break;
 case "mfunx":
 $sqlx="areatype,areaname,funname,funcname,funtype,funfull,CRTM,UPTM,OLMK";
 $zb=UX("insert into coode_funcool(".$sqlx.")select '".$areatype."','".$setcode."',funname,funcname,'page',funfull,now(),now(),OLMK from coode_multifunlist where concat('".$areatype."','".$setcode."',funname) not in(select concat(areatype,areaname,funname) from coode_funcool)");
 $zc=UX("delete from coode_funcool where areatype='".$areatype."' and areaname='".$setcode."' and funname not in(select funname from coode_multifunlist)");
 $zc1=UX("update coode_funcool set UPTM=now() where areatype='".$areatype."' and areaname='".$setcode."' ");
 break;
 case "afunx":
 $sqlx="areatype,areaname,funname,funcname,funtype,funfull,CRTM,UPTM,OLMK";
  $zb=UX("insert into coode_funcool(".$sqlx.")select '".$areatype."','".$setcode."',funname,funcname,'page',funfull,now(),now(),OLMK from coode_affairfunlist where concat('".$areatype."','".$setcode."',funname) not in(select concat(areatype,areaname,funname) from coode_funcool)");
 $zc=UX("delete from coode_funcool where areatype='".$areatype."' and areaname='".$setcode."' and funname not in(select funname from coode_affairfunlist)");
 $zc1=UX("update coode_funcool set UPTM=now() where areatype='".$areatype."' and areaname='".$setcode."' ");
 break;
 default:
}
$b=time();
echo makereturnjson("1","生成".$areatype."中的".$setcode."的分函数成功，耗时".($b-$a)."秒","");
       session_write_close();
?>