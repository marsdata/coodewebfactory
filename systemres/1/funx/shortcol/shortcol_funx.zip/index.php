<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $shortid=dftval($_GET["shortid"],"");
$dbmk=dftval($_GET["dbmk"],"");
$tbnm=UX("select tablename as result from coode_shortdata where shortid='".$shortid."'");
eval(RESFUNSET("keyinfo"));
eval(RESFUNSET("keyfunbase"));
$kb=thekeyinfo($kb,$dbmk,$tbnm,"*");
$kbase=thekeyfun($kbase,$dbmk,"shortid",$shortid);
$akb=allkeyinfo($akb,$dbmk,$tbnm);
if ($dbmk==""){
   $fmcd= "TBFRM".$tbnm."=".anyshort("tabcol","","").";\r\n";
}else{
   $fmcd= "TBFRM".$tbnm."=".file_get_contents(combineurl("http://".glw(),"/localxres/funx/anyshort/?stid=tabd2K&tbname=".$tbnm."&dmk=".$dbmk)).";\r\n";
}
$fmcd=$fmcd.$kb["CODE"]["JS"].$kbase["CODE"]["JS"].$akb["CODE"]["JS"];
if ($dbmk==""){
  $sysid=UX("select concat('x',sysid) as result from coode_tablist where TABLE_NAME='".$tbnm."'");
  if ($sysid=="x"){
    $sysid="noname";
  }else{
    $sysid=substr($sysid,1,strlen($sysid)-1);
  }
}else{
  $sysid=UX("select concat('x',sysid) as result from coode_dbtablist where TABLE_NAME='".$tbnm."' and catalog='".$dbmk."'");
  if ($sysid=="x"){
    $sysid="noname";
  }else{
    $sysid=substr($sysid,1,strlen($sysid)-1);
  }
}
if ($dbmk==""){
 $savepath="/localxres/tabx/".$tbnm."/".$shortid."_list.js";
 $savever="/localxres/tabx/".$tbnm."/".$shortid."_listjsversion/";
}else{
 $savepath="/localxres/tabx/".$dbmk."/".$tbnm."/".$shortid."_list.js";
 $savever="/localxres/tabx/".$dbmk."/".$tbnm."/".$shortid."_listjsversion/";
}
$fullpath=combineurl(localroot(),$savepath);
$fullver=combineurl(localroot(),$savever);
$oldcd=file_get_contents($fullpath);
if ($oldcd!=$fmcd){
 $x=overfile($fullpath,$fmcd);
 $x=deltree($fullver);
// $ok=unlink($fullver);
}
echo '{"status":"1","msg":"成功","redirect":"'.$savepath.'"}';
     session_write_close();
?>