<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $stid=_get("stid");
$dtype=_get("dtype");
$strst=SX("select sysid,shorttitle,tablename from coode_shortdata where shortid='".$stid."'");
$sysid=anyvalue($strst,"sysid",0);
$sttt=anyvalue($strst,"shorttitle",0);
$sttab=anyvalue($strst,"tablename",0);
$tinya=getRandChar(6);
    $sqla="sysid,tinymark,tinytitle,tabname,longexp,OLMK,CRTM,UPTM,CRTOR,RIP,STATUS,PRIME";
    if ($dtype=="form"){
     $sqlb="'".$sysid."','".$tinya."','".$sttt."','".$sttab."','/localxres/funx/anyshortnew/?stid=".$stid."&SNO=0','".onlymark()."',now(),now(),'".$_COOKIE["uid"]."','".getip()."',0,1";          
     $x=UX("insert into coode_tiny(".$sqla.")values(".$sqlb.")");
    }else{
     $sqlb="'".$sysid."','".$tinya."','".$sttt."','".$sttab."','/localxres/funx/anyjsshort/?stid=".$stid."-pnum:30-','".onlymark()."',now(),now(),'".$_COOKIE["uid"]."','".getip()."',0,1";     
     $x=UX("insert into coode_tiny(".$sqla.")values(".$sqlb.")");
    }
 echo '{"status":"1","msg":"创建成功","redirect":""}';
     session_write_close();
?>