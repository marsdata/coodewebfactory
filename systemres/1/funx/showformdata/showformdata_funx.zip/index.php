<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $stid=_get("stid");
$frst=SX("select SNO,allkeys,shortid,shorttitle,tablename,showkeys,cdt,orddt,dttp,caseid,sysid,tablename,retrievekey,skeys,addpage,detailid,tabcls from coode_shortdata where shortid='".$stid."'");
$allkeys=anyvalue($frst,"allkeys",0);
$shorttitle=anyvalue($frst,"shorttitle",0);
$tabname=anyvalue($frst,"tabname",0);
$showkeys=anyvalue($frst,"showkeys",0);
$cdt=anyvalue($frst,"cdt",0);
$orddt=anyvalue($frst,"orddt",0);
$dttp=anyvalue($frst,"dttp",0);
$caseid=anyvalue($frst,"caseid",0);
$sysid=anyvalue($frst,"sysid",0);
$tablename=anyvalue($frst,"tablename",0);
$retrievekey=anyvalue($frst,"retrievekey",0);
$skeys=anyvalue($frst,"skeys",0);
$addpage=anyvalue($frst,"addpage",0);
$detailid=anyvalue($frst,"detailid",0);
$tabcls=anyvalue($frst,"tabcls",0);
$srd='{"status":"1","msg":"获取成功","vls":[{"keyx":"allkeys","valx":"'.$allkeys.'"}';
$srd=$srd.',{"keyx":"shorttitle","valx":"'.$shorttitle.'"},{"keyx":"tabname","valx":"'.$tabname.'"}';
$srd=$srd.',{"keyx":"showkeys","valx":"'.$showkeys.'"},{"keyx":"cdt","valx":"'.$cdt.'"}';
$srd=$srd.',{"keyx":"orddt","valx":"'.$orddt.'"},{"keyx":"dttp","valx":"'.$dttp.'"}';
$srd=$srd.',{"keyx":"caseid","valx":"'.$caseid.'"},{"keyx":"sysid","valx":"'.$sysid.'"}';
$srd=$srd.',{"keyx":"tablename","valx":"'.$tablename.'"},{"keyx":"retrievekey","valx":"'.$retrievekey.'"}';
$srd=$srd.',{"keyx":"skeys","valx":"'.$skeys.'"},{"keyx":"addpage","valx":"'.$addpage.'"}';
$srd=$srd.',{"keyx":"detailid","valx":"'.$detailid.'"},{"keyx":"tabcls","valx":"'.$tabcls.'"}]}';
echo $srd;
     session_write_close();
?>