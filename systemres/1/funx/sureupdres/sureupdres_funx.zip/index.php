<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $restype=_get("restype");
$rescode=_get("rescode");
switch($restype){
  case "funx":
      $sysid=UX("select sysid as result from coode_funlist where funname='".$rescode."' and funname='".$rescode."()'");      
      $mthost=anyfunrun("svshost",glm(),"hostid=".$sysid,"");      
      if (strpos($mthost,":443")>0){
        $purl="https://".str_replace(":443","",$mthost)."/localxres/funx/getfunjson/?funid=".$rescode;
      }else{
        $purl="http://".$mthost."/localxres/funx/getfunjson/?funid=".$rescode;
      }
      $bktxt=file_get_contents($purl);
      $bkdata=json_decode($bktxt,false);
      $funfull=$bkdata->funfull;
      $zz=UX("update coode_funlist set funfull='".$funfull."' where funid='".$rescode."'");
      echo makereturnjson("1","完成","");
  break;
  case "plotx":
  $plotrst=SX("select SNO,sysid from coode_plotlist where plotmark='".$rescode."'");
  $sysid=anyvalue($plotrst,"sysid",0);
  $mthost=anyfunrun("svshost",glm(),"hostid=".$sysid,"");      
    if (strpos($mthost,":443")>0){        
        $urlx1="https://".str_replace(":443","",$mthost)."/localxres/funx/anyshortnew/?stid=Wn8RnK&reskey=plotmark&plotmark=".$rescode;
        $urlx2="https://".str_replace(":443","",$mthost)."/localxres/funx/anyjsshort/?stid=NtpFd8&plmk=".$rescode."&pnum=1000";
    }else{        
        $urlx1="http://".$mthost."/localxres/funx/anyshortnew/?stid=Wn8RnK&reskey=plotmark&plotmark=".$rescode;
        $urlx2="http://".$mthost."/localxres/funx/anyjsshort/?stid=NtpFd8&plmk=".$rescode."&pnum=1000";
    }
        
  $btxt1=file_get_contents($urlx1);
  $bdata1=json_decode($btxt1,false);
  $dkey="SNO,layoutid,plotcls,levelcount,totpoint,markname,formcode,withfont,plotmark,CRTM,CRTOR,OLMK,PTOF,sysid,PRIME,STATUS,OPRT";
  $stt1=$bdata1->status;
  $kx=Array();
  $vx=Array();
  if (intval($stt1)>=1){
    $layoutid=$bdata1->layoutid;
    $kx[0]="layoutid";
    $vx[0]=$layoutid;
    $plotcls=$bdata1->plotcls;
    $kx[1]="plotcls";
    $vx[1]=$plotcls;
    $levelcount=$bdata1->levelcount;
    $kx[2]="levelcount";
    $vx[2]=$levelcount;
    $totpoint=$bdata1->totpoint;
    $kx[3]="totpoint";
    $vx[3]=$totpoint;
    $markname=$bdata1->markname;
    $kx[4]="markname";
    $vx[4]=$markname;
    $formcode=$bdata1->formcode;
    $kx[5]="formcode";
    $vx[5]=$formcode;
    $withfont=$bdata1->withfont;
    $kx[6]="withfont";
    $vx[6]=$withfont;
    for ($jj=0;$jj<count($kx);$jj++){
     $zz=UX("update coode_plotdetail set ".$kx[$jj]='".$vx[$jj]."' where plotmark='".$rescode."'");
    }
  }
  $btxt2=file_get_contents($urlx2);
  $bdata2=json_decode($btxt2,false);
  $stt2=$bdata2->status;
  $key2="SNO,plotmark,level,myid,parid,mymark,parmark,mytitle";
  $key3="sysid,appid,layid,myurl,myclick,mydescrib,STATUS,CRTOR,CRTM,OPRT";
  if (intval($stt2)>=1){
   $myid=$bdata2->myid;
   $kx=Array();
   $vx=Array();
   $kx[0]="level";
   $vx[0]=$bdata2->level;
   $kx[1]="myid";
   $vx[1]=$bdata2->myid;
   $kx[2]="parid";
   $vx[2]=$bdata2->parid;
   $kx[3]="STATUS";
   $vx[3]=$bdata2->STATUS;
   $kx[4]="mymark";
   $vx[4]=$bdata2->mymark;
   $kx[5]="parmark";
   $vx[5]=$bdata2->parmark;
   $kx[6]="mytitle";
   $vx[6]=$bdata2->mytitle;
   $kx[7]="sysid";
   $vx[7]=$bdata2->sysid;
   $kx[8]="layid";
   $vx[8]=$bdata2->layid;
   $kx[9]="myurl";
   $vx[9]=$bdata2->myurl;
   $kx[10]="myclick";
   $vx[10]=$bdata2->myclick;
   $kx[11]="mydescrib";
   $vx[11]=$bdata2->mydescrib;
   for ($jj=0;$jj<count($kx);$jj++){
     $zz=UX("update coode_plotdetail set ".$kx[$jj]."='".$vx[$jj]."' where plotmark='".$rescode."' and myid='".$myid."'");
   }
  }
  echo makereturnjson("1","完成","");
  break;
  default:
}
     session_write_close();
?>