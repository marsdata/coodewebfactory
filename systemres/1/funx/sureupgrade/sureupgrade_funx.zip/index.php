<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $restype=_get("restype");
$rescode=_get("rescode");
$upgcode=_get("upgcode");
$trst=SX("select tabname,tabtitle,newkey,ndatatype,ndatalen,oldkey,odatatype,odatalen from coode_tabupd where upgcode='".$upgcode."'");
$tott=countresult($trst);
$fmxy="";
for ($j=0;$<$tott;$j++){
  $tabnm=anyvalue($trst,"tabnm",$j);
  $nk=anyvalue($trst,"newkey",$j);
  $ndt=anyvalue($trst,"ndatatype",$j);
  $ndl=anyvalue($trst,"ndatalen",$j);
  $ok=anyvalue($trst,"oldkey",$j);
  $odt=anyvalue($trst,"odatatype",$j);
  $odl=anyvalue($trst,"odatalen",$j);
  if ($nk.$ndt.$mdl!=$ok.$odt.$odl){
    if ($ok==""){
      if (intval($odl)>0){
          $conn=mysql_connect(gl(),glu(),glp());
          $z=updatingx($conn,glb(),"ALTER TABLE ".$tabnm." MODIFY ".$nk." ".$ndt."(".$ndl.") NOT NULL","utf8");
       }else{
          $conn=mysql_connect(gl(),glu(),glp());
          $z=updatingx($conn,glb(),"ALTER TABLE ".$tabnm." MODIFY ".$nk." ".$ndt." NOT NULL","utf8");
       }
    }else{
     if (intval($odl)>0){
      $conn=mysql_connect(gl(),glu(),glp());
      $z=updatingx($conn,glb(),"ALTER TABLE ".$tabnm." CHANGE COLUMN ".$ok." ".$nk." ".$ndt."(".$ndl.") NOT NULL","utf8");        
     }else{
      $conn=mysql_connect(gl(),glu(),glp());
      $z=updatingx($conn,glb(),"ALTER TABLE ".$tabnm." CHANGE COLUMN ".$ok." ".$nk." ".$ndt." NOT NULL","utf8");        
     }
    }//ok--
  }//nk..ndt..mdl
}
  $pdata=Array();
    $pdata["a"]="";    
      $mthost=anyfunrun("svshost",glm(),"hostid=".$sysid,"");
      
      if (strpos($mthost,":443")>0){
        $purl="https://".str_replace(":443","",$mthost)."/localxres/funx/askver/?restype=".$restype."&rescode=".$rescode;
      }else{
        $purl="http://".$mthost."/localxres/funx/askver/?restype=".$restype."&rescode=".$rescode;
      }    
      
      $bktxt=request_post($purl,$pdata);
      $bkdata=json_decode($bktxt,false);
      $crtsql=$bkdata->crtsql;
      $sqltxt=$crtsql;
      $mtmd5=$bkdata->tabmd5;
      
      $tabnm=str_replace(""," ",qian(hou($sqltxt,"CREATE TABLE"),"("));
      $sqlstr=hou($sqltxt,"(");
      $ptkey=explode(",",$sqlstr);
      $totpt=count($ptkey);
      $fmk="";
      for ($j=0;$j<$totpt;$j++){
        if (strpos("xxx".$ptkey[$j],"PRIMARY KEY")>0){    
        }else{
          if (strpos($ptkey[$j],"(")>0){
            $keyx=qian($ptkey[$j]," ");
            $ktype=qian(hou($ptkey[$j]," "),"(");
            $klen=qian(hou($ptkey[$j],"("),")");
          }else{
            $keyx=qian($ptkey[$j]," ");
            $ktype=qian(hou($ptkey[$j]," ")," ");
            $klen="0";
          }   
          if ($stype=="new"){
          }else{ 
            if  (strpos("xxx".$fmxy,$keyx)>0){        
            }else{
              $conn=mysql_connect(gl(),glu(),glp());
              $z=updatingx($conn,glb(),"ALTER TABLE ".$tabnm." DROP COLUMN ".$keyx,"utf8");
              $fmk=$fmk.$keyx.",";
            }
          }//不存在的字段
        }   
      }//for
     
    $fmk=killlaststr($fmk);    
 
   $ccc=UX("update coode_tabuindex set  leftkillk='$fmk' where upgcode='$upgcode'");
 
  $mthost=anyfunrun("svshost",glm(),"hostid=".$sysid,"");
 
 if (strpos($mthost,":443")>0){
  $url1=combineurl("https://".str_replace(":443","",$mthost),"/localxres/funx/anyshort/?stid=2qPIqS-sfile:anyjsshort.php-&pnum=150:".$tabnm."&page=1:TABLE_NAME&datatype=json");
  $url2=combineurl("https://".str_replace(":443","",$mthost),"/localxres/funx/anyshort/?stid=pMoPka-&pnum=150:coode_funlist&page=1:TABLE_NAME&datatype=json");
  $url3=combineurl("https://".str_replace(":443","",$mthost),"/localxres/funx/anyshort/?stid=EtRhCo-&pnum=150:coode_funlist&page=1:TABLE_NAME&datatype=json");
  $url4=combineurl("https://".str_replace(":443","",$mthost),"/localxres/funx/showformdata/?stid=".$rescode);
 }else{
  $url1=combineurl("http://".$mthost,"/localxres/funx/anyshort/?stid=2qPIqS-sfile:anyjsshort.php-&pnum=150:".$tabnm."&page=1:TABLE_NAME&datatype=json");
  $url2=combineurl("http://".$mthost,"/localxres/funx/anyshort/?stid=pMoPka-&pnum=150:coode_funlist&page=1:TABLE_NAME&datatype=json");
  $url3=combineurl("http://".$mthost,"/localxres/funx/anyshort/?stid=EtRhCo-&pnum=150:coode_funlist&page=1:TABLE_NAME&datatype=json");
  $url4=combineurl("http://".$mthost,"/localxres/funx/showformdata/?stid=".$rescode);
 }
 
  $bt1=file_get_contents($url1);
  $bd1=json_decode($bt1,false);
  $vls1=$bd1->vls;
 for ($j=0;count($vls1);$j++){
   $dbname=$vls1[$j]->TABLE_SCHEMA;
   $tabname=$vls1[$j]->TABLE_NAME;
   $colname=$vls1[$j]->COLUMN_NAME;
   $keytitle= $vls1[$j]->keytitle;
   $keyexplain= $vls1[$j]->keyexplain;
   $kxx=Array();
   $vxx=Array();
   $clstxt= $vls1[$j]->clstxt;
      $kxx[0]="clstxt";
      $vxx[0]=$clstxt;
   $changeable= $vls1[$j]->changeable;
      $kxx[1]="changeable";
      $vxx[1]=$changeable;
   $displayed= $vls1[$j]->displayed;
      $kxx[2]="displayed";
      $vxx[2]=$displayed;
   $isfixed= $vls1[$j]->isfixed;
      $kxx[3]="isfixed";
      $vxx[2]=$isfixed;
   $stt= $vls1[$j]->STATUS;
      $kxx[4]="STATUS";
      $vxx[4]=$stt;
   $sqx= $vls1[$j]->SQX;
      $kxx[5]="SQX";
      $vxx[5]=$sqx;
   $vqx= $vls1[$j]->VQX;
      $kxx[6]="VQX";
      $vxx[6]=$vqx;
   $dxtype= $vls1[$j]->dxtype;
      $kxx[7]="dxtype";
      $vxx[7]=$dxtype;      
   $classp= $vls1[$j]->classp;
      $kxx[8]="classp";
      $vxx[8]=$classp;
   $extcol=UX("select count(*) as result from coode_keydetailx where COLUMN_NAME='".$colname."' and TABLE_NAME='".$tabname."'");
   if (intval($extcol)==0){
     $sqlx="TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,keytitle,keyexplain,CRTM,UPTM,OLMK";
     $sqly="'$dbname','$tabname','$colname','$keytitle','$keyexplain',now(),now(),'".onlymark()."'";
     $zzx=UX("insert into coode_keydetailx(".$sqlx.")values(".$sqly.")");
   }
   for ($vv=0;$vv<count($kxx);$vv++){
     $zzy=UX("update coode_keydetailx set ".$kxx[$vv]='".$vxx[$vv]."' where COLUMN_NAME='".$colname."' and TABLE_NAME='".$tabname."'");
   }
 }
 
 $bt2=file_get_contents($url2);
 $bd2=json_decode($bt2,false);
 $key2s="SNO,TABLE_NAME,COLUMN_NAME,jsshowfun,jspostfun,sysshowfun,valuezero,syspostfun,thcode,tdcode";
 $vls2=$bd2->vls;
 for ($k=0;count($vls2);$k++){   
   $tabname=$vls2[$k]->TABLE_NAME;
   $colname=$vls2[$k]->COLUMN_NAME;
   $kxx=Array();
   $vxx=Array();
   $jsshowfun=$vls2[$k]->jsshowfun;
   $kxx[0]="jsshowfun";
   $vxx[0]=$jsshowfun;
   $sysshowfun=$vls2[$k]->sysshowfun;
   $kxx[1]="sysshowfun";
   $vxx[1]=$sysshowfun;
   $valuezero=$vls2[$k]->valuezero;
   $kxx[2]="valuezero";
   $vxx[2]=$valuezero;
   $syspostfun=$vls2[$k]->syspostfun;
   $kxx[3]="syspostfun";
   $vxx[3]=$syspostfun;
   $jspostfun=$vls2[$k]->jspostfun;
   $kxx[4]="jspostfun";
   $vxx[4]=$jspostfun;
   $thcode=$vls2[$k]->thcode;
   $kxx[5]="thcode";
   $vxx[5]=$thcode;
   $tdcode=$vls2[$k]->tdcode;
   $kxx[6]="tdcode";
   $vxx[6]=$tdcode;
   for ($vv=0;$vv<count($kxx);$vv++){
     $zzy=UX("update coode_keydetailx set ".$kxx[$vv]='".$vxx[$vv]."' where COLUMN_NAME='".$colname."' and TABLE_NAME='".$tabname."'");
   }
 }
 
 $bt3=file_get_contents($url3);
 $bd3=json_decode($bt3,false);
 $key3s="SNO,TABLE_NAME,COLUMN_NAME,COLUMN_DEFAULT,acthtml,VRT,bfist,aftist,bfupd,aftupd,bfdel,aftdel,PRIME,OLMK";
 $vls3=$bd3->vls;
 for ($v=0;count($vls3);$v++){
   $kxx=Array();
   $vxx=Array();
   $tabname=$vls3[$v]->TABLE_NAME;
   $colname=$vls3[$v]->COLUMN_NAME;
   $coldft=$vls3[$v]->COLUMN_DEFAULT;
    $kxx[0]="coldft";
    $vxx[0]=$coldft;
   $bfist=$vls3[$v]->bfist;
    $kxx[1]="bfist";
    $vxx[1]=$bfist;
   $aftist=$vls3[$v]->aftist;
    $kxx[2]="aftist";
    $vxx[2]=$aftist;
   $bfupd=$vls3[$v]->bfupd;
    $kxx[3]="bfupd";
    $vxx[3]=$bfupd;
   $aftupd=$vls3[$v]->aftupd;
    $kxx[4]="aftupd";
    $vxx[4]=$aftupd;
   $bfdel=$vls3[$v]->bfdel;
    $kxx[5]="bfdel";
    $vxx[5]=$bfdel;
   $aftdel=$vls3[$v]->aftdel;
    $kxx[6]="aftdel";
    $vxx[6]=$aftdel;
   for ($vv=0;$vv<count($kxx);$vv++){
     $zzy=UX("update coode_keydetailx set ".$kxx[$vv]='".$vxx[$vv]."' where COLUMN_NAME='".$colname."' and TABLE_NAME='".$tabname."'");
   }
 }
  $bt4=file_get_contents($url4);
  $bd4=json_decode($bt4,false);
  $vls4=$bd4->vls;
 for ($m=0;count($vls4);$m++){
    $bb=UX("update coode_shortdata set ".$vls4[$m]->keyx='".$vls4[$m]->valx."' where shortid='".$rescode."'");
 }
   $mthost=anyfunrun("svshost",glm(),"hostid=".$sysid,"");
 
 if (strpos($mthost,":443")>0){
   $url1=combineurl("https://".str_replace(":443","",$mthost),"/localxres/funx/anyshort/?stid=keydtly-&pnum=100:".$rescode."&page=1:shortid&datatype=json");
   $url2=combineurl("https://".str_replace(":443","",$mthost),"/localxres/funx/anyshort/?stid=keyfuny-&pnum=100:".$rescode."&page=1:shortid&datatype=json");
 }else{
   $url1=combineurl("http://".$mthost,"/localxres/funx/anyshort/?stid=keydtly-&pnum=150:".$rescode."&page=1:shortid&datatype=json");
   $url2=combineurl("http://".$mthost,"/localxres/funx/anyshort/?stid=keyfuny-&pnum=150:".$rescode."&page=1:shortid&datatype=json");
 }
  $bt1=file_get_contents($url1);
  $bd1=json_decode($bt1,false);
  $vls1=$bd1->vls;
  //SNO,TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,keytitle,keyexplain,clstxt,changeable,displayed,SQX,VQX,dxtype,classp,OPRT
 for ($j=0;count($vls1);$j++){
   $dbname=$vls1[$j]->TABLE_SCHEMA;
   $tabname=$vls1[$j]->TABLE_NAME;
   $colname=$vls1[$j]->COLUMN_NAME;
   $keytitle= $vls1[$j]->keytitle;
   $keyexplain= $vls1[$j]->keyexplain;
   $kxx=Array();
   $vxx=Array();
   $clstxt= $vls1[$j]->clstxt;
      $kxx[0]="clstxt";
      $vxx[0]=$clstxt;
   $changeable= $vls1[$j]->changeable;
      $kxx[1]="changeable";
      $vxx[1]=$changeable;
   $displayed= $vls1[$j]->displayed;
      $kxx[2]="displayed";
      $vxx[2]=$displayed;
   $sqx= $vls1[$j]->SQX;
      $kxx[3]="SQX";
      $vxx[3]=$sqx;
   $vqx= $vls1[$j]->VQX;
      $kxx[4]="VQX";
      $vxx[4]=$vqx;
   $dxtype= $vls1[$j]->dxtype;
      $kxx[5]="dxtype";
      $vxx[5]=$dxtype;      
   $classp= $vls1[$j]->classp;
      $kxx[6]="classp";
      $vxx[6]=$classp;
   $extcol=UX("select count(*) as result from coode_keydetaily where COLUMN_NAME='".$colname."' and shortid='".$rescode."'");
   if (intval($extcol)==0){
     $sqlx="TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,keytitle,keyexplain,CRTM,UPTM,OLMK,shortid";
     $sqly="'$dbname','$tabname','$colname','$keytitle','$keyexplain',now(),now(),'".onlymark()."','".$rescode."'";
     $zzx=UX("insert into coode_keydetailx(".$sqlx.")values(".$sqly.")");
   }
   for ($vv=0;$vv<count($kxx);$vv++){
     $zzy=UX("update coode_keydetaily set ".$kxx[$vv]='".$vxx[$vv]."' where COLUMN_NAME='".$colname."' and shortid='".$rescode."'");
   }
 }
 
 $bt2=file_get_contents($url2);
 $bd2=json_decode($bt2,false);
 $key2s="SNO,TABLE_SCHEMA,shortid,TABLE_NAME,COLUMN_NAME,keytitle,jsshowfun,jspostfun,sysshowfun,syspostfun,valuezero,OPRT";
 $vls2=$bd2->vls;
 for ($k=0;count($vls2);$k++){   
   $tabname=$vls2[$k]->TABLE_NAME;
   $colname=$vls2[$k]->COLUMN_NAME;
   $kxx=Array();
   $vxx=Array();
   $jsshowfun=$vls2[$k]->jsshowfun;
   $kxx[0]="jsshowfun";
   $vxx[0]=$jsshowfun;
   $sysshowfun=$vls2[$k]->sysshowfun;
   $kxx[1]="sysshowfun";
   $vxx[1]=$sysshowfun;
   $valuezero=$vls2[$k]->valuezero;
   $kxx[2]="valuezero";
   $vxx[2]=$valuezero;
   $syspostfun=$vls2[$k]->syspostfun;
   $kxx[3]="syspostfun";
   $vxx[3]=$syspostfun;
   $jspostfun=$vls2[$k]->jspostfun;
   $kxx[4]="jspostfun";
   $vxx[4]=$jspostfun;
   for ($vv=0;$vv<count($kxx);$vv++){
     $zzy=UX("update coode_keydetaily set ".$kxx[$vv]='".$vxx[$vv]."' where COLUMN_NAME='".$colname."' and shortid='".$rescode."'");
   }
 }
 echo makereturnjson("1","升级成功","");
 
     session_write_close();
?>