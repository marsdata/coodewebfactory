<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $sysid=$_GET["sysid"];
$a=time();
if ($sysid==""){
  $kk=UX("delete from coode_sysregres");
  $nn=anyfunrun("retabsno","","tabnm=coode_sysregres","");
  $kk=UX("delete from coode_sysregtype");
  $nn=anyfunrun("retabsno","","tabnm=coode_sysregtype","");
  $zz1=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'funx',funname,funcname,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_funlist where sysid!='' and concat('funx',funname) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz2=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'tabx',tablename,shorttitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_shortdata where sysid!='' and concat(sysid,'tabx',tablename) not in(select concat(grpid,restype,resmark) from coode_sysregres) group by concat(sysid,'tabx',tablename)");
  $zzZ2=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'tabx',TABLE_NAME,tabtitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_tablist where sysid!='' and concat(sysid,'tabx',TABLE_NAME) not in(select concat(grpid,restype,resmark) from coode_sysregres) group by concat(sysid,'tabx',TABLE_NAME)");
  $zz3=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'tempx',tempid,tinytitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_tiny where sysid!='' and tempid!='' and concat(sysid,'tempx',tempid) not in(select concat(grpid,restype,resmark) from coode_sysregres) group by concat(sysid,'tempx',tempid)");
  $zz3=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'tempx',dumark,unittitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_domainunit where sysid!='' and dumark!='' and concat(sysid,'tempx',dumark) not in(select concat(grpid,restype,resmark) from coode_sysregres) group by concat(sysid,'tempx',dumark)");
  $zz4=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'plotx',plotmark,markname,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_plotlist where sysid!='' and concat('plotx',plotmark) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz5=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'clsx',funname,funcname,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_phpcls where sysid!='' and concat('clsx',funname) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz6=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'formx',shortid,shorttitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),STATUS,vermd5 from coode_shortdata where sysid!='' and concat('formx',shortid) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz7=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'pagex',tinymark,tinytitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),STATUS,vermd5 from coode_tiny where sysid!='' and concat('pagex',tinymark) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz8=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'dataspacex',datamark,datatitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_dataspace where sysid!='' and concat('dataspacex',datamark) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz9=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'sfunx',setname,setcname,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_funsetfile where sysid!='' and concat('sfunx',setname) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz10=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'dfunx',dfunmark,dftitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_datafun where sysid!='' and concat('dfunx',dfunmark) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz11=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'mfunx',funname,funcname,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_multifunlist where sysid!='' and concat('mfunx',funname) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz12=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'groupx',plotmark,markname,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_grouplist where sysid!='' and concat('groupx',plotmark) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz13=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'cdtrdrx',concat(cdtmark,'.',cdtval),rdrpath,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_cdtrdr where sysid!='' and concat('cdtrdrx',concat(cdtmark,'.',cdtval)) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz14=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'parardrx',paramark,paratitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_parardr where sysid!='' and concat('parardrx',paramark) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz15=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'constx',constantid,constanttitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_sysconstant where sysid!='' and concat(sysid,'constx',constantid) not in(select concat(grpid,restype,resmark) from coode_sysregres)");
  $zz16=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'configx',syskey,sysktitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_sysconfig where sysid!='' and concat('configx',syskey) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz17=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'parax',paramark,paratitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_para where sysid!='' and concat('parax',paramark) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz18=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'iconsetx',setmark,settitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_iconset where sysid!='' and concat('iconsetx',setmark) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz19=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'sysx',sysid,sysname,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_sysinformation where sysid!='' and concat('sysx',sysid) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz20=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'appx',appid,appname,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_appdefault where sysid!='' and concat('appx',appid) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz21=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'layx',layid,laytitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_applay where sysid!='' and concat('layx',layid) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz22=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'csspagex',faceid,facetitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_facelist where sysid!='' and concat('csspagex',faceid) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz23=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'databasex',dbmark,dbtitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_dblist where sysid!='' and concat('databasex',dbmark) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz24=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'afunx',funname,funcname,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_affairfunlist where sysid!='' and concat('afunx',funname) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz25=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'apix',apicode,apititle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_apipool where sysid!='' and concat('apix',apicode) not in(select concat(restype,resmark) from coode_sysregres)");
  $zz26=UX("insert into coode_sysregres(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'smallcssx',elemark,eletitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_tinyhtml where sysid!='' and concat('smallcssx',elemark) not in(select concat(restype,resmark) from coode_sysregres)");
  $zzz=UX("update coode_sysregres,coode_tablist set coode_sysregres.vermd5=coode_tablist.vermd5,coode_sysregres.restitle=coode_tablist.tabtitle where coode_sysregres.resmark=coode_tablist.TABLE_NAME");
  $zzz=UX("update coode_sysregres,coode_tiny set coode_sysregres.vermd5=coode_domainunit.vermd5,coode_sysregres.restitle=coode_domainunit.unittitle where coode_sysregres.resmark=coode_domainunit.dumark");
  $ss=UX("update coode_sysregres,coode_sysrestypedefine set coode_sysregres.headpic=coode_sysrestypedefine.headpic,coode_sysregres.issys=coode_sysrestypedefine.numx,coode_sysregres.midpic=coode_sysrestypedefine.midpic where  coode_sysregres.restype=coode_sysrestypedefine.restypecode");
  $extsys=UX("insert into coode_sysinformation(sysid,sysname,CRTM,UPTM,OLMK)select grpid,grpid,now(),now(),md5(RAND()*1000) from coode_sysregres where grpid not in(select sysid from coode_sysinformation) group by grpid");
  $sqla="grpid,restype,CRTM,UPTM,CRTOR,OLMK";
  $sqlb="grpid,restype,now(),now(),'".$_COOKIE["uid"]."',md5(RAND())";
  $tt=UX("insert into coode_sysregtype(".$sqla.")select ".$sqlb." from coode_sysregres group by concat(grpid,restype)");
  $nn=UX("update coode_sysregtype,coode_sysrestypedefine set coode_sysregtype.headpic=coode_sysrestypedefine.headpic,coode_sysregtype.typename=coode_sysrestypedefine.restypetitle where coode_sysregtype.restype=coode_sysrestypedefine.restypecode");
 }else{
    $indexdemo=constval("sysindex");
    $installdemo=constval("installindex");
    $idxurl=combineurl(localroot(),"/systemres/".$sysid."/index.php");
    $zz=overfile($idxurl,'<?php'.huanhang().$indexdemo.huanhang().'?>');
    $isturl=combineurl(localroot(),"/systemres/".$sysid."/install/index.php");
    $zz=overfile($isturl,'<?php'.huanhang().$installdemo.huanhang().'?>');
    $fromfile=combineurl(localroot(),"/localxres/EARTH.php");
    $todir=combineurl(localroot(),"/systemres/".$sysid."/install/resjar/");
    $zz1=copy_filetodir($fromfile,$todir);
 
   $totres=UX("select count(*) as result from coode_sysregres where grpid='".$sysid."'");
   $resrst=SX("select resmark,vermd5 from coode_sysregres where grpid='".$sysid."'");
   $vrtx=md5($resrst);
   
   $ff=combineurl(localroot(),"/systemres/".$sysid."/".$sysid.".json");
   $fb=combineurl(localroot(),"/systemres/".$sysid."/".$sysid."01.json");   
   $fc=combineurl(localroot(),"/systemres/".$sysid."/basetab.json");   
   $fd=combineurl(localroot(),"/systemres/".$sysid."/coode01.json");   
   $zz0=UX("update coode_sysinformation  set VRT='".$vrtx."',totres='".$totres."' where sysid='".$sysid."'");
   $zz1=overfile($ff,anyfunrun("anyshort","","stid=GJXex0&pnum=9999&page=1&grpid=".$sysid,""));
   $zz2=overfile($fb,anyfunrun("anyshort","","stid=GJXVJC&pnum=9999&page=1&sysid=".$sysid,""));
   $zz3=overfile($fd,anyfunrun("anyshort","","stid=GJXRQW&pnum=9999&page=1",""));   
   $tabjson=anyfunrun("anyshort","","stid=AmmKaB&pnum=9999&page=1","");
   $tabjson=str_replace("获取成功",$sysid,$tabjson);
   $zz4=overfile($fc,$tabjson);
   
   $jurlx=combineurl(localroot(),"/systemres/".$sysid."/coode01.json");
   $resjson=file_get_contents($jurlx);
   $savepath=combineurl(localroot(),"/systemres/".$sysid."/install/resjar/coode01.json");
   $zz=overfile($savepath,$resjson);
   
   $jurlx=combineurl(localroot(),"/systemres/".$sysid."/".$sysid."01.json");
   $resjson=file_get_contents($jurlx);
   $savepath=combineurl(localroot(),"/systemres/".$sysid."/install/resjar/".$sysid."01.json");
   $zz=overfile($savepath,$resjson);
   
   $jurlx=combineurl(localroot(),"/systemres/".$sysid."/".$sysid.".json");
   $resjson=file_get_contents($jurlx);
   $savepath=combineurl(localroot(),"/systemres/".$sysid."/install/resjar/".$sysid.".json");
   $zz=overfile($savepath,$resjson);
   
   $fe=combineurl(localroot(),"/systemres/".$sysid."/install/resjar/basetab.json");   
   $zz5=overfile($fe,$tabjson);
 }
  $b=time();
echo makereturnjson("1","成功".($b-$a)."秒","");
       session_write_close();
?>