<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $demo='{h3 }[systitle]{/h3}
 {ul}<data>{/ul}';
 $item='{li}{a href="[appurl]" target="_blank"}[apptitle]{/a}[appdescrib]{/li}';
$srst=SX("select sysid,sysname from coode_sysinformation");
$fmall="";
$tots=countresult($srst);
for ($j=0;$j<$tots;$j++){
 $demox=$demo;
 $stitle=anyvalue($srst,"sysname",$j);
 $sysid=anyvalue($srst,"sysid",$j);
 $demox=str_replace("[systitle]",$stitle,$demox);
 
 $arst=SX("select appid,appname from coode_appdefault where sysid='".$sysid."'"); 
 $tota=countresult($arst);
 $fmitem="";
 for ($k=0;$k<$tota;$k++){
   $itemy=$item;
   $appid=anyvalue($arst,"appid",$k);
   $appnm=anyvalue($arst,"appname",$k);
   $itemy=str_replace("[appurl]","/localxres/funx/anyapp/?appid=".$appid,$itemy);
   $itemy=str_replace("[apptitle]",$appnm,$itemy);
   $itemy=str_replace("[appdescrib]","",$itemy);
   $fmitem=$fmitem.$itemy;
 }
 $demox=str_replace("<data>",$fmitem,$demox);
 $fmall=$fmall.$demox;
}
echo $fmall;
     session_write_close();
?>