<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     eval(RESFUNSET("resrelyrp"));
//$funtitle="系统资源深度统计";sysid=".$valstr."&rrestype=".$relyrestp."&rrescode=".$relyrescd
$sysid=dftval($_GET["sysid"],"");
$rrestype=dftval($_GET["rrestype"],"");
$rrescode=dftval($_GET["rrescode"],"");
$relyrst=SX("select relyrestp,relyrescd,relyrestitle from coode_resrelyext where restype='".$rrestype."' and rescode='".$rrescode."'");
$totrely=countresult($relyrst);
for ($j=0;$j<$totrely;$j++){
 $rrestype=anyvalue($relyrst,"relyrestp",$j);
 $rrescd=anyvalue($relyrst,"relyrescd",$j);
 $rrestitle=anyvalue($relyrst,"relyrestitle",$j);
 $newrls=addsrctores($rrestype,$rrescd,"sysx",$sysid);
 if (strpos("xx".$rrestype,"fun")>0){
  $zz=UX("update coode_resrelyext set sysid=replace(sysid,'".$sysid.",','') where restype='".$rrestype."' and rescode='".$rrescd."'");
  $zz=UX("update coode_resrelyext set sysid=concat(sysid,'".$sysid.",') where restype='".$rrestype."' and rescode='".$rrescd."'");
 }
}
echo makereturnjson("1","关联".$rrestitle."资源成功","");
     session_write_close();
?>