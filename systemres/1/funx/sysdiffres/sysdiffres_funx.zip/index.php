<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $fromhost=_get("fromhost");
$sysid=$_GET["sysid"];
    if ($_SERVER['SERVER_PORT']=="80"){     
      $myhost=$_SERVER["HTTP_HOST"];
    }else{
      $myhost=$_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"];
    }
$sqlx="thishost,host,grpid,restype,resmark,restitle,headpic,midpic,CRTM,UPTM,vermd5";
$sqly="grpid,restype,resmark,restitle,headpic,midpic,CRTM,UPTM,vermd5";
$zz=UX("insert into coode_syshostres(".$sqlx.")select '$myhost','$fromhost',".$sqly." from coode_sysregres where grpid='".$sysid."' and concat ('".$fromhost."',grpid,restype,resmark) not in (select concat(host,grpid,restype,resmark) from coode_syshostres)");
$zz1=UX("update coode_syshostres set STATUS=0,thishost='$myhost' where host='".$fromhost."' and grpid='".$sysid."'");
$systxt=anyfunrun("anyshort","","stid=PNbq6u&sysid=".$sysid,"");
$sysdata=json_decode($systxt,false);
$fmall=":)";
$vls=$sysdata->vls;
//echo $systxt;
$hosttxt=anyfunrun("anyshort",$fromhost,"stid=PNbq6u&sysid=".$sysid,"");
$hostdata=json_decode($hosttxt,false);
$data=$hostdata->vls;
$fmb=":)";
for ($k=0;$k<count($data);$k++){
   $fmb=$fmb.$data[$k]->restype."@".$data[$k]->resmark."-".$data[$k]->vermd5."/";
}
//echo $fmb."--------------------------------------------------------";
$tmp=0;
//var_dump($data);
//echo count($data);
for ($j=0;$j<count($vls);$j++){  
   $fma=$vls[$j]->restype."@".$vls[$j]->resmark."-".$vls[$j]->vermd5;   
   if (strpos($fmb,$fma)>0){
    //echo $fma."----------".strpos($fmb,$fma).huanhang();
    $tmp=$tmp+1;
   }else{
     $zz2=UX("update coode_syshostres set STATUS=1 where host='".$fromhost."' and grpid='".$sysid."' and restype='".$vls[$j]->restype."' and resmark='".$vls[$j]->resmark."'");         
   }
}
//echo "tmp-".$tmp.$fromhost;   
echo anyfunrun("anyshort","","stid=PNbJWw&sysid=".$sysid."&host=".$fromhost,"");
     session_write_close();
?>