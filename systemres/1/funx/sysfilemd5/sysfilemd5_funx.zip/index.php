<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $frst=SX("select SNO,filelcurl from coode_filelist where filetype!='folder' and md5='' limit 0,50");
$totf=countresult($frst);
for ($i=0;$i<$totf;$i++){
  $snox=anyvalue($frst,"SNO",$i);
  $flcurl=anyvalue($frst,"filelcurl",$i);
  $fsize=filesize($flcurl);
  $fmd5=md5_file($flcurl);
  $zz=UX("update coode_filelist set filesize='".$fsize."',md5='".$fmd5."' where SNO=".$snox);
}
echo makereturnjson("1","成功=".$totf,"");
     session_write_close();
?>