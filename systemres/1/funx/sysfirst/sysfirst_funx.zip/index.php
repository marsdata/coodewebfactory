<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       eval(RESFUNSET("userinfo"));
$uid=dftval($_GET["uid"],"");
$pass=dftval($_GET["pass"],"");
$bdip=dftval($_GET["bdip"],"");
$bduser=dftval($_GET["bduser"],"");
$bdpass=dftval($_GET["bdpass"],"");
$bdbase=dftval($_GET["bdbase"],"");
$exttp=UX("select count(*) as result from coode_sysrestypedefine ");
if (intval($exttp)==0){
$typetxt=anyfunrun("anyshort",glm(),"stid=coodesys&pnum=99","");
$typejson=json_decode($typetxt,false);
$vlx=$typejson->vls;
 $sqla="restypecode,restypetitle,typedescrib,headpic,midpic,png64x64,relyotherres,localsavepath,CRTM,UPTM,OLMK,CRTOR";
  for ($jj=0;$jj<count($vlx);$jj++){
    //restypecode,restypetitle,typedescrib,headpic,midpic,png64x64,relyotherres,localsavepath
    $rcode=$vlx[$jj]->restypecode;
    $rtitle=$vlx[$jj]->restypetitle;
    $rdescrib=$vlx[$jj]->typedescrib;
    $headpic=$vlx[$jj]->headpic;
    $midpic=$vlx[$jj]->midpic;
    $png64x64=$vlx[$jj]->png64x64;
    $relyo=$vlx[$jj]->relyotherres;
    $localsp=$vlx[$jj]->localsavepath;
    $sqlb="'$rcode','$rtitle','$rdescrib','$headpic','$midpic','$png64x64','$relyo','$localsp',now(),now(),'".onlymark()."','".$_COOKIE["uid"]."'";
    $zz=UX("insert into coode_sysrestypedefine(".$sqla.")values(".$sqlb.")");
  }
}
if (es($uid)*es($pass)==1 and $uid!="admin"){
 $z0=UX("update coode_keydetailx set TABLE_SCHEMA='".glb()."'");
 $z1=UX("update coode_keydetaily set TABLE_SCHEMA='".glb()."'");
 $z2=UX("update coode_keydetailz set TABLE_SCHEMA='".glb()."'");
 $z3=UX("update coode_tablist set schm='".glb()."'");
 $z4=UX("update coode_dbtablist set schm='".glb()."' where catalog='thishostcore'");
 $z5=UX("update coode_dblist set dbnm='".glb()."',dbip='".gl()."',dbus='".glu()."',dbps='".glp()."',dbdomain='".gl()."' where dbmark='thishostcore'");
 $zz0=newrole("god","上帝","universe","universe");
 $zz1q=newuser("admin","123456","universe","上帝超管","god,","","universe");
 $zz2q=newuser($uid,$pass,"universe","人类超管","god,","","universe");
 if (es($bdip)*es($bduser)*es($bdpass)*es($bdbase)==1){
  $dftfile=combineurl(localroot(),"/localxres/USERDEFINE.php");
  $dfttxt=file_get_contents($dftfile);
  $dfttxt=str_replace("[bdip]",$bdip,$dfttxt);
  $dfttxt=str_replace("[bduser]",$bdip,$dfttxt);
  $dfttxt=str_replace("[bdpass]",$bdip,$dfttxt);
  $dfttxt=str_replace("[bdbase]",$bdip,$dfttxt);
  $zz=overfile($dftfile,$dfttxt);
 }
 $dd=anyfunrun("plottoresmenu","","","");//制作资源菜单
 echo makereturnjson("1","系统数据初始化成功","/localxres/pagex/wc7frm/IEq6x9/index.html");
}else{
 echo makereturnjson("0","参数不全","");
}
       session_write_close();
?>