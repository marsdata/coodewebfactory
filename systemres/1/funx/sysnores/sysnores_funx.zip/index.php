<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $a=time();
  $kk=UX("delete from coode_sysnoreg");
  $nn=anyfunrun("retabsno","","tabnm=coode_sysnoreg","");
  $zz1=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'funx',funname,funcname,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_funlist where sysid='' and concat('funx',funname) not in(select concat(restype,resmark) from coode_sysnoreg)");
  //$zz2=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'tabx',tablename,shorttitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_shortdata where sysid='' and concat(sysid,'tabx',tablename) not in(select concat(grpid,restype,resmark) from coode_sysnoreg) group by concat(sysid,'tabx',tablename)");
  //$zz3=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'tempx',tempid,tinytitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_tiny where sysid='' and tempid!='' and concat(sysid,'tempx',tempid) not in(select concat(grpid,restype,resmark) from coode_sysnoreg) group by concat(sysid,'tempx',tempid)");
  $zz4=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'plotx',plotmark,markname,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_plotlist where sysid='' and concat('plotx',plotmark) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz5=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'clsx',funname,funcname,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_phpcls where sysid='' and concat('clsx',funname) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz6=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'formx',shortid,shorttitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),STATUS,vermd5 from coode_shortdata where sysid='' and concat('formx',shortid) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz7=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'pagex',tinymark,tinytitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),STATUS,vermd5 from coode_tiny where sysid='' and concat('pagex',tinymark) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz8=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'dataspacex',datamark,datatitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_dataspace where sysid='' and concat('dataspacex',datamark) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz9=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'sfunx',setname,setcname,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_funsetfile where sysid='' and concat('sfunx',setname) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz10=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'dfunx',dfunmark,dftitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_datafun where sysid='' and concat('dfunx',dfunmark) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz11=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'mfunx',funname,funcname,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_multifunlist where sysid='' and concat('mfunx',funname) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz12=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'groupx',plotmark,markname,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_grouplist where sysid='' and concat('groupx',plotmark) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz13=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'cdtrdrx',concat(cdtmark,'.',cdtval),rdrpath,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_cdtrdr where sysid='' and concat('cdtrdrx',concat(cdtmark,'.',cdtval)) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz14=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'parardrx',paramark,paratitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_parardr where sysid='' and concat('parardrx',paramark) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz15=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'constx',constantid,constanttitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_sysconstant where sysid='' and concat('constx',constantid) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz16=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'configx',syskey,sysktitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_sysconfig where sysid='' and concat('configx',syskey) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz17=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'parax',paramark,paratitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_para where sysid='' and concat('parax',paramark) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz18=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'iconsetx',setmark,settitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_iconset where sysid='' and concat('iconsetx',setmark) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz19=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'sysx',sysid,sysname,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_sysinformation where sysid='' and concat('sysx',sysid) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz20=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'appx',appid,appname,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_appdefault where sysid='' and concat('appx',appid) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz21=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'layx',layid,laytitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_applay where sysid='' and concat('layx',layid) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz22=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'csspagex',faceid,facetitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_facelist where sysid='' and concat('csspagex',faceid) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz23=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'databasex',dbmark,dbtitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_dblist where sysid='' and concat('databasex',dbmark) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz24=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'afunx',funname,funcname,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_affairfunlist where sysid='' and concat('afunx',funname) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz25=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'apix',apicode,apititle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_apipool where sysid='' and concat('apix',apicode) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zz26=UX("insert into coode_sysnoreg(grpid,restype,resmark,restitle,CRTOR,CRTM,UPTM,VRT,OLMK,PRIME,vermd5)select sysid,'smallcssx',elemark,eletitle,CRTOR,CRTM,UPTM,VRT,md5(RAND()),PRIME,vermd5 from coode_tinyhtml where sysid='' and concat('smallcssx',elemark) not in(select concat(restype,resmark) from coode_sysnoreg)");
  $zzz=UX("update coode_sysnoreg,coode_tablist set coode_sysnoreg.vermd5=coode_tablist.vermd5,coode_sysnoreg.restitle=coode_tablist.tabtitle where coode_sysnoreg.resmark=coode_tablist.TABLE_NAME");
  $zzz=UX("update coode_sysnoreg,coode_tiny set coode_sysnoreg.vermd5=coode_domainunit.vermd5,coode_sysnoreg.restitle=coode_domainunit.unittitle where coode_sysnoreg.resmark=coode_domainunit.dumark");
  $ss=UX("update coode_sysnoreg,coode_sysrestypedefine set coode_sysnoreg.headpic=coode_sysrestypedefine.headpic,coode_sysnoreg.issys=coode_sysrestypedefine.numx,coode_sysnoreg.midpic=coode_sysrestypedefine.midpic where  coode_sysnoreg.restype=coode_sysrestypedefine.restypecode");
  $kkk=UX("delete from coode_keydetaily where shortid not in(select shortid from coode_shortdata)");
  $kkk=UX("delete from coode_shortcss where shortid not in(select shortid from coode_shortdata)");
  $kkk=UX("delete from coode_unittiny where tinyid not in(select tinymark from coode_tiny)");
  $kkk=UX("delete from coode_keydetailx where TABLE_NAME not in(select TABLE_NAME from coode_tablist)");
  $zzz=UX("update coode_sysnoreg set CRTOR='".$_COOKIE["uid"]."'");
  $b=time();
echo makereturnjson("1","成功".($b-$a)."秒","");
       session_write_close();
?>