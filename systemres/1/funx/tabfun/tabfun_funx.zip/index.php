<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      $tabnm=$_GET["tabnm"];
 $allrst=SX("select bfist,aftist,bfupd,aftupd,bfdel,aftdel from coode_keydetailx where concat(bfist,aftist,bfupd,aftupd,bfdel,aftdel)<>'' and TABLE_NAME='".$tabnm."'");
 $totrst=countresult($allrst);
 $fmfull="";
 for ($i=0;$i<$totrst;$i++){
   $fmfull=$fmfull.tostring(anyvalue($allrst,"bfist",$i)).tostring(anyvalue($allrst,"aftist",$i)).tostring(anyvalue($allrst,"bfupd",$i)).tostring(anyvalue($allrst,"aftupd",$i)).tostring(anyvalue($allrst,"bfdel",$i)).tostring(anyvalue($allrst,"aftdel",$i));
 };
 $ffull=$fmfull;
 $ffull=str_replace("'","",$ffull);
 if ($ffull!=""){
  $tabrst=SX("select TABLE_NAME from coode_tablist where '".$ffull."' like concat('% ',TABLE_NAME,' %')");
  $tabrst=hou($tabrst,"#/#");
  $tabrst=str_replace("#-#",",",$tabrst);
  $tabrst=str_replace("#/#",",",$tabrst);
  $funrst=SX("select funname from coode_funist where '".$ffull."' like concat('%\"',replace(funname,'()',''),'\"%')");
  $funrst=hou($funrst,"#/#");
  $funrst=str_replace("#-#",",",$funrst);
  $funrst=str_replace("#/#",",",$funrst);
  $funrst=str_replace("()",",",$funrst);
  $clsrst=SX("select funname from coode_phpcls where '".$ffull."' like concat('%\"',replace(funname,'()',''),'\"%')");
  $clsrst=hou($clsrst,"#/#");
  $clsrst=str_replace("#-#",",",$clsrst);
  $clsrst=str_replace("#/#",",",$clsrst);
  $clsrst=str_replace("()",",",$clsrst);
  $x=UX("update coode_tablist set afffuns='".$funrst."',affclss='".$clsrst."',afftabs='".$tabrst."' where TABLE_NAME='".$tabnm."'");
 }
 echo "1";
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>