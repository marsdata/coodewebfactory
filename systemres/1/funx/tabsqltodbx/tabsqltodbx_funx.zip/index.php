<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     function tabsqltodbx($ucode,$sqltxt,$stype){
  $tabnm=str_replace(""," ",qian(hou($sqltxt,"CREATE TABLE"),"("));
  $sqlstr=hou($sqltxt,"(");
  $ptkey=explode(",",$sqlstr);
  $totpt=count($ptkey);
  $fmk="";
  for ($j=0;$j<$totpt;$j++){
   if (strpos("xxx".$ptkey[$j],"PRIMARY KEY")>0){    
   }else{
     if (strpos($ptkey[$j],"(")>0){
       $keyx=qian($ptkey[$j]," ");
       $ktype=qian(hou($ptkey[$j]," "),"(");
       $klen=qian(hou($ptkey[$j],"("),")");
     }else{
       $keyx=qian($ptkey[$j]," ");
       $ktype=qian(hou($ptkey[$j]," ")," ");
       $klen="0";
     }   
     if ($stype=="new"){
       $sqlx="upgcode,tabname,newkey,ndatatype,ndatalen,oldkey,odatatype,odatalen,CRTM,UPTM,OLMK";
       $sqly="'$ucode','$tabnm','$keyx','$ktype','$klen','','','',now(),now(),'".onlymark()."'";
       $zz=UX("insert into coode_tabupd(".$sqlx.")values(".$sqly.")");       
     }else{
       $zz=UX("update coode_tabupd set oldkey='".$keyx."',odatatype='".$ktype."',odatalen='".$klen."' where upgcode='$ucode' and newkey='$keyx'");
       $fmk=$fmk.$keyx.",";
     }
   }   
  }//for
  $fmk=killlaststr($fmk);
  if ($stype=="new"){
    $sqla="upgcode,tabname,newcrtsql,CRTM,UPTM,OLMK";
    $sqlb="'$ucode','$tabnm','$sqltxt',now(),now(),'".onlymark()."'";
    $cc=UX("insert into coode_tabuindex(".$sqla.")values(".$sqlb.")");
  }else{
    $cc=UX("update coode_tabupd set oldkeys='".$fmk."|".$fmk."' where upgcode='$ucode'");
  }
  
 }
 $stxt="CREATE TABLE coode_plotmylist (SNO int(11) NOT NULL AUTO_INCREMENT,sysid varchar(20) NOT NULL,appid varchar(20) NOT NULL,plotcrtor varchar(100) NOT NULL,plotmark varchar(100) NOT NULL,layoutid varchar(30) NOT NULL,CRTM datetime NOT NULL,levelcount int(11) NOT NULL,totpoint int(11) NOT NULL,markname varchar(30) NOT NULL,withfont varchar(1024) NOT NULL,defaultcss varchar(30) NOT NULL,formcode text NOT NULL,clickfun varchar(255) NOT NULL,CRTOR varchar(255) NOT NULL,mydescrib varchar(255) NOT NULL,prime int(11) NOT NULL,OLMK varchar(30) NOT NULL,PTOF varchar(30) NOT NULL,VRT varchar(255) NOT NULL,STATUS tinyint(4) NOT NULL,STCODE varchar(1024) NOT NULL,UPTM datetime NOT NULL,RIP varchar(255) NOT NULL,PRIMARY KEY (SNO)) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;";
 $bb=tabsqltodbx("hwocao",$stxt,"new");
 echo "--aaa";
     session_write_close();
?>