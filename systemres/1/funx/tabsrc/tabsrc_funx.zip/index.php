<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     function tabsrc($fbs,$tbnmx,$tbttx){  
  if ($fbs==""){
    $fbs=glb();
  }
  if ($tbnmx!=""  and $tbnmx!="undefined"){
   $tbcrt=UX("select createsql as result from coode_tablist where TABLE_NAME='".$tbnmx."' and schm='".$fbs."'");
   $sametsrc=UX("update coode_pagefuntab set sdata='".$tbcrt."' where sourcecls='tab' and sourceid='".$tbnmx."'");
   $xn=UX("insert into coode_tabsrc(srctype,srcmark,srctitle,tablename,srctext,STCODE,VRT,RIP,schm,CRTM,UPTM,CRTOR,OLMK)values('crtsql','".$tbnmx."crt','".$tbttx."创建代码','".$tbnmx."','".$tbcrt."','','','".getip()."','".$fbs."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."')");
    $zz=UX("update coode_tabsrc set srctext='".$tbcrt."' where srctype='crtsql' and srcmark='".$tbnmx."crt'");
  $strst=SX("select shortid,shorttitle,showkeys from coode_shortdata where tablename='".$tbnmx."'");
  $totst=countresult($strst);
  for ($i=0;$i<$totst;$i++){
    $xm=UX("insert into coode_tabsrc(srctype,srcmark,srctitle,tablename,srctext,STCODE,VRT,RIP,schm,CRTM,UPTM,CRTOR,OLMK)values('short','".anyvalue($strst,"shortid",$i)."','".anyvalue($strst,"shorttitle",$i)."表单','".$tbnmx."','".anyvalue($strst,"showkeys",$i)."','','','".getip()."','".$fbs."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."')");   
    $xn=UX("insert into coode_tabsrc(srctype,srcmark,srctitle,tablename,srctext,STCODE,VRT,RIP,schm,CRTM,UPTM,CRTOR,OLMK)values('subtable','".anyvalue($strst,"shortid",$i)."','".anyvalue($strst,"shorttitle",$i)."表单副表','".$tbnmx."','".anyvalue($strst,"showkeys",$i)."','','','".getip()."','".$fbs."',now(),now(),'".$_COOKIE["uid"]."','".onlymark()."')");
  }
    //要 bak的数据  还有函数名称 响应函数，应该有很多资源
    return true;
  }else{
    return false;
  }
}
$tnm=_get("tablename");
$tbtt=UX("select tabtitle from coode_tablist where TABLE_NAME='".$tnm."' and schm='".glb()."'");
if ($tnm!="" and $tnm!="coode_databak"){
 $o=tabsrc(glb(),$tnm,$tbtt);
 $y=anyfunrun("tabfun","","tabnm=".$tnm,"");
 $z=anyfunrun("tabcol","","tablename=".$tnm,"");
 //$x=anyfunrun("tabisql","","tablename=".$tnm,"");//这个可以单独拿出来作为生成按钮
 //$x=anyfunrun("makeinsert","","tablename=".$tnm,"");目前看来这个操作不需要了创建install.js的文件
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>