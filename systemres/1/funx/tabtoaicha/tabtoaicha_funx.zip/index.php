<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $mtabnm=_get("mtabnm");
$btabnm=$mtabnm."_chara";
$tabsno=_get("tabsno");
$ctabnm=$mtabnm."_wrdresnmpoints";
$trst=SX("select SNO,restpcode,contentkeys,srckey,srcttk from coode_tablist where TABLE_NAME='".$mtabnm."'");
$totx=countresult($trst);
$aa=time();
if ($totx>0){
   $restpc=anyvalue($trst,"restpcode",0);
   $ckeys=anyvalue($trst,"contentkeys",0);
   $srck=anyvalue($trst,"srckey",0);
   $srct=anyvalue($trst,"srcttk",0);
   $typetitle=UX("select typetitlex as result from coode_wrdrestpdefine where typecodex='$restpc'");
   $drst=SX("select ".$srck.",".$srct." from ".$mtabnm." where SNO=".$tabsno);
   $totd=countresult($drst);
   if ($totd>0){
     $rcode=anyvalue($drst,$srck,0);
     $rtitle=anyvalue($drst,$srct,0);
     $rtitle=str_replace(" ","",$rtitle);
     $ttarr=mb_str_split($rtitle,1,"UTF-8");     
     $tota=count($ttarr);
     //$stcx=Array();
     //$stcx[0]="user:把“".$rtitle."”这个标题提出词语用逗号隔开";
     //$arrtxt=ebot($stcx);
     //$ttarr=explode("，",$arrtxt);     
     for ($a=0;$a<$tota-1;$a++){       
       if ($ttarr[$a]!=""){
         $extx=UZ("select count(*) as result from wrdresnmpoints where typecodex='".$restpc."' and rescode='".$rcode."' and nmstr='".$ttarr[$a].$ttarr[$a+1]."'");
         if (intval($extx)==0){        
          $sqlx="strnum,typecodex,typetitlex,rescode,restitle,nmstr,SQX,CRTM,UPTM,OLMK,STCODE";
          $sqly="'".$tota."','$restpc','$typetitle','$rcode','$rtitle','".$ttarr[$a].$ttarr[$a+1]."','$a',now(),now(),'".onlymark()."','".$mtabnm."'";
          $zz=UZ("insert into ".$ctabnm."(".$sqlx.")values(".$sqly.")");                
         }else{
          $nn=UZ("update ".$ctabnm." set UPTM=now(),typetitlex='$typetitle',strnum='".$tota."',STCODE='".$mtabnm."' where typecodex='".$restpc."' and rescode='".$rcode."' and nmstr='".$ttarr[$a].$ttarr[$a+1]."'");
         }
       }
     }
        $kttx=Array();
        $dkrst=SX("select SNO,COLUMN_NAME,keytitle from coode_keydetailx where TABLE_NAME='".$mtabnm."'");
        $totdk=countresult($dkrst);
        for ($kk=0;$kk<$totdk;$kk++){
          $kttx[anyvalue($dkrst,"COLUMN_NAME",$kk)]=anyvalue($dkrst,"keytitle",$kk);
        }
        $ptkey=explode(",",$ckeys);
        $totk=count($ptkey);
        $drst=SX("select ".$ckeys." from ".$mtabnm." where SNO=".$tabsno);
        for ($jj=0;$jj<$totk;$jj++){
          if ($ptkey[$jj]!=""){
           $ktty=$kttx[$ptkey[$jj]];
           $kval=anyvalue($drst,$ptkey[$jj],0);
           $exty=UZ("select count(*) as result from ".$btabnm." where typecodex='".$restpc."' and tabnm='".$mtabnm."' and tabkey='".$ptkey[$jj]."' and tabsno='".$tabsno."'");
            if (intval($exty)==0){
              if ($kval!=""){
               $sqla="typecodex,rescode,restitle,keytitle,keyval,tabnm,tabkey,tabsno,CRTM,UPTM,OLMK";
               $sqlb="'$restpc','$rcode','$rtitle','$ktty','$kval','$mtabnm','".$ptkey[$jj]."','".$tabsno."',now(),now(),'".onlymark()."'";
               $zz=UZ("insert into ".$btabnm."(".$sqla.")values(".$sqlb.")");
              }
            }else{
             $mm=UZ("update ".$btabnm." set restitle='".$rtitle."',keytitle='".$ktty."',keyval='".$kval."' where typecodex='".$restpc."' and tabnm='".$mtabnm."' and tabkey='".$ptkey[$jj]."' and tabsno='".$tabsno."'");             
            }
          }
        }
        
     $srst=SX("select SNO,TABLE_NAME,tabtitle,restpcode,contentkeys,parreskey,aitkey,aivkey from coode_tablist where restpcode='".$restpc."'");
     $tots=countresult($srst);
     if ($tots==1){
     }else{
       for ($zz=0;$zz<$tots;$zz++){        
        $tabttx=anyvalue($srst,"tabtitle",$zz);
        $tabnmx=anyvalue($srst,"TABLE_NAME",$zz);
        $ckeyx=anyvalue($srst,"contentkeys",$zz);
        $prkey=anyvalue($srst,"parreskey",$zz);
        $aitk=anyvalue($srst,"aitkey",$zz);
        $aivk=anyvalue($srst,"aivkey",$zz);
        if ($tabnmx!=$mtabnm and $rcode!=""){
           if ($aitk=="" or $aivk==""){
             $kttx=Array();
             $dkrst=SX("select SNO,COLUMN_NAME,keytitle from coode_keydetailx where TABLE_NAME='".$tabnmx."'");
             $totdk=countresult($dkrst);
             for ($kk=0;$kk<$totdk;$kk++){
               $kttx[anyvalue($dkrst,"COLUMN_NAME",$kk)]=anyvalue($dkrst,"keytitle",$kk);
             }
             $ptkey=explode(",",$ckeys);
             $totk=count($ptkey);             
             $drst=SX("select ".$ckeys." from ".$tabnmx." where ".$prkey."='".$rcode."'");
             $totdx=countresult($drst);
             for ($ii=0;$ii<$totdx;$ii++){
               for ($jj=0;$jj<$totk;$jj++){
                if ($ptkey[$jj]!=""){
                  $ktty=$kttx[$ptkey[$jj]];
                  $kval=anyvalue($drst,$ptkey[$jj],$ii);
                  $exty=UZ("select count(*) as result from ".$btabnm." where typecodex='".$restpc."' and tabnm='".$mtabnm."' and tabkey='".$ptkey[$jj]."' and tabsno='".$tabsno."'");
                  if (intval($exty)==0){
                   if ($kval!=""){
                     $sqla="typecodex,rescode,restitle,keytitle,keyval,tabnm,tabkey,tabsno,CRTM,UPTM,OLMK";
                     $sqlb="'$restpc','$rcode','$rtitle','$ktty','$kval','$mtabnm','".$ptkey[$jj]."','".$tabsno."',now(),now(),'".onlymark()."'";
                     $zz=UZ("insert into ".$btabnm."(".$sqla.")values(".$sqlb.")");
                   }
                  }else{
                    $mm=UZ("update ".$btabnm." set restitle='".$rtitle."',keytitle='".$ktty."',keyval='".$kval."' where typecodex='".$restpc."' and tabnm='".$mtabnm."' and tabkey='".$ptkey[$jj]."' and tabsno='".$tabsno."'");             
                  }//ifintval
                 }//ifptk
                }//forjj
              }//forii
           }else{
           //ifaik
             $drst=SX("select SNO,".$aitkey.",".$aivkey." from ".$tabnmx." where ".$parreskey."='".$rcode."'");           
             $totd=countresult($drst);
             for ($jj=0;$jj<$totd;$jj++){           
               $snoz=anyvalue($drst,"SNO",$jj);
               $ktty=anyvalue($drst,$aitkey,$jj);
               $kval=anyvalue($drst,$aivkey,$jj);
               $exty=UZ("select count(*) as result from ".$btabnm." where typecodex='".$restpc."' and tabnm='".$tabnmx."' and tabkey='".$aitkey.".".$aivkey."' and tabsno='".$snoz."'");
               if (intval($exty)==0){
                if ($kval!=""){
                  $sqla="typecodex,rescode,restitle,keytitle,keyval,tabnm,tabkey,tabsno,CRTM,UPTM,OLMK";
                  $sqlb="'$restpc','$rcode','$rtitle','$ktty','$kval','$tabnmx','".$aitkey.".".$aivkey."','".$snoz."',now(),now(),'".onlymark()."'";
                  $zz=UZ("insert into ".$btabnm."(".$sqla.")values(".$sqlb.")");
                }
               }else{
                 $mm=UZ("update ".$btabnm." set restitle='".$rtitle."',keytitle='".$ktty."',keyval='".$kval."' where typecodex='".$restpc."' and tabnm='".$tabnmx."' and tabkey='".$aitkey.".".$aivkey."' and tabsno='".$snoz."'");
               }           
             }                      
           }//ifaik        
        }//if rcodenotempty
       }//fprzz
     }//iftots
   }//iftotx
   $bb=time();
   $zzz0=UZ("update ".$btabnm." set strnum=length(concat(keytitle,keyval))");
   $zzz=UX("update ".$mtabnm." set STATUS=1 where SNO=".$tabsno);
   echo makereturnjson("1","合成成功，耗时：".($bb-$aa)."秒","");
}else{
  echo makereturnjson("0","合成失败","");
}
     session_write_close();
?>