<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     require_once localroot()."/localxres/parax/baiduimgsearch/AipImageSearch.php";
  $aa=time();
  $restype=_get("restype");
  $apicode=_get("apicode");
  $tabnm=_get("tabnm");
  $tabkey=_get("tabkey");
  $tabsno=_get("tabsno");
  $trst=SX("select srckey,srcttk from coode_tablist where TABLE_NAME='".$tabnm."'");
  $srckey=anyvalue($trst,"srckey",0);
  $srcttk=anyvalue($trst,"srcttk",0);
if (es($apicode)*es($tabnm)*es($tabkey)*es($tabsno)*es($srckey)*es($srcttk)*es($restype)==1){  
  $bdtab=$tabnm."_bdrespic";
  $arst=SX("select appid,apikey,apival from coode_apipool where apicode='".$apicode."'");
  $appid=anyvalue($arst,"appid",0);
  $apikey=anyvalue($arst,"apikey",0);
  $apisecu=anyvalue($arst,"apival",0);
  $client=new AipImageSearch($appid,$apikey,$apisecu);
  $prst=SX("select ".$tabkey.",".$srckey.",".$srcttk.",CRTOR from ".$tabnm." where SNO=".$tabsno);
  $picpath=anyvalue($prst,$tabkey,0);
  if (strpos("xxx".$picpath,localroot())>0){
  }else{
    $picpath=combineurl(localroot(),$picpath);
  }
  $rescode=anyvalue($prst,$srckey,0);
  $restitle=anyvalue($prst,$srcttk,0);
  if ($picpath!="" and $rescode!="" and $restitle!="" and $apikey!="" and $apisecu!=""){
    
    $extx=UZ("select count(*) as result from ".$bdtab." where restype='".$restype."' and rescode='".$rescode."' and restitle='".$restitle."'");
    if (intval($extx)==0){
     $picurl=combineurl("/",str_replace(localroot(),"",$picpath));
     $brf='{"rescode":"'.$rescode.'","restitle":"'.$restitle.'","restype":"'.$restype.'"}';
     $opt["tags"]="87";          
     $bkhdadd=$client->similarAdd(file_get_contents($picpath), $brf, $opt);     
     $sqlx="tabnm,tabkey,tabsno,piclocal,picurl,rescode,restitle,bktxt,appid,restype,OLMK,CRTM,UPTM";
     $sqly="'$tabnm','$tabkey','$tabsno','$picpath','$picurl','$rescode','$restitle','".str_replace("\'","\\\'",json_encode($bkhdadd))."','$appid','$restype','".onlymark()."',now(),now()";
     $zz=UZ("insert into ".$bdtab."(".$sqlx.")values(".$sqly.")");
     $nn=UX("update ".$tabnm." set STATUS=1,UPTM=now() where SNO=".$tabsno);
     $bb=time();  
     $leftnum=UX("select count(*) as result from ".$tabnm." where STATUS=0");
     $zzz=UX("update coode_wrdrestpdefine set STCODE='".$leftnum."' where linemark='".$tabnm."'");
     echo makereturnjson("1","上传成功，耗时：".($bb-$aa)."秒","");  
    }else{
      echo makereturnjson("0","上传失败-已存在","");
    }
  }else{
    echo makereturnjson("0","上传失败--次参数不全","");
  }
}else{
  echo makereturnjson("0","上传失败--主参数不全","");
}
     session_write_close();
?>