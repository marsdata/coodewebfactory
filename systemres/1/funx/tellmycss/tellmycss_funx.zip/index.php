<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     eval(RESFUNSET("tabdataoprt"));
$fromhost=_get("myhost");
$clientcode=_get("clientcode");
$uid=_get("uid");
$resjson=_post("resjson");
$data=json_decode($resjson,false);
$vls=$data->vls;
$rtype=$data->rtype;
$rcode=$data->rcode;
$ver=$data->ver;
$totd=count($vls);
$tmp=0;
 for ($i=0;$i<$totd;$i++){
   $restype=$vls[$i]->restype;
   $rescode=$vls[$i]->rescode;   
   $restitle=$vls[$i]->restitle;
   $resurl=$vls[$i]->resurl;
   $resmd5=md5_file($resurl);   
    $downpath=combineurl("http://".glw(),"/remotexres/csspool/".$restype."/".str_replace(".","_",$rescode)."/".str_replace(".","_",$rescode).$clientcode."_".$restype.".zip");
    $savepath=combineurl(localroot(),"/remotexres/csspool/".$restype."/".str_replace(".","_",$rescode)."/".str_replace(".","_",$rescode).$clientcode."_".$restype.".zip");
    $zippath=combineurl(localroot(),"/remotexres/csspool/".$restype."/".str_replace(".","_",$rescode)."/".$clientcode."/");
    $visiturl="/remotexres/csspool/".$restype."/".str_replace(".","_",$rescode)."/".$clientcode."/index.html";
    $kd=downanyfile($resurl,$savepath);
    $zd=unzip($savepath,$zippath);
    if ($restype=="tempx"){
      $extx=UX("select count(*) as result from coode_domainunit where dumark='".$rescode."'");
      if (intval($extx)==0){
        $sqljfile=combineurl(localroot(),"/remotexres/csspool/".$restype."/".str_replace(".","_",$rescode)."/".$clientcode."/".str_replace(".","_",$rescode)."_".$restype."-resdata.json");
        $uu=takevaljson($sqljfile);
        $dlist=dirlist($zippath);
        for ($dd=0;$dd<count($dlist);$dd++){
         $newdirx=combineurl(localroot(),"/localxres/csspagex/".$dlist[$dd]."/");
         $frmdir=combineurl($zippath,"/".$dlist[$dd]."/");
         is_dir($newdirx) OR mkdir($newdirx, 0777, true); 
         $nff=copy_underdir($frmdir,$newdirx);
        }
      }else{
       $qndm=sysconfigval(gln(),"cloudstockhost");
       $qtxt=qnyup(garea(),$savepath);
       $qdata=json_decode($qtxt,false);
       if (intval($qdata->status)==1){
        $kf=unlink($savepath);
        $downpath=combineurl($qndm,"/remotexres/csspool/".$restype."/".str_replace(".","_",$rescode)."/".str_replace(".","_",$rescode).$clientcode."_".$restype.".zip");
       }      
      }
    }else{
      $qndm=sysconfigval(gln(),"cloudstockhost");
      $qtxt=qnyup(garea(),$savepath);
      $qdata=json_decode($qtxt,false);
      if (intval($qdata->status)==1){
        $kf=unlink($savepath);
        $downpath=combineurl($qndm,"/remotexres/csspool/".$restype."/".str_replace(".","_",$rescode)."/".str_replace(".","_",$rescode).$clientcode."_".$restype.".zip");
      }
    }
     $extver=UX("select count(*) as result from coode_csspool where restype='".$restype."' and rescode='".$rescode."' and clientcode='".$clientcode."'");
     if (intval($extver)==0){
      $sqlx="fromhost,clientcode,restype,rescode,vermd5,restitle,downurl,indexurl,CRTM,UPTM,OLMK,CRTOR,PRIME";
      $sqly="'".$fromhost."','".$clientcode."','".$restype."','".$rescode."','".$resmd5."','".$restitle."','".$downpath."','".$visiturl."',now(),now(),'".onlymark()."','".$uid."',1";
      $zz=UX("insert into coode_csspool(".$sqlx.")values(".$sqly.")");       
     }else{
      $zz=UX("update coode_csspool set UPTM=now(),vermd5='".$resmd5."' where restype='".$restype."' and rescode='".$rescode."' and clientcode='".$clientcode."'"); 
     }
    $tmp=$tmp+1;   
 }
 echo makereturnjson("1","成功上传-".$tmp."个资源","");
 
     session_write_close();
?>