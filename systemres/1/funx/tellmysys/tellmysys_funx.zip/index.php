<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
        if ($_SERVER['SERVER_PORT']=="80"){  
  $myhost=$_SERVER["HTTP_HOST"];
 }else{
  $myhost=$_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"];
 }
 $sysid=$_GET["sysid"];
 $srst=SX("select sysname,vermd5,faceimg,sysdetail from coode_sysinformation where sysid='".$sysid."'");
 $sysname=anyvalue($srst,"sysname",0);
 $vermd5=anyvalue($srst,"vermd5",0);
 $faceimg=anyvalue($srst,"faceimg",0);
 $detail=anyvalue($srst,"sysdetail",0);
 $urst=SX("select realname,vxpic from coode_userlist where userid='".$_COOKIE["uid"]."'");
 $rnm=anyvalue($urst,"realname",0);
 $vxpic=anyvalue($urst,"vxpic",0);
 $bktxt=anyfunrun("rcvhostsys",glm(),"sysid=".$sysid,"sysname=".$sysname."&rnm=".$rnm."&vxpic=".$vxpic."&myhost=".$myhost."&vermd5=".$vermd5."&faceimg=".$faceimg."&detail=".$detail);
 $bkjson=json_decode($bktxt,false);
 if (intval($bkjson->status)==1){
    echo makereturnjson("1","提交成功","");    
 }else{
    $zz=UX("update coode_sysinformation set STCODE='".($bkjson->msg)."' where sysid='".$sysid."'");
    echo makereturnjson("0","提交失败","");    
 }
       session_write_close();
?>