<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $siteurl=_post("siteurl");
$sitename=_post("sitename");
$srid=_post("srid");
$comid=_post("comid");
$extx=UX("select count(*) as result from coode_comuser where siteurl='".$siteurl."' ");
if (intval($extx)==0){
 $sqlx="comid,comname,siteurl,CRTM,UPTM,OLMK";
 $sqly="'$comid','$sitename','$siteurl',now(),now(),'".onlymark()."'";
 $zz=UX("insert into coode_comuser(".$sqlx.")values(".$sqly.")");
}else{
  $zz=UX("update coode_comuser set comid='$comid',comname='$sitename' where siteurl='$siteurl'");
}
$crst=SX("select SNO,siterid from coode_comuser where siteurl='$siteurl'");
$snox=anyvalue($crst,"SNO",0);
$osrid=anyvalue($crst,"siterid",0);
if ($srid==$osrid){
 echo makereturnjson("1","告知成功","");
}else{
 echo '{"status":"2","srid":"$osrid","redirect":""}';
}
     session_write_close();
?>