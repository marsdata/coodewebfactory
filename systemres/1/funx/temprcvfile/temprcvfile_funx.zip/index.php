<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
       $tempmark=dftval($_GET["tempmark"],"");
  $temptype=dftval($_GET["temptype"],""); 
  $tinymark=dftval($_GET["tinymark"],""); 
  $parid=dftval($_GET["parid"],""); 
  $olmk=dftval($_GET["olmk"],""); 
  $myid=dftval($_GET["myid"],""); 
  $conn=mysql_connect(gl(),glu(),glp());
  if (substr(str_replace("\\","/",$_SERVER['DOCUMENT_ROOT']),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER['DOCUMENT_ROOT'])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER['DOCUMENT_ROOT']);
  };
  if (strpos($gml,":")>0){
   $qdq=xqian($gml,":");
   $gml=strtoupper($qdq).":".xhou($gml,":");
  }
  $fkey="file";
  $tmpnm=$_FILES[$fkey]["tmp_name"];
  $fnm=$_FILES[$fkey]["name"];
  $fext=hou($fnm,".");
  $tmptp=$_FILES[$fkey]["type"];
  $tmperr=$_FILES[$fkey]["error"];
  
  if ($tinymark!=""){
    $trst=SX("select sysid,appid,layid from coode_tiny where tinymark='".$tinymark."'");
    $sysid=anyvalue($trst,"sysid",0);
    $appid=anyvalue($trst,"appid",0);
    $layid=anyvalue($trst,"layid",0);
    $yy=createdir($gml."SYS/".$sysid."/".$appid."/".$layid."/".$tinymark."/images");
    $rpt=$gml."SYS/".$sysid."/".$appid."/".$layid."/".$tinymark."/images/";  
  }else{
    $yy=createdir($gml."units/".qian($tempmark,".")."/images");
    $rpt=$gml."units/".qian($tempmark,".")."/images/";  
  }
  
   $fpn=$rpt.$olmk."-".$fnm;
   $url=combineurl("http://".glw(),str_replace($gml,"",$fpn));
   move_uploaded_file($tmpnm, $fpn);
   if ($myid=="" or $myid=="0"){
    $lastid=UX("select myid as result from coode_resjarset where tempmark='".$tempmark."' and temptype='".$temptype."' and tinymark='".$tinymark."' order by myid desc");
    $sqlx="temptype,tempmark,tinymark,restype,rmark,rtitle,reslocalurl,resrmturl,jsondata,myid,parid,CRTM,UPTM,OLMK";
    $sqly="'$temptype','$tempmark','$tinymark','$fext','$fnm','文件','$fpn','$url','','".($lastid+1)."','".$parid."',now(),now(),'".$olmk."'";
    $zz=UX("insert into coode_resjarset(".$sqlx.")values(".$sqly.")");
  }else{
    $zx=UX("update coode_resjarset set reslocalurl='".$fpn."',resrmturl='".$url."' where tempmark='".$tempmark."' and temptype='".$temptype."' and tinymark='".$tinymark."' and myid='".$myid."'");
  }
  echo '{"status":"1","msg":"上传成功","redirect":""}';
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>