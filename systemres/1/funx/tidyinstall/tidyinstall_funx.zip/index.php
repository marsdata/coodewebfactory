<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $sysid=$_GET["sysid"];
$a=time();
if ($sysid!=""){
$tprst=SX("select restypecode,relyotherres,restypetitle from coode_sysrestypedefine");
$totr=countresult($tprst);
for ($jj=0;$jj<$totr;$jj++){
  $rtype=anyvalue($tprst,"restypecode",$jj);
    $todir=combineurl(localroot(),"/systemres/".$sysid."/install/resjar/");
    $fdir1=combineurl(localroot(),"/systemres/0/".$rtype."/");
    $fdir2=combineurl(localroot(),"/systemres/1/".$rtype."/");
    $fdir3=combineurl(localroot(),"/systemres/".$sysid."/".$rtype."/");
    $zz1=copy_underdir($fdir1,$todir.$rtype."/");   
    $zz2=copy_underdir($fdir2,$todir.$rtype."/");   
    $zz3=copy_underdir($fdir3,$todir.$rtype."/");   
}
  $b=time();
  echo makereturnjson("1","整理成功-耗时".($b-$a)."秒","");
}else{
  echo makereturnjson("0","整理失败-缺少参数","");
}
       session_write_close();
?>