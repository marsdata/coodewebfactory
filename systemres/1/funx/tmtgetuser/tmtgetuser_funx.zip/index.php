<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $srd='{"data":[{inner}],"total":{tot}}';
$demo='{"id": {id},
"status": {status},
"grade": {grade},
"integral": "",
"number": {num},
"Headimg":"{headimg}",
"growthvalue":"",
"name": "{name}",
"nickname": "{nick}",
"sex": "{sex}",
"age": {age},
"province": "{pro}",
"city": "{city}",
"county": "{zone}",
"address": "{address}",
"password": "",
"phone": "{phone}",
"mobilephone": "{tel}",
"mailbox": "{email}",
"into": "",
"regtime": {regtime}
}';
$conn=mysql_connect("st.ab328.cn","st_ab328_cn","8Af3tcrfAcRrL7Hj");
$srst=selecteds($conn,"st_ab328_cn","select mid,rank,nickname,truename,litpic,sex,email,mobile,checkphone,jointime,address,province,city from sline_member order by checkphone","utf8","");
$totrst=countresult($srst);
$fmx="";
for ($i=0;$i<$totrst;$i++){
 $dmx=$demo;
 $dmx=str_replace("{id}",anyvalue($srst,"mid",$i),$dmx);
 $dmx=str_replace("{status}",anyvalue($srst,"checkphone",$i),$dmx);
 $dmx=str_replace("{grade}",anyvalue($srst,"rank",$i),$dmx);
 $dmx=str_replace("{name}",anyvalue($srst,"nickname",$i),$dmx);
 $dmx=str_replace("{nick}",anyvalue($srst,"nickname",$i),$dmx);
 $dmx=str_replace("{sex}",anyvalue($srst,"sex",$i),$dmx);
 $dmx=str_replace("{headimg}",anyvalue($srst,"litpic",$i),$dmx);
 $dmx=str_replace("{age}","18",$dmx);
 $dmx=str_replace("{num}",$i,$dmx);
 $dmx=str_replace("{phone}","",$dmx);
 $dmx=str_replace("{tel}",anyvalue($srst,"mobile",$i),$dmx);
 $dmx=str_replace("{email}",anyvalue($srst,"email",$i),$dmx);
 $dmx=str_replace("{regtime}",anyvalue($srst,"jointime",$i),$dmx);
 $dmx=str_replace("{address}",anyvalue($srst,"address",$i),$dmx);
 $dmx=str_replace("{pro}",anyvalue($srst,"province",$i),$dmx);
 $dmx=str_replace("{city}",anyvalue($srst,"city",$i),$dmx);
 $dmx=str_replace("{zone}","",$dmx);
 $fmx=$fmx.$dmx.",";
}
 $fmx=killlaststr($fmx);
 $fmx=str_replace("保密","0",$fmx);
 $srd=str_replace("{tot}",$totrst,$srd);
 $srd=str_replace("{inner}",$fmx,$srd);
 echo $srd;
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>