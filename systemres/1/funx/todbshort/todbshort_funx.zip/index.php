<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snox=_get("snox");
$odrst=SX("select shortid,shorttitle from coode_shortdata where SNO=".$snox);
$shortid=anyvalue($odrst,"shortid",0);
$extx=UX("select count(*) as result from coode_dbshort where catalog='thishostbusiness' and shortid='".$shortid."'");
if (intval($extx)==0){
  $sqlx="catalog,schm,shortid,shorttitle,caseid,detailid,tablename,allkeys,showkeys,cdt,orddt,dttp,CRTM,UPTM,OLMK";
  $sqly="'thishostbusiness',schm,shortid,shorttitle,caseid,detailid,tablename,allkeys,showkeys,cdt,orddt,dttp,now(),now(),RAND()*100000";
  $zz=UX("insert into coode_dbshort(".$sqlx.")select ".$sqly." from coode_shortdata where SNO=".$snox);
  echo makereturnjson("1","生成成功","0");
}else{
  echo makereturnjson("1","生成失败","0");
}
     session_write_close();
?>