<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sno=$_GET["SNO"];
$trst=SX("select sysid,appid,layid,tinymark,tinytitle,shortid,laypath,longexp from coode_tiny where SNO=".$sno);
$sysid=anyvalue($trst,"sysid",0);
$appid=anyvalue($trst,"appid",0);
$layid=anyvalue($trst,"layid",0);
$tinyid=anyvalue($trst,"tinymark",0);
$tinytitle=anyvalue($trst,"tinytitle",0);
$shortid=anyvalue($trst,"shortid",0);
$laypath=anyvalue($trst,"laypath",0);
$longexp=anyvalue($trst,"longexp",0);
if ($laypath!=""){
  if ($shortid!=""){
    $idrst=SX("select caseid,detailid from coode_shortdata where shortid='".$shortid."'");
    $caseid=anyvalue($idrst,"caseid",0);
    $detailid=anyvalue($idrst,"detailid",0);
    if (strpos($longexp,"anyjsshort")>0){
      $tmpid=$caseid; 
    }else{
      $tmpid=$detailid;
    }   
  }else{
   $tmpid=$tempid;   
  }
   $mark=hou($tmpid,".");
   $extx=UX("select count(*) as result from coode_domainunit where dumark='".$tinyid.".".$mark."'");  
   if (intval($extx)>0){
    $z=UX("delete  from coode_domainunit where dumark='".$tinyid.".".$mark."'");  
   }
   $fpath=combineurl(localroot(),"/SYS/".$sysid."/".$appid."/".$layid."/".$tinyid);
   $ftopath=combineurl(localroot(),"/units/".$tinyid);
   is_dir($ftopath) OR mkdir($ftopath, 0777, true);
   copy_dir($fpath,$ftopath);
   $sql0="sysid,appid,unitclass,unitmark,unitdescrib,pagehtml,vermd5,industry,business,matter,casecode,cssfilex,stylex,jsfilex,scriptx,cssfiley,styley,jsfiley,scripty,containsub,width,height,inwidth,inheight,templatecode,demoresult,pagesurround,subvermd5,copyrightmark,CRTM,UPTM"; 
   $z=UX("insert into coode_domainunit(".$sql0.",domainmark,dumark,outurl,unittitle)select ".$sql0.",'".$tinyid."','".$tinyid.".".$mark."','/units/".$tinyid."/".$mark.".html','".$tinytitle."' from coode_unittiny where tinyid='".$tinyid."' ");    
   echo "1";
}else{
  echo "0";
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>