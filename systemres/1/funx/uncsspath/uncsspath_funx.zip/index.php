<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $faceid=$_GET["faceid"];
$ddd="/localxres/csspagex";
$dir = combineurl(localroot(),$ddd);  //要获取的目录
$k=0;
$a=time();
$ffile=combineurl($dir."/",$faceid."/index.html");
$notyy=$_GET["notyy"];
$kkk=UX("update coode_facelist set STATUS=1,UPTM=now() where faceid='".$faceid."'");
$ttt=UX("select PRIME as result from coode_facelist  where faceid='".$faceid."'");
if ($faceid!=""){
 if ($notyy==""){
  if (file_exists($ffile) or intval($ttt)>0){
   $dtxt=file_get_contents($ffile);
   $titlex=qian(hou($dtxt,"title>"),"</title");
   if (strlen($titlex)<50){
    $kkk=UX("update coode_facelist set facetitle='".$titlex."' where faceid='".$faceid."' and (facetitle like '/localxres/%' or facetitle='')");
   }   
   echo makereturnjson("1","分析成功--耗时".($b-$a)."无需删除","");
  }else{
    $kk=deltree($dir."/".$faceid."/");
    $kkk=UX("delete from coode_facelist where faceid='".$faceid."'");
    $b=time();
    echo makereturnjson("1","分析成功--耗时".($b-$a)."已删除","");
  }
 }else{
    $kk=deltree($dir."/".$faceid."/");
    $kkk=UX("delete from coode_facelist where faceid='".$faceid."'");
    $b=time();
    echo makereturnjson("1","分析成功--耗时".($b-$a)."已删除","");
 }
}else{
  echo makereturnjson("0","分析失败--耗时".($b-$a)."参数不全","");
}
 
       session_write_close();
?>