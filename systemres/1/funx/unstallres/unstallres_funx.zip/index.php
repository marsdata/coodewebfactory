<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $restype=_get("restype");
$rescode=_get("rescode");
$resmark=$rescode;
$sysidx=_get("sysid");
$insmark=_get("insmark");
switch($restype){
  case "tempx":
  $ffile=combineurl(localroot(),"/systemres/".$sysidx."/tempx/".qian($resmark,".")."/".qian($resmark,".")."_tempx.zip");
  $uu=UX("update coode_domainunit set sysid='1' where dumark='".$rescode."'");
  if (file_exists($ffile)){
   unlink($ffile);
  }
  break;
  case "csspagex":
  $ffile=combineurl(localroot(),"/systemres/".$sysid."/csspagex/".$resmark."/".$resmark."_csspagex.zip");
  $uu=UX("update coode_facelist set sysid='1' where faceid='".$rescode."'");
  if (file_exists($ffile)){
   unlink($ffile);
  }
  break;
  case "tabx":
  //$spath=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/");
  //$kk0=UX("delete from coode_keydetailx where TABLE_NAME='".$rescode."'");
  //$kk1=UX("delete from coode_keydetaily where TABLE_NAME='".$rescode."'");
  //$kk2=UX("delete from coode_keydetailz where TABLE_NAME='".$rescode."'");
  //$kk3=UX("delete from coode_tablist where TABLE_NAME='".$rescode."'");
  //$kk4=UX("delete from coode_shordata where tablename='".$rescode."'");
  //$kk5=UX("delete from coode_shortcss where tablename='".$rescode."'");
  //$kk6=UX("delete from coode_tiny where tablename='".$rescode."'");
  //$conn=mysql_connect(gl(),glu(),glp());
  //$dd=updatingx($conn,glb(),"DROP TABLE IF EXISTS ".$rescode,"utf8");
  //$kk7=deltree($spath);
  //$ffile=combineurl(localroot(),"/systemres/".$sysidx."/".$restype."/".qian($resmark,".")."/".qian($resmark,".")."_".$restype.".zip");
  //if (file_exists($ffile)){
  // unlink($ffile);
  //}
  //表格应该有个专门清理，防止误删
  break;
  case "plotx":
  $spath=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/");
  $kk0=UX("delete from coode_plotdetail where plotmark='".$rescode."'");
  $kk1=UX("delete from coode_plotdekill where plotmark='".$rescode."'");
  $kk2=UX("delete from coode_plotlist where plotmark='".$rescode."'");
  $kk3=UX("delete from coode_plotmydetail where plotmark='".$rescode."'");
  $kk7=deltree($spath);
  $ffile=combineurl(localroot(),"/systemres/".$sysidx."/".$restype."/".qian($resmark,".")."/".qian($resmark,".")."_".$restype.".zip");
  if (file_exists($ffile)){
   unlink($ffile);
  }
  break;
  case "groupx":
  $spath=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/");
  $kk0=UX("delete from coode_grpclass where clsmark='".$rescode."'");
  $kk1=UX("delete from coode_grouplist where plotmark='".$rescode."'");
  $kk7=deltree($spath);
  $ffile=combineurl(localroot(),"/systemres/".$sysidx."/".$restype."/".qian($resmark,".")."/".qian($resmark,".")."_".$restype.".zip");
  if (file_exists($ffile)){
   unlink($ffile);
  }
  break;
  case "formx":
  $spath=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/");
  $kk0=UX("delete from coode_shortcss where shortid='".$rescode."'");
  $kk1=UX("delete from coode_shortdata where shortid='".$rescode."'");
  $kk2=UX("delete from coode_keydetaily where shortid='".$rescode."'");
  $kk7=deltree($spath);
  $ffile=combineurl(localroot(),"/systemres/".$sysidx."/".$restype."/".qian($resmark,".")."/".qian($resmark,".")."_".$restype.".zip");
  if (file_exists($ffile)){
   unlink($ffile);
  }
  break;
  case "dataspacex":
  $spath=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/");
  $kk0=UX("delete from coode_dspckey where datamark='".$rescode."'");
  $kk1=UX("delete from coode_dspckeyx where datamark='".$rescode."'");
  $kk2=UX("delete from coode_dspckeyy where datamark='".$rescode."'");
  $kk3=UX("delete from coode_dspckeyz where datamark='".$rescode."'");
  $kk4=UX("delete from coode_dataspace where datamark='".$rescode."'");
  $kk5=UX("delete from coode_dspcstock where datamark='".$rescode."'");
  $kk6=UX("delete from coode_dspcval where datamark='".$rescode."'");
  $kk7=UX("delete from coode_dspcindex where datamark='".$rescode."'");
  $kk8=UX("delete from coode_dsshort where datamark='".$rescode."'");
  $kk7=deltree($spath);
  $ffile=combineurl(localroot(),"/systemres/".$sysidx."/".$restype."/".qian($resmark,".")."/".qian($resmark,".")."_".$restype.".zip");
  if (file_exists($ffile)){
   unlink($ffile);
  }
  break;
  case "cdtrdrx":
  $spath=combineurl(localroot(),"/localxres/".$restype."/".qian($rescode,".")."/");
  $kk0=UX("delete from coode_cdtrdr where concat(cdtmark,'.',cdtval)='".$rescode."'");
  $kk7=deltree($spath);
  $ffile=combineurl(localroot(),"/systemres/".$sysidx."/cdtrdrx/".qian($resmark,".")."/".qian($resmark,".")."_cdtrdrx.zip");
  if (file_exists($ffile)){
   unlink($ffile);
  }
  break;
  case "pagex":
  $tnrst=SX("select sysid,appid,layid,tempid from coode_tiny where tinymark='".$rescode."'");
  $sysid=anyvalue($tnrst,"sysid",0);
  $appid=anyvalue($tnrst,"appid",0);
  $layid=anyvalue($tnrst,"layid",0);
  $tempid=anyvalue($tnrst,"tempid",0);
  $spath1=combineurl(localroot(),"/localxres/pagex/".qian($tempid,".")."/".$rescode."/");
  $kk7=deltree($spath1);
  $spath2=combineurl(localroot(),"/localxres/pagex/seedx/".$rescode."/");
  $kk8=deltree($spath2);
  $ffile=combineurl(localroot(),"/systemres/".$sysidx."/pagex/".$resmark."/".$resmark."_pagex.zip");
  if (file_exists($ffile)){
   unlink($ffile);
  }
  $kk9=UX("delete from coode_tiny where tinymark='".$rescode."'");
  $kk10=UX("delete from coode_unittiny where tinyid='".$rescode."'");
  break;
  default:  
   $spath=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/");
   $tprst=SX("select relyotherres,restypetitle from coode_sysrestypedefine where restypecode='".$restype."'");
   $rlres=anyvalue($tprst,"relyotherres",0);
   $tabnm=qian($rlres,".");
   $tabkey=hou($rlres,".");
   $kk=UX("delete from ".$tabnm." where ".$tabkey."='".str_replace("()","",$rescode)."' or ".$tabkey."='".str_replace("()","",$rescode)."()'");
   $kk7=deltree($spath);
  $ffile=combineurl(localroot(),"/systemres/".$sysidx."/".$restype."/".qian($resmark,".")."/".qian($resmark,".")."_".$restype.".zip");
  if (file_exists($ffile)){
   unlink($ffile);
  }
}
 if ($insmark!=""){
    $kk99=UX("delete from coode_sysregres where resmark='".$rescode."' and restype='".$restype."'");
    $zz00=UX("update coode_hostregres set thisver='' where  resmark='".$rescode."' and restype='".$restype."'");
    $zz=UX("update coode_installdetail set STATUS=1 where insmark='".$insmark."' and rescode='".$rescode."' and restype='".$restype."'");
    $zz=UX("update coode_installidx set succnum=succnum+1 where insmark='".$insmark."'");
 }
echo makereturnjson("1","卸载成功","");
       session_write_close();
?>