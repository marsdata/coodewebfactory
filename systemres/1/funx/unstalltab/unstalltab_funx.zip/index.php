<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
       $rescode=$_GET["tabnm"];
  if ($rescode!=""){
   $restype="tabx";
   $sysidx=UX("select sysid as result from coode_tablist where TABLE_NAME='".$rescode."'");
   $spath=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/");
   $kk0=UX("delete from ".$rescode." ");
   $kk0=UX("delete from coode_keydetailx where TABLE_NAME='".$rescode."'");
   $kk1=UX("delete from coode_keydetaily where TABLE_NAME='".$rescode."'");
   $kk2=UX("delete from coode_keydetailz where TABLE_NAME='".$rescode."'");
   $kk3=UX("delete from coode_tablist where TABLE_NAME='".$rescode."'");
   $kk4=UX("delete from coode_shordata where tablename='".$rescode."'");
   $kk5=UX("delete from coode_shortcss where tablename='".$rescode."'");
   $kk6=UX("delete from coode_tiny where tablename='".$rescode."'");
   $conn=mysql_connect(gl(),glu(),glp());
   $dd=updatingx($conn,glb(),"DROP TABLE IF EXISTS ".$rescode,"utf8");
   $kk7=deltree($spath);
   if ($sysidx!=""){
    $ffile=combineurl(localroot(),"/systemres/".$sysidx."/".$restype."/".$rescode."/".$rescode."_".$restype.".zip");
     if (file_exists($ffile)){
      unlink($ffile);
     }
   }
   echo makereturnjson("1","卸载完成","");
  }else{
   echo makereturnjson("0","卸载失败","");
  }
     session_write_close();
?>