<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $para=_get("para");
if ($para==""){
  $qrykey=_get("qrykey");
  $mtdpara=_get("mtdpara");
  $kzm=kuozhanming($mtdpara);
  echo '{"status":"1","mtdtitle":"解压:'.$mtdpara.'到","mtdpara":"'.str_replace(".".$kzm,"",$mtdpara).'"}';
}else{
  $mtdpara=_get("mtdpara"); 
  $zz=unzip($mtdpara,$para);
  echo '{"status":"1","msg":"解压:'.$mtdpara.'成功","mtdpara":"'.$mtdpara.'","vls":[]}';
}
     session_write_close();
?>