<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $filepath=$_GET["filepath"];
$tbnm=$_GET["tbnm"];
$sno=$_GET["sno"];
$tbkey=$_GET["tbkey"];
if ($filepath=="" or $filepath=="un"."defined"){
 $filepath=UX("select ".$tbkey." as result from ".$tbnm." where SNO=".$sno);
}
$conn=mysql_connect(gl(),glu(),glp());
 if (substr(str_replace("\\","/",$_SERVER['DOCUMENT_ROOT']),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER['DOCUMENT_ROOT'])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER['DOCUMENT_ROOT']);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
 }
  $tmpnm=$_FILES["file_data"]["tmp_name"];
  $fnm=$_FILES["file_data"]["name"];
  $fext=hou($fnm,".");
  $tmptp=$_FILES["file_data"]["type"];
  $tmperr=$_FILES["file_data"]["error"];
  $extf="/.php,.jpg,.gif,.png,.bmp,.svg,.zip,.rar,.pdf,.doc,.xls,.js,.css,.woff,.html,.htm,.json,.docx,.xlsx,.mp3,.mp4,.avi,.jpeg,.txt,.asp,";
  $acc=0;
 if (strpos($filepath,".")>0){
   $ptexf=explode(".",$filepath);      
   $totpte=count($ptexf);
   $exex=$ptexf[$totpte-1];
   if (strpos($extf,".".$exex.",")>0){
       $acc=1;
   }
 }else{
  $acc=0;    
 }
if ($_COOKIE["uid"]!=""  and $acc=1){
 if ($filepath!=""){  
   $fpn=combineurl($gml,$filepath);  
   move_uploaded_file($tmpnm, $fpn);  
   echo "{status:\"true\",msg:\"更改成功\"}";
 }else{
   if ($tbnm!="" and $tbnm!="un"."defined" and intval($sno)>0 ){
    $omk=onlymark();
    $rpt=$gml."ORG/BRAIN/files/".$tbnm."/";
    $fpn=$rpt.$tbnm.$tbkey.$omk."-".$fnm;
    move_uploaded_file($tmpnm, $fpn);  
    $x=UX("update ".$tbnm." set ".$tbkey."='".$fpn."' where SNO=".$sno);
    echo "{\"status\":\"true\",\"msg\":\"新增成功\"}";
   }else{
    echo "{\"status\":\"error\",\"msg\":\"信息不完全，提交失败\"}";
   }
 };
}else{
   echo "{\"status\":\"error\",\"msg\":\"非法请求，提交失败\"}";
}
     session_write_close();
function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
}
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
}
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
 $astrlen=strpos($fullstr,$astr);
 $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
 }else{
  return $fullstr;
 }
}
function xhou($fullstr,$astr){
//完美兼容中文混合
$cunzaibu=strpos("x".$fullstr,$astr);
if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}?>