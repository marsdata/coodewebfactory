<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $sno=_get("SNO");
eval(RESFUNSET("resnmtomother"));
$frst=SX("select sysid,shortid,showkeys from coode_shortdata where SNO=".$sno);
$totf=countresult($frst);
if (intval($totf)>0){
    $fn=anyvalue($frst,"shortid",0);
    $sysid=anyvalue($frst,"sysid",0);
    $shortid=anyvalue($frst,"shortid",0);    
    $zk=anyfunrun("savetoseed","","sysid="=$sysid."&restype=formx&resmark=".$shortid,"");    
    $zp=anyfunrun("uprestoqny","","only=1&sysid=".$sysid."&restype=formx&rescode=".$shortid,"");    
    $x=UX("update coode_shortdata set OPRT='',STATUS=0 where SNO=".$sno);        
    echo makereturnjson("1","升级成功","");
}else{
    echo makereturnjson("0","升级失败","");
}
       session_write_close();
?>