<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     eval(RESFUNSET("tabdataoprt"));
    $fromhost=_get("fromhost");
    $restype=_get("restype");
    $rescode=_get("rescode");
    
 if ($fromhost!="" and $restype!="" and $rescode!="" and $fromhost."/"!=glw()){
   if (strpos($fromhost,":")>0){
    $dkh=hou($fromhost,":");
   }else{
    $dkh="";
   }
   if ($dkh=="443"){
     $reshost="https://".qian($fromhost,":");
   }else{
     $reshost="http://".$fromhost;
   }
   switch($restype){
     case "pagex":
      $resurl=combineurl($reshost,"/localxres/pagex/seedx/".$rescode."/".$rescode."_pagex.zip");      
      $respath=combineurl(localroot(),"/localxres/pagex/seedx/".$rescode."/".$rescode."_pagex.zip");      
      $sqlmd5=md5_file($resurl);
      $newurl=combineurl(localroot(),"/localxres/seedx/pagex/".$rescode."/".$sqlmd5.$rescode."_pagex.zip");
      $newpath=combineurl(localroot(),"/localxres/seedx/pagex/".$rescode."/".$sqlmd5."/");
      $trst=SX("select sysid,appid,layid from coode_tiny where tinymark='".$rescode."'");
      $totx=countresult($trst);
      $sysid=anyvalue($trst,"sysid",0);
      $appid=anyvalue($trst,"appid",0);
      $layid=anyvalue($trst,"layid",0);
      if ($totx>0){
        $tarpath=combineurl(localroot(),"/localxres/pagex/".$sysid."/".$appid."/".$layid."/".$rescode."/"); 
      }else{
        $tarpath="";
      }
     break;
     case "tempx":
      $resurl=combineurl($reshost,"/localxres/tempx/".qian($rescode,".")."/".qian($rescode,".")."_tempx.zip");
      $respath=combineurl(localroot(),"/localxres/tempx/".qian($rescode,".")."/".qian($rescode,".")."_tempx.zip");
      $sqlmd5=md5_file($resurl);
      $newurl=combineurl(localroot(),"/localxres/seedx/tempx/".qian($rescode,".")."/".$sqlmd5.str_replace(".","_",$rescode)."_tempx.zip");
      $newpath=combineurl(localroot(),"/localxres/seedx/tempx/".qian($rescode,".")."/".$sqlmd5."/");
      $tarpath=combineurl(localroot(),"/localxres/tempx/".qian($rescode,".")."/"); 
     break;
     case "cdtrdrx":
      $resurl=combineurl($reshost,"/localxres/cdtrdrx/".qian($rescode,".")."/".qian($rescode,".")."_cdtrdrx.zip");
      $respath=combineurl(localroot(),"/localxres/cdtrdrx/".qian($rescode,".")."/".qian($rescode,".")."_cdtrdrx.zip");
      $sqlmd5=md5_file($resurl);
      $newurl=combineurl(localroot(),"/localxres/seedx/cdtrdrx/".qian($rescode,".")."/".$sqlmd5.str_replace(".","_",$rescode)."_cdtrdrx.zip");
      $newpath=combineurl(localroot(),"/localxres/seedx/cdtrdrx/".qian($rescode,".")."/".$sqlmd5."/");
      $tarpath=combineurl(localroot(),"/localxres/cdtrdrx/".qian($rescode,".")."/"); 
     break;
     default:
      $resurl=combineurl($reshost,"/localxres/".$restype."/".str_replace(".","_",$rescode)."/".str_replace(".","_",$rescode)."_".$restype.".zip");
      $respath=combineurl(localroot(),"/localxres/".$restype."/".str_replace(".","_",$rescode)."/".str_replace(".","_",$rescode)."_".$restype.".zip");
      $sqlmd5=md5_file($resurl);
      $newurl=combineurl(localroot(),"/localxres/seedx/".$restype."/".str_replace(".","_",$rescode)."/".$sqlmd5.str_replace(".","_",$rescode)."_".$restype.".zip");
      $newpath=combineurl(localroot(),"/localxres/seedx/".$restype."/".str_replace(".","_",$rescode)."/".$sqlmd5."/");
      $tarpath=combineurl(localroot(),"/localxres/".$restype."/".str_replace(".","_",$rescode)."/"); 
   }
    if (downanyfile($resurl,$newurl)){
        $dd=downanyfile($resurl,$respath);
        $thismd5=md5_file($respath);
        $zz=UX("update coode_sysregres set UPTM=now(),vermd5='".$thismd5."' where resmark='".$rescode."' and restype='".$restype."'");
        $zz=UX("update coode_hostregres set UPTM=now(),thisver='".$thismd5."' where resmark='".$rescode."' and restype='".$restype."'");
        $zz=unzip($newurl,$newpath);
        //unlink($newurl);
    }else{
      $err="下载资源失败；";
      $tarpath="";
    }
    if ($tarpath!=""){     
     $zz=copy_underdir($newpath,$tarpath);
     switch($restype){
       case "pagex":
         $jsonf0=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$rescode."_".$restype."-resdata.json");
         $uu=takevaljson($jsonf0);
         $jsonf1=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$rescode."_".$restype."-pagedata.json");
         $uu=takevaljson($jsonf1);
       break;
       case "tabx":
       $relyresurl=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $vls=$relydata->vls;
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$jsonf.".json"); 
         $uu=takevaljson($jsonf);
       }
       break;
       case "formx":
       $relyresurl=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $vls=$relydata->vls;
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$jsonf.".json"); 
         $uu=takevaljson($jsonf);
       }
       break;
       case "plotx":
       $relyresurl=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $vls=$relydata->vls;
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$jsonf.".json"); 
         $uu=takevaljson($jsonf);
       }
       break;
       case "groupx":
       $relyresurl=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $vls=$relydata->vls;
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$jsonf.".json"); 
         $uu=takevaljson($jsonf);
       }
       break;
       case "dataspacex":
       $relyresurl=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $vls=$relydata->vls;
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$jsonf.".json"); 
         $uu=takevaljson($jsonf);
       }
       break;
       default:
         $jsonf=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$rescode."_".$restype."-resdata.json");
         $uu=takevaljson($jsonf);
     }
     if ($restype=="tempx" or $restype=="pagex"){
       $localcss=combineurl(localroot(),"/localxres/csspagex/");       
       $zz1=copy_underdir($tarpath,$localcss);
       $zxc=deletefiles($localcss,0);
       if ($restype=="pagex"){
         $myurl=combineurl("http://".glw(),"/localxres/funx/maketinytounit/?tinyid=".$rescode."&newdo=tempx");
         $zz=file_get_contents($myurl);         
       }
     }
     $err="";
    }else{
     $err=$err."无法定位资源目录，未复制到资源目录！";
    }
    $zz=UX("update coode_hostregsys set insite=1 where sysid  in(select sysid from coode_sysinformation)");
  echo makereturnjson("1","成功安装。".$err,"");
}else{
  echo makereturnjson("0","安装失败-参数不全","");
}
     session_write_close();
?>