<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $sno=_get("sno");
eval(RESFUNSET("resnmtomother"));
   $frst=SX("select sysid,funname,vermd5,funcname,funfull from coode_funlist where SNO=".$sno);
   $totf=countresult($frst);
   if (intval($totf)>0 and strpos($frst,"报错")<=0){
     $fn=anyvalue($frst,"funname",0);
     $ftt=anyvalue($frst,"funcname",0);
     $ffull=anyvalue($frst,"funfull",0);
     $sysid=anyvalue($frst,"sysid",0);
     $fn=str_replace("()","",$fn);
     $zk=anyfunrun("savetoseed","","sysid=".$sysid."&restype=funx&resmark=".$fn,"");    
     $zp=anyfunrun("uprestoqny","","only=1&sysid=".$sysid."&restype=funx&rescode=".$fn,"");    
     $y=UX("update coode_funlist set lastfull=oldfull where SNO=".$sno);
     $x=UX("update coode_funlist set oldfull=funfull,PRIME=0 where SNO=".$sno);
    echo makereturnjson("1","升级成功","");
   }else{
    echo makereturnjson("0","数据库报错升级失败","");
   }
       session_write_close();
?>