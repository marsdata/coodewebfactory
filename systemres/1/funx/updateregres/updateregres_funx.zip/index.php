<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snox=_get("SNO");
eval(RESFUNSET("resnmtomother"));
$rst=SX("select resmark,restitle,restype from coode_sysregres where SNO=".$snox);
$resmark=anyvalue($rst,"resmark",0);
$restype=anyvalue($rst,"restype",0);
    $rescode="";
    $sysid="";
    $restext="";    
 switch($restype){
      case "clsx":
     $orst=SX("select sysid,vermd5,funcname,funname,funbody from coode_phpcls  where funname='".$resmark."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"funcname",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"funname",0);
     $restext=anyvalue($orst,"funbody",0);
     $z=UX("update coode_phpcls set PRIME=0 where  funname='".$resmark."'");
     break;
     case "funx":
     $orst=SX("select sysid,vermd5,funcname,funname,funbody from coode_funlist  where funname='".$resmark."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"funcname",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"funname",0);
     $restext=anyvalue($orst,"funbody",0);
     $z=UX("update coode_funlist set PRIME=0 where  funname='".$resmark."'");
     break;
     case "sfunx":
     $orst=SX("select sysid,vermd5,setcname,setname,funbody from coode_funsetfile  where setname='".$resmark."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"setcname",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"setname",0);
     $restext=anyvalue($orst,"funbody",0);
     $z=UX("update coode_funsetfile set PRIME=0 where  setname='".$resmark."'");
     break;
     case "dfunx":
     $orst=SX("select sysid,vermd5,dftitle,dfunmark,dfuneval from coode_datafun where where dfunmark='".$resmark."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"dftitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"dfunmark",0);
     $restext=anyvalue($orst,"dfuneval",0);
     $z=UX("update coode_datafun set PRIME=0  where  dfunmark='".$resmark."'");
     break;
     case "mfunx":
     $orst=SX("select sysid,vermd5,funcname,funname,funfull from  coode_multifunlist  where where funname='".$resmark."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"funcname",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"funname",0);
     $restext=anyvalue($orst,"funfull",0);
     $z=UX("update coode_multifunlist set PRIME=0  where  funname='".$resmark."'");
     break;
     case "groupx":
     $orst=SX("select sysid,vermd5,markname,plotmark from coode_grouplist  where plotmark='".$resmark."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"markname",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"plotmark",0);
     $z=UX("update coode_grouplist set PRIME=0  where  plotmark='".$resmark."'");
     break;
     case "plotx":
     $orst=SX("select sysid,vermd5,markname,plotmark from coode_plotlist  where plotmark='".$resmark."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"markname",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"plotmark",0);
     $z=UX("update coode_plotlist set PRIME=0  where  plotmark='".$resmark."'");
     break;
     case "pagex":
     $orst=SX("select sysid,vermd5,tinytitle,tinymark from coode_tiny where tinymark='".$resmark."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"tinytitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"tinymark",0);
     $z=UX("update coode_tiny set PRIME=0  where  tinymark='".$resmark."'");
     break;
     case "cdtrdrx":
     $orst=SX("select sysid,vermd5,cdtmark,cdtval as result from coode_cdtrdr  where concat(cdtmark,'.',cdtval)='".$resmark."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"cdtval",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"cdtmark",0).".".anyvalue($orst,"cdtval",0);     
     $z=UX("update coode_cdtrdr set PRIME=0   where concat(cdtmark,'.',cdtval)='".$resmark."'");
     break;
     case "parardrx":
     $orst=SX("select sysid,vermd5,paratitle,paramark from coode_parardr  where paramark='".$resmark."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"paratitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"plotmark",0);
     $z=UX("update coode_parardr set PRIME=0  where  paramark='".$resmark."'");
     break;
     case "constx":
     $orst=SX("select sysid,vermd5,constanttitle,constantid,constantvalue from coode_sysconstant where  constantid='".$resmark."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"constanttitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"constantid",0);
     $restext=anyvalue($orst,"constantvalue",0);
     $z=UX("update coode_sysconstant set PRIME=0  where  constantid='".$resmark."'");
     break;
     case "configx":
     $orst=SX("select sysid,vermd5,sysktitle,syskey,sysval from  coode_sysconfig  where  syskey='".$resmark."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"sysktitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"syskey",0);
     $restext=anyvalue($orst,"sysval",0);
     $z=UX("update coode_sysconfig set PRIME=0  where  syskey='".$resmark."'");
     break;
     case "dataspacex":
     $orst=SX("select sysid,vermd5,datatitle,datamark from coode_dataspace  where  datamark='".$resmark."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"datatitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"datamark",0);
     $z=UX("update coode_dataspace set PRIME=0  where  datamark='".$resmark."'");
     break;
     case "sysx":
     $orst=SX("select sysid,vermd5,sysname,sysid from coode_sysinformation where  sysid='".$resmark."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"sysname",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"sysid",0);
     $z=UX("update coode_sysinformation set PRIME=0  where  sysid='".$resmark."'");
     break;
     case "appx":
     $orst=SX("select sysid,vermd5,appname,appid from coode_appdefault  where  appid='".$resmark."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"appname",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"appid",0);
     $z=UX("update coode_appdefault set PRIME=0  where  appid='".$resmark."'");
     break;
     case "layx":
     $orst=SX("select sysid,vermd5,laytitle,layid from coode_applay  where  layid='".$resmark."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"laytitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"layid",0);
     $z=UX("update coode_applay set PRIME=0  where  layid='".$resmark."'");
     break;
     case "tempx":
     $orst=SX("select dumark,unittitle,sysid,vermd5,templatecode from coode_domainunit  where  dumark='".$resmark."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"unittitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"dumark",0);
     $restext=anyvalue($orst,"templatecode",0);
     $z=UX("update coode_domainunit set PRIME=0  where  dumark='".$resmark."'");
     break;
     default:
   }
    if ($restype=="pagex"){
     $resurl="/localxres/pagex/seedx/".$rescode."/".$rescode."_pagex.zip";
    }else if ($restype=="tempx"){
     $resurl="/localxres/".$restype."/".qian($rescode,".")."/".qian($rescode,".")."_tempx.zip";
    }else{
     $resurl="/localxres/".$restype."/".str_replace(".","_",$rescode)."/".str_replace(".","_",$rescode)."_".$restype.".zip";
    }
    
  if ( $rescode!=""){
    $zz=UX("update coode_sysregres set txturl='".$resurl."' where SNO=".$snox);
    $zk=tellmysrc($restype,$rescode,"",$sysid,$restext);    
    echo  makereturnjson("1","升级成功",$zk);
  }else{
    echo  makereturnjson("0","升级失败，参数不全","");
  }
     session_write_close();
?>