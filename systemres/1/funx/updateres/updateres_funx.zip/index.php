<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snox=$_GET["SNO"];
$restype=$_GET["restype"];
eval(RESFUNSET("resnmtomother"));
    $rescode=_get("rescode");
    $sysid="";
    $restext="";
    if ($rescode==""){
      $rescode="88888888@888";
    }
 $zz=UX("update coode_sysregres set PRIME=0 where resmark='".$rescode."' and restype='".$restype."'");
 switch($restype){
     case "funx":
     $orst=SX("select sysid,vermd5,funcname,funname,funbody from coode_funlist  where SNO='".$snox."' or funname='".$rescode."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"funcname",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"funname",0);
     $restext=anyvalue($orst,"funbody",0);
     $z=UX("update coode_funlist set PRIME=0 where  SNO='".$snox."' or funname='".$rescode."'");
     break;
     case "sfunx":
     $orst=SX("select sysid,vermd5,setcname,setname,funbody from coode_funsetfile  where SNO='".$snox."' or setname='".$rescode."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"setcname",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"setname",0);
     $restext=anyvalue($orst,"funbody",0);
     $z=UX("update coode_funsetfile set PRIME=0 where  SNO='".$snox."' or setname='".$rescode."'");
     break;
     case "dfunx":
     $orst=SX("select sysid,vermd5,dftitle,dfunmark,dfuneval from coode_datafun where SNO='".$snox."' or dfunmark='".$rescode."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"dftitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"dfunmark",0);
     $restext=anyvalue($orst,"dfuneval",0);
     $z=UX("update coode_datafun set PRIME=0  where  SNO='".$snox."' or dfunmark='".$rescode."'");
     break;
     case "mfunx":
     $orst=SX("select sysid,vermd5,funcname,funname,funfull from  coode_multifunlist  where SNO='".$snox."' or funname='".$rescode."'");
     //echo "select sysid,vermd5,funcname,funname,funfull from  coode_multifunlist  where SNO='".$snox."' or funname='".$rescode."'";     
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"funcname",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"funname",0);
     $restext=anyvalue($orst,"funfull",0);
     $z=UX("update coode_multifunlist set PRIME=0  where  SNO='".$snox."' or funname='".$rescode."'");
     break;
     case "afunx":
     $orst=SX("select sysid,vermd5,funcname,funname,funfull from  coode_affairfunlist  where SNO='".$snox."' or funname='".$rescode."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"funcname",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"funname",0);
     $restext=anyvalue($orst,"funfull",0);
     $z=UX("update coode_affairfunlist set PRIME=0  where  SNO='".$snox."' or funname='".$rescode."'");
     break;
     case "groupx":
     $orst=SX("select sysid,vermd5,markname,plotmark from coode_grouplist  where SNO='".$snox."' or plotmark='".$rescode."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"markname",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"plotmark",0);
     $z=UX("update coode_grouplist set PRIME=0  where  SNO='".$snox."' or plotmark='".$rescode."'");
     break;
     case "plotx":
     $orst=SX("select sysid,vermd5,markname,plotmark from coode_plotlist  where SNO='".$snox."' or plotmark='".$rescode."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"markname",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"plotmark",0);
     $z=UX("update coode_plotlist set PRIME=0  where  SNO='".$snox."' or plotmark='".$rescode."'");
     break;
     case "pagex":
     $orst=SX("select sysid,vermd5,tinytitle,tinymark from coode_tiny where SNO='".$snox."' or tinymark='".$rescode."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"tinytitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"tinymark",0);
     $z=UX("update coode_tiny set STATUS=0  where  SNO='".$snox."' or tinymark='".$rescode."'");
     break;
     case "cdtrdrx":
     $orst=SX("select sysid,vermd5,cdtmark,cdtval as result from coode_cdtrdr  where SNO='".$snox."' or concat(cdtmark,'.',cdtval)='".$rescode."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"cdtval",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"cdtmark",0)."-".anyvalue($orst,"cdtval",0);
     
     $z=UX("update coode_cdtrdr set PRIME=0   SNO='".$snox."'  or concat(cdtmark,'.',cdtval)='".$rescode."'");
     break;
     case "parardrx":
     $orst=SX("select sysid,vermd5,paratitle,paramark from coode_parardr  where SNO='".$snox."' or paramark='".$rescode."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"paratitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"plotmark",0);
     $z=UX("update coode_parardr set PRIME=0  where  SNO='".$snox."' or paramark='".$rescode."'");
     break;
     case "constx":
     $orst=SX("select sysid,vermd5,constanttitle,constantid,constantvalue from coode_sysconstant where  SNO='".$snox."' or constantid='".$rescode."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"constanttitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"constantid",0);
     $restext=anyvalue($orst,"constantvalue",0);
     $z=UX("update coode_sysconstant set PRIME=0  where  SNO='".$snox."' or constantid='".$rescode."'");
     break;
     case "configx":
     $orst=SX("select sysid,vermd5,sysktitle,syskey,sysval from  coode_sysconfig  where  SNO='".$snox."' or syskey='".$rescode."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"sysktitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"syskey",0);
     $restext=anyvalue($orst,"sysval",0);
     $z=UX("update coode_sysconfig set PRIME=0  where  SNO='".$snox."' or syskey='".$rescode."'");
     break;
     case "dataspacex":
     $orst=SX("select sysid,vermd5,datatitle,datamark from coode_dataspace  where  SNO='".$snox."' or datamark='".$rescode."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"datatitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"datamark",0);
     $z=UX("update coode_dataspace set PRIME=0  where  SNO='".$snox."' or datamark='".$rescode."'");
     break;
     case "sysx":
     $orst=SX("select sysid,vermd5,sysname,sysid from coode_sysinformation where  SNO='".$snox."' or sysid='".$rescode."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"sysname",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"sysid",0);
     $z=UX("update coode_sysinformation set PRIME=0  where  SNO='".$snox."' or sysid='".$rescode."'");
     break;
     case "appx":
     $orst=SX("select sysid,vermd5,appname,appid from coode_appdefault  where  SNO='".$snox."' or appid='".$rescode."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"appname",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"appid",0);
     $z=UX("update coode_appdefault set PRIME=0  where  SNO='".$snox."' or appid='".$rescode."'");
     break;
     case "layx":
     $orst=SX("select sysid,vermd5,laytitle,layid from coode_applay  where  SNO='".$snox."' or layid='".$rescode."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"laytitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"layid",0);
     $z=UX("update coode_applay set PRIME=0  where  SNO='".$snox."' or layid='".$rescode."'");
     break;
     case "tempx":
     $orst=SX("select dumark,unittitle,sysid,vermd5,templatecode from coode_domainunit  where  SNO='".$snox."' or dumark='".$rescode."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"unittitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"dumark",0);
     $restext=anyvalue($orst,"templatecode",0);
     $z=UX("update coode_domainunit set PRIME=0  where  SNO='".$snox."' or dumark='".$rescode."'");
     break;
     case "tabx":
     $orst=SX("select sysid,TABLE_NAME,tabtitle from coode_tablist  where  SNO='".$snox."' or TABLE_NAME='".$rescode."'");
     $omd5="";
     $restitle=anyvalue($orst,"tabtitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"TABLE_NAME",0);
     $restext="";
     $z=UX("update coode_tablist set PRIME=0  where  SNO='".$snox."' or TABLE_NAME='".$rescode."'");
     break;
     case "formx":
     $orst=SX("select sysid,shortid,shorttitle from coode_shortdata  where  SNO='".$snox."' or shortid='".$rescode."'");
     $omd5="";
     $restitle=anyvalue($orst,"shorttitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"shortid",0);
     $restext="";
     $z=UX("update coode_shortdata set STATUS=0  where  SNO='".$snox."' or shortid='".$rescode."'");
     break;
     case "parax":
     $orst=SX("select sysid,paramark,paratitle from coode_para  where  SNO='".$snox."' or paramark='".$rescode."'");
     $omd5="";
     $restitle=anyvalue($orst,"paratitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"paramark",0);
     $restext="";
     $z=UX("update coode_para set PRIME=0  where  SNO='".$snox."' or paramark='".$rescode."'");
     break;
     case "csspagex":
     $orst=SX("select sysid,faceid,facetitle from coode_facelist  where  SNO='".$snox."' or faceid='".$rescode."'");
     $omd5="";
     $restitle=anyvalue($orst,"facetitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"faceid",0);
     $restext="";
     $z=UX("update coode_facelist set PRIME=0  where  SNO='".$snox."' or faceid='".$rescode."'");
     break;
     case "apix":
     $orst=SX("select sysid,apicode,apititle from coode_apipool  where  SNO='".$snox."' or apicode='".$rescode."'");
     $omd5="";
     $restitle=anyvalue($orst,"apititle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"apicode",0);
     $restext="";
     $z=UX("update coode_apipool set PRIME=0  where  SNO='".$snox."' or apicode='".$rescode."'");
     break;
     case "iconsetx":
     $orst=SX("select setmark,settitle from coode_iconset  where  SNO='".$snox."' or setmark='".$rescode."'");
     $omd5="";
     $restitle=anyvalue($orst,"settitle",0);
     $sysid="1";
     $rescode=anyvalue($orst,"setmark",0);
     $restext="";
     $z=UX("update coode_iconset set PRIME=0  where  SNO='".$snox."' or setmark='".$rescode."'");
     break;
     case "databasex":
     $orst=SX("select sysid,dbmark,dbtitle from coode_dblist  where  SNO='".$snox."' or dbmark='".$rescode."'");
     $omd5="";
     $restitle=anyvalue($orst,"dbtitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"dbmark",0);
     $restext="";
     $z=UX("update coode_dblist set PRIME=0  where  SNO='".$snox."' or dbmark='".$rescode."'");
     break;
     case "clsx":
     $orst=SX("select sysid,vermd5,funcname,funname,funbody from coode_phpcls  where SNO='".$snox."' or funname='".$rescode."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"funcname",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"funname",0);
     $restext=anyvalue($orst,"funbody",0);
     $z=UX("update coode_phpcls set PRIME=0 where  SNO='".$snox."' or funname='".$rescode."'");
     break;
     case "smallcssx":
     $orst=SX("select sysid,vermd5,elemark,eletitle from coode_tinyhtml  where SNO='".$snox."' or elemark='".$rescode."'");
     $omd5=anyvalue($orst,"vermd5",0);
     $restitle=anyvalue($orst,"eletitle",0);
     $sysid=anyvalue($orst,"sysid",0);
     $rescode=anyvalue($orst,"elemark",0);
     
     $z=UX("update coode_tinyhtml set PRIME=0 where  SNO='".$snox."' or elemark='".$rescode."'");
     break;
     default:
   }
   //echo "sysid=".$sysid."--".$restype.$rescode;
  if ($restype!="" and $rescode!=""){    
    
    $zk=anyfunrun("savetoseed","","sysid=".$sysid."&restype=".$restype."&resmark=".$rescode."&rnd=".onlymark(),"");  
    $zp=anyfunrun("uprestoqny","","only=1&sysid=".$sysid."&restype=".$restype."&rescode=".$rescode."&rnd=".onlymark(),"");    
    echo  makereturnjson("1","升级成功","");
  }else{
    echo  makereturnjson("0","升级失败，参数不全","");
  }
     session_write_close();
?>