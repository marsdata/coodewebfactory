<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $sno=_get("sno");
$rst=SX("select TABLE_NAME,TABLE_SCHEMA,COLUMN_NAME,bfist,aftist,bfupd,aftupd,bfdel,aftdel from coode_keydetailx where SNO=".$sno);
$totr=countresult($rst);
if (intval($totr)>0){
    $tbnm=anyvalue($rst,"TABLE_NAME",0);
    $schm=anyvalue($rst,"TABLE_SCHEMA",0);
    $colm=anyvalue($rst,"COLUMN_NAME",0);
    $bfist=anyvalue($rst,"bfist",0);
    $aftist=anyvalue($rst,"aftist",0);
    $bfupd=anyvalue($rst,"bfupd",0);
    $aftupd=anyvalue($rst,"aftupd",0);
    $bfdel=anyvalue($rst,"bfdel",0);
    $aftdel=anyvalue($rst,"aftdel",0);
    $x=UX("update coode_keydetaily set bfist='".$bfist."',aftist='".$aftist."',bfupd='".$bfupd."',aftupd='".$aftupd."',bfdel='".$bfdel."',aftdel='".$aftdel."' where COLUMN_NAME='".$colm."' and shortid='".$tbnm."' ");
    $z=UX("update coode_keydetailx set PRIME=0 where SNO=".$sno);
    echo makereturnjson("1","成功","");
}else{
    echo makereturnjson("0","失败","");
}
     session_write_close();
?>