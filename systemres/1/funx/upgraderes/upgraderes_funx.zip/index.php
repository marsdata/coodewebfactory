<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $restype=_get("restype");
$rescode=_get("rescode");
switch($restype){
  case "formx":
    $sysid=UX("select sysid as result from coode_shortdata where shortid='".$rescode."'");
    $drst=SX("select sysid,shorttitle,tablename from coode_shortdata where shortid='".$rescode."'");     
     $shorttitle=anyvalue($drst,"shorttitle",0);
     $tablename=anyvalue($drst,"tablename",0);
    $tabrst=SX("select tabtitle,createsql from coode_tablist where TABLE_NAME='$tablename'");
      $tabtitle=anyvalue($tabrst,"tabtitle",0);
      $createsql=anyvalue($tabrst,"createsql",0);
      
    $pdata=Array();
    $pdata["a"]="";    
    $mthost=anyfunrun("svshost",glm(),"hostid=".$sysid,"");
    if (strpos($mthost,":443")>0){
        $purl="https://".str_replace(":443","",$mthost)."/localxres/funx/askver/?restype=".$restype."&rescode=".$rescode;
    }else{
        $purl="http://".$mthost."/localxres/funx/askver/?restype=".$restype."&rescode=".$rescode;
    }    
    $bktxt=request_post($purl,$pdata);
    $bkdata=json_decode($bktxt,false);
      $crtsql=$bkdata->crtsql;
      $mtmd5=$bkdata->tabmd5;
      
      $mxmd5=$bkdata->xmd5;
      $mymd5=$bkdata->ymd5;
      $mfmd5=$bkdata->formmd5;
      $zz0=tabsqltodb($mtmd5,$crtsql,"new");
      $zz1=tabsqltodb($mtmd5,$createsql,"old");
      $rdr="/localxres/funx/anyjsshort/?stid=bMswbe&upgcode=".$mtmd5;
  break;
  case "funx":
  break;
  case "tabx":
  break;
  default:
}
echo makereturnjson("1","资源更新准备成功",$rdr);
     session_write_close();
?>