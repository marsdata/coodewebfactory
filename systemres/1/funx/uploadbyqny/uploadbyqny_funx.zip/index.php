<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
        require_once combineurl(localroot(),'/localxres/parax/qny/autoload.php');
    use Qiniu\Auth;
    use Qiniu\Storage\UploadManager;
    // 设置信息
    $apicode=_get("apicode");
    $apistr=getapi($apicode);
    $apirst=SX("select sysid,appid from coode_apipool where apicode='$apicode'");
    if (strpos($apistr,"@")>0){
      $bucketname = qian($apistr,"@");
      $ak = qian(hou($apistr,"@"),":");
      $sk = hou($apistr,":");
    }else{
      $ak=qian($apistr,":");
      $sk=hou($apistr,":");
      $bucketname = anyvalue($apirst,"appid",0);
    }
    $lcfile=$_GET["lcfile"];
    $APP_ACCESS_KEY = $ak;
    $APP_SECRET_KEY = $sk;
    $bucket = $bucketname;
    $file = $lcfile;
    $thismd5=md5_file($file);
    $extmd5=UX("select count(*) as result from coode_qnyupfiles where vermd5='".$thismd5."'");
    if (intval($extmd5)==0){
     $auth = new Auth($APP_ACCESS_KEY, $APP_SECRET_KEY);    
     $fkey=str_replace(localroot(),"",$lcfile);      
     if (file_exists($lcfile) and $ak!="" and $sk!="" and $bucket!=""){
      $token = $auth->uploadToken($bucket,$fkey);
      $uploadManager = new UploadManager();   
      //两个key需要相同
      $qndm=sysconfigval(anyvalue($apirst,"sysid",0),"cloudstockhost");
      $sqlx="qnapicode,qndomain,lcfile,saveurl,fullurl,vermd5,CRTM,UPTM,OLMK,STCODE";
      $sqly="'$apicode','$qndm','$lcfile','".combineurl("/",$fkey)."','".combineurl("http://".$qndm,$fkey)."','".$thismd5."',now(),now(),'".onlymark()."','".$err."'";
      $zz=UX("insert into coode_qnyupfiles(".$sqlx.")values(".$sqly.")");
      list($ret, $err) = $uploadManager->putFile($token, $fkey, $file);
      if ($err != null) {
       echo '{"status":"0","msg":"'.$err->message().'","apicode":"'.$apicode.'","redirect":""}';
      } else {
       echo '{"status":"1","msg":"上传成功","apicode":"'.$apicode.'","bucket":"'.$bucket.'","redirect":"","key":"'.$ret["key"].'"}';
      }
     }else{
       echo '{"status":"0","msg":"参数不全","redirect":""}';  
     }
    }else{
      echo '{"status":"0","msg":"已存在该版本-".$thismd5,"redirect":""}';  
    }
     session_write_close();
?>