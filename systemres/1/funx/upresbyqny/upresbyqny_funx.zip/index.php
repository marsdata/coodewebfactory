<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
          require_once combineurl(localroot(),'/localxres/parax/qny/autoload.php');
    use Qiniu\Auth;
    use Qiniu\Storage\UploadManager;
    // 设置信息
    $apistr=_get("apistr");
    $bucketname = qian($apistr,"@");
    $ak = qian(hou($apistr,"@"),":");
    $sk = hou($apistr,":");    
    $lcfile=$_GET["lcfile"];
    $qndm=$_GET["qndm"];     
    $killhost=$_GET["killhost"];
    if ($killhost=="1"){
      $myhost="";
    }else{
      $myhost=$_SERVER["HTTP_HOST"];      
    }
    $APP_ACCESS_KEY = $ak;
    $APP_SECRET_KEY = $sk;
    $bucket = $bucketname;
    $file = $lcfile;
    $thismd5=md5_file($file);    
     $auth = new Auth($APP_ACCESS_KEY, $APP_SECRET_KEY);    
     if ($killhost=="1"){
       $fkey=str_replace(localroot(),"",$lcfile);      
     }else{
       $fkey=combineurl($myhost."/",str_replace(localroot(),"",$lcfile));      
     }
     if (file_exists($lcfile) and $ak!="" and $sk!="" and $bucket!=""){
      $token = $auth->uploadToken($bucket,$fkey);
      $uploadManager = new UploadManager();   
      //两个key需要相同
      
      $sqlx="qnapicode,qndomain,lcfile,saveurl,fullurl,vermd5,CRTM,UPTM,OLMK,STCODE";
      $sqly="'$bucketname','$qndm','$lcfile','".combineurl("/",$fkey)."','".combineurl("http://".$qndm,$fkey)."','".$thismd5."',now(),now(),'".onlymark()."','".$err."'";
      $zz=UX("insert into coode_qnyupfiles(".$sqlx.")values(".$sqly.")");
      list($ret, $err) = $uploadManager->putFile($token, $fkey, $file);
      if ($err != null) {
       echo '{"status":"0","msg":"'.$err->message().'","apicode":"'.$ak.'","redirect":""}';
      } else {
       echo '{"status":"1","msg":"上传成功","apicode":"'.$ak.'","bucket":"'.$bucket.'","redirect":"","key":"'.$ret["key"].'"}';
      }
     }else{
       echo '{"status":"0","msg":"参数不全","redirect":""}';  
     }
  
       session_write_close();
?>