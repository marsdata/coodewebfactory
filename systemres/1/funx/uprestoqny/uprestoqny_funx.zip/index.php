<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
        $restype=$_GET["restype"];
   $rescode=$_GET["rescode"];
   $sysid=dftval($_GET["sysid"],$_GET["wrdid"]);
   $wrdid=$sysid;
   $only=$_GET["only"];
if (glm()!="motherhost"){
   $succx=0;
   switch($only){
     case "1":
      $qnytxt=anyfunrun("getqnyapi",glm(),"","");
      $qnyjson=json_decode($qnytxt,false);
      $apistr=$qnyjson->msg;
      $dmhost=$qnyjson->redirect;   
       if (($sysid=="0" or $sysid=="1" or $sysid=="2" or $sysid=="v") and $_SERVER["HTTP_HOST"]!="divlovecss.com"){
         $dmhost="";
         $pool=SX("select SNO,grpid,restype,restitle,vermd5 from coode_sysregres where  resmark='".$rescode."' and restype='".$restype."' and grpid='".$sysid."'");
         $toto=1;
         $pushmark=getRandChar(7);
         $purl=combineurl("http://".glm(),"/localxres/funx/rcvres/?pushmark=".$pushmark);
         $rtitle=anyvalue($pool,"restitle",0);
         $vermd5=anyvalue($pool,"vermd5",0);
         $purl=$purl."&sysid=".$sysid;
         $purl=$purl."&restitle=".$rtitle;
         $purl=$purl."&fromhost=".killlaststr(glw());
         $purl=$purl."&vermd5=".$vermd5;  
         $purl=$purl."&restype=".$restype;  
         $purl=$purl."&rescode=".$rescode;       
         $zz=file_get_contents($purl);
       }else{
        $ff=combineurl(localroot(),"/systemres/".$sysid."/".$sysid.".json");
        $zz1=overfile($ff,anyfunrun("anyshort","","stid=GJXex0&pnum=9999&page=1&grpid=".$sysid,""));
        $bb=anyfunrun("upresbyqny","","apistr=".$apistr."&qndm=".$dmhost."&lcfile=".$ff,"");
       }
       $killhost="";
     break;
     case "2":
       $apistr=garea();
        $dmhost=qian($apistr,"@").".".$_SERVER["HTTP_HOST"];
        $ff=combineurl(localroot(),"/systemres/".$wrdid."/".$wrdid.".json");
        $zz1=overfile($ff,anyfunrun("anyshort","","stid=8jEK5R&pnum=9999&page=1&grpid=".$wrdid,""));
        $bb=anyfunrun("upresbyqny","","killhost=1&apistr=".$apistr."&qndm=".$dmhost."&lcfile=".$ff,"");
        $killhost="1";
     break;
     default:
      $qnytxt=anyfunrun("getqnyapi",glm(),"","");
      $qnyjson=json_decode($qnytxt,false);
      $apistr=$qnyjson->msg;
      $dmhost=$qnyjson->redirect;   
      $killhost="";
   }
  if (es($dmhost)*es($restype)*es($rescode)==1){
   $zz=UX("update coode_sysregres set STATUS=2 where restype='".$restype."' and resmark='".$rescode."'");
   switch($restype){
    case "pagex":
     $resurl=combineurl(localroot(),"/systemres/".$sysid."/pagex/".$rescode."/".$rescode."_pagex.zip");
    break;
    case "tempx":
    $resurl=combineurl(localroot(),"/systemres/".$sysid."/tempx/".qian($rescode,".")."/".qian($rescode,".")."_tempx.zip");
    break;
    default:
    $resurl=combineurl(localroot(),"/systemres/".$sysid."/".$restype."/".str_replace(".","_",$rescode)."/".str_replace(".","_",$rescode)."_".$restype.".zip");
   }
   $err="";  
   echo anyfunrun("upresbyqny","","killhost=".$killhost."&apistr=".$apistr."&qndm=".$dmhost."&lcfile=".$resurl,"");
 }else{
   echo makereturnjson("0","上传失败-参数不全-".$fromhost."/".$restype."/".$rescode,"");
 }
}else{
     if ($only=="1"){
       $ff=combineurl(localroot(),"/systemres/".$sysid."/".$sysid.".json");
       $zz1=overfile($ff,anyfunrun("anyshort","","stid=GJXex0&pnum=9999&page=1&grpid=".$sysid,""));
       $bb=anyfunrun("gitupsecond","","apicode=coodegit&filepath=".$ff,"");
      }
       if (es($restype)*es($rescode)==1){
        $zz=UX("update coode_sysregres set STATUS=2 where restype='".$restype."' and resmark='".$rescode."'");
        switch($restype){
          case "pagex":
           $resurl=combineurl(localroot(),"/systemres/".$sysid."/pagex/".$rescode."/".$rescode."_pagex.zip");
          break;
          case "tempx":
          $resurl=combineurl(localroot(),"/systemres/".$sysid."/tempx/".qian($rescode,".")."/".qian($rescode,".")."_tempx.zip");
          break;
          default:
          $resurl=combineurl(localroot(),"/systemres/".$sysid."/".$restype."/".str_replace(".","_",$rescode)."/".str_replace(".","_",$rescode)."_".$restype.".zip");
         }
        $err="";  
        echo anyfunrun("gitupsecond","","apicode=coodegit&filepath=".$resurl,"");
     }else{
       echo makereturnjson("0","上传失败-参数不全-".$fromhost."/".$restype."/".$rescode,"");
     }     
}
       session_write_close();
?>