<?php
function gl(){return "localhost";}//DESCRIB glb():本系统mysql 数据库IP END@glb()
function glu(){return "io_halo123_cn";}//DESCRIB glu():本系统mysql 数据库用户名 END@glu()
function glp(){return "guevara123000";}//DESCRIB glp():本系统mysql 数据库密码 END@glp()
function glb(){return "io_halo123_cn";}//DESCRIB glb():本系统mysql 数据库 END@lgb()
function gln(){return "1";}//DESCRIB gln():当前使用系统名称 END@gln()
function gla(){return md5("182.92.110.118");}//DESCRIB gla():当前apikey END@gln()
function glv(){return md5($_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"]);}//DESCRIB glv():当前api verfy 使用系统版本号 END@gln()
function glt(){return "[sitename]";}//DESCRIB glt():当前实例名称 END@glt()
function glm(){return "motherhost";}//DESCRIB glm():母系统域名 END@glt() localhost 为本地模式不联网
function hostcode(){return "coodeio";}//DESCRIB glr():授权注册码 END@glt() 申请试用后，提供服务器IP地址，给您安装，转移操作
function runblog(){return 1;}//日志记录是否开启
function runprocess(){return 1;}//日志记录是否开启
function remoteway(){return 1;}//远程模式，可以上传资源到母机
function bl(){return "localhost";}//DESCRIB glb():业务系统mysql 数据库IP END@glb()
function blu(){return "coodewrd";}//DESCRIB glu():业务系统mysql 数据库用户名 END@glu()
function blp(){return "guevara123000";}//DESCRIB glp():业务系统mysql 数据库密码 END@glp()
function blb(){return "coodewrd";}//DESCRIB glb():业务系统mysql 数据库 END@lgb()
function bln(){return "[secondsys]";}//DESCRIB gln():当前业务使用系统名称 END@gln()
function blt(){return "酷德系统资源管理";}//DESCRIB glt():当前实例名称 END@glt()
function _get($str){ $val = !empty($_GET[$str]) ? $_GET[$str] : ""; return $val; } //DESCRIB ():  END@()

function es($strx){
    $strx=str_replace(" ","",$strx);
    $strx=str_replace("un"."defined","",$strx);
    if ($strx!=""){
        return 1;
    }else{
        return 0;
    }
}

function to($s, $isfirst = false) {
    $res = '';
    $len = strlen($s);
    $pinyin_arr = self::get_pinyin_array();
    for($i=0; $i<$len; $i++) {
      $ascii = ord($s{$i});
      if($ascii > 0x80) {
        $ascii2 = ord($s{++$i});
        $ascii = $ascii * 256 + $ascii2 - 65536;
      }
      if($ascii < 255 && $ascii > 0) {
        if(($ascii >= 48 && $ascii <= 57) || ($ascii >= 97 && $ascii <= 122)) {
          $res .= $s{$i}; // 0-9 a-z
        }elseif($ascii >= 65 && $ascii <= 90) {
          $res .= strtolower($s{$i}); // A-Z
        }else{
          $res .= '_';////将符号转义 不替换符号$res .= $s{$i};
        }
      }elseif($ascii < -20319 || $ascii > -10247) {
        $res .= '_';
      }else{
        foreach($pinyin_arr as $py=>$asc) {
          if($asc <= $ascii) {
            $res .= $isfirst ? $py{0} : $py;
            break;
          }
        }
      }
    }
    return $res;
  }
  
?>