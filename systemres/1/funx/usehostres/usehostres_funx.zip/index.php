<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     eval(RESFUNSET("tabdataoprt"));
$snox=_get("SNO");
$rcrst=SX("select SNO,fromhost,resmark,restype,vermd5,STATUS from coode_respool where SNO='".$snox."'");
$totrc=countresult($rcrst);
if ($totrc>0){  
  $fromhost=hou(anyvalue($rcrst,"fromhost",0),"://");
  $pushmark=getRandChar(6);  
  $rcode=anyvalue($rcrst,"resmark",0);
  $rtype=anyvalue($rcrst,"restype",0);
  $vmd5=anyvalue($rcrst,"vermd5",0);
  $stt=anyvalue($rcrst,"STATUS",0);
}else{
  $fromhost=hou(_get("fromhost"),"://");
  $pushmark=getRandChar(6);  
  $rcode=_get("resmark");
  $rtype=_get("restype");
  $vmd5=_get("vermd5");
  $stt="0";
}
function tornx($txx){
  if ($txx==true){
    return 1;
  }else{
    return 0;
  }
}
if ($rcode!=""){
  $succx=0;
  if ( intval($stt)==1){//默认为母机服务器
   $resurl=combineurl("http://".glm(),"/localxres/respool/".$rtype."/".str_replace(".","_",$rcode)."/".$vmd5."/".str_replace(".","_",$rcode)."_".$rtype.".zip");
   $newurl=combineurl(localroot(),"/localxres/seedx/".$rtype."/".str_replace(".","_",$rcode)."/".$vmd5."/".str_replace(".","_",$rcode)."_".$rtype.".zip"); 
   $newpath=combineurl(localroot(),"/localxres/seedx/".$rtype."/".str_replace(".","_",$rcode)."/".$vmd5."/"); 
   $tarpath=combineurl(localroot(),"/localxres/".$rtype."/".qian($rcode,".")."/"); 
   if (downanyfile($resurl,$newurl)){
    $zz=unzip($newurl,$newpath);
    unlink($newurl);
    if (file_exists(combineurl($newpath,"install.sql"))){
      $sqltxt=file_get_contents(combineurl($newpath,"install.sql"));
      $rlrst=SX("select relytab,strcdt from coode_resrelydata where restype='".$rtype."' and strtype='datasql' and strcdt like '%"."d"."efault%'");
      $totrl=countresult($rlrst);
      for ($kk=0;$kk<$totrl;$kk++){
       $relytab=anyvalue($rlrst,"relytab",$kk);
       $strcdt=anyvalue($rlrst,"strcdt",$kk);
       $ksql="delete from ".$relytab." where ".$strcdt;
       $ksql=str_replace("[default]",$rcode,$ksql);
       $kkz=UX($ksql);
      }     
      $ptsql=explode(huanhang(),$sqltxt);
      $succx=count($ptsql);
      for ($nn=0;$nn<count($ptsql);$nn++){
       if ($ptsql[$nn]!=""){
        $svals=$ptsql[$nn];
        $svals=str_replace("〖","('",$svals);
        $svals=str_replace("〗","')",$svals);
        $svals=str_replace("∨","','",$svals);
        $svals=str_replace("丷",shuangyinhao(),$svals);
        $svals=str_replace("@DYH@)","'",$svals);
        $svals=str_replace("(@DYH@","'",$svals);
        //echo $svals;
        $nx=UX($svals);
       }
      }
     }else{
      $restype=$rtype;
      $rescode=$rcode;
      switch($restype){
       case "pagex":
         $jsonf0=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$rescode."_".$restype."-resdata.json");
         $uu=takevaljson($jsonf0);
         $succx=$succx+tornx($uu);
         $jsonf1=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$rescode."_".$restype."-pagedata.json");
         $uu=takevaljson($jsonf1);
         $succx=$succx+tornx($uu);
       break;
       case "tabx":
       $relyresurl=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $vls=$relydata->vls;
       $z0=crttab(0,anyfunrun("gettabcrt",$fromhost,"tabnm=".$rescode,""));
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$verx.".json"); 
         $uu=takevaljson($jsonf);
         $succx=$succx+tornx($uu);
       }
       break;
       case "formx":
       $relyresurl=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $vls=$relydata->vls;
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$verx.".json"); 
         $uu=takevaljson($jsonf);
         $succx=$succx+tornx($uu);
       }
       break;
       case "plotx":
       $relyresurl=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $vls=$relydata->vls;
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$verx.".json"); 
         $uu=takevaljson($jsonf);
         $succx=$succx+tornx($uu);
       }
       break;
       case "groupx":
       $relyresurl=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $vls=$relydata->vls;
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$verx.".json"); 
         $uu=takevaljson($jsonf);
         $succx=$succx+tornx($uu);
       }
       break;
       case "dataspacex":
       $relyresurl=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json"); 
       $relytxt=file_get_contents($relyresurl);
       $relydata=json_decode($relytxt,false);
       $vls=$relydata->vls;
       for ($j=0;$j<count($vls);$j++){
         $verx=$vls[$j]->resmd5;
         $jsonf=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$verx.".json"); 
         $uu=takevaljson($jsonf);
         $succx=$succx+tornx($uu);
       }
       break;
       default:
         $jsonf=combineurl(localroot(),"/localxres/".$restype."/".$rescode."/".$rescode."_".$restype."-resdata.json");
         $uu=takevaljson($jsonf);
         $succx=$succx+tornx($uu);
      }
     }//if fileexist
     if ($rtype!="pagex"){
      $zz=copy_underdir($newpath,$tarpath);
     }else{
      $tnrst=SX("select sysid,appid,layid,tinymark from coode_tiny where tinymark='".$rescode."'");
      $sysid=anyvalue($tnrst,"sysid",0);
      $appid=anyvalue($tnrst,"appid",0);
      $layid=anyvalue($tnrst,"layid",0);
      $tarpath=combineurl(localroot(),"/localxres/pagex/".$sysid."/".$appid."/".$layid."/".$rescode."/");
      $zz=copy_underdir($newpath,$tarpath);
     }
     echo makereturnjson("1","安装成功-".$succx."条","");
   }else{
    echo makereturnjson("0","安装失败","");
   }
  }else{
    echo anyfunrun("installpod","","fromhost=".$fromhost."&restype=".$rtype."&rescode=".$rcode,"");
    //echo "fromhost=".$fromhost."&restype=".$rtype."&rescode=".$rcode;
  }
}else{
  echo makereturnjson("0","不存在资源","");
}
     session_write_close();
?>