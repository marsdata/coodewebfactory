<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $vrst=SX("select vtitle,vaddress from eqm_venders where SNO="._get("SNO"));
$vtitle=anyvalue($vrst,"vtitle",0);
$vaddress=anyvalue($vrst,"vaddress",0);
$crst=SX("select cityid,cityname,lat,lon from z_citystreet where '".$vtitle.$vaddress."' like concat('%',cityname,'%') limit 0,5");
//echo "select cityid,cityname,lat,lon from z_citystreet where '".$vtitle.$vaddress."' like concat('%',cityname,'%') limit 0,5";
//echo $crst;
$cityid=anyvalue($crst,"cityid",0);
$cityname=anyvalue($crst,"cityname",0);
$lat=anyvalue($crst,"lat",0);
$lon=anyvalue($crst,"lon",0);
$zz=UX("update eqm_venders set STATUS=1,city='".$cityname."',areacode='".$cityid."' where SNO="._get("SNO"));
echo makereturnjson("1","成功","");
     session_write_close();
?>