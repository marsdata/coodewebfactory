<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snox=dftval($_GET["SNO"],"");
$srst=SX("select catalog,TABLE_NAME,tabtitle,fip,fuser,fpass,fbase from coode_dbtablist where SNO=".$snox);
$catalog=anyvalue($srst,"catalog",0);
$fipx=anyvalue($srst,"fip",0);
$fuserx=anyvalue($srst,"fuser",0);
$fpassx=anyvalue($srst,"fpass",0);
$fbasex=anyvalue($srst,"fbase",0);
$tabnm=anyvalue($srst,"TABLE_NAME",0);
if ($catalog=="thishostcore"){
  header ("location:/localxres/funx/anyjsshort/?datatype=html&stid=2qPIqS-&pnum=100:".$tabnm."&page=1:TABLE_NAME");
}else{
  header ("location:/localxres/funx/anyjsshort/?datatype=html&stid=2qP7P4-&catalog=".$catalog."&pnum=100:".$tabnm."&page=1:TABLE_NAME");
}
     session_write_close();
?>