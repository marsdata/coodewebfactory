<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snox=_get("SNO");
//函数类型，列表JSON数据，单条详情，等，接收；
$resrst=SX("select SNO,fromhost,restype,resmark,vermd5,restitle from coode_respool where SNO=".$snox);
$totres=countresult($resrst);
if ($totres>0){
  //$fromhost=anyvalue($resrst,"fromhost",0);
  $fromhost=_get("host");
  $restype=anyvalue($resrst,"restype",0);
  $resmark=anyvalue($resrst,"resmark",0);
  $vermd5=anyvalue($resrst,"vermd5",0);
  $restitle=anyvalue($resrst,"restitle",0);
  if (hou($fromhost,":")=="80" or hou($fromhost,":")=="443"){
    if (hou($fromhost,":")=="443"){
      $fhost="https://".qian($fromhost,":");
    }else{
      $fhost="http://".qian($fromhost,":");
    }
  }else{
    $fhost="http://".$fromhost;
  }
  switch($restype){
    case "tempx":
    $murl=makeviewurl("/localxres/tempx/".qian($resmark,".")."/index.html");
    $vurl=combineurl($fhost,"/localxres/pagex/1/sysorg/RgHw9trO/Givnix/index.html?viewurl=".$murl."&restype=".$restype."&rescode=".$resmark."&vermd5=".$vermd5);    
    break;
    case "pagex":
    $murl=makeviewurl("/localxres/funx/anyrdr/?cdtmark=".$resmark."&cdtval=".$vermd5);
    $vurl=combineurl($fhost,"/localxres/pagex/1/sysorg/RgHw9trO/Givnix/index.html?viewurl=".$murl."&restype=".$restype."&rescode=".$resmark."&vermd5=".$vermd5);    
    break;
    case "formx":
    $murl=makeviewurl("/localxres/formx/".$resmark."/index-".$vermd5.".html");
    $vurl=combineurl($fhost,"/localxres/pagex/1/sysorg/RgHw9trO/Givnix/index.html?viewurl=".$murl."&restype=".$restype."&rescode=".$resmark."&vermd5=".$vermd5);    
    break;
    case "tabx":
    $murl=makeviewurl("/localxres/funx/anyjsshort/?stid=tabfrm-pnum:300-&tablename=".$resmark."&page=1&pnum=30");
    $vurl=combineurl($fhost,"/localxres/pagex/1/sysorg/RgHw9trO/Givnix/index.html?viewurl=".$murl."&restype=".$restype."&rescode=".$resmark."&vermd5=".$vermd5);    
    break;
    case "groupx":    
    $murl=makeviewurl("/localxres/funx/anyjsshort/?stid=Q8CMrU-pnum:300-&plotmark=".$resmark."&page=1&pnum=30");
    $vurl=combineurl($fhost,"/localxres/pagex/1/sysorg/RgHw9trO/Givnix/index.html?viewurl=".$murl."&restype=".$restype."&rescode=".$resmark."&vermd5=".$vermd5);    
    break;
    case "plotx":        
    $murl=makeviewurl("/localxres/funx/anyjsshort/?stid=laypcmM-pnum:30-&plmk=".$vermd5."&parid=-1");
    $vurl=combineurl($fhost,"/localxres/pagex/1/sysorg/RgHw9trO/Givnix/index.html?viewurl=".$murl."&restype=".$restype."&rescode=".$resmark."&vermd5=".$vermd5);
    break;
    case "funx":    
    $murl=makeviewurl("/localxres/pagex/1/funabout/agt6HSp0/ittpVK/editfile.html?vermd5=".$vermd5."&restype=".$restype."&rescode=".$resmark);
    $vurl=combineurl($fhost,"/localxres/pagex/1/sysorg/RgHw9trO/Givnix/index.html?viewurl=".$murl."&restype=".$restype."&rescode=".$resmark."&vermd5=".$vermd5);
    break;
    case "clsx":    
    $murl=makeviewurl("/localxres/pagex/1/funabout/agt6HSp0/ittpVK/editfile.html?vermd5=".$vermd5."&restype=".$restype."&rescode=".$resmark);
    $vurl=combineurl($fhost,"/localxres/pagex/1/sysorg/RgHw9trO/Givnix/index.html?viewurl=".$murl."&restype=".$restype."&rescode=".$resmark."&vermd5=".$vermd5);
    break;
    case "dfunx":    
    $murl=makeviewurl("/localxres/pagex/1/funabout/agt6HSp0/ittpVK/editfile.html?vermd5=".$vermd5."&restype=".$restype."&rescode=".$resmark);
    $vurl=combineurl($fhost,"/localxres/pagex/1/sysorg/RgHw9trO/Givnix/index.html?viewurl=".$murl."&restype=".$restype."&rescode=".$resmark."&vermd5=".$vermd5);
    break;
    case "sfunx":    
    $murl=makeviewurl("/localxres/pagex/1/funabout/agt6HSp0/ittpVK/editfile.html?vermd5=".$vermd5."&restype=".$restype."&rescode=".$resmark);
    $vurl=combineurl($fhost,"/localxres/pagex/1/sysorg/RgHw9trO/Givnix/index.html?viewurl=".$murl."&restype=".$restype."&rescode=".$resmark."&vermd5=".$vermd5);
    break;
    case "mfunx": 
    $murl=makeviewurl("/localxres/pagex/1/funabout/agt6HSp0/ittpVK/editfile.html?vermd5=".$vermd5."&restype=".$restype."&rescode=".$resmark);
    $vurl=combineurl($fhost,"/localxres/pagex/1/sysorg/RgHw9trO/Givnix/index.html?viewurl=".$murl."&restype=".$restype."&rescode=".$resmark."&vermd5=".$vermd5);
    break;
    case "constx": 
    $murl=makeviewurl("/localxres/pagex/1/funabout/agt6HSp0/ittpVK/editfile.html?vermd5=".$vermd5."&restype=".$restype."&rescode=".$resmark);
    $vurl=combineurl($fhost,"/localxres/pagex/1/sysorg/RgHw9trO/Givnix/index.html?viewurl=".$murl."&restype=".$restype."&rescode=".$resmark."&vermd5=".$vermd5);
    break;
    case "configx": 
    $murl=makeviewurl("/localxres/pagex/1/funabout/agt6HSp0/ittpVK/editfile.html?vermd5=".$vermd5."&restype=".$restype."&rescode=".$resmark);
    $vurl=combineurl($fhost,"/localxres/pagex/1/sysorg/RgHw9trO/Givnix/index.html?viewurl=".$murl."&restype=".$restype."&rescode=".$resmark."&vermd5=".$vermd5);
    break;
    default:
  }
  if ($vurl!=""){
   echo makereturnjson("1","成功",$vurl);
  }else{
   echo makereturnjson("-1","失败","");
  }
}else{
  echo makereturnjson("0","失败","");
}
     session_write_close();
?>