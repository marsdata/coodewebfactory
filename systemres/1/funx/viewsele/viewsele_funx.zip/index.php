<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $selemark=dftval($_GET["selemark"],"");
$pagesrd=constval("pagesrdcode");
$prst=SX("select seletitle,jsscode,htmlcode from coode_elecode where selemark='".$selemark."'");
$totp=countresult($prst);
if (intval($totp)>0){
  $jsscode=tostring(anyvalue($prst,"jsscode",0));
  $htmlcode=tostring(anyvalue($prst,"htmlcode",0));  
  $eletitle=anyvalue($prst,"seletitle",0);
   $pagesrd=str_replace("{body","{body style=\"text-align:center;width:100%;height:100%;\"",$pagesrd);
   $srddemo='{center}{div style="width:100%;height:100%;padding-top:20px;"}'.huanhang().'[INCODE]'.huanhang().'{/div}{/center}';
   $srddemo=str_replace("[INCODE]",$htmlcode,$srddemo);
  $pagesrd=turnlab($pagesrd);    
  $pagesrd=str_replace("<!--thistitle-->",$eletitle,$pagesrd);
  $pagesrd=str_replace("<!--thesecomCSSFILES-->","",$pagesrd);
  $pagesrd=str_replace("<!--thesecomJSFILES-->","",$pagesrd);
  $pagesrd=str_replace("<!--thiscomSTYLE-->",$jsscode,$pagesrd);
  $pagesrd=str_replace("<!--thiscomSCRIPT-->","",$pagesrd);
  $pagesrd=str_replace("<!--thiscomHTML-->",turnlab($srddemo),$pagesrd);
  echo $pagesrd;
}else{
  $pagesrd=turnlab($pagesrd);    
  $pagesrd=str_replace("<!--thistitle-->","错误页面",$pagesrd);
  $pagesrd=str_replace("<!--thesecomCSSFILES-->","",$pagesrd);
  $pagesrd=str_replace("<!--thesecomJSFILES-->","",$pagesrd);
  $pagesrd=str_replace("<!--thiscomSTYLE-->",$jsscode,$pagesrd);
  $pagesrd=str_replace("<!--thiscomSCRIPT-->","",$pagesrd);
  $pagesrd=str_replace("<!--thiscomHTML-->","未发现".$selemark."元件，请检查参数",$pagesrd);
  echo $pagesrd;
}
     session_write_close();
?>