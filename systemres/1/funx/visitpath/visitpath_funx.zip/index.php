<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $path=addendx(_get("path"));
if (substr($path,0,1)!="/"){
  $path="/".$path;
}
if (strpos("xxx-".$path,localroot())>0){
  $fullpath=$path;
}else{
  $fullpath=combineurl(localroot(),$path);
}
$shortpath=str_replace(localroot(),"",$path);
$thispath=combineurl("/",$shortpath);
$filelists=Array();
$filelists=pathfile($thispath);
$totfx=count($filelists);
header("location:/localxres/funx/anyjsshort/?stid=BwT7WQ&pnum=100&page=1&lcpath=".$fullpath."&rnd=".onlymark());
     session_write_close();
?>