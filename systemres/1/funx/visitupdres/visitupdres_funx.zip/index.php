<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $vrst=SX("select SNO,pageurl,visitfunurl from coode_pagevisit order by CRTM desc limit 0,10");
$totv=countresult($vrst);
$a=time();
for ($ii=0;$ii<$totv;$ii++){
  $snox=anyvalue($vrst,"SNO",$ii);
  
  $pageurl=anyvalue($vrst,"pageurl",$ii);
  $vfurl=anyvalue($vrst,"visitfunurl",$ii);
  $pgtype=qian(hou($pageurl,"/localxres/"),"/");
  
  switch($pgtype){
    case "tempx":
    $dmmk=qian(hou($pageurl,"/localxres/tempx/"),"/").".index";
     $xrst=SX("select SNO,grpid from coode_sysregres where resmark='".$dmmk."' and restype='tempx'");
     $sysid=anyvalue($xrst,"grpid",0);
     $mthost=anyfunrun("svshost",glm(),"hostid=".$sysid,"");
     $bkjson=anyfunrun("getsysresver",$mthost,"sysid=".$sysid."&rescode=".$dmmk."&restype=tempx");
     $bkdata=json_decode($bkjson,false);
     $bkver=$bkdata->vmd5;
     $uptm=$bkdata->UPTM;
     $zzz=UX("update coode_sysregres set mtdate='".$uptm."',mtver='".$bkver."' where resmark='".$dmmk."' and restype='tempx'");
    break;
    case "csspagex":
    $dmmk=qian(hou($pageurl,"/localxres/csspagex/"),"/");
      $xrst=SX("select SNO,grpid from coode_sysregres where resmark='".$dmmk."' and restype='csspagex'");
      $sysid=anyvalue($xrst,"grpid",0);
      $mthost=anyfunrun("svshost",glm(),"hostid=".$sysid,"");
      $bkjson=anyfunrun("getsysresver",$mthost,"sysid=".$sysid."&rescode=".$dmmk."&restype=csspagex");
      $bkdata=json_decode($bkjson,false);
      $bkver=$bkdata->vmd5;
      $uptm=$bkdata->UPTM;
      $zzz=UX("update coode_sysregres set mtdate='".$uptm."',mtver='".$bkver."' where resmark='".$dmmk."' and restype='csspagex'");
    break;
    case "pagex":
     if (strpos($pageurl,"tinyid=")>0){
      $tnid=qian(hou($pageurl,"tinyid="),"&");
      $xrst=SX("select SNO,grpid from coode_sysregres where resmark='".$tnid."' and restype='pagex'");
      $sysid=anyvalue($xrst,"grpid",0);
      $mthost=anyfunrun("svshost",glm(),"hostid=".$sysid,"");
      $bkjson=anyfunrun("getsysresver",$mthost,"sysid=".$sysid."&rescode=".$tnid."&restype=pagex");
      $bkdata=json_decode($bkjson,false);
      $bkver=$bkdata->vmd5;
      $uptm=$bkdata->UPTM;
      $zzz=UX("update coode_sysregres set mtdate='".$uptm."',mtver='".$bkver."' where resmark='".$tnid."' and restype='pagex'");
     }
    break;
    case "funx":
    $stid=qian(hou($pageurl,"stid="),"&");
      $xrst=SX("select SNO,grpid from coode_sysregres where resmark='".$stid."' and restype='formx'");
      $sysid=anyvalue($xrst,"grpid",0);
      $mthost=anyfunrun("svshost",glm(),"hostid=".$sysid,"");
      $bkjson=anyfunrun("getsysresver",$mthost,"sysid=".$sysid."&rescode=".$stid."&restype=formx");
      $bkdata=json_decode($bkjson,false);
      $bkver=$bkdata->vmd5;
      $uptm=$bkdata->UPTM;
      $zzz=UX("update coode_sysregres set mtdate='".$uptm."',mtver='".$bkver."' where resmark='".$stid."' and restype='formx'");
    break;
    default:
  }
  $funname=qian(hou($vfurl,"/localxres/funx/"),"/");  
  $xrst=SX("select SNO,grpid from coode_sysregres where resmark='".$funname."' and restype='funx'");
  $totx=countresult($xrst);
  
  if ($totx>0){
    $sysid=anyvalue($xrst,"grpid",0);
    
    $mthost=anyfunrun("svshost",glm(),"hostid=".$sysid,"");
  
    $bkjson=anyfunrun("getsysresver",$mthost,"sysid=".$sysid."&rescode=".$funname."&restype=funx","");
    $bkdata=json_decode($bkjson,false);
    
    $bkver=$bkdata->vmd5;
    $uptm=$bkdata->UPTM;
    $zzz=UX("update coode_sysregres set mtdate='".$uptm."',mtver='".$bkver."' where resmark='".$funname."' and restype='funx'");      
  }
  $nnn=UX("update coode_pagevisit set STATUS=1 where SNO=".$snox);
}
$b=time();
echo makereturnjson("1","更新成功-耗时：".($b-$a),"");
     session_write_close();
?>