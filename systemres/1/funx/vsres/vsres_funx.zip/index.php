<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $vtype=_get("vtype");
$SNO=_get("SNO");
$resrst=SX("select restype,resmark,restitle from coode_sysregres where SNO='".$SNO."'");
$restype=anyvalue($resrst,"restype",0);
$resmark=anyvalue($resrst,"resmark",0);
switch($vtype){
  case "direct":
   switch($restype){
    case "tempx":
    $purl="/localxres/tempx/".qian($resmark,".")."/".hou($resmark,".").".html";   
    break;
    case "pagex":
    $purl="/localxres/funx/anytiny/?tiny=".$resmark;
    break;
    case "formx":
    $purl="/localxres/funx/anyjsshort/?stid=".$resmark."&pnum=30&page=1";
    break;
    case "funx":
    $purl="/localxres/pagex/1/funabout/6fkgeC7Y/WrvLoe/index.html?funid=".$resmark;
    break;
    default:
   }
   $rdru=$purl;
  break;
  case "edit":
   $vurl="/localxres/pagex/1/sysorg/RgHw9trO/Givnix/index.html?viewurl=";
   switch($restype){
    case "tempx":
    $purl="/localxres/tempx/".qian($resmark,".")."/".hou($resmark,".").".html";   
    break;
    case "pagex":
    $purl="/localxres/funx/anytiny/?tiny=".$resmark;
    break;
    case "formx":
    $purl="/localxres/funx/anyjsshort/?stid=".$resmark."&pnum=30&page=1";
    break;
    case "tabx":
    break;
    default:
   }
    $murl=makeviewurl($purl);
    $rdru=$vurl.$murl;
  break;
  case "detail":
  break;
  default:
}
header("location:".$rdru);
     session_write_close();
?>