<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $uid=$_GET["uid"];
$rcode=$_GET["rcode"];
$crmx=$rcode;
eval(CLASSX("workerchat"));
$wct=new workerchat();
$crmy=array();
$crmy=$wct->chatroomdft($crmx,$crmy);
$c2tab=$crmy["c2tab"];
$fstab=$crmy["fstab"];
$gstab=$crmy["gstab"];
$gltab=$crmy["gltab"];
$grtab=$crmy["grtab"];
$cptab=$crmy["cptab"];
$crtab=$crmy["crtab"];
$cutab=$crmy["cutab"];
$lbtab=$crmy["lbtab"];
$cltab=$crmy["cltab"];
$sdtab=$crmy["sdtab"];
$astab=$crmy["astab"];
$shtab=$crmy["shtab"];
$urst=SZ("select uname,uheadx,vxuid,unick,utel,usex,comid,udescrib,STCODE from ".$cutab." where uid='".$uid."'");
//echo "select uname,uheadx,vxuid,unick,utel,usex,comid,udescrib,STCODE from ".$cutab." where uid='".$uid."'";
$uname=anyvalue($urst,"uname",0);
$uheadx=anyvalue($urst,"uheadx",0);
$vxuid=anyvalue($urst,"vxuid",0);
$unick=anyvalue($urst,"unick",0);
$utel=anyvalue($urst,"utel",0);
$usex=anyvalue($urst,"usex",0);
$udescrib=anyvalue($urst,"udescrib",0);
$comid=anyvalue($urst,"comid",0);
$last3=tostring(anyvalue($urst,"STCODE",0));
$totu=countresult($urst);
if (intval($totu)>0){
  echo '{"status":"1","msg":"获取成功","uname":"'.$uname.'","uheadx":"'.$uheadx.'","vxuid":"'.$vxuid.'","unick":"'.$unick.'","utel":"'.$utel.'","usex":"'.$usex.'","comid":"'.$comid.'","udescrib":"'.$udescrib.'","last3":"'.$last3.'"}';
}else{
  $urst=SX("select realname,headpic,vxuid,nickname,phone,sex,wrdid,business,STCODE from coode_userlist where userid='".$uid."'");
   $uname=anyvalue($urst,"realname",0);
   $uheadx=anyvalue($urst,"headpic",0);
   $vxuid=anyvalue($urst,"vxuid",0);
   $unick=anyvalue($urst,"nickname",0);
   $utel=anyvalue($urst,"phone",0);
   $usex=anyvalue($urst,"sex",0);
   $udescrib=anyvalue($urst,"business",0);
   $comid=anyvalue($urst,"wrdid",0);
   $last3=tostring(anyvalue($urst,"STCODE",0));
   $totu=countresult($urst);
   if (intval($totu)>0){
    echo '{"status":"1","msg":"获取成功","uname":"'.$uname.'","uheadx":"'.$uheadx.'","vxuid":"'.$vxuid.'","unick":"'.$unick.'","utel":"'.$utel.'","usex":"'.$usex.'","comid":"'.$comid.'","udescrib":"'.$udescrib.'","last3":"'.$last3.'"}';
   }else{
    echo '{"status":"0","msg":"获取失败","uname":"","uheadx":"","vxuid":"","unick":"","utel":"","usex":"","comid":"","udescrib":"","last3":""}';
   }    
}
     session_write_close();
?>