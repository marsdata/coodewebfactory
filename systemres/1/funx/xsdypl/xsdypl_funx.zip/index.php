<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $title=$_POST["title"];
$url=$_POST["url"];
$plx=unstrs($_POST["plx"]);
$ply=explode(huanhang(),$plx);
$doumark=qian(hou($url,"video/"),"?");
$dv=_get("dv");
for ($jj=0;$jj<count($ply);$jj++){
  if (str_replace(" ","",$ply[$jj])!=""){
   $sqla="doumark,douurl,doutitle,pinglun,PRIME,CRTM,UPTM,OLMK,VRT,STCODE";
   $sqlb="'".$doumark."','".$url."','".$title."','".gohex($ply[$jj])."','".($jj+1)."',now(),now(),'".onlymark()."','".$dv."','".$dv."'";
   $zz=UX("insert into dou_pinglun(".$sqla.")values(".$sqlb.")");  
  }
}
$qq=UX("update dou_pinglun set UPTM=DATE_ADD(CRTM, INTERVAL 7*(PRIME-1) DAY)");
$qq=UX("update dou_pinglun set UPTM=DATE_ADD(CRTM, INTERVAL 200*(PRIME-1) MINUTE) where VRT='dv'");
$qq=UX("update dou_pinglun set STATUS=0,VRT='' where timestampdiff(DAY,CRTM,now())>=2 and VRT='dv' and STATUS=1");
echo makereturnjson("1","吸收成功","");
       session_write_close();
?>