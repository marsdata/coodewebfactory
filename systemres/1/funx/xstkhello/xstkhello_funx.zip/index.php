<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $userx=unstrs($_POST["userurl"]);
$hellox=unstrs($_POST["hellotxt"]);
$usery=explode(huanhang(),$userx);
$helloy=explode(huanhang(),$hellox);
$favo=$_POST["favo"];
$baktxt=$_POST["baktxt"];
$dv=_get("dv");
for ($jj=0;$jj<count($usery);$jj++){
  if (str_replace(" ","",$usery[$jj])!="" and str_replace(" ","",$helloy[$jj])!=""){
   $userz=explode(",",$usery[$jj]);
   $tkid=$userz[0];
   $tkmk=$userz[1];
   $tknk=$userz[2];
   $tkurl="https://www.tiktok.com/@".$tkmk;
   $sqla="tkid,tkmark,tkurl,gtitle,tknick,hellotxt,PRIME,CRTM,UPTM,OLMK,VRT,STCODE";
   $sqlb="'".$tkid."','".$tkmk."','".$tkurl."','".$favo."@".$baktxt."','".$tknk."','".gohex($helloy[$jj])."','".($jj+1)."',now(),now(),'".onlymark()."','".$dv."','".$dv."'";
   $zz=UX("insert into tk_hello(".$sqla.")values(".$sqlb.")");  
  }
}
$qq=UX("update tk_hello set UPTM=DATE_ADD(CRTM, INTERVAL 2*(PRIME-1) MINUTE)");
$qq=UX("update tk_hello set UPTM=DATE_ADD(CRTM, INTERVAL 100*(PRIME-1) MINUTE) where VRT='dv'");
$qq=UX("update tk_hello set STATUS=0,VRT='' where timestampdiff(DAY,CRTM,now())>=2 and VRT='dv' and STATUS=1");
echo makereturnjson("1","吸收成功","");
       session_write_close();
?>