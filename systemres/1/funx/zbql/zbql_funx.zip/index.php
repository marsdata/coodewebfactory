<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
          $insmark="clear@".date("Y-m-d");
   
   $uu=UX("update coode_domainunit set sysid='1' where sysid=''");
   $uu=UX("update coode_facelist set sysid='1' where sysid=''");
   $kk=UX("delete from coode_installdetail where insmark='".$insmark."'");
   $sqla="insmark,institle,host,sysid,OLMK,CRTOR,starttime,CRTM,UPTM";
   $sqlb="'".$insmark."','清理系统','','','".onlymark()."','".$_COOKIE[uid]."',now(),now(),now()";
   $ccc=UX("insert into coode_installidx(".$sqla.")values(".$sqlb.")");
   $uu=UX("update coode_tablist set sysid='' where sysid not in(select sysid from coode_sysinformation)");
   $sqla="host,insmark,institle,rescode,restype,restitle,vermd5,sysid,CRTM,UPTM,finishtime,OLMK";
   $sqlb="'localhost','".$insmark."','清理系统资源',resmark,restype,restitle,vermd5,grpid,CRTM,UPTM,now(),md5(RAND()*1000)";
   $nn=UX("insert into coode_installdetail(".$sqla.")select ".$sqlb." from coode_sysregres where restype!='tabx' and grpid not in(select sysid from coode_sysinformation)");
   
echo makereturnjson("1","清理准备成功","");
       session_write_close();
?>