<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
          $snox=$_GET["SNO"];
   
   $rstx=SX("select host,sysid,sysname from coode_hostregsys where SNO=".$snox);
   $host=anyvalue($rstx,"host",0);
   $sysid=anyvalue($rstx,"sysid",0);
   $sysname=anyvalue($rstx,"sysname",0);
   $insmark=$sysid."@xz@".date("Y-m-d");
   
   $sqla="insmark,institle,host,sysid,OLMK,CRTOR,CRTM,UPTM";
   $sqlb="'".$insmark."','卸载".$sysname."','".$host."','".$sysid."','".onlymark()."','".$_COOKIE[uid]."',now(),now()";
   $ccc=UX("insert into coode_installidx(".$sqla.")values(".$sqlb.")");
   
   $kk=UX("delete from coode_installdetail where insmark='".$insmark."'");
   $sqla="host,insmark,institle,rescode,restype,restitle,vermd5,thisver,sysid,CRTM,UPTM,finishtime,OLMK,STATUS";
   $sqlb="'".$host."','".$insmark."','".$sysname."',resmark,restype,restitle,vermd5,vermd5,grpid,now(),now(),now(),md5(RAND()*1000),0";
   $zz=UX("insert into coode_installdetail(".$sqla.")select ".$sqlb." from coode_sysregres where grpid='".$sysid."'");
   
   
   $visiturl="/localxres/tempx/multicmdrun/index.html?method=massunres&valstr=".$insmark."&way=quick";
   header("location:".$visiturl);
       session_write_close();
?>