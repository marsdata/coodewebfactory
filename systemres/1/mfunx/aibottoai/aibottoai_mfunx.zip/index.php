<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $datatype=dftval($_GET["datatype"],"");
$valstr=dftval($_GET["valstr"],"");
$ssmark=dftval($_GET["ssmark"],"");
$btabnm=$valstr."_chara";
$ctabnm=$valstr."_wrdresnmpoints";
$csql=constval("respoints");
$csql=str_replace("[restab]",$ctabnm,$csql);
$zz0=crttab(1,$csql);
$crtsql=constval("reschaval");
$crtsql=str_replace("[chatab]",$btabnm,$crtsql);
$zz1=crttab(1,$crtsql);
$trst=SX("select SNO,dbip,dbuser,dbpass,dbbase,dbtab,reskey,resttk from aibot_botlist where botcode='".$valstr."'");
   $srck=anyvalue($trst,"reskey",0);
   $srct=anyvalue($trst,"resttk",0);   
   $dbip=anyvalue($trst,"dbip",0);   
   $dbuser=anyvalue($trst,"dbuser",0);
   $dbpass=anyvalue($trst,"dbpass",0);
   $dbbase=anyvalue($trst,"dbbase",0);
   $dbtab=anyvalue($trst,"dbtab",0);
$demo='{"status":"1","totrcd":"[totrcd]","vls":[<data>]}';
$item='{"purl":"[purl]","ptitle":"[ptitle]"},';
$fma="";
     $tmptot=0;
     
     $callfunname="bottoaicha";
     $conn=mysql_connect($dbip,$dbuser,$dbpass);
     $trst=selecteds($conn,$dbbase,"select SNO,OLMK,CRTOR,STATUS,".$srck.",".$srct." from ".$dbtab." where STATUS=0 limit 0,1000","utf8","");
     $tot=countresult($trst);
     for ($i=0;$i<$tot;$i++){
       $snox=anyvalue($trst,"SNO",$i);
       $srcttx=anyvalue($trst,$srct,$i);
       $olmk=anyvalue($trst,"OLMK",$i);
       $urlx="/localxres/funx/".$callfunname."/?tabsno=".$snox."&botcode=".$valstr."&olmkx=".$olmk."&ssmarkx=".$ssmark;
       $titlex="正在将机器人资源".$srcttx."转为AI字符";
       $titlex=str_replace(huanhang(),"",$titlex);
       $titlex=str_replace("\r","",$titlex);
       $titlex=str_replace("\n","",$titlex);
       $olmkx=onlymark();
       $itemx=$item;
       $itemx=str_replace("[purl]",$urlx,$itemx);
       $itemx=str_replace("[ptitle]",$titlex,$itemx);
       
       $fma=$fma.$itemx;
       $tmptot=$tmptot+1;
     }
     if ($tot>0){
       $fma=killlaststr($fma);
     }
     $demo=str_replace("[totrcd]",$tot,$demo);
     $demo=str_replace("<data>",$fma,$demo);
       echo $demo;
   
     session_write_close();
?>