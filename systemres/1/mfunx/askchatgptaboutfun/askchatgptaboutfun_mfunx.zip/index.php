<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $datatype=dftval($_GET["datatype"],"");
$valstr=dftval($_GET["valstr"],"");
$demo='{"status":"1","totrcd":"[totrcd]","vls":[<data>]}';
$item='{"purl":"[purl]","ptitle":"[ptitle]"},';
$fma="";
$tmptot=0;
   $trst=SX("select SNO,funname,funfull from coode_funcool where funtype='single' and funbody=''");
   $tot=countresult($trst);
   for ($i=0;$i<$tot;$i++){
     $snox=anyvalue($trst,"SNO",$i);
     $fnm=anyvalue($trst,"funname",$i);
     $urlx="/localxres/funx/getdesfromgpt/?snox=".$snox;
     $titlex="正在从gpt获取函数描述，序号为".$snox."的".$fnm;
     $itemx=$item;
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;
   }
   if ($tot>0){
     $fma=killlaststr($fma);
   }
   if ($datatype==""){
     $demo=str_replace("<data>",$fma,$demo);
     $demo=str_replace("[totrcd]",$tmptot,$demo);
     echo $demo;
   }else{
     header("location:/localxres/tempx/multicmdrun/index.html?method=askchatgptaboutfun&valstr=".$valstr."&scd=1000");
   }
     session_write_close();
?>