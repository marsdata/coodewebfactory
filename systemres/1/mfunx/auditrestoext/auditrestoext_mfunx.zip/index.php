<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     function addtosession($ssmarkx,$vurl,$vtitle,$olmk){
  if (es($ssmarkx)*es($vurl)*es($vtitle)*es($olmk)==1){
   $sqlx="ssmark,visiturl,visittitle,CRTM,UPTM,OLMK";
   $sqly="'".$ssmarkx."','".$vurl."','".$vtitle."',now(),now(),'".$olmk."'";
   $zz=UX("insert into coode_multitask(".$sqlx.")values(".$sqly.")");
   return true;
  }else{
   return false;
  }
}
$datatype=dftval($_GET["datatype"],"");
$valstr=dftval($_GET["valstr"],"");
$ssmark=dftval($_GET["ssmark"],"");
$demo='{"status":"1","totrcd":"[totrcd]","vls":[<data>]}';
$item='{"purl":"[purl]","ptitle":"[ptitle]"},';
$fma="";
   $extb=UX("select count(*) as result from coode_multitask where ssmark='".$ssmark."'");
  if (intval($extb)==0){
   if ($ssmark!=""){
     $zzx=UX("update coode_resrelyext set STATUS=1 where (restype='pagex' or restype='tempx' or restype='formx') and relyrestp like '%funx%'");
     $zzy=UX("delete from coode_resrelyext where STATUS=0");
     $bktxt=file_get_contents(combineurl("http://".glw(),"/localxres/funx/sysallres/?datatype=json"));
     $bkdata=json_decode($bktxt,false);
     $tot=$bkdata->totrcd;
     $datax=$bkdata->vls;
     $sqla="ssmark,tottask,method,valstr,CRTM,UPTM,OLMK";
     $sqlb="'".$ssmark."',".$tot.",'".$method."','".$valstr."',now(),now(),'".onlymark()."'";
     $qq=UX("insert into coode_multitindex(".$sqla.")values(".$sqlb.")");
     
     for ($i=0;$i<$tot;$i++){
       $rtype=$datax[$i]->restype;
       $rcode=$datax[$i]->resmark;
       $rtitle=$datax[$i]->restitle;
       $olmkx=onlymark();      
       $urlx="/localxres/funx/auditthisres/?restype=".$rtype."&rescode=".$rcode."&olmkx=".$olmkx."&ssmarkx=".$ssmark;
       $titlex="正在审计".$rtitle."的主要关联资源";
       $zz=addtosession($ssmark,$urlx,$titlex,$olmkx);      
       $itemx=$item;
       $itemx=str_replace("[purl]",$urlx,$itemx);
       $itemx=str_replace("[ptitle]",$titlex,$itemx);
       $fma=$fma.$itemx;
     }
     if ($tot>0){
       $fma=killlaststr($fma);
     }
     if ($datatype==""){
       $demo=str_replace("<data>",$fma,$demo);
       $demo=str_replace("[totrcd]",$tot,$demo);
       echo $demo;
     }else{
       header("location:/localxres/tempx/multicmdrun/index.html?method=auditrestoext&valstr=".$valstr."&scd=1000");
     }     
    }else{
      echo makereturnjson("0","未获取到SESSIONMARK","");
    }
    
  }else{     
    $bktxt=anyshort("K7bDTK","1","9999");
    $bkdata=json_decode($bktxt,false);
    $tot=$bkdata->totrcd;
    $datax=$bkdata->vls;
    for ($i=0;$i<$tot;$i++){
      $urlx=$datax[$i]->visiturl;
      $titlex=$datax[$i]->visittitle;
      $itemx=$item;
      $itemx=str_replace("[purl]",$urlx,$itemx);
      $itemx=str_replace("[ptitle]",$titlex,$itemx);
      $fma=$fma.$itemx;
    }
    if ($tot>0){
      $fma=killlaststr($fma);
    }
    if ($datatype==""){
      $demo=str_replace("<data>",$fma,$demo);
      $demo=str_replace("[totrcd]",$tot,$demo);
      echo $demo;
    }else{
      header("location:/localxres/tempx/multicmdrun/index.html?method=auditrestoext&valstr=".$valstr."&scd=1000");
    }
  }
     session_write_close();
?>