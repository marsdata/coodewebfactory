<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $valstr=dftval($_GET["valstr"],"");
$sysid=qian($valstr,"@");
$taskmark=hou($valstr,"@");
 $demo='{"status":"1","totrcd":"[totrcd]","vls":[<data>]}';
 $demox='{"status":"1","totrcd":"[totrcd]","sysid":"[sysid]","systitle":"[systitle]","vls":[<data>]}';
 $item='{"purl":"[purl]","ptitle":"[ptitle]"},'; 
 $itemy='{"restype":"[restype]","rescode":"[rescode]","restitle":"[restitle]"},'; 
 $fma="";
 $fmb="";
 $a=time();
   $extx=UX("select count(*) as result from coode_sysresname where sysid='".$sysid."' and STCODE='".$taskmark."'");
   if (intval($extx)==0){
     $zz=UX("update coode_sysresname set STATUS=0,STCODE='".$taskmark."' where sysid='".$sysid."' and (restype='tab' or restype='temp' or restype='dspc' or restype='plot')");
   }
   $drst=SX("select SNO,restype,rescode,restitle from coode_sysresname where sysid='".$sysid."' and STATUS=0 and STCODE='".$taskmark."'");
   $totd=countresult($drst);
   if (intval($totd)>0){
     
     for ($m=0;$m<$totd;$m++){
        $snox=anyvalue($drst,"SNO",$m);
        $restype=anyvalue($drst,"restype",$m);        
        $rescode=anyvalue($drst,"rescode",$m);
        $restitle=anyvalue($drst,"restitle",$m);        
        $itemx=$item;
        $urlx="/DNA/EXF/anyfuns.php?fid=auditoneresver&rescode=".$rescode."&restype=".$restype."&fromsno=".$snox;
        $titlex="审计资源类型为".$restype."名".$restitle."的资源".$rescode."的版本";
        $itemx=str_replace("[purl]",$urlx,$itemx);
        $itemx=str_replace("[ptitle]",$titlex,$itemx);
        $itemz=$itemy;
        $itemz=str_replace("[restype]",$rtype,$itemz);
        $itemz=str_replace("[rescode]",$rescode,$itemz);
        $itemz=str_replace("[restitle]",$restitle,$itemz);
        $fma=$fma.$itemx;
        $fmb=$fmb.$itemz;
        $tmptot=$tmptot+1;     
     }     
        $itemx=$item;
        $urlx="/DNA/EXF/anyfuns.php?fid=auditoneresver&rescode=".$sysid."&restype=sys&fromsno=";
        $titlex="审计系统为".$sysid."的所有资源总版本";
        $itemx=str_replace("[purl]",$urlx,$itemx);
        $itemx=str_replace("[ptitle]",$titlex,$itemx);
        $itemz=$itemy;
        $itemz=str_replace("[restype]",$rtype,$itemz);
        $itemz=str_replace("[rescode]",$rescode,$itemz);
        $itemz=str_replace("[restitle]",$restitle,$itemz);
        $fma=$fma.$itemx;
        $fmb=$fmb.$itemz;
        $tmptot=$tmptot+1;     
    }else{
     echo makereturnjson("0","生成资源审计版本系统为".$sysid."的分布索引失败",($b-$a));
    }
    if ($tmptot>0){
      $fma=killlaststr($fma);
      $fmb=killlaststr($fmb);
    }
   $demox=str_replace("<data>",$fmb,$demox);
   $demox=str_replace("[totrcd]",$tmptot,$demox);
   $demox=str_replace("[systitle]",$ftitle,$demox);
   $demox=str_replace("[sysid]",$resmark,$demox);
   
   $fromdft=combineurl(localroot(),"/seeds/syss/default");
   $todft=combineurl(localroot(),"/seeds/syss/".$resmark);
   $bbd=copy_dir($fromdft,$todft);
   $wocao=overfile(combineurl(localroot(),"/seeds/syss/".$resmark."/index.json"),$demox);
if ($datatype==""){
   $demo=str_replace("<data>",$fma,$demo);
   $demo=str_replace("[totrcd]",$tmptot,$demo);
   echo $demo;
}else{
  header("location:/units/multicmdrun/index.html?method=restosys&valstr=".$sysid."@".$taskmark."&scd=500");
}
     session_write_close();
?>