<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '[relycore]';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $valstr=dftval($_GET["valstr"],"");
$demo='{"status":"1","totrcd":"[totrcd]","vls":[<data>]}';
$item='{"purl":"[purl]","ptitle":"[ptitle]"},';
$fma="";
$tmptot=0;
   $newnew=UX("update coode_funlist set STATUS=0");
   $newnew=UX("update coode_phpcls set STATUS=0");
   $trst=SX("select funname,funcname from coode_phpcls");
   $tot=countresult($trst);
   for ($i=0;$i<$tot;$i++){
     $setcode=anyvalue($trst,"funname",$i);     
     $settitle=anyvalue($trst,"funcname",$i);
     $urlx="/localxres/funx/setstosingle/?areatype=clsx&setcode=".$setcode;
     $titlex="正在对类".$settitle."集合中的参数进行统计";
     $itemx=$item;
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;
   }
   $trst=SX("select setname,setcname from coode_funsetfile");
   $tot=countresult($trst);
   for ($i=0;$i<$tot;$i++){
     $setcode=anyvalue($trst,"setname",$i);     
     $settitle=anyvalue($trst,"setcname",$i);
     $urlx="/localxres/funx/setstosingle/?areatype=sfunx&setcode=".$setcode;
     $titlex="正在对函数集".$settitle."集合中的参数进行统计";
     $itemx=$item;
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;
   }
     $urlx="/localxres/funx/setstosingle/?areatype=funx&setcode=default";
     $titlex="正在对扩展函数集合中的参数进行统计";
     $itemx=$item;
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;
     $urlx="/localxres/funx/setstosingle/?areatype=dfunx&setcode=default";
     $titlex="正在对数据函数集合中的参数进行统计";
     $itemx=$item;
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;
     $urlx="/localxres/funx/setstosingle/?areatype=mfunx&setcode=default";
     $titlex="正在对分布函数集合中的参数进行统计";
     $itemx=$item;
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;
     $urlx="/localxres/funx/setstosingle/?areatype=afunx&setcode=default";
     $titlex="正在对事务函数集合中的参数进行统计";
     $itemx=$item;
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;
     $urlx="/localxres/funx/setstosingle/?areatype=bfunx&setcode=default";
     $titlex="正在对基础函数集合中的参数进行统计";
     $itemx=$item;
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;
   if ($tot>0){
     $fma=killlaststr($fma);
   }
   
     $demo=str_replace("<data>",$fma,$demo);
     $demo=str_replace("[totrcd]",$tmptot,$demo);
     echo $demo;
   
       session_write_close();
?>