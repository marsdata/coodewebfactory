<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $valstr=dftval($_GET["valstr"],"");
//执行完毕之后；等几秒钟继续重新执行；从index获取无任务跳转地址
$mftitle="任务标题";
$mfurl="";//跳转地址
$demo='{"status":"1","tasktitle":"'.$mftitle.'","rurl":"'.$mfurl.'","totrcd":"[totrcd]","vls":[<data>]}';
$item='{"purl":"[purl]","ptitle":"[ptitle]"},';
$fma="";
     $tmptot=0;
     
     $tabnmx="coode_domainunit";
     $callfunname="countcss";
     $trst=SX("select SNO,dumark,unittitle,OLMK,CRTOR,STATUS from ".$tabnmx." where STATUS=0");
     $tot=countresult($trst);
     if ($tot>0){
      $zz=UX("update coode_facelist set PRIME=0");
     }
     for ($i=0;$i<$tot;$i++){
       $snox=anyvalue($trst,"SNO",$i);
       $tempid=anyvalue($trst,"dumark",$i);
       $utitle=anyvalue($trst,"unittitle",$i);
       $urlx="/localxres/funx/".$callfunname."/?snox=".$snox."&tempid=".$tempid."&ssmarkx=".$ssmark;
       $titlex="正在统计".$utitle."的引用次数";
       $olmkx=onlymark();
       $itemx=$item;
       $itemx=str_replace("[purl]",$urlx,$itemx);
       $itemx=str_replace("[ptitle]",$titlex,$itemx);
        
       $fma=$fma.$itemx;
       $tmptot=$tmptot+1;
     }
      if ($tot>0){
        $fma=killlaststr($fma);
      }
      $demo=str_replace("<data>",$fma,$demo);
      $demo=str_replace("[totrcd]",$tmptot,$demo);
      echo $demo;

     session_write_close();
?>