<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $valstr=dftval($_GET["valstr"],"");
$sysid=$valstr;
 $demo='{"status":"1","totrcd":"[totrcd]","vls":[<data>]}';
 $demox='{"status":"1","totrcd":"[totrcd]","sysid":"[sysid]","systitle":"[systitle]","vls":[<data>]}';
 $item='{"purl":"[purl]","ptitle":"[ptitle]"},'; 
 $itemy='{"restype":"[restype]","rescode":"[rescode]","restitle":"[restitle]"},'; 
 $fma="";
 $fmb="";
 $a=time();
   $drst=SX("select SNO,funname,funcname from coode_funlist where sysid='".$sysid."' and PRIME=0");
   $totd=countresult($drst);
   if (intval($totd)>0){     
     for ($m=0;$m<$totd;$m++){
        $snox=anyvalue($drst,"SNO",$m);
        $funnm=anyvalue($drst,"funname",$m);        
        $funtitle=anyvalue($drst,"funtitle",$m);        
        $itemx=$item;
        $urlx="/DNA/EXF/anyfuns.php?fid=savefuntofile&funsno=".$snox."&fromsno=".$snox;
        $titlex="将函数".$funtitle."转成文件";
        $itemx=str_replace("[purl]",$urlx,$itemx);
        $itemx=str_replace("[ptitle]",$titlex,$itemx);
        $itemz=$itemy;
        $itemz=str_replace("[restype]",$rtype,$itemz);
        $itemz=str_replace("[rescode]",$rescode,$itemz);
        $itemz=str_replace("[restitle]",$restitle,$itemz);
        $fma=$fma.$itemx;
        $tmptot=$tmptot+1;     
     }     
        
    }else{
     echo makereturnjson("0","生成函数转换索引失败",($b-$a));
    }
    if ($tmptot>0){
      $fma=killlaststr($fma);      
    }
   
if ($datatype==""){
   $demo=str_replace("<data>",$fma,$demo);
   $demo=str_replace("[totrcd]",$tmptot,$demo);
   echo $demo;
}else{
  header("location:/localxres/tempx/multicmdrun/index.html?method=makefuntofile&valstr=".$valstr."&scd=1000");
}
     session_write_close();
?>