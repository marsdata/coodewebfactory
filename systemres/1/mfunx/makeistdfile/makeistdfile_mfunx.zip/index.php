<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $datatype=dftval($_GET["datatype"],"");
$valstr=dftval($_GET["valstr"],"");
$demo='{"status":"1","totrcd":"[totrcd]","vls":[<data>]}';
$item='{"purl":"[purl]","ptitle":"[ptitle]"},';
$fma="";
$tmptot=0;
   if ($valstr==""){
     $trst=SX("select SNO,sqlmd5,restype,rescode from coode_resrelyinst where sysid='0' or sysid='1' order by strtype");
   }else{
     $trst=SX("select SNO,sqlmd5,restype,rescode from coode_resrelyinst where sysid='0' or sysid='1' or sysid='".$valstr."' order by strtype");
   }
   $tot=countresult($trst);
   for ($i=0;$i<$tot;$i++){
     $snox=anyvalue($trst,"SNO",$i);
     $sqlmd5=anyvalue($trst,"sqlmd5",$i);
     $urlx="/localxres/funx/makeidfile/?sqlmd5=".$sqlmd5."&sqx=".$i."&sysid=".$valstr;
     $titlex="正在制作编号为".$i."编码".$sqlmd5."安装数据文件";
     $itemx=$item;
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;
   }
   if ($tot>0){
     $fma=killlaststr($fma);
   }
   if ($datatype==""){
     $demo=str_replace("<data>",$fma,$demo);
     $demo=str_replace("[totrcd]",$tmptot,$demo);
     echo $demo;
   }else{
     header("location:/localxres/tempx/multicmdrun/index.html?method=makeistdfile&valstr=".$valstr."&scd=1000");
   }
     session_write_close();
?>