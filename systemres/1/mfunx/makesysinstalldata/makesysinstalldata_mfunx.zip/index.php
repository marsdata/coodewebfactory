<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $datatype=dftval($_GET["datatype"],"");
$valstr=dftval($_GET["valstr"],"");
$sysid=$valstr;
$demo='{"status":"1","totrcd":"[totrcd]","vls":[<data>]}';
$item='{"purl":"[purl]","ptitle":"[ptitle]"},';
$fma="";
$tmptot=0;
  $zz=UX("delete from coode_resrelyext  where relyrescd='.'");
  $zz=UX("delete from coode_resrelyext  where relyrescd like '%$%' ");
  $zz=UX("update coode_resrelyext set OPRT='single' where relyrestp='sfunx' and relyrescd in(select funname from coode_funcool where areatype='sfunx')");
  $qq=UX("insert into coode_sysresname(sysid,restype,rescode,restitle,CRTM,UPTM,OLMK)select '".$sysid."',relyrestp,relyrescd,relyrestitle,CRTM,UPTM,OLMK from coode_resrelyext where restype='sysx' and rescode='".$sysid."' and relyrestp!='bfunx' and OPRT!='single' and concat('".$sysid."',relyrestp,relyrescd) not in (select concat(sysid,restype,rescode) from coode_sysresname)");
  $qq=UX("delete from from coode_sysresname where  concat(sysid,restype,rescode) not in (select concat(rescode,relyrestp,relyrescd) from coode_resrelyext where rescode='".$sysid."')");
  //sysresname是用来做资源版本及访问统计的
   $trst=SX("select SNO,relyrestp,relyrescd,relyrestitle from coode_resrelyext where restype='sysx' and rescode='".$sysid."' and relyrestp!='bfunx' and OPRT!='single'");
   $tot=countresult($trst);
   for ($i=0;$i<$tot;$i++){
     $snox=anyvalue($trst,"SNO",$i);  
     $relyrestp=anyvalue($trst,"relyrestp",$i);     
     $relyrescd=anyvalue($trst,"relyrescd",$i);
     $relyrestitle=anyvalue($trst,"relyrestitle",$i);
     $urlx="/localxres/funx/makeresinstall/?sysid=".$valstr."&restype=".$relyrestp."&rescode=".$relyrescd;
     $titlex="正在对资源名".dftval($relyrestitle,$relyrescd)."进行数据制作";
     $itemx=$item;
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;
   }
   
   if ($tot>0){
     $fma=killlaststr($fma);
   }
   if ($datatype==""){
     $demo=str_replace("<data>",$fma,$demo);
     $demo=str_replace("[totrcd]",$tmptot,$demo);
     echo $demo;
   }else{
     header("location:/localxres/tempx/multicmdrun/index.html?method=makesysinstalldata&valstr=".$valstr."&scd=1000");
   }
     session_write_close();
?>