<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '[relycore]';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $valstr=dftval($_GET["valstr"],"");
if (strpos($valstr,"@")>0){
 $insmark=qian($valstr,"@")."@".date("Y-m-d");
 $cloud="1";
}else{
 $insmark=$valstr."@".date("Y-m-d");
 $cloud="";
}
//执行完毕之后；等几秒钟继续重新执行；从index获取无任务跳转地址
$mftitle="批量远程安装";
$mfurl="";//跳转地址
$demo='{"status":"1","tasktitle":"'.$mftitle.'","rurl":"'.$mfurl.'","totrcd":"[totrcd]","vls":[<data>]}';
$item='{"purl":"[purl]","ptitle":"[ptitle]"},';
$fma="";
     $tmptot=0;
     $tabnmx="coode_installdetail";
     if (strpos($valstr,"!")>0){
       $callfunname="installwrd";
     }else{
       $callfunname="installpod";
     }
     $zz=UX("update coode_installidx set starttime=now() where insmark='".$insmark."'");
     $trst=SX("select SNO,OLMK,CRTOR,STATUS,sysid,rescode,restitle,restype,host from ".$tabnmx." where STATUS=0 and vermd5!=thisver and insmark='".$insmark."'");
     $tot=countresult($trst);
     for ($i=0;$i<$tot;$i++){
       $snox=anyvalue($trst,"SNO",$i);
       $olmk=anyvalue($trst,"OLMK",$i);
       $sysid=anyvalue($trst,"sysid",$i);
       $rescode=anyvalue($trst,"rescode",$i);
       $restype=anyvalue($trst,"restype",$i);
       $restitle=anyvalue($trst,"restitle",$i);
       $host=anyvalue($trst,"host",$i);
       $urlx="/localxres/funx/".$callfunname."/?cloud=".$cloud."&restype=".$restype."&rescode=".$rescode."&fromhost=".$host."&sysid=".$sysid."&insmark=".$insmark;
       $titlex="正在远程安装".$restitle;
       $olmkx=onlymark();
       $itemx=$item;
       $itemx=str_replace("[purl]",$urlx,$itemx);
       $itemx=str_replace("[ptitle]",$titlex,$itemx);
        
       $fma=$fma.$itemx;
       $tmptot=$tmptot+1;
     }
      if ($tot>0){
        $fma=killlaststr($fma);
      }
      $demo=str_replace("<data>",$fma,$demo);
      $demo=str_replace("[totrcd]",$tmptot,$demo);
      echo $demo;

       session_write_close();
?>