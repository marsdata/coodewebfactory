<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $valstr=dftval($_GET["valstr"],"");
$restype=qian($valstr,"@");
$resmark=hou($valstr,"@");
$datatype=dftval($_GET["datatype"],"");
$method=$restype;
 $demo='{"status":"1","totrcd":"[totrcd]","vls":[<data>]}';
 $item='{"purl":"[purl]","ptitle":"[ptitle]"},'; 
 $fma="";
$a=time();
switch($restype){
   case "plot":
   $outpath=combineurl(localroot(),"/seeds/plots/");
   $tturl=combineurl(localroot(),"/seeds/plots/".$resmark."/");
   $frst=SX("select plotmark,markname from coode_plotlist where plotmark='".$resmark."'");
   $totf=countresult($frst);
   if (intval($totf)>0){
     $ftitle=anyvalue($frst,"markname",0);
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_plot"."&tabnm=coode_plotlist&pkey=plotmark&olmk=OLMK";
     $titlex="备份资源".$resmark."_plot表格为，coode_plotlist";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_plot"."&tabnm=coode_plotdetail&pkey=plotmark&olmk=OLMK";
     $titlex="备份资源".$resmark."_plot表格为，coode_plotdetail";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=saverestab&restype=".$restype."&resmark=".$resmark."_plot"."&tabnms=coode_plotdetail,coode_plotlist&ptitle=".$ftitle;
     $titlex="保存资源".$resmark."_plot表格为，coode_plotdetail,coode_plotlist";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;           
    }else{
     echo makereturnjson("0","生成节点为".$resmark."的种子失败",($b-$a));
    }
   break;
   case "fun":       
   $frst=SX("select funname,funcname,funfull from coode_funlist where funname='".$resmark."'");
   $totf=countresult($frst);
     if (intval($totf)>0){
      $ftitle=anyvalue($frst,"funcname",0);      
      $itemx=$item;
      $urlx="/DNA/EXF/anyfuns.php?fid=saverestab&restype=".$restype."&resmark=".$resmark."_fun"."&tabnms=coode_funlist&ptitle=".$ftitle;
      $titlex="保存资源".$resmark."_fun表格为，coode_funlist";
      $itemx=str_replace("[purl]",$urlx,$itemx);
      $itemx=str_replace("[ptitle]",$titlex,$itemx);
      $fma=$fma.$itemx;
      $tmptot=$tmptot+1;                 
     }else{
      echo makereturnjson("0","生成函数种子失败","");
     }
   break;
   case "cls":
   $frst=SX("select funname,funcname,funfull from coode_phpcls where funname='".$resmark."'");  
   $totf=countresult($frst);
   if (intval($totf)>0){
      $ftitle=anyvalue($frst,"funcname",0);
      $itemx=$item;
      $urlx="/DNA/EXF/anyfuns.php?fid=saverestab&resmark=".$resmark."_cls"."&tabnms=coode_phpcls&ptitle=".$ftitle;
      $titlex="保存资源".$resmark."_cls表格为，coode_phpcls";
      $itemx=str_replace("[purl]",$urlx,$itemx);
      $itemx=str_replace("[ptitle]",$titlex,$itemx);
      $fma=$fma.$itemx;
      $tmptot=$tmptot+1;
     }else{
      echo makereturnjson("0","生成类模块种子失败","");
     }
   break;
   case "temp":  
   $frst=SX("select unittitle,relyface,unitclass from coode_domainunit where dumark='".$resmark."'");
   $totf=countresult($frst);
   if (intval($totf)>0){
     $ftitle=anyvalue($frst,"unittitle",0);
     $relyface=anyvalue($frst,"relyface",0);
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_temp"."&tabnm=coode_domainunit&pkey=dumark&olmk=OLMK";
     $titlex="备份资源".$resmark."_temp表格为，coode_domainunit";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_temp"."&tabnm=coode_codedemo&pkey=dumark&olmk=OLMK";
     $titlex="备份资源".$resmark."_temp表格为，coode_codedemo";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_temp"."&tabnm=coode_makeformact&pkey=dumark&olmk=OLMK";
     $titlex="备份资源".$resmark."_temp表格为，coode_makeformact";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_temp"."&tabnm=coode_makedujsfile&pkey=dumark&olmk=OLMK";
     $titlex="备份资源".$resmark."_temp表格为，coode_makedujsfile";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakresfolder&resmark=".$resmark."_temp"."&folder=".$relyface;
     $titlex="备份资源".$resmark."_temp依赖样式为，".relyface;
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
      $itemx=$item;
      $urlx="/DNA/EXF/anyfuns.php?fid=saverestab&restype=".$restype."&resmark=".$resmark."_temp"."&tabnms=coode_domainunit,coode_codedemo,coode_makeformact,coode_makedujsfile&ptitle=".$ftitle;
      $titlex="保存资源".$resmark."_temp表格为，coode_domainunit,coode_codedemo,coode_makeformact,coode_makedujsfile";
      $itemx=str_replace("[purl]",$urlx,$itemx);
      $itemx=str_replace("[ptitle]",$titlex,$itemx);
      $fma=$fma.$itemx;
      $tmptot=$tmptot+1;
    }else{
      echo makereturnjson("0","生成模板为".$resmark."的种子失败",($b-$a));
    }
   break;
   case "tab":
   $frst=SX("select tabtitle,TABLE_NAME from coode_tablist where TABLE_NAME='".$resmark."'");
   $totf=countresult($frst);
   if (intval($totf)>0){
     $ftitle=anyvalue($frst,"tabtitle",0);
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_tab"."&tabnm=coode_tablist&pkey=TABLE_NAME&olmk=OLMK";
     $titlex="备份资源".$resmark."_tab表格为，coode_tablist";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_tab"."&tabnm=coode_keydetailx&pkey=TABLE_NAME&olmk=OLMK";
     $titlex="备份资源".$resmark."_tab表格为，coode_keydetailx";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_tab"."&tabnm=coode_keydetaily&pkey=TABLE_NAME&olmk=OLMK";
     $titlex="备份资源".$resmark."_tab表格为，coode_keydetaily";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_tab"."&tabnm=coode_keydetailz&pkey=TABLE_NAME&olmk=OLMK";
     $titlex="备份资源".$resmark."_tab表格为，coode_keydetailz";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_tab"."&tabnm=coode_shortdata&pkey=tablename&olmk=OLMK";
     $titlex="备份资源".$resmark."_tab表格为，coode_shortdata";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_tab"."&tabnm=coode_shortcss&pkey=tablename&olmk=OLMK";
     $titlex="备份资源".$resmark."_tab表格为，coode_shortcss";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
      $urlx="/DNA/EXF/anyfuns.php?fid=saverestab&restype=".$restype."&resmark=".$resmark."_tab"."&tabnms=coode_tablist,coode_keydetailx,coode_keydetaily,coode_keydetailz,coode_shortdata,coode_shortcss&ptitle=".$ftitle;
      $titlex="保存资源".$resmark."_temp表格为，coode_tablist,coode_keydetailx,coode_keydetaily,coode_keydetailz,coode_shortdata,coode_shortcss";
      $itemx=str_replace("[purl]",$urlx,$itemx);
      $itemx=str_replace("[ptitle]",$titlex,$itemx);
      $fma=$fma.$itemx;
      $tmptot=$tmptot+1;
    }else{
     echo makereturnjson("0","生成表格为".$resmark."的种子失败",($b-$a));
    }
   break;
  case "data":
   $frst=SX("select tabtitle,TABLE_NAME from coode_tablist where TABLE_NAME='".$resmark."'");
   $totf=countresult($frst);
   if (intval($totf)>0){
     $ftitle=anyvalue($frst,"tabtitle",0);
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_data"."&tabnm=coode_tablist&pkey=TABLE_NAME&olmk=OLMK";
     $titlex="备份资源".$resmark."_data表格为，coode_tablist";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_data"."&tabnm=coode_keydetailx&pkey=TABLE_NAME&olmk=OLMK";
     $titlex="备份资源".$resmark."_data表格为，coode_keydetailx";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_data"."&tabnm=coode_keydetaily&pkey=TABLE_NAME&olmk=OLMK";
     $titlex="备份资源".$resmark."_data表格为，coode_keydetaily";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_data"."&tabnm=coode_keydetailz&pkey=TABLE_NAME&olmk=OLMK";
     $titlex="备份资源".$resmark."_data表格为，coode_keydetailz";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_data"."&tabnm=coode_shortdata&pkey=tablename&olmk=OLMK";
     $titlex="备份资源".$resmark."_data表格为，coode_shortdata";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_data"."&tabnm=coode_shortcss&pkey=tablename&olmk=OLMK";
     $titlex="备份资源".$resmark."_data表格为，coode_shortcss";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."&tabnm=".$resmark."&pkey=&olmk=";
     $titlex="备份资源".$resmark."表格的所有数据";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
      $urlx="/DNA/EXF/anyfuns.php?fid=saverestab&restype=".$restype."&resmark=".$resmark."_data"."&tabnms=coode_tablist,coode_keydetailx,coode_keydetaily,coode_keydetailz,coode_shortdata,coode_shortcss&ptitle=".$ftitle;
      $titlex="保存资源".$resmark."_data表格为，coode_tablist,coode_keydetailx,coode_keydetaily,coode_keydetailz,coode_shortdata,coode_shortcss";
      $itemx=str_replace("[purl]",$urlx,$itemx);
      $itemx=str_replace("[ptitle]",$titlex,$itemx);
      $fma=$fma.$itemx;
      $tmptot=$tmptot+1;
    }else{
     echo makereturnjson("0","生成表格为".$resmark."的种子失败",($b-$a));
    }
   break;
   case "short":
    
   $frst=SX("select shorttitle,tablename from coode_shortdata where shortid='".$resmark."'");
   $totf=countresult($frst);
   if (intval($totf)>0){
     $ftitle=anyvalue($frst,"shorttitle",0);
     $tabname=anyvalue($frst,"tablename",0);
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_short"."&tabnm=coode_tablist&pkey=shortid&olmk=OLMK";
     $titlex="备份资源".$resmark."_short表格为，coode_tablist";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_short"."&tabnm=coode_shortdata&pkey=shortid&olmk=OLMK";
     $titlex="备份资源".$resmark."_short表格为，coode_shortdata";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_short"."&tabnm=coode_shortcss&pkey=shortid&olmk=OLMK";
     $titlex="备份资源".$resmark."_short表格为，coode_shortcss";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
      $urlx="/DNA/EXF/anyfuns.php?fid=saverestab&restype=".$restype."&resmark=".$resmark."_short"."&tabnms=coode_tablist,coode_shortdata,coode_shortcss&ptitle=".$ftitle;
      $titlex="保存资源".$resmark."_temp表格为，coode_tablist,coode_shortdata,coode_shortcss";
      $itemx=str_replace("[purl]",$urlx,$itemx);
      $itemx=str_replace("[ptitle]",$titlex,$itemx);
      $fma=$fma.$itemx;
      $tmptot=$tmptot+1;
    }else{
     echo makereturnjson("0","生成表单为".$resmark."的种子失败",($b-$a));
    }
   break;
   case "tiny":
   $frst=SX("select tinytitle,tinymark,tabname,shortid from coode_tiny where tinymark='".$resmark."'");
   $totf=countresult($frst);
   if (intval($totf)>0){
     $ftitle=anyvalue($frst,"tinytitle",0);
     $tabnm=anyvalue($frst,"tabname",0);
     $shortid=anyvalue($frst,"shortid",0);
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_tiny"."&tabnm=coode_tiny&pkey=tinymark&olmk=OLMK";
     $titlex="备份资源".$resmark."_tiny表格为，coode_tiny的资源数据";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     $itemx=$item;
     $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_tiny"."&tabnm=coode_unittiny&pkey=tinymark&olmk=OLMK";
     $titlex="备份资源".$resmark."_tiny表格为，coode_unittiny资源数据";
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;      
     
     if ($tabnm!="" and $shortid!=""){
       $itemx=$item;
       $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_tiny"."&tabnm=coode_tablist&pkey=TABLE_NAME&olmk=OLMK&resval=".$tabnm;
       $titlex="备份资源".$resmark."_tiny表格为，".$tabnm."的资源数据";
       $itemx=str_replace("[purl]",$urlx,$itemx);
       $itemx=str_replace("[ptitle]",$titlex,$itemx);
       $fma=$fma.$itemx;
       $tmptot=$tmptot+1;
       $itemx=$item;
       $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_tiny"."&tabnm=coode_shortdata&pkey=shortid&olmk=OLMK&resval=".$shortid;
       $titlex="备份资源".$resmark."_tiny表格为shortdata的资源数据，";
       $itemx=str_replace("[purl]",$urlx,$itemx);
       $itemx=str_replace("[ptitle]",$titlex,$itemx);
       $fma=$fma.$itemx;
       $tmptot=$tmptot+1;
       $itemx=$item;
       $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_tiny"."&tabnm=coode_shortcss&pkey=shortid&olmk=OLMK&resval=".$shortid;
       $titlex="备份资源".$resmark."_tiny表格为shortcss的资源数据，";
       $itemx=str_replace("[purl]",$urlx,$itemx);
       $itemx=str_replace("[ptitle]",$titlex,$itemx);
       $fma=$fma.$itemx;
       $tmptot=$tmptot+1;
       $itemx=$item;
       $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_tiny"."&tabnm=coode_keydetailx&pkey=TABLE_NAME&olmk=OLMK&resval=".$tabnm;
       $titlex="备份资源".$resmark."_tiny表格为coode_keydetailx的资源数据，";
       $itemx=str_replace("[purl]",$urlx,$itemx);
       $itemx=str_replace("[ptitle]",$titlex,$itemx);
       $fma=$fma.$itemx;
       $tmptot=$tmptot+1;
       $itemx=$item;
       $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_tiny"."&tabnm=coode_keydetaily&pkey=shortid&olmk=OLMK&resval=".$shortid;
       $titlex="备份资源".$resmark."_tiny表格为coode_keydetaily的资源数据，";
       $itemx=str_replace("[purl]",$urlx,$itemx);
       $itemx=str_replace("[ptitle]",$titlex,$itemx);
       $fma=$fma.$itemx;
       $tmptot=$tmptot+1;
       $itemx=$item;
       $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_tiny"."&tabnm=coode_keydetailz&pkey=shortid&olmk=OLMK&resval=".$shortid;
       $titlex="备份资源".$resmark."_tiny表格为coode_keydetailz的资源数据，";
       $itemx=str_replace("[purl]",$urlx,$itemx);
       $itemx=str_replace("[ptitle]",$titlex,$itemx);
       $fma=$fma.$itemx;
       $tmptot=$tmptot+1;
       $itemx=$item;
       $urlx="/DNA/EXF/anyfuns.php?fid=saverestab&restype=".$restype."&resmark=".$resmark."_tiny"."&tabnms=coode_tiny,coode_unittiny,coode_tablist,coode_shortdata,coode_shortcss,coode_keydetailx,coode_keydetaily,coode_keydetailz&ptitle=".$ftitle;
       $titlex="保存资源".$resmark."_tiny系列表格";
       $itemx=str_replace("[purl]",$urlx,$itemx);
       $itemx=str_replace("[ptitle]",$titlex,$itemx);
       $fma=$fma.$itemx;
       $tmptot=$tmptot+1;
     }else{
       $dumark=UX("select dumark as result from coode_unittiny where tinyid='".$resmark."'");
       $relyface=UX("select relyface as result from coode_domainunit where dumark='".$dumark."'");
       if ($dumark!=""){
          $itemx=$item;
          $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_tiny"."&tabnm=coode_domainunit&pkey=dumark&olmk=OLMK&resval=".$dumark;
          $titlex="备份资源".$resmark."_tiny表格为，coode_domainunit的资源数据";
          $itemx=str_replace("[purl]",$urlx,$itemx);
          $itemx=str_replace("[ptitle]",$titlex,$itemx);
          $fma=$fma.$itemx;
          $tmptot=$tmptot+1;
          $itemx=$item;
          $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_tiny"."&tabnm=coode_codedemo&pkey=dumark&olmk=OLMK&resval=".$dumark;
          $titlex="备份资源".$resmark."_tiny表格为coode_codedemo的资源数据，";
          $itemx=str_replace("[purl]",$urlx,$itemx);
          $itemx=str_replace("[ptitle]",$titlex,$itemx);
          $fma=$fma.$itemx;
          $tmptot=$tmptot+1;
          $itemx=$item;
          $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_tiny"."&tabnm=coode_makeformact&pkey=dumark&olmk=OLMK&resval=".$dumark;
          $titlex="备份资源".$resmark."_tiny表格为coode_makeformact的资源数据，";
          $itemx=str_replace("[purl]",$urlx,$itemx);
          $itemx=str_replace("[ptitle]",$titlex,$itemx);
          $fma=$fma.$itemx;
          $tmptot=$tmptot+1;
          $urlx="/DNA/EXF/anyfuns.php?fid=bakrestab&resmark=".$resmark."_tiny"."&tabnm=coode_makedujsfile&pkey=dumark&olmk=OLMK&resval=".$dumark;
          $titlex="备份资源".$resmark."_tiny表格为coode_makedujsfile的资源数据，";
          $itemx=str_replace("[purl]",$urlx,$itemx);
          $itemx=str_replace("[ptitle]",$titlex,$itemx);
          if ($relyface!=""){
           $itemx=$item;
           $urlx="/DNA/EXF/anyfuns.php?fid=bakresfolder&resmark=".$resmark."_tiny"."&folder=".$relyface;
           $titlex="备份资源".$resmark."_tiny依赖样式为，".relyface;
           $itemx=str_replace("[purl]",$urlx,$itemx);
           $itemx=str_replace("[ptitle]",$titlex,$itemx);
           $fma=$fma.$itemx;
           $tmptot=$tmptot+1;      
          }
          $itemx=$item;
          $urlx="/DNA/EXF/anyfuns.php?fid=saverestab&restype=".$restype."&resmark=".$resmark."_tiny"."&tabnms=coode_tiny,coode_unittiny,coode_domainunit,coode_codedemo,coode_makeformact,coode_makedujsfile&ptitle=".$ftitle;
          $titlex="保存资源".$resmark."_tiny系列表格";
          $itemx=str_replace("[purl]",$urlx,$itemx);
          $itemx=str_replace("[ptitle]",$titlex,$itemx);
          $fma=$fma.$itemx;
          $tmptot=$tmptot+1;
       }else{
          $itemx=$item;
          $urlx="/DNA/EXF/anyfuns.php?fid=saverestab&restype=".$restype."&resmark=".$resmark."_tiny"."&tabnms=coode_tiny,coode_unittiny&ptitle=".$ftitle;
          $titlex="保存资源".$resmark."_tiny系列表格";
          $itemx=str_replace("[purl]",$urlx,$itemx);
          $itemx=str_replace("[ptitle]",$titlex,$itemx);
          $fma=$fma.$itemx;
          $tmptot=$tmptot+1;
    
       }
     }
      
      
    }else{
     echo makereturnjson("0","生成短地址为".$resmark."的种子失败",($b-$a));
    }
   break;
   default:
}
    if ($tmptot>0){
      $fma=killlaststr($fma);
    }
if ($datatype==""){
   $demo=str_replace("<data>",$fma,$demo);
   $demo=str_replace("[totrcd]",$tmptot,$demo);
   echo $demo;
}else{
  header("location:/units/multicmdrun/index.html?method=multisaveseed&valstr=".$restype."@".$resmark."&scd=10000");
}
     session_write_close();
?>