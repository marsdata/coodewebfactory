<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $valstr=dftval($_GET["valstr"],"");
//执行完毕之后；等几秒钟继续重新执行；从index获取无任务跳转地址
$wtprst=SX("select linemark,mainpickey,apicode from coode_wrdrestpdefine where typecodex='".$valstr."'");
$ptabnm=anyvalue($wtprst,"linemark",0);
$apicode=anyvalue($wtprst,"apicode",0);
$ptabkey=anyvalue($wtprst,"mainpickey",0);
$crtsql=constval("bdrespictab");
$crtsql=str_replace("[bdpictab]",$ptabnm."_bdrespic",$crtsql);
$zz1=crttab(1,$crtsql);
$trst=SX("select SNO,restpcode,contentkeys,srckey,srcttk from coode_tablist where TABLE_NAME='".$ptabnm."'");
   $srck=anyvalue($trst,"srckey",0);
   $srct=anyvalue($trst,"srcttk",0);   
$mftitle="上传资源名为".$valstr."的图片到百度识别";
$mfurl="";
$demo='{"status":"1","tasktitle":"'.$mftitle.'","rurl":"'.$mfurl.'","totrcd":"[totrcd]","vls":[<data>]}';
$item='{"purl":"[purl]","ptitle":"[ptitle]"},';
$fma="";
     $tmptot=0;
     $tabnmx=$ptabnm;
     $callfunname="tabtobdpic";
     $trst=SX("select SNO,OLMK,CRTOR,STATUS,".$srct.",".$ptabkey." from ".$tabnmx." where STATUS=0");
     $tot=countresult($trst);
     $sqla="ssmark,tottask,CRTM,UPTM,OLMK";
     $sqlb="'".$ssmark."',".$tot.",now(),now(),'".onlymark()."'";
     for ($i=0;$i<$tot;$i++){
       $snox=anyvalue($trst,"SNO",$i);
       $olmk=anyvalue($trst,"OLMK",$i);
       $rtitle=anyvalue($trst,$srct,$i);
       $urlx="/localxres/funx/".$callfunname."/?apicode=".$apicode."&tabsno=".$snox."&tabnm=".$tabnmx."&tabkey=".$ptabkey."&restype=".$valstr;
       $titlex="正在为".$rtitle."上传到百度识别";
       $olmkx=onlymark();
       $itemx=$item;
       $itemx=str_replace("[purl]",$urlx,$itemx);
       $itemx=str_replace("[ptitle]",$titlex,$itemx);
        
       $fma=$fma.$itemx;
       $tmptot=$tmptot+1;
     }
      if ($tot>0){
        $fma=killlaststr($fma);
      }
      $demo=str_replace("<data>",$fma,$demo);
      $demo=str_replace("[totrcd]",$tmptot,$demo);
      echo $demo;

     session_write_close();
?>