<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
        $method=dftval($_GET["method"],"");
   $valstr=dftval($_GET["valstr"],"");
   $demo='{"status":"1","totrcd":"[totrcd]","vls":[<data>]}';
   $item='{"purl":"[purl]","ptitle":"[ptitle]"},';
   $fma="";
   $imgcls=SX("select imgmark,imgtitle from coode_igrpitem where grpmark='imgcls'");
   $toti=countresult($imgcls);
   for ($j=0;$j<$toti;$j++){
     $imark=anyvalue($imgcls,"imgmark",$j);
     $ititle=anyvalue($imgcls,"imgtitle",$j);
     $lcpath=combineurl(localroot(),"/IMG/".$imark);
     is_dir($lcpath) OR mkdir($lcpath, 0777, true);
     $urlx="/DNA/EXF/anyfuns.php?fid=foldertree&ddd="."/IMG/".$imark;
     $titlex="为".$ititle."目录图片进行识别操作";
     $itemx=$item;
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
   }
   $urlx="/DNA/EXF/anyfuns.php?fid=mkimagefolder";
   $titlex="将识别结果转储数据库";
   $itemx=$item;
   $itemx=str_replace("[purl]",$urlx,$itemx);
   $itemx=str_replace("[ptitle]",$titlex,$itemx);
   $fma=$fma.$itemx;
    if ($totp>0){
      $fma=killlaststr($fma);
    }
   $demo=str_replace("<data>",$fma,$demo);
   $demo=str_replace("[totrcd]",$toti,$demo);
   echo $demo;
     session_write_close();
?>