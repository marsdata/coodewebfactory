<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      if ($_GET["runerr"]=="1"){
      }else{
       error_reporting(0);
       register_shutdown_function('zyfshutdownfunc'); 
       set_error_handler('zyferror'); 
      }
      include '[relycore]';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $valstr=dftval($_GET["valstr"],"");
//执行完毕之后；等几秒钟继续重新执行；从index获取无任务跳转地址
$mftitle="任务标题";
$mfurl="";//跳转地址
if ( glm()=="motherhost"){
     $ptnm="GITHUB";
     $sysidx=qian($valstr,"@");
     $ff=combineurl(localroot(),"/systemres/".$sysidx."/".$sysidx.".json");
     $zz1=overfile($ff,anyfunrun("anyshort","","stid=GJXex0&pnum=9999&page=1&grpid=".$sysidx,""));
     $bb=anyfunrun("gitupsecond","","apicode=coodegit&filepath=".$ff,"");
     
}else{
   $sysidx=qian($valstr,"@");
   $ptnm="七牛云";
   $qnytxt=anyfunrun("getqnyapi",glm(),"","");
   $qnyjson=json_decode($qnytxt,false);
   $apistr=$qnyjson->msg;
   $dmhost=$qnyjson->redirect;
   $url1=combineurl(localroot(),"/systemres/".$valstr."/".$valstr.".json");
   $zz1=overfile($url1,anyfunrun("anyshort","","stid=GJXex0&pnum=9999&page=1&grpid=".$valstr,""));
   $tt=anyfunrun("tellmysys","","sysid=".$valstr,"");
   $first=anyfunrun("upresbyqny","","apistr=".$apistr."&qndm=".$dmhost."&lcfile=".$url1,"");
   
    $restxt=anyfunrun("anyshort","","stid=yoN6rx&pnum=9999&page=1","");
    $qnypath=combineurl(localroot(),"/localxres/sysmap.json");
    $zz=overfile($qnypath,$restxt);
    $installpodtxt=file_get_contents(combineurl(localroot(),"localxres/tempx/runingbox/installfld.php"));
    $inspath=combineurl(localroot(),"/localxres/installfld.txt");
    $zz=overfile($inspath,$installpodtxt);
    $earthtxt=file_get_contents(combineurl(localroot(),"/localxres/EARTH.php"));
    $qnyearth=combineurl(localroot(),"/localxres/earth.txt");
    $zz=overfile($qnyearth,$earthtxt);
    $indextxt=file_get_contents(combineurl(localroot(),"index.php"));
    $qnyindex=combineurl(localroot(),"/localxres/index.txt");
    $zz=overfile($qnyindex,$indextxt);
    $tabtxt=file_get_contents(combineurl(localroot(),"/systemres/v/basetab.json"));
    $qnytab=combineurl(localroot(),"/localxres/basetab.json");
    $zz=overfile($qnytab,$tabtxt);
    $udfntxt=file_get_contents(combineurl(localroot(),"/localxres/USERDEFINE.php"));
    $dfttxt=$udfntxt;
    $dfttxt=str_replace('function bl(){return "'.bl(),'function bl(){return "[bdip]',$dfttxt);
    $dfttxt=str_replace('function blu(){return "'.blu(),'function blu(){return "[bduser]',$dfttxt);
    $dfttxt=str_replace('function blp(){return "'.blp(),'function blp(){return "[bdpass]',$dfttxt);
    $dfttxt=str_replace('function blb(){return "'.blb(),'function blb(){return "[bdbase]',$dfttxt);
                    $earthtxta=$dfttxt;
                    $earthtxta=str_replace('function gl(){return "'.gl(),'function gl(){return "[fip]',$earthtxta);
                    $earthtxta=str_replace('function glu(){return "'.glu(),'function glu(){return "[fuser]',$earthtxta);
                    $earthtxta=str_replace('function glp(){return "'.glp(),'function glp(){return "[fpass]',$earthtxta);
                    $earthtxta=str_replace('function glb(){return "'.glb(),'function glb(){return "[fbase]',$earthtxta);
                    $earthtxta=str_replace('function gln(){return "'.gln(),'function gln(){return "[sysid]',$earthtxta);
                    $earthtxta=str_replace('function gla(){return "'.gla(),'function gla(){return "[rcode]',$earthtxta);
                    $earthtxta=str_replace('function glv(){return "'.glv(),'function glv(){return "[vcode]',$earthtxta);
                    $earthtxta=str_replace('function glm(){return "'.glm(),'function glm(){return "[mhost]',$earthtxta);
                    $earthtxta=str_replace('function glt(){return "'.glt(),'function glt(){return "[sysnm]',$earthtxta);
                    $earthtxta=str_replace('function glr(){return "'.glr(),'function glr(){return "[siteid]',$earthtxta);
                    $earthtxta=str_replace('function hostcode(){return "'.hostcode(),'function hostcode(){return "[sitecode]',$earthtxta);
                    $earthtxta=str_replace('function garea(){return "'.garea(),'function garea(){return "[qnycode]',$earthtxta);
    $qnydft=combineurl(localroot(),"/localxres/userdefine.txt");
    $zz=overfile($qnydft,$earthtxta);
    
    $second=anyfunrun("upresbyqny","","apistr=".$apistr."&qndm=".$dmhost."&lcfile=".$qnypath,"");
    $third=anyfunrun("upresbyqny","","apistr=".$apistr."&qndm=".$dmhost."&lcfile=".$qnyearth,"");
    $fourth=anyfunrun("upresbyqny","","apistr=".$apistr."&qndm=".$dmhost."&lcfile=".$qnyindex,"");
    $fifth=anyfunrun("upresbyqny","","apistr=".$apistr."&qndm=".$dmhost."&lcfile=".$qnytab,"");
    $sixth=anyfunrun("upresbyqny","","apistr=".$apistr."&qndm=".$dmhost."&lcfile=".$inspath,"");
    $seventh=anyfunrun("upresbyqny","","apistr=".$apistr."&qndm=".$dmhost."&lcfile=".$qnydft,"");
    
    $bkjson=json_decode($seventh,false);
    if (intval($bkjson->status)==1){
      unlink($qnydft);
      unlink($qnyearth);
      unlink($qnyindex);
      unlink($qnytab);
      unlink($inspath);
      unlink($qnypath);
    }
}
$demo='{"status":"1","valstr":"'.$valstr.'","tasktitle":"'.$mftitle.'","rurl":"'.$mfurl.'","totrcd":"[totrcd]","vls":[<data>]}';
$item='{"purl":"[purl]","ptitle":"[ptitle]"},';
$fma="";
     $tmptot=0;
     $tabnmx="coode_sysregres";
     $callfunname="uprestoqny";
     $trst=SX("select SNO,grpid,restype,resmark,restitle,OLMK,CRTOR,STATUS from ".$tabnmx." where grpid='".$sysidx."' and STATUS=1");
     $tot=countresult($trst);
     for ($i=0;$i<$tot;$i++){
       $snox=anyvalue($trst,"SNO",$i);
       $olmk=anyvalue($trst,"OLMK",$i);
       $sysid=anyvalue($trst,"grpid",$i);
       $restype=anyvalue($trst,"restype",$i);
       $rescode=anyvalue($trst,"resmark",$i);
       $restitle=anyvalue($trst,"restitle",$i);
       $urlx="/localxres/funx/".$callfunname."/?sysid=".$sysid."&restype=".$restype."&rescode=".$rescode."&snox=".$snox."&olmkx=".$olmk."&ssmarkx=".$ssmark;
       $titlex="正在将类型为".$restype."的".$restitle."上传到".$ptnm;
       $olmkx=onlymark();
       $itemx=$item;
       $itemx=str_replace("[purl]",$urlx,$itemx);
       $itemx=str_replace("[ptitle]",$titlex,$itemx);
        
       $fma=$fma.$itemx;
       $tmptot=$tmptot+1;
     }
      if ($tot>0){
        $fma=killlaststr($fma);
      }
      $demo=str_replace("<data>",$fma,$demo);
      $demo=str_replace("[totrcd]",$tmptot,$demo);
      echo $demo;

       session_write_close();
?>