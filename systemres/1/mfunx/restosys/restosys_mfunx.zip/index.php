<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $valstr=dftval($_GET["valstr"],"");
$restype=qian($valstr,"@");
$resmark=hou($valstr,"@");
$datatype=dftval($_GET["datatype"],"");
$method=$restype;
 $demo='{"status":"1","totrcd":"[totrcd]","vls":[<data>]}';
 $demox='{"status":"1","totrcd":"[totrcd]","sysid":"[sysid]","systitle":"[systitle]","vls":[<data>]}';
 $item='{"purl":"[purl]","ptitle":"[ptitle]"},'; 
 $itemy='{"restype":"[restype]","rescode":"[rescode]","restitle":"[restitle]"},'; 
 $fma="";
 $fmb="";
$a=time();
   $drst=SX("select SNO,appid,layid,resmark,restype,restitle from coode_seeds where sysid='".$resmark."'");
   $totd=countresult($drst);
   if (intval($totf)>0){
     $ftitle=UX("select systitle as result from coode_sysinformation where sysid='".$resmark."'");               
     for ($m=0;$m<$totd;$m++){
        $snox=anyvalue($drst,"SNO",$m);
        $appid=anyvalue($drst,"appid",$m);
        $layid=anyvalue($drst,"layid",$m);
        $rescode=anyvalue($drst,"resmark",$m);
        $rtype=anyvalue($drst,"restype",$m);
        $restitle=anyvalue($drst,"restitle",$m);        
        $itemx=$item;
        $urlx="/DNA/EXF/anyfuns.php?fid=makerestosys&rescode=".$rescode."&restype=".$rtype;
        $titlex="转储系统为".$resmark."的资源".$rescode."目录";
        $itemx=str_replace("[purl]",$urlx,$itemx);
        $itemx=str_replace("[ptitle]",$titlex,$itemx);
        $itemz=$itemy;
        $itemz=str_replace("[restype]",$rtype,$itemz);
        $itemz=str_replace("[rescode]",$rescode,$itemz);
        $itemz=str_replace("[restitle]",$restitle,$itemz);
        $fma=$fma.$itemx;
        $fmb=$fmb.$itemz;
        $tmptot=$tmptot+1;     
     }     
    }else{
     echo makereturnjson("0","生成资源转储节点为".$resmark."的索引失败",($b-$a));
    }
    if ($tmptot>0){
      $fma=killlaststr($fma);
      $fmb=killlaststr($fmb);
    }
   $demox=str_replace("<data>",$fmb,$demox);
   $demox=str_replace("[totrcd]",$tmptot,$demox);
   $demox=str_replace("[systitle]",$ftitle,$demox);
   $demox=str_replace("[sysid]",$resmark,$demox);
   
   $fromdft=combineurl(localroot(),"/seeds/syss/default");
   $todft=combineurl(localroot(),"/seeds/syss/".$resmark);
   $bbd=copy_dir($fromdft,$todft);
   $wocao=overfile(combineurl(localroot(),"/seeds/syss/".$resmark."/index.json"),$demox);
if ($datatype==""){
   $demo=str_replace("<data>",$fma,$demo);
   $demo=str_replace("[totrcd]",$tmptot,$demo);
   echo $demo;
}else{
  header("location:/units/multicmdrun/index.html?method=restosys&valstr=".$restype."@".$resmark."&scd=500");
}
     session_write_close();
?>