<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $datatype=dftval($_GET["datatype"],"");
$valstr=dftval($_GET["valstr"],"");
//执行完毕之后；等几秒钟继续重新执行；从index获取无任务跳转地址
$mmk=dftval($_GET["mmk"],"");
$rstx=SX("select mulftitle,runurl from coode_multifunindex where mulfmark='".$mmk."'");
$mftitle=anyvalue($rstx,"mulftitle",0);
$mfurl=anyvalue($rstx,"runurl",0);
$demo='{"status":"1","tasktitle":"'.$mftitle.'","rurl":"'.$mfurl.'","totrcd":"[totrcd]","vls":[<data>]}';
$demo='{"status":"1","totrcd":"[totrcd]","vls":[<data>]}';
$item='{"purl":"[purl]","ptitle":"[ptitle]"},';
$fma="";
     $tmptot=0;
     $tabnmx="coode_cssthis";
     $callfunname="downcssfh";
     $trst=SX("select SNO,restitle,OLMK,CRTOR,STATUS from ".$tabnmx." where isin=0");
     $tot=countresult($trst);
     $sqla="ssmark,tottask,CRTM,UPTM,OLMK";
     $sqlb="'".$ssmark."',".$tot.",now(),now(),'".onlymark()."'";
     $qq=UX("insert into coode_multitindex(".$sqla.")values(".$sqlb.")");
     for ($i=0;$i<$tot;$i++){
       $snox=anyvalue($trst,"SNO",$i);
       $olmk=anyvalue($trst,"OLMK",$i);
       $rtitle=anyvalue($trst,"restitle",$i);
       $urlx="/localxres/funx/".$callfunname."/?SNO=".$snox."&olmkx=".$olmk."&ssmarkx=".$ssmark;
       $titlex="下载".$rtitle;
       $olmkx=onlymark();
       $itemx=$item;
       $itemx=str_replace("[purl]",$urlx,$itemx);
       $itemx=str_replace("[ptitle]",$titlex,$itemx);
       $zz=addtosession($ssmark,$snox,$urlx,$titlex,$olmkx);      
       $fma=$fma.$itemx;
       $tmptot=$tmptot+1;
     }
     if ($tot>0){
       $fma=killlaststr($fma);
     }
       $demo=str_replace("<data>",$fma,$demo);
       $demo=str_replace("[totrcd]",$tmptot,$demo);
       echo $demo;

     session_write_close();
?>