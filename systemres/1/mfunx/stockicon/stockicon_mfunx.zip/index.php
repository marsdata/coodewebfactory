<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
        $method=dftval($_GET["method"],"");
   $valstr=dftval($_GET["valstr"],"");
   $demo='{"status":"1","totrcd":"[totrcd]","vls":[<data>]}';
   $item='{"purl":"[purl]","ptitle":"[ptitle]"},'; 
   $fma="";
   $trst=SX("select SNO,svgmark from coode_tinyimg where STATUS=0 and svgfrom<>''");
   $tot=countresult($trst);
   for ($i=0;$i<$tot;$i++){
     $snox=anyvalue($trst,"SNO",$i);
     $svgmk=anyvalue($trst,"svgmark",$i);
     $urlx="/DNA/EXF/anyfuns.php?fid=stocksysicon&snox=".$snox;
     $titlex="为".$svgmk."图片进行下载操作";
     $itemx=$item;
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
   }
   if ($tot>0){
     $fma=killlaststr($fma);
   }
   $demo=str_replace("<data>",$fma,$demo);
   $demo=str_replace("[totrcd]",$tot,$demo);
   echo $demo;
     session_write_close();
?>