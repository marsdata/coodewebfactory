<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $method=dftval($_GET["method"],"");
$valstr=dftval($_GET["valstr"],"");
$demo='{"status":"1","totrcd":"[totrcd]","vls":[<data>]}';
$item='{"purl":"[purl]","ptitle":"[ptitle]"},';
$fma="";
   $grprst=SX("select grppath,grpmark from coode_imggrp where SNO=".$valstr);
   $grpmark=anyvalue($grprst,"grpmark",0);
   $plist=SX("select SNO,outpath,outurl,imgtitle,imgtype from coode_igrpitem where grpmark='".$grpmark."' and outpath<>'' and imgcode=''");   
   $totp=countresult($plist);
   for ($i=0;$i<$totp;$i++){
     $snox=anyvalue($plist,"SNO",$i);
     $outp=anyvalue($plist,"outpath",$i);
     $outu=anyvalue($plist,"outurl",$i);
     $itype=anyvalue($plist,"imgtype",$i);
     $ititle=anyvalue($plist,"imgtitle",$i);
     $urlx="/DNA/EXF/anyfuns.php?fid=stockimgtotab&imgpath=".$outp."&tabname=coode_igrpitem&tabkey=imgcode&itype=".$itype."&tabsno=".$snox;
     $titlex="为".$ititle."图片进行数据库存储操作";
     $itemx=$item;
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
   }
   if ($totp>0){
     $fma=killlaststr($fma);
   }
   $demo=str_replace("<data>",$fma,$demo);
   $demo=str_replace("[totrcd]",$totp,$demo);
   echo $demo;
     session_write_close();
?>