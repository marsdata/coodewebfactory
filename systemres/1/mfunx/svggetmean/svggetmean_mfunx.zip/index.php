<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $datatype=dftval($_GET["datatype"],"");
$valstr=dftval($_GET["valstr"],"");
$ssmark=dftval($_GET["ssmark"],"");
function addtosession($ssmarkx,$tsnox,$vurl,$vtitle,$olmk){
  $sqlx="ssmark,visiturl,visittitle,tasksno,CRTM,UPTM,OLMK";
  $sqly="'".$ssmarkx."','".$vurl."','".$vtitle."','".$tsnox."',now(),now(),'".$olmk."'";
  $zz=UX("insert into coode_multitask(".$sqlx.")values(".$sqly.")");
  return true;
}
$demo='{"status":"1","totrcd":"[totrcd]","vls":[<data>]}';
$item='{"purl":"[purl]","ptitle":"[ptitle]"},';
$fma="";
   $extb=UX("select count(*) as result from coode_multitask where ssmark='".$ssmark."'");
 if (intval($extb)==0){
   if ($ssmark!=""){
     $tmptot=0;
     $trst=SX("select SNO,STATUS,OLMK from coode_icons where STATUS=0");
     $tot=countresult($trst);
     $sqla="ssmark,tottask,CRTM,UPTM,OLMK";
     $sqlb="'".$ssmark."',".$tot.",now(),now(),'".onlymark()."'";
     $qq=UX("insert into coode_multitindex(".$sqla.")values(".$sqlb.")");
     for ($i=0;$i<$tot;$i++){
       $snox=anyvalue($trst,"SNO",$i);
       $olmk=anyvalue($trst,"OLMK",$i);
       $urlx="/localxres/funx/svgmeanning/?snox=".$snox."&olmkx=".$olmk."&ssmarkx=".$ssmark;
       $titlex="正在获取序号为".$snox."的SVG图片的意义";
       $olmkx=onlymark();
       $itemx=$item;
       $itemx=str_replace("[purl]",$urlx,$itemx);
       $itemx=str_replace("[ptitle]",$titlex,$itemx);
       $zz=addtosession($ssmark,$snox,$urlx,$titlex,$olmkx);      
       $fma=$fma.$itemx;
       $tmptot=$tmptot+1;
     }
     if ($tot>0){
       $fma=killlaststr($fma);
     }
     if ($datatype==""){
       $demo=str_replace("<data>",$fma,$demo);
       $demo=str_replace("[totrcd]",$tmptot,$demo);
       echo $demo;
     }else{
       header("location:/localxres/tempx/multicmdrun/index.html?method=svggetmean&valstr=".$valstr."&scd=1000");
     }
    }else{
      echo makereturnjson("0","缺少SESSIONMARK","");
    }
 }else{
   $bktxt=anyshort("K7bDTK","1","9999");
    $bkdata=json_decode($bktxt,false);
    $tot=$bkdata->totrcd;
    $datax=$bkdata->vls;
    for ($i=0;$i<$tot;$i++){
      $urlx=$datax->visiturl;
      $titlex=$datax->visittitle;
      $itemx=$item;
      $itemx=str_replace("[purl]",$urlx,$itemx);
      $itemx=str_replace("[ptitle]",$titlex,$itemx);
      $fma=$fma.$itemx;
    }
    if ($tot>0){
      $fma=killlaststr($fma);
    }
    if ($datatype==""){
      $demo=str_replace("<data>",$fma,$demo);
      $demo=str_replace("[totrcd]",$tot,$demo);
      echo $demo;
    }else{
      header("location:/localxres/tempx/multicmdrun/index.html?method=auditrestoext&valstr=".$valstr."&scd=1000");
    }
 }
     session_write_close();
?>