<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $datatype=dftval($_GET["datatype"],"");
$valstr=dftval($_GET["valstr"],"");
$sysid=$valstr;
$demo='{"status":"1","totrcd":"[totrcd]","vls":[<data>]}';
$item='{"purl":"[purl]","ptitle":"[ptitle]"},';
$fma="";
$tmptot=0;
   $trst=SX("select SNO,relyrestp,relyrescd,relyrestitle from coode_resrelyext where restype='sysx' and rescode='".$sysid."'");
   $tot=countresult($trst);
   for ($i=0;$i<$tot;$i++){
     $snox=anyvalue($trst,"SNO",$i);  
     $relyrestp=anyvalue($trst,"relyrestp",$i);     
     $relyrescd=anyvalue($trst,"relyrescd",$i);
     $relyrestitle=anyvalue($trst,"relyrestitle",$i);
     $urlx="/localxres/funx/sysdeepau/?sysid=".$valstr."&rrestype=".$relyrestp."&rrescode=".$relyrescd;
     $titlex="正在对资源名".dftval($relyrestitle,$relyrescd)."进行二次审计";
     $itemx=$item;
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;
   }
   //上面将审计后的函数加上系统ID,就有了下面的统计
    $trst=SX("select SNO,relyrestp,relyrescd,relyrestitle from coode_resrelyext where concat('xx,',sysid) like '%,".$sysid.",%' and restype like '%funx%' ");
    $tot=countresult($trst);
   for ($i=0;$i<$tot;$i++){
     $snox=anyvalue($trst,"SNO",$i);  
     $relyrestp=anyvalue($trst,"relyrestp",$i);     
     $relyrescd=anyvalue($trst,"relyrescd",$i);
     $relyrestitle=anyvalue($trst,"relyrestitle",$i);
     $urlx="/localxres/funx/sysdeepau/?sysid=".$valstr."&rrestype=".$relyrestp."&rrescode=".$relyrescd;
     $titlex="正在对资源名".dftval($relyrestitle,$relyrescd)."进行二次审计";
     $itemx=$item;
     $itemx=str_replace("[purl]",$urlx,$itemx);
     $itemx=str_replace("[ptitle]",$titlex,$itemx);
     $fma=$fma.$itemx;
     $tmptot=$tmptot+1;
   }
   if ($tot>0){
     $fma=killlaststr($fma);
   }
   if ($datatype==""){
     $demo=str_replace("<data>",$fma,$demo);
     $demo=str_replace("[totrcd]",$tmptot,$demo);
     echo $demo;
   }else{
     header("location:/localxres/tempx/multicmdrun/index.html?method=sysressecondau&valstr=".$valstr."&scd=1000");
   }
     session_write_close();
?>