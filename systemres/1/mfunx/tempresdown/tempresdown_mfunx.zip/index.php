<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $valstr=dftval($_GET["valstr"],"");
$restype=qian($valstr,"@");
$resmark=hou($valstr,"@");
$datatype=dftval($_GET["datatype"],"");
$method=$restype;
 $demo='{"status":"1","totrcd":"[totrcd]","vls":[<data>]}'; 
 $item='{"purl":"[purl]","ptitle":"[ptitle]"},';  
 $fma="";
 
$a=time();
   $drst=SX("select SNO,tempmark,tempdate,grpmark from coode_todayfiles where STATUS=0");
   $totd=countresult($drst);
   if (intval($totd)>0){     
     for ($m=0;$m<$totd;$m++){
        $snox=anyvalue($drst,"SNO",$m);
        $tempmark=anyvalue($drst,"tempmark",$m);
        $tempdate=anyvalue($drst,"tempdate",$m);
        $grpmark=anyvalue($drst,"grpmark",$m);
        $itemx=$item;
        $urlx="/DNA/EXF/anyfuns.php?fid=downtempresfile&snox=".$snox;
        $titlex="将临时文件".$tempmark."的资源下载，序号为".$snox."目录";
        $itemx=str_replace("[purl]",$urlx,$itemx);
        $itemx=str_replace("[ptitle]",$titlex,$itemx);
        $fma=$fma.$itemx; 
        $tmptot=$tmptot+1;     
     }     
    }else{
     echo makereturnjson("0","下载标记为".$tempmark."的临时文件失败",($b-$a));
    }
    if ($tmptot>0){
      $fma=killlaststr($fma);
    }
   
   
if ($datatype==""){
   $demo=str_replace("<data>",$fma,$demo);
   $demo=str_replace("[totrcd]",$tmptot,$demo);
   echo $demo;
}else{
  header("location:/units/multicmdrun/index.html?method=tempresdown&valstr=".$restype."@".$resmark."&scd=500");
}
     session_write_close();
?>