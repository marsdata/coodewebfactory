<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $valstr=dftval($_GET["valstr"],"");
$hostx=qian($valstr,"@");
$rmtd=hou($valstr,"@");
$sysid=hou($rmtd,".");
$rway=qian($rmtd,".");
//执行完毕之后；等几秒钟继续重新执行；从index获取无任务跳转地址
$mftitle="任务标题";
$mfurl="";//跳转地址
$demo='{"status":"1","tasktitle":"'.$mftitle.'","rurl":"'.$mfurl.'","totrcd":"[totrcd]","vls":[<data>]}';
$item='{"purl":"[purl]","ptitle":"[ptitle]"},';
$fma="";
     $tmptot=0;
     $tabnmx="coode_syshostres";
     $callfunname="installpod";
     switch($rway){
       case "diff":
        $trst=SX("select SNO,sysid,motherhost,rescode,restype,restitle,OLMK,CRTOR,STATUS from ".$tabnmx." where mtver!=vermd5  and motherhost='".$hostx."' and sysid='".$sysid."' limit 0,500");
       break;
       case "notin":
        $trst=SX("select SNO,sysid,motherhost,rescode,restype,restitle,OLMK,CRTOR,STATUS from ".$tabnmx." where PRIME=0 and motherhost='".$hostx."' and sysid='".$sysid."' limit 0,500");
       break;
       default:
     }
     $tot=countresult($trst);
     for ($i=0;$i<$tot;$i++){
       $snox=anyvalue($trst,"SNO",$i);
       $olmk=anyvalue($trst,"OLMK",$i);
       $restype=anyvalue($trst,"restype",$i);
       $rescode=anyvalue($trst,"rescode",$i);
       $restitle=anyvalue($trst,"restitle",$i);
       $urlx="/localxres/funx/".$callfunname."/?sysid=".$sysid."&fromhost=".$hostx."&restype=".$restype."&rescode=".$rescode;
       $titlex="正在从".$hostx."安装类型为".$restype."的资源，名称为：".$restitle;
       $olmkx=onlymark();
       $itemx=$item;
       $itemx=str_replace("[purl]",$urlx,$itemx);
       $itemx=str_replace("[ptitle]",$titlex,$itemx);
        
       $fma=$fma.$itemx;
       $tmptot=$tmptot+1;
     }
      if ($tot>0){
        $fma=killlaststr($fma);
      }
      $demo=str_replace("<data>",$fma,$demo);
      $demo=str_replace("[totrcd]",$tmptot,$demo);
      echo $demo;

     session_write_close();
?>