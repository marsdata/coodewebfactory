<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $valstr=dftval($_GET["valstr"],"");
//执行完毕之后；等几秒钟继续重新执行；从index获取无任务跳转地址
$mftitle="系统所有资源云备份";
$mfurl="";//跳转地址
$zz=anyfunrun("makesysmap","","","");
$demo='{"status":"1","tasktitle":"'.$mftitle.'","rurl":"'.$mfurl.'","totrcd":"[totrcd]","vls":[<data>]}';
$item='{"purl":"[purl]","ptitle":"[ptitle]"},';
$fma="";
     $tmptot=0;
     $tabnmx="coode_sysregres";
     $callfunname="savetoseed";
     $trst=SX("select SNO,restype,resmark,restitle,OLMK,CRTOR,STATUS from ".$tabnmx." where STATUS=0 limit 0,1000");
     $tot=countresult($trst);
     for ($i=0;$i<$tot;$i++){
       $snox=anyvalue($trst,"SNO",$i);
       $olmk=anyvalue($trst,"OLMK",$i);
       $restype=anyvalue($trst,"restype",$i);
       $rescode=anyvalue($trst,"resmark",$i);
       $rtitle=anyvalue($trst,"restitle",$i);
       $urlx="/localxres/funx/".$callfunname."/?restype=".$restype."&resmark=".$rescode."&olmkx=".$olmk."&ssmarkx=".$ssmark;
       $titlex="正在将".$rtitle."(".$restype.")转为种子并备份";
       $olmkx=onlymark();
       $itemx=$item;
       $itemx=str_replace("[purl]",$urlx,$itemx);
       $itemx=str_replace("[ptitle]",$titlex,$itemx);
        
       $fma=$fma.$itemx;
       $tmptot=$tmptot+1;
     }
      if ($tot>0){
        $fma=killlaststr($fma);
      }
      $demo=str_replace("<data>",$fma,$demo);
      $demo=str_replace("[totrcd]",$tmptot,$demo);
      echo $demo;

     session_write_close();
?>