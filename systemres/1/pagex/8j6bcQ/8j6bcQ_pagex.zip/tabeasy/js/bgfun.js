
$(function () {
    let form = layui.form
        ,laydate = layui.laydate,
        laypage = layui.laypage,
        layer = layui.layer,
        table = layui.table;
    //常规用法
    laydate.render({
        elem: '#test1'
    });
    laydate.render({
        elem: '#test2'
    });




     let i=$("tr").length-2,j=1,k=1;
    $('.add-btn').click(function () {
        i++;
        addstrs1(i);
        form.render();
    });

    $('body').on("click",".btn-del",function () {
         var pre = $(this);
        layer.confirm('确定要删除么？',{
                btn:['确定','取消']
        },function () {
            $(pre).parent().parent().remove();
            layer.closeAll('dialog');
        })

        //
    });


    function getRandomNum() {
        return parseInt(Math.random()*50);
    }
    function addstrs1(i) {
        let  iNums = getRandomNum();
        let strs1;
            strs1 = '<tr>\n' +
   '    <td style="display: none">\n' +
   '    <input type="text" id="snu'+i+'" value="'+i+'">\n' +
   '    </td>\n' +
   '    <td>\n' +
   '    <input type="text" id="morgtitle'+i+'" class="layui-input" >\n' +
   '    </td>\n' +
   '    <td>\n' +
   '    <select id="morgtype'+i+'" lay-filter="">\n' +
   '     <option value="tinyint">微整数</option>\n' +
   '     <option value="int">整数型</option>\n' +
   '     <option value="decimal1">保留1位型</option>\n' +
   '     <option value="decimal2">保留2位型</option>\n' +
   '     <option value="decimal3">保留3位型</option>\n' +
   '     <option value="decimal4">保留4位型</option>\n' +
   '     <option value="varchar20">可变字符20</option>\n' +
   '     <option value="varchar50">可变字符50</option>\n' +
   '     <option value="varchar100">可变字符100</option>\n' +
   '     <option value="varchar255">可变字符255</option>\n' +
   '     <option value="varchar1024">可变字符1024</option>\n' +
   '     <option value="date">日期型</option>\n' +
   '     <option value="datetime">日期时间</option>\n' +
   '     <option value="select">单选择框</option>\n' +
   '     <option value="multiselect">多选择框</option>\n' +
   '     <option value="checkbox">单选项</option>\n' +
   '     <option value="multicheckbox">多选项</option>\n' +
   '     <option value="imagex">单图</option>\n' +
   '     <option value="images">多图</option>\n' +
   '     <option value="filex">单文件</option>\n' +
   '     <option value="files">多文件</option>\n' +
   '     <option value="text">文本型</option>\n' +
   '     <option value="code">代码型</option>\n' +
   '    </select>\n' +
   '    </td>\n' +
   '    <td style="text-align: center"><button type="button" class="layui-btn layui-btn-danger btn-del">删除</button></td>\n' +
   '   </tr>';   
        $('.addlists').append(strs1);
        //重新渲染
        laydate.render({
            elem: '#test1'+iNums
            ,trigger: 'click' //采用click弹出
        });
        laydate.render({
            elem: '#test2'+iNums
            ,trigger: 'click' //采用click弹出
        });
    }



})
