ccode=new Array();
ccode["srd"]="[diytop]{div class=\"cBody\" style=\"\"}{div id=\"dtar\" style=\"width:100%\"}{form id=\"addform\" shortid=\"[shortid]\" showkeys=\"[showkeys]\" tabkeys=\"[tabkeys]\" tabname=\"[tabnm]\"  pssno=\"[pssno]\" pskey=\"[pskey]\" pstitle=\"[pstitle]\" pshead=\"[pshead]\" onsubmit=\"return changesmt();\" class=\"layui-form layui-col-md8\" style=\"margin-right:0px;\" action=\"\"}  {div class=\"layui-form-item\"}    {div class=\"layui-input-block\"}    [diybutton]   {/div} {/div}  [srdinner]  {div class=\"layui-form-item\"}    {div class=\"layui-input-block\"}      {button class=\"layui-btn\" onclick=\"newx()\" lay-submit lay-filter=\"submitBut\" }远程保存{/button}            {button class=\"layui-btn\" onclick=\"newz()\" lay-submit lay-filter=\"submitBut\" }远程保存并继续{/button}            {button class=\"layui-btn\" onclick=\"window.location.reload()\" [renewbtn]}重置{/button}      {button class=\"layui-btn\" onclick=\"window.open(location.href)\" lay-submit lay-filter=\"submitBut\" }外部打开{/button}      {button class=\"layui-btn\" onclick=\"openlist()\" lay-submit lay-filter=\"submitBut\" }打开列表{/button}      [bottombutton]    {/div}  {/div} {/form}{/div} {div class=\"cody\" style=\"width:32%;margin-left:10px;display:inline;\"}{form class=\"layui-form layui-col-md8\" style=\"width:25%;margin-right:0px;margin-left:10px;\" } {/form}{/div}{/div}[diybottom]";
ccode["diytop"]="";
ccode["diybottom"]="";
ccode["varchar"]="{div class=\"layui-form-item\" style=\"[dspl]\"}{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\" class=\"layui-input\" value=\"[value]\" placeholder=\"[exp]\"}{/div}";
ccode["text"]="{div class=\"layui-form-item\" style=\"[dspl]\"}{textarea id=\"p_[key]\" [rdol] name=\"p_[key]\" class=\"layui-textarea\" style=\"[dspl]\" placeholder=\"[exp]\"}[value]{/textarea}{/div}";
ccode["richtext"]="{div class=\"layui-form-item\" style=\"[dspl]\"}{textarea id=\"p_[key]\" [rdol] name=\"p_[key]\" class=\"layui-textarea\" style=\"[dspl]\" placeholder=\"[exp]\"}[value]{/textarea}{/div}";
ccode["code"]="{div class=\"layui-form-item\" style=\"[dspl]\"}{textarea id=\"p_[key]\" [rdol] name=\"[p_key]\" class=\"layui-textarea\" style=\"[dspl]\" placeholder=\"[exp]\"}[value]{/textarea}{/div}";
ccode["select"]="function mkaselect(colname,snox,thisval,$clstxtx){      if ($clstxtx!=\"\"){    $clstxtx=tostring($clstxtx);    $fmselect=formselect(qian($clstxtx,\"|\"),hou($clstxtx,\"|\"),thisval,\"p_\"+colname,\"\",\"\");        return '<div class=\"layui-form-item\" style=\"[dspl]\">'+$fmselect+'</div>';  }else{   return \"\";  }}";
function mkaselect(colname,snox,thisval,$clstxtx){    
  if ($clstxtx!=""){
    $clstxtx=tostring($clstxtx);
    $fmselect=formselect(qian($clstxtx,"|"),hou($clstxtx,"|"),thisval,"p_"+colname,"","");    
    return '<div class="layui-form-item" style="[dspl]">'+$fmselect+'</div>';
  }else{
   return "";
  }
}
ccode["multiselect"]="function mkbselect(colname,snox,thisval,$clstxtx){$clstxt=tostring($clstxtx);  if ($clstxt!=\"\"){    $newonex=tostring($clstxt);    $inputdemo=\"<input type='hidden' id='p_[key]' value='\"+thisval+\"'>\";    $fmselect=formselectx(qian($newonex,\"|\"),hou($newonex,\"|\"),$thusvalue,\"p_\"+$colname+$snox,\"p_\"+$colname+$snox,\"\");    return $inputdemo+$fmselect;  }else{   return \"\";  }}";
function mkbselect(colname,snox,thisval,$clstxtx){
$clstxt=tostring($clstxtx);
  if ($clstxt!=""){
    $newonex=tostring($clstxt);
    $inputdemo="<input type='hidden' id='p_[key]' value='"+thisval+"'>";
    $fmselect=formselectx(qian($newonex,"|"),hou($newonex,"|"),$thusvalue,"p_"+$colname+$snox,"p_"+$colname+$snox,"");
    return $inputdemo+$fmselect;
  }else{
   return "";
  }
}
ccode["date"]="{div class=\"layui-form-item\" style=\"[dspl]\"}{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\" class=\"layui-input\" value=\"[value]\"}{/div}";
ccode["datetime"]="";
ccode["int"]="{div class=\"layui-form-item\" style=\"[dspl]\"}{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\" class=\"layui-input\" value=\"[value]\" placeholder=\"[exp]\"}{/div}";
ccode["tinyint"]="";
ccode["decimal1"]="";
ccode["decimal2"]="";
ccode["decimal3"]="";
ccode["decimal4"]="";
ccode["imagex"]="{div class=\"layui-input-block\" [dspl]}{div id=\"av[key][SNO]\" [dspl]}{/div}{div id=\"pv[key][SNO]\" [dspl] }{/div}{/div}{div class=\"layui-input-block\" [dspl]}{div id=\"fgroup-[key][SNO]\" class=\"form-group\" [dspl]}{input id=\"file-[key][SNO]\" type=\"file\" multiple class=\"file\" data-overwrite-initial=\"false\" data-min-file-count=\"1\"}{/div}{/div}";
ccode["images"]="{div class=\"layui-input-block\" [dspl]}{div id=\"av[key][SNO]\" [dspl]}{/div}{div id=\"pv[key][SNO]\" [dspl] }{/div}{/div}{div class=\"layui-input-block\" [dspl]}{div id=\"fgroup-[key][SNO]\" class=\"form-group\" [dspl]}{input id=\"file-[key][SNO]\" type=\"file\" multiple class=\"file\" data-overwrite-initial=\"false\" data-min-file-count=\"2\"}{/div}{/div}";
ccode["filex"]="{div class=\"layui-input-block\" [dspl]}{div id=\"av[key][SNO]\" [dspl]}{/div}{div id=\"pv[key][SNO]\" [dspl] }{/div}{/div}{div class=\"layui-input-block\" [dspl]}{div id=\"fgroup-[key][SNO]\" class=\"form-group\" [dspl]}{input id=\"file-[key][SNO]\" type=\"file\" multiple class=\"file\" data-overwrite-initial=\"false\" data-min-file-count=\"1\"}{/div}{/div}";
ccode["files"]="{div class=\"layui-input-block\" [dspl]}{div id=\"av[key][SNO]\" [dspl]}{/div}{div id=\"pv[key][SNO]\" [dspl] }{/div}{/div}{div class=\"layui-input-block\" [dspl]}{div id=\"fgroup-[key][SNO]\" class=\"form-group\" [dspl]}{input id=\"file-[key][SNO]\" type=\"file\" multiple class=\"file\" data-overwrite-initial=\"false\" data-min-file-count=\"2\"}{/div}{/div}";
ccode["check"]="";
ccode["multicheck"]="";
ccode["varcharSRD"]="";
ccode["textSRD"]="";
ccode["richtextSRD"]="";
ccode["codeSRD"]="";
ccode["selectSRD"]="";
ccode["multiselectSRD"]="";
ccode["dateSRD"]="";
ccode["datetimeSRD"]="";
ccode["intSRD"]="";
ccode["tinyintSRD"]="";
ccode["decimal1SRD"]="";
ccode["decimal2SRD"]="";
ccode["decimal3SRD"]="";
ccode["decimal4SRD"]="";
ccode["imagexSRD"]="";
ccode["imagesSRD"]="";
ccode["filexSRD"]="";
ccode["filesSRD"]="";
ccode["checkSRD"]="";
ccode["multicheckSRD"]="";
ccode["varcharINLINE"]="";
ccode["textINLINE"]="";
ccode["richtextINLINE"]="";
ccode["codeINLINE"]="";
ccode["selectINLINE"]="";
ccode["multiselectINLINE"]="";
ccode["dateINLINE"]="";
ccode["datetimeINLINE"]="";
ccode["intINLINE"]="";
ccode["tinyintINLINE"]="";
ccode["decimal1INLINE"]="";
ccode["decimal2INLINE"]="";
ccode["decimal3INLINE"]="";
ccode["decimal4INLINE"]="";
ccode["imagexINLINE"]="";
ccode["imagesINLINE"]="";
ccode["filexINLINE"]="";
ccode["filesINLINE"]="";
ccode["checkINLINE"]="";
ccode["multicheckINLINE"]="";
ccode["onerow"]="{label class=\"layui-form-label\" id=\"titleof[key]\" style=\"clear:both;[dspl]\"}[title]{/label}[rowx]";
ccode["duorow"]="{div class=\"layui-form-item\" style=\"clear:both\"}[rowx]{/div}";
ccode["varcharFUNCTION"]="";
ccode["textFUNCTION"]="";
ccode["richtextFUNCTION"]="";
ccode["codeFUNCTION"]="";
ccode["selectFUNCTION"]="";
ccode["multiselectFUNCTION"]="";
ccode["dateFUNCTION"]="laydatex('p_[key]');";
ccode["datetimeFUNCTION"]="";
ccode["intFUNCTION"]="";
ccode["tinyintFUNCTION"]="";
ccode["decimal1FUNCTION"]="";
ccode["decimal2FUNCTION"]="";
ccode["decimal3FUNCTION"]="";
ccode["decimal4FUNCTION"]="";
ccode["imagexFUNCTION"]=" $(\"#file-[key0]\").fileinput({      uploadUrl: \"/DNA/EXF/anyfun.php?fid=anyrcvfile&SNO=\"+GetRequest().SNO+\"&olmk=\"+$(\"#p_OLMK\").val()+\"&tbnm=[tabname]&key=[key]\",       allowedFileExtensions : [\"jpg\", \"png\",\"gif\",\"jpeg\",\"svg\"],      overwriteInitial: false,      maxFileSize: 10000,      maxFilesNum: 1,            slugCallback: function(filename) {          return filename.replace(\"(\", \"_\").replace(\"]\", \"_\");     }   });   $valuexyz=\"[thisvalue]\";   $tbnmx=\"[tabname]\";   $cdkx=\"[key]\";   $fmimgduo=\"\";            if (strpos($valuexyz,\";\")>0){                $ptvlx=$valuexyz.split(\";\");                $pttot=$ptvlx.length;;                                for ($ttt=0;$ttt<$pttot-1;$ttt++){                  $tmkx=onlymark();                   if ($ptvlx[$ttt]!=\"\"){                      $fmimgduo=$fmimgduo+\"<img src=\"+syh()+$ptvlx[$ttt]+syh()+\" id=\"+syh()+$tmkx+syh()+\" width=\"+syh()+\"40px;\"+syh()+\" height=\"+syh()+\"40px\"+syh()+\"><a href=\"+syh()+\"#\"+syh()+\" sid=\"+syh()+$tmkx+syh()+\" onclick=\"+syh()+\"killfile(\"+dyh()+$ptvlx[$ttt]+dyh()+\",\"+dyh()+$tbnmx+dyh()+\",\"+dyh()+$cdkx+dyh()+\",\"+dyh()+\",this)\"+syh()+\">\"+formimgcode(1999,20,20,\"\",\"\")+\"</a>\";                   };                };             }else{                 $tmkx=onlymark();                 $fmimgduo=$fmimgduo+\"<img src=\"+syh()+$valuexyz+syh()+\" id=\"+syh()+$tmkx+syh()+\" width=\"+syh()+\"40px;\"+syh()+\" height=\"+syh()+\"40px\"+syh()+\"><a href=\"+syh()+\"#\"+syh()+\" sid=\"+syh()+$tmkx+syh()+\" onclick=\"+syh()+\"killfile(\"+dyh()+$valuexyz+dyh()+\",\"+dyh()+$tbnmx+dyh()+\",\"+dyh()+$cdkx+dyh()+\",\"+dyh()+\",this)\"+syh()+\">\"+formimgcode(1999,20,20,\"\",\"\")+\"</a>\";             };              $(\"#av[key0]\").html($fmimgduo);";
ccode["imagesFUNCTION"]=" $(\"#file-[key0]\").fileinput({      uploadUrl: \"/DNA/EXF/anyfun.php?fid=anyrcvfile&SNO=\"+GetRequest().SNO+\"&olmk=\"+$(\"#p_OLMK\"+GetRequest().SNO).val()+\"&tbnm=[tabname]&key=[key]\",       allowedFileExtensions : [\"jpg\", \"png\",\"gif\",\"jpeg\",\"svg\"],      overwriteInitial: false,      maxFileSize: 10000,      maxFilesNum: 10,            slugCallback: function(filename) {          return filename.replace(\"(\", \"_\").replace(\"]\", \"_\");     }   });   $valuexyz=\"[thisvalue]\";   $tbnmx=\"[tabname]\";   $cdkx=\"[key]\";   $fmimgduo=\"\";            if (strpos($valuexyz,\";\")>0){                $ptvlx=$valuexyz.split(\";\");                $pttot=$ptvlx.length;;                                for ($ttt=0;$ttt<$pttot-1;$ttt++){                  $tmkx=onlymark();                   if ($ptvlx[$ttt]!=\"\"){                      $fmimgduo=$fmimgduo+\"<img src=\"+syh()+$ptvlx[$ttt]+syh()+\" id=\"+syh()+$tmkx+syh()+\" width=\"+syh()+\"40px;\"+syh()+\" height=\"+syh()+\"40px\"+syh()+\"><a href=\"+syh()+\"#\"+syh()+\" sid=\"+syh()+$tmkx+syh()+\" onclick=\"+syh()+\"killfile(\"+dyh()+$ptvlx[$ttt]+dyh()+\",\"+dyh()+$tbnmx+dyh()+\",\"+dyh()+$cdkx+dyh()+\",\"+dyh()+\",this)\"+syh()+\">\"+formimgcode(1999,20,20,\"\",\"\")+\"</a>\";                   };                };             }else{                 $tmkx=onlymark();                 $fmimgduo=$fmimgduo+\"<img src=\"+syh()+$valuexyz+syh()+\" id=\"+syh()+$tmkx+syh()+\" width=\"+syh()+\"40px;\"+syh()+\" height=\"+syh()+\"40px\"+syh()+\"><a href=\"+syh()+\"#\"+syh()+\" sid=\"+syh()+$tmkx+syh()+\" onclick=\"+syh()+\"killfile(\"+dyh()+$valuexyz+dyh()+\",\"+dyh()+$tbnmx+dyh()+\",\"+dyh()+$cdkx+dyh()+\",\"+dyh()+\",this)\"+syh()+\">\"+formimgcode(1999,20,20,\"\",\"\")+\"</a>\";             };              $(\"#av[key0]\").html($fmimgduo);";
ccode["filexFUNCTION"]=" $(\"#file-[key0]\").fileinput({      uploadUrl: \"/DNA/EXF/anyfun.php?fid=anyrcvfile&SNO=\"+GetRequest().SNO+\"&olmk=\"+$(\"#p_OLMK\").val()+\"&tbnm=[tabname]&key=[key]\",       allowedFileExtensions : [\"jpg\", \"png\",\"gif\",\"jpeg\",\"doc\",\"xls\",\"docx\",\"xlsx\",\"mp4\",\"mp3\",\"txt\",\"html\",\"css\",\"js\",\"htm\",\"ppt\",\"pptx\",\"rar\",\"zip\",\"swf\",\"pdf\",\"svg\"],      overwriteInitial: false,      maxFileSize: 10000,      maxFilesNum: 1,            slugCallback: function(filename) {          return filename.replace(\"(\", \"_\").replace(\"]\", \"_\");     }   });   $valuexyz=\"[thisvalue]\";   $tbnmx=\"[tabname]\";   $cdkx=\"[key]\";   $fmimgduo=\"\";            if (strpos($valuexyz,\";\")>0){                $ptvlx=$valuexyz.split(\";\");                $pttot=$ptvlx.length;;                                for ($ttt=0;$ttt<$pttot-1;$ttt++){                  $tmkx=onlymark();                   if ($ptvlx[$ttt]!=\"\"){                      $fmimgduo=$fmimgduo+\"<img src=\"+syh()+typeimg($ptvlx[$ttt],\"b\")+syh()+\" id=\"+syh()+$tmkx+syh()+\" width=\"+syh()+\"40px;\"+syh()+\" height=\"+syh()+\"40px\"+syh()+\"><a href=\"+syh()+\"#\"+syh()+\" sid=\"+syh()+$tmkx+syh()+\" onclick=\"+syh()+\"killfile(\"+dyh()+$ptvlx[$ttt]+dyh()+\",\"+dyh()+$tbnmx+dyh()+\",\"+dyh()+$cdkx+dyh()+\",\"+dyh()+\",this)\"+syh()+\">\"+formimgcode(1999,20,20,\"\",\"\")+\"</a>\";                   };                };             }else{                 $tmkx=onlymark();                 $fmimgduo=$fmimgduo+\"<img src=\"+syh()+typeimg($valuexyz,\"b\")+syh()+\" id=\"+syh()+$tmkx+syh()+\" width=\"+syh()+\"40px;\"+syh()+\" height=\"+syh()+\"40px\"+syh()+\"><a href=\"+syh()+\"#\"+syh()+\" sid=\"+syh()+$tmkx+syh()+\" onclick=\"+syh()+\"killfile(\"+dyh()+$valuexyz+dyh()+\",\"+dyh()+$tbnmx+dyh()+\",\"+dyh()+$cdkx+dyh()+\",\"+dyh()+\",this)\"+syh()+\">\"+formimgcode(1999,20,20,\"\",\"\")+\"</a>\";             };              $(\"#av[key0]\").html($fmimgduo);";
ccode["filesFUNCTION"]=" $(\"#file-[key0]\").fileinput({      uploadUrl: \"/DNA/EXF/anyfun.php?fid=anyrcvfile&SNO=\"+GetRequest().SNO+\"&olmk=\"+$(\"#p_OLMK\"+GetRequest().SNO).val()+\"&tbnm=[tabname]&key=[key]\",       allowedFileExtensions : [\"jpg\", \"png\",\"gif\",\"jpeg\",\"doc\",\"xls\",\"docx\",\"xlsx\",\"mp4\",\"mp3\",\"txt\",\"html\",\"css\",\"js\",\"htm\",\"ppt\",\"pptx\",\"rar\",\"zip\",\"swf\",\"pdf\",\"svg\"],      overwriteInitial: false,      maxFileSize: 10000,      maxFilesNum: 10,            slugCallback: function(filename) {          return filename.replace(\"(\", \"_\").replace(\"]\", \"_\");     }   });   $valuexyz=\"[thisvalue]\";   $tbnmx=\"[tabname]\";   $cdkx=\"[key]\";   $fmimgduo=\"\";            if (strpos($valuexyz,\";\")>0){                $ptvlx=$valuexyz.split(\";\");                $pttot=$ptvlx.length;;                                for ($ttt=0;$ttt<$pttot-1;$ttt++){                  $tmkx=onlymark();                   if ($ptvlx[$ttt]!=\"\"){                      $fmimgduo=$fmimgduo+\"<img src=\"+syh()+typeimg($ptvlx[$ttt],\"b\")+syh()+\" id=\"+syh()+$tmkx+syh()+\" width=\"+syh()+\"40px;\"+syh()+\" height=\"+syh()+\"40px\"+syh()+\"><a href=\"+syh()+\"#\"+syh()+\" sid=\"+syh()+$tmkx+syh()+\" onclick=\"+syh()+\"killfile(\"+dyh()+$ptvlx[$ttt]+dyh()+\",\"+dyh()+$tbnmx+dyh()+\",\"+dyh()+$cdkx+dyh()+\",\"+dyh()+\",this)\"+syh()+\">\"+formimgcode(1999,20,20,\"\",\"\")+\"</a>\";                   };                };             }else{                 $tmkx=onlymark();                 $fmimgduo=$fmimgduo+\"<img src=\"+syh()+typeimg($valuexyz,\"b\")+syh()+\" id=\"+syh()+$tmkx+syh()+\" width=\"+syh()+\"40px;\"+syh()+\" height=\"+syh()+\"40px\"+syh()+\"><a href=\"+syh()+\"#\"+syh()+\" sid=\"+syh()+$tmkx+syh()+\" onclick=\"+syh()+\"killfile(\"+dyh()+$valuexyz+dyh()+\",\"+dyh()+$tbnmx+dyh()+\",\"+dyh()+$cdkx+dyh()+\",\"+dyh()+\",this)\"+syh()+\">\"+formimgcode(1999,20,20,\"\",\"\")+\"</a>\";             };              $(\"#av[key0]\").html($fmimgduo);";
ccode["checkFUNCTION"]="";
ccode["checkduoFUNCTION"]="";
ccode["multicheckFUNCTION"]="";
ccode["duorowFUNCTION"]="";
ccode["srdFUNCTION"]="";
