<?php
function datatofun($fid,$fdata,$imk){
  $sqla="funname,funfull,oldfull,lastfull,CRTM,UPTM,OLMK,lang,CRTOR,VRT";
  $sqlb="'".$fid."()','".$fdata."','".$fdata."','".$fdata."',now(),now(),'".onlymark()."','php','".$_COOKIE["uid"]."','0'";
  $cz=UX("select count(*) as result from coode_funlist where funname='".$fid."()'");
  if (intval($cz)==0){
   $z=UX("insert into coode_funlist(".$sqla.")values(".$sqlb.")");   
    $cz=UX("select count(*) as result from coode_funlist where funname='".$fid."()'");
    if (intval($cz)>0){
      return true;
    }else{
      return false;
    }
  }else{
    return true;
  }  
}//DESCRIB ():  END@()
function datatocls($cid,$cdata,$imk){
  $sqla="funname,funfull,oldfull,lastfull,CRTM,UPTM,OLMK,lang,CRTOR,VRT";
  $sqlb="'".$cid."','".$cdata."','".$cdata."','".$cdata."',now(),now(),'".onlymark()."','php','".$_COOKIE["uid"]."','0'";
  $cz=UX("select count(*) as result from coode_phpcls where funname='".$cid."()'");
  if (intval($cz)==0){
   $z=UX("insert into coode_phpcls(".$sqla.")values(".$sqlb.")");   
    $cz=UX("select count(*) as result from coode_phpcls where funname='".$cid."()'");
    if (intval($cz)>0){
      return true;
    }else{
      return false;
    }
  }else{
    return true;
  }  
}//DESCRIB ():  END@()
?>