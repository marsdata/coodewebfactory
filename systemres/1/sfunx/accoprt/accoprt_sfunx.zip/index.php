<?php
function editacc($rtype,$rcode){
    $extx=UX("select count(*) as result from coode_devespace where rescode='".$rcode."' and restype='".$rtype."' and STATUS=1 and askman='".$_COOKIE["uid"]."'");    
  if (intval($extx)>0){
    return true;
  }else{
    return false;
  }
}//DESCRIB ():  END@()
function addacc($rtype,$rcode,$rtitle,$uid){
  if ($uid!=""){
   $extx=UX("select count(*) as result from coode_devespace where rescode='".$rcode."' and restype='".$rtype."'  and askman='".$_COOKIE["uid"]."'");
   if (intval($extx)>0){
    $zz=UX("update coode_devespace set STATUS=1 where rescode='".$rcode."' and restype='".$rtype."'  and askman='".$_COOKIE["uid"]."'");
    return true;
   }else{
    $sqlx="acccode,restype,rescode,restitle,resarea,fromip,fromhost,askman,CRTM,UPTM,OLMK,STATUS";
    $sqly="'','$rtype','$rcode','$rtitle','".glm()."','','','".$uid."',now(),now(),'".onlymark()."',1";
    $zz=UX("insert into coode_devespace(".$sqlx.")values(".$sqly.")");
    switch($rtype){
      case "tabx":
       $z0=UX("update coode_tablist set CRTOR='".$_COOKIE["uid"]."' where TABLE_NAME='".$rcode."'");
       $z1=UX("update coode_keydetailx set CRTOR='".$_COOKIE["uid"]."' where TABLE_NAME='".$rcode."'");
      break;
      case "formx":
       $z0=UX("update coode_shortdata set CRTOR='".$_COOKIE["uid"]."' where shortid='".$rcode."'");
       $z1=UX("update coode_keydetaily set CRTOR='".$_COOKIE["uid"]."' where shortid='".$rcode."'");
      break;
      case "funx":
       $z0=UX("update coode_funlist set CRTOR='".$_COOKIE["uid"]."' where funname='".$rcode."'");       
      break;
      case "sfunx":
       $z0=UX("update coode_funlist set CRTOR='".$_COOKIE["uid"]."' where setname='".$rcode."'");       
      break;
      default:
    }
    return true;
   }
  }else{
   $zzz=UX("delete from coode_devespace where askman=''");
   return false;
  }
}
function newacc($rtype,$rcode,$rtitle,$uid){
 $url=combineurl("http://hellowocao.com","/localxres/funx/applyforresnm/");
 $pd=array(); 
 $pd["resname"]=dftval($rtitle,$rcode);
 $pd["rescode"]=$rcode;
 $pd["restype"]=$rtype;
 $pd["accesscode"]=glv();
 $pd["resdes"]="describ";
 $pd["askman"]=$uid;
    if ($_SERVER["SERVER_PORT"]=="80" or $_SERVER['SERVER_PORT']=="443"){     
     if ($_SERVER['SERVER_PORT']=="443"){
       $fromhost="https://".$_SERVER["HTTP_HOST"];
     }else{
       $fromhost="http://".$_SERVER["HTTP_HOST"];
     }
    }else{
      $fromhost="http://".$_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"];
    }
 $pd["fromhost"]=$fromhost;
 $bktxt=request_post($url,$pd);
 $bkdata=json_decode($bktxt);
 $bkstate=intval($bkdata->status);
 switch($bkstate){
   case -1:
    $auditm=UX("select askman as result from coode_devespace where restype='".$rtype."' and rescode='".$rcode."' order by SNO");
    if ($auditm!=""){    
     $sqlx="acccode,restype,rescode,restitle,resarea,fromip,fromhost,askman,auditman,CRTM,UPTM,OLMK,STATUS";
     $sqly="'','$rtype','$rcode','$rtitle','".glm()."','','".$fromhost."','".$uid."','".$auditm."',now(),now(),'".onlymark()."',0";
     $zz=UX("insert into coode_devesuser(".$sqlx.")values(".$sqly.")");
     if ($auditm==$uid){
      $sqlx="acccode,restype,rescode,restitle,resarea,fromip,fromhost,askman,CRTM,UPTM,OLMK,STATUS";
      $sqly="'','$rtype','$rcode','$rtitle','".glm()."','','".$fromhost."','".$uid."',now(),now(),'".onlymark()."',1";
      $zz=UX("insert into coode_devespace(".$sqlx.")values(".$sqly.")");
     }
    }else{
     $sqlx="acccode,restype,rescode,restitle,resarea,fromip,fromhost,askman,auditman,CRTM,UPTM,OLMK,STATUS";
     $sqly="'','$rtype','$rcode','$rtitle','".glm()."','','".$fromhost."','".$uid."','".($bkdata->redirect)."',now(),now(),'".onlymark()."',0";
     $zz=UX("insert into coode_devesuser(".$sqlx.")values(".$sqly.")");
     if ($bkdata->redirect==$uid){
      $sqlx="acccode,restype,rescode,restitle,resarea,fromip,fromhost,askman,CRTM,UPTM,OLMK,STATUS";
      $sqly="'','$rtype','$rcode','$rtitle','".glm()."','','".$fromhost."','".$uid."',now(),now(),'".onlymark()."',1";
      $zz=UX("insert into coode_devespace(".$sqlx.")values(".$sqly.")");
     }
    }
    return false;
   break;
   case 1:
   $sqlx="acccode,restype,rescode,restitle,resarea,fromip,fromhost,askman,CRTM,UPTM,OLMK,STATUS";
   $sqly="'','$rtype','$rcode','$rtitle','".glm()."','','".$fromhost."','".$uid."',now(),now(),'".onlymark()."',1";
   $zz=UX("insert into coode_devespace(".$sqlx.")values(".$sqly.")");
   return true;
   break;
   case 0:
   return false;
   break;
   default:
 }
}
function crtsysres($rescode,$restitle,$restype){
$zz=addacc($restype,$rescode,$restitle,$_COOKIE["uid"]);
switch($restype){
  case "funx":
  $extn=UX("select count(*) as result from coode_funlist where funname='".$rescode."' or funname='".$rescode."()'");
  if (intval($extn)==0){
    $sqlx="funname,funcname,CRTM,UPTM,OLMK";
    $sqly="'$rescode','$restitle',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_funlist(".$sqlx.")values(".$sqly.")");
  }
  break;
  case "tabx":  
  $extn=UX("select count(*) as result from coode_tablist where TABLE_NAME='".$rescode."'");
  if (intval($extn)==0){
    $conn=mysql_connect(gl(),glu(),glp());
    $zz=updatingx($conn,glb(),"create table ".$rescode." like coode_tabdemo","utf8");
    $sqlx="TABLE_NAME,tabtitle,CRTM,UPTM,OLMK";
    $sqly="'$rescode','$restitle',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_tablist(".$sqlx.")values(".$sqly.")");
  }
  break;
  case "tempx":
  $extn=UX("select count(*) as result from coode_domainunit where dumark='".$rescode."'");
  if (intval($extn)==0){
    $sqlx="dumark,unittitle,domainmark,unitmark,CRTM,UPTM,OLMK";
    $sqly="'$rescode','$restitle','".qian($rescode,".")."','".hou($rescode,".")."',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_domainunit(".$sqlx.")values(".$sqly.")");
  }
  break;
  case "clsx":
  $extn=UX("select count(*) as result from coode_phpcls where funname='".$rescode."' or funname='".$rescode."()'");
  if (intval($extn)==0){
    $sqlx="funname,funcname,CRTM,UPTM,OLMK";
    $sqly="'$rescode','$restitle',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_phpcls(".$sqlx.")values(".$sqly.")");
  }
  break;
  case "formx":
  $extn=UX("select count(*) as result from coode_shortdata where shortid='".$rescode."'");
  if (intval($extn)==0){
    $sqlx="shortid,shorttitle,showkeys,CRTM,UPTM,OLMK";
    $sqly="'$rescode','$restitle','SNO,STATUS,OLMK,OPRT',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_shortdata(".$sqlx.")values(".$sqly.")");
  }
  break;
  case "sfunx":  
  $extn=UX("select count(*) as result from coode_funsetfile where setname='".$rescode."'");
  if (intval($extn)==0){
    $sqlx="setname,setftitle,CRTM,UPTM,OLMK";
    $sqly="'$rescode','$restitle',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_funsetfile(".$sqlx.")values(".$sqly.")");
  }
  break;
  case "dfunx":
  $extn=UX("select count(*) as result from coode_datafun where dfunmark='".$rescode."'");
  if (intval($extn)==0){
    $sqlx="dfunmark,dftitle,CRTM,UPTM,OLMK";
    $sqly="'$rescode','$restitle',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_datafun(".$sqlx.")values(".$sqly.")");
  }
  break;
  case "mfunx":
  $extn=UX("select count(*) as result from coode_multifunlist where funname='".$rescode."' or funname='".$rescode."()'");
  if (intval($extn)==0){
    $sqlx="funname,funcname,CRTM,UPTM,OLMK";
    $sqly="'$rescode','$restitle',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_multifunlist(".$sqlx.")values(".$sqly.")");
  }
  break;
  case "pagex":
  $extn=UX("select count(*) as result from coode_tiny where tinymark='".$rescode."'");
  if (intval($extn)==0){
    $sqlx="tinymark,tinytitle,CRTM,UPTM,OLMK";
    $sqly="'$rescode','$restitle',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_multifunlist(".$sqlx.")values(".$sqly.")");
  }
  break;
  case "cdtrdrx":  
  //不用
  break;
  case "parardrx":
  //不用  
  break;
  case "constx":
  $extn=UX("select count(*) as result from coode_sysconstant where constantid='".$rescode."'");
  if (intval($extn)==0){
    $sqlx="constantid,constanttitle,CRTM,UPTM,OLMK";
    $sqly="'$rescode','$restitle',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_sysconstant(".$sqlx.")values(".$sqly.")");
  }
  break;
  case "configx":
  $extn=UX("select count(*) as result from coode_sysconfig where syskey='".$rescode."'");
  if (intval($extn)==0){
    $sqlx="syskey,sysktitle,CRTM,UPTM,OLMK";
    $sqly="'$rescode','$restitle',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_sysconfig(".$sqlx.")values(".$sqly.")");
  }
  break;
  case "groupx":  
  $extn=UX("select count(*) as result from coode_grouplist where plotmark='".$rescode."'");
  if (intval($extn)==0){
    $sqlx="plotmark,markname,CRTM,UPTM,OLMK";
    $sqly="'$rescode','$restitle',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_grouplist(".$sqlx.")values(".$sqly.")");
  }
  break;
  case "plotx":  
  $extn=UX("select count(*) as result from coode_plotlist where plotmark='".$rescode."'");
  if (intval($extn)==0){
    $sqlx="plotmark,markname,CRTM,UPTM,OLMK";
    $sqly="'$rescode','$restitle',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_plotlist(".$sqlx.")values(".$sqly.")");
  }
  break;
  case "dataspacex":
  $extn=UX("select count(*) as result from coode_dataspace where datamark='".$rescode."'");
  if (intval($extn)==0){
    $sqlx="datamark,datatitle,CRTM,UPTM,OLMK";
    $sqly="'$rescode','$restitle',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_dataspace(".$sqlx.")values(".$sqly.")");
  }
  break;
  case "sysx":
  $extn=UX("select count(*) as result from coode_sysinformation where sysid='".$rescode."'");
  if (intval($extn)==0){
    $sqlx="sysid,sysname,CRTM,UPTM,OLMK";
    $sqly="'$rescode','$restitle',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_sysinformation(".$sqlx.")values(".$sqly.")");
  }
  break;
  case "appx":
  $extn=UX("select count(*) as result from coode_appdefault where appid='".$rescode."'");
  if (intval($extn)==0){
    $sqlx="appid,appname,CRTM,UPTM,OLMK";
    $sqly="'$rescode','$restitle',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_sysinformation(".$sqlx.")values(".$sqly.")");
  }
  break;
  case "layx":
  $extn=UX("select count(*) as result from coode_applay where layid='".$rescode."'");
  if (intval($extn)==0){
    $sqlx="layid,laytitle,CRTM,UPTM,OLMK";
    $sqly="'$rescode','$restitle',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_applay(".$sqlx.")values(".$sqly.")");
  }
  break;
  case "csspagex":
  //不需要
  break;
  case "iconsetx":  
  $extn=UX("select count(*) as result from coode_iconset where setmark='".$rescode."'");
  if (intval($extn)==0){
    $sqlx="setarea,setmark,settitle,CRTM,UPTM,OLMK";
    $sqly="'localxres','$rescode','$restitle',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_iconset(".$sqlx.")values(".$sqly.")");
  }
  break;
  case "databasex":  
  $extn=UX("select count(*) as result from coode_dblist where dbmark='".$rescode."'");
  if (intval($extn)==0){
    $sqlx="dbmark,dbtitle,CRTM,UPTM,OLMK";
    $sqly="'$rescode','$restitle',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_dblist(".$sqlx.")values(".$sqly.")");
  }
  default:
 }
}
?>