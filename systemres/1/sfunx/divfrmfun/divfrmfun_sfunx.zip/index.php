<?php
function addcodetofrm($ep,$imk,$divmk,$divcode,$parno){
    $lastno=UX("select count(*) as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$ep."'");
    if (intval($lastno)==0){
        $thissno="0";
        $parno='-1';
    }else{
      $lastno=intval(UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$ep."' order by myid desc"))+1;    
    }
    $extc=UX("select count(*) as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$ep."' and divmark='".$divmk."'");
    if (intval($extc)==0){
     if (intval($parno)>0){
         $parmkx=UX("select divmark as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$ep."' and myid='".$parno."'");
     }else{
         $parmkx="";
     }
     $sqla="instmark,myid,parid,parmark,mothersrd,divmark,frmmark,divcode,CRTM,UPTM,OLMK";
     $sqlb="'$imk','$lastno','$parno','$parmkx','$ep','$divmk','".str_replace($parmkx,"",$divmk)."','".gohex($divcode)."',now(),now(),'".onlymark()."'";
     $zz=UX("insert into coode_divfrmeles(".$sqla.")values(".$sqlb.")");
    }else{
        $uu=UX("update coode_divfrmeles set UPTM=now() where instmark='".$imk."' and divmark='".$divmk."'");
    }
    return true;
}
function tempdivadd($epx,$imk,$mk,$parmk,$spx){
    switch($mk){
        case "O":
        //O1
        $dcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]O1" class="[parmk]O1class" [parmk]O1hcode styledft="width:100%;height:100%;[parmk]O1style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)).spacex(3).'[parmk]O1INNER'.huanhang();
        $dcode=$dcode.spacex($spx).'</div>'.huanhang();
        $dcode=str_replace("[parmk]",$parmk,$dcode);
        if ($spx==0){
          $zz=addcodetofrm($epx,$imk,$parmk."O1",$dcode,-1);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."'");
           $zz=addcodetofrm($epx,$imk,$parmk."O1",$dcode,$parnox);  
        }
        return true;
        break;
        case "A":
        //Asrd,A1,A2A3Srd,A2,A3
        $asrddcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]ASrd" class="[parmk]ASrdclass" [parmk]ASrdhcode styledft="width:100%;height:100%;[parmk]ASrdstyle">[parmk]ASrdINNER'.huanhang();
        $asrddcode=$asrddcode.spacex($spx).'</div>'.huanhang();
        
        $asrddcode=str_replace("[parmk]",$parmk,$asrddcode);
        if ($spx==0){
          $zz=addcodetofrm($epx,$imk,$parmk."ASrd",$asrddcode,-1);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."'");
           
           $zz=addcodetofrm($epx,$imk,$parmk."ASrd",$asrddcode,$parnox);  
        }
        $a1dcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]A1" class="[parmk]A1class" [parmk]A1hcode styledft="width:100%;[parmk]A1style">'.huanhang();
        $a1dcode=$a1dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]A1INNER'.huanhang();
        $a1dcode=$a1dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        
        $a1dcode=str_replace("[parmk]",$parmk,$a1dcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."A1",$a1dcode,0);
        }else{            
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."ASrd'");
           $zz=addcodetofrm($epx,$imk,$parmk."A1",$a1dcode,$parnox);  
        }
        $a2a3srddcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]A2A3Srd" class="[parmk]A2A3Srdclass" [parmk]A2A3Srdhcode styledft="width:100%;[parmk]A2A3Srdstyle">[parmk]A2A3SrdINNER'.huanhang();
        $a2a3srddcode=$a2a3srddcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $a2a3srddcode=str_replace("[parmk]",$parmk,$a2a3srddcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."A2A3Srd",$a2a3srddcode,0);
        }else{            
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."ASrd'");
           $zz=addcodetofrm($epx,$imk,$parmk."A2A3Srd",$a2a3srddcode,$parnox);  
        }
        $a2dcode=spacex(strlen($parmk)*2).spacex(10).spacex($spx).'<div id="[parmk]A2" class="[parmk]A2class" [parmk]A2hcode styledft="width:50%;float:left;[parmk]A2style">'.huanhang();
        $a2dcode=$a2dcode.spacex(strlen($parmk)*2).spacex(14).spacex($spx).'[parmk]A2INNER'.huanhang();
        $a2dcode=$a2dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'</div>'.huanhang();
        
        $a2dcode=str_replace("[parmk]",$parmk,$a2dcode);
        if ($spx==0){
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."A2A3Srd'");
           $zz=addcodetofrm($epx,$imk,$parmk."A2",$a2dcode,$parnox);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."A2A3Srd'");           
           $zz=addcodetofrm($epx,$imk,$parmk."A2",$a2dcode,$parnox);  
        }
        $a3dcode=spacex(strlen($parmk)*2).spacex(10).spacex($spx).'<div id="[parmk]A3" class="[parmk]A3class" [parmk]A3hcode styledft="width:50%;float:left;[parmk]A3style">'.huanhang();
        $a3dcode=$a3dcode.spacex(strlen($parmk)*2).spacex(14).spacex($spx).'[parmk]A3INNER'.huanhang();
        $a3dcode=$a3dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'</div>'.huanhang();
        
        $a3dcode=str_replace("[parmk]",$parmk,$a3dcode);
        if ($spx==0){
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."A2A3Srd'");           
           $zz=addcodetofrm($epx,$imk,$parmk."A3",$a3dcode,$parnox);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."A2A3Srd'");
           $zz=addcodetofrm($epx,$imk,$parmk."A3",$a3dcode,$parnox);  
        }
        break;
        case "V":
        //VSrd,V1V2Srd,V1,v2,v3
        $vsrddcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]VSrd" class="[parmk]VSrdclass" [parmk]VSrdhcode styledft="width:100%;height:100%;[parmk]VSrdstyle">[parmk]VSrdINNER'.huanhang();
        $vsrddcode=$vsrddcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $vsrddcode=str_replace("[parmk]",$parmk,$vsrddcode);
        
        $vsrddcode=str_replace("[parmk]",$parmk,$vsrddcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."VSrd",$vsrddcode,0);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."'");
           
           $zz=addcodetofrm($epx,$imk,$parmk."VSrd",$vsrddcode,$parnox);  
        }
        
        $v1v2srddcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]V1V2Srd" class="[parmk]V1V2Srdclass" [parmk]V1V2Srdhcode styledft="width:100%;[parmk]V1V2Srdstyle">[parmk]V1V2SrdINNER'.huanhang();
        $v1v2srddcode=$v1v2srddcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        
        $v1v2srddcode=str_replace("[parmk]",$parmk,$v1v2srddcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."V1V2Srd",$v1v2srddcode,0);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."VSrd'");
           
           $zz=addcodetofrm($epx,$imk,$parmk."V1V2Srd",$v1v2srddcode,$parnox);  
        }
        
        $v1dcode=spacex(strlen($parmk)*2).spacex(10).spacex($spx).'<div id="[parmk]V1" class="[parmk]V1class" [parmk]V1hcode styledft="width:50%;float:left;[parmk]V1style">'.huanhang();
        $v1dcode=$v1dcode.spacex(strlen($parmk)*2).spacex(14).spacex($spx).'[parmk]V1INNER'.huanhang();
        $v1dcode=$v1dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'</div>'.huanhang();
        
        $v1dcode=str_replace("[parmk]",$parmk,$v1dcode);
        if ($spx==0){
            $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."V1V2Srd'");
            
            $zz=addcodetofrm($epx,$imk,$parmk."V1",$v1dcode,$parnox);
        }else{
            $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."V1V2Srd'");
            
            $zz=addcodetofrm($epx,$imk,$parmk."V1",$v1dcode,$parnox);  
        }
        
        $v2dcode=spacex(strlen($parmk)*2).spacex(10).spacex($spx).'<div id="[parmk]V2" class="[parmk]V2class" [parmk]V2hcode styledft="width:50%;float:left;[parmk]V2style">'.huanhang();
        $v2dcode=$v2dcode.spacex(strlen($parmk)*2).spacex(14).spacex($spx).'[parmk]V2INNER'.huanhang();
        $v2dcode=$v2dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'</div>'.huanhang();
        
        $v2dcode=str_replace("[parmk]",$parmk,$v2dcode);
        if ($spx==0){
            $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."V1V2Srd'");
           
           $zz=addcodetofrm($epx,$imk,$parmk."V2",$v2dcode,$parnox);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."V1V2Srd'");
            
           $zz=addcodetofrm($epx,$imk,$parmk."V2",$v2dcode,$parnox);  
        }
        
        $v3dcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]V3" class="[parmk]V3class" [parmk]V3hcode styledft="width:100%;[parmk]V3style">'.huanhang();
        $v3dcode=$v3dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]V3INNER</div>'.huanhang();
        
        $v3dcode=str_replace("[parmk]",$parmk,$v3dcode);
        
        if ($spx==0){
            
           $zz=addcodetofrm($epx,$imk,$parmk."V3",$v3dcode,0);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."VSrd'");
           
           $zz=addcodetofrm($epx,$imk,$parmk."V3",$v3dcode,$parnox);  
        }
        
        break;
        case "C":
        //Csrd,C1C2Srd,C1,C2,C3C4Srd,C3,C4
        $csrddcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]CSrd" class="[parmk]CSrdclass" [parmk]CSrdhcode styledft="width:100%;height:100%;[parmk]CSrdstyle">[parmk]CSrdINNER'.huanhang();
        $csrddcode=$csrddcode.spacex(strlen($parmk)*2).spacex(2).spacex($spx).'</div>'.huanhang();
        
        $csrddcode=str_replace("[parmk]",$parmk,$csrddcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."CSrd",$csrddcode,0);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."'");           
           $zz=addcodetofrm($epx,$imk,$parmk."CSrd",$csrddcode,$parnox);  
        }
        $c1c2srddcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]C1C2Srd" class="[parmk]C1C2srdclass" [parmk]C1C2srdhcode styledft="width:100%;height:50%;[parmk]C1C2Srdstyle">[parmk]C1C2SrdINNER'.huanhang();
        $c1c2srddcode=$c1c2srddcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        
        $c1c2srddcode=str_replace("[parmk]",$parmk,$c1c2srddcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."C1C2Srd",$c1c2srddcode,0);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."CSrd'");
           
           $zz=addcodetofrm($epx,$imk,$parmk."C1C2Srd",$c1c2srddcode,$parnox);  
        }
        $c1dcode=spacex(strlen($parmk)*2).spacex(10).spacex($spx).'<div id="[parmk]C1" class="[parmk]C1class" [parmk]C1hcode styledft="width:50%;height:100%;float:left;[parmk]C1style">'.huanhang();
        $c1dcode=$c1dcode.spacex(strlen($parmk)*2).spacex(14).spacex($spx).'[parmk]C1INNER'.huanhang();
        $c1dcode=$c1dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'</div>'.huanhang();
        $c1dcode=str_replace("[parmk]",$parmk,$c1dcode);
        if ($spx==0){
            $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."C1C2Srd'");
           $zz=addcodetofrm($epx,$imk,$parmk."C1",$c1dcode,$parnox);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."C1C2Srd'");
           
           $zz=addcodetofrm($epx,$imk,$parmk."C1",$c1dcode,$parnox);  
        }
        $c2dcode=spacex(strlen($parmk)*2).spacex(10).spacex($spx).'<div id="[parmk]C2" class="[parmk]C2class" [parmk]C2hcode styledft="width:50%;height:100%;float:left;[parmk]C2style">'.huanhang();
        $c2dcode=$c2dcode.spacex(strlen($parmk)*2).spacex(14).spacex($spx).'[parmk]C2INNER'.huanhang();
        $c2dcode=$c2dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'</div>'.huanhang();
        $c2dcode=str_replace("[parmk]",$parmk,$c2dcode);
        if ($spx==0){
            $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."C1C2Srd'");
           $zz=addcodetofrm($epx,$imk,$parmk."C2",$c2dcode,$parnox);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."C1C2Srd'");
           
           $zz=addcodetofrm($epx,$imk,$parmk."C2",$c2dcode,$parnox);  
        }
        $c3c4srddcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]C3C4Srd" class="[parmk]C3C4Srdclass" [parmk]C3C4Srdhcode styledft="width:100%;[parmk]C3C4Srdstyle">[parmk]C3C4SrdINNER'.huanhang();
        $c3c4srddcode=$c3c4srddcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        
        $c3c4srddcode=str_replace("[parmk]",$parmk,$c3c4srddcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."C3C4Srd",$c3c4srddcode,0);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."CSrd'");
           $zz=addcodetofrm($epx,$imk,$parmk."C3C4Srd",$c3c4srddcode,$parnox);  
           
        }
        
        $c3dcode=spacex(strlen($parmk)*2).spacex(10).spacex($spx).'<div id="[parmk]C3" class="[parmk]C3class" [parmk]C3hcode styledft="width:50%;height:100%;float:left;[parmk]C3style]">'.huanhang();
        $c3dcode=$c3dcode.spacex(strlen($parmk)*2).spacex(14).spacex($spx).'[parmk]C3INNER'.huanhang();
        $c3dcode=$c3dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'</div>'.huanhang();
        
        $c3dcode=str_replace("[parmk]",$parmk,$c3dcode);
        if ($spx==0){
            $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."C3C4Srd'");
           $zz=addcodetofrm($epx,$imk,$parmk."C3",$c3dcode,$parnox);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."C3C4Srd'");
           
           $zz=addcodetofrm($epx,$imk,$parmk."C3",$c3dcode,$parnox);  
        }
        $c4dcode=$c4dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'<div id="[parmk]C4" class="[parmk]C4class" [parmk]C4hcode styledft="width:50%;height:100%;float:left;[parmk]C4style]">'.huanhang();
        $c4dcode=$c4dcode.spacex(strlen($parmk)*2).spacex(14).spacex($spx).'[parmk]C4INNER'.huanhang();
        $c4dcode=$c4dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'</div>'.huanhang();
        
        $c4dcode=str_replace("[parmk]",$parmk,$c4dcode);
        if ($spx==0){
            $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."C3C4Srd'");
           $zz=addcodetofrm($epx,$imk,$parmk."C4",$c3dcode,$parnox);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."C3C4Srd'");
           
           $zz=addcodetofrm($epx,$imk,$parmk."C4",$c4dcode,$parnox);  
           
        }
        
        break;
        case "H":
        //HSrd,H1,H2
        $hsrddcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]HSrd" class="[parmk]HSrdclass" [parmk]HSrdhcode styledft="width:100%;height:100%;[parmk]HSrdstyle">[parmk]HSrdINNER'.huanhang();
        $hsrddcode=$hsrddcode.spacex(strlen($parmk)*2).spacex(2).spacex($spx).'</div>'.huanhang();
        $hsrddcode=str_replace("[parmk]",$parmk,$hsrddcode);        
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."HSrd",$hsrddcode,0);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."'");
           
           $zz=addcodetofrm($epx,$imk,$parmk."HSrd",$hsrddcode,$parnox);  
        }
        
        $h1dcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]H1" class="[parmk]H1class" [parmk]H1hcode styledft="width:100%;[parmk]H1style">'.huanhang();
        $h1dcode=$h1dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]H1INNER'.huanhang();
        $h1dcode=$h1dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        
        $h1dcode=str_replace("[parmk]",$parmk,$h1dcode);
        
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."H1",$h1dcode,0);
        }else{
           
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."HSrd'");
           $zz=addcodetofrm($epx,$imk,$parmk."H1",$h1dcode,$parnox);  
        }
        $h2dcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]H2" class="[parmk]H2class" [parmk]H2hcode styledft="width:100%;[parmk]H2style">'.huanhang();
        $h2dcode=$h2dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]H2INNER'.huanhang();
        $h2dcode=$h2dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        
        $h2dcode=str_replace("[parmk]",$parmk,$h2dcode);
        
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."H2",$h2dcode,0);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."HSrd'");
           
           $zz=addcodetofrm($epx,$imk,$parmk."H2",$h2dcode,$parnox);  
        }
        break;
        case "N":
        //NSrd,N1,N2
        $nsrddcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]NSrd" class="[parmk]NSrdclass" [parmk]NSrdhcode styledft="width:100%;height:100%;[parmk]NSrdstyle">[parmk]NSrdINNER'.huanhang();
        $nsrddcode=$nsrddcode.spacex(strlen($parmk)*2).spacex(2).spacex($spx).'</div>'.huanhang();
        $nsrddcode=str_replace("[parmk]",$parmk,$nsrddcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."NSrd",$hsrddcode,0);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."'");
           
           $zz=addcodetofrm($epx,$imk,$parmk."NSrd",$nsrddcode,$parnox);  
        }
        $n1dcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]N1" class="[parmk]N1class" [parmk]N1hcode styledft="width:50%;height:100%;float:left;[parmk]N1style">'.huanhang();
        $n1dcode=$n1dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]N1INNER'.huanhang();
        $n1dcode=$n1dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        
        $n1dcode=str_replace("[parmk]",$parmk,$n1dcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."N1",$n1dcode,0);
        }else{            
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."NSrd'");
           $zz=addcodetofrm($epx,$imk,$parmk."N1",$n1dcode,$parnox);  
        }
        $n2dcode=$n2dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]N2" class="[parmk]N2class" [parmk]N2hcode styledft="width:50%;height:100%;float:left;[parmk]N2style]">'.huanhang();
        $n2dcode=$n2dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]N2INNER'.huanhang();
        $n2dcode=$n2dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $n2dcode=str_replace("[parmk]",$parmk,$n2dcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."N2",$n2dcode,0);
        }else{
            
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."NSrd'");
           $zz=addcodetofrm($epx,$imk,$parmk."N2",$n2dcode,$parnox);  
        }
        break;
        case "M":
        //MSrd,M1,M2,M3
        $msrddcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]MSrd" class="[parmk]MSrdclass" [parmk]MSrdhcode styledft="width:100%;height:100%;[parmk]MSrdstyle">[parmk]MSrdINNER'.huanhang();
        $msrddcode=$msrddcode.spacex(strlen($parmk)*2).spacex(2).spacex($spx).'</div>'.huanhang();
        $msrddcode=str_replace("[parmk]",$parmk,$msrddcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."MSrd",$msrddcode,0);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."'");
           
           $zz=addcodetofrm($epx,$imk,$parmk."MSrd",$msrddcode,$parnox);  
        }
        
        $m1dcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]M1" class="[parmk]M1class" [parmk]M1hcode styledft="width:33.33%;height:100%;float:left;[parmk]M1style]">'.huanhang();
        $m1dcode=$m1dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]M1INNER'.huanhang();
        $m1dcode=$m1dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $m1dcode=str_replace("[parmk]",$parmk,$m1dcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."M1",$m1dcode,0);
        }else{
           
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."MSrd'");
           $zz=addcodetofrm($epx,$imk,$parmk."M1",$m1dcode,$parnox);  
        }
        
        $m2dcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]M2" class="[parmk]M2class" [parmk]M2hcode styledft="width:33.33%;height:100%;float:left;[parmk]M2style]">'.huanhang();
        $m2dcode=$m2dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]M2INNER'.huanhang();
        $m2dcode=$m2dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $m2dcode=str_replace("[parmk]",$parmk,$m2dcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."M2",$m2dcode,0);
        }else{
           
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."MSrd'");
           $zz=addcodetofrm($epx,$imk,$parmk."M2",$m2dcode,$parnox);  
        }
        
        $m3dcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]M3" class="[parmk]M3class" [parmk]M3hcode styledft="width:33.33%;height:100%;float:left;[parmk]M3style]">'.huanhang();
        $m3dcode=$m3dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]M3INNER'.huanhang();
        $m3dcode=$m3dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $m3dcode=str_replace("[parmk]",$parmk,$m3dcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."M3",$n1dcode,0);
        }else{
           
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."MSrd'");
           $zz=addcodetofrm($epx,$imk,$parmk."M3",$m3dcode,$parnox);  
        }
        break;
        case "W":
        //WSrd,W1,W2,W3,W4
        $wsrddcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]WSrd" class="[parmk]WSrdclass" [parmk]WSrdhcode styledft="width:100%;height:100%;[parmk]WSrdstyle">[parmk]WSrdINNER'.huanhang();
        $wsrddcode=$wsrddcode.spacex(strlen($parmk)*2).spacex(2).spacex($spx).'</div>'.huanhang();
        $wsrddcode=str_replace("[parmk]",$parmk,$wsrddcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."WSrd",$wsrddcode,0);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."'");
           
           $zz=addcodetofrm($epx,$imk,$parmk."WSrd",$wsrddcode,$parnox);  
        }
        
        $w1dcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]W1" class="[parmk]W1class" [parmk]W1hcode styledft="width:25%;height:100%;float:left;[parmk]W1style">'.huanhang();
        $w1dcode=$w1dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]W1INNER'.huanhang();
        $w1dcode=$w1dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $w1dcode=str_replace("[parmk]",$parmk,$w1dcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."W1",$w1dcode,0);
        }else{
           
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."WSrd'");
           $zz=addcodetofrm($epx,$imk,$parmk."W1",$w1dcode,$parnox);  
        }
        $w2dcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]W2" class="[parmk]W2class" [parmk]W2hcode styledft="width:25%;height:100%;float:left;[parmk]W2style">'.huanhang();
        $w2dcode=$w2dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]W2INNER'.huanhang();
        $w2dcode=$w2dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $w2dcode=str_replace("[parmk]",$parmk,$w2dcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."W2",$w2dcode,0);
        }else{
           
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."WSrd'");
           $zz=addcodetofrm($epx,$imk,$parmk."W2",$w2dcode,$parnox);  
        }
        $w3dcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]W3" class="[parmk]W3class" [parmk]W3hcode styledft="width:25%;height:100%;float:left;[parmk]W3style">'.huanhang();
        $w3dcode=$w3dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]W3INNER'.huanhang();
        $w3dcode=$w3dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $w3dcode=str_replace("[parmk]",$parmk,$w3dcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."W3",$w3dcode,0);
        }else{
            
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."WSrd'");
           $zz=addcodetofrm($epx,$imk,$parmk."W3",$w3dcode,$parnox);  
        }
        $w4dcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]W4" class="[parmk]W4class" [parmk]W4hcode styledft="width:25%;height:100%;float:left;[parmk]W4style">'.huanhang();
        $w4dcode=$w4dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]W4INNER'.huanhang();
        $w4dcode=$w4dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $w4dcode=str_replace("[parmk]",$parmk,$w4dcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."W4",$w4dcode,0);
        }else{
           
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."WSrd'");
           $zz=addcodetofrm($epx,$imk,$parmk."W4",$w4dcode,$parnox);  
        }
        break;
        case "E":
        //ESrd,E1,E2,E3
        $esrddcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]ESrd" class="[parmk]ESrdclass" [parmk]ESrdhcode styledft="width:100%;height:100%;[parmk]ESrdstyle">[parmk]ESrdINNER'.huanhang();
        $esrddcode=$esrddcode.spacex(strlen($parmk)*2).spacex(2).spacex($spx).'</div>'.huanhang();
        $esrddcode=str_replace("[parmk]",$parmk,$esrddcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."ESrd",$esrddcode,0);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."'");
           
           $zz=addcodetofrm($epx,$imk,$parmk."ESrd",$esrddcode,$parnox);  
        }
        
        $e1dcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]E1" class="[parmk]E1class" [parmk]E1hcode styledft="width:100%;[parmk]E1style">'.huanhang();
        $e1dcode=$e1dcode.spacex(strlen($parmk)*2).spacex(5).spacex($spx).'[parmk]E1INNER'.huanhang();
        $e1dcode=$e1dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $e1dcode=str_replace("[parmk]",$parmk,$e1dcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."E1",$e1dcode,0);
        }else{
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."ESrd'");
           
           $zz=addcodetofrm($epx,$imk,$parmk."E1",$e1dcode,$parnox);  
        }
        $e2dcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]E2" class="[parmk]E2class" [parmk]E2hcode styledft="width:100%;[parmk]E2style">'.huanhang();
        $e2dcode=$e2dcode.spacex(strlen($parmk)*2).spacex(5).spacex($spx).'[parmk]E2INNER'.huanhang();
        $e2dcode=$e2dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $e2dcode=str_replace("[parmk]",$parmk,$e2dcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."E2",$e2dcode,0);
        }else{
            
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."ESrd'");
           $zz=addcodetofrm($epx,$imk,$parmk."E2",$e2dcode,$parnox);  
        }
        $e3dcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]E3" class="[parmk]E3class" [parmk]E3hcode styledft="width:100%;[parmk]E3style">'.huanhang();
        $e3dcode=$e3dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]E3INNER'.huanhang();
        $e3dcode=$e3dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $e3dcode=str_replace("[parmk]",$parmk,$e3dcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."E3",$e3dcode,0);
        }else{
            
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."ESrd'");
           $zz=addcodetofrm($epx,$imk,$parmk."E3",$e3dcode,$parnox);  
        }
        break;
        case "F":
        //FSrd,F1,F2,F3,F4
        $fsrddcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]FSrd" class="[parmk]FSrdclass" [parmk]FSrdhcode styledft="width:100%;height:100%;[parmk]FSrdstyle">[parmk]FSrdINNER'.huanhang();
        $fsrddcode=$fsrddcode.spacex(strlen($parmk)*2).spacex(2).spacex($spx).'</div>'.huanhang();
        $fsrddcode=str_replace("[parmk]",$parmk,$fsrddcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."FSrd",$fsrddcode,0);
        }else{
            
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."'");
           $zz=addcodetofrm($epx,$imk,$parmk."FSrd",$fsrdcode,$parnox);  
        }
        
        $f1dcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]F1" class="[parmk]F1class" [parmk]F1hcode styledft="width:100%;[parmk]F1style">'.huanhang();
        $f1dcode=$f1dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]F1INNER'.huanhang();
        $f1dcode=$f1dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $f1dcode=str_replace("[parmk]",$parmk,$f1dcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."F1",$f1dcode,0);
        }else{
            
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."FSrd'");
           $zz=addcodetofrm($epx,$imk,$parmk."F1",$f1dcode,$parnox);  
        }
        $f2dcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]F2" class="[parmk]F2class" [parmk]F2hcode styledft="width:100%;[parmk]F2style]">'.huanhang();
        $f2dcode=$f2dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]F2INNER'.huanhang();
        $f2dcode=$f2dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $f2dcode=str_replace("[parmk]",$parmk,$f2dcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."F2",$f2dcode,0);
        }else{
            
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."FSrd'");
           $zz=addcodetofrm($epx,$imk,$parmk."F2",$f2dcode,$parnox);  
        }
        $f3dcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]F3" class="[parmk]F3class" [parmk]F3hcode styledft="width:100%;[parmk]F3style]">'.huanhang();
        $f3dcode=$f3dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]F3INNER'.huanhang();
        $f3dcode=$f3dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $f3dcode=str_replace("[parmk]",$parmk,$f3dcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."F3",$f3dcode,0);
        }else{
               
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."FSrd'");
           $zz=addcodetofrm($epx,$imk,$parmk."F3",$f3dcode,$parnox);  
        }
        $f4dcode=spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]F4" class="[parmk]F4class" [parmk]F4hcode styledft="width:100%;[parmk]F4style]">'.huanhang();
        $f4dcode=$f4dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]F4INNER'.huanhang();
        $f4dcode=$f4dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $f4dcode=str_replace("[parmk]",$parmk,$f4dcode);
        if ($spx==0){
           $zz=addcodetofrm($epx,$imk,$parmk."F4",$f4dcode,0);
        }else{
               
           $parnox=UX("select myid as result from coode_divfrmeles where instmark='".$imk."' and mothersrd='".$epx."' and divmark='".$parmk."FSrd'");
           $zz=addcodetofrm($epx,$imk,$parmk."F4",$f4dcode,$parnox);  
        }
        break;
        default:
    }
    return true;
}
function tempunit($mk,$parmk,$spx){
    switch($mk){
        case "O":
        //O1
        $dcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]O1" class="[parmk]O1class" [parmk]O1hcode styledft="width:100%;height:100%;[parmk]O1style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)).spacex(3).'[parmk]O1INNER'.huanhang();
        $dcode=$dcode.spacex($spx).'</div>'.huanhang();
        $dcode=str_replace("[parmk]",$parmk,$dcode);
        return $dcode;
        break;
        case "A":
        //Asrd,A1,A2A3Srd,A2,A3
        $dcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]ASrd" class="[parmk]ASrdclass" [parmk]ASrdhcode styledft="width:100%;height:100%;[parmk]ASrdstyle">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]A1" class="[parmk]A1class" [parmk]A1hcode styledft="width:100%;[parmk]A1style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]A1INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]A2A3Srd" class="[parmk]A2A3Srdclass" [parmk]A2A3Srdhcode styledft="width:100%;[parmk]A2A3Srdstyle">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'<div id="[parmk]A2" class="[parmk]A2class" [parmk]A2hcode styledft="width:50%;float:left;[parmk]A2style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(14).spacex($spx).'[parmk]A2INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'<div id="[parmk]A3" class="[parmk]A3class" [parmk]A3hcode styledft="width:50%;float:left;[parmk]A3style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(14).spacex($spx).'[parmk]A3INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex($spx).'</div>'.huanhang();
        $dcode=str_replace("[parmk]",$parmk,$dcode);
         return $dcode;
        break;
        case "V":
        //VSrd,V1V2Srd,V1,v2,v3
        $dcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]VSrd" class="[parmk]VSrdclass" [parmk]VSrdhcode styledft="width:100%;height:100%;[parmk]VSrdstyle">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]V1V2Srd" class="[parmk]V1V2Srdclass" [parmk]V1V2Srdhcode styledft="width:100%;[parmk]V1V2Srdstyle">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'<div id="[parmk]V1" class="[parmk]V1class" [parmk]V1hcode styledft="width:50%;float:left;[parmk]V1style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(14).spacex($spx).'[parmk]V1INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'<div id="[parmk]V2" class="[parmk]V2class" [parmk]V2hcode styledft="width:50%;float:left;[parmk]V2style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(14).spacex($spx).'[parmk]V2INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]V3" class="[parmk]V3class" [parmk]V3hcode styledft="width:100%;[parmk]V3style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]V3INNER</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=str_replace("[parmk]",$parmk,$dcode);
         return $dcode;
        break;
        case "C":
        //Csrd,C1C2Srd,C1,C2,C3C4Srd,C3,C4
        $dcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]CSrd" class="[parmk]CSrdclass" [parmk]CSrdhcode styledft="width:100%;height:100%;[parmk]CSrdstyle">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]C1C2Srd" class="[parmk]C1C2srdclass" [parmk]C1C2srdhcode styledft="width:100%;height:50%;[parmk]C1C2Srdstyle">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'<div id="[parmk]C1" class="[parmk]C1class" [parmk]C1hcode styledft="width:50%;height:100%;float:left;[parmk]C1style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(14).spacex($spx).'[parmk]C1INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'<div id="[parmk]C2" class="[parmk]C2class" [parmk]C2hcode styledft="width:50%;height:100%;float:left;[parmk]C2style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(14).spacex($spx).'[parmk]C2INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]C3C4Srd" class="[parmk]C3C4Srdclass" [parmk]C3C4Srdhcode styledft="width:100%;[parmk]C3C4Srdstyle">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'<div id="[parmk]C3" class="[parmk]C3class" [parmk]C3hcode styledft="width:50%;height:100%;float:left;[parmk]C3style]">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(14).spacex($spx).'[parmk]C3INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'<div id="[parmk]C4" class="[parmk]C4class" [parmk]C4hcode styledft="width:50%;height:100%;float:left;[parmk]C4style]">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(14).spacex($spx).'[parmk]C4INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(2).spacex($spx).'</div>'.huanhang();
        $dcode=str_replace("[parmk]",$parmk,$dcode);
               return $dcode;
        break;
        case "H":
        //HSrd,H1,H2
        $dcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]HSrd" class="[parmk]HSrdclass" [parmk]HSrdhcode styledft="width:100%;height:100%;[parmk]HSrdstyle">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]H1" class="[parmk]H1class" [parmk]H1hcode styledft="width:100%;[parmk]H1style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]H1INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]H2" class="[parmk]H2class" [parmk]H2hcode styledft="width:100%;[parmk]H2style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]H2INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(2).spacex($spx).'</div>'.huanhang();
        $dcode=str_replace("[parmk]",$parmk,$dcode);
         return $dcode;
        break;
        case "N":
        //NSrd,N1,N2
        $dcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]NSrd" class="[parmk]NSrdclass" [parmk]NSrdhcode styledft="width:100%;height:100%;[parmk]NSrdstyle">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]N1" class="[parmk]N1class" [parmk]N1hcode styledft="width:50%;height:100%;float:left;[parmk]N1style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]N1INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]N2" class="[parmk]N2class" [parmk]N2hcode styledft="width:50%;height:100%;float:left;[parmk]N2style]">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]N2INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(2).spacex($spx).'</div>'.huanhang();
        $dcode=str_replace("[parmk]",$parmk,$dcode);
        return $dcode;
        break;
        case "M":
        //MSrd,M1,M2,M3
        $dcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]MSrd" class="[parmk]MSrdclass" [parmk]MSrdhcode styledft="width:100%;height:100%;[parmk]MSrdstyle">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]M1" class="[parmk]M1class" [parmk]M1hcode styledft="width:33.33%;height:100%;float:left;[parmk]M1style]">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]M1INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]M2" class="[parmk]M2class" [parmk]M2hcode styledft="width:33.33%;height:100%;float:left;[parmk]M2style]">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]M2INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]M3" class="[parmk]M3class" [parmk]M3hcode styledft="width:33.33%;height:100%;float:left;[parmk]M3style]">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]M3INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(2).spacex($spx).'</div>'.huanhang();
        $dcode=str_replace("[parmk]",$parmk,$dcode);
         return $dcode;
        break;
        case "W":
        //WSrd,W1,W2,W3,W4
        $dcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]WSrd" class="[parmk]WSrdclass" [parmk]WSrdhcode styledft="width:100%;height:100%;[parmk]WSrdstyle">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]W1" class="[parmk]W1class" [parmk]W1hcode styledft="width:25%;height:100%;float:left;[parmk]W1style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]W1INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]W2" class="[parmk]W2class" [parmk]W2hcode styledft="width:25%;height:100%;float:left;[parmk]W2style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]W2INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]W3" class="[parmk]W3class" [parmk]W3hcode styledft="width:25%;height:100%;float:left;[parmk]W3style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]W3INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]W4" class="[parmk]W4class" [parmk]W4hcode styledft="width:25%;height:100%;float:left;[parmk]W4style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]W4INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(2).spacex($spx).'</div>'.huanhang();
        $dcode=str_replace("[parmk]",$parmk,$dcode);
         return $dcode;
        break;
        case "E":
        //ESrd,E1,E2,E3
        $dcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]ESrd" class="[parmk]ESrdclass" [parmk]ESrdhcode styledft="width:100%;height:100%;[parmk]ESrdstyle">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]E1" class="[parmk]E1class" [parmk]E1hcode styledft="width:100%;[parmk]E1style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(5).spacex($spx).'[parmk]E1INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]E2" class="[parmk]E2class" [parmk]E2hcode styledft="width:100%;[parmk]E2style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(5).spacex($spx).'[parmk]E2INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]E3" class="[parmk]E3class" [parmk]E3hcode styledft="width:100%;[parmk]E3style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]E3INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(2).spacex($spx).'</div>'.huanhang();
        $dcode=str_replace("[parmk]",$parmk,$dcode);
               return $dcode;
        break;
        case "F":
        //FSrd,F1,F2,F3,F4
        $dcode=spacex(strlen($parmk)*2).spacex(2).'<div id="[parmk]FSrd" class="[parmk]FSrdclass" [parmk]FSrdhcode styledft="width:100%;height:100%;[parmk]FSrdstyle">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]F1" class="[parmk]F1class" [parmk]F1hcode styledft="width:100%;[parmk]F1style">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]F1INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]F2" class="[parmk]F2class" [parmk]F2hcode styledft="width:100%;[parmk]F2style]">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]F2INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]F3" class="[parmk]F3class" [parmk]F3hcode styledft="width:100%;[parmk]F3style]">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]F3INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'<div id="[parmk]F4" class="[parmk]F4class" [parmk]F4hcode styledft="width:100%;[parmk]F4style]">'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(10).spacex($spx).'[parmk]F4INNER'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(6).spacex($spx).'</div>'.huanhang();
        $dcode=$dcode.spacex(strlen($parmk)*2).spacex(2).spacex($spx).'</div>'.huanhang();
        $dcode=str_replace("[parmk]",$parmk,$dcode);
               return $dcode;
        break;
        default:
    }
}
function comcode($expx,$parmk){
    if (strpos($expx,"=")>0){
        $mkx=qian($expx,"=");
        $mvy=hou($expx,"=");          
        $leftx="";
        switch($mkx){
            case "A":
            if (strlen($mvy)==3){
                $leftx=tempunit("A",$parmk,0);
                $a1icode=tempunit(substr($mvy,0,1),$parmk."A1",strlen($parmk)*2+10);
                $leftx=str_replace($parmk."A1INNER",substr($a1icode,strlen($parmk."A1")*2+2,strlen($a1icode)-(strlen($parmk."A1")*2+1)),$leftx);
                $a2icode=tempunit(substr($mvy,1,1),$parmk."A2",strlen($parmk)*2+14);
                $leftx=str_replace($parmk."A2INNER",substr($a2icode,strlen($parmk."A2")*2+2,strlen($a2icode)-(strlen($parmk."A2")*2+1)),$leftx);
                $a3icode=tempunit(substr($mvy,2,1),$parmk."A3",strlen($parmk)*2+14);
                $leftx=str_replace($parmk."A3INNER",substr($a3icode,strlen($parmk."A3")*2+2,strlen($a3icode)-(strlen($parmk."A3")*2+1)),$leftx);
                return $leftx;
            }else{
                $leftx=tempunit("A",$parmk,0);
                return $leftx;
            }
            break;
            case "V":
            if (strlen($mvy)==3){
                $leftx=tempunit("V",$parmk,0);
                $v1icode=tempunit(substr($mvy,0,1),$parmk."V1",strlen($parmk)*2+14);
                $leftx=str_replace($parmk."V1INNER",substr($v1icode,strlen($parmk."V1")*2+2,strlen($v1icode)-(strlen($parmk."V1")*2+1)),$leftx);
                $v2icode=tempunit(substr($mvy,1,1),$parmk."V2",strlen($parmk)*2+14);
                $leftx=str_replace($parmk."V2INNER",substr($v2icode,strlen($parmk."V2")*2+2,strlen($v2icode)-(strlen($parmk."V2")*2+1)),$leftx);
                $v3icode=tempunit(substr($mvy,2,1),$parmk."V3",strlen($parmk)*2+10);
                $leftx=str_replace($parmk."V3INNER",substr($v3icode,strlen($parmk."V3")*2+2,strlen($v3icode)-(strlen($parmk."V3")*2+1)),$leftx);
                return $leftx;
            }else{
                $leftx=tempunit("V",$parmk,0);
                return $leftx;
            }
            break;
            case "C":
            if (strlen($mvy)==4){
                $leftx=tempunit("C",$parmk,0);
                $c1icode=tempunit(substr($mvy,0,1),$parmk."C1",strlen($parmk)*2+14);
                $leftx=str_replace($parmk."C1INNER",substr($c1icode,strlen($parmk."C1")*2+2,strlen($c1icode)-(strlen($parmk."C1")*2+1)),$leftx);
                $c2icode=tempunit(substr($mvy,1,1),$parmk."C2",strlen($parmk)*2+14);
                $leftx=str_replace($parmk."C2INNER",substr($c2icode,strlen($parmk."C2")*2+2,strlen($c2icode)-(strlen($parmk."C2")*2+1)),$leftx);
                $c3icode=tempunit(substr($mvy,2,1),$parmk."C3",strlen($parmk)*2+14);
                $leftx=str_replace($parmk."C3INNER",substr($c3icode,strlen($parmk."C3")*2+2,strlen($c3icode)-(strlen($parmk."C3")*2+1)),$leftx);
                $c4icode=tempunit(substr($mvy,3,1),$parmk."C4",strlen($parmk)*2+14);
                $leftx=str_replace($parmk."C4INNER",substr($c4icode,strlen($parmk."C4")*2+2,strlen($c4icode)-(strlen($parmk."C4")*2+1)),$leftx);
                return $leftx;
            }else{
                $leftx=tempunit("C",$parmk,0);
                return $leftx;
            }
            break;
            case "H":
            if (strlen($mvy)==2){
                $leftx=tempunit("H",$parmk,0);
                $h1icode=tempunit(substr($mvy,0,1),$parmk."H1",strlen($parmk)*2+10);
                $leftx=str_replace($parmk."H1INNER",substr($h1icode,strlen($parmk."H1")*2+2,strlen($h1icode)-(strlen($parmk."H1")*2+1)),$leftx);
                $h2icode=tempunit(substr($mvy,1,1),$parmk."H2",strlen($parmk)*2+10);
                $leftx=str_replace($parmk."H2INNER",substr($c2icode,strlen($parmk."H2")*2+2,strlen($h2icode)-(strlen($parmk."H2")*2+1)),$leftx);
                return $leftx;
            }else{
                $leftx=tempunit("H",$parmk,0);
                return $leftx;
            }
            break;
            case "N":
            if (strlen($mvy)==2){
                $leftx=tempunit("N",$parmk,0);
                $n1icode=tempunit(substr($mvy,0,1),$parmk."N1",strlen($parmk)*2+10);
                $leftx=str_replace($parmk."N1INNER",substr($n1icode,strlen($parmk."N1")*2+2,strlen($n1icode)-(strlen($parmk."N1")*2+1)),$leftx);
                $n2icode=tempunit(substr($mvy,1,1),$parmk."N2",strlen($parmk)*2+10);
                $leftx=str_replace($parmk."N2INNER",substr($n2icode,strlen($parmk."N2")*2+2,strlen($n2icode)-(strlen($parmk."N2")*2+1)),$leftx);
                return $leftx;
            }else{
                $leftx=tempunit("N",$parmk,0);
                return $leftx;
            }
            break;
            case "M":
            if (strlen($mvy)==3){
                $leftx=tempunit("M",$parmk,0);
                $m1icode=tempunit(substr($mvy,0,1),$parmk."M1",strlen($parmk)*2+10);
                $leftx=str_replace($parmk."M1INNER",substr($m1icode,strlen($parmk."M1")*2+2,strlen($m1icode)-(strlen($parmk."M1")*2+1)),$leftx);
                $m2icode=tempunit(substr($mvy,1,1),$parmk."M2",strlen($parmk)*2+10);
                $leftx=str_replace($parmk."M2INNER",substr($m2icode,strlen($parmk."M2")*2+2,strlen($m2icode)-(strlen($parmk."M2")*2+1)),$leftx);
                $m3icode=tempunit(substr($mvy,2,1),$parmk."M3",strlen($parmk)*2+10);
                $leftx=str_replace($parmk."M3INNER",substr($m3icode,strlen($parmk."M3")*2+2,strlen($m3icode)-(strlen($parmk."M3")*2+1)),$leftx);
                return $leftx;
            }else{
                $leftx=tempunit("M",$parmk,0);
                return $leftx;
            }
            break;
            case "W":
            if (strlen($mvy)==4){
                $leftx=tempunit("W",$parmk,0);
                $w1icode=tempunit(substr($mvy,0,1),$parmk."W1",strlen($parmk)*2+10);
                $leftx=str_replace($parmk."W1INNER",substr($w1icode,strlen($parmk."W1")*2+2,strlen($w1icode)-(strlen($parmk."W1")*2+1)),$leftx);
                $w2icode=tempunit(substr($mvy,1,1),$parmk."W2",strlen($parmk)*2+10);
                $leftx=str_replace($parmk."W2INNER",substr($w2icode,strlen($parmk."W2")*2+2,strlen($w2icode)-(strlen($parmk."W2")*2+1)),$leftx);
                $w3icode=tempunit(substr($mvy,2,1),$parmk."W3",strlen($parmk)*2+10);
                $leftx=str_replace($parmk."W3INNER",substr($w3icode,strlen($parmk."W3")*2+2,strlen($w3icode)-(strlen($parmk."W3")*2+1)),$leftx);
                $w4icode=tempunit(substr($mvy,3,1),$parmk."W4",strlen($parmk)*2+10);
                $leftx=str_replace($parmk."W4INNER",substr($w4icode,strlen($parmk."W4")*2+2,strlen($w4icode)-(strlen($parmk."W4")*2+1)),$leftx);
                return $leftx;
            }else{
                $leftx=tempunit("W",$parmk,0);
                return $leftx;
            }
            break;
            case "E":
            if (strlen($mvy)==3){
                $leftx=tempunit("E",$parmk,0);
                $e1icode=tempunit(substr($mvy,0,1),$parmk."E1",strlen($parmk)*2+5);
                $leftx=str_replace($parmk."E1INNER",substr($e1icode,strlen($parmk."E1")*2+2,strlen($e1icode)-(strlen($parmk."E1")*2+1)),$leftx);
                $e2icode=tempunit(substr($mvy,1,1),$parmk."E2",strlen($parmk)*2+5);
                $leftx=str_replace($parmk."E2INNER",substr($e2icode,strlen($parmk."E2")*2+2,strlen($e2icode)-(strlen($parmk."E2")*2+1)),$leftx);
                $e3icode=tempunit(substr($mvy,2,1),$parmk."E3",strlen($parmk)*2+10);
                $leftx=str_replace($parmk."E3INNER",substr($e3icode,strlen($parmk."E3")*2+2,strlen($e3icode)-(strlen($parmk."E3")*2+1)),$leftx);
                return $leftx;
            }else{
                $leftx=tempunit("E",$parmk,0);
                return $leftx;
            }
            break;
            case "F":
            if (strlen($mvy)==4){
                $leftx=tempunit("F",$parmk,0);
                $f1icode=tempunit(substr($mvy,0,1),$parmk."F1",strlen($parmk)*2+10);
                $leftx=str_replace($parmk."F1INNER",substr($f1icode,strlen($parmk."F1")*2+2,strlen($f1icode)-(strlen($parmk."F1")*2+1)),$leftx);
                $f2icode=tempunit(substr($mvy,1,1),$parmk."F2",strlen($parmk)*2+10);
                $leftx=str_replace($parmk."F2INNER",substr($f2icode,strlen($parmk."F2")*2+2,strlen($f2icode)-(strlen($parmk."F2")*2+1)),$leftx);
                $f3icode=tempunit(substr($mvy,2,1),$parmk."F3",strlen($parmk)*2+10);
                $leftx=str_replace($parmk."F3INNER",substr($f3icode,strlen($parmk."F3")*2+2,strlen($f3icode)-(strlen($parmk."F3")*2+1)),$leftx);
                $f4icode=tempunit(substr($mvy,3,1),$parmk."F4",strlen($parmk)*2+10);
                $leftx=str_replace($parmk."F4INNER",substr($f4icode,strlen($parmk."F4")*2+2,strlen($f4icode)-(strlen($parmk."F4")*2+1)),$leftx);
                return $leftx;
            }else{
                $leftx=tempunit("F",$parmk,0);
                return $leftx;
            }
            break;
            default:
        }
    }else{
        return "";
    }
}
function anacomdiv($expx,$parmk){
    if (strpos($expx,"=")>0){
        $mkx=qian($expx,"=");
        $mvy=hou($expx,"=");          
        $leftx="";
        switch($mkx){
            case "A":
            if (strlen($mvy)==3){
                $leftx=tempdivadd($expx,$parmk,"A",$parmk,0);
                $a1icode=tempdivadd($expx,$parmk,substr($mvy,0,1),$parmk."A1",strlen($parmk)*2+10);
                
                $a2icode=tempdivadd($expx,$parmk,substr($mvy,1,1),$parmk."A2",strlen($parmk)*2+14);
                
                $a3icode=tempdivadd($expx,$parmk,substr($mvy,2,1),$parmk."A3",strlen($parmk)*2+14);
                
                
            }else{
                $leftx=tempdivadd($expx,$parmk,"A",$parmk,0);
                
            }
            break;
            case "V":
            if (strlen($mvy)==3){
                $leftx=tempdivadd($expx,$parmk,"V",$parmk,0);
                $v1icode=tempdivadd($expx,$parmk,substr($mvy,0,1),$parmk."V1",strlen($parmk)*2+14);
                
                $v2icode=tempdivadd($expx,$parmk,substr($mvy,1,1),$parmk."V2",strlen($parmk)*2+14);
                
                $v3icode=tempdivadd($expx,$parmk,substr($mvy,2,1),$parmk."V3",strlen($parmk)*2+10);
                
                
            }else{
                $leftx=tempdivadd($expx,$parmk,"V",$parmk,0);
                
            }
            break;
            case "C":
            if (strlen($mvy)==4){
                $leftx=tempdivadd($expx,$parmk,"C",$parmk,0);
                $c1icode=tempdivadd($expx,$parmk,substr($mvy,0,1),$parmk."C1",strlen($parmk)*2+14);
                
                $c2icode=tempdivadd($expx,$parmk,substr($mvy,1,1),$parmk."C2",strlen($parmk)*2+14);
                
                $c3icode=tempdivadd($expx,$parmk,substr($mvy,2,1),$parmk."C3",strlen($parmk)*2+14);
                
                $c4icode=tempdivadd($expx,$parmk,substr($mvy,3,1),$parmk."C4",strlen($parmk)*2+14);
                
                
            }else{
                $leftx=tempdivadd($expx,$parmk,"C",$parmk,0);
                
            }
            break;
            case "H":
            if (strlen($mvy)==2){
                $leftx=tempdivadd($expx,$parmk,"H",$parmk,0);
                $h1icode=tempdivadd($expx,$parmk,substr($mvy,0,1),$parmk."H1",strlen($parmk)*2+10);
                
                $h2icode=tempdivadd($expx,$parmk,substr($mvy,1,1),$parmk."H2",strlen($parmk)*2+10);
                
                
            }else{
                $leftx=tempdivadd($expx,$parmk,"H",$parmk,0);
              
            }
            break;
            case "N":
            if (strlen($mvy)==2){
                $leftx=tempdivadd($expx,$parmk,"N",$parmk,0);
                $n1icode=tempdivadd($expx,$parmk,substr($mvy,0,1),$parmk."N1",strlen($parmk)*2+10);
              
                $n2icode=tempdivadd($expx,$parmk,substr($mvy,1,1),$parmk."N2",strlen($parmk)*2+10);
              
              
            }else{
                $leftx=tempdivadd($expx,$parmk,"N",$parmk,0);
                
            }
            break;
            case "M":
            if (strlen($mvy)==3){
                $leftx=tempdivadd($expx,$parmk,"M",$parmk,0);
                $m1icode=tempdivadd($expx,$parmk,substr($mvy,0,1),$parmk."M1",strlen($parmk)*2+10);
                
                $m2icode=tempdivadd($expx,$parmk,substr($mvy,1,1),$parmk."M2",strlen($parmk)*2+10);
                
                $m3icode=tempdivadd($expx,$parmk,substr($mvy,2,1),$parmk."M3",strlen($parmk)*2+10);
                
                
            }else{
                $leftx=tempdivadd($expx,$parmk,"M",$parmk,0);
                
            }
            break;
            case "W":
            if (strlen($mvy)==4){
                $leftx=tempdivadd($expx,$parmk,"W",$parmk,0);
                $w1icode=tempdivadd($expx,$parmk,substr($mvy,0,1),$parmk."W1",strlen($parmk)*2+10);
                
                $w2icode=tempdivadd($expx,$parmk,substr($mvy,1,1),$parmk."W2",strlen($parmk)*2+10);
                
                $w3icode=tempdivadd($expx,$parmk,substr($mvy,2,1),$parmk."W3",strlen($parmk)*2+10);
                
                $w4icode=tempdivadd($expx,$parmk,substr($mvy,3,1),$parmk."W4",strlen($parmk)*2+10);
                
                
            }else{
                $leftx=tempdivadd($expx,$parmk,"W",$parmk,0);
                
            }
            break;
            case "E":
            if (strlen($mvy)==3){
                $leftx=tempdivadd($expx,$parmk,"E",$parmk,0);
                $e1icode=tempdivadd($expx,$parmk,substr($mvy,0,1),$parmk."E1",strlen($parmk)*2+5);
                
                $e2icode=tempdivadd($expx,$parmk,substr($mvy,1,1),$parmk."E2",strlen($parmk)*2+5);
                
                $e3icode=tempdivadd($expx,$parmk,substr($mvy,2,1),$parmk."E3",strlen($parmk)*2+10);
                
                
            }else{
                $leftx=tempdivadd($expx,$parmk,"E",$parmk,0);
                
            }
            break;
            case "F":
            if (strlen($mvy)==4){
                $leftx=tempdivadd($expx,$parmk,"F",$parmk,0);
                $f1icode=tempdivadd($expx,$parmk,substr($mvy,0,1),$parmk."F1",strlen($parmk)*2+10);
                
                $f2icode=tempdivadd($expx,$parmk,substr($mvy,1,1),$parmk."F2",strlen($parmk)*2+10);
                
                $f3icode=tempdivadd($expx,$parmk,substr($mvy,2,1),$parmk."F3",strlen($parmk)*2+10);
                
                $f4icode=tempdivadd($expx,$parmk,substr($mvy,3,1),$parmk."F4",strlen($parmk)*2+10);
                
                
            }else{
                $leftx=tempdivadd($expx,$parmk,"F",$parmk,0);
                
            }
            break;
            default:
        }
        $zz=UX("update coode_divfrmeles set widthx='1*parw',heightx='1*parh' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%Srd'");
        $zz=UX("update coode_divfrmeles set widthx='1*parw',heightx='1*parh' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%O1'");
        $zz=UX("update coode_divfrmeles set widthx='1*parw',heightx='0.5*parh' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%"."A1'");
        $zz=UX("update coode_divfrmeles set widthx='1*parw',heightx='0.5*parh' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%"."A2A3Srd'");
        $zz=UX("update coode_divfrmeles set widthx='0.5*parw',heightx='1*parh',divstyle='float:left;' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%"."A2'");
        $zz=UX("update coode_divfrmeles set widthx='0.5*parw',heightx='1*parh',divstyle='float:left;' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%"."A3'");
        
        $zz=UX("update coode_divfrmeles set widthx='1*parw',heightx='0.5*parh' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%V1V2Srd'");
        $zz=UX("update coode_divfrmeles set widthx='0.5*parw',heightx='1*parh',divstyle='float:left;' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%V1'");
        $zz=UX("update coode_divfrmeles set widthx='0.5*parw',heightx='1*parh',divstyle='float:left;' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%V2'");
        $zz=UX("update coode_divfrmeles set widthx='1*parw',heightx='0.5*parh' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%V3'");
        
        $zz=UX("update coode_divfrmeles set widthx='1*parw',heightx='0.5*parh' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%H1'");
        $zz=UX("update coode_divfrmeles set widthx='1*parw',heightx='0.5*parh' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%H2'");
        $zz=UX("update coode_divfrmeles set widthx='0.5*parw',heightx='1*parh',divstyle='float:left;' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%N1'");
        $zz=UX("update coode_divfrmeles set widthx='0.5*parw',heightx='1*parh',divstyle='float:left;' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%N2'");
        
        $zz=UX("update coode_divfrmeles set widthx='1*parw',heightx='0.5*parh' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%"."C1C2Srd'");
        $zz=UX("update coode_divfrmeles set widthx='1*parw',heightx='0.5*parh' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%"."C3C4Srd'");
        $zz=UX("update coode_divfrmeles set widthx='0.5*parw',heightx='1*parh',divstyle='float:left;' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%"."C1'");
        $zz=UX("update coode_divfrmeles set widthx='0.5*parw',heightx='1*parh',divstyle='float:left;' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%"."C2'");
        $zz=UX("update coode_divfrmeles set widthx='0.5*parw',heightx='1*parh',divstyle='float:left;' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%"."C3'");
        $zz=UX("update coode_divfrmeles set widthx='0.5*parw',heightx='1*parh',divstyle='float:left;' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%"."C4'");
        
        $zz=UX("update coode_divfrmeles set widthx='0.333*parw',heightx='1*parh',divstyle='float:left;' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%M1'");
        $zz=UX("update coode_divfrmeles set widthx='0.333*parw',heightx='1*parh',divstyle='float:left;' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%M2'");
        $zz=UX("update coode_divfrmeles set widthx='0.333*parw',heightx='1*parh',divstyle='float:left;' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%M3'");
        
        $zz=UX("update coode_divfrmeles set widthx='0.25*parw',heightx='1*parh',divstyle='float:left;' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%W1'");
        $zz=UX("update coode_divfrmeles set widthx='0.25*parw',heightx='1*parh',divstyle='float:left;' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%W2'");
        $zz=UX("update coode_divfrmeles set widthx='0.25*parw',heightx='1*parh',divstyle='float:left;' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%W3'");
        $zz=UX("update coode_divfrmeles set widthx='0.25*parw',heightx='1*parh',divstyle='float:left;' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%W4'");
        
        $zz=UX("update coode_divfrmeles set widthx='1*parw',heightx='0.333*parh' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%"."E1'");
        $zz=UX("update coode_divfrmeles set widthx='1*parw',heightx='0.333*parh' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%"."E2'");
        $zz=UX("update coode_divfrmeles set widthx='1*parw',heightx='0.333*parh' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%"."E3'");
        
        $zz=UX("update coode_divfrmeles set widthx='1*parw',heightx='0.25*parh' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%"."F1'");
        $zz=UX("update coode_divfrmeles set widthx='1*parw',heightx='0.25*parh' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%"."F2'");
        $zz=UX("update coode_divfrmeles set widthx='1*parw',heightx='0.25*parh' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%"."F3'");
        $zz=UX("update coode_divfrmeles set widthx='1*parw',heightx='0.25*parh' where instmark='".$parmk."' and mothersrd='".$expx."' and frmmark like '%"."F4'");
        $elerst=SX("select SNO,myid,parid from coode_divfrmeles where instmark='".$parmk."' and mothersrd='".$expx."'");
        $tote=countresult($elerst);
        for ($pp=0;$pp<$tote;$pp++){
          $snox=anyvalue($elerst,"SNO",$pp);
          $myidx=anyvalue($elerst,"myid",$pp);
          $paridx=anyvalue($elerst,"parid",$pp);
          $exty=UX("select count(*) as result from coode_divfrmeles where instmark='".$parmk."' and mothersrd='".$expx."' and parid='".$myidx."'");
          if (intval($exty)>0){
          }else{
            $zz=UX("update coode_divfrmeles set STATUS=1 where SNO=".$snox);
          }
           $prst=SX("select widthx,heightx,divstyle,divhcode from coode_divfrmeles  where instmark='".$parmk."' and mothersrd='".$expx."' and myid='".$paridx."'");
           $pwx=anyvalue($prst,"widthx",0);
           $phx=anyvalue($prst,"heightx",0);
           $dstl=anyvalue($prst,"divstyle",0);
           $dhcode=anyvalue($prst,"divhcode",0);
           $zz=UX("update coode_divfrmeles set parhcode='".$dhcode."',parstyle='".$dstl."',parwx='".$pwx."',parhx='".$phx."' where SNO=".$snox);
        }
        return true;
    }else{
        return false;
    }
}
function tempele($mk,$parmk){
    $fme="";
    switch($mk){
        case "O":
        //O1
        $fme=$parmk."O1,";
        return $fme;
        break;
        case "A":
        $fme=$parmk."A1,".$parmk."A2,".$parmk."A3,";
        return $fme;
        break;
        case "V":
        //VSrd,V1V2Srd,V1,v2,v3
        $fme=$parmk."V1,".$parmk."V2,".$parmk."V3,";
        return $fme;
        break;
        case "C":
        $fme=$parmk."C1,".$parmk."C2,".$parmk."C3,".$parmk."C4,";
         return $fme;
        break;
        case "H":
        //HSrd,H1,H2
        $fme=$parmk."H1,".$parmk."H2,";
        return $fme;
        break;
        case "N":
        //NSrd,N1,N2
        $fme=$parmk."N1,".$parmk."N2,";
        return $fme;
        break;
        case "M":
        //MSrd,M1,M2,M3
        $fme=$parmk."M1,".$parmk."M2,".$parmk."M3,";
        return $fme;
        break;
        case "W":
        //WSrd,W1,W2,W3,W4
        $fme=$parmk."W1,".$parmk."W2,".$parmk."W3,".$parmk."W4,";
         return $fme;
        break;
        case "E":
        //ESrd,E1,E2,E3
        $fme=$parmk."E1,".$parmk."E2,".$parmk."E3,";
        return $fme;
        break;
        case "F":
        //FSrd,F1,F2,F3,F4
        $fme=$parmk."F1,".$parmk."F2,".$parmk."F3,".$parmk."F4,";
        return $fme;
        break;
        default:
        $fme=$parmk.$mk."x,";
        return $fme;
    }
}
function comeles($expx,$parmk){
    //FAWN Visit HOME 快速记忆
    if (strlen($expx)>0){
        $mkx=qian($expx,"=");
        $mvy=hou($expx,"=");
        $ptlen=strlen($mvy);
        switch($ptlen){
            case 1:
              $ptmvy[0]=substr($mvy,0,1);
            break;
            case 2:
              $ptmvy[0]=substr($mvy,0,1);
              $ptmvy[1]=substr($mvy,1,1);
            break;
            case 3:
              $ptmvy[0]=substr($mvy,0,1);
              $ptmvy[1]=substr($mvy,1,1);
              $ptmvy[2]=substr($mvy,2,1);
            break;
            case 4:
              $ptmvy[0]=substr($mvy,0,1);
              $ptmvy[1]=substr($mvy,1,1);
              $ptmvy[2]=substr($mvy,2,1);
              $ptmvy[3]=substr($mvy,3,1);
            break;
            default:
            
        }
        $leftx="";
        $fma="";
        $fmb="";
        switch($mkx){
            case "A":
            if (strlen($mvy)==3){
                $fma="A1,A2,A3";
                $fmb=$fmb.tempele($ptmvy[0],$parmk."A1");
                $fmb=$fmb.tempele($ptmvy[1],$parmk."A2");
                $fmb=$fmb.tempele($ptmvy[2],$parmk."A3");
            }else{
                $fma="A1,A2,A3";
                $fmb="";
            }
            break;
            case "V":
            if (strlen($mvy)==3){
                $fma="V1,V2,V3";
                $fmb=$fmb.tempele($ptmvy[0],$parmk."V1");
                $fmb=$fmb.tempele($ptmvy[1],$parmk."V2");
                $fmb=$fmb.tempele($ptmvy[2],$parmk."V3");
            }else{
                $fma="V1,V2,V3";
                $fmb="";
            }
            break;
            case "C":
            if (strlen($mvy)==4){
                $fma="C1,C2,C3,C4";
                $fmb=$fmb.tempele($ptmvy[0],$parmk."C1");
                $fmb=$fmb.tempele($ptmvy[1],$parmk."C2");
                $fmb=$fmb.tempele($ptmvy[2],$parmk."C3");
                $fmb=$fmb.tempele($ptmvy[3],$parmk."C4");
            }else{
                $fma="C1,C2,C3,C4";
                $fmb="";
            }
            break;
            case "H":
            if (strlen($mvy)==2){
                $fma="H1,H2";
                $fmb=$fmb.tempele($ptmvy[0],$parmk."H1");
                $fmb=$fmb.tempele($ptmvy[1],$parmk."H2");
            }else{
                $fma="H1,H2";
                $fmb="";
            }
            break;
            case "N":
            if (strlen($mvy)==2){
                $fma="N1,N2";
                $fmb=$fmb.tempele($ptmvy[0],$parmk."N1");
                $fmb=$fmb.tempele($ptmvy[1],$parmk."N2");
            }else{
                $fma="N1,N2";
                $fmb="";
            }
            break;
            case "M":
            if (strlen($mvy)==3){
                $fma="N1,N2";
                $fmb=$fmb.tempele($ptmvy[0],$parmk."M1");
                $fmb=$fmb.tempele($ptmvy[1],$parmk."M2");
            }else{
                $fma="M1,M2";
                $fmb="";
            }
            break;
            case "W":
            if (strlen($mvy)==4){
                $fma="W1,W2,W3,W4";
                $fmb=$fmb.tempele($ptmvy[0],$parmk."W1");
                $fmb=$fmb.tempele($ptmvy[1],$parmk."W2");
                $fmb=$fmb.tempele($ptmvy[2],$parmk."W3");
                $fmb=$fmb.tempele($ptmvy[3],$parmk."W4");
                
            }else{
                $fma="W1,W2,W3,W4";
                $fmb="";
            }
            break;
            case "E":
            if (strlen($mvy)==3){
                $fma="E1,E2,E3";
                $fmb=$fmb.tempele($ptmvy[0],$parmk."E1");
                $fmb=$fmb.tempele($ptmvy[1],$parmk."E2");
                $fmb=$fmb.tempele($ptmvy[2],$parmk."E3");
            }else{
                $fma="E1,E2,E3";
                $fmb="";
            }
            break;
            case "F":
            if (strlen($mvy)==4){
                $fma="F1,F2,F3,F4";
                $fmb=$fmb.tempele($ptmvy[0],$parmk."F1");
                $fmb=$fmb.tempele($ptmvy[1],$parmk."F2");
                $fmb=$fmb.tempele($ptmvy[2],$parmk."F3");
                $fmb=$fmb.tempele($ptmvy[3],$parmk."F4");
            }else{
                $fma="F1,F2,F3,F4";
                $fmb="";
            }
            break;
            default:
                $fma=$mkx;
                $fmb="";
        }
        return $parmk."@".$fma."/".$fmb;
    }else{
        return "";
    }
}
function exdivpara($keyx,$estr){
$bstr="";
  switch($estr){
    case "1*parw":
    $bstr="100%;";
    break;
    case "1*parh":
    $bstr="100%;";
    break;
    case "0.5*parw":
    $bstr="50%;";
    break;
    case "0.5*parh":
    $bstr="50%;";
    break;
    case "0.333*parw":
    $bstr="33.3%;";
    break;
    case "0.333*parh":
    $bstr="33.3%;";
    break;
    case "0.25*parw":
    $bstr="25%;";
    break;
    case "0.25*parh":
    $bstr="25%;";
    break;
    default:
    if (strpos($estr,"*par")>0){
      $bstr=(qian($estr,"*par")*100)."%;";
    }else{
      $bstr=$estr.";";
    }
  }
  if ($keyx!="" and $estr!=""){
    return $keyx.$bstr;
  }else{
    return "";
  }
}
function exdivparv($keyx,$estr,$parv){
$bstr="";
    if (strpos($estr,"*par")>0){
      if(intval($parv)==1){
       $bstr=(qian($estr,"*par")*100)."%;";
      }else{
       $bstr=(qian($estr,"*par")*$parv)."px;";
      }
    }else{
      $bstr=$estr.";";
    }
    if ($keyx!="" and $estr!="" and intval($parv)>0){
      return $keyx.$bstr;
    }else{
      return "";
    }
}
function makedivnewstyle($basestyle,$imark,$expx,$fmk){
   $divrst=SX("select widthx,heightx,divtype,marleft,martop,marright,marbottom,mypdleft,mypdtop,mypdright,mypdbottom from coode_divfrmeles where instmark='".$imark."' and mothersrd='".str_replace("@","=",$expx)."' and frmmark='".$fmk."'");    
   $totdiv=countresult($divrst);  
   $fmstl="";
   if (intval($totdiv)>0){
      $widthx=anyvalue($divrst,"widthx",0);
      $fmstl=$fmstl.exdivpara("width:",$widthx);
      $heightx=anyvalue($divrst,"heightx",0);
      $fmstl=$fmstl.exdivpara("height:",$heightx);
      $divtype=anyvalue($divrst,"divtype",0);
      $marleft=anyvalue($divrst,"marleft",0);
      $fmstl=$fmstl.exdivpara("margin-left:",$marleft);
      $martop=anyvalue($divrst,"martop",0);
      $fmstl=$fmstl.exdivpara("margin-top:",$martop);
      $marright=anyvalue($divrst,"marright",0);
      $fmstl=$fmstl.exdivpara("margin-right:",$marright);
      $marbottom=anyvalue($divrst,"marbottom",0);
      $fmstl=$fmstl.exdivpara("margin-bottom:",$marbottom);
      $mypdleft=anyvalue($divrst,"mypdleft",0);
      $fmstl=$fmstl.exdivpara("padding-left:",$mypdleft);
      $mypdtop=anyvalue($divrst,"mypdtop",0);
      $fmstl=$fmstl.exdivpara("padding-top:",$mypdtop);
      $mypdright=anyvalue($divrst,"mypdright",0);
      $fmstl=$fmstl.exdivpara("padding-right:",$mypdright);
      $mypdbottom=anyvalue($divrst,"mypdbottom",0);
      $fmstl=$fmstl.exdivpara("padding-bottom:",$mypdbottom);      
      return $basestyle.$fmstl;
   }else{
      return $basestyle;
   }
}
function makedivvalstyle($basestyle,$imark,$expx,$fmk,$wdx,$hdx){
   $divrst=SX("select widthx,heightx,divtype,marleft,martop,marright,marbottom,mypdleft,mypdtop,mypdright,mypdbottom from coode_divfrmeles where instmark='".$imark."' and mothersrd='".str_replace("@","=",$expx)."' and frmmark='".$fmk."'");
   $totdiv=countresult($divrst);  
   $fmstl="";
   if (intval($totdiv)>0){
      $widthx=anyvalue($divrst,"widthx",0);
      $fmstl=$fmstl.exdivparv("width:",$widthx,$wdx);
      $heightx=anyvalue($divrst,"heightx",0);
      $fmstl=$fmstl.exdivparv("height:",$heightx,$hdx);
      $divtype=anyvalue($divrst,"divtype",0);
      $marleft=anyvalue($divrst,"marleft",0);
      $fmstl=$fmstl.exdivparv("margin-left:",$marleft,$wdx);
      $martop=anyvalue($divrst,"martop",0);
      $fmstl=$fmstl.exdivparv("margin-top:",$martop,$hdx);
      $marright=anyvalue($divrst,"marright",0);
      $fmstl=$fmstl.exdivparv("margin-right:",$marright,$wdx);
      $marbottom=anyvalue($divrst,"marbottom",0);
      $fmstl=$fmstl.exdivparv("margin-bottom:",$marbottom,$hdx);
      $mypdleft=anyvalue($divrst,"mypdleft",0);
      $fmstl=$fmstl.exdivparv("padding-left:",$mypdleft,$wdx);
      $mypdtop=anyvalue($divrst,"mypdtop",0);
      $fmstl=$fmstl.exdivparv("padding-top:",$mypdtop,$hdx);
      $mypdright=anyvalue($divrst,"mypdright",0);
      $fmstl=$fmstl.exdivparv("padding-right:",$mypdright,$wdx);
      $mypdbottom=anyvalue($divrst,"mypdbottom",0);
      $fmstl=$fmstl.exdivparv("padding-bottom:",$mypdbottom,$hdx);      
      return $basestyle.$fmstl;
   }else{
      return $basestyle;
   }
}
?>