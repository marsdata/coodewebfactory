<?php
function addcdtrdr($tnmk,$pointx,$rdrurl){
$extc=UX("select count(*) as result from coode_cdtrdr where cdtmark='".$tnmk."' and cdtval='".$pointx."'");
 if (intval($extc)==0){
   $sqlx="cdtmark,cdtval,rdrpath,CRTM,UPTM,OLMK";
   $sqly="'$tnmk','$pointx','$rdrurl',now(),now(),'".onlymark()."'";
   $zz=UX("insert into coode_cdtrdr(".$sqlx.")values(".$sqly.")");
 }else{
   $uu=UX("update coode_cdtrdr set rdrpath='".$rdrurl."',UPTM=now() where cdtmark='".$tnmk."' and cdtval='".$pointx."'");
 }
 return true;
}
function tellmysrc($srctype,$srcid,$srctitle,$sysidx,$dtdata){
    $restype=$srctype;
    $resmark=$srcid;
    $rescode=$srcid;    
 
    if ( $_SERVER['SERVER_PORT']=="443"){     
      $fromhost="https://".$_SERVER["HTTP_HOST"];
    }else if ($_SERVER['SERVER_PORT']=="80"){
      $fromhost="http://".$_SERVER["HTTP_HOST"];
    }else{
      $fromhost="http://".$_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"];
    }
        
    $pdata=array();
    $zz=file_get_contents("http://".combineurl(glw(),"/localxres/funx/savetoseed/?sysid=".$sysidx."&restype=".$restype."&resmark=".$resmark));
    //执行完这个之后系统就会生成新的MD5
   switch($restype){
     case "funx":   
     //1
     $orst=SX("select sysid,vermd5,funcname,funfull from coode_funlist  where funname='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"funcname",0);
     $restext=anyvalue($orst,"funfull",0);
     break;
     case "sfunx":
     //2
     $orst=SX("select sysid,vermd5,setcname,funbody from coode_funsetfile  where setname='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"setcname",0);
     $restext=anyvalue($orst,"funbody",0);
     break;
     case "dfunx":
     //3
     $orst=SX("select sysid,vermd5,dftitle,dfuneval from coode_datafun where dfunmark='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"dftitle",0);
     $restext=anyvalue($orst,"dfuneval",0);
     break;
     case "mfunx":
     //4
     $orst=SX("select sysid,vermd5,funcname,funfull from  coode_multifunlist  where funname='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"funcname",0);
     $restext=anyvalue($orst,"funfull",0);
     break;
     case "clsx":
     //5
     $orst=SX("select sysid,vermd5,funcname,funfull from coode_phpcls  where funname='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"funcname",0);
     $restext=anyvalue($orst,"funfull",0);
     break;
     case "groupx":
     //6
     $orst=SX("select sysid,vermd5,markname from coode_grouplist  where plotmark='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"markname",0);
     $clsjson=file_get_contents(combineurl("http://".glw(),"/localxres/funx/anyshort/?stid=Q8Cfee&plotmark=".$rescode));
     $restext=gohex($clsjson);
     break;
     case "plotx":
     //7
     $orst=SX("select sysid,vermd5,markname from coode_plotlist  where plotmark='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $sqla="plotmark,myid,parid,mymark,mytitle,myurl,mydescrib,STATUS,CRTM,UPTM,OLMK";
     $sqlb="'".$nmd5."',myid,parid,mymark,mytitle,myurl,mydescrib,STATUS,now(),now(),RAND()*1000000";
     $szz=UX("insert into coode_plotmydetail(".$sqla.")select ".$sqlb." from coode_plotdetail where plotmark='".$rescode."' and concat('".$rescode."',mymark) not in(select concat(plotmark,mymark) from coode_plotmydetail)");
     $restitle=anyvalue($orst,"markname",0);     
     $plotjson=file_get_contents(combineurl("http://".glw(),"/localxres/funx/anyshort/?stid=NtpFd8&plmk=".$rescode."&pnum=1000"));
     $restext=gohex($plotjson);
     break;
     case "tabx":
     //8
     $orst=SX("select sysid,vermd5,tabtitle,createsql from coode_tablist  where TABLE_NAME='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"tabtitle",0);
     $restext=anyvalue($orst,"createsql",0);
     break;
     case "formx":
     //9
     $orst=SX("select sysid,vermd5,shorttitle,showkeys  from coode_shortdata  where shortid='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"shorttitle",0);
     $orifilex=combineurl(localroot(),"/localxres/formx/".$rescode."/index.html");
     $orifiley=combineurl(localroot(),"/localxres/formx/".$rescode."/detail.html");
     $newindex=combineurl(localroot(),"/localxres/formx/".$rescode."/index-".$nmd5.".html");
     $newdetail=combineurl(localroot(),"/localxres/formx/".$rescode."/detail-".$nmd5.".html");
     $restext=$newindex;
     $ftxtx=file_get_contents($orifilex);
     $ftxty=file_get_contents($orifiley);
     $zzx=overfile($newindex,$ftxtx);
     $zzy=overfile($newdetail,$ftxty);
     
     break;
     case "pagex":
     //10
     $orst=SX("select sysid,appid,layid,vermd5,tinytitle,laypath from coode_tiny where tinymark='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"tinytitle",0);
     $laypath=anyvalue($orst,"laypath",0);     
     $newpath=str_replace("index.html","index-".$nmd5.".html",$laypath);
     $newfile=combineurl(localroot(),$newpath);
     $restext=$newpath;
     $orifilex=combineurl(localroot(),$laypath);
     $ftxtx=file_get_contents($orifilex);
     $bb=addcdtrdr($rescode,$nmd5,$newpath);
     $zzx=overfile($newfile,$ftxtx);
     break;
     case "cdtrdrx":
     //11
     $orst=SX("select sysid,vermd5,cdtmark,cdtval,rarpath,rdrcode from coode_cdtrdr  where concat(cdtmark,'-',cdtval)='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"cdtval",0);
     $restext=dftval(anyvalue($orst,"rdrpath",0),anyvalue($orst,"rdrcode",0));
     break;
     case "parardrx":
     //12
     $orst=SX("select sysid,vermd5,paratitle,rdrpath,rdrcode from coode_parardr  where paramark='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"paratitle",0);
     $restext=dftval(anyvalue($orst,"rdrpath",0),anyvalue($orst,"rdrcode",0));
     break;
     case "constx":
     //13
     $orst=SX("select sysid,vermd5,constanttitle,constantvalue from coode_sysconstant  where constantid='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"constanttitle",0);
     $restext=anyvalue($orst,"constantvalue",0);
     break;
     case "configx":
     //14
     $orst=SX("select sysid,vermd5,sysktitle,sysval from  coode_sysconfig  where syskey='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"sysktitle",0);
     $restext=anyvalue($orst,"sysval",0);
     break;
     case "dataspacex":
     //15
     $orst=SX("select sysid,vermd5,datatitle from coode_dataspace  where datamark='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"datatitle",0);
     $dsjson=file_get_contents(combineurl("http://".glw(),"/localxres/funx/anyshort/?stid=Kk2P4K&pnum=150:".$rescode."&page=1:datamark"));
     $restext=gohex($dsjson);     
     break;
     case "sysx":
     //16
     $orst=SX("select sysid,vermd5,sysname,indexurl from coode_sysinformation where sysid='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"sysname",0);
     $restext=anyvalue($orst,"indexurl",0);
     break;
     case "appx":
     //17
     $orst=SX("select sysid,vermd5,appname,inurl from coode_appdefault  where appid='".$rescode."' and sysid='".$sysidx."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"appname",0);
     $restext=anyvalue($orst,"inurl",0);
     break;
     case "layx":
     //18
     $orst=SX("select sysid,vermd5,laytitle,pagelay,mobilelay from coode_applay  where layid='".$rescode."' and sysid='".$sysidx."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"laytitle",0);
     $restext=anyvalue($orst,"pagelay",0).".".anyvalue($orst,"mobilelay",0);
     break;
     case "tempx":
     //19
     $orst=SX("select sysid,vermd5,unittitle,templatecode from coode_domainunit  where dumark='".$rescode."' and sysid='".$sysidx."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"unittitle",0);
     $restext=anyvalue($orst,"templatecode",0);
     break;
     case "afunx":
     //20
     $orst=SX("select sysid,vermd5,funcname,funfull from coode_affairfunlist  where funname='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"funcname",0);
     $restext=anyvalue($orst,"funfull",0);
     break;
     case "databasex":
     $orst=SX("select sysid,dbmark,dbtitle,vermd5 from coode_dblist  where dbmark='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"dbtitle",0);
     $restext="";
     //21
     break;
     case "apix":
     //22
     $orst=SX("select sysid,apititle,vermd5 from coode_apipool  where apicode='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"apititle",0);
     $restext="";
     break;     
     case "parax":
     //23
     $orst=SX("select sysid,paramark,paratitle,vermd5 from coode_para  where paramark='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"paratitle",0);
     $restext="";
     break;
     case "csspagex":     
     //24
     $orst=SX("select sysid,faceid,facetitle,vermd5 from coode_facelist  where faceid='".$rescode."'");
     $nmd5=anyvalue($orst,"vermd5",0);
     $sysid=anyvalue($orst,"sysid",0);
     $restitle=anyvalue($orst,"facetitle",0);
     break;
     case "iconsetx":
     $orst=SX("select setmark,settitle from coode_iconset  where setmark='".$rescode."'");
     $sysid="0";
     $restitle=anyvalue($orst,"settitle",0);
     break;
     default:
    }
    $pdata["restext"]=$restext;
    if ($srctype=="pagex"){
     $resurl=combineurl($fromhost,"/localxres/pagex/seedx/".$srcid."/".$srcid."_pagex.zip");
    }else if ($srctype=="tempx"){
     $resurl=combineurl($fromhost,"/localxres/".$srctype."/".qian($srcid,".")."/".qian($srcid,".")."_tempx.zip");
    }else{
     $resurl=combineurl($fromhost,"/localxres/".$srctype."/".str_replace(".","_",$srcid)."/".str_replace(".","_",$srcid)."_".$srctype.".zip");
    }
    
    $pdata["resurl"]=$resurl;
    $pdata["vmd5"]=$nmd5;
    $pdata["hostcode"]=hostcode();
    $pdata["resmark"]=$srcid;
    $pdata["restype"]=$srctype;
    $pdata["restitle"]=$restitle;
    $pdata["fromhost"]=$fromhost;
    if ( $resmark!="" and $restype!=""){
      //在这里要生成 SQL INDEX.JSON .ZIP等一系列文件
      if (glm()!="motherhost"){
       $mthost=anyfunrun("svshost",glm(),"hostid=".$sysid,"");
       if (strpos($mthost,":443")>0){
        $purl="https://".str_replace(":443","",$mthost)."/localxres/funx/bakclientres/?restype=".$restype."&resmark=".$resmark."&clientcode=".hostcode()."&crtor=".$_COOKIE["cid"]."/".$_COOKIE["uid"];
       }else{
        $purl="http://".$mthost."/localxres/funx/bakclientres/?restype=".$restype."&resmark=".$resmark."&clientcode=".hostcode()."&crtor=".$_COOKIE["cid"]."/".$_COOKIE["uid"];
       }
       $zz=request_post($purl,$pdata);
      }
      
      return $zz;
    }else{
 
      return "参数不对，或者本机为母机";  
    }
}
function datamd5($durl,$dmd5){
    $extx=UX("select count(*) as result from coode_waitforaspdata where dataurl='".qian($durl,"?")."' and vmd5='".$dmd5."'");
    if (intval($extx)>0 or strlen($dmd5)!=32){
        return false;
    }else{
        return true;
    }
}
function setdatamd5($durl,$dmd5,$dtxt){
    $extx=UX("select count(*) as result from coode_waitforaspdata where dataurl='".qian($durl,"?")."' and vmd5='".$dmd5."'");
    if (intval($extx)==0 and strlen($dmd5)==32){
     $sqlx="dataurl,asktime,vmd5,datatxt";
     $sqly="'".qian($durl,"?")."',now(),'$dmd5','".$dtxt."'";
     $zz=UX("insert into coode_waitforaspdata(".$sqlx.")values(".$sqly.")");
     return true;
    }else{
        return false;
    }
}
?>