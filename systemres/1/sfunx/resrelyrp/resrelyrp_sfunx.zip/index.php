<?php
function killtpfile($dirx,$ftype){
 $directory = $dirx; // 指定目录路径
 $files = glob($directory . '/*.'.$ftype); // 获取所有.json文件
 foreach ($files as $file) {
   if (is_file($file)) {
      unlink($file); // 删除文件
   }
 }
 return true;
}
function judgefun($fxid){
  $rtntxt=UX("select concat(areatype,'@',funname) as result from coode_funcool where funname='".$fxid."'");
  return $rtntxt;
}
function resvermd5($restype,$rescode){
  switch($restype){
   case "funx":  //1
   $zz=UX("update coode_funlist set vermd5=md5(concat(funcname,funfull)) where funname='".$rescode."' or  funname='".$rescode."()'");
   $vmd5=UX("select vermd5 as result from coode_funlist where funname='".$rescode."'");
   break;
   case "dfunx": //2
   $zz=UX("update coode_datafun set vermd5=md5(concat(dftitle,dfuneval)) where dfunmark='".$rescode."'");
   $vmd5=UX("select vermd5 as result from coode_datafun where dfunmark='".$rescode."'");
   break;
   case "sfunx":  //3
   $zz=UX("update coode_funsetfile set vermd5=md5(concat(setcname,funbody)) where setname='".$rescode."'");
   $vmd5=UX("select vermd5 as result from coode_funsetfile where setname='".$rescode."'");
   break;
   case "mfunx":  //4
   $zz=UX("update coode_multifunlist set vermd5=md5(concat(funcname,funbody)) where funname='".$rescode."'");
   $vmd5=UX("select vermd5 as result from coode_multifunlist where funname='".$rescode."'");
   break;
   case "afunx":  //5
   $zz=UX("update coode_affairfunlist set vermd5=md5(concat(funcname,funbody)) where funname='".$rescode."'");
   $vmd5=UX("select vermd5 as result from coode_affairfunlist where funname='".$rescode."'");
   break;
   case "dataspacex":  //6
    $d1rst=SX("select datatitle,jsondata from coode_dataspace where datamark='".$rescode."'");
    $d2rst=SX("select md5(concat(keymark,keytitle,keylen,clstxt,classp,sqx,keytype,dxtype,keydescrib)) as result from coode_dspckey where datamark='".$rescode."'");    
    $vmd5=md5($d1rst.$d2rst);
    $zz=UX("update coode_dataspace set vermd5='".$vmd5."' where datamark='".$rescode."'");
   break;
   case "databasex":  //7
    $zz=UX("update coode_dblist set vermd5=md5(concat(dbname,dbtitle,dbtype,dbip,dbus,dbps,dbdomain)) where dbmark='".$rescode."'");
    $vmd5=UX("select vermd5 as result from coode_dblist where dbmark='".$rescode."'");
   break;
   case "tabx":  //8
    $d1rst=SX("select tabtitle,createsql from coode_tablist where TABLE_NAME='".$rescode."'");
    $d2rst=SX("select md5(concat(keytitle,valuezero,keyexplain,jsshowfun,sysshowfun,jspostfun,syspostfun,bfist,aftist,bfupd,aftupd,bfdel,aftdel,SQX,VQX,isfixed,changeable,displayed,dxtype,COLUMN_TYPE)) as result from coode_keydetailx where TABLE_NAME='".$rescode."'");
    $vmd5=md5($d1rst.$d2rst);
    $zz=UX("update coode_tablist set vermd5='".$vmd5."' where TABLE_NAME='".$rescode."'");
   break;
   case "formx":  //9
    $d1rst=SX("select shorttitle,caseid,detailid,tablename,cdt,orddt,dttp,addtitle,addpage from coode_shortdata where shortid='".$rescode."'");
    $d2rst=SX("select md5(concat(keytitle,valuezero,keyexplain,jsshowfun,sysshowfun,jspostfun,syspostfun,bfist,aftist,bfupd,aftupd,bfdel,aftdel,SQX,VQX,isfixed,changeable,displayed,dxtype,COLUMN_TYPE)) as result from coode_keydetaily where shortid='".$rescode."'");
    $d3rst=SX("select jsfiles,cssfiles,scriptx,stylex,diytop,diybottom from coode_shortcss where shortid='".$rescode."'");
    $vmd5=md5($d1rst.$d2rst.d3rst);
    $zz=UX("update coode_shortdata set vermd5='".$vmd5."' where shortid='".$rescode."'");
   break;
   case "plotx":  //10
    $d1rst=SX("select plotcls,levelcount,totpoint,markname from coode_plotlist where plotmark='".$rescode."'");
    $d2rst=SX("select md5(concat(level,myid,parid,oriid,mytitle,mymark,myurl,myclick,fontname,fontshow,mydescrib)) as result from coode_plotdetail where plotmark='".$rescode."'");
    $vmd5=md5($d1rst.$d2rst);
    $zz=UX("update coode_plotlist set vermd5='".$vmd5."' where plotmark='".$rescode."'");
   break;
   case "groupx":  //11
    $d1rst=SX("select layoutid,markname,defaultcss,formcode,clickfun from coode_grouplist where plotmark='".$rescode."'");
    $d2rst=SX("select md5(concat(domain,keyid,keyval,compid,groupid,clientid,totsrc)) as result from coode_grpclass where clsmark='".$rescode."'");
    $vmd5=md5($d1rst.$d2rst);
    $zz=UX("update coode_grouplist set vermd5='".$vmd5."' where plotmark='".$rescode."'");
   break;
   case "tempx":  //12
    $d1rst=SX("select relyface,unittitle,md5(concat(unitclass,funcls,outurl,casecode,cssfilex,stylex,scriptx,jsfilex,templatecode,pagesurround)) from coode_domainunit where dumark='".$rescode."'");
    $d2rst=SX("select md5(concat(keytype,keydemo)) as result from coode_codedemo where dumark='".$rescode."'");
    $d3rst=SX("select evalcode from coode_makedujsfile where dumark='".$rescode."'");
    $d4rst=SX("select evalcode from coode_makeformact where dumark='".$rescode."'");
    $vmd5=md5($d1rst.$d2rst.$d3rst.$d4rst);
    $zz=UX("update coode_domainunit set vermd5='".$vmd5."' where dumark='".$rescode."'");
   break;
   case "csspagex":  //13
   $zz=UX("update coode_faceist set vermd5=md5(concat(facetype,facecolor,filepath)) where faceid='".$rescode."'");
   $vmd5=UX("select vermd5 as result from coode_facelist where faceid='".$rescode."'");
   break;
   case "pagex":  //14
    $d1rst=SX("select imghead,tinytitle,longexp,shortid,tabname,sysid,appid,layid from coode_tiny where tinymark='".$rescode."'");
    $d2rst=SX("select md5(concat(unittitle,unitclass,outurl,cssfilex,stylex,scriptx,jsfilex,casecode,templatecode,pagesurround)) as result from coode_unittiny where tinyid='".$rescode."'");
    $vmd5=md5($d1rst.$d2rst);
    $zz=UX("update coode_tiny set vermd5='".$vmd5."' where tinyid='".$rescode."'");
   break;
   case "cdtrdrx":  //15
    $d1rst=SX("select md5(concat(cdtval,rdrpath,rdrcode)) from coode_cdtrdr where concat(cdtmark,'.',cdtval)='".$rescode."'");
    
    $vmd5=md5($d1rst);
    $zz=UX("update coode_cdtrdr set vermd5='".$vmd5."' where concat(cdtmark,'.',cdtval)='".$rescode."'");
   break;
   case "parardrx":  //16
   $zz=UX("update coode_parardr set vermd5=md5(concat(paratitle,paratype,parapoint,paraval,rdrpath,rdrcode,ismbl)) where paramark='".$rescode."'");
   $vmd5=UX("select vermd5 as result from coode_parardr where paramark='".$rescode."'");
   break;
   case "constx":  //17
   $zz=UX("update coode_sysconstant set vermd5=md5(concat(constanttitle,constanttype,constantvalue)) where  constantid='".$rescode."'");
   $vmd5=UX("select vermd5 as result from coode_sysconstant where constantid='".$rescode."'");
   break;
   case "configx":  //18
   $zz=UX("update coode_sysconfig set vermd5=md5(concat(sysktitle,sysval)) where  syskey='".$rescode."'");
   $vmd5=UX("select vermd5 as result from coode_sysconfig where syskey='".$rescode."'");
   break;
   case "sysx":   //19
   $zz=UX("update coode_sysinformation set vermd5=md5(concat(sysname,indexurl,loginurl,inurl,custinurl,outurl,totres)) where  sysid='".$rescode."'");
   $vmd5=UX("select vermd5 as result from coode_sysinformation where sysid='".$rescode."'");
   break;
   case "appx":   //20
   $zz=UX("update coode_appdefault set vermd5=md5(concat(appname,sysid,faceimg,appdetail,inurl,outurl)) where  appid='".$rescode."'");
   $vmd5=UX("select vermd5 as result from coode_appdefault where appid='".$rescode."'");
   break;
   case "layx":   //21
   $zz=UX("update coode_applay set vermd5=md5(concat(sysid,sysid,laytitle,colora,colorb,pagelay,mobilelay)) where  layid='".$rescode."'");
   $vmd5=UX("select vermd5 as result from coode_applay where layid='".$rescode."'");
   break;
   case "prarx":   //22
   $zz=UX("update coode_para set vermd5=md5(concat(paratitle,paradescrib,parapath,paravender,parawebsite,paraversion)) where  paramark='".$rescode."'");
   $vmd5=UX("select vermd5 as result from coode_para where paramark='".$rescode."'");
   break;
   case "apix":   //23
   $zz=UX("update coode_apipool set vermd5=md5(concat(apikey,apival,apititle,parcode,partitle)) where  appid='".$rescode."'");
   $vmd5=UX("select vermd5 as result from coode_apipool where appid='".$rescode."'");
   break;
   case "smallcssx":  //24
   $zz=UX("update coode_tinyhtml set vermd5=md5(concat(eletitle,eletype,cssfilex,jsfilex,jsscode,htmlcode,pagesrd,relypara,widthx,heightx,shapex,colors,sizefixed,isfloat,outurl)) where  elemark='".$rescode."'");
   $vmd5=UX("select vermd5 as result from coode_tinyhtml where elemark='".$rescode."'");
   break;
   case "clsx":  //25
   $zz=UX("update coode_phpcls set vermd5=md5(concat(funcname,funfull)) where  funname='".$rescode."'");
   $vmd5=UX("select vermd5 as result from coode_phpcls where funname='".$rescode."'");
   break;
   case "iconsetx":  //26
   $zz=UX("update coode_iconset set vermd5=md5(concat(settitle,imgmark,imgtitle,imglabel,imgtype,industry,colora,colorb,shapex)) where  setmark='".$rescode."'");
   $vmd5=UX("select vermd5 as result from coode_iconset where setmark='".$rescode."'");
   break;
   default:
  }
  return $vmd5;
}
function addsrctores($srctype,$srccode,$restype,$rescode){
  $exti=UX("select count(*) as result from coode_resrelyext where restype='".$restype."' and rescode='".$rescode."' and relyrestp='".$srctype."' and relyrescd='".$srccode."'");
  if (es($srctype)*es($srccode)*es($restype)*es($rescode)==1){
  if (intval($exti)==0){  
   $srctitle=UX("select restitle as result from coode_sysregres where restype='".$srctype."' and resmark='".$srccode."'");
   $restitle=UX("select restitle as result from coode_sysregres where restype='".$restype."' and resmark='".$rescode."'");
   $sqlx="restype,rescode,restitle,relyrestp,relyrescd,relyrestitle,CRTM,UPTM,OLMK";
   $sqly="'".$restype."','".$rescode."','".$restitle."','".$srctype."','".$srccode."','".$srctitle."',now(),now(),'".onlymark()."'";
   $zzz=UX("insert into coode_resrelyext(".$sqlx.")values(".$sqly.")");     
   return true;
  }else{
   $srctitle=UX("select restitle as result from coode_sysregres where restype='".$srctype."' and resmark='".$srccode."'");
   $restitle=UX("select restitle as result from coode_sysregres where restype='".$restype."' and resmark='".$rescode."'");
   $zz=UX("update coode_resrelyext set UPTM=now(),restitle='".$restitle."',relyrestitle='".$srctitle."' where restype='".$restype."' and rescode='".$rescode."' and relyrestp='".$srctype."' and relyrescd='".$srccode."'");
   return true;
  }
  }else{
   return false;
  }
}
function datatoinst($bmk,$relytab,$strtype,$strcdtx,$sysid,$restype,$rescode){
    $drst=SX("select SNO,frmsql,datasql from coode_datainstall where resid='".$bmk."'");    
    $totd=countresult($drst);
    $zz=addprc("funsetx","datatoinst-drst",28,"totd",$totd);
    $fmitem="";
    for ($p=0;$p<$totd;$p++){
     $snox=anyvalue($drst,"SNO",$p);
     $frmsql=anyvalue($drst,"frmsql",$p);
     $datasql=anyvalue($drst,"datasql",$p);
     if ($datasql!=""){
      $newsql=str_replace("[DATA]",$datasql,$frmsql).";";
     }else{
      $newsql="";
      $zz=UX("update coode_datainstall set STATUS=-1 where SNO=".$snox);
     }     
     $imd5=md5($newsql);
     $exti=UX("select count(*) as result from coode_resrelyinst where  sqlmd5='".$imd5."' and restype='".$restype."' and rescode='".$rescode."' and sysid='".$sysid."'");
     $zz=addprc("funsetx","addidtoinstall-exti",42,"exti-imd5",$exti."@".$imd5);
      if (intval($exti)==0 and $imd5!=""){
       $sqlx="sysid,restype,rescode,restitle,relytab,strtype,strcdt,sqlstring,sqlmd5,CRTM,UPTM,OLMK";
       $sqly="'".$sysid."','".$restype."','".$rescode."','插入一条".$rescode."依赖".$relytab."表的sql脚本数据','".$relytab."','".$strtype."','".gohex($strcdtx)."','".$newsql."','".$imd5."',now(),now(),'".onlymark()."'";
       $zz=UX("insert into coode_resrelyinst(".$sqlx.")values(".$sqly.")");      
       $zz=addprc("funsetx","addidtoinstall-istrelyinst",46,"zz=UX-ist-",$newsql);
      }else{
       $zz=UX("update coode_resrelyinst set restitle='插入一条".$rescode."依赖".$relytab."表的SQL脚本',UPTM=now(),relytab='".$relytab."',sqlstring='".$newsql."' where  sqlmd5='".$imd5."' and restype='".$restype."' and rescode='".$rescode."' and sysid='".$sysid."'");
       $zz=addprc("funsetx","addidtoinstall-istrelyinst",50,"zz=UX.UPD",$zz);
      }
    }
    return $totd;
}
function addidtoinstall($sysid,$restype,$rescode,$relytab,$strtype,$strcdt){
  switch($strtype){
   case "createsql":
   if ($relytab=="table@myself"){
    $relytab=$rescode;
   }
   $idata=UX("select createsql as result from coode_tablist where TABLE_NAME='".$relytab."'");
   if ($idata!=""){
    $imd5=md5($idata);
   }else{
    $imd5="";
   }
   $exti=UX("select count(*) as result from coode_resrelyinst where sqlmd5='".$imd5."' and restype='".$restype."' and rescode='".$rescode."' and sysid='".$sysid."'");
   if (intval($exti)==0){
    $sqlx="sysid,restype,rescode,restitle,relytab,strtype,strcdt,sqlstring,sqlmd5,CRTM,UPTM,OLMK";
    $sqly="'".$sysid."','".$restype."','".$rescode."','创建资源".$rescode."依赖表".$relytab."的sql脚本','".$relytab."','".$strtype."','".$strcdt."','".($idata)."','".$imd5."',now(),now(),'".onlymark()."'";
    $zz=UX("insert into coode_resrelyinst(".$sqlx.")values(".$sqly.")");     
   }else{
    $zz=UX("update coode_resrelyinst set restitle='创建资源".$rescode."依赖表',UPTM=now(),relytab='".$relytab."',sqlstring='".$idata."' where  sqlmd5='".$imd5."' and restype='".$restype."' and rescode='".$rescode."' and sysid='".$sysid."'");
   }
   return "tabsql";
   break;
   case "datasql":
    $strcdtx=str_replace("[default]",$rescode,$strcdt);
    $bmk=$rescode."@".$relytab.md5($strcdtx);
    $zz=addprc("funsetx","addidtoinstall.bf.bakinstall",50,"bmk:",$bmk);
    $totx=bakinstall($bmk,$relytab,$strcdtx);    
    $zz=addprc("funsetx","after-bakinstall",52,"totx",$totx);
    if (intval($totx)>0){
    $zz=addprc("funsetx","addidtoinstall-end",81,"return","true");
    return $bmk;
    }else{
     return "";
    }
   break;
   default:
  }
}
function makeresist($sysid,$restype,$rescode){
 if (es($sysid)*es($restype)*es($rescode)==1){
  $rdata=SX("select relytab,strtype,strcdt from coode_resrelydata where restype='".$restype."' and rescode='default' order by SQX");
  $totr=countresult($rdata);  
  $zz=addprc("funsetx","makeresist",87,"totr-count.rdata",$totr);
  $bkarr=Array();
  $tabarr=Array();
  $tparr=Array();
  $cdtarr=Array();
  $tmp=0;
  $fmcdt="";
  for ($j=0;$j<$totr;$j++){
    $relytab=anyvalue($rdata,"relytab",$j);
    $strtype=anyvalue($rdata,"strtype",$j);
    $strcdt=tostring(anyvalue($rdata,"strcdt",$j));
    $zz=addprc("funsetx","makeresist-to-addidtoinstall",92,"relytab-strtype,strcdt:",$relytab."@".$strtype."@".$strcdt);
    $bbk=addidtoinstall($sysid,$restype,$rescode,$relytab,$strtype,$strcdt);
    if ($bbk!="" and $bbk!="tabsql"){
     $bkarr[$tmp]=$bbk;
     $tabarr[$tmp]=$relytab;
     $tparr[$tmp]=$strtype;
     $cdtarr[$tmp]=$strcdt;
     $fmcdt=$fmcdt." resid='".$bbk."'  or";
     $tmp++;
    }
  }
  $fmcdt=substr($fmcdt,0,strlen($fmcdt)-3);
  $rp=repairins($fmcdt);
  for ($j=0;$j<count($bkarr);$j++){
   $z0=datatoinst($bkarr[$j],$tabarr[$j],$tparr[$j],$cdtarr[$j],$sysid,$restype,$rescode);
  }
  return true;
 }else{
  return false;
 }
}
?>