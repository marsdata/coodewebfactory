<?php
function addalert($edate,$etime,$lv,$atype,$etitle,$srcid,$srctitle,$adesc,$abman){
  $sqlx="errmark,level,errtitle,alerttype,aboutsrcid,aboutsrctitle,aboutman,errdescrib,errtime,errdate,CRTM,UPTM,OLMK";
  $sqly="'".getRandChar(8)."','".$lv."','".$etitle."','".$atype."','".$srcid."','".$srctitle."','".$abman."','".$adesc."','".$etime."','".$edate."',now(),now(),'".onlymark()."'";
  $zz=UX("insert into massqr_erralert(".$sqlx.")values(".$sqly.")");
  return true;
}
function syssendeqmmsg($sdv,$sdm,$acd,$rcd,$rtt,$radd,$mvs,$ctm){
 switch($sdv){
   case "app":
   //$zx=addalert(date("Y-m-d"),date("Y-m-d H:i:s"),5,"eqmchktime","设备".$rtt.$mvs."到达检测时间",$acd.".".$rcd,$rtt,"位于".$radd."的设备".$rtt.$mvs."到达检测时间",$sdm);
   $urlx=combineurl("http://".glw(),"/localxres/funx/worcsendmsg/?thisuid=18841888888&fuid=".$sdm."&rcode=csworchat");
   $pd=Array();
   $pd["msgcontent"]="<p>位于".$radd."的设备".$rtt.$mvs."到达检测时间</p>";
   $zz=request_post($urlx,$pd);
   break;
   case "sms":
   $urlx=combineurl("http://".glw(),"/localxres/funx/hitangsms/?mobile=".$sdm."&msgtype=jctz&mcode=".$acd."-".$rcd."&inplace=".$radd."&mversion=".$mvs."&srctitle=".$rtt."&ctime=".$ctm);
   return file_get_contents($urlx);
   break;
   case "email":
   break;
   default:
 }
 return true;
}
?>