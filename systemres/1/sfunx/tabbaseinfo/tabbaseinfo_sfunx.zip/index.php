<?php
function extdbtab($dbip,$dbuser,$dbpass,$dbnm,$tbnm){  
  $conn=mysql_connect($dbip,$dbuser,$dbpass);
  $extt=updatings($conn,"information_schema","select count(*) as result from TABLES where TABLE_SCHEMA='".$dbnm."' and TABLE_NAME='".$tbnm."'","utf8");
  if (intval($extt)>0){
     return true;
  }else{
     return false;
  }
}
function gettabinfo($dbnm,$tbnm,$dbinfo=array()){
    if ($dbnm==glb()){
        $dbnm="";
    }
    $dbrst=SX("select mainsqx,subsqx,host,srckey,md5key,contentkeys,allkeys from coode_dbtablist where schm='".$dbnm."' and TABLE_NAME='".$tbnm."'");
   if (countresult($dbrst)>0){
        $dbinfo["mainsqx"]=anyvalue($dbrst,"mainsqx",0);
        $dbinfo["subsqx"]=anyvalue($dbrst,"subsqx",0);
        $dbinfo["host"]=anyvalue($dbrst,"host",0);
        $dbinfo["srckey"]=anyvalue($dbrst,"srckey",0);
        $dbinfo["md5key"]=anyvalue($dbrst,"md5key",0);
        $dbinfo["ckeys"]=anyvalue($dbrst,"contentkeys",0);
        $dbinfo["akeys"]=anyvalue($dbrst,"allkeys",0);
   }else{
       $dbrst=SX("select mainsqx,subsqx,srckey,md5key,contentkeys,allkeys from coode_tablist where schm='".glb()."' and TABLE_NAME='".$tbnm."'");
        $dbinfo["mainsqx"]=anyvalue($dbrst,"mainsqx",0);
        $dbinfo["subsqx"]=anyvalue($dbrst,"subsqx",0);
        $dbinfo["host"]="";
        $dbinfo["srckey"]=anyvalue($dbrst,"rescdkey",0);
        $dbinfo["md5key"]=anyvalue($dbrst,"md5key",0);
        $dbinfo["ckeys"]=anyvalue($dbrst,"contentkeys",0);
        $dbinfo["akeys"]=anyvalue($dbrst,"allkeys",0);
   }
   return $dbinfo;
}
function takedbinfo($dbmark,$tbnm,$dbinfo=array()){
        
    if ($dbmark!="" and $dbmark!="thishostcore" and $dbmark!=glb()){
       $dbrst=SX("select tabtitle,fip,fuser,fpass,fbase,allkeys from coode_dbtablist where catalog='".$dbmark."'  and TABLE_NAME='".$tbnm."'");
        $dbinfo["dbnm"]=$dbnmx;
        $dbinfo["title"]=anyvalue($dbrst,"tabtitle",0);
        $dbinfo["fip"]=anyvalue($dbrst,"fip",0);
        $dbinfo["fuser"]=anyvalue($dbrst,"fuser",0);
        $dbinfo["fpass"]=anyvalue($dbrst,"fpass",0);
        $dbinfo["fbase"]=anyvalue($dbrst,"fbase",0);
        $krst=SX("select COLUMN_NAME,classp from coode_dbkeydx where TABLE_CATALOG='".$dbmark."' and TABLE_NAME='".$tbnm."' and (classp=1 or classp=2 or classp=5 or classp=6 or classp=7 or classp=10 or classp=11 ) order by SQX");
        $totk=countresult($krst);
        $dbinfo["pskey"]="";
        $dbinfo["pstitle"]="";
        $dbinfo["pshead"]="";
        $dbinfo["pssno"]="";
        $dbinfo["psolmk"]="";
        $dbinfo["akeys"]=anyvalue($dbrst,"allkeys",0);
        for ($b=0;$b<$totk;$b++){
            $cp=intval(anyvalue($krst,"classp",$b));
            $cn=anyvalue($krst,"COLUMN_NAME",$b);
            switch($cp){
                case 1:
                 if ($dbinfo["pskey"]==""){
                   $dbinfo["pskey"]=$cn;
                 }else{
                   $dbinfo["pskey"]=$dbinfo["pskey"].",".$cn;
                 }
                break;
                case 2:
                 $dbinfo["pstitle"]=$cn;
                break;
                case 5:
                 $dbinfo["pshead"]=$cn;
                break;
                case 6:
                 $dbinfo["pssno"]=$cn;
                break;
                case 7:
                 $dbinfo["psolmk"]=$cn;
                break;
                case 8:
                 $dbinfo["psarea"]=$cn;
                break;
                case 10:
                 $dbinfo["ickey"]=$cn;
                break;
                case 11:
                 $dbinfo["iwkey"]=$cn;
                break;
                case 12:
                 $dbinfo["icrtm"]=$cn;
                break;
               default:
            }
        }
    }else{
        $dbrst=SX("select SNO,tabtitle,allkeys from coode_tablist where  TABLE_NAME='".$tbnm."'");
        $dbinfo["fip"]="localhost";
        $dbinfo["fuser"]=glu();
        $dbinfo["fpass"]=glp();
        $dbinfo["fbase"]=glb();
        $dbinfo["akeys"]=anyvalue($dbrst,"allkeys",0);
        $dbinfo["title"]=anyvalue($dbrst,"tabtitle",0);
        $krst=SX("select COLUMN_NAME,classp from coode_keydetailx where TABLE_SCHEMA='".glb()."' and TABLE_NAME='".$tbnm."' and (classp=1 or classp=2 or classp=5 or classp=6  or classp=7 or classp=10  or classp=11)");
        $totk=countresult($krst);
        $dbinfo["pskey"]="";
        $dbinfo["pstitle"]="";
        $dbinfo["pshead"]="";
        $dbinfo["pssno"]="";
        $dbinfo["psolmk"]="";
        for ($b=0;$b<$totk;$b++){
            $cp=intval(anyvalue($krst,"classp",$b));
            $cn=anyvalue($krst,"COLUMN_NAME",$b);
            switch($cp){
                case 1:
                 $dbinfo["pskey"]=$cn;
                break;
                case 2:
                 $dbinfo["pstitle"]=$cn;
                break;
                case 5:
                 $dbinfo["pshead"]=$cn;
                break;
                case 6:
                 $dbinfo["pssno"]=$cn;
                break;
                case 7:
                 $dbinfo["psolmk"]=$cn;
                break;
                case 8:
                 $dbinfo["psarea"]=$cn;
                break;
                case 10:
                 $dbinfo["ickey"]=$cn;
                break;
                case 11:
                 $dbinfo["iwkey"]=$cn;
                break;
                case 12:
                 $dbinfo["icrtm"]=$cn;
                break;
               default:
            }
        }
    }
    return $dbinfo;
}
function getdatabase($dbmk,$dbinfo=array()){
    $dbrst=SX("select dbip,dbus,dbps,dbname from coode_dblist where dbmark='".$dbmk."'");
    if (countresult($dbrst)>0){
        $dbinfo["fip"]=anyvalue($dbrst,"dbip",0);
        $dbinfo["fuser"]=anyvalue($dbrst,"dbus",0);
        $dbinfo["fpass"]=anyvalue($dbrst,"dbps",0);
        $dbinfo["fbase"]=anyvalue($dbrst,"dbname",0);
    }else{
        $dbinfo["fip"]="";
        $dbinfo["fuser"]="";
        $dbinfo["fpass"]="";
        $dbinfo["fbase"]="";
    }
    return $dbinfo;
}
function getdbinfo($dbnm,$tbnm,$dbinfo=array()){
    $dbrst=SX("select fip,fuser,fpass,fbase from coode_dbtablist where schm='".$dbnm."' and TABLE_NAME='".$tbnm."'");
    if (countresult($dbrst)>0 and $dbnm!=glb()){
        $dbinfo["fip"]=anyvalue($dbrst,"fip",0);
        $dbinfo["fuser"]=anyvalue($dbrst,"fuser",0);
        $dbinfo["fpass"]=anyvalue($dbrst,"fpass",0);
        $dbinfo["fbase"]=anyvalue($dbrst,"fbase",0);
        $krst=SX("select COLUMN_NAME,classp from coode_dbkeydx where TABLE_SCHEMA='".$dbnm."' and TABLE_NAME='".$tbnm."' and (classp=1 or classp=2 or classp=5 or classp=6 or classp=7 )");
        $totk=countresult($krst);
        $dbinfo["pskey"]="";
        $dbinfo["pstitle"]="";
        $dbinfo["pshead"]="";
        $dbinfo["pssno"]="";
        $dbinfo["psolmk"]="";
        for ($b=0;$b<$totk;$b++){
            $cp=intval(anyvalue($krst,"classp",$b));
            $cn=anyvalue($krst,"COLUMN_NAME",$b);
            switch($cp){
                case 1:
                 $dbinfo["pskey"]=$cn;
                break;
                case 2:
                 $dbinfo["pstitle"]=$cn;
                break;
                case 5:
                 $dbinfo["pshead"]=$cn;
                break;
                case 6:
                 $dbinfo["pssno"]=$cn;
                break;
                case 7:
                 $dbinfo["psolmk"]=$cn;
                break;
                case 8:
                 $dbinfo["psarea"]=$cn;
                break;
               default:
            }
        }
    }else{
        $dbinfo["fip"]="localhost";
        $dbinfo["fuser"]=glu();
        $dbinfo["fpass"]=glp();
        $dbinfo["fbase"]=glb();
        $krst=SX("select COLUMN_NAME,classp from coode_keydetailx where TABLE_SCHEMA='".dftval($dbnm,glb())."' and TABLE_NAME='".$tbnm."' and (classp=1 or classp=2 or classp=5 or classp=6  or classp=7)");
        $totk=countresult($krst);
        $dbinfo["pskey"]="";
        $dbinfo["pstitle"]="";
        $dbinfo["pshead"]="";
        $dbinfo["pssno"]="";
        $dbinfo["psolmk"]="";
        for ($b=0;$b<$totk;$b++){
            $cp=intval(anyvalue($krst,"classp",$b));
            $cn=anyvalue($krst,"COLUMN_NAME",$b);
            switch($cp){
                case 1:
                 $dbinfo["pskey"]=$cn;
                break;
                case 2:
                 $dbinfo["pstitle"]=$cn;
                break;
                case 5:
                 $dbinfo["pshead"]=$cn;
                break;
                case 6:
                 $dbinfo["pssno"]=$cn;
                break;
                case 7:
                 $dbinfo["psolmk"]=$cn;
                break;
                case 8:
                 $dbinfo["psarea"]=$cn;
                break;
               default:
            }
        }
    }
    return $dbinfo;
}
function getdbact($dbmk,$tbnm,$actinfo=array()){
    if ($dbmk==glb() or $dbmk=="" or $dbmk=="thishostcore"){
        $actrst=SX("select bfist,aftist,bfupd,aftupd,bfdel,aftdel from coode_keydetailx where TABLE_SCHEMA='".glb()."' and TABLE_NAME='".$tbnm."' and (COLUMN_NAME='SNO' or COLUMN_NAME='sNo' or classp=6)");
        $actinfo["bfist"]=tostring(anyvalue($actrst,"bfist",0));
        $actinfo["aftist"]=tostring(anyvalue($actrst,"aftist",0));
        $actinfo["bfupd"]=tostring(anyvalue($actrst,"bfupd",0));
        $actinfo["aftupd"]=tostring(anyvalue($actrst,"aftupd",0));
        $actinfo["bfdel"]=tostring(anyvalue($actrst,"bfdel",0));
        $actinfo["aftdel"]=tostring(anyvalue($actrst,"aftdel",0));
    }else{
        $actrst=SX("select bfist,aftist,bfupd,aftupd,bfdel,aftdel from coode_dbkeydx where TABLE_CATALOG='".$dbmk."' and TABLE_NAME='".$tbnm."' and classp=6");
        $actinfo["bfist"]=tostring(anyvalue($actrst,"bfist",0));
        $actinfo["aftist"]=tostring(anyvalue($actrst,"aftist",0));
        $actinfo["bfupd"]=tostring(anyvalue($actrst,"bfupd",0));
        $actinfo["aftupd"]=tostring(anyvalue($actrst,"aftupd",0));
        $actinfo["bfdel"]=tostring(anyvalue($actrst,"bfdel",0));
        $actinfo["aftdel"]=tostring(anyvalue($actrst,"aftdel",0));
    }
    return $actinfo;
}
function tabaffect($dbnm,$tbnm){
    if ($dbnm=="" or $dbnm==glb()){
        $trst=SX("select SNO,afftabs from coode_tablist where  TABLE_NAME='".$tbnm."'");
        $afftabs="xxx,".anyvalue($trst,"afftabs",0).",xx";
        if (anyvalue($trst,"afftabs",0)!=""){
          $dd=UX("update coode_tiny set STATUS=1 where '".$afftabs."' like concat('%,',tabname,',%') and tabname<>''");        
        }
    }else{
        $dbtrst=SX("select fip,fuser,fpass,afftabs from coode_dbtablist where schm='".$dbnm."' and TABLE_NAME='".$tbnm."'");
        $fip=anyvalue($dbtrst,"fip",0);
        $fuser=anyvalue($dbtrst,"fuser",0);
        $fpass=anyvalue($dbtrst,"fpass",0);
        $afftabs="xxx,".anyvalue($dbtrst,"afftabs",0).",xx";
        if (anyvalue($dbtrst,"afftabs",0)!=""){
          $dd=UX("update coode_tiny set STATUS=1 where '".$afftabs."' like concat('%,',tabname,',%') and schm='".$dbnm."' and tabname<>''");        
        }
    }
    return true;
}
function plotnextid($plmk,$pltb){
    switch($pltb){
        case "coode_plotdetail":
            return intval(UX("select myid as result from ".$pltb." where plotmark='".$plmk."' order by myid desc"))*1+1;
        break;
        case "coode_nodes":
            return intval(UX("select myid as result from ".$pltb." where treemark='".$plmk."' order by myid desc"))*1+1;
        break;
        case "target_tarorg":
            return intval(UX("select myid as result from ".$pltb." where tarmark='".$plmk."' order by myid desc"))*1+1;
        break;
        case "target_srckey":
            return intval(UX("select myid as result from ".$pltb." where srcmark='".$plmk."' order by myid desc"))*1+1;
        break;
        default:
    }
    
}
?>