<?php
function formcrt($dbase,$otnm,$ntnm,$skeys,$farr=array()){
  if ($dbase==""){
    $dbase=glb();
  }
 $conn=mysql_connect(gl(),glu(),glp());
if ($otnm!="" and $skeys!=""){
 $trst=selecteds($conn,"information_schema","select TABLE_CATALOG,TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,ORDINAL_POSITION,COLUMN_DEFAULT,IS_NULLABLE,DATA_TYPE,CHARACTER_MAXIMUM_LENGTH,CHARACTER_OCTET_LENGTH,NUMERIC_PRECISION,NUMERIC_SCALE,CHARACTER_SET_NAME,COLLATION_NAME,COLUMN_TYPE,COLUMN_KEY,EXTRA,PRIVILEGES,COLUMN_COMMENT from COLUMNS where TABLE_SCHEMA='".$dbase."' and TABLE_NAME='".$otnm."' and 'x,".$skeys.",' like concat('%,',COLUMN_NAME,',%')","utf8","");
 $totrst=countresult($trst);
 $fmc="";
 $fmk="";
 $fmktp="";
 $fmik="";
 $fmjscon="";
  $tbdk="X/CRTM/UPTM/CRTOR/STATUS/OLMK/VRT/STCODE/PTOF/PRIME/RIP/SNO/OPRT/";
 for ($k=0;$k<$totrst;$k++){
   $sTABLE_CATALOG[$k]=anyvalue($trst,"TABLE_CATALOG",$k);
   $sTABLE_SCHEMA[$k]=anyvalue($trst,"TABLE_SCHEMA",$k);
   $sTABLE_NAME[$k]=anyvalue($trst,"TABLE_NAME",$k);
   $sCOLUMN_NAME[$k]=anyvalue($trst,"COLUMN_NAME",$k);
   $sORDINAL_POSITION[$k]=anyvalue($trst,"ORDINAL_POSITION",$k);
   $sCOLUMN_DEFAULT[$k]=anyvalue($trst,"COLUMN_DEFAULT",$k);
   $sIS_NULLABLE[$k]=anyvalue($trst,"IS_NULLABLE",$k);
   $sDATA_TYPE[$k]=anyvalue($trst,"DATA_TYPE",$k);
   $sCHARACTER_MAXIMUM_LENGTH[$k]=anyvalue($trst,"CHARACTER_MAXIMUM_LENGTH",$k);
   $sCHARACTER_OCTET_LENGTH[$k]=anyvalue($trst,"CHARACTER_OCTET_LENGTH",$k);
   $sNUMERIC_PRECISION[$k]=anyvalue($trst,"NUMERIC_PRECISION",$k);
   $sNUMERIC_SCALE[$k]=anyvalue($trst,"NUMERIC_SCALE",$k);
   $sCHARACTER_SET_NAME[$k]=anyvalue($trst,"CHARACTER_SET_NAME",$k);
   $sCOLLATION_NAME[$k]=anyvalue($trst,"COLLATION_NAME",$k);
   $sCOLUMN_TYPE[$k]=anyvalue($trst,"COLUMN_TYPE",$k);
   $sCOLUMN_KEY[$k]=anyvalue($trst,"COLUMN_KEY",$k);
   $sEXTRA[$k]=anyvalue($trst,"EXTRA",$k);
   $sPRIVILEGES[$k]=anyvalue($trst,"PRIVILEGES",$k);
   $sCOLUMN_COMMENT[$k]=anyvalue($trst,"COLUMN_COMMENT",$k);
   $somark[$k]=date('Ymdhis').getRandChar(6);
   if ($sCOLUMN_NAME[$k]=="SNO"){
   }else{
    $fmk=$fmk.$sCOLUMN_NAME[$k].",";
    if (strpos($tbdk,"/".$sCOLUMN_NAME[$k]."/")>0){
    }else{
      $fmik=$fmik.$sCOLUMN_NAME[$k].",";
    }
    if ($k<$totrst-1){
        if (strpos($tbdk,"/".$sCOLUMN_NAME[$k]."/")>0){
        }else{
         $fmik=$fmik.$sCOLUMN_NAME[$k].",";
         $fmjscon=$fmjscon."↓\"".$sCOLUMN_NAME[$k]."∵↓,".$sCOLUMN_NAME[$k].",↓\",↓,";
        }
    }else{
        if (strpos($tbdk,"/".$sCOLUMN_NAME[$k]."/")>0){
          $fmjscon=$fmjscon."↓\"tablename∵".$tnm."\"↓";
        }else{
          $fmik=$fmik.$sCOLUMN_NAME[$k].",";
          $fmjscon=$fmjscon."↓\"".$sCOLUMN_NAME[$k]."∵↓,".$sCOLUMN_NAME[$k].",↓\"↓";
        }
    }
    if ($k<$totrst-1){
     $fmktp=$fmktp.$sCOLUMN_NAME[$k].",↓↑,↑↓,";
     $fmjstp=$fmjstp."↓\"".$sCOLUMN_NAME[$k]."∵↓,".$sCOLUMN_NAME[$k].",↓\",↓,";
    }else{
      $fmktp=$fmktp.$sCOLUMN_NAME[$k];
      $fmjstp=$fmjstp."↓\"".$sCOLUMN_NAME[$k]."∵↓,".$sCOLUMN_NAME[$k].",↓\"↓";
    }
   }
  switch($sDATA_TYPE[$k]){
    case "int":
    if ($sCOLUMN_NAME[$k]=="SNO"){
      $fmc=$fmc.$sCOLUMN_NAME[$k]." int(11) NOT NULL AUTO_INCREMENT,";
    }else{
      $fmc=$fmc.$sCOLUMN_NAME[$k]." int(11) NOT NULL,";
    }
    break;
    case "decimal":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." decimal(10,2) NOT NULL,";
    break;
    case "varchar":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." varchar(".$sCHARACTER_MAXIMUM_LENGTH[$k].") NOT NULL,";
    break;
    case "text":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." text NOT NULL,";
    break;
    case "longtext":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." longtext NOT NULL,";
    break;
    case "date":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." date NOT NULL,";
    break;
    case "datetime":
    $fmc=$fmc.$sCOLUMN_NAME[$k]." datetime NOT NULL,";
    break;    
    default:
   }  
 }
  $fmc=$fmc."PRIMARY KEY (SNO),";
  $fmk=killlaststr($fmk);
  $fmik=killlaststr($fmik);
  $fmktp="concat(↓↑↓,".$fmktp.",↓↑↓)";
  $fmjstp="concat(".$fmjstp.")";
  $btree=betrees($tnm);
  if ($btree==""){
    $fmc=killlaststr($fmc);
  }else{
    $fmc=$fmc.$btree;
  }
  $crtsql="CREATE TABLE ".$ntnm." (".$fmc.") ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;";
  $farr["crtsql"]=$crtsql;
  $farr["allkey"]=$fmk;
  $farr["conkey"]=$fmik;
  $farr["keytps"]=$fmktp;
  $farr["jsontp"]=$fmjstp;
  $farr["jsoncon"]=$fmjscon;
}
  return $farr;
}//DESCRIB ():  END@()
?>