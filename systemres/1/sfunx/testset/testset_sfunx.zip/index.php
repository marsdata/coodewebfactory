<?php
function test(){
 return "yes";
}
?>