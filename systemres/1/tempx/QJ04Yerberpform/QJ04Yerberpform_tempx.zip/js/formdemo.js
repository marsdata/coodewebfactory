ccode=new Array();
ccode["srd"]="[diytop]{div style=\"height:100%;\"} {div id=\"parta\" style=\"width:100%;height:100%;\"}  {div class=\"easyui-layout\" data-options=\"fit:true\" id=\"useBox\" style=\"height:100%\"}    {form id=\"addform\" shortid=\"[shortid]\" showkeys=\"[showkeys]\" tabname=\"[tabnm]\"  class=\"layui-form layui-col-md8\" style=\"margin-right:0px;height:100%\" method=\"post\"}      {div data-options=\"region:'center',split:true\" style=\"height:100%\"}          {div id=\"tabs\"}            {div title=\"基本信息\" style=\"float:left;width:40%;height:100%;\"}              [srdinner]                {div class=\"forSubmint\"} {a href=\"javascript:void(0)\" class=\"easyui-linkbutton\"  iconCls=\"icon-save\" onclick=\"obj.sum()\" }保存{/a} {a href=\"javascript:void(0)\" class=\"easyui-linkbutton\"  iconCls=\"icon-reload\" onclick=\"location.href='/SPEC/EDITOR/anyshortnew.php?stid='+GetRequest().stid+'&SNO=0'\" }新条目{/a}{a href=\"javascript:void(0)\" class=\"easyui-linkbutton\" onclick=\"window.location.reload();\"  iconCls=\"icon-redo\" }重置{/a} {a href=\"javascript:void(0)\" class=\"easyui-linkbutton\" onclick=\"history.go(-1);\"  iconCls=\"icon-back\" }返回{/a}{/div}            {/div}            {div title=\"信息列表\" style=\"float:left;width:60%;height:100%;\"}                {table id=\"table\" class=\"tableStyle\"}{/table}            {/div}          {/div}       {/div}     {/form}     {/div} {/div} {div id=\"partb\" style=\"clear:both;width:100%;height:600px;display:none;\"}     {iframe id=\"ifrm\" src =\"/FACE/404/universe/404.html\" scrolling=\"yes\" style=\"width:100%;height:100%\" frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" }  {/iframe} {/div}{/div}[diybottom]";
ccode["diytop"]="";
ccode["diybottom"]="";
ccode["varchar"]="{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\" class=\"TailInput\" value=\"[value]\" placeholder=\"[exp]\"}";
ccode["text"]="{textarea id=\"p_[key]\" [rdol] name=\"p_[key]\" class=\"TailArea\" style=\"[dspl]\" placeholder=\"[exp]\"}[value]{/textarea}";
ccode["richtext"]="{textarea id=\"p_[key]\" [rdol] name=\"p_[key]\" class=\"TailArea\" style=\"[dspl]\" placeholder=\"[exp]\"}[value]{/textarea}";
ccode["code"]="{textarea id=\"p_[key]\" [rdol] name=\"p_[key]\" class=\"TailArea\" style=\"[dspl]\" placeholder=\"[exp]\"}[value]{/textarea}";
ccode["select"]="function mkaselectx(colname,snox,thisval,$clstxtx,cange,dspl){  if ($clstxtx!=\"\"){    $clstxtx=tostring($clstxtx);    if (intval(dspl)==0){     $fmselect=formselect(qian($clstxtx,\"|\"),hou($clstxtx,\"|\"),thisval,\"p_\"+colname,\"easyui-combobox\",\"style=\"+syh()+\"display:none;\"+syh());        }else{      if (intval(cange)==0){        $fmselect=formselectonly(qian($clstxtx,\"|\"),hou($clstxtx,\"|\"),thisval,\"p_\"+colname,\"easyui-combobox\",\"\");          }else{        $fmselect=formselect(qian($clstxtx,\"|\"),hou($clstxtx,\"|\"),thisval,\"p_\"+colname,\"easyui-combobox\",\"\");                 }    }    return $fmselect;  }else{   return \"\";  }}";
function mkaselectx(colname,snox,thisval,$clstxtx,cange,dspl){
  if ($clstxtx!=""){
    $clstxtx=tostring($clstxtx);
    if (intval(dspl)==0){
     $fmselect=formselect(qian($clstxtx,"|"),hou($clstxtx,"|"),thisval,"p_"+colname,"easyui-combobox","style="+syh()+"display:none;"+syh());    
    }else{
      if (intval(cange)==0){
        $fmselect=formselectonly(qian($clstxtx,"|"),hou($clstxtx,"|"),thisval,"p_"+colname,"easyui-combobox","");    
      }else{
        $fmselect=formselect(qian($clstxtx,"|"),hou($clstxtx,"|"),thisval,"p_"+colname,"easyui-combobox","");           
      }
    }
    return $fmselect;
  }else{
   return "";
  }
}
ccode["multiselect"]="function mkaselecty(colname,snox,thisval,$clstxtx){      if ($clstxtx!=\"\"){    $clstxtx=tostring($clstxtx);    $fmselect=formselecty(qian($clstxtx,\"|\"),hou($clstxtx,\"|\"),thisval,\"p_\"+colname,\"easyui-combobox\",\"\");        return $fmselect;  }else{   return \"\";  }}";
function mkaselecty(colname,snox,thisval,$clstxtx){    
  if ($clstxtx!=""){
    $clstxtx=tostring($clstxtx);
    $fmselect=formselecty(qian($clstxtx,"|"),hou($clstxtx,"|"),thisval,"p_"+colname,"easyui-combobox","");    
    return $fmselect;
  }else{
   return "";
  }
}
ccode["date"]="{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\" class=\"easyui-datebox TailInput\" value=\"[value]\" placeholder=\"[exp]\"}";
ccode["datetime"]="{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\" class=\"easyui-datetimebox TailInput\" value=\"[value]\" placeholder=\"[exp]\"}";
ccode["int"]="{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\" class=\"TailInput\" value=\"[value]\" placeholder=\"[exp]\"}";
ccode["tinyint"]="";
ccode["decimal1"]="{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\" class=\"TailInput\" value=\"[value]\" placeholder=\"[exp]\"}";
ccode["decimal2"]="{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\" class=\"TailInput\" value=\"[value]\" placeholder=\"[exp]\"}";
ccode["decimal3"]="{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\" class=\"TailInput\" value=\"[value]\" placeholder=\"[exp]\"}";
ccode["decimal4"]="{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\" class=\"TailInput\" value=\"[value]\" placeholder=\"[exp]\"}";
ccode["imagex"]="{div id=\"[key]show\" vals=[value]}{/div}{input type=\"hidden\" id=\"p_[key]\" name=\"p_[key]\"}{a id=\"[key]btn\" href=\"javascript:void(0)\" class=\"easyui-linkbutton\"  iconCls=\"icon-add\"}上传{/a}";
ccode["images"]="{div id=\"[key]show\" vals=[value]}{/div}{input type=\"hidden\" id=\"p_[key]\" name=\"p_[key]\"}{a id=\"[key]btn\" href=\"javascript:void(0)\" data-upload-more=\"true\"  class=\"easyui-linkbutton\"  iconCls=\"icon-add\"}上传{/a}";
ccode["filex"]="{div id=\"[key]show\" vals=[value]}{/div}{input type=\"hidden\" id=\"p_[key]\" name=\"p_[key]\"}{a id=\"[key]btn\" href=\"javascript:void(0)\" class=\"easyui-linkbutton\"  iconCls=\"icon-add\"}上传{/a}";
ccode["files"]="{div id=\"[key]show\" vals=[value]}{/div}{input type=\"hidden\" id=\"p_[key]\" name=\"p_[key]\"}{a id=\"[key]btn\" href=\"javascript:void(0)\" data-upload-more=\"true\"  class=\"easyui-linkbutton\"  iconCls=\"icon-add\"}上传{/a}";
ccode["check"]="{div style=\"margin-bottom:20px\"}{input type=\"text\"  data-toggle=\"topjui-checkbox\" name=\"p_[key]\" [rdol] autocomplete=\"off\" class=\"TailInput\" value=\"[value]\" label=\"[value]:\" placeholder=\"[exp]\"}{/div}";
ccode["multicheck"]="{div style=\"margin-bottom:20px\"}{input type=\"text\"  data-toggle=\"topjui-checkbox\" name=\"p_[key]\" [rdol] autocomplete=\"off\" class=\"TailInput\" value=\"[value]\" label=\"[value]:\" placeholder=\"[exp]\"}{/div}";
ccode["varcharSRD"]="";
ccode["textSRD"]="{td class=\"TailLabel\" style=\"[dspl]\"}[title]：{/td}{td id=\"eleof[key]\" style=\"[dspl]\"  colspan=\"[colsnum]\" rdol=\"[rdol]\"  dxtype=\"[dxtp]\"}[inner]{/td}";
ccode["richtextSRD"]="{td class=\"TailLabel\" style=\"[dspl]\"}[title]：{/td}{td id=\"eleof[key]\" style=\"[dspl]\"  colspan=\"[colsnum]\" rdol=\"[rdol]\"  dxtype=\"[dxtp]\"}[inner]{/td}";
ccode["codeSRD"]="{td class=\"TailLabel\" style=\"[dspl]\"}[title]：{/td}{td id=\"eleof[key]\" style=\"[dspl]\"  colspan=\"[colsnum]\" rdol=\"[rdol]\"  dxtype=\"[dxtp]\"}[inner]{/td}";
ccode["selectSRD"]="";
ccode["multiselectSRD"]="";
ccode["dateSRD"]="";
ccode["datetimeSRD"]="";
ccode["intSRD"]="";
ccode["tinyintSRD"]="";
ccode["decimal1SRD"]="";
ccode["decimal2SRD"]="";
ccode["decimal3SRD"]="";
ccode["decimal4SRD"]="";
ccode["imagexSRD"]="";
ccode["imagesSRD"]="";
ccode["filexSRD"]="";
ccode["filesSRD"]="";
ccode["checkSRD"]="";
ccode["multicheckSRD"]="";
ccode["varcharINLINE"]="";
ccode["textINLINE"]="";
ccode["richtextINLINE"]="";
ccode["codeINLINE"]="";
ccode["selectINLINE"]="";
ccode["multiselectINLINE"]="";
ccode["dateINLINE"]="";
ccode["datetimeINLINE"]="";
ccode["intINLINE"]="";
ccode["tinyintINLINE"]="";
ccode["decimal1INLINE"]="";
ccode["decimal2INLINE"]="";
ccode["decimal3INLINE"]="";
ccode["decimal4INLINE"]="";
ccode["imagexINLINE"]="";
ccode["imagesINLINE"]="";
ccode["filexINLINE"]="";
ccode["filesINLINE"]="";
ccode["checkINLINE"]="";
ccode["multicheckINLINE"]="";
ccode["onerow"]="{tr style=\"[dspl]\"}[rowx]{/tr}";
ccode["duorow"]="{tr}[rowx]{/tr}";
ccode["varcharFUNCTION"]="";
ccode["textFUNCTION"]="";
ccode["richtextFUNCTION"]="";
ccode["codeFUNCTION"]="";
ccode["selectFUNCTION"]="";
ccode["multiselectFUNCTION"]="";
ccode["dateFUNCTION"]="";
ccode["datetimeFUNCTION"]="";
ccode["intFUNCTION"]="";
ccode["tinyintFUNCTION"]="";
ccode["decimal1FUNCTION"]="";
ccode["decimal2FUNCTION"]="";
ccode["decimal3FUNCTION"]="";
ccode["decimal4FUNCTION"]="";
ccode["imagexFUNCTION"]="";
ccode["imagesFUNCTION"]="";
ccode["filexFUNCTION"]="";
ccode["filesFUNCTION"]="";
ccode["checkFUNCTION"]="";
ccode["checkduoFUNCTION"]="";
ccode["multicheckFUNCTION"]="";
ccode["duorowFUNCTION"]="";
ccode["srdFUNCTION"]="";
