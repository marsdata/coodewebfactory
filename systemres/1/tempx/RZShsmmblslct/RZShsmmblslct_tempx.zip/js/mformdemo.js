ccode=new Array();
ccode["srd"]="{div id=\"BgDiv1\"}{/div}{div class=\"U-login-con\"} {div class=\"DialogDiv\" style=\"display:none; \"} {div class=\"U-guodu-box\"} {div} {table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" } {tr}{td align=\"center\"}{img id=\"waitimg\" src=\"mblzhezhao/images/loading.gif\"}{/td}{/tr} {tr}{td valign=\"middle\" align=\"center\" }提交中，请稍后！{/td}{/tr} {/table} {/div} {/div} {/div} {div class=\"cl\"}{/div}{/div}{div class=\"mobile\"}  {!--页面加载 开始--} {div id=\"preloader\"}  {div id=\"status\"}   {p class=\"center-text\"}{span}拼命加载中···{/span}{/p}  {/div} {/div} {!--页面加载 结束--}  {!--header 开始--} {header} {div class=\"header\"}  {h2}[shorttitle]{/h2} {/div} {/header} {!--header 结束--} {div class=\"container\"}  {div class=\"content\"}        {form id=\"addform\"  shortid=\"[shortid]\" showkeys=\"[showkeys]\" tabkeys=\"[tabkeys]\" tabname=\"[tabnm]\"  pssno=\"[pssno]\" pskey=\"[pskey]\" pstitle=\"[pstitle]\" pshead=\"[pshead]\" onsubmit=\"return changesmt();\" class=\"layui-form layui-col-md8\" style=\"margin-right:0px;\" action=\"\"}    [srdinner]    {/form}    {div class=\"btn-holder\"}          {a href=\"javascript:void(0)\" class=\"button white bigrounded\"  onclick=\"newx()\"}提交{/a}      {a href=\"javascript:void(0)\" class=\"button white bigrounded\"  onclick=\"window.location.reload()\"}重置{/a}      {a href=\"javascript:void(0)\" class=\"button white bigrounded\"  onclick=\"history.go(-1)\"}返回{/a}          {/div}  {/div}{/div}";
ccode["diytop"]="";
ccode["diybottom"]="";
ccode["varchar"]="{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\"  class=\"field-input\" size=\"35\" value=\"[value]\" placeholder=\"[exp]\"}";
ccode["text"]="";
ccode["richtext"]="{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\"  class=\"field-input\" size=\"35\" value=\"[value]\" placeholder=\"[exp]\"}{div class=\"auto-screening auto-hidden\" id=\"s_[key]\"}{/div}";
ccode["code"]="function jrunx(colname,snox,thisval,$gkinfo){ $(\"#p_\"+colname).bind('input propertychange',function(){            arr=new Array();            $newonex=$gkinfo[colname][\"COLUMN_CLSTXT\"];            qx=qian($newonex,\"|\");            ptqx=qx.split(\",\");            for (bb=0;bb<ptqx.length;bb++){              if (ptqx[bb]!=\"\"){                arr.push(ptqx[bb]);              }            }            var arrNew = [];            var ii;            for(ii=0;ii<arr.length;ii++){               var arrItems=arr[ii];            　　             　　 if($.inArray(arrItems,arrNew)==-1) {            　　　　 arrNew.push(arrItems);                                }            }                        for(ii=0;ii<arrNew.length;ii++){               var arrWord = arrNew[ii].toString();                              if(((arrWord.indexOf($('#p_'+colname).val())) > -1) && ($('#p_'+colname).val().length > 0)){                  var addArrWord = \"<div class=auto-screening-prompt>\" + arrWord + \"</div>\";                   $(\"#s_\"+colname).append(addArrWord);                   $(\"#s_\"+colname).removeClass(\"auto-hidden\");               }            }                        $(\".auto-screening-prompt\").each(function(){               if($(this).text().indexOf($('#p_'+colname).val()) < 0){                  $(this).remove();               }               else if($('#p_'+colname).val().length == 0){                  $(\"#s_\"+colname).addClass(\"auto-hidden\");                  $(\".auto-screening-prompt\").remove();               }            });                           $(\".auto-screening-prompt\").each(function(ii, iText){              var iTextHtml = iText.innerHTML;              $(\".auto-screening-prompt\").each(function(jj, jText){              var jTextHtml = jText.innerHTML;              if (ii < jj && iTextHtml == jTextHtml) {                $(this).remove();              }           });        });                     $(\".auto-screening-prompt\").on(\"click\",function(){              $(\"#p_\"+colname).val($(this).text());              $(\"#s_\"+colname).addClass(\"auto-hidden\");              $(\".auto-screening-prompt\").remove();         })                 })}";
function jrunx(colname,snox,thisval,$gkinfo){
 $("#p_"+colname).bind('input propertychange',function(){
            arr=new Array();
            $newonex=$gkinfo[colname]["COLUMN_CLSTXT"];
            qx=qian($newonex,"|");
            ptqx=qx.split(",");
            for (bb=0;bb<ptqx.length;bb++){
              if (ptqx[bb]!=""){
                arr.push(ptqx[bb]);
              }
            }
            var arrNew = [];
            var ii;
            for(ii=0;ii<arr.length;ii++){
               var arrItems=arr[ii];            　　 
            　　 if($.inArray(arrItems,arrNew)==-1) {
            　　　　 arrNew.push(arrItems);                 
               }
            }            
            for(ii=0;ii<arrNew.length;ii++){
               var arrWord = arrNew[ii].toString();               
               if(((arrWord.indexOf($('#p_'+colname).val())) > -1) && ($('#p_'+colname).val().length > 0)){
                  var addArrWord = "<div class=auto-screening-prompt>" + arrWord + "</div>";
                   $("#s_"+colname).append(addArrWord);
                   $("#s_"+colname).removeClass("auto-hidden");
               }
            }            
            $(".auto-screening-prompt").each(function(){
               if($(this).text().indexOf($('#p_'+colname).val()) < 0){
                  $(this).remove();
               }
               else if($('#p_'+colname).val().length == 0){
                  $("#s_"+colname).addClass("auto-hidden");
                  $(".auto-screening-prompt").remove();
               }
            });               
            $(".auto-screening-prompt").each(function(ii, iText){
              var iTextHtml = iText.innerHTML;
              $(".auto-screening-prompt").each(function(jj, jText){
              var jTextHtml = jText.innerHTML;
              if (ii < jj && iTextHtml == jTextHtml) {
                $(this).remove();
              }
           });
        });         
            $(".auto-screening-prompt").on("click",function(){
              $("#p_"+colname).val($(this).text());
              $("#s_"+colname).addClass("auto-hidden");
              $(".auto-screening-prompt").remove();
         })            
     })
}
ccode["select"]="function mkoselect(colname,snox,thisval,$gkinfo){  $newonex=$gkinfo[colname][\"COLUMN_CLSTXT\"];  if ($newonex.indexOf(\"key\")>0){    eval('$newonex=datatxt.'+colname+'CLSTXT;');  }    if ($newonex!=\"\"){          $fmselect=formselect(qian($newonex,\"|\"),hou($newonex,\"|\"),thisval,\"p_\"+colname,\"pickout\",\"\");    return $fmselect;  }else{   return \"\";  }}";
function mkoselect(colname,snox,thisval,$gkinfo){
  $newonex=$gkinfo[colname]["COLUMN_CLSTXT"];
  if ($newonex.indexOf("key")>0){
    eval('$newonex=datatxt.'+colname+'CLSTXT;');
  }  
  if ($newonex!=""){      
    $fmselect=formselect(qian($newonex,"|"),hou($newonex,"|"),thisval,"p_"+colname,"pickout","");
    return $fmselect;
  }else{
   return "";
  }
}
ccode["multiselect"]="function mkdselect(colname,snox,thisval,$gkinfo){  $newonex=$gkinfo[colname][\"COLUMN_CLSTXT\"];  if ($newonex.indexOf(\"key\")>0){    eval('$newonex=datatxt.'+colname+'CLSTXT;');  }    if ($newonex!=\"\"){          $fmselect=formselect(qian($newonex,\"|\"),hou($newonex,\"|\"),thisval,\"p_\"+colname,\"pickout\",\"\");    return $fmselect;  }else{   return \"\";  }}";
function mkdselect(colname,snox,thisval,$gkinfo){
  $newonex=$gkinfo[colname]["COLUMN_CLSTXT"];
  if ($newonex.indexOf("key")>0){
    eval('$newonex=datatxt.'+colname+'CLSTXT;');
  }  
  if ($newonex!=""){      
    $fmselect=formselect(qian($newonex,"|"),hou($newonex,"|"),thisval,"p_"+colname,"pickout","");
    return $fmselect;
  }else{
   return "";
  }
}
ccode["date"]="";
ccode["datetime"]="";
ccode["int"]="";
ccode["tinyint"]="";
ccode["decimal1"]="";
ccode["decimal2"]="";
ccode["decimal3"]="";
ccode["decimal4"]="";
ccode["imagex"]="";
ccode["images"]="";
ccode["filex"]="";
ccode["files"]="";
ccode["check"]="";
ccode["multicheck"]="";
ccode["varcharSRD"]="";
ccode["textSRD"]="";
ccode["richtextSRD"]="";
ccode["codeSRD"]="";
ccode["selectSRD"]="";
ccode["multiselectSRD"]="";
ccode["dateSRD"]="";
ccode["datetimeSRD"]="";
ccode["intSRD"]="";
ccode["tinyintSRD"]="";
ccode["decimal1SRD"]="";
ccode["decimal2SRD"]="";
ccode["decimal3SRD"]="";
ccode["decimal4SRD"]="";
ccode["imagexSRD"]="";
ccode["imagesSRD"]="";
ccode["filexSRD"]="";
ccode["filesSRD"]="";
ccode["checkSRD"]="";
ccode["multicheckSRD"]="";
ccode["varcharINLINE"]="";
ccode["textINLINE"]="";
ccode["richtextINLINE"]="";
ccode["codeINLINE"]="";
ccode["selectINLINE"]="";
ccode["multiselectINLINE"]="";
ccode["dateINLINE"]="";
ccode["datetimeINLINE"]="";
ccode["intINLINE"]="";
ccode["tinyintINLINE"]="";
ccode["decimal1INLINE"]="";
ccode["decimal2INLINE"]="";
ccode["decimal3INLINE"]="";
ccode["decimal4INLINE"]="";
ccode["imagexINLINE"]="";
ccode["imagesINLINE"]="";
ccode["filexINLINE"]="";
ccode["filesINLINE"]="";
ccode["checkINLINE"]="";
ccode["multicheckINLINE"]="";
ccode["onerow"]="{div class=\"form-group\"}{label id=\"titleof[key]\" style=\"clear:both;[dspl]\" for=\"p_[key]\"}[title]:{/label}[rowx]{/div}";
ccode["duorow"]="{div class=\"form-group\"}{label id=\"titleof[key]\" style=\"clear:both;[dspl]\" for=\"p_[key]\"}[title]:{/label}[rowx]{/div}";
ccode["varcharFUNCTION"]="";
ccode["textFUNCTION"]="";
ccode["richtextFUNCTION"]="zz=jrunx(\"[key]\",\"[SNO]\",\"[value]\",$gkinfo);";
ccode["codeFUNCTION"]="";
ccode["selectFUNCTION"]="sr=pickout.to({el:'#p_[key]',theme: 'clean',});";
ccode["multiselectFUNCTION"]="mjr=pickout.to({el:'#p_[key]',theme: 'dark', search: true});mjr1=pickout.updated('p_[key]');";
ccode["dateFUNCTION"]="";
ccode["datetimeFUNCTION"]="";
ccode["intFUNCTION"]="";
ccode["tinyintFUNCTION"]="";
ccode["decimal1FUNCTION"]="";
ccode["decimal2FUNCTION"]="";
ccode["decimal3FUNCTION"]="";
ccode["decimal4FUNCTION"]="";
ccode["imagexFUNCTION"]="";
ccode["imagesFUNCTION"]="";
ccode["filexFUNCTION"]="";
ccode["filesFUNCTION"]="";
ccode["checkFUNCTION"]="";
ccode["checkduoFUNCTION"]="";
ccode["multicheckFUNCTION"]="";
ccode["duorowFUNCTION"]="";
ccode["srdFUNCTION"]="";
