ccode=new Array();
ccode["srd"]="{div id=\"BgDiv1\"}{/div}{div class=\"U-login-con\"} {div class=\"DialogDiv\" style=\"display:none; \"} {div class=\"U-guodu-box\"} {div} {table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" } {tr}{td align=\"center\"}{img src=\"mblzhezhao/images/loading.gif\"}{/td}{/tr} {tr}{td valign=\"middle\" align=\"center\" }提交中，请稍后！{/td}{/tr} {/table} {/div} {/div} {/div} {div class=\"cl\"}{/div}{/div}{div class=\"mobile\"}  {!--页面加载 开始--} {div id=\"preloader\"}  {div id=\"status\"}   {p class=\"center-text\"}{span}拼命加载中···{/span}{/p}  {/div} {/div} {!--页面加载 结束--}  {!--header 开始--} {header} {div class=\"header\"}  {h2}[shorttitle]{/h2} {/div} {/header} {!--header 结束--}  {div class=\"w main\"}   {form id=\"addform\" shortid=\"[shortid]\" showkeys=\"[showkeys]\" olmkkey=\"[olmkkey]\" prisno=\"[prisno]\" tabname=\"[tabname]\" onsubmit=\"return changesmt();\"}    [srdinner]   {div class=\"item item-captcha\"}    {div class=\"ui-btn-wrap\"} {a class=\"U-user-login-btn\" href=\"javascript:void(0)\" onclick=\"newx();\"}提交资料{/a} {/div}   {/div}   {/form}{/div}";
ccode["diytop"]="";
ccode["diybottom"]="";
ccode["varchar"]="  {input id=\"p_[key]\" class=\"txt-input\" type=\"text\" name=\"p_[key]\" [rdol]  value=\"[thisvalue]\" placeholder=\"[exp]\"}";
ccode["text"]="";
ccode["richtext"]="";
ccode["code"]="";
ccode["select"]="function mkaselect(colname,snox,thisval,$gkinfo){  $newonex=$gkinfo[colname][\"COLUMN_CLSTXT\"];  if ($newonex.indexOf(\"key\")>0){    eval('$newonex=datatxt.'+colname+'CLSTXT;');  }    if ($newonex!=\"\"){          $fmselect=formselect(qian($newonex,\"|\"),hou($newonex,\"|\"),thisval,\"p_\"+colname,\"txt-input\",\"\");    return $fmselect;  }else{   return \"\";  }}";
function mkaselect(colname,snox,thisval,$gkinfo){
  $newonex=$gkinfo[colname]["COLUMN_CLSTXT"];
  if ($newonex.indexOf("key")>0){
    eval('$newonex=datatxt.'+colname+'CLSTXT;');
  }  
  if ($newonex!=""){      
    $fmselect=formselect(qian($newonex,"|"),hou($newonex,"|"),thisval,"p_"+colname,"txt-input","");
    return $fmselect;
  }else{
   return "";
  }
}
ccode["multiselect"]="";
ccode["date"]="  {input id=\"p_[key]\" class=\"txt-input\" type=\"date\" name=\"p_[key]\" [rdol]  value=\"[thisvalue]\" placeholder=\"[exp]\"}";
ccode["datetime"]="  {input id=\"p_[key]\" class=\"txt-input\" type=\"datetime-local\" name=\"p_[key]\" [rdol]  value=\"[thisvalue]\" placeholder=\"[exp]\"}";
ccode["int"]="  {input id=\"p_[key]\" class=\"txt-input\" type=\"text\" name=\"p_[key]\" [rdol]  value=\"[thisvalue]\" placeholder=\"[exp]\"}";
ccode["tinyint"]="  {input id=\"p_[key]\" class=\"txt-input\" type=\"text\" name=\"p_[key]\" [rdol]  value=\"[thisvalue]\" placeholder=\"[exp]\"}";
ccode["decimal1"]="  {input id=\"p_[key]\" class=\"txt-input\" type=\"text\" name=\"p_[key]\" [rdol]  value=\"[thisvalue]\" placeholder=\"[exp]\"}";
ccode["decimal2"]="  {input id=\"p_[key]\" class=\"txt-input\" type=\"text\" name=\"p_[key]\" [rdol]  value=\"[thisvalue]\" placeholder=\"[exp]\"}";
ccode["decimal3"]="  {input id=\"p_[key]\" class=\"txt-input\" type=\"text\" name=\"p_[key]\" [rdol]  value=\"[thisvalue]\" placeholder=\"[exp]\"}";
ccode["decimal4"]="  {input id=\"p_[key]\" class=\"txt-input\" type=\"text\" name=\"p_[key]\" [rdol]  value=\"[thisvalue]\" placeholder=\"[exp]\"}";
ccode["imagex"]="function mkimage(thisval,dxtype,snox){  if (snox==\"0\"){    return \"<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-num='1' id='u_[key]'></div>[exp]</div>\";  }else{    return \"<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-value='\"+thisval+\"' data-num='1' id='u_[key]'></div>[exp]</div>\";  };}";
function mkimage(thisval,dxtype,snox){
  if (snox=="0"){
    return "<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-num='1' id='u_[key]'></div>[exp]</div>";
  }else{
    return "<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-value='"+thisval+"' data-num='1' id='u_[key]'></div>[exp]</div>";
  };
}
ccode["images"]="function mkimgx(thisval,dxtype,snox){  if (snox==\"0\"){    return \"<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-num='5' id='u_[key]'></div>[exp]</div>\";  }else{    if (right(thisval,1)==\";\"){     thisval=killlasttring(thisval);    };    return \"<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-value='\"+thisval+\"' data-num='5' id='u_[key]'></div>[exp]</div>\";  };}";
function mkimgx(thisval,dxtype,snox){
  if (snox=="0"){
    return "<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-num='5' id='u_[key]'></div>[exp]</div>";
  }else{
    if (right(thisval,1)==";"){
     thisval=killlasttring(thisval);
    };
    return "<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-value='"+thisval+"' data-num='5' id='u_[key]'></div>[exp]</div>";
  };
}
ccode["filex"]="function mkfilex(thisval,dxtype,snox){  if (snox==\"0\"){    return \"<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-num='1' id='u_[key]'></div>[exp]</div>\";  }else{    return \"<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-value='\"+thisval+\"' data-num='1' id='u_[key]'></div>[exp]</div>\";  };}";
function mkfilex(thisval,dxtype,snox){
  if (snox=="0"){
    return "<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-num='1' id='u_[key]'></div>[exp]</div>";
  }else{
    return "<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-value='"+thisval+"' data-num='1' id='u_[key]'></div>[exp]</div>";
  };
}
ccode["files"]="function mkduofile(thisval,dxtype,snox){  if (snox==\"0\"){    return \"<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-num='5' id='u_[key]'></div></div>\";  }else{    if (right(thisval,1)==\";\"){     thisval=killlasttring(thisval);    };    return \"<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-value='\"+thisval+\"' data-num='5' id='u_[key]'></div></div>\";  };}";
function mkduofile(thisval,dxtype,snox){
  if (snox=="0"){
    return "<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-num='5' id='u_[key]'></div></div>";
  }else{
    if (right(thisval,1)==";"){
     thisval=killlasttring(thisval);
    };
    return "<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-value='"+thisval+"' data-num='5' id='u_[key]'></div></div>";
  };
}
ccode["check"]="function mkocheck(colname,snox,thisval,$gkinfo){  $newonex=$gkinfo[colname][\"COLUMN_CLSTXT\"];    if ($newonex.indexOf(\"key\")>0){    eval('$newonex=datatxt.'+colname+'CLSTXT;');  }else{    $newonex=makeclstxt($newonex);  }  if ($newonex!=\"\"){    srddemo='[inner]{input id=\"p_[key]\" style=\"display:none;\"}';    actdemo='{input type=\"radio\" name=\"c_[key]\"  checked ck=\"c_[key]\" nm=\"p_[key]\" value=\"[value]\" onchange=\"newvaly(this)\"}[title]';    commdemo='{input type=\"radio\" name=\"c_[key]\" ck=\"c_[key]\" nm=\"p_[key]\" value=\"[value]\" onchange=\"newvaly(this)\"}[title]';    $fmselect=formcheckx(qian($newonex,\"|\"),hou($newonex,\"|\"),thisval,srddemo,actdemo,commdemo);        return \"[exp]:\"+$fmselect;      }else{   return \"\";  }}function newvaly(e){ $(\"#\"+$(e).attr(\"nm\")).val($(e).val()); return true;}";
function mkocheck(colname,snox,thisval,$gkinfo){
  $newonex=$gkinfo[colname]["COLUMN_CLSTXT"];  
  if ($newonex.indexOf("key")>0){
    eval('$newonex=datatxt.'+colname+'CLSTXT;');
  }else{
    $newonex=makeclstxt($newonex);
  }
  if ($newonex!=""){
    srddemo='[inner]{input id="p_[key]" style="display:none;"}';
    actdemo='{input type="radio" name="c_[key]"  checked ck="c_[key]" nm="p_[key]" value="[value]" onchange="newvaly(this)"}[title]';
    commdemo='{input type="radio" name="c_[key]" ck="c_[key]" nm="p_[key]" value="[value]" onchange="newvaly(this)"}[title]';
    $fmselect=formcheckx(qian($newonex,"|"),hou($newonex,"|"),thisval,srddemo,actdemo,commdemo);    
    return "[exp]:"+$fmselect;    
  }else{
   return "";
  }
}
function newvaly(e){
 $("#"+$(e).attr("nm")).val($(e).val());
 return true;
}
ccode["multicheck"]="function mkdcheck(colname,snox,thisval,$gkinfo){  $newonex=$gkinfo[colname][\"COLUMN_CLSTXT\"];    if ($newonex.indexOf(\"key\")>0){    eval('$newonex=datatxt.'+colname+'CLSTXT;');  }else{    $newonex=makeclstxt($newonex);  }  if ($newonex!=\"\"){    srddemo='[inner]{input id=\"p_[key]\" style=\"display:none;\"}';    actdemo='{input type=\"checkbox\" name=\"c_[key]\"  checked ck=\"c_[key]\" nm=\"p_[key]\" value=\"[value]\" onchange=\"newvalx(this)\"}[title]';    commdemo='{input type=\"checkbox\" name=\"c_[key]\" ck=\"c_[key]\" nm=\"p_[key]\" value=\"[value]\" onchange=\"newvalx(this)\"}[title]';    $fmselect=formcheckx(qian($newonex,\"|\"),hou($newonex,\"|\"),thisval,srddemo,actdemo,commdemo);        return \"[exp]\"+$fmselect;      }else{   return \"\";  }}function newvalx(e){ $(\"#\"+$(e).attr(\"nm\")).val(getchkvalue($(e).attr(\"ck\"))); return true;}";
function mkdcheck(colname,snox,thisval,$gkinfo){
  $newonex=$gkinfo[colname]["COLUMN_CLSTXT"];  
  if ($newonex.indexOf("key")>0){
    eval('$newonex=datatxt.'+colname+'CLSTXT;');
  }else{
    $newonex=makeclstxt($newonex);
  }
  if ($newonex!=""){
    srddemo='[inner]{input id="p_[key]" style="display:none;"}';
    actdemo='{input type="checkbox" name="c_[key]"  checked ck="c_[key]" nm="p_[key]" value="[value]" onchange="newvalx(this)"}[title]';
    commdemo='{input type="checkbox" name="c_[key]" ck="c_[key]" nm="p_[key]" value="[value]" onchange="newvalx(this)"}[title]';
    $fmselect=formcheckx(qian($newonex,"|"),hou($newonex,"|"),thisval,srddemo,actdemo,commdemo);    
    return "[exp]"+$fmselect;    
  }else{
   return "";
  }
}
function newvalx(e){
 $("#"+$(e).attr("nm")).val(getchkvalue($(e).attr("ck")));
 return true;
}
ccode["varcharSRD"]="";
ccode["textSRD"]="";
ccode["richtextSRD"]="";
ccode["codeSRD"]="";
ccode["selectSRD"]="";
ccode["multiselectSRD"]="";
ccode["dateSRD"]="";
ccode["datetimeSRD"]="";
ccode["intSRD"]="";
ccode["tinyintSRD"]="";
ccode["decimal1SRD"]="";
ccode["decimal2SRD"]="";
ccode["decimal3SRD"]="";
ccode["decimal4SRD"]="";
ccode["imagexSRD"]="";
ccode["imagesSRD"]="";
ccode["filexSRD"]="";
ccode["filesSRD"]="";
ccode["checkSRD"]="";
ccode["multicheckSRD"]="";
ccode["varcharINLINE"]="";
ccode["textINLINE"]="";
ccode["richtextINLINE"]="";
ccode["codeINLINE"]="";
ccode["selectINLINE"]="";
ccode["multiselectINLINE"]="";
ccode["dateINLINE"]="";
ccode["datetimeINLINE"]="";
ccode["intINLINE"]="";
ccode["tinyintINLINE"]="";
ccode["decimal1INLINE"]="";
ccode["decimal2INLINE"]="";
ccode["decimal3INLINE"]="";
ccode["decimal4INLINE"]="";
ccode["imagexINLINE"]="";
ccode["imagesINLINE"]="";
ccode["filexINLINE"]="";
ccode["filesINLINE"]="";
ccode["checkINLINE"]="";
ccode["multicheckINLINE"]="";
ccode["onerow"]="[rowx]";
ccode["duorow"]="[rowx]";
ccode["varcharFUNCTION"]="";
ccode["textFUNCTION"]="";
ccode["richtextFUNCTION"]="";
ccode["codeFUNCTION"]="";
ccode["selectFUNCTION"]="";
ccode["multiselectFUNCTION"]="";
ccode["dateFUNCTION"]="";
ccode["datetimeFUNCTION"]="";
ccode["intFUNCTION"]="";
ccode["tinyintFUNCTION"]="";
ccode["decimal1FUNCTION"]="";
ccode["decimal2FUNCTION"]="";
ccode["decimal3FUNCTION"]="";
ccode["decimal4FUNCTION"]="";
ccode["imagexFUNCTION"]="snox=dftval(GetRequest().SNO,\"0\"); if(snox==\"0\"){  $(\"#u_[key]\").attr(\"action\",\"/DNA/EXF/anyfuns.php?fid=easyrcvfile&tbnm=[thistable]&key=[key]&olmk=\"+$(\"#p_\"+$(\"#addform\").attr(\"olmkkey\")).val()); }else{  $(\"#u_[key]\").attr(\"action\",\"/DNA/EXF/anyfuns.php?fid=easyrcvfile&tbnm=[thistable]&key=[key]&SNO=\"+snox); } $(\"#u_[key]\").upload();";
ccode["imagesFUNCTION"]="snox=dftval(GetRequest().SNO,\"0\"); if(snox==\"0\"){  $(\"#u_[key]\").attr(\"action\",\"/DNA/EXF/anyfuns.php?fid=easyrcvfile&tbnm=[thistable]&key=[key]&olmk=\"+$(\"#p_\"+$(\"#addform\").attr(\"olmkkey\")).val()); }else{  $(\"#u_[key]\").attr(\"action\",\"/DNA/EXF/anyfuns.php?fid=easyrcvfile&tbnm=[thistable]&key=[key]&SNO=\"+snox); } $(\"#u_[key]\").upload();";
ccode["filexFUNCTION"]="snox=dftval(GetRequest().SNO,\"0\"); if(snox==\"0\"){  $(\"#u_[key]\").attr(\"action\",\"/DNA/EXF/anyfuns.php?fid=easyrcvfile&tbnm=[thistable]&key=[key]&olmk=\"+$(\"#p_\"+$(\"#addform\").attr(\"olmkkey\")).val()); }else{  $(\"#u_[key]\").attr(\"action\",\"/DNA/EXF/anyfuns.php?fid=easyrcvfile&tbnm=[thistable]&key=[key]&SNO=\"+snox); } $(\"#u_[key]\").upload();";
ccode["filesFUNCTION"]="snox=dftval(GetRequest().SNO,\"0\"); if(snox==\"0\"){  $(\"#u_[key]\").attr(\"action\",\"/DNA/EXF/anyfuns.php?fid=easyrcvfile&tbnm=[thistable]&key=[key]&olmk=\"+$(\"#p_\"+$(\"#addform\").attr(\"olmkkey\")).val()); }else{  $(\"#u_[key]\").attr(\"action\",\"/DNA/EXF/anyfuns.php?fid=easyrcvfile&tbnm=[thistable]&key=[key]&SNO=\"+snox); } $(\"#u_[key]\").upload();";
ccode["checkFUNCTION"]="";
ccode["checkduoFUNCTION"]="";
ccode["multicheckFUNCTION"]="";
ccode["duorowFUNCTION"]="";
ccode["srdFUNCTION"]="";
