var indexdata = 
[
    { text: '',isexpand:false, children: [ 
		{url:"demos/base/resizable.htm",text:"工作台"},
		{url:"demos/base/drag.htm",text:"消息中心"},
		{url:"demos/base/drag2.htm",text:"业务消息提醒"},
		{url:"demos/base/dragresizable.htm",text:"新闻公告"},
		{url:"demos/base/tip.htm",text:"战报信息"},
		{ url: "demos/filter/filter.htm", text: "工作总结" },
		{ url: "demos/filter/filterwin.htm", text: "通讯录" },
		{ url: "demos/filter/grid.htm", text: "内部论坛" },
		{ url: "demos/filter/filterwin.htm", text: "我的提醒" },
		{ url: "demos/filter/grid.htm", text: "员工请假管理" } 
	]
    },
   
	{ text: '',isexpand:false, children: [ 
		{ url: "demos/dialog/dialogAll.htm", text: "所有房源" },
        { url: "demos/dialog/dialogParent.htm", text: "本组房源" },
		{url:"demos/dialog/dialogTarget.htm",text:"出售房源"},
		{url:"demos/dialog/dialogUrl.htm",text:"出租房源"}, 
		{url:"demos/dialog/tip.htm",text:"我的房源"}, 
		{url:"demos/dialog/window.htm",text:"跟进管理"},
		{ url: "demos/dialog/dialogAll.htm", text: "楼盘销控中心" },
        { url: "demos/dialog/dialogParent.htm", text: "房价行情分析" },
		{url:"demos/dialog/dialogTarget.htm",text:"我的收藏"},
		{url:"demos/dialog/dialogUrl.htm",text:"广告管理"}, 
		{url:"demos/dialog/tip.htm",text:"审批管理"},
	]},
	{ text: '',isexpand:false, children: [  
		{url:"demos/menu/evenmenu.htm",text:"所有客源"},
		{url:"demos/menu/menubar.htm",text:"本组客源"}, 
		{url:"demos/menu/mulmenu.htm",text:"求购客源"},
		{url:"demos/menu/evenmenu.htm",text:"求租客源"},
		{url:"demos/menu/menubar.htm",text:"我的客源"}, 
		{url:"demos/menu/mulmenu.htm",text:"跟进管理"},
		{url:"demos/menu/mulmenu.htm",text:"我的收藏"}
	]},
	{ text: '',isexpand:false, children: [  
		{ url: "demos/comboBox/comboBoxSelect.htm", text: "合同查询" },
        { url: "demos/comboBox/comboBoxUnSelect.htm", text: "业绩分配" }

	]},
	{
	    text: '', isexpand: false, children: [
            { url: "demos/tree/bigDataTest.htm", text: "员工管理" },
            { url: "demos/tree/treeIsExpand.htm", text: "我的资料管理" },
            { url: "demos/tree/treeDelay.htm", text: "问卷调查" }
	]
	},

    {
        text: "", isexpand: "false", children: [
            { url: "demos/listbox/listboxCheckbox.htm", text: "打卡记录" }

        ]
    },

	{
	    text: '', isexpand: false, children: [
        
        { url: "demos/form/tab/default.htm", text: "门店工资管理" },
        { url: "demos/form/tab/indexInit.htm", text: "人员工资管理" }

	]
		},
	
    {
        isexpand: "false", text: "", children: [
           { url: "demos/portal/portal.htm", text: "门店业绩" },
           { url: "demos/portal/panel.htm", text: "个人、门店量化统计" },
           { url: "demos/portal/portal-columns.htm", text: "成交量分析" },
           { url: "demos/portal/portal-cookie.htm", text: "区域均价" },

        ]
    },
	 { text: '', isexpand: false, children: [
		   { url: "demos/portal/portal.htm", text: "学区房划分表" },
         
		
	]
    }, 
];


