$(window).resize(function(){
	var size = ($(window).width()/10);
	if(size > 72) size = 72;
	$('html').css('font-size',size+'px');
}).resize();



