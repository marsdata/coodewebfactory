/*-防止各大cdn公共库加载地址失效问题，此地址我们会时时监控，及调整以保障正常访问-www.jq22.com为您服务*/
/*当前为百度cdn公共库提供的jQuery-1.10.2*/
document.write("<script src='http://libs.baidu.com/jquery/1.10.2/jquery.min.js'><\/script>");