ccode=new Array();
ccode["srd"]="[diytop]{div id=\"main\"}{div class=\"page_title\"}[shorttitle]{/div}  {div class=\"demo\"}  {form id=\"addform\" class=\"jqtransform\" shortid=\"[shortid]\" showkeys=\"[showkeys]\" tabkeys=\"[tabkeys]\" tabname=\"[tabnm]\"  pssno=\"[pssno]\" pskey=\"[pskey]\" pstitle=\"[pstitle]\" pshead=\"[pshead]\" onsubmit=\"return changesmt();\" class=\"layui-form layui-col-md8\" style=\"margin-right:0px;\" action=\"\"}    [srdinner]    {p}{label}&nbsp;{/label}{input type=\"submit\" value=\"提交\" onclick=\"newx()\" /} {input type=\"reset\" value=\"重置\" onclick=\"window.location.reload()\" /}{/p}  {/form}  {/div}{/div}[diybottom]";
ccode["diytop"]="";
ccode["diybottom"]="";
ccode["varchar"]="{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\"  style=\"width:100%\" value=\"[value]\" size=\"60\" placeholder=\"[exp]\"}";
ccode["text"]="{textarea id=\"p_[key]\" [rdol] name=\"p_[key]\" style=\"[dspl]\" placeholder=\"[exp]\"  rows=\"6\" cols=\"40\"}[value]{/textarea}";
ccode["richtext"]="[vtitle]";
ccode["code"]="{textarea id=\"p_[key]\" [rdol] name=\"p_[key]\" style=\"[dspl]\" placeholder=\"[exp]\"  rows=\"6\" cols=\"40\"}[value]{/textarea}";
ccode["select"]="function mkoselect(colname,snox,thisval,$gkinfo){  $newonex=$gkinfo[colname][\"COLUMN_CLSTXT\"];  if ($newonex.indexOf(\"key\")>0){    eval('$newonex=datatxt.'+colname+'CLSTXT;');  }    if ($newonex!=\"\"){          $fmselect=formselect(qian($newonex,\"|\"),hou($newonex,\"|\"),thisval,\"p_\"+colname,\"\",\"\");    return $fmselect;  }else{   return \"\";  }}";
function mkoselect(colname,snox,thisval,$gkinfo){
  $newonex=$gkinfo[colname]["COLUMN_CLSTXT"];
  if ($newonex.indexOf("key")>0){
    eval('$newonex=datatxt.'+colname+'CLSTXT;');
  }  
  if ($newonex!=""){      
    $fmselect=formselect(qian($newonex,"|"),hou($newonex,"|"),thisval,"p_"+colname,"","");
    return $fmselect;
  }else{
   return "";
  }
}
ccode["multiselect"]="";
ccode["date"]="{input type=\"date\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\"  value=\"[value]\" placeholder=\"[exp]\"}";
ccode["datetime"]="{input type=\"datetime-local\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\"  value=\"[value]\" placeholder=\"[exp]\"}";
ccode["int"]="{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\"  value=\"[value]\" placeholder=\"[exp]\"}";
ccode["tinyint"]="{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\"  value=\"[value]\" placeholder=\"[exp]\"}";
ccode["decimal1"]="{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\"  value=\"[value]\" placeholder=\"[exp]\"}";
ccode["decimal2"]="{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\"  value=\"[value]\" placeholder=\"[exp]\"}";
ccode["decimal3"]="{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\"  value=\"[value]\" placeholder=\"[exp]\"}";
ccode["decimal4"]="{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\"  value=\"[value]\" placeholder=\"[exp]\"}";
ccode["imagex"]="";
ccode["images"]="";
ccode["filex"]="";
ccode["files"]="";
ccode["check"]="function mkocheck(colname,snox,thisval,$gkinfo){  $newonex=$gkinfo[colname][\"COLUMN_CLSTXT\"];    if ($newonex.indexOf(\"key\")>0){    eval('$newonex=datatxt.'+colname+'CLSTXT;');  }else{    $newonex=makeclstxt($newonex);  }  if ($newonex!=\"\"){    srddemo='[inner]{input id=\"p_[key]\" style=\"display:none;\"}';    actdemo='{input type=\"checkbox\" name=\"c_[key]\"  checked ck=\"c_[key]\" nm=\"p_[key]\" value=\"[value]\" onchange=\"newvaly(this)\"}[title]';    commdemo='{input type=\"checkbox\" name=\"c_[key]\" ck=\"c_[key]\" nm=\"p_[key]\" value=\"[value]\" onchange=\"newvaly(this)\"}[title]';    $fmselect=formcheckx(qian($newonex,\"|\"),hou($newonex,\"|\"),thisval,srddemo,actdemo,commdemo);        return $fmselect;      }else{   return \"\";  }}function newvaly(e){ $(\"#\"+$(e).attr(\"nm\")).val($(e).val()); return true;}";
function mkocheck(colname,snox,thisval,$gkinfo){
  $newonex=$gkinfo[colname]["COLUMN_CLSTXT"];  
  if ($newonex.indexOf("key")>0){
    eval('$newonex=datatxt.'+colname+'CLSTXT;');
  }else{
    $newonex=makeclstxt($newonex);
  }
  if ($newonex!=""){
    srddemo='[inner]{input id="p_[key]" style="display:none;"}';
    actdemo='{input type="checkbox" name="c_[key]"  checked ck="c_[key]" nm="p_[key]" value="[value]" onchange="newvaly(this)"}[title]';
    commdemo='{input type="checkbox" name="c_[key]" ck="c_[key]" nm="p_[key]" value="[value]" onchange="newvaly(this)"}[title]';
    $fmselect=formcheckx(qian($newonex,"|"),hou($newonex,"|"),thisval,srddemo,actdemo,commdemo);    
    return $fmselect;    
  }else{
   return "";
  }
}
function newvaly(e){
 $("#"+$(e).attr("nm")).val($(e).val());
 return true;
}
ccode["multicheck"]="function mkdcheck(colname,snox,thisval,$gkinfo){  $newonex=$gkinfo[colname][\"COLUMN_CLSTXT\"];    if ($newonex.indexOf(\"key\")>0){    eval('$newonex=datatxt.'+colname+'CLSTXT;');  }else{    $newonex=makeclstxt($newonex);  }  if ($newonex!=\"\"){    srddemo='[inner]{input id=\"p_[key]\" style=\"display:none;\"}';    actdemo='{input type=\"checkbox\" name=\"c_[key]\"  checked ck=\"c_[key]\" nm=\"p_[key]\" value=\"[value]\" onchange=\"newvalx(this)\"}[title]';    commdemo='{input type=\"checkbox\" name=\"c_[key]\" ck=\"c_[key]\" nm=\"p_[key]\" value=\"[value]\" onchange=\"newvalx(this)\"}[title]';    $fmselect=formcheckx(qian($newonex,\"|\"),hou($newonex,\"|\"),thisval,srddemo,actdemo,commdemo);        return $fmselect;      }else{   return \"\";  }}function newvalx(e){ $(\"#\"+$(e).attr(\"nm\")).val(getchkvalue($(e).attr(\"ck\"))); return true;}";
function mkdcheck(colname,snox,thisval,$gkinfo){
  $newonex=$gkinfo[colname]["COLUMN_CLSTXT"];  
  if ($newonex.indexOf("key")>0){
    eval('$newonex=datatxt.'+colname+'CLSTXT;');
  }else{
    $newonex=makeclstxt($newonex);
  }
  if ($newonex!=""){
    srddemo='[inner]{input id="p_[key]" style="display:none;"}';
    actdemo='{input type="checkbox" name="c_[key]"  checked ck="c_[key]" nm="p_[key]" value="[value]" onchange="newvalx(this)"}[title]';
    commdemo='{input type="checkbox" name="c_[key]" ck="c_[key]" nm="p_[key]" value="[value]" onchange="newvalx(this)"}[title]';
    $fmselect=formcheckx(qian($newonex,"|"),hou($newonex,"|"),thisval,srddemo,actdemo,commdemo);    
    return $fmselect;    
  }else{
   return "";
  }
}
function newvalx(e){
 $("#"+$(e).attr("nm")).val(getchkvalue($(e).attr("ck")));
 return true;
}
ccode["varcharSRD"]="";
ccode["textSRD"]="";
ccode["richtextSRD"]="";
ccode["codeSRD"]="";
ccode["selectSRD"]="";
ccode["multiselectSRD"]="";
ccode["dateSRD"]="";
ccode["datetimeSRD"]="";
ccode["intSRD"]="";
ccode["tinyintSRD"]="";
ccode["decimal1SRD"]="";
ccode["decimal2SRD"]="";
ccode["decimal3SRD"]="";
ccode["decimal4SRD"]="";
ccode["imagexSRD"]="";
ccode["imagesSRD"]="";
ccode["filexSRD"]="";
ccode["filesSRD"]="";
ccode["checkSRD"]="";
ccode["multicheckSRD"]="";
ccode["varcharINLINE"]="";
ccode["textINLINE"]="";
ccode["richtextINLINE"]="";
ccode["codeINLINE"]="";
ccode["selectINLINE"]="";
ccode["multiselectINLINE"]="";
ccode["dateINLINE"]="";
ccode["datetimeINLINE"]="";
ccode["intINLINE"]="";
ccode["tinyintINLINE"]="";
ccode["decimal1INLINE"]="";
ccode["decimal2INLINE"]="";
ccode["decimal3INLINE"]="";
ccode["decimal4INLINE"]="";
ccode["imagexINLINE"]="";
ccode["imagesINLINE"]="";
ccode["filexINLINE"]="";
ccode["filesINLINE"]="";
ccode["checkINLINE"]="";
ccode["multicheckINLINE"]="";
ccode["onerow"]="{p id=\"titleof[key]\" style=\"clear:both;[dspl]\"}{label}[title]：{/label}[rowx]{/p}";
ccode["duorow"]="{p id=\"titleof[key]\" style=\"clear:both;[dspl]\"}{label}[title]：{/label}[rowx]{/p}";
ccode["varcharFUNCTION"]="";
ccode["textFUNCTION"]="";
ccode["richtextFUNCTION"]="";
ccode["codeFUNCTION"]="";
ccode["selectFUNCTION"]="";
ccode["multiselectFUNCTION"]="";
ccode["dateFUNCTION"]="";
ccode["datetimeFUNCTION"]="";
ccode["intFUNCTION"]="";
ccode["tinyintFUNCTION"]="";
ccode["decimal1FUNCTION"]="";
ccode["decimal2FUNCTION"]="";
ccode["decimal3FUNCTION"]="";
ccode["decimal4FUNCTION"]="";
ccode["imagexFUNCTION"]="";
ccode["imagesFUNCTION"]="";
ccode["filexFUNCTION"]="";
ccode["filesFUNCTION"]="";
ccode["checkFUNCTION"]="";
ccode["checkduoFUNCTION"]="";
ccode["multicheckFUNCTION"]="";
ccode["duorowFUNCTION"]="";
ccode["srdFUNCTION"]="";
