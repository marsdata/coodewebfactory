
$(function () {
    let form = layui.form
        ,laydate = layui.laydate,
        laypage = layui.laypage,
        layer = layui.layer,
        table = layui.table;
    //常规用法
    laydate.render({
        elem: '#test1'
    });
    laydate.render({
        elem: '#test2'
    });




     let i=$("tr").length-2,j=1,k=1;
    $('.add-btn').click(function () {
        i++;
        addstrs1(i);
        form.render();
    });

    $('body').on("click",".btn-del",function () {
         var pre = $(this);
        layer.confirm('确定要删除么？',{
                btn:['确定','取消']
        },function () {
            $(pre).parent().parent().remove();
            layer.closeAll('dialog');
        })

        //
    });


    function getRandomNum() {
        return parseInt(Math.random()*50);
    }
    function addstrs1(i) {
        let  iNums = getRandomNum();
        let strs1;
            strs1 = '<tr>\n' +
   '    <td style="display: none">\n' +
   '    <input type="text" id="snu'+i+'" value="'+i+'">\n' +
   '    </td>\n' +
   '    <td>\n' +
   '    <input type="text" id="morgtitle'+i+'" class="layui-input" >\n' +
   '    </td>\n' +
   '    <td>\n' +
   '    <select id="morgtype'+i+'" lay-filter="">\n' +
   '     <option value="fileunit">文件资料</option>\n' +
   '     <option value="orgunit">组成单元</option>\n' +
   '     <option value="orgfun">功能</option>\n' +
   '    </select>\n' +
   '    </td>\n' +
   '    <td style="text-align: center"><button type="button" class="layui-btn layui-btn-danger btn-del">删除</button></td>\n' +
   '   </tr>';   
        $('.addlists').append(strs1);
        //重新渲染
        laydate.render({
            elem: '#test1'+iNums
            ,trigger: 'click' //采用click弹出
        });
        laydate.render({
            elem: '#test2'+iNums
            ,trigger: 'click' //采用click弹出
        });
    }



})
