function login() {
    window.location.href = "login.html";
}
function register() {
    window.location.href = "register.html";
}
function back() {
    history.back();
}
