$(document).ready(function(){
    $('.gallery-item').ma5gallery({
        preload:true,
        fullscreen:false
    });
});
/*www.sucaijiayuan.com*/