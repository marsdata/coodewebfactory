$(function(){
   
   /*顶部nav*/
   var swiper = new Swiper('.nav-container', {
  slidesPerView: 'auto',
  paginationClickable: true
 });
 $(".nav-ul .swiper-slide").click(function(){
    $(this).addClass("active-li").siblings().removeClass("active-li");
 });
 
 
 
 
 /*瀑布流初始化设置*/
   var $grid = $('.grid').masonry({
     itemSelector : '.grid-item',
     gutter:10
 });
 // layout Masonry after each image loads
   $grid.imagesLoaded().done( function() {
     console.log('uuuu===');
   $grid.masonry('layout');
   });
    var pageIndex = 0 ; var dataFall = [];
    var totalItem = 10;
    $(window).scroll(function(){
     
      $grid.masonry('layout');
    var scrollTop = $(this).scrollTop();var scrollHeight = $(document).height();var windowHeight = $(this).height(); 
    tmpall=sessionStorage.fmall;
    // && (tmpall.indexOf(','+(sessionStorage.pagex)+',')<=0)==true
    if ((scrollHeight-(scrollTop + windowHeight) <=10)){          
      if (dftval(GetRequest().mtype,"0")=="0" ){
      sessionStorage.pagex=intval(sessionStorage.pagex)+1;
      sessionStorage.fmall=sessionStorage.fmall+sessionStorage.pagex+",";       
      $.ajax({
            dataType:"json",
            type:'get',
            url:'/SPEC/EDITOR/anyshort.php?stid=8VjGcy&mt='+(GetRequest().mtype*100)+"&pnum=10&page="+sessionStorage.pagex,
           success:function(result){
             dataFall = result.vls;
             setTimeout(function(){
                appendFall();
             },500)
           },
           error:function(e){
             console.log('请求失败')
           }           
        })
       }else{
        sessionStorage.pagex=intval(sessionStorage.pagex)+1;
       $.ajax({
            dataType:"json",
            type:'get',
            url:'/SPEC/EDITOR/anyshort.php?stid=8Vj83g&mt='+(GetRequest().mtype*100)+"&pnum=10&page="+sessionStorage.pagex,
           success:function(result){
             dataFall = result.vls;
             setTimeout(function(){
                appendFall();
             },500)
           },
           error:function(e){
             console.log('请求失败')
           }           
        })
        
       }//ifmtp
       
    }//
    
   }) 
 
  
  function appendFall(){
   $.each(dataFall, function(index ,value) {
     var dataLength = dataFall.length;
     $grid.imagesLoaded().done( function() {
     $grid.masonry('layout');
      });
    var detailUrl;
     var $griDiv = $('<div class="grid-item item">');
     var $img = $("<img class='item-img'>");
     $img.attr('src',value.mQrUrl).appendTo($griDiv);
     var $section = $('<section class="section-p">');
     $section.appendTo($griDiv);
     var $p1 = $("<p class='title-p'>");
     $p1.html(value.srcTitle).appendTo($section);
     var $p2 = $("<p class='name-p'>");
     $p2.html(value.mSize).appendTo($section);
     var $p3 = $("<p class='price-p'>");
     $p3.html(value.mCode).appendTo($section);
     var $items = $griDiv;
      $items.imagesLoaded().done(function(){
           $grid.masonry('layout');
      $grid.append( $items ).masonry('appended', $items);
        })
   });
  }
 
 
 
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
})
