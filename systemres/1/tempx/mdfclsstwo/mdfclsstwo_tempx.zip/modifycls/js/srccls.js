var province=["机电设备","机电产品及配件","金属材料","非金属材料","劳保、消防器材"];
var city=[["采煤系统","掘进系统","露采设备","运输设备","电气设备","提升设备","排水设备","通风设备","压风设备","矿井安全设备","选煤设备","煤矿采掘通用设备","机电配件","地面车辆"],["低压电器及附件","照明电器","仪器仪表","电子元件","蓄电池","紧固件","轴承","阀门","金属管件","轨道附件","焊机焊条","简易起重机具","通用配件","矿用钻（凿）岩工具","工具量具磨具索具"],["黑色金属材料","有色金属材料","金属丝绳","电线电缆","胶带连接","金属支护用品"],["木材","非金属建筑材料","石棉及制品","耐火材料","橡塑制品","爆破材料","液体燃料及润滑油脂","涂料","其他工业产品"],["劳动防护服","头部用品","呼吸防护用品","手部防护用品","足部防护用品","登高防坠用具","消防器材","洗浴用品"]];
var district=[["采煤系统","掘进系统","露采设备","运输设备","电气设备","提升设备","排水设备","通风设备","压风设备","矿井安全设备","选煤设备","煤矿采掘通用设备","机电配件","地面车辆"],["低压电器及附件","照明电器","仪器仪表","电子元件","蓄电池","紧固件","轴承","阀门","金属管件","轨道附件","焊机焊条","简易起重机具","通用配件","矿用钻（凿）岩工具","工具量具磨具索具"],["黑色金属材料","有色金属材料","金属丝绳","电线电缆","胶带连接","金属支护用品"],["木材","非金属建筑材料","石棉及制品","耐火材料","橡塑制品","爆破材料","液体燃料及润滑油脂","涂料","其他工业产品"],["劳动防护服","头部用品","呼吸防护用品","手部防护用品","足部防护用品","登高防坠用具","消防器材","洗浴用品"]];
var expressArea, areaCont, areaList = $("#areaList"), areaTop = areaList.offset().top;

/*初始化省份*/
function intProvince() {
	areaCont = "";
	for (var i=0; i<province.length; i++) {
		areaCont += '<li onClick="selectP(' + i + ');">' + province[i] + '</li>';
	}
	areaList.html(areaCont);
	$("#areaBox").scrollTop(0);
	$("#backUp").removeAttr("onClick").hide();
}
intProvince();

/*选择省份*/
function selectP(p) {
	areaCont = "";
	areaList.html("");
	for (var j=0; j<city[p].length; j++) {
		areaCont += '<li onClick="selectC(' + p + ',' + j + ');">' + city[p][j] + '</li>';
	}
	areaList.html(areaCont);
	$("#areaBox").scrollTop(0);
	expressArea = province[p] + " > ";
	$('#remen').hide();
}

/*选择城市*/
function selectC(p,c) {
	areaCont = "";
	for (var k=0; k<district[p][c].length; k++) {
		areaCont += '<li onClick="selectD(' + p + ',' + c + ',' + k + ');">' + district[p][c][k] + '</li>';
	}
	areaList.html(areaCont);
	$("#areaBox").scrollTop(0);
	var sCity = city[p][c];
	
	if (sCity != "省直辖县级行政单位") {
		if (sCity == "东莞市" || sCity == "中山市" || sCity == "儋州市" || sCity == "嘉峪关市") {
			expressArea += sCity;
			$("#expressArea dl dd").html(expressArea);
			clockArea();
		} 
	}
	
	//截断渲染省市
	clockArea();
	var expressArea = province[p] +'-'+ city[p][c];
	//判断是否是市辖区和市辖县
	if (expressArea == province[p] + '-' +'市辖区' || expressArea == province[p] + '-' +'市辖县') {
		$("#expressArea dl dd").html(province[p]);
	}else{
		$("#expressArea dl dd").html(expressArea);
	}
	$("#backUp").attr("onClick", "selectP(" + p + ");");
}

/*选择区县*/
function selectD(p,c,d) {
	clockArea();
	expressArea += district[p][c][d];
	$("#expressArea dl dd").html(expressArea);
}

/*关闭省市区选项*/
function clockArea() {
	$("#areaMask").fadeOut();
	$("#areaLayer").animate({"right": "-100%"});
	$('#remen').show();
	intProvince();
}

$(function() {
	/*打开省市区选项*/
	$("#expressArea").click(function() {
		$("#areaMask").fadeIn();
		$("#areaLayer").animate({"right": 0});
	});
	/*关闭省市区选项*/
	$("#areaMask, #closeArea").click(function() {
		clockArea();
	});
	//选择semen城市
	$('#remen .list').click(function(){
		var remen_city = $(this).html();
		$("#expressArea dl dd").html(remen_city);
		clockArea();
	})
});