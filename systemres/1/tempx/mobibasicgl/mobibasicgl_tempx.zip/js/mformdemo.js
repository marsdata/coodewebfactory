ccode=new Array();
ccode["srd"]="{form class=\"form\" name=\"contact-form\"  id=\"addform\" shortid=\"[shortid]\" showkeys=\"[showkeys]\" olmkkey=\"[olmkkey]\" prisno=\"[prisno]\" tabname=\"[tabname]\" onsubmit=\"return changesmt();\"}  {h1 class=\"form__headline\"}{/h1}  {div class=\"form__description\"}    {!-- {p}{a href=\"javascript:void(0)\" onclick=\"golatest();\"}点击返回列表{/a}{/p}--}  {/div}[srdinner]  {!--{div class=\"form__confirm\"}    {p class=\"form__confirm-text\"}      {a class=\"form__link\" href=\"#privacy-policy\"}{/a}     {/p}  {/div}--}  {div class=\"form__submit\" style=\"\"}    {a  class=\"button\" href=\"javascript:void(0)\" onclick=\"newx()\" }提交{/a}    {p class=\"form__validation\" data-validation=\"submit\" role=\"alert\" aria-live=\"assertive\"}{/p}      {/div}{/form}";
ccode["diytop"]="";
ccode["diybottom"]="";
ccode["varchar"]="{input id=\"p_[key]\" class=\"text-input__body\" type=\"text\" name=\"p_[key]\" [rdol]  value=\"[thisvalue]\" placeholder=\"[exp]\"}{span class=\"text-input__validator\"}{/span}";
ccode["text"]=" {textarea id=\"p_[key]\" class=\"textarea__body\" style=\"height:50px;\" name=\"p_[key]\"  [rdol]  placeholder=\"[exp]\"}[thisvalue]{/textarea}";
ccode["richtext"]=" {textarea id=\"p_[key]\" class=\"textarea__body\" name=\"p_[key]\" style=\"height:40px;\"  [rdol]   placeholder=\"[exp]\"}[thisvalue]{/textarea}";
ccode["code"]=" {textarea id=\"p_[key]\" class=\"textarea__body\" name=\"p_[key]\" style=\"height:40px;\"  [rdol]   placeholder=\"[exp]\"}[thisvalue]{/textarea}";
ccode["select"]="function mkaselect(colname,snox,thisval,$gkinfo){  $newonex=$gkinfo[colname][\"COLUMN_CLSTXT\"];  if ($newonex.indexOf(\"key\")>0){    eval('$newonex=datatxt.'+colname+'CLSTXT;');  }    if ($newonex!=\"\"){          $fmselect=formselect(qian($newonex,\"|\"),hou($newonex,\"|\"),thisval,\"p_\"+colname,\"select-box__body\",\"\");    return $fmselect;  }else{   return \"\";  }}";
function mkaselect(colname,snox,thisval,$gkinfo){
  $newonex=$gkinfo[colname]["COLUMN_CLSTXT"];
  if ($newonex.indexOf("key")>0){
    eval('$newonex=datatxt.'+colname+'CLSTXT;');
  }  
  if ($newonex!=""){      
    $fmselect=formselect(qian($newonex,"|"),hou($newonex,"|"),thisval,"p_"+colname,"select-box__body","");
    return $fmselect;
  }else{
   return "";
  }
}
ccode["multiselect"]="function mkbselect(colname,snox,thisval,$gkinfo){  $newonex=$gkinfo[colname][\"COLUMN_CLSTXT\"];    if ($newonex.indexOf(\"key\")>0){    eval('$newonex=datatxt.'+colname+'CLSTXT;');  }else{    $newonex=makeclstxt($newonex);  }  if ($newonex!=\"\"){    srddemo='{ul class=\"form__group-list\"}[inner]{/ul}{input id=\"p_[key]\" style=\"display:none;\"}';    actdemo='{li class=\"form__group-list-item\"}{label class=\"checkbox\"}{input class=\"checkbox__input\" type=\"checkbox\" name=\"c_[key]\"  checked ck=\"c_[key]\" nm=\"p_[key]\" value=\"[value]\" onchange=\"newvalx(this)\"}{span class=\"checkbox__icon\"}{/span}{span class=\"checkbox__text\"}[title]{/span}{/label}{/li}';    commdemo='{li class=\"form__group-list-item\"}{label class=\"checkbox\"}{input class=\"checkbox__input\" type=\"checkbox\" name=\"c_[key]\"  ck=\"c_[key]\" nm=\"p_[key]\" value=\"[value]\" onchange=\"newvalx(this)\"}{span class=\"checkbox__icon\"}{/span}{span class=\"checkbox__text\"}[title]{/span}{/label}{/li}';    $fmselect=formcheckx(qian($newonex,\"|\"),hou($newonex,\"|\"),thisval,srddemo,actdemo,commdemo);        return $fmselect;      }else{   return \"\";  }}function newvalx(e){ $(\"#\"+$(e).attr(\"nm\")).val(getchkvalue($(e).attr(\"ck\"))); return true;}";
function mkbselect(colname,snox,thisval,$gkinfo){
  $newonex=$gkinfo[colname]["COLUMN_CLSTXT"];  
  if ($newonex.indexOf("key")>0){
    eval('$newonex=datatxt.'+colname+'CLSTXT;');
  }else{
    $newonex=makeclstxt($newonex);
  }
  if ($newonex!=""){
    srddemo='{ul class="form__group-list"}[inner]{/ul}{input id="p_[key]" style="display:none;"}';
    actdemo='{li class="form__group-list-item"}{label class="checkbox"}{input class="checkbox__input" type="checkbox" name="c_[key]"  checked ck="c_[key]" nm="p_[key]" value="[value]" onchange="newvalx(this)"}{span class="checkbox__icon"}{/span}{span class="checkbox__text"}[title]{/span}{/label}{/li}';
    commdemo='{li class="form__group-list-item"}{label class="checkbox"}{input class="checkbox__input" type="checkbox" name="c_[key]"  ck="c_[key]" nm="p_[key]" value="[value]" onchange="newvalx(this)"}{span class="checkbox__icon"}{/span}{span class="checkbox__text"}[title]{/span}{/label}{/li}';
    $fmselect=formcheckx(qian($newonex,"|"),hou($newonex,"|"),thisval,srddemo,actdemo,commdemo);    
    return $fmselect;    
  }else{
   return "";
  }
}
function newvalx(e){
 $("#"+$(e).attr("nm")).val(getchkvalue($(e).attr("ck")));
 return true;
}
ccode["date"]="{input type=\"text\" id=\"p_[key]\" data-options=\"｛'type':'YYYY-MM-DD','beginYear':2010,'endYear':2088｝\" style=\"width:166px;height:19px;\" value=\"[thisvalue]\"}";
ccode["datetime"]="{input type=\"text\" id=\"p_[key]\" data-options=\"｛'type':'YYYY-MM-DD hh:mm:ss','beginYear':1900,'endYear':2099｝\" style=\"width:170px;height:25px;vertical-align: middle;text-align: left;\" value=\"[thisvalue]\"}";
ccode["int"]="{input id=\"p_[key]\" class=\"text-input__body\" type=\"text\" name=\"p_[key]\" [rdol]  value=\"[thisvalue]\"  placeholder=\"[exp]\"}{span class=\"text-input__validator\"}{/span}";
ccode["tinyint"]="";
ccode["decimal1"]="{input id=\"p_[key]\" class=\"text-input__body\" type=\"text\" name=\"p_[key]\" [rdol]  value=\"[thisvalue]\"}{span class=\"text-input__validator\"}{/span}";
ccode["decimal2"]="{input id=\"p_[key]\" class=\"text-input__body\" type=\"text\" name=\"p_[key]\" [rdol]  value=\"[thisvalue]\"}{span class=\"text-input__validator\"}{/span}";
ccode["decimal3"]="{input id=\"p_[key]\" class=\"text-input__body\" type=\"text\" name=\"p_[key]\" [rdol]  value=\"[thisvalue]\"}{span class=\"text-input__validator\"}{/span}";
ccode["decimal4"]="{input id=\"p_[key]\" class=\"text-input__body\" type=\"text\" name=\"p_[key]\" [rdol]  value=\"[thisvalue]\"}{span class=\"text-input__validator\"}{/span}";
ccode["imagex"]="function mkimage(thisval,dxtype,snox){  if (snox==\"0\"){    return \"<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-num='1' id='u_[key]'></div>[exp]</div>\";  }else{    return \"<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-value='\"+thisval+\"' data-num='1' id='u_[key]'></div>[exp]</div>\";  };}";
function mkimage(thisval,dxtype,snox){
  if (snox=="0"){
    return "<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-num='1' id='u_[key]'></div>[exp]</div>";
  }else{
    return "<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-value='"+thisval+"' data-num='1' id='u_[key]'></div>[exp]</div>";
  };
}
ccode["images"]="function mkimgx(thisval,dxtype,snox){  if (snox==\"0\"){    return \"<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-num='5' id='u_[key]'></div>[exp]</div>\";  }else{    if (right(thisval,1)==\";\"){     thisval=killlasttring(thisval);    };    return \"<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-value='\"+thisval+\"' data-num='5' id='u_[key]'></div>[exp]</div>\";  };}";
function mkimgx(thisval,dxtype,snox){
  if (snox=="0"){
    return "<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-num='5' id='u_[key]'></div>[exp]</div>";
  }else{
    if (right(thisval,1)==";"){
     thisval=killlasttring(thisval);
    };
    return "<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-value='"+thisval+"' data-num='5' id='u_[key]'></div>[exp]</div>";
  };
}
ccode["filex"]="function mkfilex(thisval,dxtype,snox){  if (snox==\"0\"){    return \"<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-num='1' id='u_[key]'></div>[exp]</div>\";  }else{    return \"<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-value='\"+thisval+\"' data-num='1' id='u_[key]'></div>[exp]</div>\";  };}";
function mkfilex(thisval,dxtype,snox){
  if (snox=="0"){
    return "<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-num='1' id='u_[key]'></div>[exp]</div>";
  }else{
    return "<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-value='"+thisval+"' data-num='1' id='u_[key]'></div>[exp]</div>";
  };
}
ccode["files"]="function mkduofile(thisval,dxtype,snox){  if (snox==\"0\"){    return \"<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-num='5' id='u_[key]'></div></div>\";  }else{    if (right(thisval,1)==\";\"){     thisval=killlasttring(thisval);    };    return \"<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-value='\"+thisval+\"' data-num='5' id='u_[key]'></div></div>\";  };}";
function mkduofile(thisval,dxtype,snox){
  if (snox=="0"){
    return "<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-num='5' id='u_[key]'></div></div>";
  }else{
    if (right(thisval,1)==";"){
     thisval=killlasttring(thisval);
    };
    return "<div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-value='"+thisval+"' data-num='5' id='u_[key]'></div></div>";
  };
}
ccode["check"]="";
ccode["multicheck"]="";
ccode["varcharSRD"]="  {div class=\"form__group\" style=\"[dspl]\"}    {p class=\"form__group-header\"}      {label class=\"form__group-label\" for=\"p_[key]\"}[title]{/label}          {/p}    {div class=\"form__group-content\"}      {div class=\"form__text-input -wide\"}        {p class=\"text-input\" id=\"eleof[key]\"}           [rowx]        {/p}      {/div}      {p class=\"form__validation\" data-validation=\"p_[key]\" role=\"alert\" aria-live=\"assertive\"}{/p}    {/div}  {/div}";
ccode["textSRD"]="{div class=\"form__group\" style=\"[dspl]\"}    {p class=\"form__group-header\"}      {label class=\"form__group-label\" for=\"p_[key]\"}[title]{/label}    {/p}    {div class=\"form__group-content\"}      {div class=\"form__textarea\"}        {div id=\"eleof[key]\"  class=\"textarea js-flexible-textarea\"}        [inner]        {/div}      {/div}      {p class=\"form__validation\" data-validation=\"p_[key]\" role=\"alert\" aria-live=\"assertive\"}{/p}    {/div}  {/div}";
ccode["richtextSRD"]="{div class=\"form__group\" style=\"[dspl]\"}    {p class=\"form__group-header\"}      {label class=\"form__group-label\" for=\"p_[key]\"}[title]{/label}    {/p}    {div class=\"form__group-content\"}      {div class=\"form__textarea\"}        {div id=\"eleof[key]\"  class=\"textarea js-flexible-textarea\"}        [inner]        {/div}      {/div}      {p class=\"form__validation\" data-validation=\"p_[key]\" role=\"alert\" aria-live=\"assertive\"}{/p}    {/div}  {/div}";
ccode["codeSRD"]="{div class=\"form__group\" style=\"[dspl]\"}    {p class=\"form__group-header\"}      {label class=\"form__group-label\" for=\"p_[key]\"}[title]{/label}    {/p}    {div class=\"form__group-content\"}      {div class=\"form__textarea\"}        {div id=\"eleof[key]\"  class=\"textarea js-flexible-textarea\"}        [inner]        {/div}      {/div}      {p class=\"form__validation\" data-validation=\"p_[key]\" role=\"alert\" aria-live=\"assertive\"}{/p}    {/div}  {/div}";
ccode["selectSRD"]="{div class=\"form__group\" style=\"[dspl]\"}    {p class=\"form__group-header\"}      {label class=\"form__group-label\" for=\"p_[key]\"}[title]{/label}    {/p}    {div class=\"form__group-content\"}      {div class=\"form__select-box\"}        {div class=\"select-box\" id=\"eleof[key]\"}          [inner]        {/div}      {/div}      {p class=\"form__validation\" data-validation=\"p_[key]\" role=\"alert\" aria-live=\"assertive\"}{/p}    {/div}  {/div}";
ccode["multiselectSRD"]="{fieldset class=\"form__group\"}      {legend class=\"form__group-header\"}      {span class=\"form__group-label\"}[title]{/span}    {/legend}    {div class=\"form__group-content\" id=\"eleof[key]\"}      [inner]    {/div}{/fieldset}";
ccode["dateSRD"]="  {div class=\"form__group\" style=\"[dspl]\"}    {p class=\"form__group-header\"}      {label class=\"form__group-label\" for=\"p_[key]\"}[title]{/label}    {/p}    {div class=\"form__group-content\"}      {div class=\"form__text-input\"}        {p class=\"text-input\" id=\"eleof[key]\"}         [inner]        {/p}      {/div}    {/div}  {/div}";
ccode["datetimeSRD"]="  {div class=\"form__group\" style=\"[dspl]\"}    {p class=\"form__group-header\"}      {label class=\"form__group-label\" for=\"p_[key]\"}[title]{/label}          {/p}    {div class=\"form__group-content\"}      {div class=\"form__text-input -wide\"}        {p class=\"text-input\" id=\"eleof[key]\"}           [inner]        {/p}      {/div}      {p class=\"form__validation\" data-validation=\"p_[key]\" role=\"alert\" aria-live=\"assertive\"}{/p}    {/div}  {/div}";
ccode["intSRD"]="  {div class=\"form__group\" style=\"[dspl]\"}    {p class=\"form__group-header\"}      {label class=\"form__group-label\" for=\"p_[key]\"}[title]{/label}          {/p}    {div class=\"form__group-content\"}      {div class=\"form__text-input -wide\"}        {p class=\"text-input\" id=\"eleof[key]\"}           [rowx]        {/p}      {/div}      {p class=\"form__validation\" data-validation=\"p_[key]\" role=\"alert\" aria-live=\"assertive\"}{/p}    {/div}  {/div}";
ccode["tinyintSRD"]="";
ccode["decimal1SRD"]="";
ccode["decimal2SRD"]="";
ccode["decimal3SRD"]="";
ccode["decimal4SRD"]="";
ccode["imagexSRD"]="  {div class=\"form__group\" style=\"[dspl]\"}    {p class=\"form__group-header\"}      {span class=\"form__group-label\"}[title]{/span}    {/p}    {div class=\"form__group-content\"}      {div class=\"form__file-select\"}        {div class=\"file-select js-flie-select\" id=\"eleof[key]\"}          [inner]                  {/div}      {/div}    {/div}  {/div}";
ccode["imagesSRD"]="  {div class=\"form__group\" style=\"[dspl]\"}    {p class=\"form__group-header\"}      {span class=\"form__group-label\"}[title]{/span}    {/p}    {div class=\"form__group-content\"}      {div class=\"form__file-select\"}        {div class=\"file-select js-flie-select\" id=\"eleof[key]\"}          [inner]                  {/div}      {/div}    {/div}  {/div}";
ccode["filexSRD"]="  {div class=\"form__group\" style=\"[dspl]\"}    {p class=\"form__group-header\"}      {span class=\"form__group-label\"}[title]{/span}    {/p}    {div class=\"form__group-content\"}      {div class=\"form__file-select\"}        {div class=\"file-select js-flie-select\" id=\"eleof[key]\"}          [inner]                  {/div}      {/div}    {/div}  {/div}";
ccode["filesSRD"]="  {div class=\"form__group\" style=\"[dspl]\"}    {p class=\"form__group-header\"}      {span class=\"form__group-label\"}[title]{/span}    {/p}    {div class=\"form__group-content\"}      {div class=\"form__file-select\"}        {div class=\"file-select js-flie-select\" id=\"eleof[key]\"}          [inner]                  {/div}      {/div}    {/div}  {/div}";
ccode["checkSRD"]="";
ccode["multicheckSRD"]="";
ccode["varcharINLINE"]="";
ccode["textINLINE"]="";
ccode["richtextINLINE"]="";
ccode["codeINLINE"]="";
ccode["selectINLINE"]="";
ccode["multiselectINLINE"]="";
ccode["dateINLINE"]="";
ccode["datetimeINLINE"]="";
ccode["intINLINE"]="";
ccode["tinyintINLINE"]="";
ccode["decimal1INLINE"]="";
ccode["decimal2INLINE"]="";
ccode["decimal3INLINE"]="";
ccode["decimal4INLINE"]="";
ccode["imagexINLINE"]="";
ccode["imagesINLINE"]="";
ccode["filexINLINE"]="";
ccode["filesINLINE"]="";
ccode["checkINLINE"]="";
ccode["multicheckINLINE"]="";
ccode["onerow"]="[rowx]";
ccode["duorow"]="[rowx]";
ccode["varcharFUNCTION"]="";
ccode["textFUNCTION"]="";
ccode["richtextFUNCTION"]="";
ccode["codeFUNCTION"]="";
ccode["selectFUNCTION"]="";
ccode["multiselectFUNCTION"]="";
ccode["dateFUNCTION"]="$.date(\"#p_[key]\");";
ccode["datetimeFUNCTION"]="$.date(\"#p_[key]\");";
ccode["intFUNCTION"]="";
ccode["tinyintFUNCTION"]="";
ccode["decimal1FUNCTION"]="";
ccode["decimal2FUNCTION"]="";
ccode["decimal3FUNCTION"]="";
ccode["decimal4FUNCTION"]="";
ccode["imagexFUNCTION"]="snox=_get(\"SNO\"); if(snox==\"0\"){  $(\"#u_[key]\").attr(\"action\",\"/localxres/funx/easyrcvfile/?tbnm=[thistable]&key=[key]&olmk=\"+$(\"#p_\"+$(\"#addform\").attr(\"olmkkey\")).val()); }else{  $(\"#u_[key]\").attr(\"action\",\"/localxres/funx/easyrcvfile/?tbnm=[thistable]&key=[key]&SNO=\"+snox); } $(\"#u_[key]\").upload();";
ccode["imagesFUNCTION"]="snox=_get(\"SNO\"); if(snox==\"0\"){  $(\"#u_[key]\").attr(\"action\",\"/localxres/funx/easyrcvfile/?tbnm=[thistable]&key=[key]&olmk=\"+$(\"#p_\"+$(\"#addform\").attr(\"olmkkey\")).val()); }else{  $(\"#u_[key]\").attr(\"action\",\"/localxres/funx/easyrcvfile/?tbnm=[thistable]&key=[key]&SNO=\"+snox); } $(\"#u_[key]\").upload();";
ccode["filexFUNCTION"]="snox=_get(\"SNO\"); if(snox==\"0\"){  $(\"#u_[key]\").attr(\"action\",\"/localxres/funx/easyrcvfile/?tbnm=[thistable]&key=[key]&olmk=\"+$(\"#p_OLMK\").val()); }else{  $(\"#u_[key]\").attr(\"action\",\"/localxres/funx/easyrcvfile/?tbnm=[thistable]&key=[key]&SNO=\"+snox); } $(\"#u_[key]\").upload();";
ccode["filesFUNCTION"]="snox=_get(\"SNO\"); if(snox==\"0\"){  $(\"#u_[key]\").attr(\"action\",\"/localxres/funx/easyrcvfile/?tbnm=[thistable]&key=[key]&olmk=\"+$(\"#p_OLMK\").val()); }else{  $(\"#u_[key]\").attr(\"action\",\"/localxres/funx/easyrcvfile/?tbnm=[thistable]&key=[key]&SNO=\"+snox); } $(\"#u_[key]\").upload();";
ccode["checkFUNCTION"]="";
ccode["checkduoFUNCTION"]="";
ccode["multicheckFUNCTION"]="";
ccode["duorowFUNCTION"]="";
ccode["srdFUNCTION"]="";
