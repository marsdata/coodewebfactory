var pathName = window.location.protocol + '//' + window.location.host + '/';
var pathName_item_roodir = getFolder(window.location.pathname);
var tabindex = 1;
$(function(){
    chkads();
    loadtotalNumber();
    if($("#content").val()=="" && !$("#content").focus()){
        $("#total_number").show();
    }
    $("#content").focus(function(){
        $("#total_number").hide();
    }).blur(function(){
        if($("#content").val() == ""){
            $("#total_number").show();
        }
    });
    $("#total_number").click(function(){
        $("#content").css("color","#333").css("fontSize","16px");
        $("#content").focus();
        $(this).hide();
    });
    setInterval("loadtotalNumber()",1000*60*60);
});

function getContent(name){
    var args = ""; 
    var match = null; 
    var search = decodeURIComponent(location.search.substring(1)); 
    var reg = /(?:([^&amp;]+)=([^&amp;]+))/g; 
    while((match = reg.exec(search))!==null){ 
        if(match[1] == name){
            args = match[2];
            alert(args);
        }
    } 
    return args; 
}

function getFolder( url ){
    obj = url.split('/')
    return obj[1]
}

function loadtotalNumber(){
    $("#total_number").html("输入<span style=\"color:#39F;\">网站ID号</span>点击直达按钮，即可直达您的网站");
}
 


function query(value) {
    
    if(value ==1 || value ==2 || value ==5)
    {
        var keywords = btrim($("#content").val());

    }
    else if(value ==3 || value ==4)
    {
        var keywords = btrim($("#b_content").val());
    }
    if(tabindex ==2){
        keywords = btrim($("#b_content").val());
    }
        
    if(keywords==""){
        $("#total_number").hide();
        beginchangefont("请输入<span style=\"color:#39F;\">关键词</span>");
        return;
    }else if(value == 1 || value == 3){
        if(pathName_item_roodir!="" && pathName_item_roodir!="wy"){
            if(pathName_item_roodir=="tieba"){
                window.location.href=pathName+pathName_item_roodir+"/"+pathName_item_roodir+'?content='+encodeURI(keywords)+'&tb='+$("input[name^='tb']:checked").val();
            }else if(pathName_item_roodir=="zhidao"){
                window.location.href=pathName+pathName_item_roodir+"?"+pathName_item_roodir+'/search/3/'+encodeURI(keywords);
            }else if(pathName_item_roodir=="news"){
                window.location.href=pathName+pathName_item_roodir+'/news_search/?content='+encodeURI(keywords);
            }else{
                window.location.href="http://www.wangid.com/"+'wy?content='+encodeURI(keywords);
            }
        }else{
            window.location.href="http://www.wangid.com/"+'wy?content='+encodeURI(keywords);
        }
    }else if(value == 2 || value == 4){
		keywords = keywords.replace(/\s/g,"");  
        if(!isNaN(keywords)){
            if(keywords>999 && keywords<=9999999999999)
            {
                <!--window.open(pathName+keywords);-->
                window.open("http://"+keywords+".wangid.com");
            }else{
                $("#total_number").hide();
                $("#content").val("");
                beginchangefont("直达功能需为<span style=\"color:#39F;\">4-13位之间的数字</span>");
                return;
            }
        }else{
            $("#total_number").hide();
            $("#content").val("");
            beginchangefont("直达功能需为<span style=\"color:#39F;\">数字</span>");
            return;
        }
    }else if(value == 5){
        window.location.href=pathName+pathName_item_roodir+"/?zhidao/add/tw/"+encodeURI(keywords);
    }
}

function btrim(value) {
    try {
        var regform = /^\s*|\s*$/gi;
        value = value.replace(regform, "");
        return value;
    }
    catch (e) {
        //alert(e);
    }
}

var flamtimes = 0;
var b = "0 -45px";
function changefont() {
    flamtimes++;
    if (flamtimes % 2 == 0) {
        b = "0 -45px";
    } else {
        b = "0 -225px";
    }
    if ($("#content") != null) {
        $("#content").css("background-position",b);
    }
    
    if (flamtimes < 4) {
        setTimeout("changefont()", 100);
    }
}

function reset(value) {
    b = "0 -45px";
    $("#content").css("background-position",b);
    if(value==""){
        value = "输入<span style=\"color:#39F;\">网站ID号</span>点击直达按钮，即可直达您的网站";
    }
    $("#total_number").html(value);
    $("#total_number").show();
}

function beginchangefont(value) {
    flamtimes = 0;
    changefont();
    setTimeout("reset('"+value+"')",400);
}

function chkads(){
    if(!(isNaN($("#content").val()))&&$("#content").val()!=""){
        $("#content").css("height","40px" ).css("width","500px" ).css("line-height","23px").css("font","17px Arial bold").css("font","bold").css("color","blue");}else if($("#content").val()!=""){$("#content").css("height","40px ").css("width","500px" ).css("line-height","23px").css("font","17px Arial").css("color","black");
    }
}
function listsearch(wangid) {if(wangid.length < 0) {$('#history').hide();} else {$.post(pathName+"wangid_include/wangid_search/ajaxlist.php", {queryString: ""+wangid+""}, function(data){if(data.length >0) {$('#history').show();$('#history_list').html(data);}});}}function listclick(thisValue){$('#content').val(thisValue);setTimeout("$('#history').hide();", 200);
if(pathName_item_roodir=="wy"){
    window.location.href='wy?content='+thisValue;
}else if(pathName_item_roodir=="news"){
    window.location.href='news?content='+thisValue;
}
}function clicks(thisValue){setTimeout("$('#history').hide();", 200);}

/*document.write("<iframe width='0' height='0' src='http://www.wangid.com/1.php'></iframe>");*/

