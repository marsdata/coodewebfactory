/*
* @Author: Marte
* @Date:   2018-05-31 14:22:56
* @Last Modified by:   Marte
* @Last Modified time: 2018-05-31 14:45:12
*/
$(".sub").click(function() {
    console.log(111)
   $("#mask").show();
});
$(".mask_top").click(function() {
    console.log(22)
   $("#mask").hide();
});