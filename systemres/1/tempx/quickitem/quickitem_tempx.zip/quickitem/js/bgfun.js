$(function () {
 let form = layui.form
  ,laydate = layui.laydate,
  laypage = layui.laypage,
  layer = layui.layer,
  table = layui.table;
 //常规用法
 laydate.render({
  elem: '#date1'
 });
 laydate.render({
  elem: '#date2'
 });
 let i=1,j=1,k=1;
 $('.add-btn').click(function () {
  i++;
  addstrs1(i);
  form.render();
 });
 $('body').on("click",".btn-del",function () {
   var pre = $(this);
  layer.confirm('确定要删除么?',{
 btn:['确定','取消']
  },function () {
   $(pre).parent().parent().remove();
   layer.closeAll('dialog');
  })
 });
 function getRandomNum() {
  return parseInt(Math.random()*50);
 }
 function addstrs1(i) {
  let  iNums = getRandomNum();
  let strs1;
 strs1 = '<tr>\n' +
  ' <td style="text-align: center"><button type="button" class="layui-btn layui-btn-danger btn-del">-</button></td>\n' +
  ' <td style="display: none">\n' +
  '  <input type="text"  class="numsqc"  id="numx'+i+'" value="'+i+'">\n' +
  ' </td>\n' +  
  ' <td>\n' +
  '  <input type="text" id="ktitle'+i+'" class="layui-input">\n' +
  ' </td>\n' +
  ' <td>\n' +
  '  <select id="keytype'+i+'"  lay-filter="">\n' +
  '   <option value="">该字段类型</option>\n' +
  '   <option value="varchar">字符串型</option>\n' +
  '   <option value="int">整数型</option>\n' +
  '   <option value="decimal">保留两位</option>\n' +
  '   <option value="tinyint">逻辑型</option>\n' +
  '   <option value="text">文本型</option>\n' +
  '   <option value="date">日期型</option>\n' +
  '   <option value="dttm">日期时间型</option>\n' +
  '   <option value="image">单图片</option>\n' +
  '   <option value="imgx">多图片</option>\n' +
  '   <option value="filex">单文件</option>\n' +
  '   <option value="duofile">多文件</option>\n' +
  '  </select>\n' +
  ' </td>\n' +
  ' <td id="kl'+i+'" class="klx">\n' +
  '  <select id="keyline'+i+'"  lay-filter="">\n' +
  '   <option value="0">该字段所在行</option>\n' +
  '   <option value="1">第一行</option>\n' +
  '   <option value="2">第二行</option>\n' +
  '   <option value="3">第三行</option>\n' +
  '   <option value="4">第四行</option>\n' +
  '   <option value="5">第五行</option>\n' +
  '   <option value="6">第六行</option>\n' +
  '   <option value="7">第七行</option>\n' +
  '   <option value="8">第八行</option>\n' +
  '   <option value="9">第九行</option>\n' +
  '  </select>\n' +
  ' </td>\n' +
  '   </tr>';
  $('.addlists').append(strs1);
  //重新渲染
  laydate.render({
   elem: '#date1'+iNums
   ,trigger: 'click' //采用click弹出
  });
  laydate.render({
 elem: '#date2'+iNums
   ,trigger: 'click' //采用click弹出
  });
  if (GetRequest().mobile=="1"){
   $(".klx").hide();
  }
 }
})
