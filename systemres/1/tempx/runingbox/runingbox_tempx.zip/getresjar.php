<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../localxres/EARTH.php';

$jsony=file_get_contents("../resjar/basetab.json");
$jsont=json_decode($jsony,false);
$sysid=$jsont->msg;
$vls=$jsont->vls;
for ($jj=0;$jj<count($vls);$jj++){
    $imghead=$vls[$jj]->imghead; 
    $TABLE_NAME=$vls[$jj]->TABLE_NAME; 
    $tabtitle=$vls[$jj]->tabtitle; 
    $createsql=$vls[$jj]->createsql; 
    $mainsqx=$vls[$jj]->mainsqx; 
    $subsqx=$vls[$jj]->subsqx; 
    $olmkkey=$vls[$jj]->olmkkey; 
    $areakey=$vls[$jj]->areakey; 
    $md5key=$vls[$jj]->md5key; 
    $srckey=$vls[$jj]->srckey; 
    $srcttk=$vls[$jj]->srcttk; 
    $parreskey=$vls[$jj]->parreskey; 
    $vermd5=$vls[$jj]->vermd5; 
    $OLMK=$vls[$jj]->OLMK; 
    $cc=crttab(0,$createsql);
    $sqla="imghead,TABLE_NAME,tabtitle,createsql,mainsqx,subsqx,olmkkey,areakey,md5key,srckey,srcttk,parreskey,vermd5,OLMK";
    $sqlb="'$imghead','$TABLE_NAME','$tabtitle','$createsql','$mainsqx','$subsqx','$olmkkey','$areakey','$md5key','$srckey','$srcttk','$parreskey','$vermd5','$OLMK'";
    $exttab=UX("select count(*) as result from coode_tablist where TABLE_NAME='".$TABLE_NAME."'");
    if ($exttab*1==0){
        $cc=UX("insert into coode_tablist(".$sqla.")values(".$sqlb.")");
    }else{
        $dd=UX("update coode_tablist set imghead='".$imghead."',tabtitle='".$tabtitle."',createsql='".$createsql."',mainsqx='".$mainsqx."',subsqx='".$subsqx."',olmkkey='".$olmkkey."',areakey='".$areakey."',md5key='".$md5key."',srckey='".$srckey."',srcttk='".$srcttk."',parreskey='".$parreskey."',vermd5='".$vermd5."',OLMK='".$OLMK."' where TABLE_NAME='".$TABLE_NAME."'");
    }
}
$totrst=UX("select count(*) as result from coode_installdetail where insmark='".date("Y-m-d")."'");
$jsonx=file_get_contents("../resjar/".$sysid."01.json");
$jsonx=str_replace("获取成功",($totrst*1),$jsonx);
echo $jsonx;
   
?>