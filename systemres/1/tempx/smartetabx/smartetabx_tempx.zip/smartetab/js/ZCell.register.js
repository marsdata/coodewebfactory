function  resetzr()
{
    zr = ["E62327FA26A2E37F69062528CDE4B0E0"];
   
}
