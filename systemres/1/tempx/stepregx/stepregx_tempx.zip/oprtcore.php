<?php
session_start();
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
error_reporting(0);
register_shutdown_function('zyfshutdownfunc');
set_error_handler('zyferror');
$acttype=$_GET["otype"];

switch ($acttype) {
    case "dbase":
        $fip=$_GET["fip"];
        $fuser=$_GET["fuser"];
        $fpass=$_GET["fpass"];
        $fbase=$_GET["fbase"];

        $mcode=$_GET["mcode"];
        $vcode=$_GET["vcode"];

         $bkask=file_get_contents("http://divlovecss.com/localxres/funx/askforcoode/?hdomain=".$_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"]);
         $bkdata=json_decode($bkask);
         $rcode=$bkdata->rcode;
         $vcode=$bkdata->vcode;
         $conn=mysql_connect($fip,$fuser,$fpass);
         $earthtxta=file_get_contents("../resjar/USERDEFINE.txt");
         $earthtxtb=file_get_contents("../resjar/EARTH.php");
         if (vflink($conn)>0){
                if ($rcode!=""){
                    $earthtxta=str_replace("[fip]",$fip,$earthtxta);
                    $earthtxta=str_replace("[fuser]",$fuser,$earthtxta);
                    $earthtxta=str_replace("[fpass]",$fpass,$earthtxta);
                    $earthtxta=str_replace("[fbase]",$fbase,$earthtxta);
                    $earthtxta=str_replace("[sysid]","WEO",$earthtxta);
                    $earthtxta=str_replace("[rcode]",$rcode,$earthtxta);
                    $earthtxta=str_replace("[vcode]",$vcode,$earthtxta);
                    $zz1=overfile(mdir()."/localxres/USERDEFINE.php",$earthtxta);
                    $zz2=overfile(mdir()."/localxres/EARTH.php",$earthtxtb);
                    //$fdir=mdir()."/resjar/";
                    //$todir=mdir()."/localxres/";
                    //$zz1=copy_underdir($fdir,$todir);
                    $crtsqla='CREATE TABLE coode_installidx (SNO int(11) NOT NULL AUTO_INCREMENT,insmark varchar(50) NOT NULL,institle varchar(255) NOT NULL,host varchar(255) NOT NULL,sysid varchar(1024) NOT NULL,succnum int(11) NOT NULL,failnum int(11) NOT NULL,starttime datetime NOT NULL,OLMK varchar(255) NOT NULL,CRTOR varchar(255) NOT NULL,PRIME int(11) NOT NULL,STCODE varchar(1024) NOT NULL,STATUS tinyint(4) NOT NULL,VRT varchar(255) NOT NULL,RIP varchar(255) NOT NULL,UPTM datetime NOT NULL,CRTM datetime NOT NULL,PTOF varchar(255) NOT NULL,OPRT varchar(1024) NOT NULL,PRIMARY KEY (SNO)) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;';
                    $crtsqlb='CREATE TABLE coode_installdetail (SNO int(11) NOT NULL AUTO_INCREMENT,insmark varchar(50) NOT NULL,institle varchar(255) NOT NULL,host varchar(255) NOT NULL,sysid varchar(50) NOT NULL,restype varchar(50) NOT NULL,restitle varchar(255) NOT NULL,rescode varchar(50) NOT NULL,finishtime datetime NOT NULL,CRTOR varchar(255) NOT NULL,PRIME int(11) NOT NULL,STCODE varchar(1024) NOT NULL,STATUS tinyint(4) NOT NULL,VRT varchar(255) NOT NULL,RIP varchar(255) NOT NULL,UPTM datetime NOT NULL,CRTM datetime NOT NULL,PTOF varchar(255) NOT NULL,OLMK varchar(50) NOT NULL,OPRT varchar(1024) NOT NULL,PRIMARY KEY (SNO),UNIQUE KEY opid (insmark,sysid,rescode) USING BTREE) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;';
                    $crtsqlc='CREATE TABLE coode_tablist (  SNO int(11) NOT NULL AUTO_INCREMENT,  schm varchar(50) NOT NULL,  rescode varchar(100) NOT NULL,  imghead varchar(1024) NOT NULL,  worldmarks varchar(1024) NOT NULL,  restpcode varchar(100) NOT NULL,  tabnick varchar(50) NOT NULL,  TABLE_NAME varchar(30) NOT NULL,  resenword varchar(50) NOT NULL,  reschiword varchar(100) NOT NULL,  allkeys text NOT NULL,  mainsqx varchar(50) NOT NULL,  subsqx varchar(50) NOT NULL,  olmkkey varchar(50) NOT NULL,  areakey varchar(50) NOT NULL,  md5key varchar(50) NOT NULL,  createsql text NOT NULL,  contentkeys text NOT NULL,  jsonconts text NOT NULL,  keynames text NOT NULL,  keytpnms text NOT NULL,  jsontpnms text NOT NULL,  srckey varchar(100) NOT NULL,  srcttk varchar(100) NOT NULL,  parreskey varchar(100) NOT NULL,  aitkey varchar(100) NOT NULL,  aivkey varchar(100) NOT NULL,  issys tinyint(4) NOT NULL,  ispmiss tinyint(4) NOT NULL,  tabtitle varchar(30) NOT NULL,  tabtype varchar(50) NOT NULL,  tabcls varchar(100) NOT NULL,  sysid varchar(100) NOT NULL,  keylens int(11) NOT NULL,  sizetype varchar(50) NOT NULL,  grpmark varchar(50) NOT NULL,  CRTOR varchar(30) NOT NULL,  vermd5 varchar(100) NOT NULL,  hasshort tinyint(4) NOT NULL,  beforeview longtext NOT NULL,  ickey varchar(100) NOT NULL,  iwkey varchar(100) NOT NULL,  copyrightmark varchar(20) NOT NULL,  STATUS tinyint(4) NOT NULL,  OLMK varchar(30) NOT NULL,  CRTM datetime NOT NULL,  PTOF varchar(30) NOT NULL,  VRT varchar(50) NOT NULL,  UPTM datetime NOT NULL,  STCODE varchar(1024) NOT NULL,  PRIME int(11) NOT NULL,  RIP varchar(255) NOT NULL,  OPRT varchar(1024) NOT NULL,  PRIMARY KEY (SNO),  UNIQUE KEY oltab (TABLE_NAME) USING BTREE) ENGINE=InnoDB AUTO_INCREMENT=2386 DEFAULT CHARSET=utf8;';
                    $conn=mysql_connect($fip,$fuser,$fpass);
                    $zz=updatingy($conn,$fbase,$crtsqla,"utf8");
                    $conn=mysql_connect($fip,$fuser,$fpass);
                    $zz=updatingy($conn,$fbase,$crtsqlb,"utf8");
                    $conn=mysql_connect($fip,$fuser,$fpass);
                    $zz=updatingy($conn,$fbase,$crtsqlc,"utf8");
                  echo '{"status":"1","msg":"制作核心配置文件操作成功"}';   
                }else{
                  echo '{"status":"0","msg":"操作失败"}';     
                }

        }else{
                echo '{"status":"0","msg":"链接失败"}';
        }
    break;
    case "vflink":
        $fip=$_GET["fip"];
        $fuser=$_GET["fuser"];
        $fpass=$_GET["fpass"];
        $fbase=$_GET["fbase"];
        $vcode=$_GET["vcode"];
        
        $conn=mysql_connect($fip,$fuser,$fpass);
        if (vflink($conn)>0){
             echo '{"status":"1","msg":"数据库连接成功"}';
        }else{
             echo '{"status":"0","msg":"数据库连接失败"}';
        }
        $vfc=$_GET["vfc"];
        $vfm=$_GET["vfm"];
        $fvfa="";
        $fvfk="";
    break;
    default:
}
function mysql_connect($fi,$fu,$fp){return new mysqli($fi,$fu,$fp);}
function vflink($conx){
 if ($conx){
    return updatingy($conx,"information_schema","select count(*) as result from COLUMNS","utf8")*1;
 }else{
    return -1;    
 }
}

function mdir(){
  if (substr(str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]),-1)!="/"){
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"])."/";
  }else{
    $gml=str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);
  };
 if (strpos($gml,":")>0){
  $qdq=xqian($gml,":");
  $gml=strtoupper($qdq).":".xhou($gml,":");
 }
$tmpdqml=str_replace("\\","/",dirname(__FILE__));
 if (strpos($tmpdqml,":")>0){
  $qdqx=xqian($tmpdqml,":");
  $tmpdqml=strtoupper($qdqx).":".xhou($tmpdqml,":");
 }
 $pathx=str_replace($gml,"",$tmpdqml)."/";
 $xdml="../../../../../../../../";
 $tms=0;
 for ($c=0;$c<strlen($pathx);$c++){
   if (substr($pathx,$c,1)=="/"){
    $tms=$tms+1;
   };
 }
 return substr($xdml,0,3*$tms);
}
function xqian($fullstr,$astr){
//完美兼容中文混合
 $cunzaibu=strpos("x".$fullstr,$astr);
 if ($cunzaibu>0){
  $astrlen=strpos($fullstr,$astr);
  $fmrt=substr($fullstr,0,$astrlen);
  return $fmrt;
  }else{
   return $fullstr;
  }
}
function xhou($fullstr,$astr){
 //完美兼容中文混合
 $cunzaibu=strpos("x".$fullstr,$astr);
 if ($cunzaibu>0){
  $spos=strpos($fullstr,$astr);
  $lens=strlen($astr);
  $alll=strlen($fullstr);
  return substr($fullstr,($spos+$lens),($alll-($spos+$lens)));
 }else{
  return $fullstr;
 };
}
function overfile($fnm,$ftxt){
  $lsx=explode("/",$fnm);
  $totls=count($lsx);
  $frt=str_replace($lsx[$totls-1],"",$fnm);
  $cx=createdir($frt);
 $myfile = fopen($fnm, "w") or die("Unable to open file!");
 $txt = $ftxt;
 fwrite($myfile, $txt);
 fclose($myfile);
 return 1;
}
function createdir($path){
 if (is_dir($path)){
    return "0";
 }else{
  //第三个参数是“true”表示能创建多级目录，iconv防止中文目录乱码
   $res=mkdir($path,0777,true);
   if ($res){
    return 1;
   }else{
    return -1;
   }
 }

} 
function make_numbers( $length = 6 )
{
    for($i = 0; $i < $length; $i++)
    {
        // 将 $length 个数组元素连接成字符串
        $password .= rand(0, 9);
    }
    return $password;
}
function updatingy($con,$db,$sqlstr,$lan){
 //mysql_select_db($db, $con);
 //mysql_query("SET NAMES ".$lan);    
 if (gettype($con)=="object" and $con){
 $con -> query("set names '".$lan."'"); //数据库输出编码
 $con -> select_db($db); //打开数据库
 $result = $con->query($sqlstr); //查询成功
//$result = mysql_query($sqlstr);
  if (strpos($sqlstr,"result")>0){
   if ($result){
      while($row = mysqli_fetch_array($result))
      {
        mysqli_close($con);
        return empty($row["result"])?"":$row["result"];
      }
   }else{
     $sqlerror=mysqli_error($con);
     mysqli_close($con);  
     return "failure:SE-".$sqlerror."@".$sqlstr;
   }
  }else{
   mysqli_close($con);
   return $result?1:0;
  };
 }else{
  if (gettype($con)=="object"){
   return "failure:SE-".mysqli_error();
  }else{
  //远程
   $purl="http://".$con["host"]."/funx/updatingx/?db=".$db."&uid=";
   $pdata=array();
   $pdata["sqlstr"]=$sqlstr;
   return request_post($purl,$pdata);
  }
 } 
}//DESCRIB ():  END@()
function killlaststr($strx){ return substr($strx,0,strlen($strx)-1);}
function copy_dir($src="", $dst="")
{
    if (empty($src) || empty($dst))
    {
        return false;
    }
    $dir = opendir($src);
    is_dir($dst) OR mkdir($dst, 0777, true); 
    while (false !== ($file = readdir($dir)))
    {
        if (($file != '.') && ($file != '..'))
        {
            if (is_dir($src . '/' . $file))
            {
                copy_dir($src . '/' . $file, $dst . '/' . $file);
            }
            else
            {
                copy($src . '/' . $file, $dst . '/' . $file);
            }
        }
    }
    closedir($dir);
    return true;
}
function copy_underdir($from_dir,$to_dir){//只复制目录里文件内容到另一个目录
    if (substr($to_dir,-1)=="/"){
      $to_dir=killlaststr($to_dir);
    }
     if (!is_dir($from_dir)){
        return false;
    }    
    $from_files = scandir($from_dir);    
    if (!file_exists($to_dir)){        
      is_dir($to_dir) OR mkdir($to_dir, 0777, true); 
    }
    if (!empty($from_files)){
        foreach ($from_files as $file){
            if ($file == '.' || $file == '..' ){
                continue;
            }              
            if (is_dir($from_dir.'/'.$file)){//如果是目录，则调用自身
                copy_dir($from_dir.'/'.$file,$to_dir.'/'.$file);
            }else{//直接copy到目标文件夹
                copy($from_dir.'/'.$file,$to_dir.'/'.$file);
            }
        }
    }
   return true;
 }
?>