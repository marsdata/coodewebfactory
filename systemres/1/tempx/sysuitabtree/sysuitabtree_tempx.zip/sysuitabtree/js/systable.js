/*
 * SYSUI-SYSTABLEMODULE
 * 2019-06-05 version2.5
 * 799129700@qq.com SYSHUXL-化海天堂 by www.husysui.com
 * Reserved head available commercial use
 * Universal background system interface framework
 */
function extend(o, n, override) {
	for(var key in n) {
		if(n.hasOwnProperty(key) && (!o.hasOwnProperty(key) || override)) {
			o[key] = n[key];
		}
	}
	return o;
};
/** 
 * map遍历数组 
 * @param fn [function] 回调函数； 
 * @param context [object] 上下文； 
 */
Array.prototype.myMap = function(fn, context) {
	context = context || window;
	var ary = [];
	if(Array.prototype.map) {
		ary = this.map(fn, context);
	} else {
		for(var i = 0; i < this.length; i++) {
			ary[i] = fn.apply(context, [this[i], i, this]);
		}
	}
	return ary;
}
//处理
function addLoadListener(fn) {
	if(typeof window.addEventListener != 'undefined') {
		window.addEventListener('load', fn, false);
	} else if(typeof document.addEventListener != 'undefined') {
		document.addEventListener('load', fn, false);
	} else if(typeof window.attachEvent != 'undefined') {
		window.attachEvent('onload', fn);
	} else {
		var oldfn = window.onload;
		if(typeof window.onload != 'function') {
			window.onload = fn;
		} else {
			window.onload = function() {
				oldfn();
				fn();
			};
		}
	}
};
//简化document.getElementById方法
function TAB$(i) {
	return document.getElementById(i)
};
//简化document.createElement方法
function TABLAYER$(i) {
	return document.createElement(i)
};
//简化document.getElementsByName方法
function name$(i) {
	return document.getElementsByName(i)
}

function tagname$(i) {
	return document.getElementsByTagName(i)
}
// 插件构造函数 - 返回数组结构
function SYSTableSorter(options) {
	this._initial(options);
};
SYSTableSorter.prototype = {
	constructor: this,
	_initial: function(options) {
		var par = {
			TableName: '', //table表格名称
			btnArea: '', //执行table外的按钮操作区域
			paginName: '', //设置分页区域
			defaultimg: 'default_img.png', //图片加载默认图
			edit: '', //编辑区
			curPage: 1, //默认显示当前页
			Sequence: [], //输入需要排序的位置排序
			RightClick: false, //是否允许右键
			mobile: false, //是否启用移动模式
			scrollName: null, //滚动区域
			template: true, //是否启用内置模块编辑
			btnpageing: 5, //用于显示分页列表按钮数量
			mode: '', //html界面显示模table\ul
			setItem: '', //存储表名
			CustomName: '',
			TreeStatus: false, //是否启用树状图结构
			treeArrowSite: 1, //树状图箭头位置
			CustomKey: '',
			loading: '<div class="loading">加载中请稍等......</div>', //加载样式设置
			ErrorMessage: '操作失败，请稍后再试！', //错误提示信息
			SuccessPrompt: '操作成功！', //成功提示信息
			timeFormat: '', //时间格式
			pageSize: [], //设置每页显示条数
			ViewState: [], //无需设置
			sessionArr: [], //无需设置
			mobBackdrop:'',//移动下拉背景样式设置
			SelectName: '', //下拉数据表键值名称，用于数组格式时使用，当有下拉时填写该值，用于获取名称，该值与你数据库中键值名相同
			Callback: function() {}, //回调table数据
			SpreadEvent: function() {}, //用户自定义扩展方法
			DeleteEvent: function() {}, //删除
			ModifyEvent: function() {}, //修改
			DetailedEvent: function() {}, //详细
			SelectEvent: function() {}, //下拉操作，只在于有下拉时进行编辑。
			SaveEvent: function() {}, //保存提交事件
			CheckboxDeleteEvent: function() {}, //批量删除事件
			SearchEvent: function() {}, //搜索事件
			ExceldData: function() {} //导出表格	
		};
		this.par = extend(par, options, true);
		//判断是否存在class属性方法
		this.hasClass = function(elements, cName) {
			return !!elements.className.match(new RegExp("(\\s|^)" + cName + "(\\s|$)"));
		}
		//添加class属性方法
		this.addClass = function(elements, cName) {
			if(!this.hasClass(elements, cName)) {
				elements.className += " " + cName;
			};
		};
		//删除class属性方法 elements当前结构  cName类名
		this.removeClass = function(elements, cName) {
			if(this.hasClass(elements, cName)) {
				elements.className = elements.className.replace(new RegExp("(\\s|^)" + cName + "(\\s|$)"), " "); // replace方法是替换
			};
		};
		//根据class类名条件筛选结构
		this.getByClass = function(oParent, sClass) { //根据class获取元素
			var oReasult = [];
			var oEle = oParent.getElementsByTagName("*");
			for(i = 0; i < oEle.length; i++) {
				if(oEle[i].className == sClass) {
					oReasult.push(oEle[i]);
				}
			};
			return oReasult;
		};
		//根据class类名条件筛选结构
		this.getElementsByClassName = function(parent, className) {
			//获取所有父节点下的tag元素　
			var aEls = parent.getElementsByTagName("*");　　
			var arr = [];
			//循环所有tag元素　
			for(var i = 0; i < aEls.length; i++) {
				//将tag元素所包含的className集合（这里指一个元素可能包含多个class）拆分成数组,赋值给aClassName	　　　　
				var aClassName = aEls[i].className.split(' ');　　　　 //遍历每个tag元素所包含的每个className
				for(var j = 0; j < aClassName.length; j++) {　　　　　　 //如果符合所选class，添加到arr数组				　　　　　
					if(aClassName[j] == className) {　　　　　　　　
						arr.push(aEls[i]);　　　　　　　　 //如果className里面包含'box' 则跳出循环						　　　　　　　　
						break; //防止一个元素出现多次相同的class被添加多次						　　　　　　
					}　　　　
				};　　
			};　　
			return arr;
		};
		//删除指定_element方法
		this.removeElement = function(_element) {
			var _parentElement = _element.parentNode;
			if(_parentElement) {
				_parentElement.removeChild(_element);
			};
		};
		this.show(this.par);
	},
	//方法
	show: function(callback) {
		var _this = this;
		var Table = TAB$(callback.TableName);
		var other = TAB$(callback.btnArea); //声明执行对象
		var mode = callback.mode;
		var args = callback.Sequence;
		if(mode == "table") {
			// 设置表头的状态位，排序时根据状态判断升降序 
			for(var x = 0; x < Table.rows[0].cells.length; x++) {
				callback.ViewState[x] = false;
				var th = document.createAttribute("data-th");
				th.nodeValue = x;
				Table.rows[0].cells[x].setAttributeNode(th);
			};
			if(args != null) {
				for(var s = 0; s < args.length; s++) {
					if(args.length > 1) {
						if(args.length > Table.rows[0].cells.length) {
							continue;
						} else {
							var newDiv = TABLAYER$("em");
							_this.addClass(newDiv, 'NormalCss');
							Table.rows[0].cells[args[s]].appendChild(newDiv);
							Table.rows[0].cells[args[s]].onclick = function(e) {
								var sortname = e.target;
								var z = sortname.getAttribute("data-th");
								for(var m = 0; m < args.length; m++) {
									var id = args[m];
									if(id == z) {
										_this.onSequence(Table, id, sortname);
									}
								}
							};
							Table.rows[0].cells[args[s]].style.cursor = "pointer";
						}
					}
				}
			};
			//checkbox全选选择操作，表格列宽拖拽
			var tTD;
			for(var x = 0; x < Table.rows[0].cells.length; x++) {
				var checkbox = Table.rows[0].cells[x].getElementsByTagName('input')[x];
				checkbox ? Table.rows[0].cells[x].onclick = function(e) {
					for(var m = 0; m < Table.rows[0].cells.length; m++) {
						_this.oncheckbox(Table, m);
					}
				} : '';
				//表格拖拽
				Table.rows[0].cells[x].onmousedown = function(e) {
					_this.Dragdrop(e, Table, tTD, this);
				}
				Table.rows[0].cells[x].onmouseup = function(e) {
					_this.onmouseupDrop(e, Table, tTD, this);

				}
				Table.rows[0].cells[x].onmousemove = function(e) {
					_this.onmousemoveDrop(e, Table, tTD, this);
				}
			};
		}
		_this.callbackf(Table, _this, other);

		if(callback.RightClick == true) {
			document.oncontextmenu = function(e) {
				e.preventDefault();
				e.stopPropagation();
			}
		}; //禁用右键功能
		_this.sessionArrhtml(Table);
		_this.par.SpreadEvent(_this);
	},
	//判断是手机还是pc
	isMobile: function(mobile_flag) {
		var userAgentInfo = navigator.userAgent;
		var mobileAgents = ["Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod"];
		var mobile_flag = false;
		//根据userAgent判断是否是手机
		for(var v = 0; v < mobileAgents.length; v++) {
			if(userAgentInfo.indexOf(mobileAgents[v]) > 0) {
				mobile_flag = true;
				break;
			}
		}
		var screen_width = window.screen.width;
		var screen_height = window.screen.height;
		//根据屏幕分辨率判断是否是手机
		if(screen_width < 500 && screen_height < 800) {
			mobile_flag = true;
		}
		return mobile_flag;
	},
	getScrollHeight: function() {
		var fileh = TAB$(_this.par.scrollName);
		var scrollHeight = 0,
			bodyScrollHeight = 0,
			documentScrollHeight = 0;　　
		if(fileh!=null) {　　　　
			bodyScrollHeight = fileh.scrollHeight;　
			if(document.documentElement) {　　　　
			    documentScrollHeight = fileh.scrollHeight;　　
		    }　
		}　　　　
		scrollHeight = (bodyScrollHeight - documentScrollHeight > 0) ? bodyScrollHeight : documentScrollHeight;　　
		return scrollHeight;
	},
	//处理移动端还是PC端的事件
	mobileflag: function(Table, curPage, pageTotal, pageSize, total,boxname) {
		var _this = this;
		var mobile_flag = _this.isMobile(mobile_flag);
		//当为移动端时处理事件
		if(mobile_flag) {
			var startY = 0;
			const maxMove = 400;//效果
			var scroll = TAB$(_this.par.scrollName);
			var windowHeight = 0;
			var header = document.getElementsByTagName('header')[0].clientHeight;
			if(document.compatMode == "CSS1Compat") {　　　　
				windowHeight = document.documentElement.clientHeight - header;　　
			} else {　　　　
				windowHeight = document.body.clientHeight - header;　　
			}
				var backdrop = TABLAYER$('div');
			    backdrop.innerHTML = _this.par.mobBackdrop;
			    backdrop.className = 'backdrop';
			    Table.parentNode.appendChild(backdrop);
			scroll.addEventListener('touchstart', function(event) {
				var i=0;
				startY = event.changedTouches[0].clientY;
				var touch = event.targetTouches[0];
				startPos = {x:touch.pageX,y:touch.pageY,time:+new Date};    //取第一个touch的坐标值
				startcli=i++;
				//初始加载样式
			});
			 scroll.addEventListener('touchmove', function(e) {	
			  	const y = e.changedTouches[0].clientY - startY <= maxMove ? e.changedTouches[0].clientY - startY : maxMove;
				Table.style.transition = "none";
                Table.style.transform = 'translateY('+0.3*y+'px)';  // 阻尼系数0.3      
                var backdrop = document.body.querySelector(".backdrop");
                 if(backdrop!=null){
                 	backdrop.style.transition = "none";
	                backdrop.style.display="block";
	                backdrop.style.transform = 'translateY('+0.1*y+'px)';  // 阻尼系数0.1
                 }
               startcli;
			});
			scroll.addEventListener('touchend', function(event) {
				startcli;
			    Table.style.transition = 'transform .6s';
                Table.style.transform = 'translateY('+0+'px)';
                var transform = Table.style.transform || '';
                var transformY = transform.match(/translateY\(\s*(\d+)px\)/)[1];
                var duration = +new Date - startPos.time;    //滑动的持续时间
                if(Number(duration) > 300){ 
                   if(startcli==0){
		                if(transformY==0){	
		                    _this.scrollchange(Table,scroll, windowHeight, pageSize,pageTotal, event); 
		                   startcli++;
		                }
	                 }
                }
                var backdrop = document.body.querySelector(".backdrop");
                if(backdrop!=null){
                	backdrop.style.transition = 'transform .6s';
                    backdrop.style.transform = 'translateY('+0+'px)';
                	_this.removeElement(backdrop);
                }
			});
		} else {
            return false;
		}
	},
	scrollchange: function(Table,scroll, windowHeight, pageSize,pageTotal, obj) {
		var nameedit,
			edit = TAB$(_this.par.edit);
		edit ? nameedit = TAB$(_this.par.edit) : nameedit = Table.getElementsByTagName('tbody')[0];
		var getScrollTop = scroll.scrollTop;
		var getScrollHeight = _this.getScrollHeight(getScrollHeight);
		if(getScrollTop + windowHeight == getScrollHeight) {
			var boxname = _this.par.CustomName;
			var edit = _this.getByClass(nameedit.parentNode, boxname);
			var sm = Math.ceil(edit.length / pageSize);
			    sm++;
			if(sm<=pageTotal){
				var condition = JSON.parse(window.sessionStorage.getItem("searchname")); //获取session存储名
				_this.nextPage(null, sm, pageTotal, null, obj,condition);	
			}
		}else if(getScrollTop==0){
			var curPage=_this.par.curPage;
            _this.par.Callback(Table, _this, curPage, pageSize, name);//执行回调的方法
            var pro = document.body.querySelector(".mobile_prompt");
            pro!=null?_this.removeElement(pro):'';  
		}
	},
	//回调table数据的方法
	callbackf: function(Table, obj, other) {
		var condition = JSON.parse(window.sessionStorage.getItem("searchname")); //获取session存储名
		var name;
		var size = obj.par.pageSize;
		var pageSize = size[0];
		var curPage = obj.par.curPage;
		if(condition != null) {
			var value = condition[0].sname;
			var type = condition[0].status;
			obj.par.SearchEvent(obj, value, curPage, pageSize, null, type);
		} else {
			obj.par.Callback(Table, obj, curPage, pageSize, name);//执行回调的方法
		}
		obj.ajaxObject(obj);
		obj.Selectedbtnmethod(other, Table, obj, curPage, pageSize);
	},
	//设置一个提示框，编辑提示框，texts为提示文本 ，time为显示时间秒单位
	PromptBox: function(texts, time, status) {
		var _this = this;
		var b = document.body.querySelector(".box_Bullet");
		if(!b) {
			var box = document.createElement("div");
			document.body.appendChild(box).className = "box_Bullet";
			var boxcss = document.querySelector(".box_Bullet");
			var winWidth = window.innerWidth;
			document.body.appendChild(box).innerHTML = texts;
			var wblank = winWidth - boxcss.offsetWidth;
			box.style.cssText = "width:" + boxcss.offsetWidth + "px" + "; left:" + (wblank / 2) + "px" + ";" +
				"margin-top:" + (-boxcss.offsetHeight / 2) + "px";

			var int = setInterval(function() {
				time--;
				_this.endclearInterval(time, box, int);
			}, 1000);

		} else if(status == true) {
			document.body.removeChild(b);
			return;
		}
	},
	endclearInterval: function(time, box, int) {
		time > 0 ? time-- : clearInterval(int);
		if(time == 0) {
			clearInterval(int);
			document.body.removeChild(box);
			return;
		}
	},
	//声明ajax方法.，用于判断浏览器是否支持ajax
	ajaxObject: function(obj) {
		var xmlHttp;
		try {
			// Firefox, Opera 8.0+, Safari
			xmlHttp = new XMLHttpRequest();
		} catch(e) {
			// Internet Explorer
			try {
				xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
			} catch(e) {
				try {
					xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
				} catch(e) {
					obj.PromptBox('您的浏览器不支持AJAX', 2, false);
					return false;
				}
			}
		}
		return xmlHttp;
	},
	//Get请求
	ajaxGet: function(url, success, curPage, pageSize, obj, name) {
		var _this = this;
		var template = _this.par.template;
		var start = 0,
			end = 0;
		var Table = TAB$(_this.par.TableName);
		var ajax = _this.ajaxObject();
		ajax.open("get", url, true);
		if(ajax) {
			_this.PromptBox(_this.par.loading, 0, true);
		}
		ajax.onreadystatechange = function() {
			if(ajax.readyState == 4) {
				if(ajax.status == 200) {
					var json = ajax.responseText; //获取到json字符串，还需解析
					if(json == "202") {
						_this.PromptBox(_this.par.SuccessPrompt, 2, false);
						var condition = JSON.parse(window.sessionStorage.getItem("searchname")); //获取session存储名
						if(condition != null) {
							var value = condition[0].sname;
							var type = condition[0].status;
							_this.par.SearchEvent(Table, value, curPage, pageSize, null, type);
						} else {
							_this.par.Callback(Table, _this, curPage, pageSize, name);//执行回调的方法
						}
						_this.PromptBox(_this.par.SuccessPrompt, 0, true);
						return;
					} else if(json == "101") {
						_this.PromptBox(_this.par.ErrorMessage, 2, false);
						_this.PromptBox(null, 0, true);
						return;
					} else {
						var JsonStr = JSON.parse(json); //将字符串转换为json数组
						if(template == true) {
							if(success == "select") {
								_this.SelectMethod(Table, JsonStr, _this, curPage);
							} else if(name == 'Excel') {
								_this.Excelentire(Table, _this, JsonStr, name); //用于执行Excel导出功能
							} else {
								_this.contenthtml(Table, JsonStr, _this, curPage, pageSize, obj, name);
							}
						}
						_this.PromptBox(null, 0, true);
						return;
					}
				} else {
					_this.PromptBox("HTTP请求错误！错误码：" + ajax.status, 2, false);
				}
				return
			}
		};
		ajax.send();
	},
	//Post请求
	ajaxPost: function(url, data, evnet, layer) {
		var _this = this;
		var ajax = _this.ajaxObject();
		ajax.open("post", url, true);
		ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
		ajax.onreadystatechange = function() {
			if(ajax.readyState == 4) {
				if(ajax.status == 200) {
					_this.statusname(ajax.responseText, _this, evnet, layer);
				} else {
					_this.PromptBox("HTTP请求错误！错误码：" + ajax.status, 2, false);
					return;
				}
			} else {
				return
			}
		}
		typeof(data) != "undefined" ? ajax.send(data): '';
	},
	//状态类型判断
	statusname: function(status, set, evnet, layer) {
		//判断是的保存按钮操作
		if(evnet.name == "SaveEvent") {
			if(status == "101") {
				set.PromptBox(set.par.ErrorMessage, 2, false);
			} else if(status == "202") {
				//保存信息返回修改后的信息，不刷新界面，需用户主动刷新，减少服务器请求，查看修改后的信息
				set.PromptBox(set.par.SuccessPrompt, 2);
				var edit = set.getByClass(layer.parentNode, 'table-edit');
				for(var i = 0; i < edit.length; i++) {
					var selected = edit[i].getElementsByTagName("select")[0]; // 选中索引
					if(selected) {
						var index = selected.selectedIndex; // 选中索引
						var text = selected.options[index].innerHTML;
					} else {
						var text = edit[i].getElementsByTagName("input")[0].value;
					}
					var muster = _this.getByClass(edit[i], 'radio');
					if(muster != 0) {
						for(var c = 0; c < muster.length; c++) {
							var n = muster[c].getElementsByTagName("input")[0].getAttribute("data-name");
							if(muster[c].getElementsByTagName("input")[0].checked == true) {
								var text = n;
							}
						}
					}
					edit[i].innerHTML = text;
				}
				evnet.innerText = "修改";
				evnet.name = 'modifyEvent';
			}
		} else {
			if(status == "101") {
				set.PromptBox(set.par.ErrorMessage, 2, false);
			} else if(status == "202") {
				set.PromptBox(set.par.SuccessPrompt, 2, false);
			}
		}
	},
	//session存储html
	sessionArrhtml: function(Table) {
		_this = this;
		var list,
			edit = TAB$(_this.par.edit);
		edit ? list = TAB$(_this.par.edit) : list = Table.getElementsByTagName('tbody')[0];
		var rota = _this.par.setItem;
		var sessionArr = _this.par.sessionArr; //声明新的数组
		var obj = {
			html: list.innerHTML
		};
		sessionArr.push(obj);
		var html = JSON.stringify(sessionArr);
		window.sessionStorage.setItem(rota, html); //保存存储名为menu

		//新建保存当前table
		var menu = 'Excel';
		var EsessionArr = _this.par.sessionArr; //声明新的数组
		var Excelhtml = {
			html: Table.innerHTML
		};
		EsessionArr.push(Excelhtml);
		var Ehtml = JSON.stringify(EsessionArr);
		window.sessionStorage.setItem(menu, Ehtml); //保存存储名为menu
	},
	//树状图数据结构重组方法
	treedata: function(oldArr, pid, nameedit) {
		var _this = this;
		var newArr = [];
		var size = oldArr.length;
		oldArr.myMap(function(item) {
			if(item.pid === pid) {
				var newgroup = {};
				for(var i = 0; i < size; i++) {
					var rows = nameedit.children;
					var cells = nameedit.rows[0].children;
					var tds = nameedit.rows[0].cells.length;
					for(var x = 0; x < tds; x++) {
						var keyvalue = rows[0].cells[x].getAttribute("data-value");
						var value = item[keyvalue];
						newgroup[keyvalue] = '';
						newgroup[keyvalue] += value;
					}
				}
				var child = _this.treedata(oldArr, item.id, nameedit);
				if(child.length > 0) {
					newgroup.child = child;
				}
				newArr.push(newgroup);
			}
		});
		return newArr;
	},
	//循环多级方式获取
	treelevel: function(treelist, _this, nameedit, JsonStr, BrowserInfo, rows) {
		for(var i = 0; i < treelist.length; i++) {
			if(mun != undefined) {
				var r = mun;
			} else {
				var r = i;
			}
			var clonedNode = rows[r].cloneNode(true); // 克隆节点
			nameedit.appendChild(clonedNode); //添加克隆的节点
			var tree = rows[r].getAttribute("data-tree"); //获取设置树状图参数
			var cells = nameedit.rows[r].children;
			//树状图处理
			if(tree == "tree") { //判断
				_this.addClass(rows[r], 'father');
				//var id = document.createAttribute("data-id");
				//id.nodeValue = treelist[i].id;
				//rows[r].setAttributeNode(id);
				if(treelist[i].child != null) {
					var child = treelist[i].child.length;
				} else {
					var child = 0;
				}
				if(child > 0) {
					var Site = _this.par.treeArrowSite;
					var tds = cells.length;
					for(var x = 0; x < tds; x++) {
						var Child = cells[x];
						_this.stencil(nameedit, rows[i], JsonStr, tds, treelist[i], r, Child, x, BrowserInfo);
					}
					var level = treelist[i].child;
					if(level != null) {
						var mun = r;
						mun++;
						for(var s = 0; s < level.length; s++) {
							var clonedNode = rows[mun].cloneNode(true); // 克隆节点
							nameedit.appendChild(clonedNode); //添加克隆的节点
							var tree = rows[mun].getAttribute("data-tree"); //获取设置树状图参数
							var cells = nameedit.rows[mun].children;
							_this.addClass(rows[mun], 'child' + treelist[i].id + ' sys-childstyle');
							var tds = cells.length;
							if(level[s].child != null) {
								var childsl = level[s].child.length;
							} else {
								var childsl = 0;
							}
							if(childsl > 0) {
								//编辑子级方法,最多三级
								_this.addClass(rows[mun], 'father');
								for(var x = 0; x < tds; x++) {
									var Child = cells[x];
									_this.stencil(nameedit, rows[mun], JsonStr, tds, level[s], mun, Child, x, BrowserInfo);
								}
								nameedit.rows[mun].cells[Site].insertAdjacentHTML('afterbegin', "<span class='sys-child icon-arrow plus' name='plusclick' data-id='" + level[s].id + "' data-fid='" + treelist[i].id + "'></span>");
								levels = level[s].child;
								if(levels != null) {
									for(var l = 0; l < levels.length; l++) {
										mun++;
										_this.TreeChildModule(nameedit, treelist, level, levels, BrowserInfo, i, l, mun, JsonStr, rows);
									}
								}
							} else {
								for(var x = 0; x < tds; x++) {
									var Child = cells[x];
									_this.stencil(nameedit, rows[mun], JsonStr, tds, level[s], mun, Child, x, BrowserInfo);
								}
								var Site = _this.par.treeArrowSite;
								nameedit.rows[mun].cells[Site].insertAdjacentHTML('afterbegin', "<span class='icon-arrow'></span>");
							}
							mun++;
						}
					}
					nameedit.rows[r].cells[Site].insertAdjacentHTML('afterbegin', "<span class='icon-arrow plus' name='plusclick' data-id='" + treelist[i].id + "'></span>");
				} else {
					var tds = cells.length;
					for(var x = 0; x < tds; x++) {
						var Child = cells[x];
						_this.stencil(nameedit, rows[r], JsonStr, tds, treelist[i], r, Child, x, BrowserInfo);

					}
					var Site = _this.par.treeArrowSite;
					nameedit.rows[r].cells[Site].insertAdjacentHTML('afterbegin', "<span class='icon-arrow'></span>");
				}
			}
			var a = 1; //起始条数
			var amount = a + mun; //每循环一次加1，直到数据为空为止结束
		}
		if(amount != (nameedit.rows.length)) {
			var ms = nameedit.rows.length;
			for(var a = ms - 1; a >= amount; a--) {
				_this.removeElement(nameedit.rows[a]);
			}
		}
	},
	TreeChildModule: function(nameedit, treelist, level, levels, BrowserInfo, i, l, mun, JsonStr, rows) {
		var clonedNode = rows[mun].cloneNode(true); // 克隆节点
		nameedit.appendChild(clonedNode); //添加克隆的节点
		var tree = rows[mun].getAttribute("data-tree"); //获取设置树状图参数
		var cells = nameedit.rows[mun].children;
		var pid = document.createAttribute("data-pid");
		pid.nodeValue = level[0].id;
		rows[mun].cells[0].setAttributeNode(pid);
		_this.addClass(rows[mun], 'child' + treelist[i].id + ' sys-childstyle');
		var tds = cells.length;
		for(var x = 0; x < tds; x++) {
			var Child = cells[x];
			_this.stencil(nameedit, rows[mun], JsonStr, tds, levels[l], mun, Child, x, BrowserInfo);
		}
		var Site = _this.par.treeArrowSite;
		nameedit.rows[mun].cells[Site].insertAdjacentHTML('afterbegin', "<span class='icon-arrow third-level'></span>");
	},
	//模版
	contenthtml: function(Table, JsonStr, _this, curPage, pageSize, obj, name) {
		var nameedit,
			edit = TAB$(_this.par.edit);
		edit ? nameedit = TAB$(_this.par.edit) : nameedit = Table.getElementsByTagName('tbody')[0];
		var total = parseInt(JsonStr.total);
		var pageTotal = Math.ceil(total / pageSize);
		var rota = _this.par.setItem;
		var mode = _this.par.mode;
		var menu = JSON.parse(window.sessionStorage.getItem(rota));
		var tbody = document.createElement('tbody');
		var boxname = _this.par.CustomName;
		var prompt = "没有找到相关内容";
		modleprompt = "没有更多了";
		if(menu == null) {
			var time = 4;
			var int = setInterval(function() {
				_this.PromptBox("抱歉,浏览记录丢失,将从新刷新页面!", 2);
				time--;
				time > 0 ? time-- : clearInterval(int);
				if(time == 0) {
					clearInterval(int);
					window.location.reload();
					return;
				}
			}, 1000);
		} else {
			if(JsonStr.data != null) {
				var number = JsonStr.data.length;
				var oldArr = JsonStr.data;
				var s = navigator.userAgent.toLowerCase();
				var BrowserInfo = {
					IsIE: /*@cc_on!@*/ false,
					IsIE9Under: /*@cc_on!@*/ false && (parseInt(s.match(/msie (\d+)/)[1], 10) <= 9),
				};
				if(BrowserInfo.IsIE9Under) {
					edit ? nameedit.innerHTML = menu[0].html : nameedit.appendChild = menu[0].html; //获取session存储的内容导入table表格中  

				} else {
					if(obj) {
						if(obj.type != "touchend" && obj.type != "touchmove") {
							nameedit.innerHTML = menu[0].html; //获取session存储的内容导入表格中
							if(obj.name == "RefreshEvent") {
								var get = nameedit.parentNode.getElementsByTagName("span")[0];
								get ? get.remove() : '';
							}
						} else {
							nameedit.innerHTML += menu[0].html; //获取session存储的内容导入表格中   
						}
					} else {
						nameedit.innerHTML = menu[0].html; //获取session存储的内容导入表格中
					}
				}
				var status = _this.par.TreeStatus;
				if(status == true) {
					var pid = 0; //默认值
					var rows = nameedit.children;
					_this.treedata(oldArr, pid, nameedit);
					var treelist = _this.treedata(oldArr, pid, nameedit);
					_this.treelevel(treelist, _this, nameedit, JsonStr, BrowserInfo, rows);
					_this.BtnoperationMethod(Table, _this, curPage, pageSize, obj);
					_this.currentcheckbox(Table, _this, curPage, pageSize);

				} else if(status == false) {
					for(var i = 0; i < pageSize; i++) {
						var num;
						var li;
						number <= pageSize ? num = i : num = (curPage - 1) * pageSize + i;
						var Array = JsonStr.data[num];
						_this.par.mobile == true ? li = (curPage - 1) * pageSize + i : li = i;
						if(Array) {
							if(mode == "ul") {
								var rows = nameedit.getElementsByTagName("ul");
								var clonedNode = nameedit.children[li].cloneNode(true); // 克隆节点
								nameedit.appendChild(clonedNode); // 在父节点插入克隆的节点
								var tds = rows[li].getElementsByTagName("li");
								for(var x = 0; x < tds.length; x++) {
									var Child = tds[x];
									_this.stencil(nameedit, rows[i], JsonStr, tds.length, Array, i, Child, x, BrowserInfo);
								}
							} else if(mode == "table") {
								var rows = nameedit.children;
								if(BrowserInfo.IsIE9Under) {
									var clonedNode = rows[0].cloneNode(true); // 克隆节点
									nameedit.appendChild(clonedNode);
									var cells = nameedit.rows[0].children;
									var tds = cells.length;
									for(var x = 0; x < tds; x++) {
										var Child = cells[x];
										_this.stencil(nameedit, rows[i], JsonStr, tds, Array, i, Child, x, BrowserInfo);
									}
								} else {
									var clonedNode = nameedit.rows[i].cloneNode(true); // 克隆节点
									nameedit.appendChild(clonedNode); // 在父节点插入克隆的节点
									var tds = nameedit.rows[i].cells.length;
									for(var x = 0; x < tds; x++) {
										var Child = nameedit.rows[i].cells[x];
										_this.stencil(nameedit, rows[i], JsonStr, tds, Array, i, Child, x, BrowserInfo);
									}
								}
							} else if(mode == "templet") {
								var edit = _this.getByClass(nameedit.parentNode, boxname);
								var clonedNode = nameedit.children[li].cloneNode(true); // 克隆节点
								nameedit.appendChild(clonedNode); // 在父节点插入克隆的节点
								var K = _this.par.CustomKey;
								var Child = _this.getElementsByClassName(edit[li], K);
								for(var x = 0; x < Child.length; x++) {
									_this.stencil(nameedit, rows, JsonStr, Child.length, Array, i, Child[x], x, BrowserInfo);
								}
							}
							var a = 1; //起始条数
							var amount = a + li; //每循环一次加1，直到数据为空为止结束
						}
					}
				};
				if(mode == "ul") {
					if(amount != (nameedit.children.length)) {
						var ms = nameedit.children.length;
						for(var a = ms - 1; a >= amount; a--) {
							_this.removeElement(nameedit.children[a]);
						}
					}
					if(_this.par.mobile == true) {
						if(number < pageSize) {
							_this.prompt(nameedit, modleprompt, JsonStr.data, obj);
						}
					}
				} else if(mode == "table") {
					var rows = nameedit.getElementsByTagName("tr");
					var Child = nameedit.rows[amount]; //设置最后一条数据
					//nameedit.removeChild(Child); //删除起始html样式
					if(amount != (nameedit.rows.length)) {
						var ms = nameedit.rows.length;
						for(var a = ms - 1; a >= amount; a--) {
							_this.removeElement(nameedit.rows[a]);
						}
					}
					_this.BtnoperationMethod(Table, _this, curPage, pageSize, obj);
					_this.currentcheckbox(Table, _this, curPage, pageSize);

				} else if(mode == "templet") {
					if(amount != (nameedit.children.length)) {
						var edit = _this.getByClass(nameedit.parentNode, boxname);
						var Child = edit[amount]; //设置最后一条数据
						_this.removeElement(Child);
					}
					if(_this.par.mobile == true) {
						if(number < pageSize) {
							_this.prompt(nameedit, modleprompt, JsonStr.data, obj);
						}
					}
				}
				if(_this.par.mobile == true) {
				    _this.mobileflag(Table, curPage, pageTotal, pageSize, total,boxname);
			    } else {
				    _this.pageTableMethod(null, curPage, pageTotal, pageSize, total, name);
			    }
			} else {
				if(mode == "ul") {
					if(_this.par.mobile == true) {
						_this.prompt(nameedit, modleprompt, JsonStr.data, obj);
					} else {
						nameedit.innerHTML = '<span class="prompt mobile_prompt">' + prompt + '</span>';
					}
				} else if(mode == "table") {
					var tds = nameedit.rows[0].cells.length;
					nameedit.innerHTML = '<td colspan="' + tds + '" class="mode_prompt">' + prompt + '</td>';
				}
			}
		}
	},
	prompt: function(nameedit, modleprompt, data, obj) {
		var _this = this;
		//var get = nameedit.parentNode.getElementsByTagName("span")[0];
		var get =_this.hasClass(nameedit.parentNode,'prompt');
		get ? _this.removeElement(get) : '';
		if(data != null) {
			nameedit.parentNode.innerHTML += '<span class="prompt mobile_prompt">' + modleprompt + '</span>';
		} else {
			if(obj.name == "searchEvent") {
				nameedit.innerHTML = ""; //为空时清除已有列表内容
				nameedit.parentNode.innerHTML += '<span class="prompt mobile_prompt">' + modleprompt + '</span>'; //返回提示信息
			} else {
				nameedit.parentNode.innerHTML += '<span class="prompt mobile_prompt">' + modleprompt + '</span>';
			}
		}
	},
	//获取内容模版方法
	stencil: function(nameedit, rows, JsonStr, tds, Array, i, Child, x, BrowserInfo) {
		var _this = this;
		var keyvalue = Child.getAttribute("data-value");
		var formatname = Child.getAttribute("data-format"); //格式
		var defaults = Child.getAttribute("data-default"); //格式
		var btn = Child.getAttribute("data-button"); //设置起始按钮
		var url = Child.getAttribute("data-url"); //地址		
		var dates = Array[keyvalue];
		if(formatname == 'time') {
			var format = _this.par.timeFormat;
			var value = _this.formatDate(format, dates);
		} else if(formatname == 'checkbox') {
			var ArrayString = Child.getAttribute("data-Array");
			if(ArrayString) {
				var result = ArrayString.split(",");
				var newarr = []; //声明一个数组
				for(var n = 0; n < result.length; n++) {
					var newgroup = {
						id: n,
						cname: result[n]
					};
					newarr.push(newgroup); //从新整合数组 
				} //对数组进行判断	
				for(var c = 0; c < newarr.length; c++) {
					if(Array[keyvalue] == newarr[c].id) {
						var value = newarr[c].cname;
					} else {
						Child.innerHTML = "无";
					}
				};
				
			} else {
				var value = "<label class='checkbox radio'><input name='checkbox' data-name='checkbox'  type='checkbox' value='" + Array[keyvalue] + "' class='ace'><span class='lbl'></span></label>"
			}
		} else if(formatname == "img") {
			var formatname = Child.getAttribute("data-Array"); //参数
			var value = '<img src="' + formatname + Array[keyvalue] + '" class="imgset" onerror="this.src=' + "'" + formatname + _this.par.defaultimg + "'" + ',this.onerror=null "/>';
		} else if(formatname == "select") {
			var value = "";
			var name = _this.par.SelectName; //键值名称
			var selectdata = Array[keyvalue]; //根据当前键值名称获取指定下拉值名称
			if(selectdata[name] != null) {
				value = selectdata[name];
				//var svalue = Array[keyvalue];
				//for(var s= 0; s < selectdata.length; s++){
				//	  var selname=selectdata[s];
				//	  var ov=selname[keyvalue];
				//	  if(svalue==ov){
				//		 value = selname.name;
				//	  }		
				//}
			} else {
				value = "无";
			}
		} else {
			var value = Array[keyvalue];
		}
		if(btn == "btn") {
			if(x == (tds - 1)) {
				var mode = _this.par.mode;
				if(mode == "table") {
					if(BrowserInfo.IsIE9Under) {
						var s = nameedit.rows[0].children[tds - 1];
					} else {
						var s = nameedit.rows[i].cells[tds - 1];
					}
					var btn = s.getElementsByTagName("button") || s.getElementsByTagName("a"); //获取按钮
					for(var b = 0; b < btn.length; b++) {
						var atr = document.createAttribute("data-id");
						atr.nodeValue = value;
						btn[b].setAttributeNode(atr);
					}
				} else if(mode == "ul") {
                          return false;
				}
			}
		} else if(url == "address") {
			if(Child.getAttribute('data-href') != null) {
				var herf = Child.getAttribute('data-href');
				Child.href = herf + value;
				Child.removeAttribute("data-href");
			} else if(Child.getAttribute('data-click') != null) {
				var herf = Child.getAttribute('data-click');
				var name = herf.replace(")", "," + value + ")");
				Child.setAttribute('onclick', name);
				Child.removeAttribute("data-click");
			}
		} else {
			if(keyvalue) {
				Array[keyvalue] ? Child.innerHTML = value : Child.innerHTML = "无";
				//Child.removeAttribute("data-Array");
			}
		}
	},
	//时间戳转换
	formatDate: function(format, date) {
		if(typeof date === "string") {
			var mts = date.match(/(\/Date(\d+)\/)/);
			if(mts && mts.length >= 3) {
				date = parseInt(mts[2]);
			}
		}
		date = new Date(parseInt(date * 1000));
		if(!date || date.toUTCString() == "Invalid Date") {
			return "";
		}
		var map = {
			"M": date.getMonth() + 1, //月份
			"d": date.getDate(), //日
			"h": date.getHours(), //小时
			"m": date.getMinutes(), //分
			"s": date.getSeconds(), //秒
			"q": Math.floor((date.getMonth() + 3) / 3), //季度
			"S": date.getMilliseconds() //毫秒
		};
		format = format.replace(/([yMdhmsqS])+/g, function(all, t) {
			var v = map[t];
			if(v !== undefined) {
				if(all.length > 1) {
					v = '0' + v;
					v = v.substr(v.length - 2);
				}
				return v;
			} else if(t === 'y') {
				return(date.getFullYear() + '').substr(4 - all.length);
			}
			return all;
		});
		return format;
	},
	// table以外层按钮操作方法
	Selectedbtnmethod: function(other, Table, obj, curPage, pageSize) {
		if(other) {
			var btn = other.getElementsByTagName("a") || other.getElementsByTagName("button");
			for(var i = 0; i < btn.length; i++) {
				btn[i].onclick = function(e) {
					var Table = TAB$(obj.par.TableName);
					if(this.name == "DeleteCheckbox") {
						//判断是否存在checkbox选中栏目，
						var checkbox = name$('checkbox');
						var trm = Table.rows.length;
						var batchDelete = "";
						for(var x = Table.rows.length - 1; x >= 1; x--) {
							if(checkbox[x].checked == true) {
								var id = checkbox[x].value;
								var keyname = checkbox[x].getAttribute("data-name");
								batchDelete += id + ",";
								var remove = checkbox[x].parentNode.parentNode.parentNode;
								var trm = Table.rows.length - 1;
							}
						};
						if(Table.rows.length == trm) {
							obj.PromptBox("请选择你要删除的信息！", 2, false);
						} else {
							batchDelete = batchDelete.substring(0, batchDelete.lastIndexOf(','));
							obj.par.CheckboxDeleteEvent(obj, batchDelete, curPage, pageSize);
						}
					} else if(this.name == "searchEvent") {
						    var formData = "";
							window.sessionStorage.removeItem("searchname");
                            var term=name$("searchText");
                            var newgroup = {};//声明一个对象集合
                            var newarr=[];
                                for(var s = 0; s < term.length; s++){
	                             	var keyvalue = term[s].getAttribute("data-term");
	                             	var v = term[s].value;
	                             	newgroup[keyvalue]="";
	                             	formData += keyvalue + "=" + v + "&";
	                             	newgroup[keyvalue] += v;
                                }
						if(v) {                         
							obj.par.SearchEvent(obj, formData, curPage, pageSize, this, newarr);
							//编辑保存查询结果到session中,用于执行刷新界面时的数据查询
							var rota = "searchname"; 
							var objs = {
								sname: formData,
								status: "searchText"
							};
							newarr.push(objs); //从新整合数组
							var html = JSON.stringify(newarr);
							window.sessionStorage.setItem(rota, html); //保存存储名为searchname的session
						} else {
							obj.PromptBox("请输入查询关键字！", 2, false);
						}
						//删除我提示文本内容
						var pro = document.body.querySelector(".mobile_prompt");
                        pro!=null?obj.removeElement(pro):'';  
			 			
					} else if(this.name == "RefreshEvent") {
						var condition = JSON.parse(window.sessionStorage.getItem("searchname")); //获取session存储名
						//执行刷新当前table数据请求		
						if(condition != null) {
							var value = condition[0].sname;
							var type = condition[0].status;
							obj.par.SearchEvent(obj, value, curPage, pageSize, null, type);
						} else {
							obj.par.Callback(Table, obj, curPage, pageSize, this);
						}
					}else if(this.name=="EntireEvent"){
						//刷新全部
						sessionStorage.removeItem("searchname");//删除指定session数组
						obj.par.Callback(Table, obj, curPage, pageSize, this);
						
					}else if(this.name == "ExcelEvent") {
						var name = this.getAttribute("data-name"); //获表格名称
						var Table = obj.par.TableName; //指定导出区域
						//Excel导出功能
						var idTmr;
						var explorer = obj.BrowserSpot(explorer);
						if(explorer == "ie") {
							var oXL = new ActiveXObject("Excel.Application");
							var oWB = oXL.Workbooks.Add();
							var xlsheet = oWB.Worksheets(1);
							var sel = document.body.createTextRange();
							sel.moveToElementText(Table);
							sel.select();
							sel.execCommand("Copy");
							xlsheet.Paste();
							oXL.Visible = true;
							try {
								var fname = oXL.Application.GetSaveAsFilename("Excel.xls", "Excel Spreadsheets (*.xls), *.xls");
							} catch(e) {
								print("Nested catch caught " + e);
							} finally {
								oWB.SaveAs(fname);
								oWB.Close(savechanges = false);
								oXL.Quit();
								oXL = null;
								idTmr = window.setInterval(obj.Cleanup(), 1);
							}
						} else {
							obj.tableToExcel(Table, name, obj);
						}
					}else if(this.name == "ExcelEntire") {
						var mode = 'Excel';
						obj.par.ExceldData(obj, Table, mode);

					}
				};
			};
		}
	},
	/*****************设置导出全部数据*************************/
	Excelentire: function(Table, obj, JsonStr, mode) {
		var rota = 'Excel';
		var menu = JSON.parse(window.sessionStorage.getItem(rota)); //获取session存储名
		var BrowserInfo = {
			IsIE: /*@cc_on!@*/ false,
			IsIE9Under: /*@cc_on!@*/ false && (parseInt(s.match(/msie (\d+)/)[1], 10) <= 9),
		};
		var newtable;
		newtable = TABLAYER$('table');
		newtable.id = 'Exceltable';
		document.body.appendChild(newtable);
		//newtable.style.cssText = "display:none;";
		if(BrowserInfo.IsIE9Under) {
			edit ? TAB$('Exceltable').innerHTML = menu[1].html : TAB$('Exceltable').appendChild = menu[1].html; //获取session存储的内容导入table表格中  
		} else {
			TAB$('Exceltable').innerHTML = menu[1].html; //获取session存储的内容导入表格中
		}
		var nameedit = TAB$('Exceltable').getElementsByTagName('tbody')[0];
		var amount = parseInt(JsonStr.length); //获取数据数量
		if(JsonStr != null) {
			var newarr = []; //声明新的数组
			for(var i = 0; i < amount; i++) {
				var rows = nameedit.children;
				var li;
				if(BrowserInfo.IsIE9Under) {
					var clonedNode = rows[0].cloneNode(true); // 克隆节点
					nameedit.appendChild(clonedNode);
					var cells = nameedit.rows[i].children;
					var tds = cells.length;
					for(var x = 0; x < tds; x++) {
						var Child = cells[x];
						obj.stencil(nameedit, rows[i], JsonStr, tds, JsonStr[i], i, Child, x, BrowserInfo);
					}
				} else {
					var clonedNode = nameedit.rows[0].cloneNode(true); // 克隆节点
					nameedit.appendChild(clonedNode); // 在父节点插入克隆的节点
					var tds = nameedit.rows[i].cells.length;
					for(var x = 0; x < tds; x++) {
						var Child = nameedit.rows[i].cells[x];
						obj.stencil(nameedit, rows[i], JsonStr, tds, JsonStr[i], i, Child, x, BrowserInfo);
					}
				}
				var a = 1; //起始条数
				var total = a + i; //每循环一次加1，直到数据为空为止结束
			}
			/*************删除不必要的内容************/
			for(var x = 0; x < nameedit.rows.length; x++) {
				var z = nameedit.rows[x].cells.length;
				obj.removeElement(nameedit.rows[x].cells[z - 1]);
				obj.removeElement(nameedit.rows[x].cells[0]);
			}
			var z = newtable.rows[0].cells.length;
			obj.removeElement(newtable.rows[0].cells[z - 1]);
			obj.removeElement(newtable.rows[0].cells[0]);
			var arry = {
				htmls: newtable.innerHTML
			};
			newarr.push(arry); //从新整合数组 
			var htmlz = JSON.stringify(newarr);
			window.sessionStorage.setItem(rota, htmlz); //保存存储名为menu
			obj.removeElement(newtable);
			var li = JSON.parse(window.sessionStorage.getItem(rota)); //获取session存储名
			//Excel导出功能
			var idTmr;
			var explorer = obj.BrowserSpot(explorer);
			if(explorer == "ie") {
				var oXL = new ActiveXObject("Excel.Application");
				var oWB = oXL.Workbooks.Add();
				var xlsheet = oWB.Worksheets(1);
				var sel = document.body.createTextRange();
				sel.moveToElementText(newtable);
				sel.select();
				sel.execCommand("Copy");
				xlsheet.Paste();
				oXL.Visible = true;
				try {
					var fname = oXL.Application.GetSaveAsFilename("Excel.xls", "Excel Spreadsheets (*.xls), *.xls");
				} catch(e) {
					print("Nested catch caught " + e);
				} finally {
					oWB.SaveAs(fname);
					oWB.Close(savechanges = false);
					oXL.Quit();
					oXL = null;
					idTmr = window.setInterval(obj.Cleanup(), 1);
				}
			} else {
				var html = li[0].htmls;
				var uri = 'data:application/vnd.ms-excel;base64,',
					         template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"' +                   'xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>'                   + '<x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets>'                   + '</x:ExcelWorkbook></xml><![endif]-->' +                   ' <style type="text/css">' +                   '.table{' +                   ' border-collapse:collapse;' +                   ' border:thin solid #999; ' +                   '}' +                   '.table_striped thead th{' +                  'color: #707070;' +
					' background: #f2f2f2;' +
					'background-image: -webkit-gradient(linear,left 0,left 100%,from(#f8f8f8),to(#ececec));' +
					'background-image: -webkit-linear-gradient(top,#f8f8f8,0%,#ececec,100%);' +
					'background-image: -moz-linear-gradient(top,#f8f8f8 0,#ececec 100%);' +
					'background-image: linear-gradient(to bottom,#f8f8f8 0,#ececec 100%);' +
					'background-repeat: repeat-x;' +
					'filter:progid:DXImageTransform.Microsoft.gradient(startColorstr="#fff8f8f8",endColorstr="#ffececec",GradientType=0);' +                   ' }' +                   ' .table td{' +                   '  border:thin solid #999;' +                   '  padding:2px 5px;' +                   '  text-align: center;' +                   ' }</style>' +                   '</head><body ><table class="gallery table table_list table_striped table-bordered border">{table}</table></body></html>',
					base64 = function(s) {
						return window.btoa(unescape(encodeURIComponent(s)))
					},
					format = function(s, c) {
						return s.replace(/{(\w+)}/g, function(m, p) {
							return c[p];
						})
					}
				if(!newtable.nodeType) newtable = newtable
				var ctx = {
					worksheet: 'name' || 'Worksheet',
					table: html
				}
				window.location.href = uri + base64(format(template, ctx));
				var BrowserInfo = {
					IsIE: /*@cc_on!@*/ false,
					IsIE9Under: /*@cc_on!@*/ false && (parseInt(s.match(/msie (\d+)/)[1], 10) <= 9),
				};
			}
		}
	},
	/**
	 * 设置拷贝需要下载的table表格，对拷贝的表格进行操作，然后下载修改的table表格
	 * 主要删除操作的内容区，只保留数据显示的区域，以使表格整洁，表格导出后样式不在显示
	 */
	ExcelHTML: function(html) {
		var _table = this;
		var list = TAB$(_table.par.TableName);
		var newtable;
		newtable = TABLAYER$('table');
		newtable.id = 'Newtable';
		document.body.appendChild(newtable);
		newtable.style.cssText = "display:none;";
		var copy = list.innerHTML;
		newtable.innerHTML = copy; //拷贝样式内容到新的table中
		for(var x = 1; x < newtable.rows.length; x++) {
			var z = newtable.rows[x].cells.length;
			_table.removeElement(newtable.rows[x].cells[z - 1]);
			_table.removeElement(newtable.rows[x].cells[0]);
			//newtable.rows[x].cells[z - 1].remove();
			//newtable.rows[x].cells[0].remove();
		}
		var z = newtable.rows[0].cells.length;
		_table.removeElement(newtable.rows[0].cells[z - 1]);
		_table.removeElement(newtable.rows[0].cells[0]);
		//newtable.rows[0].cells[z - 1].remove();
		//newtable.rows[0].cells[0].remove();
		var html = newtable.innerHTML;
		return html; //对新拷贝的表格进行处理获取内容
	},
	tableToExcel: function(table, name, obj) {
		var html = obj.ExcelHTML(html);
		var uri = 'data:application/vnd.ms-excel;base64,',
			         template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"' +                   'xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>'                   + '<x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets>'                   + '</x:ExcelWorkbook></xml><![endif]-->' +                   ' <style type="text/css">' +                   '.table{' +                   ' border-collapse:collapse;' +                   ' border:thin solid #999; ' +                   '}' +                   '.table_striped thead th{' +                  'color: #707070;' +
			' background: #f2f2f2;' +
			'background-image: -webkit-gradient(linear,left 0,left 100%,from(#f8f8f8),to(#ececec));' +
			'background-image: -webkit-linear-gradient(top,#f8f8f8,0%,#ececec,100%);' +
			'background-image: -moz-linear-gradient(top,#f8f8f8 0,#ececec 100%);' +
			'background-image: linear-gradient(to bottom,#f8f8f8 0,#ececec 100%);' +
			'background-repeat: repeat-x;' +
			'filter:progid:DXImageTransform.Microsoft.gradient(startColorstr="#fff8f8f8",endColorstr="#ffececec",GradientType=0);' +                   ' }' +                   ' .table td{' +                   '  border:thin solid #999;' +                   '  padding:2px 5px;' +                   '  text-align: center;' +                   ' }</style>' +                   '</head><body ><table class="gallery table table_list table_striped table-bordered border">{table}</table></body></html>',
			base64 = function(s) {
				return window.btoa(unescape(encodeURIComponent(s)))
			},
			format = function(s, c) {
				return s.replace(/{(\w+)}/g, function(m, p) {
					return c[p];
				})
			}
		if(!table.nodeType) table = document.getElementById(table)
		var ctx = {
			worksheet: name || 'Worksheet',
			table: html
		}
		window.location.href = uri + base64(format(template, ctx));
		var BrowserInfo = {
			IsIE: /*@cc_on!@*/ false,
			IsIE9Under: /*@cc_on!@*/ false && (parseInt(s.match(/msie (\d+)/)[1], 10) <= 9),
		};
		BrowserInfo.IsIE9Under ? TAB$("Newtable").removeNode() : TAB$("Newtable").remove();
	},
	Cleanup: function() {
		window.clearInterval(idTmr);
		CollectGarbage();
	},
	BrowserSpot: function(explorer) {
		var explorer = window.navigator.userAgent;
		//ie
		if(explorer.indexOf("MSIE") >= 0) {
			return 'ie';
		}
		//firefox
		else if(explorer.indexOf("Firefox") >= 0) {
			return 'Firefox';
		}
		//Chrome
		else if(explorer.indexOf("Chrome") >= 0) {
			return 'Chrome';
		}
		//Opera
		else if(explorer.indexOf("Opera") >= 0) {
			return 'Opera';
		}
		//Safari
		else if(explorer.indexOf("Safari") >= 0) {
			return 'Safari';
		}
		return explorer;
	},
	//按钮操作事件方法
	BtnoperationMethod: function(Table, obj, curPage, pageSize) {
		for(var x = 1; x < Table.rows.length; x++) {
			for(var c = 0; c < Table.rows[x].cells.length; c++) {
				var btn = Table.rows[x].cells[c].getElementsByTagName("button") || Table.rows[x].cells[c].getElementsByTagName("a"); //获取按钮
				Table.rows[x].cells[c].onclick = function(e) {
					var evt = e || window.event;
					var tar = evt.target || evt.srcElement;
					var on = tar.tagName.toLowerCase();
					if(on == "button" || on == "span") {
						var name = tar.getAttribute('name');
						var id = tar.getAttribute("data-id");
						addLoadListener(obj.btnclick);
						obj.btnclick(Table, id, this, name, tar, curPage, pageSize);
					}
				}
			}
		}
	},
	//下拉选择操作
	SelectMethod: function(Table, data, _this, obj) {
		var keyvalue = obj.getAttribute("data-value");
		var option = "";
		for(var i = 0; i < data.length; i++) {
			option += "<option value=" + data[i].id + ">" + data[i].name + "</option>";
		}
		obj.innerHTML = "<select class='select' name=" + keyvalue + ">" + option + "</select>";
	},
	//执行事件方法
	btnclick: function(Table, id, obj, name, e, curPage, pageSize) {
		var _this = this;
		if(name == 'deleteEvent') {
			_this.par.DeleteEvent(obj, _this, id, curPage, pageSize); //删除操作	
			return;
		} else if(name == 'modifyEvent') {
			_this.ModifyMethod(Table, id, obj, name, e, id);
			_this.par.ModifyEvent(obj, _this, id); //修改操作
			return;
		} else if(name == 'detailedEvent') {
			_this.par.DetailedEvent(obj, _this, id, pageSize); //详细操作
			return;
		} else if(name == 'SaveEvent') {
			_this.SaveMethod(Table, id, obj, _this, e);
		} else if(name == 'plusclick') {
			var list = obj.parentNode.parentNode;
			var fid = e.getAttribute('data-fid');
			if(fid) {
				var child = "child" + fid + "";
			} else {
				var child = "child" + id + "";
			}
			var sl = _this.getElementsByClassName(list, child);
			var len = sl.length;
			var plusminu = function(i) {
				sl[i].style.display = "none";
				e.setAttribute('name', 'minusclick');
				_this.removeClass(e, 'plus');
				_this.addClass(e, 'minus');
			};
			for(var i = 0; i < len; i++) {
				if(fid) {
					var pid = sl[i].cells[0].getAttribute("data-pid");
					pid ? plusminu(i) : '';
				} else {
					plusminu(i);
				}
			}
			//隐藏	   
		} else if(name == 'minusclick') {
			var fid = obj.getAttribute('data-fid');
			var list = obj.parentNode.parentNode;
			var fid = e.getAttribute('data-fid');
			if(fid) {
				var child = "child" + fid + "";
			} else {
				var child = "child" + id + "";
			}
			var sl = _this.getElementsByClassName(list, child);
			var len = sl.length;
			var plusminu = function(i) {
				sl[i].style.display = "table-row";
				e.setAttribute('name', 'plusclick');
				_this.removeClass(e, 'minus');
				_this.addClass(e, 'plus');
			};
			for(var i = 0; i < len; i++) {
				if(fid) {
					var pid = sl[i].cells[0].getAttribute("data-pid");
					pid ? plusminu(i) : '';
				} else {
					plusminu(i);
				}
			}
			//显示				
		} else if(name == 'tree') {
			//父级全选操作 只用于tree树状图状态下使用
			var list = obj.parentNode; //父级
			var child = "child" + id + "";
			var sl = _this.getElementsByClassName(list, child);
			if(sl != 0) {
				for(var i = 0; i < sl.length; i++) {
					var checkbox = sl[i].cells[0].getElementsByTagName('input')[0];
					if(e) {
						if(e.checked == false) {
							checkbox ? checkbox.checked = false : '';
							_this.removeClass(sl[i], 'active');
							_this.removeClass(obj, 'active');
						} else {
							checkbox.checked = true;
							_this.addClass(obj, 'active');
							_this.addClass(sl[i], 'active');
						}
					}
				}
			} else {
				if(e.checked == false) {
					e.checked = true;
					_this.addClass(obj, 'active');
				} else {
					e.checked = false;
					_this.removeClass(obj, 'active');
				}
			}
		}
	},
	//执行修改信息操作方法
	ModifyMethod: function(Table, id, obj, name, e, id) {
		var _this = this; //声明调用数组集合
		var edit = _this.getByClass(obj.parentNode, 'table-edit');
		if(edit != 0) {
			for(var i = 0; i < edit.length; i++) {
				var keyvalue = edit[i].getAttribute("data-value");
				var keyname = edit[i].getAttribute("data-name");
				var ArrayString = edit[i].getAttribute("data-Array");
				var text = edit[i].innerText;
				if(keyname == "checkbox") {
					edit[i].innerHTML = ""; //清除内容
					var result = ArrayString.split(",");
					var newarr = []; //声明一个数组
					for(var n = 0; n < result.length; n++) {
						var newgroup = {
							id: n,
							name: result[n]
						};
						newarr.push(newgroup); //从新整合数组 
					} //对数组进行判断
					for(var c = 0; c < newarr.length; c++) {
						if(text == newarr[c].name) {
							edit[i].innerHTML += "<label class='radio'><input name='" + keyvalue + id +
								"' type='radio' checked='checked' data-name='" + newarr[c].name + "' value='" + c + "' class='ace'><span class='lbl'>" + newarr[c].name +
								"</span></label>"
						} else {
							edit[i].innerHTML += "<label class='radio'><input name='" + keyvalue + id + "' data-name='" + newarr[c].name + "'  type='radio' value='" + c +
								"' class='ace'><span class='lbl'>" + newarr[c].name + "</span></label>"
						}
					}
					//edit[i].removeAttribute("data-Array");
				} else if(keyname == "select") {
					edit[i].innerHTML = ""; //清除内容
					var aobj = edit[i];
					_this.par.SelectEvent(_this, aobj);

				} else {
					edit[i].innerHTML = "<input type='text' class='edit-text' value='" + text + "' name='" + keyvalue + "' />";
				}
			}
			e.innerText = "保存";
			e.name = 'SaveEvent';
		} else {
			_this.PromptBox("抱歉，不支持直接修改信息，请点击详细进行操作", 2, false);
		}
	},
	//执行保存的事件方法
	SaveMethod: function(Table, id, obj, _this, e) {
		var formData = "";
		var m = obj.parentNode.getElementsByTagName('td');
		for(var i = 0; i < m.length; i++) {
			var edit = _this.hasClass(m[i], 'table-edit');
			if(edit) {
				var keyvalue = m[i].getAttribute("data-value");
				var tagname = m[i].getElementsByTagName("input")[0] || m[i].getElementsByTagName("select")[0];
				var keyname = tagname.name;
				var muster = _this.getByClass(m[i], 'radio');
				if(muster != 0) {
					for(var c = 0; c < muster.length; c++) {
						var checkedname = name$(keyvalue + id)[c];
						if(checkedname.checked == true) {
							var text = name$(keyvalue + id)[c].value;
							keyname = keyvalue;
						}
					}
				} else {
					var tablevalue = m[i].getElementsByTagName("input")[0] || m[i].getElementsByTagName("select")[0];
					var text = tablevalue.value;
				}
				formData += keyname + "=" + text + "&";
				if(text == "") {
					_this.PromptBox("修改信息内容不能为空", 2, false);
					return false;
				}
			}
		}
		_this.par.SaveEvent(obj, _this, id, formData, e); //保存操作
	},
	//分页方法
	pageTableMethod: function(html, curPage, pageTotal, pageSize, total, name) {
		var that = this;
		var condition = JSON.parse(window.sessionStorage.getItem("searchname")); //获取session存储名
		var Table = TAB$(that.par.TableName);
		var amount = that.par.btnpageing;
		var pagination = TAB$(that.par.paginName);
		pageTotal == 0 ? pageTotal = 1 : ''; //默认数据为0时执行该方法
		if(pagination) {
			//分页
			var number = name$('page-number')[0];
			if(number) {
				var ul = number.parentNode;
				var pag = [];
				var modern = [];
				var pagset = [];
				var number = name$('page-number');
				var sets = that.par.pageSize;
				for(var i = 0; i < number.length; i++) {
					var pages = parseInt(number[i].getAttribute("data-pages"));
					modern.push(pages);
					//curPage=pages;
				}
				if(curPage < amount) {
					var ellipsis = number[0].parentNode.getElementsByTagName('span')[0];
					var jh = Math.min(amount, pageTotal);
					while(jh) {
						pag.unshift(jh--);
					}
					for(var s = 0; s < sets.length; s++) {
						var current;
						total == 0 ? current = 1 : current = 0;
						set = Math.ceil((total + current) / sets[s]);
						if(name != null) {
							if(pageTotal == set) {
								for(var i = number.length - 1; i >= 0; i--) {
									pag[i] != modern[i] ? that.removeElement(number[i]) : '';
									ellipsis ? that.removeElement(ellipsis) : '';
								}
								var next = name$('Next-page')[0];
								var last = name$('Pre-page')[0];
								that.lastPage(ul, curPage, html, last, condition); //上一页
								that.nextPage(ul, curPage, pageTotal, html, next, condition);
							}
						}
						that.finalPage(ul, curPage, pageTotal, pageSize, html);
					}
					for(var i = 0; i < pag.length; i++) {
						if(number.length <= amount) {
							if(pag[i] == modern[i]) {
								number[i].setAttribute("data-pages", pag[i]);
								number[i].innerHTML = pag[i];
								var ys = parseInt(number[i].innerHTML);
								if(ys == curPage) {
									that.addClass(number[i], 'active');
								} else {
									that.removeClass(number[i], 'active');
								}
							} else {

								var li = TABLAYER$('li');
								var atr = document.createAttribute("name");
								atr.nodeValue = "page-number";
								li.setAttributeNode(atr);
								var pages = document.createAttribute("data-pages");
								pages.nodeValue = pag[i];
								li.setAttributeNode(pages);
								li.innerHTML = pag[i];
								number[0].parentNode.appendChild(li);
							}
						} else {
							number[i].setAttribute("data-pages", pag[i]);
							number[i].innerHTML = pag[i];
							var ys = parseInt(number[i].innerHTML);
							if(ys == curPage) {
								that.addClass(number[i], 'active');
							} else {
								that.removeClass(number[i], 'active');
							}
						}
					}
					if(pageTotal > amount) {
						if(!ellipsis) {
							var span = TABLAYER$('span');
							that.addClass(span, 'ellipsis');
							span.innerHTML = '...';
							number[0].parentNode.appendChild(span);
							var next = TABLAYER$('li');
							var atr = document.createAttribute("name");
							atr.nodeValue = "page-number";
							next.setAttributeNode(atr);
							var pages = document.createAttribute("data-pages");
							pages.nodeValue = pageTotal;
							next.setAttributeNode(pages);
							next.innerHTML = pageTotal;
							that.removeClass(next, 'pages');
							that.addClass(next, 'mantissa');
							number[0].parentNode.appendChild(next);
						}
					}
					//对相同页面进行比，并删除其中一个相同值样式
					for(var i = 0; i < number.length - 1; i++) {
						var size = number[i].getAttribute('data-pages');
						for(var j = i + 1; j < number.length; j++) {
							var contrast = number[j].getAttribute('data-pages');
							if(size == contrast) {
								that.removeElement(number[i]);
								//number[i].remove();
							}
						}
					}
				} else {
					if(curPage > amount - 1) {
						var middle = (curPage - 1) - Math.floor(pageSize / 2),
							//从哪里开始
							i = amount;
						if(middle > pageTotal - pageSize) {
							middle = pageTotal - pageSize + 1;
						}
						while(i--) {
							pag.push(middle++);
						}
						//var classname = that.hasClass(number[amount], 'mantissa');
						//var last;
						// classname?last=parseInt(number[amount].getAttribute("data-pages")):'';
						for(var i = 0; i < number.length - 1; i++) {
							var current = parseInt(number[i].getAttribute("data-pages"));
							var ellipsis = number[i].parentNode.getElementsByTagName('span')[0];
							for(var S = 0; S < number.length; S++) {
								var index;
								var active = _this.hasClass(number[S], 'active');
								active ? index = parseInt(number[S].getAttribute("data-pages")) : '';
							}
							if(pageTotal - curPage > 1) {
								index > amount ? ellipsis.style.display = "none" : ''; //隐藏更多
								index == amount ? ellipsis.style.display = "inline" : ''; //显示更多
								var pages = parseInt(number[i].getAttribute("data-pages"));
								number[i].setAttribute("data-pages", pag[i]);
								number[i].innerHTML = pag[i];
							}
							var ys = parseInt(number[i].innerHTML);
							ys == curPage ? that.addClass(number[i], 'active') : that.removeClass(number[i], 'active');
						}
					} else {
						return;
					}
				}
			} else {
				that.firstPage(ul, curPage, html, pageTotal, pagination, pageSize); //首页
				that.lastPage(ul, curPage, html, null, pagination, pageSize, condition); //上一页
				var ul = pagination.appendChild(TABLAYER$('ul'));
				that.addClass(ul, 'Page-library');
				for(var p = 0; p < pageTotal; p++) {
					var li = TABLAYER$('li');
					var atr = document.createAttribute("name");
					atr.nodeValue = "page-number";
					li.setAttributeNode(atr);
					if(p == curPage - 1) {
						li.className += ' active';
					} else {
						that.addClass(li, 'pages');
						that.getPage(curPage);
					}
					li.innerHTML = p + 1;
					var pages = document.createAttribute("data-pages");
					pages.nodeValue = p + 1;
					li.setAttributeNode(pages);
					ul.appendChild(li);
				};
				var number = name$('page-number');
				for(var i = 0; i < number.length; i++) {
					if(pageTotal > amount + 1) {
						if(number.length == pageTotal) {
							var span = TABLAYER$('span');
							that.addClass(span, 'ellipsis');
							span.innerHTML = '...';
							ul.appendChild(span);
						}
					}
					for(var e = amount; e < number.length; e++) {
						_this.removeElement(number[e]);
					}
					li.innerHTML = pageTotal;
					that.removeClass(li, 'pages');
					that.addClass(li, 'mantissa');
					ul.appendChild(li);
				};
				var next = name$('Next-page')[0];
				//调用下一页
				that.nextPage(ul, curPage, pageTotal, html, next,condition);
				//调用尾页
				that.finalPage(ul, curPage, pageTotal, pageSize, html);
			}
			//是否显示总页数,每页个数,数据
			that.showPageTotal(ul, curPage, pageTotal, total, Table);
			//根据点击的页数分页
			for(var i = 0; i < number.length; i++) {
				if(number) {
					number[i].index = i;
					addLoadListener(that.pageonclick(number[i], number, number.parentNode, number[i], curPage, pageTotal, pageSize, that, html, Table));
				}
			}
		}
	},
	//分页点击
	pageonclick: function(event, number, ul, li, curPage, pageTotal, pageSize, obj, html, Table) {
		var Pre = name$('Pre-page')[0]; //设置
		var next = name$('Next-page')[0];
		var condition = JSON.parse(window.sessionStorage.getItem("searchname")); //获取session存储名
		//点击页数操作
		event.onclick = function(e) {
			obj.Paginations(ul, li, number, pageTotal, obj, e, curPage, pageSize, Table, html, Pre, next, condition);
		}
		//点击上一页操作
		Pre.onclick = function(e) {
			var disabled = obj.hasClass(e.target, 'disabled');
			if(!disabled) {
				obj.Paginations(ul, li, number, pageTotal, obj, e, curPage, pageSize, Table, html, Pre, next, condition);
			} else {
				obj.PromptBox("没有更多了!", 2);
			}
		}
		//点击下一页操作
		next.onclick = function(e) {
			var disabled = obj.hasClass(e.target, 'disabled');
			if(!disabled) {
				obj.Paginations(ul, li, number, pageTotal, obj, e, curPage, pageSize, Table, html, Pre, next, condition);
			} else {
				obj.PromptBox("没有更多了!", 2);
			}
		}
	},
	//根据点击事件操作
	Paginations: function(ul, li, number, pageTotal, obj, e, curPage, pageSize, Table, html, Pre, next, condition) {
		var amount = obj.par.btnpageing;
		var quantity = number.length;
		for(var S = 0; S < number.length; S++) {
			var index;
			var active = _this.hasClass(number[S], 'active');
			active ? index = S : '';
		}
		if(e.target == next) {
			index++;
		} else if(e.target == Pre) {
			index--;

		} else {
			index = e.target.index;
		}
		for(var n = 0; n < number.length; n++) {
			var classname = obj.hasClass(li, 'mantissa');
			if(classname) {
				var u = parseInt(li.getAttribute("data-pages"));
			}
			var curPage = parseInt(number[index].getAttribute("data-pages"));
			var ym = parseInt(number[n].getAttribute("data-pages"));
			if(ym == curPage) {
				obj.removeClass(number[n], 'pages');
				obj.addClass(number[n], 'active');
			} else {
				obj.removeClass(number[n], 'active');
			}
			if(u - curPage > 1) {
				obj.getPages(ul, curPage, pageTotal, pageSize, condition);
			}

		}
		//方法名称
      	if(condition != null) {
				var value = condition[0].sname;
				var type = condition[0].status;
				obj.par.SearchEvent(obj, value, curPage, pageSize, null, type);
			} else {
				obj.par.Callback(Table, obj, curPage, pageSize,li); //执行回调的方法
		}
		obj.lastPage(ul, curPage, html, Pre, condition); //上一页
		obj.nextPage(ul, curPage, pageTotal, html, next, condition); //下一页

	},
	//当前页码数的方法
	getPage: function(page) {
		//暂无
	},
	//首页的方法
	firstPage: function(ul, curPage, html, pageTotal, pagination, pageSize) {
		var that = this;
		var Table = TAB$(that.par.TableName);
		var span = TABLAYER$('span');
		var size = that.par.pageSize;
		var pageSize = size[0];
		span.innerHTML = '首页';
		pagination.appendChild(span);
		span.onclick = function() {
			var condition = JSON.parse(window.sessionStorage.getItem("searchname")); //获取session存储名
			var val = parseInt(1);
			curPage = val;
			that.getPage(that.curPage);
			if(condition != null) {
				var value = condition[0].sname;
				var type = condition[0].status;
				that.par.SearchEvent(that, value, curPage, pageSize, null, type);
			} else {
				that.par.Callback(Table, that, curPage, pageSize);

			}
			that.addClass(span, 'active');
			var last = name$('last-page')[0]; //设置
			that.removeClass(last, 'active');
			var Pre = name$('Pre-page')[0]; //设置
			that.lastPage(ul, curPage, html, Pre); //上一页
			var next = name$('Next-page')[0];
			that.nextPage(ul, curPage, pageTotal, html, next,condition); //下一页
		};
		var atr = document.createAttribute("name");
		atr.nodeValue = "home-page";
		pagination.setAttributeNode(atr);
	},
	//上一页的方法+
	lastPage: function(ul, curPage, html, obj, pagination, condition) {
		var that = this;
		var size = that.par.pageSize;
		var pageSize = size[0];
		var Table = TAB$(that.par.TableName);
		var number = name$('page-number');
		var span = TABLAYER$('span');
		if(!obj) {
			span.innerHTML = '<';
			if(parseInt(curPage) == 1) {
				span.className = 'disabled';
			}
			var atr = document.createAttribute("name");
			atr.nodeValue = "Pre-page";
			span.setAttributeNode(atr);
			pagination.appendChild(span);
		} else {
			if(parseInt(curPage) > 1) {
				obj.onclick = function() {
					curPage = parseInt(curPage - 1);
					if(curPage > 0) {
						that.par.Callback(Table, that, curPage, pageSize);
						that.getPage(that.curPage);
					}
					if(curPage == 1) {
						that.addClass(obj, 'disabled');
					}
				}
				that.removeClass(obj, 'disabled');
			} else {
				for(var i = 0; i < number.length; i++) {
					var lastm = parseInt(number[i].getAttribute("data-pages"));
					if(curPage != lastm) {
						that.removeClass(number[i], 'active');
					}
				}
				that.addClass(obj, 'disabled');
			}
		}
	},
	//分页判断方法
	getPages: function(ul, curPage, pageTotal, pageSize, condition) {
		var pag = [];
		var that = this;
		if(curPage <= pageTotal) {
			if(curPage < pageSize) {
				//当前页数小于显示条数
				var i = Math.min(pageSize, pageTotal);
				while(i) {
					pag.unshift(i--);
				}
			} else {
				//当前页数大于显示条数
				var middle = curPage - Math.floor(pageSize / 2),
					//从哪里开始
					i = pageSize;
				if(middle > pageTotal - pageSize) {
					middle = pageTotal - pageSize + 1;
				}
				while(i--) {
					pag.push(middle++);
				}
			}
		} else {
			that.PromptBox("当前页数不能大于总页数", 2);
		}
		if(!pageSize) {
			that.PromptBox("显示页数不能为空或者0", 2);
		}
		return pag;
	},
	Pagination: function(ul, pag, pageTotal, that) {
		var number = name$('page-number');
		var pagination = TAB$(that.par.paginName);
		for(var i = 0; i < number.length - 1; i++) {
			var li = TABLAYER$('li');
			number[i].innerHTML = pag[i];
			ul.appendChild(li);
			var m = pageTotal - 1;
			if(pag[i] == m) {}
		}
	},
	//下一页方法
	nextPage: function(ul, curPage, pageTotal, html, obj, condition) {
		var that = this;
		var Table = TAB$(that.par.TableName);
		var span = TABLAYER$('span');
		var number = name$('page-number');
		var size = that.par.pageSize;
		var pageSize = size[0];
		if(!obj) {
			span.innerHTML = '>';
			curPage = parseInt(curPage + 1);
			if(parseInt(curPage) < parseInt(pageTotal)) {
				span.onclick = function() {
					for(var i = 0; i < number.length - 1; i++) {
						var active = that.hasClass(number[i], 'active');
						if(active) {
							var curPage = parseInt(number[i].getAttribute("data-pages"));
						}
					}
					if(curPage >= pageTotal - 1) {
						span.className = 'disabled';
					} else {
						if(condition != null) {
							var value = condition[0].sname;
							var type = condition[0].status;
							that.par.SearchEvent(that, value, curPage, pageSize, null, type);
						} else {
							that.par.Callback(Table, that, curPage, pageSize,span);

						}
						that.getPage(that.curPage);
						var Pre = name$('Pre-page')[0];
						that.removeClass(Pre, 'disabled');
					}
				};
			} else {
				span.className = 'disabled';
			}
			var atr = document.createAttribute("name");
			atr.nodeValue = "Next-page";
			span.setAttributeNode(atr);
			ul ? ul.parentNode.appendChild(span) : '';
		} else {
			if(parseInt(curPage + 1) <= parseInt(pageTotal)) {
				if(obj.type != "touchend" && obj.type != "touchmove") {
					that.removeClass(obj, 'disabled');
				} else {
					if(condition != null) {
						var value = condition[0].sname;
						var type = condition[0].status;
						that.par.SearchEvent(that, value, curPage, pageSize, obj, type);
					} else {
						that.par.Callback(Table, that, curPage, pageSize, obj);
					}
				}
			} else {
				if(obj.type != "touchend" && obj.type != "touchmove") {
					for(var i = 0; i < number.length; i++) {
						var lastm = parseInt(number[i].getAttribute("data-pages"));
						if(curPage == lastm) {
							that.addClass(number[i], 'active');
						}
					}
					that.addClass(obj, 'disabled');
				} else {
					if(condition != null) {
						var value = condition[0].sname;
						var type = condition[0].status;
						that.par.SearchEvent(that, value, curPage, pageSize, obj, type);
					} else {
						that.par.Callback(Table, that, curPage, pageSize, obj);
					}
				}
			}
		}
	},
	//是否显示总页数,每页个数,数据
	showPageTotal: function(ul, curPage, pageTotal, total, Table) {
		var that = this;
		var totalPage = that.getByClass(ul.parentNode, 'totalPage');
		if(totalPage == 0) {
			var span1 = TABLAYER$('span');
			span1.innerHTML = '每页：<select class="select-page" name="SelectPage"></select> 条';
			span1.className = 'select-page';
			ul.parentNode.appendChild(span1);
			var span2 = TABLAYER$('span');
			span2.innerHTML = '共&nbsp' + pageTotal + '&nbsp页';
			span2.className = 'totalPage';
			var pages = document.createAttribute("name");
			pages.nodeValue = 'pageTotal';
			span2.setAttributeNode(pages);
			ul.parentNode.appendChild(span2);
			var span3 = TABLAYER$('span');
			span3.innerHTML = '合计&nbsp' + total + '&nbsp条';
			span3.className = 'totalPage';
			var pages1 = document.createAttribute("name");
			pages1.nodeValue = 'total';
			span3.setAttributeNode(pages1);
			ul.parentNode.appendChild(span3);
			that.selectPage(curPage, pageTotal, total, Table);
		} else {
			for(var i = 0; i < totalPage.length; i++) {
				var num = totalPage[i].getAttribute('name');
				//var num =parseInt(totalPage[i].innerText.replace(/[^0-9]/ig,""));
				if(num == 'pageTotal') {
					totalPage[i].innerHTML = '共&nbsp' + pageTotal + '&nbsp页';
				}
				if(num == 'total') {
					totalPage[i].innerHTML = '合计&nbsp' + total + '&nbsp条';
				}
			}
		}
	},
	//下拉选择数据显示条数
	selectPage: function(curPage, pageTotal, total, Table) {
		var that = this;
		var name = name$('SelectPage')[0];
		var size = that.par.pageSize;
		for(var i = 0; i < size.length; i++) {
			name.innerHTML += "<option value=" + size[i] + ">" + size[i] + "</option>";
		}
		var pageSize = size[0];
		name.onchange = function() {
			var pageSize = parseInt(name.options[name.selectedIndex].value);
			that.par.Callback(Table, that, curPage, pageSize, name);
		};
	},
	//尾页方法
	finalPage: function(ul, curPage, pageTotal, pageSize, html) {
		var that = this;
		var Table = TAB$(that.par.TableName);
		var amount = that.par.btnpageing;
		var P = name$('last-page')[0];
		var span = TABLAYER$('span');
		if(!P) {
			var number = name$('page-number');
			span.innerHTML = '尾页';
			ul.parentNode.appendChild(span);
		} else {
			var next = name$('Next-page')[0];
			var number = name$('page-number');
			span.innerHTML = '尾页';
			ul.parentNode.replaceChild(span, P);
		}
		//var size = that.par.pageSiz e;
		//var pageSize = size[0];
		var pagination = TAB$(that.par.paginName);
		span.onclick = function() {
			var condition = JSON.parse(window.sessionStorage.getItem("searchname")); //获取session存储名
			curPage = parseInt(pageTotal);
			that.getPage(curPage);
			if(condition!=null){
				var value=condition[0].sname;
		      	var type=condition[0].status;
		      	that.par.SearchEvent(that, value, curPage, pageSize, null, type);
		    }else{
		    	that.par.Callback(Table, that, curPage, pageSize,span);
		    }
			that.addClass(span, 'active');
			for(var i = 0; i < number.length; i++) {
				that.removeClass(number[i], 'active');
			}
			var Pre = name$('Pre-page')[0]; //设置
			that.lastPage(ul, curPage, html, Pre); //上一页
			var next = name$('Next-page')[0];
			that.nextPage(ul, curPage, pageTotal, html, next,condition); //下一页
		};
		var atr = document.createAttribute("name");
		atr.nodeValue = "last-page";
		span.setAttributeNode(atr);
	},
	onSequence: function(Table, col, e) {
		var _this = this;

		// 定义判断排序字段的一个标志位，数字排序(自己写)和字符排序(JavaScript内置函数) 
		var SortAsNumber = true;
		// 定义放置需要排序的行数组 
		var Sorter = [];
		for(var x = 1; x < Table.rows.length; x++) {
			Sorter[x - 1] = [Table.rows[x].cells[col].innerHTML, x];
			// 判断需要排序字段的类型，分为数字型和非数字型 
			SortAsNumber = SortAsNumber && _this.IsNumeric(Sorter[x - 1][0]);
		}
		// 如果是数字型采用下面的方法排序 
		if(SortAsNumber) {
			for(var x = 0; x < Sorter.length; x++) {
				for(var y = x + 1; y < Sorter.length; y++) {
					if(parseFloat(Sorter[y][0]) < parseFloat(Sorter[x][0])) {
						var tmp = Sorter[x];
						Sorter[x] = Sorter[y];
						Sorter[y] = tmp;
					}
				}
			}
		}
		// 如果是非数字型的可以采用内置方法sort()排序 
		else {
			Sorter.sort();
		}
		if(_this.par.ViewState[col]) {
			// JavaScript内置函数，用于颠倒数组中元素的顺序。 
			Sorter.reverse();
			_this.par.ViewState[col] = false;
			_this.addClass(Table.rows[0].cells[col].lastChild, 'SortDescCss');
			_this.removeClass(Table.rows[0].cells[col].lastChild, 'SortAscCss');
		} else {
			_this.par.ViewState[col] = true;
			_this.addClass(Table.rows[0].cells[col].lastChild, 'SortAscCss');
			_this.removeClass(Table.rows[0].cells[col].lastChild, 'SortDescCss');
		}
		var Rank = [];
		for(var x = 0; x < Sorter.length; x++) {
			Rank[x] = _this.GetRowHtml(Table.rows[Sorter[x][1]]);
		}
		for(var x = 1; x < Table.rows.length; x++) {
			for(var y = 0; y < Table.rows[x].cells.length; y++) {
				Table.rows[x].cells[y].innerHTML = Rank[x - 1][y];
			}
		}
		_this.OnSorted(Table.rows[0].cells[col], _this.par.ViewState[col]);
	},
	//点击选择框事件
	currentcheckbox: function(Table, index, curPage, pageSize) {
		for(var x = 1; x < Table.rows.length; x++) {
			var checkbox = Table.rows[x].cells[0].getElementsByTagName('input')[0];
			checkbox ? Table.rows[x].cells[0].onclick = function(e) {
				for(var m = 1; m < Table.rows.length; m++) {
					index.onlikecheck(Table, m, curPage, pageSize, e)
				}
			} : ''; //单选事件
		};
	},
	//选择事件处理方法
	onlikecheck: function(Table, col, curPage, pageSize, e) {
		var _this = this;
		var status = _this.par.TreeStatus;
		if(status == true) {
			var evt = e || window.event;
			var tar = evt.target || evt.srcElement;
			var cbox = tar.parentNode.getElementsByTagName('input')[0];
			var obj = tar.parentNode.parentNode.parentNode;
			var id = cbox.value; //获取checkbox值
			var tree = Table.rows[col].getAttribute("data-tree"); //获取设置树状图参数
			addLoadListener(_this.btnclick);
			this.btnclick(Table, id, obj, tree, cbox, curPage, pageSize);
			var n = Table.querySelectorAll(".active").length;
			var t = Table.rows.length - 1;
			var checkbox = Table.rows[0].cells[0].getElementsByTagName('input')[0];
			if(n == t) {
				checkbox.checked = true;
			} else if((t - n) <= n) {
				checkbox.checked = false;
			}
		} else {
			for(var x = 0; x < Table.rows[0].cells.length; x++) {
				var checkbox = Table.rows[0].cells[x].getElementsByTagName('input')[x];
				if(checkbox) {
					if(checkbox.checked == true) {
						checkbox ? checkbox.checked = false : '';
					}
				}
				var zcheckbox = Table.rows[col].cells[0].getElementsByTagName('input')[x];
				if(zcheckbox) {
					if(zcheckbox.checked == true) {
						_this.addClass(Table.rows[col], 'active');
					} else if(zcheckbox.checked == false) {
						_this.removeClass(Table.rows[col], 'active');
					}
					for(var x = 1; x < Table.rows.length; x++) {
						var n = Table.querySelectorAll(".active").length;
						var t = Table.rows.length - 1;
						if(n == t) {
							checkbox ? checkbox.checked = true : '';
						}
					}
				}
			}
		}
	},
	//全选处理方法
	oncheckbox: function(Table, col) {
		var _this = this;
		for(var x = 1; x < Table.rows.length; x++) {
			var checkbox = Table.rows[x].cells[col].getElementsByTagName('input')[col];
			if(checkbox) {
				for(var y = 0; y < Table.rows[0].cells.length; y++) {
					var checkboxs = Table.rows[0].cells[y].getElementsByTagName('input')[y];
					if(checkboxs) {
						if(checkboxs.checked == false) {
							checkbox ? checkbox.checked = false : '';
							_this.removeClass(Table.rows[x], 'active');
						} else {
							checkbox.checked = true;
							_this.addClass(Table.rows[x], 'active');
						}
					}
				}
			}
		}
	},
	//表格拖拽鼠标指针点击时发生
	Dragdrop: function(e, Table, tTD, obj) {
		var col = obj.cellIndex;
		var tTD = Table.rows[0].cells[col];
		if(e.offsetX > tTD.offsetWidth - 10) {
			tTD.mouseDown = true;
			tTD.oldX = e.x;
			tTD.oldWidth = tTD.offsetWidth;
		}
	},
	//表格拖拽鼠标按键被松开时发生
	onmouseupDrop: function(e, Table, tTD, obj) {
		var col = obj.cellIndex;
		if(tTD == undefined) tTD = Table.rows[0].cells[col];
		tTD.mouseDown = false;
		tTD.style.cursor = 'default';
	},
	//表格拖拽鼠标指针移动时发生
	onmousemoveDrop: function(e, Table, tTD, obj) {
		var col = obj.cellIndex;
		//更改鼠标样式
		if(e.offsetX > Table.rows[0].cells[col].offsetWidth - 5) {
			Table.rows[0].cells[col].style.cursor = 'e-resize';
		} else {
			Table.rows[0].cells[col].style.cursor = 'default';
		}
		//取出暂存的Table Cell
		if(tTD == undefined) tTD = Table.rows[0].cells[col];
		//调整宽度
		if(tTD.mouseDown != null && tTD.mouseDown == true) {
			tTD.style.cursor = 'default';
			if(tTD.oldWidth + (e.x - tTD.oldX) > 0)
				tTD.width = tTD.oldWidth + (e.x - tTD.oldX);
			//调整列宽
			tTD.style.width = tTD.width;
			tTD.style.cursor = 'e-resize';
			//调整该列中的每个Cell
			table = tTD;
			while(table.tagName != 'TABLE') table = table.parentElement;
			for(j = 0; j < table.rows.length; j++) {
				table.rows[j].cells[tTD.cellIndex].width = tTD.width;
			}
		}
	},
	// 取得指定行的内容. 
	GetRowHtml: function(row) {
		var result = [];
		for(var x = 0; x < row.cells.length; x++) {
			result[x] = row.cells[x].innerHTML;
		}
		return result;
	},
	OnSorted: function(cell, IsAsc) {
		return;
	},
	IsNumeric: function(num) {
		return /^\d+(\.\d+)?$/.test(num);
	}
};