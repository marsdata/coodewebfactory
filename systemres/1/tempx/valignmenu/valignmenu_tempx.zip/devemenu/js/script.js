(function() {
  var a, i, len, magicLine, ref;

  magicLine = class magicLine {
    constructor(menu) {
      this.update = this.update.bind(this);
      this.menu = menu;
      if (!this.menu) {
        return;
      }
      this.menu.classList.add('has-magic-line');
      this.line = document.createElement('li');
      this.line.classList.add('magic-line');
      this.menu.appendChild(this.line);
      this.update();
      window.addEventListener('resize', this.update);
    }

    update() {
      var el;
      if (!(el = this.menu.querySelector('.active'))) {
        return;
      }
      this.line.style.transform = `translateY( ${el.offsetTop || 0}px )`;
      this.line.style.height = `${el.offsetHeight || 0}px`;
      return this.line.style.backgroundColor = window.getComputedStyle(el).getPropertyValue('background-color');
    }

  };

  // initialize
  window.magicLine = new magicLine(document.querySelector('.menu'));

  ref = document.querySelectorAll('.menu-item a');
  // click
  for (i = 0, len = ref.length; i < len; i++) {
    a = ref[i];
    a.addEventListener('click', function(e) {
      var ref1;
      e.preventDefault();
      if ((ref1 = document.querySelector('.menu-item.active')) != null) {
        ref1.classList.remove('active');
      }
      this.parentNode.classList.add('active');
      return window.magicLine.update();
    });
  }

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiPGFub255bW91cz4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBLENBQUEsRUFBQSxDQUFBLEVBQUEsR0FBQSxFQUFBLFNBQUEsRUFBQTs7RUFBTSxZQUFOLE1BQUEsVUFBQTtJQUVFLFdBQWEsS0FBQSxDQUFBO1VBWWIsQ0FBQSxhQUFBLENBQUE7TUFaYyxJQUFDLENBQUE7TUFFYixLQUFjLElBQUMsQ0FBQSxJQUFmO0FBQUEsZUFBQTs7TUFFQSxJQUFDLENBQUEsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFoQixDQUFvQixnQkFBcEI7TUFDQSxJQUFDLENBQUEsSUFBRCxHQUFRLFFBQVEsQ0FBQyxhQUFULENBQXVCLElBQXZCO01BQ1IsSUFBQyxDQUFBLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBaEIsQ0FBb0IsWUFBcEI7TUFDQSxJQUFDLENBQUEsSUFBSSxDQUFDLFdBQU4sQ0FBa0IsSUFBQyxDQUFBLElBQW5CO01BRUEsSUFBQyxDQUFBLE1BQUQsQ0FBQTtNQUNBLE1BQU0sQ0FBQyxnQkFBUCxDQUF3QixRQUF4QixFQUFrQyxJQUFDLENBQUEsTUFBbkM7SUFWVzs7SUFZYixNQUFRLENBQUEsQ0FBQTtBQUVWLFVBQUE7TUFBSSxLQUFjLENBQUEsRUFBQSxHQUFLLElBQUMsQ0FBQSxJQUFJLENBQUMsYUFBTixDQUFvQixTQUFwQixDQUFMLENBQWQ7QUFBQSxlQUFBOztNQUVBLElBQUMsQ0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVosR0FBd0IsQ0FBQSxZQUFBLENBQUEsQ0FBZSxFQUFFLENBQUMsU0FBSCxJQUFjLENBQTdCLENBQUEsSUFBQTtNQUN4QixJQUFDLENBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFaLEdBQXFCLENBQUEsQ0FBQSxDQUFHLEVBQUUsQ0FBQyxZQUFILElBQWlCLENBQXBCLENBQUEsRUFBQTthQUNyQixJQUFDLENBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxlQUFaLEdBQThCLE1BQU0sQ0FBQyxnQkFBUCxDQUF3QixFQUF4QixDQUEyQixDQUFDLGdCQUE1QixDQUE2QyxrQkFBN0M7SUFOeEI7O0VBZFYsRUFBQTs7O0VBd0JBLE1BQU0sQ0FBQyxTQUFQLEdBQW1CLElBQUksU0FBSixDQUFjLFFBQVEsQ0FBQyxhQUFULENBQXVCLE9BQXZCLENBQWQ7O0FBSW5COztFQUFBLEtBQUEscUNBQUE7O0lBQ0UsQ0FBQyxDQUFDLGdCQUFGLENBQW1CLE9BQW5CLEVBQTRCLFFBQUEsQ0FBQyxDQUFELENBQUE7QUFDOUIsVUFBQTtNQUFJLENBQUMsQ0FBQyxjQUFGLENBQUE7O1lBQzJDLENBQUUsU0FBUyxDQUFDLE1BQXZELENBQThELFFBQTlEOztNQUNBLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEdBQTFCLENBQThCLFFBQTlCO2FBQ0EsTUFBTSxDQUFDLFNBQVMsQ0FBQyxNQUFqQixDQUFBO0lBSjBCLENBQTVCO0VBREY7QUE1QkEiLCJzb3VyY2VzQ29udGVudCI6WyJjbGFzcyBtYWdpY0xpbmVcbiAgXG4gIGNvbnN0cnVjdG9yOiAoQG1lbnUpIC0+XG4gICAgXG4gICAgcmV0dXJuIHVubGVzcyBAbWVudVxuICAgICAgICBcbiAgICBAbWVudS5jbGFzc0xpc3QuYWRkICdoYXMtbWFnaWMtbGluZSdcbiAgICBAbGluZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQgJ2xpJ1xuICAgIEBsaW5lLmNsYXNzTGlzdC5hZGQgJ21hZ2ljLWxpbmUnXG4gICAgQG1lbnUuYXBwZW5kQ2hpbGQgQGxpbmVcblxuICAgIEB1cGRhdGUoKVxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyICdyZXNpemUnLCBAdXBkYXRlXG5cbiAgdXBkYXRlOiA9PlxuXG4gICAgcmV0dXJuIHVubGVzcyBlbCA9IEBtZW51LnF1ZXJ5U2VsZWN0b3IgJy5hY3RpdmUnXG4gICAgICAgIFxuICAgIEBsaW5lLnN0eWxlLnRyYW5zZm9ybSA9IFwidHJhbnNsYXRlWSggI3tlbC5vZmZzZXRUb3B8fDB9cHggKVwiXG4gICAgQGxpbmUuc3R5bGUuaGVpZ2h0ID0gXCIje2VsLm9mZnNldEhlaWdodHx8MH1weFwiXG4gICAgQGxpbmUuc3R5bGUuYmFja2dyb3VuZENvbG9yID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoZWwpLmdldFByb3BlcnR5VmFsdWUoJ2JhY2tncm91bmQtY29sb3InKVxuXG4jIGluaXRpYWxpemVcbiAgICBcbndpbmRvdy5tYWdpY0xpbmUgPSBuZXcgbWFnaWNMaW5lIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5tZW51JylcblxuIyBjbGlja1xuXG5mb3IgYSBpbiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcubWVudS1pdGVtIGEnKVxuICBhLmFkZEV2ZW50TGlzdGVuZXIgJ2NsaWNrJywgKGUpIC0+XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLm1lbnUtaXRlbS5hY3RpdmUnKT8uY2xhc3NMaXN0LnJlbW92ZSAnYWN0aXZlJ1xuICAgIHRoaXMucGFyZW50Tm9kZS5jbGFzc0xpc3QuYWRkICdhY3RpdmUnXG4gICAgd2luZG93Lm1hZ2ljTGluZS51cGRhdGUoKSJdfQ==
//# sourceURL=coffeescript