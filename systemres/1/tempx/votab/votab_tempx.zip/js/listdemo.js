ccode=new Array();
kcode=new Array();
ccode["chtml"]="{a href=\"javascript:void(0)\" onclick=\"viewitemx([thissno],600,600)\" style=\";\" snox=\"[thissno]\"}{img src=\"/localxres/iconsetx/pagecontrol/detail5.svg\" style=\"width:20px;height:20px;\"}{/a}{a href=\"javascript:void(0)\" onclick=\"updateitem([thissno])\" style=\";\"  snox=\"[thissno]\"}{img  id=\"upd[thissno]\" src=\"/localxres/iconsetx/pagecontrol/tongguoqr.svg\" style=\"width:20px;height:20px\"}{/a}{a href=\"javascript:void(0)\" onclick=\"delitem([thissno])\"  style=\";\"  snox=\"[thissno]\"}{img  src=\"/localxres/iconsetx/pagecontrol/shanchu13.svg\" style=\"width:20px;height:20px\"}{/a}";
ccode["varchar"]="[thisvalue]";
ccode["srd"]="[diytop][searchdemo]{div class=\"public_box\"}{h1 class=\"title\"}{strong}[shorttitle]{/strong}{div class=\"articleTop\"}{div class=\"win-input\"}{input id=\"searchkey\" type=\"search\" class=\"text-serach\" placeholder=\"请输入关键词进行检索\"}{button class=\"button-normal\" id=\"alertbox\" onclick=\"allsearch('[shortid]');\"}搜索{/button}{/div}{span}{a class=\"button-normal button-search\" href=\"javascript:void(0)\" onclick=\"window.location.reload()\"}刷新{/a}{a class=\"button-normal button-add\" href=\"javascript:void(0)\" onclick=\"newone()\"}创建数据{/a}{/span}{/div}{/h1}{form name=\"tabform\"  class=\"layui-form\" onsubmit=\"return changesmt();\"  action=\"#\"}{table name=\"tabunit\" class=\"table-default mb10\" shortid=\"[shortid]\" style=\"TAB_STL\"  tbname=\"[tabnm]\" tbkies=\"[tabkeys]\" tabkeys=\"[tkeys]\" pssno=\"[pssno]\" pskey=\"[pskey]\" pstitle=\"[pstitle]\" pshead=\"[pshead]\"  totrcd=\"[totrcd]\"  pnum=\"[pnum]\"}{/table}{/form}{div class=\"actionBtnGroup\"}{button class=\"button-normal button-add mr10\" onclick=\"quanxuan()\"}全选{/button}{button class=\"button-normal button-del\" onclick=\"plsc()\"}删除{/button}{/div}{/div}{div id=\"pageskin\" }[tabpage]{/div}[diybottom]";
ccode["tabdemo"]="{table  name=\"tabunit\" class=\"table-default mb10\"  style=\"TAB_STL\"  tbname=\"[tabnm]\" pskey=\"[pskey]\" pstitle=\"[pstitle]\" pshead=\"[pshead]\" pssno=\"[pssno]\" tbkies=\"[tabkeys]\"   totrcd=\"[totrcd]\"  pnum=\"[pnum]\" }[tbheadbody]{/table}";
ccode["text"]="";
ccode["richtext"]="";
ccode["code"]="";
ccode["select"]="function mkaselect($colname,$snox,$clstxt,$acthtm,$thusvalue,$arraydata,jsondata,$ti){  $clstxt=tostring($clstxt);    if ($clstxt!=\"\"){      if (strpos($clstxt,\"key-\")==1){          $hk=qian(hou($clstxt,\"key-\"),\"]\");          $clstxt=tostring($arraydata[$hk][$ti]);      }else{          if (strpos($clstxt,\"key\")==1 ){              kclstxtx=\"\";                         $clstxt=makeclstxtbykst($clstxt,$arraydata,$ti);              }else{                        $clstxt=$clstxt;         };      };     fmselect=\"<div class='select-box'>\"+formselect(qian($clstxt,\"|\"),hou($clstxt,\"|\"),$thusvalue,\"p_\"+$colname+$snox,\"select\",$acthtm)+\"</div>\";    return fmselect;  }else{   return \"\";  }}";
function mkaselect($colname,$snox,$clstxt,$acthtm,$thusvalue,$arraydata,jsondata,$ti){
  $clstxt=tostring($clstxt);  
  if ($clstxt!=""){
      if (strpos($clstxt,"key-")==1){
          $hk=qian(hou($clstxt,"key-"),"]");
          $clstxt=tostring($arraydata[$hk][$ti]);
      }else{
          if (strpos($clstxt,"key")==1 ){ 
             kclstxtx="";            
             $clstxt=makeclstxtbykst($clstxt,$arraydata,$ti);    
          }else{            
            $clstxt=$clstxt;
         };
      };
     fmselect="<div class='select-box'>"+formselect(qian($clstxt,"|"),hou($clstxt,"|"),$thusvalue,"p_"+$colname+$snox,"select",$acthtm)+"</div>";
    return fmselect;
  }else{
   return "";
  }
}
ccode["multiselect"]="function mkbselect($colname,$snox,$clstxt,$thusvalue,$arraydata,jsondata,$ti){$clstxt=tostring($clstxt);  if ($clstxt!=\"\"){      $newonex=tostring($clstxt);      if (strpos($newonex,\"key-\")==1){          $hk=qian(hou($newonex,\"key-\"),\"]\");          $newonex=tostring($arraydata[$hk][$ti]);      }else{          if (strpos($newonex,\"key\")==1 ){              kclstxtx=\"\";             $newonex=makeclstxtbykst($clstxt,$arraydata,$ti);          };      };    $inputdemo=\"<input type='hidden' id='p_[key0]' value='\"+$thusvalue+\"'>\";    $fmselect=formselectx(qian($newonex,\"|\"),hou($newonex,\"|\"),$thusvalue,\"p_\"+$colname+$snox,\"p_\"+$colname+$snox,\"\");    return \"<div class='select-box'>\"+$inputdemo+$fmselect+\"</div>\";  }else{   return \"\";  }}";
function mkbselect($colname,$snox,$clstxt,$thusvalue,$arraydata,jsondata,$ti){
$clstxt=tostring($clstxt);
  if ($clstxt!=""){
      $newonex=tostring($clstxt);
      if (strpos($newonex,"key-")==1){
          $hk=qian(hou($newonex,"key-"),"]");
          $newonex=tostring($arraydata[$hk][$ti]);
      }else{
          if (strpos($newonex,"key")==1 ){ 
             kclstxtx="";
             $newonex=makeclstxtbykst($clstxt,$arraydata,$ti);
          };
      };
    $inputdemo="<input type='hidden' id='p_[key0]' value='"+$thusvalue+"'>";
    $fmselect=formselectx(qian($newonex,"|"),hou($newonex,"|"),$thusvalue,"p_"+$colname+$snox,"p_"+$colname+$snox,"");
    return "<div class='select-box'>"+$inputdemo+$fmselect+"</div>";
  }else{
   return "";
  }
}
ccode["date"]="";
ccode["datetime"]="";
ccode["int"]="[thisvalue]";
ccode["tinyint"]="[thisvalue]";
ccode["decimal1"]="{input id=\"p_[key][thissno]\" data_step=\"0.1\" style=\"width:100px;\" data_min=\"0\" data_max=\"9999\" data_edit=\"true\"  data_digit=\"1\" value=\"[thisvalue]\"}";
ccode["decimal2"]="{input id=\"p_[key][thissno]\" data_step=\"0.01\" style=\"width:100px;\" data_min=\"0\" data_max=\"9999\" data_edit=\"true\"  data_digit=\"2\" value=\"[thisvalue]\"}";
ccode["decimal3"]="{input id=\"p_[key][thissno]\" data_step=\"0.001\" style=\"width:100px;\" data_min=\"0\" data_max=\"9999\" data_edit=\"true\"  data_digit=\"3\" value=\"[thisvalue]\"}";
ccode["decimal4"]="{input id=\"p_[key][thissno]\" data_step=\"0.0001\" style=\"width:100px;\" data_min=\"0\" data_max=\"9999\" data_edit=\"true\"  data_digit=\"4\" value=\"[thisvalue]\"}";
ccode["imagex"]="";
ccode["images"]="";
ccode["filex"]="";
ccode["files"]="";
ccode["check"]="";
ccode["multicheck"]="";
ccode["datasnoth"]="";
ccode["oprtbtnth"]="";
ccode["varcharth"]="";
ccode["textth"]="";
ccode["richtextth"]="";
ccode["codeth"]="";
ccode["selectth"]="";
ccode["multiselectth"]="";
ccode["dateth"]="";
ccode["datetimeth"]="";
ccode["intth"]="";
ccode["tinyintth"]="";
ccode["decimal1th"]="";
ccode["decimal2th"]="";
ccode["decimal3th"]="";
ccode["decimal4th"]="";
ccode["imagexth"]="";
ccode["imagesth"]="";
ccode["filexth"]="";
ccode["filesth"]="";
ccode["checkth"]="";
ccode["multicheckth"]="";
ccode["datasnotd"]="";
ccode["oprtbtntd"]="";
ccode["varchartd"]="";
ccode["texttd"]="";
ccode["richtexttd"]="";
ccode["codetd"]="";
ccode["selecttd"]="";
ccode["multiselecttd"]="";
ccode["datetd"]="";
ccode["datetimetd"]="";
ccode["inttd"]="";
ccode["tinyinttd"]="";
ccode["decimal1td"]="";
ccode["decimal2td"]="";
ccode["decimal3td"]="";
ccode["decimal4td"]="";
ccode["imagextd"]="";
ccode["imagestd"]="";
ccode["filextd"]="";
ccode["filestd"]="";
ccode["checktd"]="";
ccode["multichecktd"]="";
ccode["oprt"]="function oprteval(){    $(\"form[name='tabform']\").html(bktable);    $('.loadingBox').attr('data-show', 0);    newtdlisten();    listenclsduo();     layrender();     layui.use(['form'], function(){     form =layui.form;     form.on('select(brickType)', function(data){      ocg=$(this).parent().parent().prev().attr(\"onchange\");     nv=$(this).attr(\"lay-value\");     if (ocg!=undefined  &&  nv!=undefined){      if (ocg!=\"\"){        ocg=ocg.replace(/\<thisnewvalue\>/g,nv);        eval(ocg);        form.render();       };     };   });  });     a=$(\"th\");    b=$(\"td\");    for (z=0;z<a.length;z++){     $(a[z]).width($(b[z]).width());    }  }";
function oprteval(){
    $("form[name='tabform']").html(bktable);
    $('.loadingBox').attr('data-show', 0);
    newtdlisten();
    listenclsduo();
     layrender();
     layui.use(['form'], function(){
     form =layui.form;
     form.on('select(brickType)', function(data){ 
     ocg=$(this).parent().parent().prev().attr("onchange");
     nv=$(this).attr("lay-value");
     if (ocg!=undefined  &&  nv!=undefined){
      if (ocg!=""){
        ocg=ocg.replace(/\<thisnewvalue\>/g,nv);
        eval(ocg);
        form.render(); 
      };
     };
   });
  }); 
    a=$("th");
    b=$("td");
    for (z=0;z<a.length;z++){
     $(a[z]).width($(b[z]).width());
    }
  }
ccode["tabtr"]="{tr  snox=\"[thissno]\" sqx=\"[sqx]\"}[inner]{/tr}";
ccode["tabtd"]="{td id=\"[key][SNO]\" snoid=\"[thissno]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" knm=\"[key]\" tdata=\"[hvalue]\" rdol=\"[rdol]\" style=\"[dspl]\"}[inner]{/td}";
ccode["tabhdtr"]="{tr}[inner]{/tr}";
ccode["tabhdtd"]="{th id=\"tabhd[key]\"  tpnm=\"[tpnm]\"  dxtp=\"[dxtype]\"  class=\"\" rdol=\"[readonly]\" style=\"[dspl]\"}[inner]{/th}";
ccode["content"]="{div class=\"oldTable\" style=\"overflow: auto; height: auto; magin-top: -8px;\" id=\"htmllist\"}[shortdata]{/div}";
ccode["pgsrd"]="{center}{div id=\"customPages\" class=\"customPages\"}{a href=\"javascript:void(0)\" onclick=\"window.open(location.href.replace('&refresh=',''))\"}{img id=\"tcg\" src=\"/localxres/iconsetx/pagecontrol/移动.svg\" style=\"width:20px;height:20px;\"}{/a}{a href=\"javascript:void(0)\" onclick=\"window.open(location.href+'&refresh=1')\"}{img src=\"/localxres/iconsetx/pagecontrol/qj37.svg\" style=\"width:20px;height:20px;\"}{/a}{span class=\"layui-laypage-count\"}共[totrst]条{/span}{span class=\"layui-laypage-count\"}共[totpage]页{/span}{span class=\"layui-laypage-limits\"}[pgselect]{/span}{span class=\"layui-laypage-limits\"}[pgnum]{/span}{div class=\"layui-box layui-laypage layui-laypage-default\" id=\"layui-laypage-1\"}{a href=\"javascript:void(0);\" class=\"layui-laypage-prev\"  onclick=\"tospage([prepg])\"}上一页{/a}{a href=\"javascript:void(0);\" class=\"layui-laypage-first\" onclick=\"tospage(1)\"}首页{/a}  [pageinner]{a href=\"javascript:void(0);\"  class=\"layui-laypage-last\" onclick=\"tospage([totye])\"}尾页{/a}{a href=\"javascript:void(0);\" class=\"layui-laypage-next\" onclick=\"tospage([nxtpg])\"}下一页{/a}{a href=\"javascript:void(0)\" id=\"isu\" onclick=\"changeb()\"}{img src=\"/localxres/iconsetx/pagecontrol/xg0.svg\" style=\"width:20px;height:20px;\"}{/a}{input id=\"isupdate\" type=\"hidden\" lay-skin=\"primary\" value=\"0\" }{/div}{/div}{/center}";
ccode["pgin"]="{span class=\"layui-laypage-curr\"}{em class=\"layui-laypage-em\"}{/em}{em}[pgtt]{/em}{/span}";
ccode["pgout"]="{a href=\"javascript:void(0);\" onclick=\"tospage([page])\"}[pgtt]{/a}";
ccode["searchdemo"]="";
ccode["chtmlSCRIPT"]="";
ccode["varcharSCRIPT"]="";
ccode["contentSCRIPT"]="";
ccode["searchdemoSCRIPT"]="";
ccode["srdSCRIPT"]="";
ccode["textSCRIPT"]="";
ccode["richtextSCRIPT"]="";
ccode["codeSCRIPT"]="";
ccode["selectSCRIPT"]="";
ccode["multiselectSCRIPT"]="";
ccode["dateSCRIPT"]="";
ccode["datetimeSCRIPT"]="";
ccode["intSCRIPT"]="";
ccode["tinyintSCRIPT"]="";
ccode["decimal1SCRIPT"]="";
ccode["decimal2SCRIPT"]="";
ccode["decimal3SCRIPT"]="";
ccode["decimal4SCRIPT"]="";
ccode["imagexSCRIPT"]="";
ccode["imagesSCRIPT"]="";
ccode["pgsrdSCRIPT"]="";
ccode["pginSCRIPT"]="";
ccode["pgoutSCRIPT"]="";
ccode["filexSCRIPT"]="";
ccode["filesSCRIPT"]="";
ccode["checkSCRIPT"]="";
ccode["multicheckSCRIPT"]="";
ccode["tabtrSCRIPT"]="";
ccode["tabtdSCRIPT"]="";
ccode["tabhdtrSCRIPT"]="";
ccode["tabhdtdSCRIPT"]="";
ccode["oprtSCRIPT"]="";
ccode["chtmlFUNCTION"]="";
ccode["varcharFUNCTION"]="";
ccode["textFUNCTION"]="";
ccode["richtextFUNCTION"]="";
ccode["codeFUNCTION"]="";
ccode["selectFUNCTION"]="";
ccode["multiselectFUNCTION"]="$(\".p_[key][thissno]\").fSelect();";
ccode["dateFUNCTION"]="";
ccode["datetimeFUNCTION"]="";
ccode["intFUNCTION"]="";
ccode["tinyintFUNCTION"]="";
ccode["decimal1FUNCTION"]="";
ccode["decimal2FUNCTION"]="";
ccode["decimal3FUNCTION"]="";
ccode["decimal4FUNCTION"]="";
ccode["imagexFUNCTION"]="";
ccode["imagesFUNCTION"]="";
ccode["pgsrdFUNCTION"]="";
ccode["pginFUNCTION"]="";
ccode["pgoutFUNCTION"]="";
ccode["filexFUNCTION"]="";
ccode["filesFUNCTION"]="";
ccode["checkFUNCTION"]="";
ccode["multicheckFUNCTION"]="";
ccode["oprtFUNCTION"]="";
ccode["contentFUNCTION"]="";
ccode["searchdemoFUNCTION"]="";
ccode["srdFUNCTION"]="";
