ccode=new Array();
ccode["srd"]=" [diytop] {div class=\"public_box\" id=\"addform\" showkeys=\"[showkeys]\"}        {h1 class=\"title\"}            {strong id=\"formtitle\"}[shorttitle]{/strong}            {span}                {a class=\"button-normal button-search\" href=\"javascript:void(0)\" onclick=\"window.location.reload()\"}刷新{/a}&nbsp;&nbsp;{a class=\"button-normal button-search\" href=\"javascript:void(0)\" onclick=\"gotodata()\"}数据表{/a}            {/span}        {/h1}        {div class=\"tabBox\"}            {div class=\"tabTitle\"}                {div class=\"tabWrap\" id=\"tabtop\"}                   [tabtop]                {/div}            {/div}            {div class=\"tabBody mb10\" id=\"tabbody\"}               [tabbody]            {/div}            {div class=\"actionBtnGroup\"}                {button class=\"button-normal button-add\" onclick=\"savex()\"}保存{/button}            {/div}        {/div}    {/div}[diybottom]";
ccode["diytop"]="";
ccode["diybottom"]="";
ccode["chtml"]="multiline";
ccode["itemsrd"]="{div class=\"win-input mb10\" id=\"eleof[key]\" style=\"[dspl]\" rdol=\"[rdol]\"  dxtype=\"[dxtp]\"}[inner]{/div}";
ccode["inline"]="tabActive::{span class=\"tabBtn [labcode]\"}[labtitle]{/span}";
ccode["varchar"]="{span class=\"input-name\"}[title]{/span}{input type=\"text\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\" class=\"text-full\" value=\"[value]\" placeholder=\"[exp]\"}";
ccode["text"]=" {span class=\"input-name\"}[title]{/span}{textarea  id=\"p_[key]\" [rdol] name=\"p_[key]\" class=\"textarea\"  style=\"width:100%;[dspl];\" placeholder=\"[exp]\"}[value]{/textarea}";
ccode["richtext"]="{span class=\"input-name\"}[title]{/span}{section name=\"editor\"}{div id=\"p_[key]\" [rdol] name=\"p_[key]\"  style=\"[dspl]\" style=\"margin-top: 30px;\"}{/div}{/section}";
ccode["code"]=" {span class=\"input-name\"}[title]{/span} {div class=\"container\" style=\"width:100%\"}  {div class=\"row\" style=\"width:100%\"}   {div class=\"col-sm-6\" style=\"width:100%\"}    {div class=\"panel panel-default\" style=\"width:100%\"}      {div class=\"panel-body\" style=\"padding: 0px;\" style=\"width:100%\"}              {textarea class=\"form-control\" id=\"p_[key]\" [rdol] name=\"p_[key]\" style=\"dspl; height: 385.56px;width:100%;padding: 0px 0px;\"}[value]{/textarea}      {/div}    {/div}   {/div}  {/div} {/div}";
ccode["select"]="function mkaselect(colname,snox,thisval,$clstxtx){      if ($clstxtx!=\"\"){    $clstxtx=tostring($clstxtx);    $fmselect=formselect(qian($clstxtx,\"|\"),hou($clstxtx,\"|\"),thisval,\"p_\"+colname,\"select\",\"\");                                return '<span class=\"input-name\">[title]</span><div class=\"select-box\" style=\"[dspl]\">'+$fmselect+'</div>';  }else{    return \"\";  }}";
function mkaselect(colname,snox,thisval,$clstxtx){    
  if ($clstxtx!=""){
    $clstxtx=tostring($clstxtx);
    $fmselect=formselect(qian($clstxtx,"|"),hou($clstxtx,"|"),thisval,"p_"+colname,"select","");                            
    return '<span class="input-name">[title]</span><div class="select-box" style="[dspl]">'+$fmselect+'</div>';
  }else{
    return "";
  }
}
ccode["multiselect"]="function mkbselect(colname,snox,thisval,$clstxtx){$clstxt=tostring($clstxtx);  if ($clstxt!=\"\"){    $newonex=tostring($clstxt);    $inputdemo=\"<input type='hidden' id='p_[key]' value='\"+thisval+\"'>\";    $fmselect=formselectx(qian($newonex,\"|\"),hou($newonex,\"|\"),$thusvalue,\"p_\"+$colname+$snox,\"p_\"+$colname+$snox,\"\");    return $inputdemo+\"<span class='input-name'>[title]</span><div class='select-box' style='[dspl]'>\"+$fmselect+\"</div>\";  }else{   return \"\";  }}";
function mkbselect(colname,snox,thisval,$clstxtx){
$clstxt=tostring($clstxtx);
  if ($clstxt!=""){
    $newonex=tostring($clstxt);
    $inputdemo="<input type='hidden' id='p_[key]' value='"+thisval+"'>";
    $fmselect=formselectx(qian($newonex,"|"),hou($newonex,"|"),$thusvalue,"p_"+$colname+$snox,"p_"+$colname+$snox,"");
    return $inputdemo+"<span class='input-name'>[title]</span><div class='select-box' style='[dspl]'>"+$fmselect+"</div>";
  }else{
   return "";
  }
}
ccode["date"]="{span class=\"input-name\"}[title]{/span}{input type=\"date\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\" class=\"text-full\" value=\"[value]\" placeholder=\"[exp]\"}";
ccode["datetime"]="{span class=\"input-name\"}[title]{/span}{input type=\"datetime-local\" id=\"p_[key]\" name=\"p_[key]\" [rdol] autocomplete=\"off\" class=\"text-full\" value=\"[value]\" placeholder=\"[exp]\"}";
ccode["int"]="";
ccode["tinyint"]="";
ccode["decimal1"]="";
ccode["decimal2"]="";
ccode["decimal3"]="";
ccode["decimal4"]="";
ccode["imagex"]="function mkimage(thisval,dxtype,snox){  if (snox==\"0\"){    return \"<span class='input-name'>[title]</span><div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-num='1' id='u_[key]'></div>[exp]</div>\";  }else{    return \"<span class='input-name'>[title]</span><div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-value='\"+thisval+\"' data-num='1' id='u_[key]'></div>[exp]</div>\";  };}";
function mkimage(thisval,dxtype,snox){
  if (snox=="0"){
    return "<span class='input-name'>[title]</span><div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-num='1' id='u_[key]'></div>[exp]</div>";
  }else{
    return "<span class='input-name'>[title]</span><div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-value='"+thisval+"' data-num='1' id='u_[key]'></div>[exp]</div>";
  };
}
ccode["images"]="function mkimgx(thisval,dxtype,snox){  if (snox==\"0\"){    return \"<span class='input-name'>[title]</span><div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-num='5' id='u_[key]'></div>[exp]</div>\";  }else{    if (right(thisval,1)==\";\"){     thisval=killlasttring(thisval.replace(/;/g,\",\"));    };    return \"<span class='input-name'>[title]</span><div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-value='\"+thisval+\"' data-num='5' id='u_[key]'></div>[exp]</div>\";  };}";
function mkimgx(thisval,dxtype,snox){
  if (snox=="0"){
    return "<span class='input-name'>[title]</span><div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-num='5' id='u_[key]'></div>[exp]</div>";
  }else{
    if (right(thisval,1)==";"){
     thisval=killlasttring(thisval.replace(/;/g,","));
    };
    return "<span class='input-name'>[title]</span><div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg' data-value='"+thisval+"' data-num='5' id='u_[key]'></div>[exp]</div>";
  };
}
ccode["filex"]="function mkfilex(thisval,dxtype,snox){  if (snox==\"0\"){    return \"<span class='input-name'>[title]</span><div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-num='1' id='u_[key]'></div>[exp]</div>\";  }else{    return \"<span class='input-name'>[title]</span><div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-value='\"+thisval+\"' data-num='1' id='u_[key]'></div>[exp]</div>\";  };}";
function mkfilex(thisval,dxtype,snox){
  if (snox=="0"){
    return "<span class='input-name'>[title]</span><div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-num='1' id='u_[key]'></div>[exp]</div>";
  }else{
    return "<span class='input-name'>[title]</span><div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-value='"+thisval+"' data-num='1' id='u_[key]'></div>[exp]</div>";
  };
}
ccode["files"]="function mkduofile(thisval,dxtype,snox){  if (snox==\"0\"){    return \"<span class='input-name'>[title]</span><div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-num='5' id='u_[key]'></div></div>\";  }else{    if (right(thisval,1)==\";\"){     thisval=killlasttring(thisval.replace(/;/g,','));    };    return \"<span class='input-name'>[title]</span><div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-value='\"+thisval+\"' data-num='5' id='u_[key]'></div></div>\";  };}";
function mkduofile(thisval,dxtype,snox){
  if (snox=="0"){
    return "<span class='input-name'>[title]</span><div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-num='5' id='u_[key]'></div></div>";
  }else{
    if (right(thisval,1)==";"){
     thisval=killlasttring(thisval.replace(/;/g,','));
    };
    return "<span class='input-name'>[title]</span><div class='case'><div class='upload' action='/upload' data-type='bmp,jpg,jpeg,png,gif,svg,doc,docx,xls,xlsx,pdf,rar,zip,ppt,pptx,txt' data-value='"+thisval+"' data-num='5' id='u_[key]'></div></div>";
  };
}
ccode["check"]="";
ccode["multicheck"]="";
ccode["varcharSRD"]="";
ccode["textSRD"]="";
ccode["richtextSRD"]="{div class=\"win-input\" id=\"eleof[key]\" style=\"[dspl]\" rdol=\"[rdol]\"  dxtype=\"[dxtp]\"}[inner]{/div}";
ccode["codeSRD"]="{div class=\"win-input\" id=\"eleof[key]\" style=\"[dspl]\" rdol=\"[rdol]\"  dxtype=\"[dxtp]\"}[inner]{/div}";
ccode["selectSRD"]="";
ccode["multiselectSRD"]="";
ccode["dateSRD"]="";
ccode["datetimeSRD"]="";
ccode["intSRD"]="";
ccode["tinyintSRD"]="";
ccode["decimal1SRD"]="";
ccode["decimal2SRD"]="";
ccode["decimal3SRD"]="";
ccode["decimal4SRD"]="";
ccode["imagexSRD"]="";
ccode["imagesSRD"]="";
ccode["filexSRD"]="";
ccode["filesSRD"]="";
ccode["checkSRD"]="";
ccode["multicheckSRD"]="";
ccode["varcharINLINE"]="";
ccode["textINLINE"]="";
ccode["richtextINLINE"]="";
ccode["codeINLINE"]="";
ccode["selectINLINE"]="";
ccode["multiselectINLINE"]="";
ccode["dateINLINE"]="";
ccode["datetimeINLINE"]="";
ccode["intINLINE"]="";
ccode["tinyintINLINE"]="";
ccode["decimal1INLINE"]="";
ccode["decimal2INLINE"]="";
ccode["decimal3INLINE"]="";
ccode["decimal4INLINE"]="";
ccode["imagexINLINE"]="";
ccode["imagesINLINE"]="";
ccode["filexINLINE"]="";
ccode["filesINLINE"]="";
ccode["checkINLINE"]="";
ccode["multicheckINLINE"]="";
ccode["onerow"]="[rowx]";
ccode["duorow"]="bodyActive::{div class=\"bodyLi [clscode]\"}[tabx]{/div}";
ccode["varcharFUNCTION"]="";
ccode["textFUNCTION"]="";
ccode["richtextFUNCTION"]="$('#p_[key]').editable({inlineMode: false, alwaysBlank: true});$('#p_[key] .froala-element').html(tostring('[hexvalue]'));";
ccode["codeFUNCTION"]="$(\"#p_[key]\").setTextareaCount({   width: \"30px\",   bgColor: \"#f5f5f5\",   color: \"#282c34\",   display: \"block\",   borderColor: \"#979797\"});window.onresize = function(){   let pw = $(\".panel-body\").width();   $(\"#p_[key]\").width((pw - 28) + 'px');};if (intval(\"[vwx]\")==0){  $(\"#p_[key]\").width(\"350px\");}else{ $(\"#p_[key]\").width(\"[vwx]\"+\"px\");};";
ccode["selectFUNCTION"]="";
ccode["multiselectFUNCTION"]="";
ccode["dateFUNCTION"]="";
ccode["datetimeFUNCTION"]="";
ccode["intFUNCTION"]="";
ccode["tinyintFUNCTION"]="";
ccode["decimal1FUNCTION"]="";
ccode["decimal2FUNCTION"]="";
ccode["decimal3FUNCTION"]="";
ccode["decimal4FUNCTION"]="";
ccode["imagexFUNCTION"]="snox=_get(\"SNO\"); if(snox==\"0\"){  $(\"#u_[key]\").attr(\"action\",\"/localxres/funx/easyrcvfile/?tbnm=[thistable]&key=[key]&olmk=\"+$(\"#p_OLMK\").val()); }else{  $(\"#u_[key]\").attr(\"action\",\"/localxres/funx/easyrcvfile/?tbnm=[thistable]&key=[key]&SNO=\"+snox); } $(\"#u_[key]\").upload();";
ccode["imagesFUNCTION"]="snox=_get(\"SNO\"); if(snox==\"0\"){  $(\"#u_[key]\").attr(\"action\",\"/localxres/funx/easyrcvfile/?tbnm=[thistable]&key=[key]&olmk=\"+$(\"#p_OLMK\").val()); }else{  $(\"#u_[key]\").attr(\"action\",\"/localxres/funx/easyrcvfile/?tbnm=[thistable]&key=[key]&SNO=\"+snox); } $(\"#u_[key]\").upload();";
ccode["filexFUNCTION"]="snox=_get(\"SNO\"); if(snox==\"0\"){  $(\"#u_[key]\").attr(\"action\",\"/localxres/funx/easyrcvfile/?tbnm=[thistable]&key=[key]&olmk=\"+$(\"#p_OLMK\").val()); }else{  $(\"#u_[key]\").attr(\"action\",\"/localxres/funx/easyrcvfile/?tbnm=[thistable]&key=[key]&SNO=\"+snox); } $(\"#u_[key]\").upload();";
ccode["filesFUNCTION"]="snox=_get(\"SNO\"); if(snox==\"0\"){  $(\"#u_[key]\").attr(\"action\",\"/localxres/funx/easyrcvfile/?tbnm=[thistable]&key=[key]&olmk=\"+$(\"#p_OLMK\").val()); }else{  $(\"#u_[key]\").attr(\"action\",\"/localxres/funx/easyrcvfile/?tbnm=[thistable]&key=[key]&SNO=\"+snox); } $(\"#u_[key]\").upload();";
ccode["checkFUNCTION"]="";
ccode["checkduoFUNCTION"]="";
ccode["multicheckFUNCTION"]="";
ccode["duorowFUNCTION"]="";
ccode["srdFUNCTION"]="";
