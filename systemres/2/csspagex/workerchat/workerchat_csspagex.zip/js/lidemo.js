function maketpldemo($fileurl,$fromid,$toid,$fromheadx,$toheadx){
  $fname=urlfname($fileurl);
  $kzm=hou($fname,".");
  $myvideodemo='<li class="me">\
       <div class="content"> \
           <div class="msg video">\
             <img class="img__video" src="/localxres/iconsetx/pagecontrol/tv.jpg" videoUrl="[videourl]" />\
           </div>\
        </div>\
        <a class="avatar" href="javascript:void(0)">\
          <img src="[myheadx]" />\
        </a>\
      </li>';
 $hisvideodemo='<li class="others">\
                     <a class="avatar" href="[hisinfourl]"><img src="[hisheadx]" /></a>\
                     <div class="content">\
                        <div class="msg video">\
                         <img class="img__video" src="/localxres/iconsetx/pagecontrol/tv.jpg" videoUrl="[videourl]" />\
                        </div>\
                     </div>\
                  </li>';
  $myimgdemo='<li class="me">\
             <div class="content">\
               <div class="msg picture">\
                <img class="img__pic" src="[imgurl]" />\
               </div>\
             </div>\
             <a class="avatar" href="javascript:void(0)"><img src="[myheadx]" /></a>\
    </li>';
  $hisimgdemo='<li class="others">\
                     <a class="avatar" href="[hisinfourl]"><img src="[hisheadx]" /></a>\
                     <div class="content">\
                        <div class="msg picture">\
                           <img class="img__pic" src="[imgurl]" />\
                        </div>\
                     </div>\
                  </li>';
  $mygifdemo='<li class="me">\
          <div class="content">\
              <div class="msg lgface">\
               <img class="img__pic" src="[gifurl]" />\
              </div>\
          </div>\
            <a class="avatar" href="javascript:void(0)"><img src="[myheadx]" /></a>\
        </li>';
  $hisgifdemo='<li class="others">\
                     <a class="avatar" href="[hisinfourl]"><img src="[hisheadx]" /></a>\
                     <div class="content">\
                        <div class="msg lgface">\
                           <img class="img__pic" src="[gifurl]" />\
                        </div>\
                     </div>\
                  </li>';
   $myothdemo='<li class="me">\
          <div class="content">\
            <div class="msg"><a href="[fileurl]" target="about_blank"><img src="/localxres/iconsetx/pagecontrol/wdwp.svg" style="width:50px;height:50px;">文件下载:[filename]</a></div>\
          </div>\
            <a class="avatar" href="javascript:void(0)"><img src="[myheadx]" /></a>\
        </li>';
  $hisothdemo='<li class="others">\
                     <a class="avatar" href="[hisinfourl]"><img src="[hisheadx]" /></a>\
                     <div class="content">\
                        <div class="msg"><a href="[fileurl]" target="about_blank"><img src="/localxres/iconsetx/pagecontrol/wdwp.svg" style="width:50px;height:50px;">文件下载:[filename]</a></div>\
                        </div>\
                     </div>\
                  </li>';
    $mdemo="";
  switch($kzm){
    case "gif":
    if (_cookie("uid")==$fromid){
       $mdemo=$mygifdemo;
       $mdemo=$mdemo.replace("[gifurl]",$fileurl);
       $mdemo=$mdemo.replace("[myheadx]",$fromheadx);
    }else{
       $mdemo=$hisgifdemo;
       $mdemo=$mdemo.replace("[gifurl]",$fileurl);
       $mdemo=$mdemo.replace("[hisheadx]",$fromheadx);
       $mdemo=$mdemo.replace("[hisinfourl]","/localxres/pagex/2/workerchat/Go7G55/S5FHW0/friend.html?layid=Go7G55&tinyid=S5FHW0&fuid="+$fromid+"&rcode="+_get("rcode"));
    }
    break;
    case "jpg":
    if (_cookie("uid")==$fromid){
       $mdemo=$myimgdemo;
       $mdemo=$mdemo.replace("[imgurl]",$fileurl);
       $mdemo=$mdemo.replace("[myheadx]",$fromheadx);
    }else{
       $mdemo=$hisimgdemo;
       $mdemo=$mdemo.replace("[imgurl]",$fileurl);
       $mdemo=$mdemo.replace("[hisheadx]",$fromheadx);
       $mdemo=$mdemo.replace("[hisinfourl]","/localxres/pagex/2/workerchat/Go7G55/S5FHW0/friend.html?layid=Go7G55&tinyid=S5FHW0&fuid="+$fromid+"&rcode="+_get("rcode"));
    }
    break;
    case "jpeg":
    if (_cookie("uid")==$fromid){
       $mdemo=$myimgdemo;
       $mdemo=$mdemo.replace("[imgurl]",$fileurl);
       $mdemo=$mdemo.replace("[myheadx]",$fromheadx);
    }else{
       $mdemo=$hisimgdemo;
       $mdemo=$mdemo.replace("[imgurl]",$fileurl);
       $mdemo=$mdemo.replace("[hisheadx]",$fromheadx);
       $mdemo=$mdemo.replace("[hisinfourl]","/localxres/pagex/2/workerchat/Go7G55/S5FHW0/friend.html?layid=Go7G55&tinyid=S5FHW0&fuid="+$fromid+"&rcode="+_get("rcode"));
    }
    break;
    case "svg":
    if (_cookie("uid")==$fromid){
       $mdemo=$myimgdemo;
       $mdemo=$mdemo.replace("[imgurl]",$fileurl);
       $mdemo=$mdemo.replace("[myheadx]",$fromheadx);
    }else{
       $mdemo=$hisimgdemo;
       $mdemo=$mdemo.replace("[imgurl]",$fileurl);
       $mdemo=$mdemo.replace("[hisheadx]",$fromheadx);
       $mdemo=$mdemo.replace("[hisinfourl]","/localxres/pagex/2/workerchat/Go7G55/S5FHW0/friend.html?layid=Go7G55&tinyid=S5FHW0&fuid="+$fromid+"&rcode="+_get("rcode"));
    }
    break;
    case "bmp":
    if (_cookie("uid")==$fromid){
       $mdemo=$myimgdemo;
       $mdemo=$mdemo.replace("[imgurl]",$fileurl);
       $mdemo=$mdemo.replace("[myheadx]",$fromheadx);
    }else{
       $mdemo=$hisimgdemo;
       $mdemo=$mdemo.replace("[imgurl]",$fileurl);
       $mdemo=$mdemo.replace("[hisheadx]",$fromheadx);
       $mdemo=$mdemo.replace("[hisinfourl]","/localxres/pagex/2/workerchat/Go7G55/S5FHW0/friend.html?layid=Go7G55&tinyid=S5FHW0&fuid="+$fromid+"&rcode="+_get("rcode"));
    }
    break;
    case "png":
    if (_cookie("uid")==$fromid){
       $mdemo=$myimgdemo;
       $mdemo=$mdemo.replace("[imgurl]",$fileurl);
       $mdemo=$mdemo.replace("[myheadx]",$fromheadx);
    }else{
       $mdemo=$hisimgdemo;
       $mdemo=$mdemo.replace("[imgurl]",$fileurl);
       $mdemo=$mdemo.replace("[hisheadx]",$fromheadx);
       $mdemo=$mdemo.replace("[hisinfourl]","/localxres/pagex/2/workerchat/Go7G55/S5FHW0/friend.html?layid=Go7G55&tinyid=S5FHW0&fuid="+$fromid+"&rcode="+_get("rcode"));
    }
    break;
    case "mp4":
    if (_cookie("uid")==$fromid){
       $mdemo=$myvideodemo;
       $mdemo=$mdemo.replace("[videourl]",$fileurl);
       $mdemo=$mdemo.replace("[myheadx]",$fromheadx);
    }else{
       $mdemo=$hisvideodemo;
       $mdemo=$mdemo.replace("[videourl]",$fileurl);
       $mdemo=$mdemo.replace("[hisheadx]",$fromheadx);
       $mdemo=$mdemo.replace("[hisinfourl]","/localxres/pagex/2/workerchat/Go7G55/S5FHW0/friend.html?layid=Go7G55&tinyid=S5FHW0&fuid="+$fromid+"&rcode="+_get("rcode"));
    }
    break;
    default:
    if (_cookie("uid")==$fromid){
       $mdemo=$myothdemo;
       $mdemo=$mdemo.replace("[fileurl]",$fileurl);
       $mdemo=$mdemo.replace("[filename]",$fname);
       $mdemo=$mdemo.replace("[myheadx]",$fromheadx);
    }else{
       $mdemo=$hisothdemo;
       $mdemo=$mdemo.replace("[fileurl]",$fileurl);
       $mdemo=$mdemo.replace("[filename]",$fname);
       $mdemo=$mdemo.replace("[hisheadx]",$fromheadx);
       $mdemo=$mdemo.replace("[hisinfourl]","/localxres/pagex/2/workerchat/Go7G55/S5FHW0/friend.html?layid=Go7G55&tinyid=S5FHW0&fuid="+$fromid+"&rcode="+_get("rcode"));
    }
  }
  if ($fileurl!="" && $fromid!="" && $toid!="" && $fromheadx!="" && $toheadx!=""){
   return $mdemo;
  }else{
   return "";   
  }
}