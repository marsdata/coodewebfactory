<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $uid=$_GET["uid"];
$wrdid=$_GET["wrdid"];
function getchatroom($rcdx,$rinfo=array()){
 $crst=SX("select SNO,croommark,croomname,croomdescrib,circletotab,friendstab,groupstab,grplisttab,grprcdtab,chatpostab,chatrcdtab,chatusertab,collecttab,linkusertab,CRTM,UPTM,OLMK,bankselfaccount from worchat_chatroomlist where croommark='".$rcdx."'");
 $totcr=countresult($crst);
 
 if (intval($totcr)>0){
   
   $rinfo["dsno"]=anyvalue($crst,"SNO",0);
   $rinfo["title"]=anyvalue($crst,"croomname",0);
   $rinfo["describ"]=tostring(anyvalue($crst,"croomdescrib",0));
   $rinfo["circle"]=anyvalue($crst,"circletotab",0);
   $rinfo["friends"]=anyvalue($crst,"friendstab",0);
   $rinfo["groupd"]=anyvalue($crst,"groupstab",0);   
   $rinfo["grouplist"]=anyvalue($crst,"grplisttab",0);
   $rinfo["grprecord"]=anyvalue($crst,"grprcdtab",0);
   $rinfo["chatpos"]=anyvalue($crst,"chatpostab",0);
   $rinfo["chatrecord"]=anyvalue($crst,"chatrcdtab",0);
   $rinfo["chatuser"]=anyvalue($crst,"chatusertab",0);
   $rinfo["linkuser"]=anyvalue($crst,"linkusertab",0);
   $rinfo["collection"]=anyvalue($crst,"collecttab",0);
 }
 return $rinfo;
}
if ($uid!="" and $wrdid!=""){
  
  $ri=array();
  $ri=getchatroom($wrdid,$ri);
  $sqlc="select userid,departs,realname,vxuid,comid,sex,headpic,utel,nickname from coode_svsuser where userid='".$uid."' and wrdid='".$wrdid."'";
  $drst=SX($sqlc);
  $depart=anyvalue($drst,"departs",0);
  $realname=anyvalue($drst,"realname",0);
  $vxuid=anyvalue($drst,"vxuid",0);
  $comid=anyvalue($drst,"comid",0);
  $sex=anyvalue($drst,"sex",0);
  $headpic=anyvalue($drst,"headpic",0);
  $mobile=anyvalue($drst,"utel",0);
  $nickname=anyvalue($drst,"nickname",0);
  $extx=UZ("select count(*) as result from ".$ri["chatuser"]." where uid='".$uid."'");
  if ($extx*1==0){
   $sqla="uid,uname,vxuid,usex,uheadx,utel,unick,subpho,comid,CRTM,UPTM,OLMK,CRTOR,RIP";
   $sqlb="'".$uid."','".$realname."','".$vxuid."','".$sex."','".$headpic."','".$mobile."','".$nickname."','','".$comid."',now(),now(),RAND()*1000000,'".$_COOKIE["uid"]."','".getip()."'";
   $z=UZ("insert into ".$ri["chatuser"]."(".$sqla.")values( ".$sqlb.")");  
  
  }else{
   $nn=UZ("update ".$ri["chatuser"]." set comid='".$comid."',uname='".$realname."',usex='".$sex."',uheadx='".$headpic."',utel='".$mobile."',unick='".$nickname."',UPTM=now() where uid='".$uid."'");
  }
  echo makereturnjson("1","转入成功","");
}else{
  echo makereturnjson("0","参数不全",""); 
}
  
  
     session_write_close();
?>