<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $dbmarkx=dftval($_GET["dbmk"],"");
$stidx=dftval($_GET["stid"],"");
$tabolmk=dftval($_GET["tabolmk"],"");
$ak=dftval($_GET["ak"],"");
$av=dftval($_GET["av"],"");
//$arole=UX("select hostrolex as result from coode_scvuser where apikey='".$ak."' and apival='".$av."'");
$prst=SX("select dbmark,dbtabnm from coode_clientdataplan where dbmark='".$dbmarkx."' and shortid='".$stidx."'");
$totp=countresult($prst);
if (intval($totp)>0){   
     $tabnmx=anyvalue($prst,"dbtabnm",0);
     eval(RESFUNSET("tabbaseinfo"));
     $dinfo=array();     
     $dinfo=takedbinfo($dbmarkx,$tabnmx,$dinfo);
     $dbnmx=$dinfo["dbnm"];
     $dbip=$dinfo["fip"];
     $dbuser=$dinfo["fuser"];
     $dbpass=$dinfo["fpass"];
     $dbbase=$dinfo["fbase"];
     $pssno=$dinfo["mainsqx"];
     $psolmk=$dinfo["psolmk"];
     $conn=mysql_connect($dbip,$dbuser,$dbpass);
     $zz=updatings($conn,$dbbase,"delete from ".$tabnmx." where ".$psolmk."='".$tabolmk."'","utf8");
   //echo makereturnjson("1","删除成功","delete from ".$tabnmx." where ".$psolmk."='".$tabolmk."'");
   echo makereturnjson("1","删除成功","");
}else{ 
   echo makereturnjson("-1","无权操作","");
}
     session_write_close();
?>