<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $a=time();
$rsrst=SX("select SNO,rescodex,restitlex,restypes,brasetmark,dfdbmk,dfdbtab,dfdbsno,CRTM,UPTM,OLMK from coode_worldresdefine where STATUS=0 order by SNO limit 0,20");
$totr=countresult($rsrst);
if ($totr>0){
 for ($j=0;$j<$totr;$j++){
   $snox=anyvalue($rsrst,"SNO",$j);
   $rescodex=anyvalue($rsrst,"rescodex",$j);
   $restitlex=anyvalue($rsrst,"restitlex",$j);
   $restypes=anyvalue($rsrst,"restypes",$j);
   $brasetmark=anyvalue($rsrst,"brasetmark",$j);
   $dfdbmk=anyvalue($rsrst,"dfdbmk",$j);
   $dfdbtab=anyvalue($rsrst,"dfdbtab",$j);
   $dfdbsno=anyvalue($rsrst,"dfdbsno",$j);
   $nd=file_get_contents(combineurl("http://".glw(),"/localxres/funx/compdata/?SNO=".$snox));
   $md=json_decode($nd,false);
   $sqlx="rescode,restitle,restypes,dfdbmk,dfdbtab,dfdbsno,compstt,runmsg,runtime,runmachine,tobsmark,CRTM,UPTM,OLMK";
   $sqly="'$rescodex','$restitlex','".$restypes."','$dfdbmk','$dfdbtab','$dfdbsno','".$md->status."','".$md->msg."',now(),'".getip()."','".$brasetmark."',now(),now(),'".onlymark()."'";
   $zz=UX("insert into coode_ressameblog(".$sqlx.")values(".$sqly.")");   
 }
 $b=time();
 $totx=UX("select count(*) as result from coode_worldresdefine where STATUS=0 ");
 echo makereturnjson("1","同步成功耗时-".($b-$a)."秒","剩余:".$totx);
}else{
 echo makereturnjson("0","无任务","");
}
     session_write_close();
?>