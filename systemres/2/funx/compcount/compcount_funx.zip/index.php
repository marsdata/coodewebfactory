<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $tpcd=dftval(_get("tpcd"),"");
$tprst=SX("select bgrpmark,bgrptitle from coode_wrdrestporg where typecodex='".$tpcd."'");
$tottp=countresult($tprst);
$item='{"tabnm":"[tabnm]","tabtitle":"[tabtitle]","fnsnum":"[fnsnum]"},';
$fmi="";
if ($tottp>0){
 for ($j=0;$j<$tottp;$j++){
  $itemx=$item;
  $tabnm=anyvalue($tprst,"bgrpmark",$j);
  $tabtt=anyvalue($tprst,"bgrptitle",$j);
  $dnum=UX("select count(*) as result from coode_ressameblog where tobsmark like '%".$tabnm."%'");
  $itemx=str_replace("[tabnm]",$tabnm,$itemx);
  $itemx=str_replace("[tabtitle]",$tabtt,$itemx);
  $itemx=str_replace("[fnsnum]",$dnum,$itemx);
  $fmi=$fmi.$itemx;
 }
 $fmi=killlaststr($fmi);
 echo '{"status":"1","msg":"成功","vls":['.$fmi.']}';
}else{
 echo '{"status":"0","msg":"失败","vls":[]}';
}
     session_write_close();
?>