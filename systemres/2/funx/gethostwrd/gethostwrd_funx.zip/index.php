<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $mthost=glm();
if (glm()!="mother"){
 $kk=UX("delete from coode_hostregwrd");
 $nn=anyfunrun("retabsno","","tabnm=coode_hostregwrd","");
 $sysdata=anyfunrun("anyshort",$mthost,"stid=wDCl58&pnum=999&page=1&datatype=json","");
 $datax=json_decode($sysdata,false);
 $vlx=$datax->vls;
 $sqla="host,wrdid,wrdname,devehead,deveman,describ,headpic,midpic,hostver,STATUS,STCODE,CRTM,UPTM,OLMK,CRTOR";
 for ($jj=0;$jj<count($vlx);$jj++){
  $host=$vlx[$jj]->host;
  $sysid=$vlx[$jj]->wrdid;
  $sysname=$vlx[$jj]->wrdname;
  $devehead=$vlx[$jj]->devehead;
  $deveman=$vlx[$jj]->deveman;
  $describ=$vlx[$jj]->describ;
  $midpic=$vlx[$jj]->midpic;
  $hdpic=$vlx[$jj]->headpic;
  $stt=$vlx[$jj]->STATUS;
  $stcode=$vlx[$jj]->STCODE;
  
   if (strpos($hdpic,"//")>0){
     $headpic=$hdpic;
   }else{
     $headpic=combineurl("http://".$host,$hdpic);
   }
  
  $hostver=$vlx[$jj]->hostver;
  $sqlb="'$host','$wrdid','$wrdname','$devehead','$deveman','$describ','$headpic','$midpic','$hostver','".$stt."','".$stcode."',now(),now(),'".onlymark()."','system'";
  $zzz=UX("insert into coode_hostregwrd(".$sqla.")values(".$sqlb.")"); 
 }
 $nn=UX("update coode_hostregwrd set PRIME=0 ");
 $nn=UX("update coode_hostregwrd set PRIME=1 where wrdid in(select worldcode from coode_worlddefine)");
 $nn2=UX("update coode_hostregwrd,coode_worlddefine set coode_hostregwrd.thisver=coode_worlddefine.datamark where coode_hostregwrd.wrdid=coode_worlddefine.worldcode");
   echo makereturnjson("1","获取成功","");
 }else{
   echo makereturnjson("0","本机为主机","");
 }
     session_write_close();
?>