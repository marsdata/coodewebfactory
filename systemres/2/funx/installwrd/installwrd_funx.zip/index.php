<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     eval(RESFUNSET("resrelyrp"));
eval(RESFUNSET("tabdataoprt"));
eval(RESFUNSET("dspbasecoprt"));
   $fromhost=$_GET["fromhost"];
   $restype=$_GET["restype"];
   $rescode=$_GET["rescode"];
   $sysid=dftval($_GET["sysid"],$_GET["wrdid"]);
   $cloud=$_GET["cloud"];
function tornx($txx){
  if ($txx==true){
   return 1;
  }else{
   return 0;
  }
}
$succx=0;
if (es($fromhost)*es($restype)*es($rescode)==1){
   if (strpos($fromhost,":")>0){
     $dkh=hou($fromhost,":");
   }else{
     $dkh="";
   }
   if ($dkh=="443"){
     $reshost="https://".qian($fromhost,":");
   }else{
     $reshost="http://".$fromhost;
   }
    $resurl=combineurl($reshost,"/systemres/".$sysid."/".$restype."/".str_replace(".","_",$rescode)."/".str_replace(".","_",$rescode)."_".$restype.".zip");
    $newurl=combineurl(localroot(),"/remotexres/receive/".$restype."/".str_replace(".","_",$rescode)."_".$restype.".zip");
    $newpath=combineurl(localroot(),"/remotexres/receive/".$restype."/".qian($rescode,".")."/");
    $tarpath=combineurl(localroot(),"/localxres/".$restype."/".qian($rescode,".")."/"); 
   $err="";
    $kk=unlink($newurl);
    $kk2=deltree($newpath);
 if ((remotefilesize($resurl)*1/1000000)<=12){
  if (downanyfile($resurl,$newurl)==true){
     $zz=unzip($newurl,$newpath);
     //unlink($newurl);
      $jsonf=combineurl(localroot(),"/remotexres/receive/".$restype."/".qian($rescode,".")."/".str_replace(".","_",$rescode)."_".$restype."-resdata.json");
      $uu=takevaljson($jsonf);
      $succx=$succx+tornx($uu);
 
    if ($tarpath!=""){    
     $zz=copy_underdir($newpath,$tarpath);     
    }  
   $insmark=_get("insmark");
   if ($insmark!=""){
    $zz=UX("update coode_installdetail set STATUS=1,thisver='".$vvvmd5."' where insmark='".$insmark."' and rescode='".$rescode."' and restype='".$restype."'");
    $zz=UX("update coode_installidx set succnum=succnum+1 where insmark='".$insmark."'");
   }
   echo makereturnjson("1","成功安装".$succx."条。".$err,"");     
  }else{
   $err="下载资源失败；";
   $tarpath="";
    if ($insmark!=""){   
     $zz=UX("update coode_installdetail set STATUS=1,STCODE='下载失败',thisver='".$vvvmd5."' where insmark='".$insmark."' and rescode='".$rescode."' and restype='".$restype."'");
     $zz=UX("update coode_installidx set failnum=failnum+1 where insmark='".$insmark."'");
    }
    echo makereturnjson("0","安装失败-下载失败-".$fromhost."/".$restype."/".$rescode,"");   
  }
 }else{
     $err="下载资源失败-超过12M";
    $tarpath="";
    if ($insmark!=""){   
     $zz=UX("update coode_installdetail set STATUS=1,STCODE='资源过大',thisver='".$vvvmd5."' where insmark='".$insmark."' and rescode='".$rescode."' and restype='".$restype."'");
     $zz=UX("update coode_installidx set failnum=failnum+1 where insmark='".$insmark."'");
    }
    echo makereturnjson("0","安装失败-文件太大-".$fromhost."/".$restype."/".$rescode,"");   
 }
    
}else{
  if ($insmark!=""){   
    $zz=UX("update coode_installdetail set STATUS=1,STCODE='参数不全',thisver='".$vvvmd5."' where insmark='".$insmark."' and rescode='".$rescode."' and restype='".$restype."'");
    $zz=UX("update coode_installidx set failnum=failnum+1 where insmark='".$insmark."'");
  }
  echo makereturnjson("0","安装失败-参数不全-".$fromhost."/".$restype."/".$rescode,"");
}
     session_write_close();
?>