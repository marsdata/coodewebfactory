<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $uid=$_GET["uid"];
if ($uid!=""){
  $urst=SX("select realname,headpic,scvid,email,mobile,qq,sex,nickname from coode_userlist where userid='".$uid."'");
  $realname=anyvalue($urst,"realname",0);
  $headpic=anyvalue($urst,"headpic",0);
  $realname=anyvalue($urst,"realname",0);
  $scvid=anyvalue($urst,"scvid",0);
  $email=anyvalue($urst,"email",0);
  $mobile=anyvalue($urst,"mobile",0);
  $qq=anyvalue($urst,"qq",0);
  $sex=anyvalue($urst,"sex",0);
  $nickname=anyvalue($urst,"nickname",0);
  if (strpos($scvid,",")>0){
    $ptscv=explode(",",$scvid);
    $totp=count($ptscv);
    for ($jj=0;$jj<$totp;$jj++){
     $extu=UX("select count(*) as result from coode_svsuser where comid='".$ptscv[$jj]."' and userid='".$uid."'");
     if ($extu*1==1 ){
      if ($ptscv[$jj]!=""){
       $nn=UX("update coode_svsuser set UPTM=now(),nickname='".$nickname."',realname='".$realname."',sex='".$sex."',utel='".$mobile."',email='".$email."',pynick='".chitopy($realname)."',headpic='".$headpic."' where comid='".$ptscv[$jj]."' and userid='".$uid."'");
      }
     }else{//ifextu
       if ($ptscv[$jj]!=""){
        $sqlx="userid,nickname,headpic,realname,comid,sex,utel,email,pynick,OLMK,CRTM,UPTM";
        $sqly="'".$uid."','".$nickname."','".$headpic."','".$realname."','".$ptscv[$jj]."','".$sex."','".$mobile."','".$email."','".chitopy($realname)."','".onlymark()."',now(),now()";
        $zz=UX("insert into coode_svsuser(".$sqlx.")values(".$sqly.")");
       }//ifpt
     }//ifextu
    }//for
  }else{
   if ($scvid!=""){
     $extu=UX("select count(*) as result from coode_svsuser where comid='".$scvid."' and userid='".$uid."'");
     if ($extu*1==1 ){
       $nn=UX("update coode_svsuser set UPTM=now(),nickname='".$nickname."',realname='".$realname."',sex='".$sex."',utel='".$mobile."',email='".$email."',pynick='".chitopy($realname)."',headpic='".$headpic."' where comid='".$scvid."' and userid='".$uid."'");
     }else{
        $sqlx="userid,nickname,headpic,realname,comid,sex,utel,email,pynick,OLMK,CRTM,UPTM";
        $sqly="'".$uid."','".$nickname."','".$headpic."',".$realname.",'".$scvid."','".$sex."','".$mobile."','".$email."','".chitopy($realname)."','".onlymark()."',now(),now()";
        $zz=UX("insert into coode_svsuser(".$sqlx.")values(".$sqly.")");       
     }
   }//if scvid
  }//if scv,
  $zzz=UX("update coode_svsuser,coode_comuser set coode_svsuser.wrdid=coode_comuser.wrdid where coode_svsuser.comid=coode_comuser.comid");
 echo makereturnjson("1","推送成功",""); 
}else{//ifuid
 echo makereturnjson("0","参数不全","");
}//if uid
     session_write_close();
?>