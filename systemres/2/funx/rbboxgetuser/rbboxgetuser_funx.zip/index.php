<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $ptel=$_GET["ptel"];
$drst=SX("select realname,depart,passwd,userid,wrdid,headpic,nickname,business,apiKey from coode_userlist where userid='".$ptel."'");
$totd=countresult($drst);
$grpmng=anyvalue($drst,"authorize",0);
$ops=anyvalue($drst,"passwd",0);
if (intval($totd)>0 and strpos($drst,"报错")<=0){
  echo "{\"uname\":\"".anyvalue($drst,"realname",0)."\",\"business\":\"".anyvalue($drst,"business",0)."\",\"sth\":\"".date("H")."\",\"workot\":\"".$wot."\",\"haspass\":\"".$haspass."\",\"signstate\":\"".$sttt."\",\"userid\":\"".$ptel."\",\"comid\":\"".anyvalue($drst,"comid",0)."\",\"usex\":\"".anyvalue($drst,"sex",0)."\",\"age\":\"0\",\"pdepart\":\"".anyvalue($drst,"depart",0)."\",\"groupmng\":\"".anyvalue($drst,"authorize",0)."\",\"uheadx\":\"".anyvalue($drst,"headpic",0)."\",\"nickname\":\"".anyvalue($drst,"nickname",0)."\",\"last3\":\"\",\"apikey\":\"".anyvalue($drst,"apikey",0)."\"}";
}else{
  echo "{\"uname\":\"\",\"sth\":\"".date("H")."\",\"business\":\"\",\"workot\":\"\",\"haspass\":\"\",\"signstate\":\"\",\"userid\":\"\",\"comid\":\"\",\"usex\":\"\",\"age\":\"0\",\"pdepart\":\"\",\"groupmng\":\"\",\"uheadx\":\"\",\"nickname\":\"\",\"last3\":\"\",\"apikey\":\"\"}";
}
     session_write_close();
?>