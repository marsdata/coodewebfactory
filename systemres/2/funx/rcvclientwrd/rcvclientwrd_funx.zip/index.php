<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $wrdcode=dftval($_POST["wrdcode"],"");
$wrdname=dftval($_POST["wrdname"],"");
$passwd=dftval($_POST["passwd"],"");
$asktel=dftval($_POST["asktel"],"");
$email=dftval($_POST["email"],"");
$apiky=dftval($_GET["ak"],"");
$apivy=dftval($_GET["av"],"");
if (verifyscv($apiky,$apivy)){
 if (es($wrdcode)*es($wrdname)*es($passwd)*es($asktel)==1){
  $extb=UX("select count(*) as result from coode_worlddefine where worldcode='".$wrdcode."'");
  if (intval($extb)==0){
    $sqla="worldcode,worldtitle,passwordx,emailx,regmobile,headimg,worldtype,CRTOR,CRTM,UPTM,OLMK,CRTOR";
    $sqlb="'$wrdcode','$wrdname','$passwd','$email','$asktel','/localxres/iconsetx/restype/myworld.png','-1','".$asktel."',now(),now(),'".onlymark()."','".$asktel."'";
    $zz=UX("insert into coode_worlddefine(".$sqla.")values(".$sqlb.")");
    echo makereturnjson("1","申请成功","");
  }else{
    echo makereturnjson("0","申请失败，该世界已存在","");
  }
 }else{
  echo makereturnjson("0","失败,缺少参数","");
 }
}else{
 echo makereturnjson("-1","客户端不在服务期","");
}
     session_write_close();
?>