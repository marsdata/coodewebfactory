<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $wrdid=$_GET["wrdid"];
$myhost=$_POST["myhost"];
$wrdname=$_POST["wrdname"];
$vermd5=$_POST["vermd5"];
$faceimg=$_POST["faceimg"];
$qnycode=$_POST["qnycode"];
$rnm=$_POST["rnm"];
$vxpic=$_POST["vxpic"];
if (strpos($vxpic,"//")>0){
}else{
  $vxpic=combineurl("http://".$myhost,$vxpic);
}
$extx=UX("select count(*) as result from coode_hostregwrd where wrdid='".$wrdid."' and host='".$myhost."'");
if (intval($extx)==0){
  $sqla="host,wrdid,wrdname,devehead,deveman,headpic,midpic,hostver,CRTM,UPTM,OLMK,CRTOR,describ,relycore";
  $sqlb="'".$myhost."','".$wrdid."','".$wrdname."','".$vxpic."','".$rnm."','".combineurl("http://".$myhost,$faceimg)."','".$faceimg."','".$vermd5."',now(),now(),'".onlymark()."','hellowocao','','".$qnycode."'";
  $zz=UX("insert into coode_hostregwrd(".$sqla.")values(".$sqlb.")");
  echo makereturnjson("1","提交成功","");
}else{
  $exty=UX("select count(*) as result from coode_hostregwrd where wrdid='".$wrdid."' and host='".$myhost."' and STATUS=-1");
  if (intval($exty)==1){      
      $yy=UX("select STCODE as result from coode_hostregwrd where wrdid='".$wrdid."' and host='".$myhost."' and STATUS=-1");    
      echo makereturnjson("-1","更新失败，黑名单(".$yy.")","");    
  }else{
      $zz=UX("update coode_hostregwrd set deveman='".$rnm."',devehead='".$vxpic."',STATUS=0,UPTM=now(),wrdname='".$wrdname."',relycore='".$qnycode."',describ='',headpic='".combineurl("http://".$myhost,$faceimg)."',hostver='".$vermd5."' where host='".$myhost."' and wrdid='".$wrdid."'");
      echo makereturnjson("1","更新成功","");
  }
}
$nn=UX("update coode_hostregwrd set PRIME=0 ");
$nn=UX("update coode_hostregwrd set PRIME=1 where wrdid in(select worldcode from coode_worlddefine)");
     session_write_close();
?>