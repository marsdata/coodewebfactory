<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     eval(RESFUNSET("tabdataoprt"));
$restype=dftval($_GET["restype"],"");
$wrdidx=dftval($_GET["wrdid"],"");
$rescode=dftval($_GET["rescode"],"");
$zz=UX("update coode_wrdregres set STATUS=-2,UPTM=now() where restype='".$restype."' and resmark='".$rescode."' and grpid='".$wrdidx."'");
if (es($restype)*es($wrdidx)*es($rescode)==1){
 $fpath=combineurl(localroot(),"/worldxres/".$wrdidx."/".$restype."/".$rescode."");
 $kk=deltree($fpath);
 $srd='{"status":"1","rtype":"[rtype]","rcode":"[rcode]","rtitle":"[rtitle]","ver":"[ver]","vls":[<data>]}';
 $item='{"restype":"[restype]","rescode":"[rescode]","resmd5":"[resmd5]","restitle":"[restitle]","resurl":"[resurl]"},'; 
 $tprst=SX("select SNO,tabtype,typetitlex,linemark,objmarks from coode_wrdrestpdefine where typecodex='".$restype."'");
 $snox=anyvalue($tprst,"SNO",0);
 $tabtype=anyvalue($tprst,"tabtype",0);
 $typetitlex=anyvalue($tprst,"typetitlex",0);
 $linemark=anyvalue($tprst,"linemark",0);
 $tabrst=SX("select srckey,srcttk,md5key,contentkeys from coode_tablist where TABLE_NAME='".$linemark."'");
 $srckey=anyvalue($tabrst,"srckey",0);
 $srcttk=anyvalue($tabrst,"srcttk",0);
 $md5key=anyvalue($tabrst,"md5key",0);
 $ckeys=anyvalue($tabrst,"contentkeys",0);
 $ckeys=str_replace(",".$md5key,"",$ckeys);
 $nnn=UX("update ".$linemark." set ".$md5key."=md5(concat(".$ckeys.")) where ".$srckey."='".$rescode."'");
 $vmd5=UX("select ".$md5key." as result from ".$linemark."  where ".$srckey."='".$rescode."'");
 $zz=UX("update coode_wrdregres set vermd5='".$vmd5."' where restype='".$restype."' and resmark='".$rescode."'");
 $resrst=SX("select ".$srckey.",".$srcttk.",".$md5key." from ".$linemark." where ".$srckey."='".$rescode."'");
 $restitle=anyvalue($resrst,$srcttk,0);
 $ver=anyvalue($resrst,$md5key,0);
 $objmarks=anyvalue($tprst,"objmarks",0);
 $fmitem="";  
  $itemx=$item;
  
  $jpath=makevaljson($restype,date("YmdHis"),"coode_wrdrestpdefine",$snox);  
  $vmd5=md5(file_get_contents($jpath));
  $jfile=combineurl(localroot(),"/worldxres/".$wrdidx."/".$restype."/".$rescode."/".$vmd5.".json"); 
  if ($jpath!=""){
    $zzj=overfile($jfile,file_get_contents($jpath));
  }
  $itemx=str_replace("[restype]","typecode",$itemx);
  $itemx=str_replace("[rescode]",$restype,$itemx);
  $itemx=str_replace("[resmd5]",$vmd5,$itemx);
  $itemx=str_replace("[restitle]",$typetitlex,$itemx);
  $itemx=str_replace("[resurl]",$jpath,$itemx);
  $fmitem=$fmitem.$itemx;
 switch($tabtype){
   case "1":
   break;
   case "xp":
   if (strpos($objmarks,",")>0){
    $ptobj=explode(",",$objmarks);
    for ($jj=0;$jj<count($ptobj);$jj++){     
     if ($ptobj[$jj]!=""){
      $tabrst=SX("select srckey,srcttk,md5key,parreskey from coode_tablist where TABLE_NAME='".$ptobj[$jj]."'");
      $srckey=anyvalue($tabrst,"srckey",0);
      $parreskey=anyvalue($tabrst,"parreskey",0);
      $srcttk=anyvalue($tabrst,"srcttk",0);
      $md5key=anyvalue($tabrst,"md5key",0);
      $resrst=SX("select SNO,".$srckey.",".$srcttk.",".$md5key." from ".$ptobj[$jj]." where ".$parreskey."='".$rescode."'");
      $totres=countresult($resrst);
     for ($kk=0;$kk<$totres;$kk++){
       $snoy=anyvalue($resrst,"SNO",$kk);
       $rescd=anyvalue($resrst,$srckey,$kk);
       $restt=anyvalue($resrst,$srcttk,$kk);
       
       $itemx=$item;   
       $jpath=makevaljson($restype,date("YmdHis"),$ptobj[$jj],$snoy);  
       $vmd5=md5(file_get_contents($jpath));
       $jfile=combineurl(localroot(),"/worldxres/".$wrdidx."/".$restype."/".$rescode."/".$vmd5.".json"); 
       if ($jpath!=""){
         $zzj=overfile($jfile,file_get_contents($jpath));
       }
       $itemx=str_replace("[restype]",$rescode,$itemx);
       $itemx=str_replace("[rescode]",$rescd,$itemx);
       $itemx=str_replace("[resmd5]",$vmd5,$itemx);
       $itemx=str_replace("[restitle]",$restt,$itemx);
       $itemx=str_replace("[resurl]",$jpath,$itemx);
       $fmitem=$fmitem.$itemx;
      }//forkk     
     }//ifptobj
    }//forjj
   }else{
    if ($objmarks!=""){
     $tabrst=SX("select srckey,srcttk,md5key,parreskey from coode_tablist where TABLE_NAME='".$objmarks."'");
     $srckey=anyvalue($tabrst,"srckey",0);
     $parreskey=anyvalue($tabrst,"parreskey",0);
     $srcttk=anyvalue($tabrst,"srcttk",0);
     $md5key=anyvalue($tabrst,"md5key",0);
     $resrst=SX("select SNO,".$srckey.",".$srcttk.",".$md5key." from ".$ptobj[$jj]." where ".$parreskey."='".$rescode."'");
     $totres=countresult($resrst);
     for ($kk=0;$kk<$totres;$kk++){
       $snoy=anyvalue($resrst,"SNO",$kk);
       $rescd=anyvalue($resrst,$srckey,$kk);
       $restt=anyvalue($resrst,$srcttk,$kk);
       
       $itemx=$item;   
       $jpath=makevaljson($restype,date("YmdHis"),$ptobj[$jj],$snoy);  
       $vmd5=md5(file_get_contents($jpath));
       $jfile=combineurl(localroot(),"/worldxres/".$wrdidx."/".$restype."/".$rescode."/".$vmd5.".json"); 
       if ($jpath!=""){
         $zzj=overfile($jfile,file_get_contents($jpath));
       }
       $itemx=str_replace("[restype]",$rescode,$itemx);
       $itemx=str_replace("[rescode]",$rescd,$itemx);
       $itemx=str_replace("[resmd5]",$vmd5,$itemx);
       $itemx=str_replace("[restitle]",$restt,$itemx);
       $itemx=str_replace("[resurl]",$jpath,$itemx);
       $fmitem=$fmitem.$itemx;
     }     
    }
   }//ifobjmarks
   break;
   default: 
 }
  $fmitem=killlaststr($fmitem);
  $srd=str_replace("[rtype]",$restype,$srd);
  $srd=str_replace("[rcode]",$rescode,$srd);
  $srd=str_replace("[ver]",$ver,$srd);
  $srd=str_replace("<data>",$fmitem,$srd);
  $srd=str_replace("[rtitle]",$restitle,$srd);
  $resfile=combineurl(localroot(),"/worldxres/".$wrdidx."/".$restype."/".$rescode."/".$rescode."_".$restype."-relyres.json");
  $zzx=overfile($resfile,$srd);
  $dd=createdir(combineurl(localroot(),"/systemres/".$wrdidx."/".$restype."/".$rescode."/")); 
  $ffile=combineurl(localroot(),"/systemres/".$wrdidx."/".$restype."/".$rescode."/".$rescode."_".$restype.".zip");
  
  if (file_exists($ffile)){
   unlink($ffile);
   $mm=make_zip_file_for_folder($ffile, $fpath);
  }else{
   $mm=make_zip_file_for_folder($ffile, $fpath);
  }  
  echo makereturnjson("1","生成世界资源种子成功","");
}else{
  echo makereturnjson("0","缺少参数","");
}
$zz=UX("update coode_wrdregres set STATUS=1,UPTM=now() where restype='".$restype."' and resmark='".$rescode."' and grpid='".$wrdidx."'");
     session_write_close();
?>