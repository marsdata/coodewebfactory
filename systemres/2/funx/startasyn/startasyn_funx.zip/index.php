<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snox=$_GET["SNO"];
 if ($_SERVER['SERVER_PORT']=="80"){  
  $myhost=$_SERVER["HTTP_HOST"];
 }else{
  $myhost=$_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"];
 }
$srst=SX("select Fromhost,asynfuncode,asynfunurl,auditman from coode_asynrun where SNO=".$snox);
$host=anyvalue($srst,"Fromhost",0);
if ($myhost==$host){
  $host="";
}
$fid=anyvalue($srst,"asynfuncode",0);
$qry=anyvalue($srst,"asynfunurl",0);
$auditman=anyvalue($srst,"auditman",0);
$qry=str_replace(":","=",$qry);
$qry=str_replace("@","&",$qry);
$host=$_GET["host"];
if ($auditman==$_COOKIE["uid"]){
  $zz=UX("update coode_asynrun set runtime=now() where SNO=".$snox);
  $aa=time();
  echo anyfunrun($fid,$host,$qry,"");
  $bb=time();
  $zz=UX("update coode_asynrun set STATUS=1,costtime=".($bb-$aa)." where SNO=".$snox);
}else{
  echo makereturnjson("0","无权执行","");
}
     session_write_close();
?>