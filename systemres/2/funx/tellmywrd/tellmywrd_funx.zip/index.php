<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
      if ($_SERVER['SERVER_PORT']=="80"){  
  $myhost=$_SERVER["HTTP_HOST"];
 }else{
  $myhost=$_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"];
 }
 $wrdid=$_GET["wrdid"];
 $srst=SX("select worldcode,worldtitle,datamark,headimg from coode_worlddefine where worldcode='".$wrdid."'");
 $wrdname=anyvalue($srst,"worldtitle",0);
 $vermd5=anyvalue($srst,"datamark",0);
 $faceimg=anyvalue($srst,"headimg",0);
 
 $urst=SX("select realname,vxpic from coode_userlist where userid='".$_COOKIE["uid"]."'");
 $rnm=anyvalue($urst,"realname",0);
 $vxpic=anyvalue($urst,"vxpic",0);
 $qnycode=qian(garea(),"@");
 $bktxt=anyfunrun("rcvhostwrd",glm(),"wrdid=".$wrdid,"wrdname=".$wrdname."&rnm=".$rnm."&vxpic=".$vxpic."&myhost=".$myhost."&vermd5=".$vermd5."&faceimg=".$faceimg."&detail=".$detail."&qnycode=".$qnycode);
 $bkjson=json_decode($bktxt,false);
 if (intval($bkjson->status)==1){
    echo makereturnjson("1","提交成功","");    
 }else{
    $zz=UX("update coode_worlddefine set STCODE='".($bkjson->msg)."' where worldcode='".$wrdid."'");
    echo makereturnjson("0","提交失败","");    
 }
     session_write_close();
?>