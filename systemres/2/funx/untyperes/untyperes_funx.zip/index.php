<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $wrdidx=$_GET["wrdid"];
$restype=$_GET["restype"];
if ($wrdidx!="" and $restype!=""){
  $tt=anyfunrun("tellmywrd","","wrdid=".$wrdidx,"");
  $tprst=SX("select headicon,headimg,linemark,tabtype,objmarks from coode_wrdrestpdefine where worldmarks='".$wrdid."' and typecodex='".$restype."'");
    $lmark=anyvalue($tprst,"linemark",0);
    $omarks=anyvalue($tprst,"objmarks",0);
    $kk=UX("delete from coode_wrdregres where restype='".$restype."' and grpid='".$wrdidx."'");
    $nn=anyfunrun("retabsno","","tabnm=coode_wrdregres","");
    $nn=UX("delete from ".$lmark);
    $nn=anyfunrun("retabsno","","tabnm=".$lmark,"");
    if (strpos($omarks,",")>0){
      $ptomk=explode(",",$omarks);
      for ($jj=0;$jj<count($ptomk);$jj++){
        $nn=UX("delete from ".$ptomk[$jj]);
        $nn=anyfunrun("retabsno","","tabnm=".$ptomk[$jj],"");       
      }
    }else{
      if ($omarks!=""){
        $nn=UX("delete from ".$omarks);
        $nn=anyfunrun("retabsno","","tabnm=".$omarks,"");
      }
    }
  $totres=UX("select count(*) as result from coode_wrdregres where grpid='".$wrdidx."'");  
  $nn=anyfunrun("retabsno","","tabnm=coode_wrdregres","");
   $ff=combineurl(localroot(),"/systemres/".$wrdidx."/".$wrdidx.".json");
   $gg=combineurl(localroot(),"/systemres/".$wrdidx."/install/resjar/".$wrdidx.".json");
   $datatxt=anyfunrun("anyshort","","stid=8jEKSz&pnum=9999&page=1&grpid=".$wrdidx,"");
   $zz1=overfile($gg,$datatxt);
   $zz2=overfile($ff,$datatxt);
  $zz=UX("update coode_worlddefine set datamark='".md5($datatxt)."',aboutres='".$totres."' where worldcode='".$wrdidx."'"); 
  echo makereturnjson("1","清空成功","");
}else{
  echo makereturnjson("0","清空失败，参数不全","");
}
     session_write_close();
?>