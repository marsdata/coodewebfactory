<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snox=_get("SNO");
$tabnm=_get("tabnm");
  if ($snox!="" and $tabnm!=""){    
     $tabrst=SX("select worldmarks,restpcode,srckey,mainsqx,srcttk,md5key,contentkeys from coode_tablist where TABLE_NAME='".$tabnm."'");
     $restype=anyvalue($tabrst,"restpcode",0);
     $wrdid=anyvalue($tabrst,"worldmarks",0);
     $srckey=anyvalue($tabrst,"srckey",0);
     $mainsqx=anyvalue($tabrst,"mainsqx",0);
     $srcttk=anyvalue($tabrst,"srcttk",0);
     $md5key=dftval(anyvalue($tabrst,"md5key",0),"VRT");
     $ckeys=anyvalue($tabrst,"contentkeys",0);
     $ckeys=str_replace(",".$md5key,"",$ckeys);
     $rescode=UX("select ".$srckey." as result from ".$tabnm." where ".$mainsqx."=".$snox);
     $nn1=UX("update ".$tabnm." set ".$md5key."=md5(concat(".$ckeys.")),PRIME=0 where ".$mainsqx."=".$snox);
     $nn2=UX("update ".$tabnm." set ".$md5key."=md5(concat(".$ckeys.")),itemCtPos=0 where ".$mainsqx."=".$snox);
     $zk=anyfunrun("saveinseed","","wrdid=".$wrdid."&restype=".$restype."&rescode=".$rescode,"");  
     $zp=anyfunrun("uprestoqny","","only=2&wrdid=".$wrdid."&restype=".$restype."&rescode=".$rescode,"");    
    echo  makereturnjson("1","升级成功","");
  }else{
    echo  makereturnjson("0","升级失败，参数不全","");
  }
     session_write_close();
?>