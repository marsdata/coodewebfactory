<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $appid = 'wx9f6f36a4ccd8eb89';
$appsecret = 'c1c63600aa3500b61e21d5fdf0fe47d9';
eval(CLASSX("vxposition"));
$vxp=new vxposition();
$fromurl=$_POST["fromurl"];
$furl=unstrs($fromurl);
$jsoncode=json_encode($vxp->getSignPackage($appid,$appsecret,$furl));
$jsoncode=str_replace("\\","",$jsoncode);
echo $jsoncode;
     session_write_close();
?>