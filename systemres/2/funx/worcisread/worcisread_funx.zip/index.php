<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $snos=$_GET["SNOS"];
$fmcdt="";
$rcode=_get("rcode");
$chattype=$_GET["chattype"];
$lon=$_GET["lon"];
$lat=$_GET["lat"];
eval(CLASSX("excoor"));
$ec=new excoor(); 
$newx=$ec->txtobaidu($lon,$lat);
$bjingdu=qian($newx,",");
$bweidu=hou($newx,",");
$fuid=$_GET["fuid"];
$crmx=$rcode;
eval(CLASSX("workerchat"));
$wct=new workerchat();
$crmy=array();
$crmy=$wct->chatroomdft($crmx,$crmy);
$c2tab=$crmy["c2tab"];
$fstab=$crmy["fstab"];
$gstab=$crmy["gstab"];
$gltab=$crmy["gltab"];
$grtab=$crmy["grtab"];
$cptab=$crmy["cptab"];
$crtab=$crmy["crtab"];
$cutab=$crmy["cutab"];
$lbtab=$crmy["lbtab"];
$cltab=$crmy["cltab"];
$sdtab=$crmy["sdtab"];
$astab=$crmy["astab"];
$shtab=$crmy["shtab"];
if ($lon!="" and $lat!="" and $fuid!=""){
    $uid=$_COOKIE["uid"];
    $sqlx="uid,uname,utel,depart,lon,lat,blon,blat,nickname,headpic,fuid,CRTM,UPTM,OLMK,RIP,CRTOR";
    $sqly="'".$uid."','".$realname."','".$mobile."','".$depart."','".$lon."','".$lat."','".$bjingdu."','".$bweidu."','".$nickname."','".$headpic."','".$fuid."',now(),now(),'".onlymark()."','".getip()."','".$_COOKIE["uid"]."'";
    $z=UX("insert into ".$cptab."(".$sqlx.")values(".$sqly.")");
    $bbb=UX("update ".$fstab.",".$cptab." set ".$cptab.".funame=".$fstab.".frienduname,".$cptab.".fheadpic=".$fstab.".frienduheadx,".$cptab.".fnickname=".$fstab.".friendunick,".$cptab.".fmobile=".$fstab.".friendutel where ".$fstab.".frienduid=".$cptab.".fuid ");
    $zz=UX("update ".$cptab.",".$cutab." set ".$cptab.".funame=".$cutab.".realname,".$cptab.".fdepart=".$cutab.".depart,".$cptab.".fheadpic=".$cutab.".headpic,".$cptab.".fnickname=".$cutab.".nickname,".$cptab.".fmobile=".$cutab.".mobile where ".$cutab.".userid=".$cptab.".fuid ");
    $zzz=UX("update ".$cptab.",".$cutab." set ".$cptab.".uname=".$cutab.".realname,".$cptab.".depart=".$cutab.".depart,".$cptab.".headpic=".$cutab.".headpic,".$cptab.".nickname=".$cutab.".nickname,".$cptab.".utel=".$cutab.".mobile where ".$cutab.".userid=".$cptab.".uid ");
    $cc=UX("update ".$cptab." set flon='".$lon."',flat='".$lat."',bflon='".$bjingdu."',bflat='".$bweidu."' where fuid='".$uid."' and flon='' and flat=''");
}
if ($snos!=""){
  $ptsno=explode(",",$snos);
  $totpt=count($ptsno);
  for ($i=0;$i<$totpt;$i++){
    if ($ptsno[$i]!=""){
      $fmcdt=$fmcdt." or SNO='".$ptsno[$i]."'";
    }
  }
  $fmcdt=substr($fmcdt,3,strlen($fmcdt)-3);
  if ($chattype=="grpchat"){
     $z=UX("update ".$grtab." set isread=1 where ".$fmcdt);
     $guid=UX("select groupid as result from ".$grtab."  where ".$fmcdt);
     $notr=intval(UX("select count(*) as result from ".$crtab." where touid='".$_COOKIE["uid"]."' and groupid='".$guid."' and isread=0"));
     $c=UX("update ".$fstab." set STATUS=1,PRIME='".$notr."' where uid='".$_COOKIE["uid"]."' and frienduid='".$guid."'");
  }else{
     $z=UX("update ".$crtab." set isread=1 where ".$fmcdt);
     $fromuid=UX("select fromuid as result from ".$crtab."  where ".$fmcdt);
     $notr=intval(UX("select count(*) as result from ".$crtab." where touid='".$_COOKIE["uid"]."' and fromuid='".$fromuid."' and isread=0"));
     $c=UX("update ".$fstab." set STATUS=1,PRIME='".$notr."' where uid='".$_COOKIE["uid"]."' and frienduid='".$fromuid."'");
  }
  echo "1";
}else{
  echo "0";
}
     session_write_close();
?>