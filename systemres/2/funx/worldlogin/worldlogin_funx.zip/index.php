<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $wrduid=dftval($_GET["wrduid"],"");
$wrdpass=dftval($_GET["wrdpass"],"");
$wrst=SX("select SNO,worldtitle,loginpage,regmobile from coode_worlddefine where worldcode='".$wrduid."' and passwordx='".$wrdpass."'");
$totw=countresult($wrst);
if (intval($totw)>0){
         $rtel=anyvalue($wrst,"regmobile",0);
         $wtitle=anyvalue($wrst,"worldtitle",0);
           setcookie("uid",$rtel,time()+3600,"/");                      
           setcookie("depart","gods",time()+3600,"/");           
           setcookie("roleids","god",time()+3600,"/");                  
           setcookie("deadline",time()+3600,time()+3600,"/");
           $stoken=md5($rtel.$wrduid.time());
           setcookie("stoken",$stoken,time()+3600,"/");            
            $rname=$wtitle;
            $comid=$wrduid;
            setcookie("cid",$comid,time()+3600,"/");
            $sqla="userid,realname,comid,sysid,depart,dpmore,posids,stoken,deadline,logintime,loginarea,fromdomain,CRTM,UPTM,OLMK,CRTOR";
            $sqlb="'".$uid."','".$rname."','".$comid."','".$wrduid."','".$depart."','','','".$stoken."',date_add(now(), interval 30 minute),now(),'','',now(),now(),'".onlymark()."','".$uidx."'";
            $c=UX("insert into coode_loginstoken(".$sqla.")values(".$sqlb.")");
  echo makereturnjson("1","登录成功","/localxres/pagex/2/wrproute/HR74SivJ/fqD2OG/index.html");
}else{
  echo makereturnjson("0","登录失败","");
}
     session_write_close();
?>