<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $wrdidx=$_GET["wrdid"];
$aa=time();
if ($wrdidx==""){
  $kk=UX("delete from coode_wrdregres");
  $nn=anyfunrun("retabsno","","tabnm=coode_wrdregres","");
  $tprst=SX("select worldmarks,headicon,headimg,typecodex,linemark,tabtype,objmarks from coode_wrdrestpdefine ");
  $tottp=countresult($tprst);
  for ($jj=0;$jj<$tottp;$jj++){
   $wmarks=anyvalue($tprst,"worldmarks",$jj);
   $hdicon=anyvalue($tprst,"headicon",$jj);
   $lmark=anyvalue($tprst,"linemark",$jj);
   $tpcode=anyvalue($tprst,"typecodex",$jj);
   $tabrst=SX("select tabnick,imghead,srckey,srcttk,md5key,contentkeys from coode_tablist where TABLE_NAME='".$lmark."'");
   $srckey=anyvalue($tabrst,"srckey",0);
   $srcttk=anyvalue($tabrst,"srcttk",0);
   $md5key=anyvalue($tabrst,"md5key",0);
   $imghead=anyvalue($tabrst,"imghead",0);
   $tabnick=anyvalue($tabrst,"tabnick",0);
   if ($md5key==""){
     $md5key="VRT";
   }
   if ($tabnick==""){
     $tabnick="STCODE";
   }
   if ($imghead==""){
     $imghead="'".$hdicon."'";
   }
   $ckeys=anyvalue($tabrst,"contentkeys",0);
   $ckeys=str_replace(",".$md5key,"",$ckeys);
   $nn=UX("update ".$lmark." set ".$md5key."=md5(concat(".$ckeys."))");
   if ($srckey!="" and $srcttk!=""){
    $sqla="grpid,resmark,restype,restitle,vermd5,headpic,funbody,CRTM,UPTM,OLMK,CRTOR";
    $sqlb="'".$wmarks."',".$srckey.",'".$tpcode."',".$srcttk.",".$md5key.",".$imghead.",".$tabnick.",now(),now(),md5(RAND()*100),'".$_COOKIE["uid"]."'";
    $zz=UX("insert into coode_wrdregres(".$sqla.")select ".$sqlb." from ".$lmark." where concat('".$tpcode."',".$srckey.") not in (select concat(restype,resmark) from coode_wrdregres)");    
   }
  }
}else{
  $tt=anyfunrun("tellmywrd","","wrdid=".$wrdidx,"");
  $kk=UX("delete from coode_wrdregres where grpid='".$wrdidx."'");
  $uu=UX("update coode_tablist,coode_shortdata set coode_shortdata.worldmarks=coode_tablist.worldmarks,coode_shortdata.restpcode=coode_tablist.restpcode where coode_shortdata.tablename=coode_tablist.TABLE_NAME");
  $tprst=SX("select worldmarks,headicon,headimg,typecodex,linemark,tabtype,objmarks from coode_wrdrestpdefine where worldmarks='".$wrdidx."'");
  $tottp=countresult($tprst);
  for ($jj=0;$jj<$tottp;$jj++){
   $wmarks=anyvalue($tprst,"worldmarks",$jj);
   $hdicon=anyvalue($tprst,"headicon",$jj);
   $lmark=anyvalue($tprst,"linemark",$jj);
   $tpcode=anyvalue($tprst,"typecodex",$jj);
   $tabrst=SX("select imghead,tabnick,srckey,srcttk,md5key,contentkeys from coode_tablist where TABLE_NAME='".$lmark."'");
   $srckey=anyvalue($tabrst,"srckey",0);
   $srcttk=anyvalue($tabrst,"srcttk",0);
   $md5key=anyvalue($tabrst,"md5key",0);
   $imghead=anyvalue($tabrst,"imghead",0);
   $tabnick=anyvalue($tabrst,"tabnick",0);
   if ($md5key==""){
     $md5key="VRT";
   }
   if ($tabnick==""){
     $tabnick="STCODE";
   }
   if ($imghead==""){
     $imghead="'".$hdicon."'";
   }
   $ckeys=anyvalue($tabrst,"contentkeys",0);
   $ckeys=str_replace(",".$md5key,"",$ckeys);
   $nn=UX("update ".$lmark." set ".$md5key."=md5(concat(".$ckeys."))");
   if ($srckey!="" and $srcttk!=""){
    $sqla="grpid,resmark,restype,restitle,vermd5,headpic,funbody,CRTM,UPTM,OLMK,CRTOR";
    $sqlb="'".$wmarks."',".$srckey.",'".$tpcode."',".$srcttk.",".$md5key.",".$imghead.",".$tabnick.",now(),now(),md5(RAND()*100),'".$_COOKIE["uid"]."'";
    $zz=UX("insert into coode_wrdregres(".$sqla.")select ".$sqlb." from ".$lmark." where concat('".$tpcode."',".$srckey.") not in (select concat(restype,resmark) from coode_wrdregres)");
    //$zz=UX("update coode_wrdregres set headpic='".$hdicon."' where headpic='' and restype='".$tpcode."' and grpid='".$wmarks."'");
   }
  }
  $totres=UX("select count(*) as result from coode_wrdregres where grpid='".$wrdidx."'");
  
  
   $ff=combineurl(localroot(),"/systemres/".$wrdidx."/".$wrdidx.".json");
   $gg=combineurl(localroot(),"/systemres/".$wrdidx."/install/resjar/".$wrdidx.".json");
   $datatxt=anyfunrun("anyshort","","stid=8jEKSz&pnum=9999&page=1&grpid=".$wrdidx,"");
   $zz1=overfile($gg,$datatxt);
   $zz2=overfile($ff,$datatxt);
  $zz=UX("update coode_worlddefine set datamark='".md5($datatxt)."',aboutres='".$totres."' where worldcode='".$wrdidx."'"); 
}
$bb=time();
echo makereturnjson("1","生成成功-耗时".($bb-$aa)."秒","");
     session_write_close();
?>