<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $askstr=unstrs($_POST["askstr"]);
$wrdsno=$_GET["wrdsno"];
$wrdid=UX("select worldcode as result from coode_worlddefine where SNO=".$wrdsno);
$slnum=dftval($_GET["slnum"],"50");
$csql=constval("bdrqtab");
$bdtab="bdairequest".date("Ym");
$csql=str_replace("[bdtab]",$bdtab,$csql);
$zz0=crttab(1,$csql);
$csql1=constval("asktab");
$asktab="wrdresnmask".date("Ym");
$csql1=str_replace("[asktab]",$asktab,$csql1);
$zz1=crttab(1,$csql1);
$arst=SZ("select typecodex,typetitlex,rescode,restitle,count(rescode) as totr,strnum,STCODE from ".$wrdid."_wrdresnmpoints where '".$askstr."' like concat('%',nmstr,'%') group by rescode order by totr desc limit 0,".$slnum);
//echo "select typecodex,typetitlex,rescode,restitle,count(rescode) as totr,strnum,STCODE from ".$wrdid."_wrdresnmpoints where '".$askstr."' like concat('%',nmstr,'%') group by rescode order by totr desc limit 0,".$slnum;
$tota=countresult($arst);
$demo='{"status":"1","msg":"获取成功","qrysql":"[qrysql]","rtnstr":"[rtnstr]","totx":"[totx]","resnames":[<resdata>]}';
$dataitem='{"tpcode":"[tpcode]","rescode":"[rescode]","numstr":"[numstr]","restitle":"[restitle]","headpic":"[headpic]","funbody":"[funbody]"},';
$fmdata="";
$fmchara="";
$fmcdx="";
$aistr="";
$strai="";
$aitt="";
$ord="";  
  $sqlx="strnum,askstr,typecodex,rescode,restitle,nmstr,CRTM,UPTM,OLMK";
  $sqly="'$i','$askstr','".$wrdsno."','".$wrdid."','".$wrdid."','".$slnum."',now(),now(),'".onlymark()."'";
  $zz=UZ("insert into ".$asktab."(".$sqlx.")values(".$sqly.")");
for ($i=0;$i<$tota;$i++){
  $tcodex=anyvalue($arst,"typecodex",$i);
  $titlex=anyvalue($arst,"typetitlex",$i);
  
  $rcodex=anyvalue($arst,"rescode",$i);
  $strai=$strai.$rcodex.",";
  $ord=$ord."'".$rcodex."',";
  $stcode=anyvalue($arst,"STCODE",$i);
  $fmcdx=$fmcdx."(restype='".$tcodex."' and resmark='".$rcodex."') or ";
  $chatab=$wrdid."_chara";
  $rtitlex=anyvalue($arst,"restitle",$i);
  $aitt=$aitt.$rtitlex.",";
  $totr=anyvalue($arst,"totr",$i);
  $aistr=$aistr.$totr.",";
  $strnum=anyvalue($arst,"strnum",$i);
}
$ord=killlaststr($ord);
$aistr=killlaststr($aistr);
$strai=killlaststr($strai);
$aitt=killlaststr($aitt);
$ptai=explode(",",$aistr);
$fmcdx=killlaststr($fmcdx);
$fmcdx=killlaststr($fmcdx);
$fmcdx=killlaststr($fmcdx);
$sqlz="select restype,resmark,restitle,headpic,funbody from coode_wrdregres where ".$fmcdx."  limit 0,".$slnum;
$brst=SX($sqlz);
$totb=countresult($brst);
for ($jj=0;$jj<$totb;$jj++){
  $itemx=$dataitem;
  $restype=anyvalue($brst,"restype",$jj);
  $rcodex=anyvalue($brst,"resmark",$jj);
  $headpic=anyvalue($brst,"headpic",$jj);
  $funbody=anyvalue($brst,"funbody",$jj);
  $rtitlex=anyvalue($brst,"restitle",$jj);
   
  $itemx=str_replace("[tpcode]",$restype,$itemx);
  $itemx=str_replace("[rescode]",$rcodex,$itemx);
  $itemx=str_replace("[restitle]",$rtitlex,$itemx);
  $itemx=str_replace("[headpic]",$headpic,$itemx);
  $itemx=str_replace("[funbody]",$funbody,$itemx);  
  $itemx=str_replace("[numstr]",$ptai[$jj],$itemx);  
  $fmdata=$fmdata.$itemx;
}
$fmdata=killlaststr($fmdata);
$demo=str_replace("<resdata>",$fmdata,$demo);
$demo=str_replace("[totx]",$totb,$demo);
$demo=str_replace("[qrysql]",gohex($sqlz),$demo);
$demo=str_replace("[rtnstr]",$aitt."_".$strai."|".$aistr,$demo);
echo $demo;
     session_write_close();
?>