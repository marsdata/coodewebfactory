<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
     $valstr=$_GET["valstr"];
$wrdid=qian($valstr,"@");
$sysid=$wrdid;
$host=hou($valstr,"@");
//执行完毕之后；等几秒钟继续重新执行；从index获取无任务跳转地址
$mftitle="任务标题";
$mfurl="";//跳转地址
$demo='{"status":"1","tasktitle":"'.$mftitle.'","rurl":"'.$mfurl.'","totrcd":"[totrcd]","vls":[<data>]}';
$item='{"purl":"[purl]","ptitle":"[ptitle]"},';
$fma="";
$datax=file_get_contents("http://".$host."/systemres/".$sysid."/".$sysid.".json");
$datay=json_decode($datax,false);
$totrcd=$datay->totrcd;
$vlx=$datay->vls;
     $tmptot=0;
     $tabnmx="coode_hostregres";
     $callfunname="gethostoneres";
     $tot=UX("select count(*) as result from ".$tabnmx." where host='".$host."' and grpid='".$sysid."'");     
     for ($i=$tot;$i<intval($totrcd);$i++){
       $resmark=$vlx[$i]->resmark;
       $restype=$vlx[$i]->restype;
       $restitle=$vlx[$i]->restitle;
       $vermd5=$vlx[$i]->vermd5;
       $urlx="/localxres/funx/".$callfunname."/?restype=".$restype."&resmark=".$resmark."&sysid=".$sysid."&host=".$host."&vermd5=".$vermd5."&restitle=".$restitle;
       $titlex="正在获取".$host."的".$restitle."资源";
       $olmkx=onlymark();
       $itemx=$item;
       $itemx=str_replace("[purl]",$urlx,$itemx);
       $itemx=str_replace("[ptitle]",$titlex,$itemx);
        
       $fma=$fma.$itemx;
       $tmptot=$tmptot+1;
     }
      if ($tot>0){
        $fma=killlaststr($fma);
      }
      $demo=str_replace("<data>",$fma,$demo);
      $demo=str_replace("[totrcd]",$tmptot,$demo);
      echo $demo;

     session_write_close();
?>