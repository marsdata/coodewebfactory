<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '[relycore]';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $valstr=dftval($_GET["valstr"],"");
//执行完毕之后；等几秒钟继续重新执行；从index获取无任务跳转地址
$mftitle="任务标题";
$mfurl="";//跳转地址
   $apistr=garea();
   $dmhost=qian($apistr,"@").".".$_SERVER["HTTP_HOST"];   
   $url1=combineurl(localroot(),"/systemres/".$valstr."/".$valstr.".json");
   $zz1=overfile($url1,anyfunrun("anyshort","","stid=8jEK5R&pnum=9999&page=1&grpid=".$valstr,""));
   $tt=anyfunrun("tellmywrd","","wrdid=".$valstr,"");
$first=anyfunrun("upresbyqny","","killhost=1&apistr=".$apistr."&qndm=".$dmhost."&lcfile=".$url1,"");
$demo='{"status":"1","valstr":"'.$valstr.'","tasktitle":"'.$mftitle.'","rurl":"'.$mfurl.'","totrcd":"[totrcd]","vls":[<data>]}';
$item='{"purl":"[purl]","ptitle":"[ptitle]"},';
$fma="";
     $tmptot=0;
     $tabnmx="coode_wrdregres";
     $callfunname="uprestoqny";
     $trst=SX("select SNO,grpid,restype,resmark,restitle,OLMK,CRTOR,STATUS from ".$tabnmx." where grpid='".$valstr."' and STATUS=1");
     $tot=countresult($trst);
     for ($i=0;$i<$tot;$i++){
       $snox=anyvalue($trst,"SNO",$i);
       $olmk=anyvalue($trst,"OLMK",$i);
       $wrdid=anyvalue($trst,"grpid",$i);
       $restype=anyvalue($trst,"restype",$i);
       $rescode=anyvalue($trst,"resmark",$i);
       $restitle=anyvalue($trst,"restitle",$i);
       $urlx="/localxres/funx/".$callfunname."/?killhost=1&wrdid=".$wrdid."&restype=".$restype."&rescode=".$rescode."&snox=".$snox."&olmkx=".$olmk."&ssmarkx=".$ssmark;
       $titlex="正在将类型为".$restype."的".$restitle."上传到七牛云";
       $olmkx=onlymark();
       $itemx=$item;
       $itemx=str_replace("[purl]",$urlx,$itemx);
       $itemx=str_replace("[ptitle]",$titlex,$itemx);
        
       $fma=$fma.$itemx;
       $tmptot=$tmptot+1;
     }
      if ($tot>0){
        $fma=killlaststr($fma);
      }
      $demo=str_replace("<data>",$fma,$demo);
      $demo=str_replace("[totrcd]",$tmptot,$demo);
      echo $demo;

       session_write_close();
?>