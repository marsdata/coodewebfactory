kbase=new Array();
kbase["COLUMN"]=new Array();
kbase["COLUMN"]["SEQUENCE"]="+";
kbase["COLUMN"]["COLUMN_TPLEN"]="0";
kbase["COLUMN"]["READONLY"]="";
versioninfo="updatetime:2026-01-21 00:34:41";