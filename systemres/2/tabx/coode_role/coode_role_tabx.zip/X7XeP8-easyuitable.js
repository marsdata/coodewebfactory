






obj={        find:function () {
                $("#table").datagrid('load',{
                        
                })
                
        },
      addBox:function () {
                $("#addBox").dialog({
                        closed: false
                });                
               $.ajax({
                       url:'/localxres/funx/easyuidetail/?stid=X7XeP8&id=0&dbnm='+dftval(GetRequest().dbnm,"")+'&laydb='+dftval(GetRequest().laydb,"")+makeurlqry(),
                       type:'post',
                       dataType:'json',
                       success:function (res) {
                               if(res){
                                       var data=res.rows;
                                       $.each(data,function (index) {
                                               id=intval(data[index].id);
                                               if(0==id){
                                                       $('#addForm').form('load',{
                                                              id:id,p_roleid0:data[index].roleid,p_roletitle0:data[index].roletitle,p_roledescrib0:data[index].roledescrib,p_sysid0:data[index].sysid,p_cid0:data[index].cid,p_OLMK0:data[index].OLMK,p_OPRT0:data[index].OPRT
                                                       })                                                       
                                               }
                                       })
                               }
                       },
                       error:function () {
                               $.messager.show({
                                       title:'提示',
                                       msg:'更新失败'
                               })
                       }
               })
        },
        edit:function (id) {
                var ID;
                $("#addBox").dialog({
                        closed:false
                })
               $.ajax({
                       url:'/localxres/funx/easyuidetail/?stid=X7XeP8&id='+id+'&dbnm='+dftval(GetRequest().dbnm,"")+'&laydb='+dftval(GetRequest().laydb,""),
                       type:'post',
                       dataType:'json',
                       success:function (res) {
                               if(res){
                                       var data=res.rows;
                                       $.each(data,function (index) {
                                               ID=intval(data[index].id);
                                               if(id==ID){
                                                       $('#addForm').form('load',{
                                                              id:id,p_roleid0:data[index].roleid,p_roletitle0:data[index].roletitle,p_roledescrib0:data[index].roledescrib,p_sysid0:data[index].sysid,p_cid0:data[index].cid,p_OLMK0:data[index].OLMK,p_OPRT0:data[index].OPRT
                                                       })                                                       
                                               }
                                       })
                               }
                       },
                       error:function () {
                               $.messager.show({
                                       title:'提示',
                                       msg:'更新失败'
                               })
                       }
               })
        },
       sum:function () {
                $("#addForm").form('submit',{
                        url:"/localxres/funx/easyuircv/?stid=X7XeP8&id="+dftval($("#id").val(),"")+"&dbnm="+dftval(GetRequest().dbnm,"")+'&laydb='+dftval(GetRequest().laydb,""),
                        onSubmit:function () {
                                return $(this).form('validate')
                        },
                        success:function (data) {
                                roleid0=$("#p_roleid0").val();roletitle0=$("#p_roletitle0").val();roledescrib0=$("#p_roledescrib0").val();sysid0=$("#p_sysid0").val();cid0=$("#p_cid0").val();OLMK0=$("#p_OLMK0").val();OPRT0=$("#p_OPRT0").val();
                                $("#table").datagrid('insertRow',{
                                        index:0,
                                        row: {
                                                roleid:roleid0,roletitle:roletitle0,roledescrib:roledescrib0,sysid:sysid0,cid:cid0,OLMK:OLMK0,OPRT:OPRT0
                                        }
                                });
                                $("#addBox").dialog({
                                        closed: true
                                });
                                $.messager.show({
                                        title:'提示',
                                        msg:'信息保存成功'
                                });
                                window.location.reload();
                        }
                })
        },
        look:function () {
                $("#lookTail").dialog({
                        closed: false
                })
        },
       sum:function () {
                $("#addForm").form('submit',{
                        url:"/localxres/funx/easyuircv/?stid=X7XeP8&id="+dftval($("#id").val(),"")+"&dbnm="+dftval(GetRequest().dbnm,"")+'&laydb='+dftval(GetRequest().laydb,""),
                        onSubmit:function () {
                                return $(this).form('validate')
                        },
                        success:function (data) {
                                roleid0=$("#p_roleid0").val();roletitle0=$("#p_roletitle0").val();roledescrib0=$("#p_roledescrib0").val();sysid0=$("#p_sysid0").val();cid0=$("#p_cid0").val();OLMK0=$("#p_OLMK0").val();OPRT0=$("#p_OPRT0").val();
                                $("#table").datagrid('insertRow',{
                                        index:0,
                                        row: {
                                                roleid:roleid0,roletitle:roletitle0,roledescrib:roledescrib0,sysid:sysid0,cid:cid0,OLMK:OLMK0,OPRT:OPRT0
                                        }
                                });
                                $("#addBox").dialog({
                                        closed: true
                                });
                                $.messager.show({
                                        title:'提示',
                                        msg:'信息保存成功'
                                });
                                window.location.reload();
                        }
                })
        },
        del:function () {
                var rows=$("#table").datagrid("getSelections");
               if(rows.length>0){
                       $.messager.confirm('确定删除','你确定要删除你选择的记录吗?',function (flg) {
                               if(flg){
                                       var ids=[];
                                       for(i=0;i<rows.length;i++){
                                               ids.push(rows[i].id);
                                       }
                                       var num=ids.length;
                                      $.ajax({
                                              type:'post',
                                              url:"/localxres/funx/easyuidel/?tabname=coode_role&dbnm="+dftval(GetRequest().dbnm,""),
                                              data:{
                                                      ids:ids.join(',')
                                              },
                                              beforesend:function () {
                                                      $("#table").datagrid('loading');                                                    
                                              },
                                              success:function (data) {
                                                      if(data){
                                                              $("#table").datagrid('loaded');
                                                              $("#table").datagrid('load');
                                                              $("#table").datagrid('unselectAll');
                                                              $.messager.show({
                                                                      title:'提示',
                                                                      msg:num+'个记录被删除'
                                                              })
                                                      }
                                                      else{
                                                              $.messager.show({
                                                                      title:'警示信息',
                                                                      msg:"信息删除失败"
                                                              })
                                                      }
                                              }
                                      })
                               }
                       })
               }
               else{
                 $.messager.alert('提示','请选择要删除的记录','info');
               }
        },
        delOne:function (id) {
                id=$("#table").datagrid('getSelected').id;
                $.messager.confirm('提示信息','是否删除所选择记录',function (flg) {
                        if(flg){
                                $.ajax({
                                        type:'post',
                                        url:'/localxres/funx/easyuidel/?tabname=coode_role&dbnm='+dftval(GetRequest().dbnm,"")+'&laydb='+dftval(GetRequest().laydb,""),
                                        data:{
                                                ID:id
                                        },
                                        beforesend:function () {
                                                $("#table").datagrid('loading');
                                        },
                                        success:function (data) {
                                                if(data){
                                                        $("#table").datagrid("loaded");
                                                        $("#table").datagrid("load");
                                                        $("#table").datagrid("unselectRow");
                                                        $.messager.show({
                                                                title:'提示信息',
                                                                msg:"信息删除成功"
                                                        })
                                                }
                                                else{
                                                        $.messager.show({
                                                                title:'警示信息',
                                                                msg:"信息删除失败"
                                                        })
                                                }
                                        }
                                })
                        }
                })
        }
}
prehref=location.href;
        if (prehref.indexOf("pnum:")>0){
         pn=intval(qian(hou(prehref,"pnum:"),"-"));
        }else if (prehref.indexOf("pnum=")>0){
         pn=intval(qian(hou(prehref,"pnum="),"&"));
        }else{
         pn=30;
        }
        $("#table").datagrid({
        title:"数据列表",
        iconCls:"icon-left02",
        url:'/localxres/funx/easyuilist/?stid=X7XeP8&dbnm='+dftval(GetRequest().dbnm,"")+'&datatype='+dftval(GetRequest().datatype,"")+'&laydb='+dftval(GetRequest().laydb,"")+makeurlqry(),
        fitColumns:true,
        striped:true,
        pagination:true,
        pageSize:pn,
        width:'100%',
        rownumbers:true,
        pageList:[pn,pn*2],
        pageNumber:1,
        nowrap:true,
        height:'auto',
        sortName:'id',
        checkOnSelect:false,
        sortOrder:'asc',
        toolbar: '#tabelBut',
        columns:[[
                {
                        checkbox:true,
                        field:'no',
                        width:100,
                        align:'center'
                },
                {field:'roleid',title:'角色id',width:100.000,align:'center'},{field:'roletitle',title:'角色标题',width:100.000,align:'center'},{field:'roledescrib',title:'角色描述',width:100.000,align:'center'},{field:'sysid',title:'系统ID',width:100.000,align:'center'},{field:'cid',title:'机构id',width:100.000,align:'center'},{field:'OLMK',title:'唯一标记',width:100.000,align:'center'},{field:'OPRT',title:'操作',width:100.000,align:'center'},            
                {
                        field:"opr",
                        title:'操作',
                        width:100,
                        align:'center',
                        formatter:function (val,row) {
                                e = '<a  id="updx" data-id="98" class=" operA"  onclick="obj.edit(\'' + row.id + '\')">编辑</a> ';
                                f = '<a  id="rfrx" data-id="98" class=" operA"  onclick="goitem(\'' + row.id + '\')">修改</a> ';
                                c = '<a  id="look" style="display:none;"  onclick="obj.look(\'' + row.id + '\')">流程查看</a> ';
                                d = '<a  id="delx" data-id="98" class=" operA01"  onclick="obj.delOne(\'' + row.id + '\')">删除</a> ';
                                return e+f+d+c;
                        }
                }
        ]]
})
$("#addBox").dialog({
        title:"信息内容",
        width:500,
        height:300,
        closed: true,
        modal:true,
        shadow:true
})
$("#lookTail").dialog({
        title:"信息内容",
        width:650,
        height:410,
        closed: true,
        modal:true,
        shadow:true
})
$("td").click(function (){var innerx,fieldx;fieldx=$(this).attr("field");innerx=$(this).html();if (strpos(innerx,fieldx)>43){}else{hidefield(fieldx);}});