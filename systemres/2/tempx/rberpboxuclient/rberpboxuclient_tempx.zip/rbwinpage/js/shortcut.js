//id,iconName,iconUrl,url,width,height
var shortcut = [
[0,"我的电脑","images/icos/01.png","http://www.baidu.com/?",1000,500],
[1,"我的图片","images/icos/02.png","http://www.17sucai.com/",1000,500],
[2,"我的音乐","images/icos/03.png","http://y.qq.com/",1000,500],
[3,"我的指南","images/icos/04.png","http://www.17sucai.com/",800,500],
[4,"应用程序","images/icos/05.png","http://www.17sucai.com/",600,500],
[5,"我的私信","images/icos/06.png","http://www.17sucai.com/",1000,500],
[6,"色盘","images/icos/07.png","http://www.17sucai.com/",1000,500],
[7,"云上传","images/icos/08.png","http://pan.baidu.com/disk/home",1000,500],
[8,"云下载","images/icos/09.png","http://pan.baidu.com/disk/home",1000,500],
[9,"行程","images/icos/10.png","http://www.17sucai.com/",1000,500],
[10,"记事本","images/icos/11.png","http://www.17sucai.com/",900,540],
];