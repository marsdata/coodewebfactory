/**
 +-------------------------------------------------------------------
 * jQuery FontScroll - 锟斤拷锟斤拷锟斤拷锟斤拷锟较癸拷锟斤拷锟斤拷锟� - http://java2.sinaapp.com
 +-------------------------------------------------------------------
 * @version    1.0.0 beta
 * @since      2014.06.12
 * @author     kongzhim <kongzhim@163.com> <http://java2.sinaapp.com>
 * @github     http://git.oschina.net/kzm/FontScroll
 +-------------------------------------------------------------------
 */

/*(function($){

    $.fn.FontScroll = function(options){
        var d = {time: 2000,s: 'fontColor',num: 1};
        var o = $.extend(d,options);
        

        this.children('ul').addClass('line');
        var _con = $('.line').eq(0);
        var _conH = _con.height(); //锟斤拷锟斤拷锟杰高讹拷
        var _conChildH = _con.children().eq(0).height();//一锟轿癸拷锟斤拷锟竭讹拷
        var _temp = _conChildH;  //锟斤拷时锟斤拷锟斤拷
        var _time = d.time;  //锟斤拷锟斤拷锟斤拷锟�
        var _s = d.s;  //锟斤拷锟斤拷锟斤拷锟�


        _con.clone().insertAfter(_con);//锟斤拷始锟斤拷锟斤拷隆

        //锟斤拷式锟斤拷锟斤拷
        var num = d.num;
        var _p = this.find('li');
        var allNum = _p.length;

        _p.eq(num).addClass(_s);


        var timeID = setInterval(Up,_time);
        console.log(timeID);
		this.hover(function(){clearInterval(timeID)},function(){timeID = setInterval(Up,_time);});

        function Up(){
            _con.animate({marginTop: '-'+_conChildH});
            //锟斤拷式锟斤拷锟斤拷
            _p.removeClass(_s);
            num += 1;
            _p.eq(num).addClass(_s);
            
            if(_conH == _conChildH){
                _con.animate({marginTop: '-'+_conChildH},"normal",over);
            } else {
                _conChildH += _temp;
            }
        }
        function over(){
            _con.attr("style",'margin-top:0');
            _conChildH = _temp;
            num = 1;
            _p.removeClass(_s);
            _p.eq(num).addClass(_s);
        }
    }
})(jQuery);*/



// JavaScript Document
(function($){
    $.fn.myScroll = function(options){
        //榛樿閰嶇疆
        var defaults = {
            speed:60,  //婊氬姩閫熷害,鍊艰秺澶ч€熷害瓒婃參
            rowHeight:24 //姣忚鐨勯珮搴�
        };

        var opts = $.extend({}, defaults, options),intId = [];

        function marquee(obj, step){

            obj.find("ul").animate({
                marginTop: '-=1'
            },0,function(){
                var s = Math.abs(parseInt($(this).css("margin-top")));
                if(s >= step){
                    $(this).find("li").slice(0, 1).appendTo($(this));
                    $(this).css("margin-top", 0);
                }
            });
        }

        this.each(function(i){
            var sh = opts["rowHeight"],speed = opts["speed"],_this = $(this);
            intId[i] = setInterval(function(){
                if(_this.find("ul").height()<=_this.height()){

                    clearInterval(intId[i]);
                }else{
                    marquee(_this, sh);
                }
            }, speed);

            _this.hover(function(){
                clearInterval(intId[i]);
            },function(){
                intId[i] = setInterval(function(){
                    if(_this.find("ul").height()<=_this.height()){
                        clearInterval(intId[i]);
                    }else{
                        marquee(_this, sh);
                    }
                }, speed);
            });

        });

    }

})(jQuery);