<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: ".killlaststr(glw())); // 生产环境替换为你的域名
header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *"); // 生产环境替换为指定域名
/**
 * 火山引擎ARK API Key模式 - 多模态对话（普通+流式）
 */
class ArkChatClient {
    private $apiKey; // 平台提供的API Key
    private $baseUrl;
    public function __construct($apiKey) {
        $this->apiKey = $apiKey;
        $this->baseUrl = "https://ark.cn-beijing.volces.com/api/v3/chat/completions";
    }
    /**
     * 构造多模态请求体
     */
    private function buildBody($model, $imageUrl, $text, $stream = false) {
        return json_encode([
            "model" => $model,
            "messages" => [
                [
                    "role" => "user",
                    "content" => [
                        ["type" => "image_url", "image_url" => ["url" => $imageUrl]],
                        ["type" => "text", "text" => $text]
                    ]
                ]
            ],
            "reasoningEffort" => "medium",
            "stream" => $stream,
            "temperature" => 0.7
        ], JSON_UNESCAPED_UNICODE);
    }
    /**
     * 普通同步请求
     */
    public function chatCompletions($model, $imageUrl, $text) {
        $headers = [
            "Content-Type: application/json; charset=utf-8",
            "Authorization: Bearer {$this->apiKey}" // 核心：Bearer鉴权
        ];
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $this->baseUrl,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $this->buildBody($model, $imageUrl, $text),
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_TIMEOUT => 30
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return [
            'code' => $httpCode,
            'data' => json_decode($response, true)
        ];
    }
    /**
     * 流式请求（逐行输出）
     */
    public function streamChatCompletions($model, $imageUrl, $text) {
        $headers = [
            "Content-Type: application/json; charset=utf-8",
            "Authorization: Bearer {$this->apiKey}"
        ];
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $this->baseUrl,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $this->buildBody($model, $imageUrl, $text, true),
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_WRITEFUNCTION => function($ch, $data) {
                foreach (explode("\n", trim($data)) as $line) {
                    if (str_starts_with($line, 'data: ')) {
                        $json = substr($line, 6);
                        if ($json === '[DONE]') break;
                        $res = json_decode($json, true);
                        echo $res['choices'][0]['delta']['content'] ?? '';
                        flush();
                    }
                }
                return strlen($data);
            }
        ]);
        curl_exec($ch);
        curl_close($ch);
    }
}
// ====================== 调用示例 ======================
// 替换为平台给你的API Key
$API_KEY = "9d7b38c6-05b4-4538-8bba-1443f64c2ed3";
$client = new ArkChatClient($API_KEY);
// 替换为你的推理接入点ID、图片URL、问题
$model = "doubao-seed-1-6-lite-251015";
$imageUrl = "https://ark-project.tos-cn-beijing.ivolces.com/images/view.jpeg";
$text = "这是哪里?";
// 1. 普通请求
//echo "----- 普通请求结果 -----\n";
$normalRes = $client->chatCompletions($model, $imageUrl, $text);
if ($normalRes['code'] == 200) {
    echo $normalRes['data']['choices'][0]['message']['content'] . "\n";
} else {
    echo "错误：" . json_encode($normalRes['data'], JSON_UNESCAPED_UNICODE) . "\n";
}
// 2. 流式请求
//echo "----- 流式请求结果 -----\n";
//$client->streamChatCompletions($model, $imageUrl, $text);
       session_write_close();
?>