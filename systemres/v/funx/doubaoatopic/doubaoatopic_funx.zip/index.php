<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       $apiKey = "9d7b38c6-05b4-4538-8bba-1443f64c2ed3";
$snox=$_GET["SNO"];
if (empty($apiKey)) {
    die("错误：未配置环境变量 ARK_API_KEY，请先设置API Key\n");
}
// 2. 定义API基础配置（和Python SDK的base_url对应）
$baseUrl = 'https://ark.cn-beijing.volces.com/api/v3';
$endpoint = '/images/generations'; // 文生图API端点
$fullUrl = $baseUrl . $endpoint;
// 3. 构建请求参数（与Python代码参数一一对应）
$drst=SX("select model,taskcode,taskdes from coode_arcpictask where SNO=".$snox);
$taskcode=tostring(anyvalue($drst,"taskcode",0));
$taskdes=tostring(anyvalue($drst,"taskdes",0));
$requestData = [
    'model' => 'doubao-seedream-4-0-250828', // 模型名称
    'prompt' => $taskdes,
    'sequential_image_generation' => 'disabled',
    'response_format' => 'url', // 返回图片URL（而非base64）
    'size' => '2K', // 图片尺寸
    'stream' => false, // 非流式响应
    'watermark' => false // 加水印
];
// 4. 初始化curl并配置请求
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $fullUrl,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($requestData), // 转JSON格式
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey // API认证（Bearer Token方式，Python SDK底层逻辑）
    ],
    CURLOPT_RETURNTRANSFER => true, // 返回响应内容而非直接输出
    CURLOPT_SSL_VERIFYPEER => true, // 验证SSL证书（生产环境建议开启）
    CURLOPT_TIMEOUT => 30 // 请求超时时间（文生图建议设长一点）
]);
// 5. 执行请求并处理响应
try {
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        throw new Exception('CURL请求错误：' . curl_error($ch));
    }
    // 解析JSON响应
    $responseData = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('响应JSON解析失败：' . $response);
    }
    // 检查API是否返回错误
    if (isset($responseData['error'])) {
        throw new Exception('API返回错误：' . $responseData['error']['message']);
        $zz=UX("update coode_arcpictask set STCODE='".$responseData['error']['message']."' where SNO=".$snox);
    }
    // 输出图片URL（和Python代码print(imagesResponse.data[0].url)对应）
    if (isset($responseData['data'][0]['url'])) {
        //echo "生成的图片URL：" . $responseData['data'][0]['url'] . "\n";
        $mdl="doubao-seedream-4-0-250828";
        $fpath="/worldxres/doubaoai/atopic/".$taskcode."/".$taskcode.".jpg";
        $mysrc=combineurl(localroot(),$fpath);
        $ss=GrabImage($responseData['data'][0]['url'], $mysrc);
        $zz=UX("update coode_arcpictask set fnsdes='".$fpath."',STATUS=1,model='".$mdl."',starttime=now(),finishtime=now(),picurl='".$responseData['data'][0]['url']."' where SNO=".$snox);
        echo makereturnjson("1","生成成功","");
    } else {
        throw new Exception('响应中未找到图片URL：' . json_encode($responseData));
    }
} catch (Exception $e) {
    die("执行失败：" . $e->getMessage() . "\n");
          echo makereturnjson("0","生成失败","");
} finally {
    curl_close($ch); // 关闭curl资源
}
       session_write_close();
?>