<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       class ArkClient {
    private $baseUrl;
    private $apiKey;
    private $model;
    /**
     * 初始化客户端
     * @param string $apiKey API密钥
     * @param string $baseUrl API基础地址
     * @param string $model 模型ID
     */
    public function __construct($apiKey, $baseUrl = "https://ark.cn-beijing.volces.com/api/v3", $model = "deepseek-v3-250324") {
        $this->apiKey = $apiKey;
        $this->baseUrl = $baseUrl;
        $this->model = $model;
    }
    /**
     * 标准请求（非流式）
     * @param array $messages 消息列表
     * @return string|null 回复内容
     * @throws Exception
     */
    public function chatCompletions($messages) {
        $url = $this->baseUrl . "/chat/completions";
        
        $payload = [
            "model" => $this->model,
            "messages" => $messages,
            "stream" => false
        ];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
            "Authorization: Bearer " . $this->apiKey
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if (curl_errno($ch)) {
            throw new Exception("CURL Error: " . curl_error($ch));
        }
        curl_close($ch);
        if ($httpCode !== 200) {
            throw new Exception("API Error ({$httpCode}): " . $response);
        }
        $result = json_decode($response, true);
        return $result['choices'][0]['message']['content'] ?? null;
    }
    /**
     * 流式请求
     * @param array $messages 消息列表
     * @throws Exception
     */
    public function chatCompletionsStream($messages) {
        $url = $this->baseUrl . "/chat/completions";
        
        $payload = [
            "model" => $this->model,
            "messages" => $messages,
            "stream" => true
        ];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
            "Authorization: Bearer " . $this->apiKey
        ]);
        // 流式响应相关配置
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_WRITEFUNCTION, function($ch, $data) {
            // 处理流式返回的数据
            $lines = explode("\n", $data);
            foreach ($lines as $line) {
                $line = trim($line);
                if (empty($line)) continue;
                
                // 移除 "data: " 前缀
                if (strpos($line, "data: ") === 0) {
                    $line = substr($line, 6);
                }
                
                // 结束标记
                if ($line === "[DONE]") break;
                
                if (!empty($line)) {
                    $chunk = json_decode($line, true);
                    if (isset($chunk['choices'][0]['delta']['content']) && $chunk['choices'][0]['delta']['content']) {
                        echo $chunk['choices'][0]['delta']['content'];
                        flush(); // 立即输出内容
                    }
                }
            }
            return strlen($data);
        });
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if (curl_errno($ch)) {
            throw new Exception("CURL Error: " . curl_error($ch));
        }
        curl_close($ch);
        if ($httpCode !== 200) {
            throw new Exception("API Error ({$httpCode})");
        }
    }
}
// ===================== 示例使用 =====================
try {
    // 1. 从环境变量获取API Key（推荐方式）
    // $apiKey = getenv('ARK_API_KEY');
    
    // 2. 或者直接设置API Key（测试用）
    $apiKey = "9d7b38c6-05b4-4538-8bba-1443f64c2ed3"; // 替换为你的实际API Key
    
    // 初始化客户端
    $client = new ArkClient($apiKey);
    // 构建消息
    $messages = [
        ["role" => "system", "content" => "你是人工智能助手."],
        ["role" => "user", "content" => "你好"]
    ];
    // 标准请求示例
    echo "----- standard request -----\n";
    $response = $client->chatCompletions($messages);
    echo $response . "\n\n";
    // 流式请求示例
    //echo "----- streaming request -----\n";
    //$client->chatCompletionsStream($messages);
    //echo "\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
       session_write_close();
?>