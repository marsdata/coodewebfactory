<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       date_default_timezone_set("Asia/Shanghai");
/**
 * 火山引擎 Ark 视频任务查询接口 PHP 实现
 * 支持分页、状态过滤、TaskID过滤、模型过滤，带API Key鉴权
 */
/**
 * 查询视频生成任务列表
 * @param string $apiKey 火山引擎 ARK API Key
 * @param array $params 查询参数（可选）
 *        - page_num: 页码（默认1）
 *        - page_size: 每页条数（默认10）
 *        - filter_status: 任务状态（如succeeded/failed/pending/running，可选）
 *        - filter_task_ids: 任务ID列表（逗号分隔字符串，如"task1,task2"，可选）
 *        - filter_model: 模型ID（如doubao-seedance-1-0-pro-250528，可选）
 * @return array 解析后的任务列表数据
 * @throws Exception
 */
function queryArkVideoTasks($apiKey, $params = []) {
    // 1. 基础配置
    $baseUrl = "https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks";
    
    // 2. 整理查询参数（默认值 + 用户传入值）
    $queryParams = [
        'page_num' => isset($params['page_num']) ? intval($params['page_num']) : 1,
        'page_size' => isset($params['page_size']) ? intval($params['page_size']) : 10
    ];
    
    // 3. 处理过滤参数（拼接filter.前缀）
    if (!empty($params['filter_status'])) {
        $queryParams['filter.status'] = $params['filter_status'];
    }
    if (!empty($params['filter_task_ids'])) {
        $queryParams['filter.task_ids'] = $params['filter_task_ids'];
    }
    if (!empty($params['filter_model'])) {
        $queryParams['filter.model'] = $params['filter_model'];
    }
    
    // 4. 拼接完整URL（带查询参数）
    $url = $baseUrl . '?' . http_build_query($queryParams);
    
    // 5. 初始化CURL请求
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_HTTPGET => true,
        CURLOPT_HTTPHEADER => [
            "Content-Type: application/json",
            "Authorization: Bearer " . $apiKey // API Key鉴权（核心）
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HEADER => false // 不返回响应头
    ]);
    
    // 6. 执行请求并处理响应
    try {
        $response = curl_exec($ch);
        
        // 检查CURL错误
        if (curl_errno($ch)) {
            throw new Exception("CURL请求错误: " . curl_error($ch));
        }
        
        // 检查HTTP状态码
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($httpCode !== 200) {
            throw new Exception("API请求失败，状态码: {$httpCode}，响应内容: {$response}");
        }
        
        // 7. 解析JSON响应
        $result = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("响应JSON解析失败: " . json_last_error_msg());
        }
        
        curl_close($ch);
        return $result;
        
    } catch (Exception $e) {
        curl_close($ch);
        throw new Exception("查询任务失败: " . $e->getMessage());
    }
}
// ===================== 示例使用 =====================
try {
    // 配置信息（替换为你的实际值）
    $apiKey = "9d7b38c6-05b4-4538-8bba-1443f64c2ed3";
    
    // 示例1：基础查询（第1页，每页10条）
    //echo "----- 基础查询（第1页，每页10条）-----\n";
    $basicResult = queryArkVideoTasks($apiKey);
    $taskResult=$basicResult;
    $rtnjson=json_encode($basicResult, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n\n";
    
    $jsondata=json_decode($rtnjson,false);
    $total=$jsondata->total;
    $itemx=$jsondata->items;
    
    
if (!empty($taskResult['items']) && is_array($taskResult['items'])) {
    foreach ($taskResult['items'] as $item) {
        try {
            // ========== 提取每个任务的字段（做空值保护，避免报错） ==========
            // 任务ID
            $tid = isset($item['id']) ? $item['id'] : '';
            // 创建时间（时间戳转Y-m-d H:i:s）
            $starttime = isset($item['created_at']) && is_numeric($item['created_at']) 
                ? date("Y-m-d H:i:s", $item['created_at']) : '';
            // 完成时间（时间戳转Y-m-d H:i:s）
            $finishtime = isset($item['updated_at']) && is_numeric($item['updated_at']) 
                ? date("Y-m-d H:i:s", $item['updated_at']) : '';
            // 视频比例
            $ratio = isset($item['ratio']) ? $item['ratio'] : '';
            // 完成token数
            $comtokens = isset($item['usage']['completion_tokens']) ? $item['usage']['completion_tokens'] : 0;
            // 总token数
            $tottokens = isset($item['usage']['total_tokens']) ? $item['usage']['total_tokens'] : 0;
            // 视频时长
            $duration = isset($item['duration']) ? $item['duration'] : 0;
            // 分辨率
            $resolution = isset($item['resolution']) ? $item['resolution'] : '';
            // 模型ID
            $mdl = isset($item['model']) ? $item['model'] : '';
            // 视频URL
            $vurl = isset($item['content']['video_url']) ? $item['content']['video_url'] : '';
            // 任务状态码（对应STCODE）
            $stt = isset($item['status']) ? $item['status'] : '';
            
            // ========== 拼接SQL插入语句（和你指定的格式完全一致） ==========
            $sqlx = "tasklabel,taskcode,starttime,finishtime,ratio,comtokens,totaltokens,duration,resolution,model,videourl,STATUS,STCODE";
            // tasklabel固定为"当日日期创建的任务"，STATUS固定为0
            $sqly = "'".date("Y-m-d")."创建的任务','".$tid."','".$starttime."','".$finishtime."','".$ratio."','".$comtokens."','".$tottokens."','".$duration."','".$resolution."','".$mdl."','".$vurl."',0,'".$stt."'";
        $extx=UX("select count(*) as result from coode_picvideotask where taskcode='".$tid."'");
         if (intval($extx)==0){
            // ========== 执行插入操作（使用你的UX函数） ==========
            $zz = UX("insert into coode_picvideotask(".$sqlx.")values(".$sqly.")");
         }else{
          $zz=UX("update coode_picvideotask set ratio='".$ratio."',comtokens='".$comtokens."',totaltokens='".$tottokens."',duration='".$duration."',resolution='".$resolution."',model='".$mdl."',videourl='".$vurl."',STCODE='".$stt."',startdate=date(now()),starttime='".$starttime."',finishtime='".$finishtime."' where taskcode='".$tid."'");
          $zz=UX("update coode_picvideotask set STATUS=1 where STCODE='succeeded'");
          $zz=UX("update coode_picvideotask set STATUS=0 where STCODE!='succeeded'");
         }
            // 可选：输出插入日志，便于调试
            //echo "任务 {$tid} 插入结果：" . ($zz ? "成功" : "失败") . "\n";
            
        } catch (Exception $e) {
            // 单个任务插入失败不中断整体循环，记录错误日志
            //echo "任务插入失败，错误信息：" . $e->getMessage() . "\n";
            continue;
        }
    }
    //echo "所有任务数据插入完成！\n";
} else {
    //echo "无可用的任务数据！\n";
}
     
    //echo $rtnjson;
    // 示例2：高级查询（指定页码、状态、TaskID、模型）
    // echo "----- 高级查询（筛选成功的任务）-----\n";
    //$advancedParams = [
    //    'page_num' => 1,
    //    'page_size' => 20,
    //    'filter_status' => 'succeeded', // 只查成功的任务
    //    'filter_task_ids' => 'cgt-20260123235141-bhf5j,cgt-20260123235236-cmhml,cgt-20260124002528-76rsr,cgt-20260124002634-mgj4k', // 只查指定TaskID
    //    'filter_model' => 'doubao-seedance-1-0-pro-250528' // 只查指定模型
    //];
    //$advancedResult = queryArkVideoTasks($apiKey, $advancedParams);
    //echo json_encode($advancedResult, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
    echo makereturnjson("1","成功 " ,"");
} catch (Exception $e) {
    echo makereturnjson("0","错误: " . $e->getMessage() ,"");
}
       session_write_close();
?>