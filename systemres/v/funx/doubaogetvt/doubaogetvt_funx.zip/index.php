<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       date_default_timezone_set("Asia/Shanghai");
/**
 * 火山引擎 Ark 视频任务查询接口 PHP 实现
 * 支持分页、状态过滤、TaskID过滤、模型过滤，带API Key鉴权
 */
/**
 * 查询视频生成任务列表
 * @param string $apiKey 火山引擎 ARK API Key
 * @param array $params 查询参数（可选）
 *        - page_num: 页码（默认1）
 *        - page_size: 每页条数（默认10）
 *        - filter_status: 任务状态（如succeeded/failed/pending/running，可选）
 *        - filter_task_ids: 任务ID列表（逗号分隔字符串，如"task1,task2"，可选）
 *        - filter_model: 模型ID（如doubao-seedance-1-0-pro-250528，可选）
 * @return array 解析后的任务列表数据
 * @throws Exception
 */
function queryArkVideoTasks($apiKey, $params = []) {
    // 1. 基础配置
    $baseUrl = "https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks";
    
    // 2. 整理查询参数（默认值 + 用户传入值）
    $queryParams = [
        'page_num' => isset($params['page_num']) ? intval($params['page_num']) : 1,
        'page_size' => isset($params['page_size']) ? intval($params['page_size']) : 10
    ];
    
    // 3. 处理过滤参数（拼接filter.前缀）
    if (!empty($params['filter_status'])) {
        $queryParams['filter.status'] = $params['filter_status'];
    }
    if (!empty($params['filter_task_ids'])) {
        $queryParams['filter.task_ids'] = $params['filter_task_ids'];
    }
    if (!empty($params['filter_model'])) {
        $queryParams['filter.model'] = $params['filter_model'];
    }
    
    // 4. 拼接完整URL（带查询参数）
    $url = $baseUrl . '?' . http_build_query($queryParams);
    
    // 5. 初始化CURL请求
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_HTTPGET => true,
        CURLOPT_HTTPHEADER => [
            "Content-Type: application/json",
            "Authorization: Bearer " . $apiKey // API Key鉴权（核心）
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HEADER => false // 不返回响应头
    ]);
    
    // 6. 执行请求并处理响应
    try {
        $response = curl_exec($ch);
        
        // 检查CURL错误
        if (curl_errno($ch)) {
            throw new Exception("CURL请求错误: " . curl_error($ch));
        }
        
        // 检查HTTP状态码
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($httpCode !== 200) {
            throw new Exception("API请求失败，状态码: {$httpCode}，响应内容: {$response}");
        }
        
        // 7. 解析JSON响应
        $result = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("响应JSON解析失败: " . json_last_error_msg());
        }
        
        curl_close($ch);
        return $result;
        
    } catch (Exception $e) {
        curl_close($ch);
        throw new Exception("查询任务失败: " . $e->getMessage());
    }
}
// ===================== 示例使用 =====================
try {
    // 配置信息（替换为你的实际值）
    $apiKey = "9d7b38c6-05b4-4538-8bba-1443f64c2ed3";
    
    // 示例1：基础查询（第1页，每页10条）
    //echo "----- 基础查询（第1页，每页10条）-----\n";
    $basicResult = queryArkVideoTasks($apiKey);
    $rtnjson=json_encode($basicResult, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n\n";
    var_dump($basicResult);
    $jsondata=json_decode($rtnjson,false);
    $total=$jsondata->total;
    $itemx=$jsondata->items;
    echo "---".$basicResult[0]["total"];
    if (intval($total)>0){
       for ($jj=0;$jj<$total;$jj++){
          $tid=$itemx[$jj]->id;
          $mdl=$itemx[$jj]->model;        
          $stt=$itemx[$jj]->status;
          $ctt=$itemx[$jj]->content;
          $vurl=$ctt->video_url;
          $usage=$ctt->usage;
          
          $comtokens=$usage->completion_tokens;
          $tottokens=$usage->total_tokens;
          $ratio=$ctt->ratio;
          $duration=$ctt->duration;
          $resolution=$ctt->resolution;
          $ta=intval($ctt->created_at);
          $tb=intval($ctt->updated_at);
          $starttime = date("Y-m-d H:i:s", $ta);
          $finishtime = date("Y-m-d H:i:s", $tb);
          
         $extx=UX("select count(*) as result from coode_picvideotask where taskcode='".$tid."'");
         if (intval($extx)==0){
          $sqlx="tasklabel,taskcode,starttime,finishtime,ratio,comtokens,totaltokens,duration,resolution,model,videourl,STATUS,STCODE";
          $sqly="'".date("Y-m-d")."创建的任务','".$tid."','".$starttime."','".$finishtime."','".$ratio."','".$comtokens."','".$tottokens."','".$duration."','".$resolution."','".$mdl."','".$vurl."',0,'".$stt."'";
          $zz=UX("insert into coode_picvideotask(".$sqlx.")values(".$sqly.")");
         }else{
              $zz=UX("update coode_picvideotask set starttime='".$starttime."',finishtime='".$finishtime."' where taskcode='".$tid."'");
         }
       }
    }
    //echo $rtnjson;
    // 示例2：高级查询（指定页码、状态、TaskID、模型）
    // echo "----- 高级查询（筛选成功的任务）-----\n";
    //$advancedParams = [
    //    'page_num' => 1,
    //    'page_size' => 20,
    //    'filter_status' => 'succeeded', // 只查成功的任务
    //    'filter_task_ids' => 'cgt-20260123235141-bhf5j,cgt-20260123235236-cmhml,cgt-20260124002528-76rsr,cgt-20260124002634-mgj4k', // 只查指定TaskID
    //    'filter_model' => 'doubao-seedance-1-0-pro-250528' // 只查指定模型
    //];
    //$advancedResult = queryArkVideoTasks($apiKey, $advancedParams);
    //echo json_encode($advancedResult, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
    
} catch (Exception $e) {
    echo "错误: " . $e->getMessage() . "\n";
}
       session_write_close();
?>