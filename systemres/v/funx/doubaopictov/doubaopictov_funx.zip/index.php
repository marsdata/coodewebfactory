<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
       class ArkI2VClient {
    private $baseUrl;
    private $apiKey;
    
    /**
     * 初始化客户端
     * @param string $apiKey API密钥
     * @param string $baseUrl API基础地址
     */
    public function __construct($apiKey, $baseUrl = "https://ark.cn-beijing.volces.com/api/v3") {
        $this->apiKey = $apiKey;
        $this->baseUrl = $baseUrl;
    }
    
    /**
     * 创建图生视频任务
     * @param string $modelId 模型ID
     * @param string $textPrompt 文本提示词（含参数）
     * @param string $imageUrl 首帧图片URL
     * @return array 任务创建结果（含task_id）
     * @throws Exception
     */
    public function createI2VTask($modelId, $textPrompt, $imageUrl) {
        $url = $this->baseUrl . "/content_generation/tasks";
        
        // 构建请求体（和Python SDK参数完全对应）
        $payload = [
            "model" => $modelId,
            "content" => [
                [
                    "type" => "text",
                    "text" => $textPrompt
                ],
                [
                    "type" => "image_url",
                    "image_url" => [
                        "url" => $imageUrl
                    ]
                ]
            ]
        ];
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_HTTPHEADER => [
                "Content-Type: application/json",
                "Authorization: Bearer " . $this->apiKey
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_TIMEOUT => 30
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if (curl_errno($ch)) {
            throw new Exception("CURL Error: " . curl_error($ch));
        }
        curl_close($ch);
        
        if ($httpCode !== 200) {
            throw new Exception("创建任务失败 ({$httpCode}): " . $response);
        }
        
        $result = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("响应解析失败: " . json_last_error_msg());
        }
        
        if (!isset($result['id'])) {
            throw new Exception("未获取到任务ID: " . json_encode($result));
        }
        
        return $result;
    }
    
    /**
     * 查询任务状态
     * @param string $taskId 任务ID
     * @return array 任务状态信息
     * @throws Exception
     */
    public function getTaskStatus($taskId) {
        $url = $this->baseUrl . "/content_generation/tasks/{$taskId}";
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_HTTPGET => true,
            CURLOPT_HTTPHEADER => [
                "Content-Type: application/json",
                "Authorization: Bearer " . $this->apiKey
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_TIMEOUT => 30
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if (curl_errno($ch)) {
            throw new Exception("CURL Error: " . curl_error($ch));
        }
        curl_close($ch);
        
        if ($httpCode !== 200) {
            throw new Exception("查询任务失败 ({$httpCode}): " . $response);
        }
        
        $result = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("响应解析失败: " . json_last_error_msg());
        }
        
        return $result;
    }
    
    /**
     * 轮询等待任务完成
     * @param string $taskId 任务ID
     * @param int $interval 轮询间隔（秒）
     * @param int $maxRetries 最大重试次数
     * @return array 任务完成结果
     * @throws Exception
     */
    public function pollTaskUntilComplete($taskId, $interval = 1, $maxRetries = 60) {
        $retryCount = 0;
        
        while ($retryCount < $maxRetries) {
            $taskInfo = $this->getTaskStatus($taskId);
            $status = $taskInfo['status'] ?? 'unknown';
            
            echo "当前状态: {$status}, 重试次数: {$retryCount}/{$maxRetries}\n";
            
            // 任务成功完成
            if ($status === "succeeded") {
                return $taskInfo;
            }
            
            // 任务失败
            if ($status === "failed") {
                $errorMsg = $taskInfo['error']['message'] ?? '未知错误';
                throw new Exception("任务执行失败: {$errorMsg} (Task ID: {$taskId})");
            }
            
            // 任务仍在处理中，继续轮询
            if (in_array($status, ['pending', 'running'])) {
                $retryCount++;
                sleep($interval);
                continue;
            }
            
            // 其他未知状态
            throw new Exception("未知任务状态: {$status} (Task ID: {$taskId})");
        }
        
        throw new Exception("任务轮询超时 ({$maxRetries}秒)，Task ID: {$taskId}");
    }
}
// ===================== 示例使用 =====================
try {
    // 配置信息（替换为你的实际值）
    $apiKey = "9d7b38c6-05b4-4538-8bba-1443f64c2ed3"; // 你的ARK API Key
    $modelId = "doubao-seedance-1-0-lite-i2v-250428"; // 图生视频模型ID
    $textPrompt = "天空的云飘动着，路上的车辆行驶  --resolution 720p  --duration 5 --camerafixed false --watermark true";
    $imageUrl = "https://ark-project.tos-cn-beijing.volces.com/doc_image/see_i2v.jpeg"; // 首帧图片URL
    
    // 初始化客户端
    $client = new ArkI2VClient($apiKey);
    
    // 1. 创建图生视频任务
    echo "----- 创建图生视频任务 -----\n";
    $createResult = $client->createI2VTask($modelId, $textPrompt, $imageUrl);
    $taskId = $createResult['id'];
    echo "任务创建成功，Task ID: {$taskId}\n";
    $sqlx="tasklabel,taskcode,taskdes,starttime,startdate,process,picurl,videourl,STATUS";
     $sqly="'".date("Y-m-d")."创建的任务','".$taskId."','5s',now(),date(now()),0,'','',0";
     $zz=UX("insert into coode_picvideotask(".$sqlx.")values(".$sqly.")");
    echo "创建结果: " . json_encode($createResult, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n\n";
    
    // 2. 轮询查询任务状态
    //echo "----- 轮询任务状态 -----\n";
    $taskResult = $client->pollTaskUntilComplete($taskId, 1, 60); // 轮询60秒，每秒查一次
    
    // 3. 输出任务完成结果
    //echo "\n----- 任务执行成功 -----\n";
    //echo "最终结果: " . json_encode($taskResult, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
    
    // 提取视频URL（核心结果）
    //if (isset($taskResult['output']['content'][0]['video_url']['url'])) {
    //    $videoUrl = $taskResult['output']['content'][0]['video_url']['url'];
      //  echo "\n生成的视频URL: {$videoUrl}\n";
    //}
    
} catch (Exception $e) {
    echo "\n错误: " . $e->getMessage() . "\n";
}


       session_write_close();
?>