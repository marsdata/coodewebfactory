<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
    error_reporting(0);
    register_shutdown_function('zyfshutdownfunc'); 
    set_error_handler('zyferror'); 
    include '../../EARTH.php';
    $stk=$_GET["stk"];
    eval(RESFUNSET("heartbeat"));
    eval(RESFUNSET("permision"));
    eval(RESFUNSET("quickvalue"));
     if ($stk==""){
         $stk=$_COOKIE["stoken"];
     }
     if ($stk!="" and $stk!="un"."defined"){
       $z=refreshstoken($stk);
     };
        $snox=$_GET["SNO"];
   $wrd=$_GET["wrd"];
   if ($wrd=="1"){
    $rstx=SX("select relycore,host,wrdid,wrdname from coode_hostregwrd where SNO=".$snox);
    $host=anyvalue($rstx,"host",0);
    $dmhost="wrdstock.hellowocao.com/".anyvalue($rstx,"relycore",0).anyvalue($rstx,"wrdid",0);
    $sysid=anyvalue($rstx,"wrdid",0);
    $sysname=anyvalue($rstx,"wrdname",0);
    $insmark=$sysid."@".date("Y-m-d");
   }else{
    $rstx=SX("select host,sysid,sysname from coode_hostregsys where SNO=".$snox);
    $host=anyvalue($rstx,"host",0);
    $dmhost=$host;
    $sysid=anyvalue($rstx,"sysid",0);
    $sysname=anyvalue($rstx,"sysname",0);
    $insmark=$sysid."@".date("Y-m-d");
   }
   
   $sqla="insmark,institle,host,sysid,OLMK,CRTOR,CRTM,UPTM";
   $sqlb="'".$insmark."','安装".$sysname."','".$dmhost."','".$sysid."','".onlymark()."','".$_COOKIE[uid]."',now(),now()";
   $ccc=UX("insert into coode_installidx(".$sqla.")values(".$sqlb.")");
   
   $kk=UX("delete from coode_installdetail where insmark='".$insmark."'");
   $sqla="host,insmark,institle,rescode,restype,restitle,vermd5,thisver,sysid,CRTM,UPTM,finishtime,OLMK,STATUS";
   $sqlb="host,'".$insmark."','".$sysname."',resmark,restype,restitle,hostver,thisver,grpid,now(),now(),now(),md5(RAND()*1000),0";
   $zz=UX("insert into coode_installdetail(".$sqla.")select ".$sqlb." from coode_hostregres where grpid='".$sysid."' and host='".$dmhost."'");
  
  $ss=UX("update coode_installdetail,coode_sysregres set coode_installdetail.thisver=coode_sysregres.vermd5 where coode_installdetal.sysid=coode_sysregres.grpid and coode_installdetail.rescode=coode_sysregres.resmark and coode_installdetail.restype=coode_sysregres.restype");    
  $ss=UX("update coode_installdetail,coode_sysregres set coode_installdetail.thisver=coode_wrdregres.vermd5 where coode_installdetal.sysid=coode_wrdregres.grpid and coode_installdetail.rescode=coode_wrdregres.resmark and coode_installdetail.restype=coode_wrdregres.restype");    
  $ss=UX("update coode_installdetail set PRIME=1 where vermd5=thisver");    
  $totres=UX("select count(*) as result from coode_installdetail where  grpid='".$sysid."' and host='".$host."'");
  $diffres=UX("select count(*) as result from coode_installdetail where PRIME=1 and  grpid='".$sysid."' and host='".$host."'");
  $ss=UX("update coode_hostressys set totres='".$totres."',insite='".$diffres."' where  sysid='".$sysid."' and host='".$host."'");
  $ss=UX("update coode_hostreswrd set totres='".$totres."',insite='".$diffres."' where  wrdid='".$sysid."' and host='".$host."'");
echo makereturnjson("1","准备成功","");
     session_write_close();
?>