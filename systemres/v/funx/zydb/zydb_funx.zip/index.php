<?php
 header('Content-Type:text/html;charset=utf-8');
 header("Access-Control-Allow-Origin:*");
 header("Access-Control-Allow-Headers:content-type");
 header("Access-Control-Request-Method:GET,POST");
 if(strtoupper($_SERVER['REQUEST_METHOD'])== 'OPTIONS'){
  exit;
 }
      error_reporting(0);
      register_shutdown_function('zyfshutdownfunc'); 
      set_error_handler('zyferror'); 
      include '../../EARTH.php';
      $stk=$_GET["stk"];
      eval(RESFUNSET("heartbeat"));
      eval(RESFUNSET("permision"));
      eval(RESFUNSET("quickvalue"));
       if ($stk==""){
               $stk=$_COOKIE["stoken"];
       }
       if ($stk!="" and $stk!="un"."defined"){
           $z=refreshstoken($stk);
       };
          
  
  $ss=UX("update coode_hostregres,coode_sysregres set coode_sysregres.mtmd5=coode_hostregres.hostver where coode_hostregres.restype=coode_sysregres.restype and coode_hostregres.resmark=coode_sysregres.resmark");
  $ss=UX("update coode_hostregres,coode_sysregres set coode_hostregres.thisver=coode_sysregres.vermd5 where coode_hostregres.restype=coode_sysregres.restype and coode_hostregres.resmark=coode_sysregres.resmark");
  $ss=UX("update coode_syshostres,coode_sysregres set coode_syshostres.vermd5=coode_sysregres.vermd5 where coode_syshostres.sysid=coode_sysregres.grpid and coode_syshostres.rescode=coode_sysregres.resmark and coode_syshostres.restype=coode_sysregres.restype");    
  $nn=UX("update coode_syshostres set STATUS=1 where vermd5=mtver");
  $nn=UX("update coode_hostregres set STATUS=1 where thisver=hostver");
echo makereturnjson("1","对比成功","");
       session_write_close();
?>